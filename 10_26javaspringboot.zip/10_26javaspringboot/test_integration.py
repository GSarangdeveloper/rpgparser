"""
Integration Tests for Spring Boot API Generator
Tests the complete workflow from specification to code generation
"""

import unittest
import json
import tempfile
import os
import shutil
import zipfile
import time
from pathlib import Path
from app import app
from services.openapi_parser_service import OpenAPIParserService
from services.postman_parser_service import PostmanParserService
from services.code_generator_service import CodeGeneratorService
from services.validation_service import ValidationService
from services.error_handler import ErrorHandler, ValidationError


class IntegrationTestCase(unittest.TestCase):
    """Base test case with common setup"""

    def setUp(self):
        """Set up test client and temp directory"""
        self.app = app
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up temp directory"""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)


class TestCompleteWorkflow(IntegrationTestCase):
    """Test the complete generation workflow"""

    def test_manual_configuration_workflow(self):
        """Test project generation with manual configuration"""
        # Prepare request data
        request_data = {
            'projectConfiguration': {
                'projectName': 'Test API',
                'description': 'Integration test project',
                'groupId': 'com.test',
                'artifactId': 'test-api',
                'packageName': 'com.test.api',
                'springBootVersion': '3.2.0',
                'javaVersion': '17',
                'buildTool': 'gradle',
                'packaging': 'jar'
            },
            'apiSpecification': {
                'baseControllerPath': '/api/v1',
                'controllerClassName': 'Test',
                'description': 'Test Controller',
                'endpoints': [
                    {
                        'id': '1',
                        'name': 'getAllItems',
                        'httpMethod': 'GET',
                        'path': '/items',
                        'description': 'Get all items',
                        'response': {
                            'type': 'LIST',
                            'httpStatus': '200',
                            'dataType': 'ItemResponse',
                            'wrapInResponseEntity': True
                        }
                    }
                ]
            },
            'generationOptions': {
                'includeServiceLayer': True,
                'includeExceptionHandling': True,
                'includeValidation': True,
                'includeLogging': True,
                'generateTests': True
            }
        }

        # Generate project
        response = self.client.post(
            '/api/v1/generate/project',
            data=json.dumps(request_data),
            content_type='application/json'
        )

        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertIn('projectId', data)

        # Download generated project
        project_id = data['projectId']
        download_response = self.client.get(f'/api/v1/download/{project_id}')
        self.assertEqual(download_response.status_code, 200)
        self.assertEqual(download_response.content_type, 'application/zip')

    def test_openapi_upload_workflow(self):
        """Test project generation with OpenAPI file upload"""
        # Create sample OpenAPI file
        openapi_content = """
openapi: 3.0.0
info:
  title: Test API
  version: 1.0.0
paths:
  /users:
    get:
      summary: Get users
      responses:
        '200':
          description: Success
"""
        openapi_file = os.path.join(self.temp_dir, 'openapi.yaml')
        with open(openapi_file, 'w') as f:
            f.write(openapi_content)

        # Upload file
        with open(openapi_file, 'rb') as f:
            response = self.client.post(
                '/api/v1/upload/specification',
                data={'file': (f, 'openapi.yaml')},
                content_type='multipart/form-data'
            )

        # Verify parsing
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertIn('data', data)

    def test_postman_collection_workflow(self):
        """Test project generation with Postman collection"""
        # Create sample Postman collection
        postman_collection = {
            "info": {
                "name": "Test Collection",
                "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
            },
            "item": [
                {
                    "name": "Get Users",
                    "request": {
                        "method": "GET",
                        "url": {
                            "raw": "{{baseUrl}}/users",
                            "host": ["{{baseUrl}}"],
                            "path": ["users"]
                        }
                    }
                }
            ]
        }

        postman_file = os.path.join(self.temp_dir, 'postman.json')
        with open(postman_file, 'w') as f:
            json.dump(postman_collection, f)

        # Upload file
        with open(postman_file, 'rb') as f:
            response = self.client.post(
                '/api/v1/upload/specification',
                data={'file': (f, 'postman.json')},
                content_type='multipart/form-data'
            )

        # Verify parsing
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertEqual(data['type'], 'Postman Collection')

    def test_code_preview_workflow(self):
        """Test code preview functionality"""
        request_data = {
            'projectConfiguration': {
                'packageName': 'com.test.api'
            },
            'apiSpecification': {
                'controllerClassName': 'User',
                'baseControllerPath': '/api',
                'endpoints': [
                    {
                        'name': 'getUser',
                        'httpMethod': 'GET',
                        'path': '/users/{id}',
                        'requestParameters': [
                            {
                                'name': 'id',
                                'type': 'Long',
                                'parameterLocation': 'PATH',
                                'required': True
                            }
                        ]
                    }
                ]
            }
        }

        response = self.client.post(
            '/api/v1/preview/code',
            data=json.dumps(request_data),
            content_type='application/json'
        )

        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertIn('preview', data)
        self.assertIn('controller', data['preview'])


class TestValidation(IntegrationTestCase):
    """Test input validation"""

    def test_project_configuration_validation(self):
        """Test project configuration validation"""
        # Missing required fields
        invalid_data = {
            'projectConfiguration': {
                'projectName': 'Test'
                # Missing groupId, artifactId, packageName
            }
        }

        response = self.client.post(
            '/api/v1/generate/project',
            data=json.dumps(invalid_data),
            content_type='application/json'
        )

        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertFalse(data['success'])

    def test_invalid_java_version(self):
        """Test invalid Java version validation"""
        request_data = {
            'projectConfiguration': {
                'projectName': 'Test',
                'groupId': 'com.test',
                'artifactId': 'test',
                'packageName': 'com.test',
                'javaVersion': '99'  # Invalid version
            }
        }

        response = self.client.post(
            '/api/v1/generate/project',
            data=json.dumps(request_data),
            content_type='application/json'
        )

        self.assertEqual(response.status_code, 400)

    def test_invalid_http_method(self):
        """Test invalid HTTP method validation"""
        request_data = {
            'projectConfiguration': {
                'projectName': 'Test',
                'groupId': 'com.test',
                'artifactId': 'test',
                'packageName': 'com.test'
            },
            'apiSpecification': {
                'endpoints': [
                    {
                        'name': 'test',
                        'httpMethod': 'INVALID',  # Invalid method
                        'path': '/test'
                    }
                ]
            }
        }

        response = self.client.post(
            '/api/v1/generate/project',
            data=json.dumps(request_data),
            content_type='application/json'
        )

        self.assertEqual(response.status_code, 400)

    def test_file_size_validation(self):
        """Test file size limit validation"""
        # Create a file larger than 10MB
        large_file = os.path.join(self.temp_dir, 'large.json')
        with open(large_file, 'wb') as f:
            f.write(b'x' * (11 * 1024 * 1024))  # 11MB

        with open(large_file, 'rb') as f:
            response = self.client.post(
                '/api/v1/upload/specification',
                data={'file': (f, 'large.json')},
                content_type='multipart/form-data'
            )

        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('exceeds', data['error'].lower())

    def test_invalid_file_type(self):
        """Test invalid file type validation"""
        invalid_file = os.path.join(self.temp_dir, 'test.txt')
        with open(invalid_file, 'w') as f:
            f.write('Not a valid specification')

        with open(invalid_file, 'rb') as f:
            response = self.client.post(
                '/api/v1/upload/specification',
                data={'file': (f, 'test.txt')},
                content_type='multipart/form-data'
            )

        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('Invalid file type', data['error'])


class TestParsers(IntegrationTestCase):
    """Test specification parsers"""

    def test_openapi_parser(self):
        """Test OpenAPI parser with various formats"""
        parser = OpenAPIParserService()

        # Test OpenAPI 3.0
        openapi_spec = {
            'openapi': '3.0.0',
            'info': {'title': 'Test', 'version': '1.0'},
            'paths': {
                '/test': {
                    'get': {
                        'summary': 'Test endpoint',
                        'responses': {'200': {'description': 'Success'}}
                    }
                }
            }
        }

        result = parser.parse_specification(openapi_spec)
        self.assertIn('projectConfiguration', result)
        self.assertIn('apiSpecification', result)
        self.assertEqual(len(result['apiSpecification']['endpoints']), 1)

    def test_postman_parser(self):
        """Test Postman collection parser"""
        parser = PostmanParserService()

        collection = json.dumps({
            "info": {
                "name": "Test",
                "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
            },
            "item": [
                {
                    "name": "Test Request",
                    "request": {
                        "method": "POST",
                        "url": "http://localhost:8080/api/test"
                    }
                }
            ]
        })

        result = parser.parse_collection(collection)
        self.assertIn('projectConfiguration', result)
        self.assertIn('apiSpecification', result)

    def test_swagger_parser(self):
        """Test Swagger 2.0 parser"""
        parser = OpenAPIParserService()

        swagger_spec = {
            'swagger': '2.0',
            'info': {'title': 'Test', 'version': '1.0'},
            'paths': {
                '/test': {
                    'get': {
                        'summary': 'Test endpoint',
                        'responses': {'200': {'description': 'Success'}}
                    }
                }
            }
        }

        result = parser.parse_specification(swagger_spec)
        self.assertIn('projectConfiguration', result)
        self.assertIn('apiSpecification', result)


class TestCodeGeneration(IntegrationTestCase):
    """Test code generation service"""

    def test_controller_generation(self):
        """Test controller code generation"""
        generator = CodeGeneratorService()

        project_config = {'packageName': 'com.test'}
        api_spec = {
            'controllerClassName': 'Test',
            'baseControllerPath': '/api',
            'endpoints': [
                {
                    'name': 'getTest',
                    'httpMethod': 'GET',
                    'path': '/test',
                    'response': {
                        'type': 'SINGLE_OBJECT',
                        'httpStatus': '200',
                        'dataType': 'TestResponse'
                    }
                }
            ]
        }
        generation_options = {
            'includeServiceLayer': True,
            'includeValidation': True
        }

        result = generator.generate_code(project_config, api_spec, generation_options)

        # Verify controller was generated
        controller_key = 'src/main/java/com/test/controller/TestController.java'
        self.assertIn(controller_key, result)
        controller_code = result[controller_key]
        self.assertIn('@RestController', controller_code)
        self.assertIn('@GetMapping', controller_code)

    def test_service_generation(self):
        """Test service layer generation"""
        generator = CodeGeneratorService()

        project_config = {'packageName': 'com.test'}
        api_spec = {
            'controllerClassName': 'User',
            'endpoints': []
        }
        generation_options = {
            'includeServiceLayer': True
        }

        result = generator.generate_code(project_config, api_spec, generation_options)

        # Verify service was generated
        service_key = 'src/main/java/com/test/service/UserService.java'
        self.assertIn(service_key, result)

    def test_test_generation(self):
        """Test unit test generation"""
        generator = CodeGeneratorService()

        project_config = {'packageName': 'com.test'}
        api_spec = {
            'controllerClassName': 'Product',
            'endpoints': [
                {
                    'name': 'getProduct',
                    'httpMethod': 'GET',
                    'path': '/products/{id}'
                }
            ]
        }
        generation_options = {
            'generateTests': True
        }

        result = generator.generate_code(project_config, api_spec, generation_options)

        # Verify test was generated
        test_key = 'src/test/java/com/test/controller/ProductControllerTest.java'
        self.assertIn(test_key, result)
        test_code = result[test_key]
        self.assertIn('@SpringBootTest', test_code)
        self.assertIn('@Test', test_code)


class TestErrorHandling(IntegrationTestCase):
    """Test error handling"""

    def test_error_handler(self):
        """Test error handler utility"""
        handler = ErrorHandler()

        # Test required fields validation
        with self.assertRaises(ValidationError):
            handler.validate_required_fields(
                {'field1': 'value'},
                ['field1', 'field2'],
                'test'
            )

        # Test string length validation
        with self.assertRaises(ValidationError):
            handler.validate_string_length(
                'ab',
                'test_field',
                min_length=3
            )

        # Test pattern validation
        with self.assertRaises(ValidationError):
            handler.validate_pattern(
                '123',
                'test_field',
                r'^[a-z]+$',
                'lowercase letters'
            )

        # Test enum validation
        with self.assertRaises(ValidationError):
            handler.validate_enum(
                'invalid',
                'test_field',
                ['valid1', 'valid2']
            )

    def test_api_error_responses(self):
        """Test API error response format"""
        # Test 404 error
        response = self.client.get('/api/v1/download/nonexistent')
        self.assertEqual(response.status_code, 404)
        data = json.loads(response.data)
        self.assertFalse(data['success'])
        self.assertIn('error', data)

        # Test missing file in upload
        response = self.client.post(
            '/api/v1/upload/specification',
            data={},
            content_type='multipart/form-data'
        )
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertFalse(data['success'])
        self.assertIn('No file provided', data['error'])


class TestHealthCheck(IntegrationTestCase):
    """Test health check endpoint"""

    def test_health_endpoint(self):
        """Test health check returns proper status"""
        response = self.client.get('/api/v1/health')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'healthy')
        self.assertIn('timestamp', data)
        self.assertIn('services', data)


class TestProgressTracking(IntegrationTestCase):
    """Test progress tracking with SSE"""

    def test_progress_endpoint(self):
        """Test progress SSE endpoint"""
        # Note: Full SSE testing requires special handling
        # This tests basic endpoint availability
        response = self.client.get('/api/v1/progress/test-project-id')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content_type, 'text/event-stream')


def run_integration_tests():
    """Run all integration tests"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Add test cases
    suite.addTests(loader.loadTestsFromTestCase(TestCompleteWorkflow))
    suite.addTests(loader.loadTestsFromTestCase(TestValidation))
    suite.addTests(loader.loadTestsFromTestCase(TestParsers))
    suite.addTests(loader.loadTestsFromTestCase(TestCodeGeneration))
    suite.addTests(loader.loadTestsFromTestCase(TestErrorHandling))
    suite.addTests(loader.loadTestsFromTestCase(TestHealthCheck))
    suite.addTests(loader.loadTestsFromTestCase(TestProgressTracking))

    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Return success/failure
    return result.wasSuccessful()


if __name__ == '__main__':
    success = run_integration_tests()
    exit(0 if success else 1)