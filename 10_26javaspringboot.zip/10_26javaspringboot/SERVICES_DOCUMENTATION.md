# Services Documentation - Spring Boot API Generator

## Table of Contents
1. [Overview](#overview)
2. [InitializrService](#initializrservice)
3. [CodeGeneratorService](#codegeneratorservice)
4. [ProjectModifierService](#projectmodifierservice)
5. [ValidationService](#validationservice)
6. [OpenAPIParserService](#openapiparserservice)
7. [PostmanParserService](#postmanparserservice)
8. [ErrorHandler](#errorhandler)
9. [Service Integration](#service-integration)
10. [Best Practices](#best-practices)

## Overview

The Spring Boot API Generator uses a service-oriented architecture where each service has a specific responsibility. Services are designed to be:
- **Loosely coupled**: Minimal dependencies between services
- **Highly cohesive**: Single responsibility per service
- **Testable**: Easy to unit test in isolation
- **Reusable**: Can be used in different contexts

### Service Layer Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     Flask Routes                         │
└─────────────────────────┬───────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────┐
│                   Service Layer                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │  Validation  │  │   Parsers    │  │  Generators  │ │
│  │   Service    │  │   Services   │  │   Service    │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │ Initializr   │  │   Modifier   │  │    Error     │ │
│  │   Service    │  │   Service    │  │   Handler    │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└──────────────────────────────────────────────────────────┘
```

## InitializrService

### Purpose
Integrates with Spring Initializr API to download Spring Boot starter projects with specified dependencies and configuration.

### Location
`services/initializr_service.py`

### Class Definition

```python
class InitializrService:
    """Service to interact with Spring Initializr API"""

    BASE_URL = "https://start.spring.io"
    TIMEOUT = 30  # seconds
    RETRY_COUNT = 3
    RETRY_DELAY_BASE = 1  # Base delay in seconds for exponential backoff
    CACHE_DURATION = 900  # 15 minutes in seconds
```

### Key Methods

#### download_project(config: Dict) -> bytes

Downloads a Spring Boot starter project from Spring Initializr.

**Parameters:**
- `config` (Dict): Project configuration containing:
  - `type`: Project type (default: "gradle-project")
  - `language`: Programming language (default: "java")
  - `bootVersion`: Spring Boot version
  - `baseDir`: Base directory name
  - `groupId`: Group ID
  - `artifactId`: Artifact ID
  - `name`: Project name
  - `description`: Project description
  - `packageName`: Package name
  - `packaging`: Packaging type (jar/war)
  - `javaVersion`: Java version
  - `dependencies`: Comma-separated dependency IDs

**Returns:**
- `bytes`: ZIP file content

**Features:**
- Retry logic with exponential backoff
- Handles service unavailability (503 errors)
- Timeout handling
- Session reuse for performance

**Example:**
```python
service = InitializrService()
config = {
    'bootVersion': '3.2.0',
    'groupId': 'com.example',
    'artifactId': 'demo',
    'dependencies': 'web,data-jpa,h2'
}
zip_content = service.download_project(config)
```

#### get_metadata() -> Dict

Retrieves Spring Initializr metadata with caching.

**Returns:**
- `Dict`: Metadata including available versions, dependencies, etc.

**Features:**
- 15-minute cache for performance
- Automatic cache invalidation
- Fallback to direct fetch on cache miss

**Example:**
```python
metadata = service.get_metadata()
boot_versions = metadata.get('bootVersion', {}).get('values', [])
```

### Configuration

```python
# Environment variables
SPRING_INITIALIZR_URL = os.getenv('INITIALIZR_URL', 'https://start.spring.io')
INITIALIZR_TIMEOUT = int(os.getenv('INITIALIZR_TIMEOUT', '30'))
RETRY_COUNT = int(os.getenv('RETRY_COUNT', '3'))
```

### Error Handling

```python
try:
    zip_content = service.download_project(config)
except requests.Timeout:
    # Handle timeout
except requests.RequestException as e:
    # Handle other request errors
except Exception as e:
    # Handle unexpected errors
```

## CodeGeneratorService

### Purpose
Generates Java source code files using Jinja2 templates based on API specifications.

### Location
`services/code_generator_service.py`

### Class Definition

```python
class CodeGeneratorService:
    """Service to generate Spring Boot code using templates"""

    def __init__(self):
        template_dir = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            'templates',
            'java'
        )
        self.env = Environment(loader=FileSystemLoader(template_dir))
```

### Key Methods

#### generate_code(project_config, api_spec, generation_options) -> Dict[str, str]

Generates all code files based on specifications.

**Parameters:**
- `project_config` (Dict): Project configuration
  - `packageName`: Base package name
  - `projectName`: Project name
- `api_spec` (Dict): API specification
  - `controllerClassName`: Controller class name
  - `baseControllerPath`: Base URL path
  - `endpoints`: List of endpoint configurations
- `generation_options` (Dict): Generation options
  - `includeServiceLayer`: Generate service layer
  - `includeExceptionHandling`: Generate exception handlers
  - `includeValidation`: Add validation annotations
  - `generateTests`: Generate unit tests
  - `generateRepository`: Generate JPA repositories

**Returns:**
- `Dict[str, str]`: Map of file paths to file contents

**Example:**
```python
generator = CodeGeneratorService()
files = generator.generate_code(
    project_config={'packageName': 'com.example'},
    api_spec={'controllerClassName': 'User', 'endpoints': [...]},
    generation_options={'includeServiceLayer': True}
)
# files = {
#     'src/main/java/com/example/controller/UserController.java': '...',
#     'src/main/java/com/example/service/UserService.java': '...'
# }
```

#### Template Methods

##### _generate_controller()
Generates REST controller with endpoints.

**Template Variables:**
- `package_name`: Package for controllers
- `class_name`: Controller class name
- `service_name`: Service class name
- `base_path`: Base URL path
- `endpoints`: Endpoint configurations
- `imports`: Required imports

##### _generate_service()
Generates service interface and implementation.

**Template Variables:**
- `package_name`: Package for services
- `class_name`: Service class name
- `methods`: Service methods

##### _generate_dto()
Generates request/response DTOs.

**Template Variables:**
- `package_name`: Package for DTOs
- `dto_name`: DTO class name
- `fields`: DTO fields with validation

##### _generate_test()
Generates JUnit 5 tests.

**Template Variables:**
- `package_name`: Package for tests
- `class_name`: Test class name
- `endpoints`: Endpoints to test

### Template System

#### Template Location
```
templates/java/
├── controller.java.j2
├── controller_test.java.j2
├── service.java.j2
├── service_impl.java.j2
├── dto_request.java.j2
├── dto_response.java.j2
├── entity.java.j2
├── repository.java.j2
├── exception.java.j2
└── global_exception_handler.java.j2
```

#### Custom Filters
```python
# Available Jinja2 filters
{{ value | camelcase }}  # Convert to camelCase
{{ value | pascalcase }} # Convert to PascalCase
{{ value | snakecase }}  # Convert to snake_case
{{ value | kebabcase }}  # Convert to kebab-case
```

## ProjectModifierService

### Purpose
Modifies Spring Initializr ZIP files by adding generated code and updating configurations.

### Location
`services/project_modifier_service.py`

### Class Definition

```python
class ProjectModifierService:
    """Service to modify Spring Boot project ZIP files"""

    def modify_project(
        self,
        zip_content: bytes,
        generated_files: Dict[str, str],
        dependencies: List[str] = None
    ) -> bytes:
        """Add generated files to project ZIP"""
```

### Key Methods

#### modify_project(zip_content, generated_files, dependencies) -> bytes

Modifies ZIP file by adding generated files.

**Parameters:**
- `zip_content` (bytes): Original ZIP file content
- `generated_files` (Dict[str, str]): Map of paths to file contents
- `dependencies` (List[str]): Additional dependencies to add

**Returns:**
- `bytes`: Modified ZIP file content

**Process:**
1. Open original ZIP file
2. Find source directory structure
3. Add generated files at correct locations
4. Update build.gradle if needed
5. Return modified ZIP

**Example:**
```python
modifier = ProjectModifierService()
generated_files = {
    'src/main/java/com/example/controller/UserController.java': controller_code,
    'src/main/java/com/example/service/UserService.java': service_code
}
modified_zip = modifier.modify_project(original_zip, generated_files)
```

#### Helper Methods

##### _find_src_path(zip_file: ZipFile) -> str
Finds the source directory path in ZIP.

##### _get_package_path(package_name: str) -> str
Converts package name to directory path.

##### _update_build_file(zip_file: ZipFile, dependencies: List[str])
Updates build.gradle with additional dependencies.

### ZIP Structure Handling

```python
# Expected structure
project.zip/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/example/demo/
│   │   └── resources/
│   └── test/
├── build.gradle
└── settings.gradle

# Generated structure
project.zip/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/example/demo/
│   │   │       ├── controller/
│   │   │       ├── service/
│   │   │       ├── dto/
│   │   │       └── exception/
```

## ValidationService

### Purpose
Provides 4-layer validation architecture for input data validation.

### Location
`services/validation_service.py`

### Class Definition

```python
class ValidationService:
    """4-Layer validation service for comprehensive input validation"""

    class ValidationLayer(Enum):
        INPUT_SANITIZATION = 1
        SCHEMA_VALIDATION = 2
        BUSINESS_RULES = 3
        DEPENDENCY_VALIDATION = 4
```

### Validation Layers

#### Layer 1: Input Sanitization
Cleans and normalizes input data.

**Operations:**
- Remove leading/trailing whitespace
- Normalize empty strings to None
- Remove dangerous characters
- Convert types where appropriate

**Example:**
```python
def _sanitize_input(self, data: Dict) -> Dict:
    sanitized = {}
    for key, value in data.items():
        if isinstance(value, str):
            value = value.strip()
            if not value:
                value = None
        sanitized[key] = value
    return sanitized
```

#### Layer 2: Schema Validation
Validates data structure and types.

**Checks:**
- Required fields presence
- Field types
- Nested structure validation
- Array/object validation

**Example:**
```python
def _validate_schema(self, data: Dict) -> Dict:
    errors = []

    # Check required fields
    required = ['projectName', 'groupId', 'artifactId']
    for field in required:
        if field not in data:
            errors.append(f"Missing required field: {field}")

    if errors:
        raise ValidationError("Schema validation failed", errors)

    return data
```

#### Layer 3: Business Rules
Applies domain-specific business logic.

**Rules:**
- Package name format
- Version compatibility
- Dependency conflicts
- Naming conventions

**Example:**
```python
def _validate_business_rules(self, data: Dict) -> Dict:
    errors = []

    # Validate Java package name
    package_pattern = r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$'
    if not re.match(package_pattern, data.get('packageName', '')):
        errors.append("Invalid package name format")

    # Check Java version compatibility
    java_version = data.get('javaVersion')
    boot_version = data.get('springBootVersion')
    if not self._check_compatibility(java_version, boot_version):
        errors.append(f"Java {java_version} incompatible with Boot {boot_version}")

    return data
```

#### Layer 4: Dependency Validation
Validates dependencies and relationships.

**Checks:**
- Dependency compatibility
- Required dependencies
- Conflicting dependencies
- Version constraints

**Example:**
```python
def _validate_dependencies(self, data: Dict) -> Dict:
    dependencies = data.get('dependencies', [])

    # Check for conflicts
    if 'web' in dependencies and 'webflux' in dependencies:
        raise ValidationError("Cannot use both web and webflux")

    # Check required dependencies
    if 'data-jpa' in dependencies and 'database' not in dependencies:
        dependencies.append('h2')  # Add default database

    return data
```

### Usage

```python
validator = ValidationService()

# Validate through all layers
validated_data = validator.validate_all(input_data)

# Validate specific layer
sanitized = validator.validate(input_data, ValidationLayer.INPUT_SANITIZATION)
```

### Error Codes

| Code | Description | Layer |
|------|-------------|-------|
| `MISSING_FIELD` | Required field missing | Schema |
| `INVALID_TYPE` | Wrong field type | Schema |
| `INVALID_FORMAT` | Format validation failed | Business |
| `DEPENDENCY_CONFLICT` | Conflicting dependencies | Dependency |
| `VERSION_INCOMPATIBLE` | Version mismatch | Business |

## OpenAPIParserService

### Purpose
Parses OpenAPI 3.0 and Swagger 2.0 specifications into internal configuration format.

### Location
`services/openapi_parser_service.py`

### Class Definition

```python
class OpenAPIParserService:
    """Service for parsing OpenAPI/Swagger specifications"""

    SUPPORTED_VERSIONS = ['3.0', '3.1', '2.0']

    def parse_specification(self, spec: Dict) -> Dict:
        """Parse OpenAPI/Swagger specification to configuration"""
```

### Key Methods

#### parse_specification(spec: Dict) -> Dict

Parses OpenAPI/Swagger specification.

**Parameters:**
- `spec` (Dict): OpenAPI/Swagger specification object

**Returns:**
- `Dict`: Internal configuration format

**Version Detection:**
```python
if 'openapi' in spec:
    # OpenAPI 3.x
    return self._parse_openapi_3(spec)
elif 'swagger' in spec:
    # Swagger 2.0
    return self._parse_swagger_2(spec)
else:
    raise ValueError("Unknown specification format")
```

#### parse_file(file_path: str) -> Dict

Parses specification from file.

**Supported Formats:**
- YAML (.yaml, .yml)
- JSON (.json)

**Example:**
```python
parser = OpenAPIParserService()
config = parser.parse_file('openapi.yaml')
```

#### parse_content(content: str, format: str) -> Dict

Parses specification from string content.

**Parameters:**
- `content` (str): Specification content
- `format` (str): Content format ('yaml' or 'json')

### OpenAPI 3.0 Parsing

#### Structure Mapping

| OpenAPI Field | Configuration Field | Description |
|---------------|-------------------|-------------|
| `info.title` | `projectName` | Project name |
| `info.description` | `description` | Project description |
| `servers[0].url` | `baseControllerPath` | Base path |
| `paths` | `endpoints` | API endpoints |
| `components.schemas` | DTOs | Data models |

#### Endpoint Parsing

```python
def _parse_openapi_endpoint(self, path: str, method: str, operation: Dict):
    return {
        'name': operation.get('operationId', self._generate_name(method, path)),
        'httpMethod': method.upper(),
        'path': path,
        'description': operation.get('summary', ''),
        'parameters': self._parse_parameters(operation),
        'requestBody': self._parse_request_body(operation),
        'responses': self._parse_responses(operation)
    }
```

### Swagger 2.0 Parsing

#### Differences from OpenAPI 3.0

| Swagger 2.0 | OpenAPI 3.0 | Notes |
|-------------|-------------|-------|
| `basePath` | `servers[].url` | Base URL handling |
| `definitions` | `components.schemas` | Schema definitions |
| `produces/consumes` | `content` | Media types |
| Parameter `in` body | `requestBody` | Request body handling |

### Schema Resolution

```python
def _resolve_ref(self, ref: str, spec: Dict) -> Dict:
    """Resolve $ref references"""
    if not ref.startswith('#/'):
        raise ValueError("External references not supported")

    path = ref[2:].split('/')
    result = spec
    for part in path:
        result = result[part]

    return result
```

### Validation Extraction

```python
def _extract_validation(self, schema: Dict) -> Dict:
    """Extract validation rules from schema"""
    validation = {}

    if schema.get('minLength'):
        validation['size'] = {'min': schema['minLength']}
    if schema.get('maxLength'):
        validation.setdefault('size', {})['max'] = schema['maxLength']
    if schema.get('pattern'):
        validation['pattern'] = schema['pattern']
    if schema.get('format') == 'email':
        validation['email'] = True

    return validation
```

## PostmanParserService

### Purpose
Parses Postman Collection v2.1 format into internal configuration.

### Location
`services/postman_parser_service.py`

### Class Definition

```python
class PostmanParserService:
    """Service for parsing Postman collections"""

    SUPPORTED_VERSIONS = ['2.1.0', '2.1', '2.0.0', '2.0']

    def parse_collection(self, collection_data: str) -> Dict:
        """Parse Postman collection JSON"""
```

### Key Methods

#### parse_collection(collection_data: str) -> Dict

Parses Postman collection.

**Parameters:**
- `collection_data` (str): JSON string of Postman collection

**Returns:**
- `Dict`: Internal configuration format

### Collection Structure

```json
{
  "info": {
    "name": "Collection Name",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Request Name",
      "request": {
        "method": "GET",
        "url": "{{baseUrl}}/users"
      }
    }
  ],
  "variable": [
    {
      "key": "baseUrl",
      "value": "http://localhost:8080"
    }
  ]
}
```

### Features

#### Nested Folder Support

```python
def _parse_items(self, items: List, endpoints: List, path_prefix: str = ""):
    """Recursively parse collection items including folders"""
    for item in items:
        if 'item' in item:
            # This is a folder
            folder_path = f"{path_prefix}/{item['name']}"
            self._parse_items(item['item'], endpoints, folder_path)
        elif 'request' in item:
            # This is a request
            endpoint = self._parse_request(item, path_prefix)
            endpoints.append(endpoint)
```

#### Variable Resolution

```python
def _resolve_variables(self, text: str, variables: Dict) -> str:
    """Resolve {{variable}} references"""
    for key, value in variables.items():
        text = text.replace(f"{{{{key}}}}", value)
    return text
```

#### Authentication Detection

```python
def _has_auth(self, collection: Dict) -> bool:
    """Check if collection uses authentication"""
    # Check collection-level auth
    if 'auth' in collection:
        return True

    # Check request-level auth
    for item in self._flatten_items(collection.get('item', [])):
        if 'auth' in item.get('request', {}):
            return True

    return False
```

### Request Parsing

#### URL Parsing

```python
def _parse_url(self, url: Any) -> Dict:
    """Parse Postman URL object or string"""
    if isinstance(url, str):
        # Simple string URL
        return self._parse_string_url(url)
    elif isinstance(url, dict):
        # Postman URL object
        return {
            'path': self._build_path(url.get('path', [])),
            'query': url.get('query', []),
            'variables': url.get('variable', [])
        }
```

#### Body Parsing

```python
def _parse_request_body(self, body: Dict) -> Optional[Dict]:
    """Parse different body modes"""
    mode = body.get('mode')

    if mode == 'raw':
        return self._parse_raw_body(body.get('raw'))
    elif mode == 'formdata':
        return self._parse_form_data(body.get('formdata'))
    elif mode == 'urlencoded':
        return self._parse_urlencoded(body.get('urlencoded'))

    return None
```

## ErrorHandler

### Purpose
Centralized error handling with custom exceptions and formatted responses.

### Location
`services/error_handler.py`

### Exception Hierarchy

```python
APIGeneratorError (base)
├── ValidationError
├── ParsingError
├── GenerationError
├── InitializrError
└── FileSystemError
```

### Custom Exceptions

#### APIGeneratorError

Base exception class.

```python
class APIGeneratorError(Exception):
    def __init__(self, message: str, code: str = "UNKNOWN", details: Dict = None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)
```

#### ValidationError

Input validation failures.

```python
class ValidationError(APIGeneratorError):
    def __init__(self, message: str, field: str = None, details: Dict = None):
        code = "VALIDATION_ERROR"
        if details is None:
            details = {}
        if field:
            details['field'] = field
        super().__init__(message, code, details)
```

### Error Handler Class

#### handle_error(error: Exception, context: str = None) -> Dict

Formats error for API response.

**Parameters:**
- `error` (Exception): The exception to handle
- `context` (str): Context where error occurred

**Returns:**
- `Dict`: Formatted error response

**Example:**
```python
try:
    # Some operation
    pass
except Exception as e:
    error_response = ErrorHandler.handle_error(e, 'project_generation')
    return jsonify(error_response), 500
```

### Validation Methods

#### validate_required_fields(data, required_fields, context)

```python
ErrorHandler.validate_required_fields(
    data={'name': 'test'},
    required_fields=['name', 'email'],
    context='user_input'
)
# Raises ValidationError if 'email' is missing
```

#### validate_string_length(value, field_name, min_length, max_length)

```python
ErrorHandler.validate_string_length(
    value='ab',
    field_name='username',
    min_length=3,
    max_length=20
)
# Raises ValidationError if length constraints violated
```

#### validate_pattern(value, field_name, pattern, pattern_name)

```python
ErrorHandler.validate_pattern(
    value='invalid-package',
    field_name='packageName',
    pattern=r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$',
    pattern_name='Java package name'
)
```

### Decorator

#### with_error_handling(context: str = None)

Decorator for automatic error handling.

```python
@with_error_handling(context='user_creation')
def create_user(data):
    # Function implementation
    pass

# Automatically catches and formats errors
```

### Error Response Format

```json
{
  "success": false,
  "error": {
    "id": "20240101120000",
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "field": "email",
      "constraint": "format",
      "value": "invalid-email"
    },
    "timestamp": "2024-01-01T12:00:00Z"
  }
}
```

## Service Integration

### Service Dependencies

```
ValidationService (standalone)
    ↓
ErrorHandler (uses ValidationError)
    ↓
OpenAPIParserService ← Uses validation
PostmanParserService ← Uses validation
    ↓
CodeGeneratorService ← Uses parsed data
    ↓
InitializrService (downloads base)
    ↓
ProjectModifierService ← Combines all
```

### Integration Example

```python
# Complete workflow
def generate_project_workflow(specification):
    try:
        # 1. Validate input
        validator = ValidationService()
        validated = validator.validate_all(specification)

        # 2. Parse specification
        if is_openapi(specification):
            parser = OpenAPIParserService()
        else:
            parser = PostmanParserService()

        config = parser.parse_specification(specification)

        # 3. Download base project
        initializr = InitializrService()
        zip_content = initializr.download_project(config['projectConfiguration'])

        # 4. Generate code
        generator = CodeGeneratorService()
        files = generator.generate_code(
            config['projectConfiguration'],
            config['apiSpecification'],
            config['generationOptions']
        )

        # 5. Modify project
        modifier = ProjectModifierService()
        final_zip = modifier.modify_project(zip_content, files)

        return final_zip

    except APIGeneratorError as e:
        return ErrorHandler.handle_error(e, 'project_generation')
```

### Service Communication

Services communicate through:
1. **Direct method calls**: Synchronous communication
2. **Data contracts**: Well-defined input/output formats
3. **Exceptions**: Error propagation
4. **Events**: Progress updates (future enhancement)

## Best Practices

### Service Design

1. **Single Responsibility**: Each service has one clear purpose
2. **Stateless**: Services don't maintain state between calls
3. **Idempotent**: Same input produces same output
4. **Defensive Programming**: Validate inputs, handle errors

### Error Handling

```python
# Always use specific exceptions
raise ValidationError("Invalid email format", field='email')

# Not generic exceptions
raise Exception("Invalid email")  # Bad
```

### Testing

```python
# Mock external dependencies
@patch('services.initializr_service.requests.get')
def test_download_project(mock_get):
    mock_get.return_value.content = b'zip content'
    service = InitializrService()
    result = service.download_project({})
    assert result == b'zip content'
```

### Performance

1. **Caching**: Cache expensive operations (metadata)
2. **Session Reuse**: Reuse HTTP sessions
3. **Lazy Loading**: Load resources only when needed
4. **Batch Operations**: Process multiple items together

### Security

1. **Input Validation**: Always validate external input
2. **Sanitization**: Clean user input
3. **Error Messages**: Don't expose sensitive information
4. **File Operations**: Validate file paths and sizes

### Logging

```python
import logging

logger = logging.getLogger(__name__)

class MyService:
    def operation(self):
        logger.debug("Starting operation")
        try:
            # Operation
            logger.info("Operation successful")
        except Exception as e:
            logger.error(f"Operation failed: {e}")
            raise
```

### Configuration

```python
# Use environment variables
import os

class ConfigurableService:
    def __init__(self):
        self.timeout = int(os.getenv('SERVICE_TIMEOUT', '30'))
        self.retry_count = int(os.getenv('RETRY_COUNT', '3'))
```

---

**Last Updated:** January 2024 | **Version:** 2.0.0