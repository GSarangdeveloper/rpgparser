"""
Postman Collection Parser Service
Parses Postman Collection v2.1 format to Spring Boot API configuration
"""

import json
import re
from typing import Dict, List, Any, Optional
from datetime import datetime

class PostmanParserService:
    """Service for parsing Postman collections to API configuration"""

    def __init__(self):
        self.supported_versions = ['2.1.0', '2.1', '2.0.0', '2.0']

    def parse_collection(self, collection_data: str) -> Dict:
        """
        Parse Postman collection JSON to API configuration

        Args:
            collection_data: Raw Postman collection JSON string

        Returns:
            Parsed configuration dictionary
        """
        try:
            collection = json.loads(collection_data)

            # Validate collection format
            if 'info' not in collection or 'item' not in collection:
                raise ValueError("Invalid Postman collection format")

            # Check version compatibility
            version = collection.get('info', {}).get('schema', '')
            if not self._is_version_supported(version):
                raise ValueError(f"Unsupported Postman collection version: {version}")

            # Parse collection
            config = self._parse_postman_collection(collection)

            return config

        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {str(e)}")
        except Exception as e:
            raise ValueError(f"Error parsing Postman collection: {str(e)}")

    def _is_version_supported(self, version: str) -> bool:
        """Check if Postman collection version is supported"""
        for supported in self.supported_versions:
            if version.startswith(f"https://schema.getpostman.com/json/collection/v{supported}") or \
               version.startswith(f"http://schema.getpostman.com/json/collection/v{supported}") or \
               version == supported:
                return True
        return False

    def _parse_postman_collection(self, collection: Dict) -> Dict:
        """Parse Postman collection to configuration"""
        info = collection.get('info', {})

        # Extract project configuration from collection info
        project_config = {
            'projectName': self._sanitize_project_name(info.get('name', 'PostmanAPI')),
            'description': info.get('description', 'API generated from Postman collection'),
            'groupId': 'com.example',
            'artifactId': self._generate_artifact_id(info.get('name', 'postman-api')),
            'packageName': 'com.example.api',
            'springBootVersion': '3.2.0',
            'javaVersion': '17',
            'buildTool': 'gradle',
            'packaging': 'jar'
        }

        # Parse endpoints from collection items
        endpoints = []
        endpoint_id = 1

        # Process collection items (can be nested folders)
        self._parse_items(collection.get('item', []), endpoints, endpoint_id)

        # Extract base URL from collection variables or first request
        base_path = self._extract_base_path(collection)

        # Build API specification
        api_spec = {
            'baseControllerPath': base_path,
            'controllerClassName': self._generate_controller_name(info.get('name', 'API')),
            'description': f"Controller for {info.get('name', 'API')}",
            'endpoints': endpoints
        }

        return {
            'projectConfiguration': project_config,
            'dependencyConfiguration': {
                'database': 'h2',
                'security': self._has_auth(collection),
                'documentation': True,
                'caching': False,
                'messaging': False
            },
            'apiSpecification': api_spec,
            'generationOptions': {
                'includeServiceLayer': True,
                'includeExceptionHandling': True,
                'includeValidation': True,
                'includeLogging': True,
                'generateTests': True,
                'generateCustomExceptions': True,
                'generateRepository': True,
                'enhanceWithLLM': False,
                'generateSwaggerDocs': True
            }
        }

    def _parse_items(self, items: List, endpoints: List, endpoint_id: int, path_prefix: str = "") -> int:
        """Recursively parse Postman collection items"""
        for item in items:
            if 'item' in item:
                # This is a folder, recurse into it
                folder_name = item.get('name', '')
                new_prefix = f"{path_prefix}/{self._to_kebab_case(folder_name)}" if path_prefix else f"/{self._to_kebab_case(folder_name)}"
                endpoint_id = self._parse_items(item['item'], endpoints, endpoint_id, new_prefix)
            elif 'request' in item:
                # This is a request, parse it
                endpoint = self._parse_request(item, endpoint_id, path_prefix)
                if endpoint:
                    endpoints.append(endpoint)
                    endpoint_id += 1
        return endpoint_id

    def _parse_request(self, item: Dict, endpoint_id: int, path_prefix: str) -> Optional[Dict]:
        """Parse a single Postman request to endpoint configuration"""
        request = item.get('request', {})

        if not request:
            return None

        # Extract method and URL
        method = request.get('method', 'GET').upper()
        url_info = self._parse_url(request.get('url', {}))

        # Build endpoint path
        path = path_prefix + url_info['path'] if path_prefix else url_info['path']
        if not path:
            path = f"/{self._to_kebab_case(item.get('name', 'endpoint'))}"

        # Parse request parameters
        parameters = self._parse_parameters(url_info, request)

        # Parse request body
        request_body = self._parse_request_body(request.get('body', {}))

        # Generate endpoint configuration
        endpoint = {
            'id': str(endpoint_id),
            'name': self._to_camel_case(item.get('name', f'endpoint{endpoint_id}')),
            'httpMethod': method,
            'path': path,
            'description': item.get('name', ''),
            'operationId': self._to_camel_case(item.get('name', f'operation{endpoint_id}'))
        }

        # Add parameters if present
        if parameters:
            endpoint['requestParameters'] = parameters

        # Add request body if present
        if request_body:
            endpoint['requestBody'] = request_body

        # Add default response configuration
        endpoint['response'] = self._generate_default_response(method, item.get('name', ''))

        return endpoint

    def _parse_url(self, url: Any) -> Dict:
        """Parse Postman URL object or string"""
        if isinstance(url, str):
            # Simple URL string
            parts = url.split('?')
            path = parts[0]
            query = parts[1] if len(parts) > 1 else ''

            # Extract path from full URL
            if path.startswith('http'):
                path = '/' + '/'.join(path.split('/')[3:])

            return {
                'path': path,
                'query': query,
                'variables': []
            }
        elif isinstance(url, dict):
            # Postman URL object
            path = url.get('path', [])
            if isinstance(path, list):
                # Build path from segments
                path_str = '/' + '/'.join(path)
                # Replace :variable with {variable}
                path_str = re.sub(r':(\w+)', r'{\1}', path_str)
            else:
                path_str = path

            return {
                'path': path_str,
                'query': url.get('query', []),
                'variables': url.get('variable', [])
            }
        else:
            return {'path': '', 'query': '', 'variables': []}

    def _parse_parameters(self, url_info: Dict, request: Dict) -> List[Dict]:
        """Parse request parameters from URL and headers"""
        parameters = []

        # Parse path variables
        path_vars = re.findall(r'\{(\w+)\}', url_info['path'])
        for var in path_vars:
            parameters.append({
                'name': var,
                'type': 'String',
                'parameterLocation': 'PATH',
                'required': True,
                'description': f'Path parameter {var}'
            })

        # Parse query parameters
        if isinstance(url_info['query'], list):
            for param in url_info['query']:
                if isinstance(param, dict) and not param.get('disabled', False):
                    parameters.append({
                        'name': param.get('key', ''),
                        'type': 'String',
                        'parameterLocation': 'QUERY',
                        'required': False,
                        'description': param.get('description', ''),
                        'defaultValue': param.get('value', '')
                    })

        # Parse header parameters (excluding standard headers)
        headers = request.get('header', [])
        standard_headers = ['content-type', 'accept', 'authorization', 'user-agent']

        for header in headers:
            if isinstance(header, dict) and not header.get('disabled', False):
                header_name = header.get('key', '').lower()
                if header_name not in standard_headers:
                    parameters.append({
                        'name': header.get('key', ''),
                        'type': 'String',
                        'parameterLocation': 'HEADER',
                        'required': False,
                        'description': header.get('description', '')
                    })

        return parameters

    def _parse_request_body(self, body: Dict) -> Optional[Dict]:
        """Parse Postman request body configuration"""
        if not body or body.get('mode') not in ['raw', 'formdata', 'urlencoded']:
            return None

        mode = body.get('mode')
        request_body = {
            'required': True,
            'type': 'Request',
            'fields': []
        }

        if mode == 'raw':
            # Try to parse JSON body
            raw_body = body.get('raw', '')
            if raw_body:
                try:
                    json_body = json.loads(raw_body)
                    request_body['fields'] = self._extract_fields_from_json(json_body)
                except:
                    # If not valid JSON, create a single string field
                    request_body['fields'] = [{
                        'name': 'body',
                        'type': 'String',
                        'required': True,
                        'description': 'Request body'
                    }]

        elif mode == 'formdata' or mode == 'urlencoded':
            # Parse form data fields
            data = body.get(mode, [])
            for field in data:
                if isinstance(field, dict) and not field.get('disabled', False):
                    request_body['fields'].append({
                        'name': field.get('key', ''),
                        'type': 'String',
                        'required': False,
                        'description': field.get('description', ''),
                        'validation': {}
                    })

        # Generate type name from endpoint name
        request_body['type'] = 'RequestDto'

        return request_body if request_body['fields'] else None

    def _extract_fields_from_json(self, json_obj: Any, prefix: str = "") -> List[Dict]:
        """Extract field definitions from JSON sample"""
        fields = []

        if isinstance(json_obj, dict):
            for key, value in json_obj.items():
                field_name = f"{prefix}.{key}" if prefix else key
                field_type = self._infer_type(value)

                if field_type == 'Object':
                    # Nested object, recurse
                    nested_fields = self._extract_fields_from_json(value, field_name)
                    fields.extend(nested_fields)
                else:
                    fields.append({
                        'name': key,
                        'type': field_type,
                        'required': True,
                        'description': f'Field {key}'
                    })

        return fields

    def _infer_type(self, value: Any) -> str:
        """Infer Java type from JSON value"""
        if isinstance(value, bool):
            return 'Boolean'
        elif isinstance(value, int):
            return 'Integer'
        elif isinstance(value, float):
            return 'Double'
        elif isinstance(value, str):
            # Check for date/time patterns
            if re.match(r'\d{4}-\d{2}-\d{2}$', value):
                return 'LocalDate'
            elif re.match(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', value):
                return 'LocalDateTime'
            else:
                return 'String'
        elif isinstance(value, list):
            return 'List'
        elif isinstance(value, dict):
            return 'Object'
        else:
            return 'String'

    def _generate_default_response(self, method: str, endpoint_name: str) -> Dict:
        """Generate default response configuration based on HTTP method"""
        if method == 'GET':
            response_type = 'LIST' if 'all' in endpoint_name.lower() or 'list' in endpoint_name.lower() else 'SINGLE_OBJECT'
        elif method == 'POST':
            response_type = 'SINGLE_OBJECT'
        elif method == 'PUT' or method == 'PATCH':
            response_type = 'SINGLE_OBJECT'
        elif method == 'DELETE':
            response_type = 'VOID'
        else:
            response_type = 'SINGLE_OBJECT'

        http_status = '201' if method == 'POST' else '204' if method == 'DELETE' else '200'

        return {
            'type': response_type,
            'httpStatus': http_status,
            'dataType': 'ResponseDto',
            'wrapInResponseEntity': True
        }

    def _extract_base_path(self, collection: Dict) -> str:
        """Extract base path from collection variables or first request"""
        # Check for collection variables
        variables = collection.get('variable', [])
        for var in variables:
            if var.get('key') in ['baseUrl', 'base_url', 'apiUrl', 'api_url']:
                url = var.get('value', '')
                if url:
                    # Extract path from URL
                    if url.startswith('http'):
                        parts = url.split('/')
                        if len(parts) > 3:
                            return '/' + '/'.join(parts[3:])

        # Try to extract from first request
        items = collection.get('item', [])
        for item in items:
            if 'request' in item:
                url = item['request'].get('url', {})
                if isinstance(url, dict):
                    path = url.get('path', [])
                    if isinstance(path, list) and path:
                        # Get common prefix from path
                        if path[0] in ['api', 'v1', 'v2']:
                            return '/' + path[0]

        return '/api'

    def _has_auth(self, collection: Dict) -> bool:
        """Check if collection has authentication configured"""
        # Check collection-level auth
        if 'auth' in collection:
            return True

        # Check if any request has auth
        items = collection.get('item', [])
        for item in items:
            if 'auth' in item.get('request', {}):
                return True
            # Check nested items
            if 'item' in item:
                if self._has_auth({'item': item['item']}):
                    return True

        return False

    def _sanitize_project_name(self, name: str) -> str:
        """Sanitize project name for Spring Boot"""
        # Remove special characters and spaces
        name = re.sub(r'[^a-zA-Z0-9\s-]', '', name)
        # Replace spaces with hyphens
        name = name.replace(' ', '-')
        # Remove consecutive hyphens
        name = re.sub(r'-+', '-', name)
        return name.strip('-') or 'postman-api'

    def _generate_artifact_id(self, name: str) -> str:
        """Generate artifact ID from project name"""
        # Convert to lowercase and replace spaces
        artifact_id = name.lower().replace(' ', '-')
        # Remove special characters
        artifact_id = re.sub(r'[^a-z0-9-]', '', artifact_id)
        # Remove consecutive hyphens
        artifact_id = re.sub(r'-+', '-', artifact_id)
        return artifact_id.strip('-') or 'api'

    def _generate_controller_name(self, name: str) -> str:
        """Generate controller class name"""
        # Remove special characters
        name = re.sub(r'[^a-zA-Z0-9\s]', '', name)
        # Convert to PascalCase
        words = name.split()
        controller_name = ''.join(word.capitalize() for word in words)
        return controller_name or 'Api'

    def _to_camel_case(self, text: str) -> str:
        """Convert text to camelCase"""
        # Remove special characters
        text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
        words = text.split()
        if not words:
            return 'method'
        # First word lowercase, rest capitalized
        return words[0].lower() + ''.join(word.capitalize() for word in words[1:])

    def _to_kebab_case(self, text: str) -> str:
        """Convert text to kebab-case"""
        # Remove special characters
        text = re.sub(r'[^a-zA-Z0-9\s-]', '', text)
        # Replace spaces with hyphens
        text = text.replace(' ', '-')
        # Convert to lowercase
        text = text.lower()
        # Remove consecutive hyphens
        text = re.sub(r'-+', '-', text)
        return text.strip('-') or 'endpoint'