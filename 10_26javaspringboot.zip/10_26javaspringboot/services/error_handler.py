"""
Comprehensive Error Handler for Spring Boot API Generator
Handles edge cases and provides detailed error messages
"""

import logging
import traceback
from typing import Dict, Any, Optional
from functools import wraps
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class APIGeneratorError(Exception):
    """Base exception class for API Generator"""
    def __init__(self, message: str, code: str = "UNKNOWN", details: Dict = None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)


class ValidationError(APIGeneratorError):
    """Raised when input validation fails"""
    def __init__(self, message: str, field: str = None, details: Dict = None):
        code = "VALIDATION_ERROR"
        if details is None:
            details = {}
        if field:
            details['field'] = field
        super().__init__(message, code, details)


class ParsingError(APIGeneratorError):
    """Raised when file parsing fails"""
    def __init__(self, message: str, file_type: str = None, details: Dict = None):
        code = "PARSING_ERROR"
        if details is None:
            details = {}
        if file_type:
            details['file_type'] = file_type
        super().__init__(message, code, details)


class GenerationError(APIGeneratorError):
    """Raised when code generation fails"""
    def __init__(self, message: str, component: str = None, details: Dict = None):
        code = "GENERATION_ERROR"
        if details is None:
            details = {}
        if component:
            details['component'] = component
        super().__init__(message, code, details)


class InitializrError(APIGeneratorError):
    """Raised when Spring Initializr interaction fails"""
    def __init__(self, message: str, status_code: int = None, details: Dict = None):
        code = "INITIALIZR_ERROR"
        if details is None:
            details = {}
        if status_code:
            details['status_code'] = status_code
        super().__init__(message, code, details)


class ErrorHandler:
    """Central error handler for the application"""

    @staticmethod
    def handle_error(error: Exception, context: str = None) -> Dict[str, Any]:
        """
        Handle an error and return formatted error response

        Args:
            error: The exception that occurred
            context: Additional context about where the error occurred

        Returns:
            Dictionary with error details
        """
        error_id = datetime.utcnow().strftime("%Y%m%d%H%M%S")

        # Log the error
        logger.error(f"Error {error_id} in {context or 'unknown context'}: {str(error)}")
        logger.debug(traceback.format_exc())

        # Build error response
        if isinstance(error, APIGeneratorError):
            return {
                'success': False,
                'error': {
                    'id': error_id,
                    'code': error.code,
                    'message': error.message,
                    'details': error.details,
                    'timestamp': datetime.utcnow().isoformat()
                }
            }
        else:
            # Generic error handling
            return {
                'success': False,
                'error': {
                    'id': error_id,
                    'code': 'INTERNAL_ERROR',
                    'message': 'An unexpected error occurred',
                    'details': {
                        'error_type': type(error).__name__,
                        'error_message': str(error)
                    },
                    'timestamp': datetime.utcnow().isoformat()
                }
            }

    @staticmethod
    def validate_required_fields(data: Dict, required_fields: list, context: str = "input"):
        """
        Validate that all required fields are present and non-empty

        Args:
            data: Dictionary to validate
            required_fields: List of required field names
            context: Context for error messages

        Raises:
            ValidationError if validation fails
        """
        missing_fields = []
        empty_fields = []

        for field in required_fields:
            if field not in data:
                missing_fields.append(field)
            elif data[field] is None or (isinstance(data[field], str) and not data[field].strip()):
                empty_fields.append(field)

        if missing_fields:
            raise ValidationError(
                f"Missing required fields in {context}",
                details={'missing_fields': missing_fields}
            )

        if empty_fields:
            raise ValidationError(
                f"Empty required fields in {context}",
                details={'empty_fields': empty_fields}
            )

    @staticmethod
    def validate_string_length(value: str, field_name: str, min_length: int = None, max_length: int = None):
        """Validate string length constraints"""
        if min_length and len(value) < min_length:
            raise ValidationError(
                f"{field_name} must be at least {min_length} characters",
                field=field_name,
                details={'actual_length': len(value), 'min_length': min_length}
            )

        if max_length and len(value) > max_length:
            raise ValidationError(
                f"{field_name} exceeds maximum length of {max_length} characters",
                field=field_name,
                details={'actual_length': len(value), 'max_length': max_length}
            )

    @staticmethod
    def validate_pattern(value: str, field_name: str, pattern: str, pattern_name: str = None):
        """Validate string against a regex pattern"""
        import re
        if not re.match(pattern, value):
            raise ValidationError(
                f"{field_name} does not match required pattern" + (f" ({pattern_name})" if pattern_name else ""),
                field=field_name,
                details={'value': value, 'pattern': pattern}
            )

    @staticmethod
    def validate_enum(value: Any, field_name: str, allowed_values: list):
        """Validate that value is in allowed list"""
        if value not in allowed_values:
            raise ValidationError(
                f"{field_name} must be one of {allowed_values}",
                field=field_name,
                details={'value': value, 'allowed_values': allowed_values}
            )

    @staticmethod
    def validate_file_size(file_size: int, max_size_mb: int = 10):
        """Validate file size"""
        max_size_bytes = max_size_mb * 1024 * 1024
        if file_size > max_size_bytes:
            raise ValidationError(
                f"File size exceeds maximum of {max_size_mb}MB",
                details={
                    'file_size_mb': file_size / (1024 * 1024),
                    'max_size_mb': max_size_mb
                }
            )

    @staticmethod
    def safe_parse_json(content: str, context: str = "JSON"):
        """Safely parse JSON with error handling"""
        import json
        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            raise ParsingError(
                f"Invalid {context} format",
                file_type='json',
                details={
                    'line': e.lineno,
                    'column': e.colno,
                    'message': e.msg
                }
            )

    @staticmethod
    def safe_parse_yaml(content: str, context: str = "YAML"):
        """Safely parse YAML with error handling"""
        import yaml
        try:
            return yaml.safe_load(content)
        except yaml.YAMLError as e:
            error_details = {}
            if hasattr(e, 'problem_mark'):
                mark = e.problem_mark
                error_details['line'] = mark.line + 1
                error_details['column'] = mark.column + 1

            raise ParsingError(
                f"Invalid {context} format",
                file_type='yaml',
                details=error_details
            )


def with_error_handling(context: str = None):
    """
    Decorator to add error handling to functions

    Args:
        context: Context description for error messages
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                error_context = context or f"{func.__module__}.{func.__name__}"
                error_response = ErrorHandler.handle_error(e, error_context)

                # Re-raise as APIGeneratorError with context
                if not isinstance(e, APIGeneratorError):
                    raise GenerationError(
                        f"Error in {error_context}: {str(e)}",
                        component=error_context
                    )
                raise

        return wrapper
    return decorator


def validate_project_configuration(config: Dict):
    """Validate project configuration with comprehensive checks"""
    handler = ErrorHandler()

    # Required fields
    handler.validate_required_fields(
        config,
        ['projectName', 'groupId', 'artifactId', 'packageName'],
        'project configuration'
    )

    # Validate project name
    handler.validate_string_length(
        config['projectName'],
        'Project name',
        min_length=1,
        max_length=100
    )

    # Validate group ID format
    handler.validate_pattern(
        config['groupId'],
        'Group ID',
        r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$',
        'reverse domain name'
    )

    # Validate artifact ID format
    handler.validate_pattern(
        config['artifactId'],
        'Artifact ID',
        r'^[a-z][a-z0-9-]*$',
        'lowercase with hyphens'
    )

    # Validate package name format
    handler.validate_pattern(
        config['packageName'],
        'Package name',
        r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$',
        'Java package name'
    )

    # Validate Java version
    if 'javaVersion' in config:
        handler.validate_enum(
            config['javaVersion'],
            'Java version',
            ['8', '11', '17', '21']
        )

    # Validate build tool
    if 'buildTool' in config:
        handler.validate_enum(
            config['buildTool'],
            'Build tool',
            ['gradle', 'gradle-kotlin']
        )

    # Validate packaging
    if 'packaging' in config:
        handler.validate_enum(
            config['packaging'],
            'Packaging',
            ['jar', 'war']
        )


def validate_api_endpoint(endpoint: Dict, index: int):
    """Validate individual API endpoint configuration"""
    handler = ErrorHandler()
    context = f"endpoint {index + 1}"

    # Required fields
    handler.validate_required_fields(
        endpoint,
        ['name', 'httpMethod', 'path'],
        context
    )

    # Validate HTTP method
    handler.validate_enum(
        endpoint['httpMethod'],
        'HTTP method',
        ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']
    )

    # Validate path format
    path = endpoint['path']
    if not path.startswith('/'):
        raise ValidationError(
            f"Path in {context} must start with '/'",
            field='path',
            details={'path': path}
        )

    # Validate parameter locations
    if 'requestParameters' in endpoint:
        for param_idx, param in enumerate(endpoint['requestParameters']):
            param_context = f"parameter {param_idx + 1} in {context}"

            handler.validate_required_fields(
                param,
                ['name', 'type', 'parameterLocation'],
                param_context
            )

            handler.validate_enum(
                param['parameterLocation'],
                'Parameter location',
                ['PATH', 'QUERY', 'HEADER']
            )

            # Validate path parameters are in the path
            if param['parameterLocation'] == 'PATH':
                if f"{{{param['name']}}}" not in path:
                    raise ValidationError(
                        f"Path parameter '{param['name']}' not found in path '{path}'",
                        field='requestParameters',
                        details={'parameter': param['name'], 'path': path}
                    )

    # Validate request body
    if 'requestBody' in endpoint:
        body = endpoint['requestBody']
        if 'fields' in body:
            for field_idx, field in enumerate(body['fields']):
                field_context = f"field {field_idx + 1} in {context} request body"
                handler.validate_required_fields(
                    field,
                    ['name', 'type'],
                    field_context
                )

    # Validate response
    if 'response' in endpoint:
        response = endpoint['response']
        handler.validate_required_fields(
            response,
            ['type', 'httpStatus'],
            f"{context} response"
        )

        handler.validate_enum(
            response['type'],
            'Response type',
            ['SINGLE_OBJECT', 'LIST', 'VOID', 'CUSTOM']
        )


def handle_file_upload_error(error: Exception, filename: str = None):
    """Handle file upload specific errors"""
    if isinstance(error, (IOError, OSError)):
        raise APIGeneratorError(
            "File system error during upload",
            code="FILE_SYSTEM_ERROR",
            details={'filename': filename, 'error': str(error)}
        )

    if "timeout" in str(error).lower():
        raise APIGeneratorError(
            "File upload timed out",
            code="UPLOAD_TIMEOUT",
            details={'filename': filename}
        )

    if "size" in str(error).lower():
        raise APIGeneratorError(
            "File size limit exceeded",
            code="FILE_TOO_LARGE",
            details={'filename': filename}
        )

    # Re-raise if not handled
    raise