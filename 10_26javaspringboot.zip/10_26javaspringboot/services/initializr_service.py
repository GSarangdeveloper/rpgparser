import requests
import os
import tempfile
import time
import json
from typing import Dict, Optional
from datetime import datetime, timedelta


class InitializrService:
    """Service to interact with Spring Initializr API"""

    BASE_URL = "https://start.spring.io"
    TIMEOUT = 30
    RETRY_COUNT = 3
    RETRY_DELAY_BASE = 1  # Base delay in seconds for exponential backoff

    def __init__(self):
        self.session = requests.Session()
        self._metadata_cache = None
        self._metadata_cache_time = None
        self._cache_duration = timedelta(hours=1)  # Cache metadata for 1 hour

    def generate_base_project(
        self,
        project_config: Dict,
        dependency_config: Dict
    ) -> Optional[str]:
        """
        Generate base Spring Boot project using Spring Initializr with retry logic
        Returns path to downloaded ZIP file
        """
        # Build parameters
        params = self._build_initializr_params(project_config, dependency_config)

        # Retry logic with exponential backoff
        for attempt in range(self.RETRY_COUNT):
            try:
                # Call Spring Initializr
                response = self.session.get(
                    f"{self.BASE_URL}/starter.zip",
                    params=params,
                    timeout=self.TIMEOUT
                )

                if response.status_code == 200:
                    # Validate ZIP file
                    if len(response.content) == 0:
                        raise ValueError("Received empty ZIP file from Spring Initializr")

                    # Save ZIP file
                    temp_dir = tempfile.gettempdir()
                    zip_path = os.path.join(temp_dir, f"base_project_{project_config.get('artifactId')}.zip")

                    with open(zip_path, 'wb') as f:
                        f.write(response.content)

                    return zip_path

                elif response.status_code == 503:
                    # Service unavailable, retry
                    if attempt < self.RETRY_COUNT - 1:
                        delay = self.RETRY_DELAY_BASE * (2 ** attempt)  # Exponential backoff
                        print(f"Spring Initializr unavailable. Retrying in {delay} seconds...")
                        time.sleep(delay)
                        continue
                    else:
                        raise Exception(f"Spring Initializr API unavailable after {self.RETRY_COUNT} attempts")

                else:
                    # Other error codes
                    error_msg = f"Spring Initializr API error: {response.status_code}"
                    if response.text:
                        error_msg += f" - {response.text}"
                    raise Exception(error_msg)

            except requests.exceptions.Timeout:
                if attempt < self.RETRY_COUNT - 1:
                    delay = self.RETRY_DELAY_BASE * (2 ** attempt)
                    print(f"Request timeout. Retrying in {delay} seconds...")
                    time.sleep(delay)
                    continue
                else:
                    raise Exception(f"Request timeout after {self.RETRY_COUNT} attempts")

            except requests.exceptions.ConnectionError as e:
                if attempt < self.RETRY_COUNT - 1:
                    delay = self.RETRY_DELAY_BASE * (2 ** attempt)
                    print(f"Connection error. Retrying in {delay} seconds...")
                    time.sleep(delay)
                    continue
                else:
                    raise Exception(f"Connection error after {self.RETRY_COUNT} attempts: {str(e)}")

            except Exception as e:
                # For other exceptions, don't retry
                print(f"Error calling Spring Initializr: {str(e)}")
                return None

        return None

    def _build_initializr_params(
        self,
        project_config: Dict,
        dependency_config: Dict
    ) -> Dict:
        """Build parameters for Spring Initializr API"""

        params = {
            'type': 'gradle-project',
            'language': 'java',
            'bootVersion': project_config.get('springBootVersion', '3.2.0'),
            'baseDir': project_config.get('artifactId', 'demo'),
            'groupId': project_config.get('groupId', 'com.example'),
            'artifactId': project_config.get('artifactId', 'demo'),
            'name': project_config.get('projectName', 'demo'),
            'description': project_config.get('description', 'Spring Boot API'),
            'packageName': project_config.get('packageName', 'com.example.demo'),
            'packaging': project_config.get('packaging', 'jar'),
            'javaVersion': project_config.get('javaVersion', '17')
        }

        # Build dependencies list
        dependencies = ['web', 'lombok', 'validation', 'devtools']

        # Add database dependency
        db = dependency_config.get('database')
        if db == 'mysql':
            dependencies.append('mysql')
        elif db == 'postgresql':
            dependencies.append('postgresql')
        elif db == 'h2':
            dependencies.append('h2')
        elif db == 'mongodb':
            dependencies.append('data-mongodb')

        # Add optional dependencies
        if dependency_config.get('security'):
            dependencies.append('security')
        if dependency_config.get('documentation'):
            dependencies.append('springdoc-openapi-starter-webmvc-ui')
        if dependency_config.get('caching'):
            dependencies.append('cache')

        params['dependencies'] = ','.join(dependencies)

        return params

    def get_metadata(self) -> Optional[Dict]:
        """Get available Spring Boot versions and dependencies with caching"""
        # Check cache first
        if self._metadata_cache and self._metadata_cache_time:
            if datetime.now() - self._metadata_cache_time < self._cache_duration:
                return self._metadata_cache

        # Fetch new metadata with retry logic
        for attempt in range(self.RETRY_COUNT):
            try:
                response = self.session.get(
                    f"{self.BASE_URL}",
                    headers={'Accept': 'application/json'},
                    timeout=self.TIMEOUT
                )

                if response.status_code == 200:
                    metadata = response.json()
                    # Cache the metadata
                    self._metadata_cache = metadata
                    self._metadata_cache_time = datetime.now()
                    return metadata

                elif response.status_code == 503 and attempt < self.RETRY_COUNT - 1:
                    delay = self.RETRY_DELAY_BASE * (2 ** attempt)
                    time.sleep(delay)
                    continue

                return None

            except requests.exceptions.Timeout:
                if attempt < self.RETRY_COUNT - 1:
                    delay = self.RETRY_DELAY_BASE * (2 ** attempt)
                    time.sleep(delay)
                    continue
                return None

            except Exception as e:
                print(f"Error fetching metadata: {str(e)}")
                return None

        return None

    def validate_configuration(self, project_config: Dict, dependency_config: Dict) -> Dict:
        """Validate configuration before generation"""
        errors = []
        warnings = []

        # Validate project name
        if not project_config.get('projectName'):
            errors.append("Project name is required")
        elif len(project_config.get('projectName', '')) < 3:
            errors.append("Project name must be at least 3 characters")
        elif len(project_config.get('projectName', '')) > 50:
            errors.append("Project name must not exceed 50 characters")

        # Validate package name
        package_name = project_config.get('packageName')
        if not package_name:
            errors.append("Package name is required")
        elif not self._is_valid_java_package(package_name):
            errors.append("Invalid Java package name format")

        # Validate artifact ID
        artifact_id = project_config.get('artifactId')
        if not artifact_id:
            errors.append("Artifact ID is required")
        elif not self._is_valid_artifact_id(artifact_id):
            errors.append("Artifact ID must be lowercase with hyphens only")

        # Validate group ID
        group_id = project_config.get('groupId')
        if not group_id:
            errors.append("Group ID is required")
        elif not self._is_valid_java_package(group_id):
            errors.append("Invalid Group ID format (use Java package format)")

        # Validate Java version compatibility with Spring Boot version
        java_version = project_config.get('javaVersion', '17')
        boot_version = project_config.get('springBootVersion', '3.2.0')

        if boot_version.startswith('3.') and java_version not in ['17', '21']:
            errors.append(f"Spring Boot {boot_version} requires Java 17 or higher")
        elif boot_version.startswith('2.7') and java_version == '21':
            warnings.append(f"Java {java_version} might have compatibility issues with Spring Boot {boot_version}")

        # Validate build tool is Gradle
        if project_config.get('buildTool') and project_config.get('buildTool') != 'gradle':
            errors.append("Only Gradle build tool is supported")

        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }

    def _is_valid_java_package(self, package_name: str) -> bool:
        """Check if string is valid Java package name"""
        import re
        pattern = r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$'
        return bool(re.match(pattern, package_name))

    def _is_valid_artifact_id(self, artifact_id: str) -> bool:
        """Check if string is valid artifact ID"""
        import re
        pattern = r'^[a-z][a-z0-9-]*$'
        return bool(re.match(pattern, artifact_id))
