"""
OpenAPI/Swagger Specification Parser Service
Parses OpenAPI 3.0 and Swagger 2.0 specifications to extract API information
"""

import yaml
import json
from typing import Dict, List, Optional, Any
import re


class OpenAPIParserService:
    """Service to parse OpenAPI/Swagger specifications"""

    def __init__(self):
        self.type_mapping = {
            # OpenAPI types to Java types
            'string': 'String',
            'integer': 'Integer',
            'int32': 'Integer',
            'int64': 'Long',
            'number': 'Double',
            'float': 'Float',
            'double': 'Double',
            'boolean': 'Boolean',
            'array': 'List',
            'object': 'Object',
            'date': 'LocalDate',
            'date-time': 'LocalDateTime',
            'password': 'String',
            'byte': 'byte[]',
            'binary': 'byte[]',
            'email': 'String',
            'uuid': 'String',
            'uri': 'String',
            'hostname': 'String',
            'ipv4': 'String',
            'ipv6': 'String'
        }

    def parse_file(self, file_path: str, file_type: str = None) -> Dict:
        """
        Parse OpenAPI specification file

        Args:
            file_path: Path to the specification file
            file_type: File type (yaml/json), auto-detected if not provided

        Returns:
            Parsed specification in internal format
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Auto-detect file type if not provided
            if not file_type:
                if file_path.endswith(('.yaml', '.yml')):
                    file_type = 'yaml'
                elif file_path.endswith('.json'):
                    file_type = 'json'

            if file_type == 'yaml':
                spec = yaml.safe_load(content)
            else:
                spec = json.loads(content)

            return self.parse_specification(spec)

        except Exception as e:
            raise Exception(f"Failed to parse file: {str(e)}")

    def parse_content(self, content: str, format: str) -> Dict:
        """
        Parse OpenAPI specification from string content

        Args:
            content: Specification content as string
            format: Format of the content (yaml/json)

        Returns:
            Parsed specification in internal format
        """
        try:
            if format in ['yaml', 'openapi-yaml']:
                spec = yaml.safe_load(content)
            else:
                spec = json.loads(content)

            return self.parse_specification(spec)

        except Exception as e:
            raise Exception(f"Failed to parse content: {str(e)}")

    def parse_specification(self, spec: Dict) -> Dict:
        """
        Parse OpenAPI/Swagger specification to internal format

        Args:
            spec: OpenAPI specification as dictionary

        Returns:
            Parsed specification in internal format
        """
        # Detect OpenAPI version
        if 'openapi' in spec:
            # OpenAPI 3.0+
            return self._parse_openapi_3(spec)
        elif 'swagger' in spec:
            # Swagger 2.0
            return self._parse_swagger_2(spec)
        else:
            raise ValueError("Unsupported specification format")

    def _parse_openapi_3(self, spec: Dict) -> Dict:
        """Parse OpenAPI 3.0 specification"""
        result = {
            'title': spec.get('info', {}).get('title', 'API'),
            'description': spec.get('info', {}).get('description', ''),
            'version': spec.get('info', {}).get('version', '1.0.0'),
            'basePath': self._extract_base_path_openapi3(spec),
            'endpoints': []
        }

        # Parse paths
        paths = spec.get('paths', {})
        for path, path_item in paths.items():
            for method, operation in path_item.items():
                if method.lower() in ['get', 'post', 'put', 'delete', 'patch']:
                    endpoint = self._parse_operation_openapi3(
                        path, method.upper(), operation, spec
                    )
                    if endpoint:
                        result['endpoints'].append(endpoint)

        return result

    def _parse_swagger_2(self, spec: Dict) -> Dict:
        """Parse Swagger 2.0 specification"""
        result = {
            'title': spec.get('info', {}).get('title', 'API'),
            'description': spec.get('info', {}).get('description', ''),
            'version': spec.get('info', {}).get('version', '1.0.0'),
            'basePath': spec.get('basePath', '/'),
            'endpoints': []
        }

        # Parse paths
        paths = spec.get('paths', {})
        for path, path_item in paths.items():
            for method, operation in path_item.items():
                if method.lower() in ['get', 'post', 'put', 'delete', 'patch']:
                    endpoint = self._parse_operation_swagger2(
                        path, method.upper(), operation, spec
                    )
                    if endpoint:
                        result['endpoints'].append(endpoint)

        return result

    def _extract_base_path_openapi3(self, spec: Dict) -> str:
        """Extract base path from OpenAPI 3.0 servers"""
        servers = spec.get('servers', [])
        if servers and len(servers) > 0:
            url = servers[0].get('url', '')
            # Extract path from URL
            if '://' in url:
                # Full URL, extract path
                parts = url.split('/', 3)
                if len(parts) > 3:
                    return '/' + parts[3]
            else:
                # Relative path
                return url
        return '/'

    def _parse_operation_openapi3(self, path: str, method: str, operation: Dict, spec: Dict) -> Dict:
        """Parse OpenAPI 3.0 operation"""
        endpoint = {
            'name': operation.get('operationId', self._generate_operation_id(method, path)),
            'httpMethod': method,
            'path': path,
            'summary': operation.get('summary', ''),
            'description': operation.get('description', ''),
            'requestParameters': [],
            'requestBody': None,
            'response': None
        }

        # Parse parameters
        parameters = operation.get('parameters', [])
        for param in parameters:
            param_info = self._parse_parameter_openapi3(param)
            if param_info:
                endpoint['requestParameters'].append(param_info)

        # Parse request body
        if 'requestBody' in operation:
            request_body = self._parse_request_body_openapi3(
                operation['requestBody'], spec
            )
            if request_body:
                endpoint['requestBody'] = request_body

        # Parse responses
        responses = operation.get('responses', {})
        if '200' in responses or '201' in responses:
            response_key = '201' if '201' in responses else '200'
            response = self._parse_response_openapi3(
                responses[response_key], spec, response_key
            )
            if response:
                endpoint['response'] = response

        return endpoint

    def _parse_operation_swagger2(self, path: str, method: str, operation: Dict, spec: Dict) -> Dict:
        """Parse Swagger 2.0 operation"""
        endpoint = {
            'name': operation.get('operationId', self._generate_operation_id(method, path)),
            'httpMethod': method,
            'path': path,
            'summary': operation.get('summary', ''),
            'description': operation.get('description', ''),
            'requestParameters': [],
            'requestBody': None,
            'response': None
        }

        # Parse parameters
        parameters = operation.get('parameters', [])
        body_params = []

        for param in parameters:
            if param.get('in') == 'body':
                body_params.append(param)
            else:
                param_info = self._parse_parameter_swagger2(param, spec)
                if param_info:
                    endpoint['requestParameters'].append(param_info)

        # Parse body parameters as request body
        if body_params:
            request_body = self._parse_body_parameter_swagger2(body_params[0], spec)
            if request_body:
                endpoint['requestBody'] = request_body

        # Parse responses
        responses = operation.get('responses', {})
        if '200' in responses or '201' in responses:
            response_key = '201' if '201' in responses else '200'
            response = self._parse_response_swagger2(
                responses[response_key], spec, response_key
            )
            if response:
                endpoint['response'] = response

        return endpoint

    def _parse_parameter_openapi3(self, param: Dict) -> Optional[Dict]:
        """Parse OpenAPI 3.0 parameter"""
        location_map = {
            'path': 'PATH',
            'query': 'QUERY',
            'header': 'HEADER',
            'cookie': 'COOKIE'
        }

        schema = param.get('schema', {})

        return {
            'name': param.get('name'),
            'type': self._map_type(schema.get('type'), schema.get('format')),
            'parameterLocation': location_map.get(param.get('in'), 'QUERY'),
            'required': param.get('required', False),
            'description': param.get('description', ''),
            'defaultValue': schema.get('default', '')
        }

    def _parse_parameter_swagger2(self, param: Dict, spec: Dict) -> Optional[Dict]:
        """Parse Swagger 2.0 parameter"""
        location_map = {
            'path': 'PATH',
            'query': 'QUERY',
            'header': 'HEADER',
            'formData': 'FORM'
        }

        return {
            'name': param.get('name'),
            'type': self._map_type(param.get('type'), param.get('format')),
            'parameterLocation': location_map.get(param.get('in'), 'QUERY'),
            'required': param.get('required', False),
            'description': param.get('description', ''),
            'defaultValue': param.get('default', '')
        }

    def _parse_request_body_openapi3(self, request_body: Dict, spec: Dict) -> Optional[Dict]:
        """Parse OpenAPI 3.0 request body"""
        content = request_body.get('content', {})

        # Priority: application/json
        if 'application/json' in content:
            schema = content['application/json'].get('schema', {})

            # Resolve reference if needed
            if '$ref' in schema:
                schema = self._resolve_reference(schema['$ref'], spec)

            fields = self._parse_schema_properties(schema, spec)

            # Generate DTO name from schema title or generate one
            dto_name = schema.get('title', 'Request')
            if not dto_name.endswith('Request'):
                dto_name += 'Request'

            return {
                'required': request_body.get('required', False),
                'type': dto_name,
                'fields': fields
            }

        return None

    def _parse_body_parameter_swagger2(self, param: Dict, spec: Dict) -> Optional[Dict]:
        """Parse Swagger 2.0 body parameter"""
        schema = param.get('schema', {})

        # Resolve reference if needed
        if '$ref' in schema:
            schema = self._resolve_reference(schema['$ref'], spec)

        fields = self._parse_schema_properties(schema, spec)

        # Generate DTO name
        dto_name = schema.get('title', param.get('name', 'Request'))
        if not dto_name.endswith('Request'):
            dto_name += 'Request'

        return {
            'required': param.get('required', False),
            'type': dto_name,
            'fields': fields
        }

    def _parse_response_openapi3(self, response: Dict, spec: Dict, status_code: str) -> Optional[Dict]:
        """Parse OpenAPI 3.0 response"""
        content = response.get('content', {})

        # Priority: application/json
        if 'application/json' in content:
            schema = content['application/json'].get('schema', {})

            # Resolve reference if needed
            if '$ref' in schema:
                schema = self._resolve_reference(schema['$ref'], spec)

            # Check if it's an array
            if schema.get('type') == 'array':
                response_type = 'LIST'
                items_schema = schema.get('items', {})
                if '$ref' in items_schema:
                    items_schema = self._resolve_reference(items_schema['$ref'], spec)
                dto_name = items_schema.get('title', 'Response')
                fields = self._parse_schema_properties(items_schema, spec)
            else:
                response_type = 'SINGLE_OBJECT'
                dto_name = schema.get('title', 'Response')
                fields = self._parse_schema_properties(schema, spec)

            if not dto_name.endswith('Response'):
                dto_name += 'Response'

            return {
                'type': response_type,
                'httpStatus': status_code,
                'dataType': dto_name,
                'fields': fields,
                'wrapInResponseEntity': True
            }

        # No content response
        if status_code in ['204', '205']:
            return {
                'type': 'VOID',
                'httpStatus': status_code,
                'wrapInResponseEntity': True
            }

        return None

    def _parse_response_swagger2(self, response: Dict, spec: Dict, status_code: str) -> Optional[Dict]:
        """Parse Swagger 2.0 response"""
        schema = response.get('schema', {})

        if not schema:
            # No content response
            return {
                'type': 'VOID',
                'httpStatus': status_code,
                'wrapInResponseEntity': True
            }

        # Resolve reference if needed
        if '$ref' in schema:
            schema = self._resolve_reference(schema['$ref'], spec)

        # Check if it's an array
        if schema.get('type') == 'array':
            response_type = 'LIST'
            items_schema = schema.get('items', {})
            if '$ref' in items_schema:
                items_schema = self._resolve_reference(items_schema['$ref'], spec)
            dto_name = items_schema.get('title', 'Response')
            fields = self._parse_schema_properties(items_schema, spec)
        else:
            response_type = 'SINGLE_OBJECT'
            dto_name = schema.get('title', 'Response')
            fields = self._parse_schema_properties(schema, spec)

        if not dto_name.endswith('Response'):
            dto_name += 'Response'

        return {
            'type': response_type,
            'httpStatus': status_code,
            'dataType': dto_name,
            'fields': fields,
            'wrapInResponseEntity': True
        }

    def _parse_schema_properties(self, schema: Dict, spec: Dict) -> List[Dict]:
        """Parse schema properties to extract fields"""
        fields = []
        properties = schema.get('properties', {})
        required_fields = schema.get('required', [])

        for field_name, field_schema in properties.items():
            # Resolve reference if needed
            if '$ref' in field_schema:
                field_schema = self._resolve_reference(field_schema['$ref'], spec)

            field = {
                'name': field_name,
                'type': self._map_type(field_schema.get('type'), field_schema.get('format')),
                'required': field_name in required_fields,
                'description': field_schema.get('description', ''),
                'validation': {}
            }

            # Add validation rules
            if field_schema.get('minLength'):
                field['validation']['minLength'] = field_schema['minLength']
            if field_schema.get('maxLength'):
                field['validation']['maxLength'] = field_schema['maxLength']
            if field_schema.get('minimum'):
                field['validation']['min'] = field_schema['minimum']
            if field_schema.get('maximum'):
                field['validation']['max'] = field_schema['maximum']
            if field_schema.get('pattern'):
                field['validation']['pattern'] = field_schema['pattern']
            if field_schema.get('format') == 'email':
                field['validation']['email'] = True
            if field['required']:
                field['validation']['notNull'] = True
                if field['type'] == 'String':
                    field['validation']['notBlank'] = True

            # Handle nested objects
            if field_schema.get('type') == 'object':
                # For now, treat nested objects as custom types
                field['type'] = self._to_pascal_case(field_name)

            # Handle arrays
            if field_schema.get('type') == 'array':
                items = field_schema.get('items', {})
                item_type = self._map_type(items.get('type'), items.get('format'))
                field['type'] = f'List<{item_type}>'

            fields.append(field)

        return fields

    def _resolve_reference(self, ref: str, spec: Dict) -> Dict:
        """Resolve a $ref reference in the specification"""
        # Remove leading '#/' and split by '/'
        ref_path = ref.replace('#/', '').split('/')

        # Navigate to the referenced object
        current = spec
        for part in ref_path:
            if part in current:
                current = current[part]
            else:
                return {}

        return current

    def _map_type(self, openapi_type: str, format: str = None) -> str:
        """Map OpenAPI type to Java type"""
        if format:
            # Check format-specific mappings first
            if format in self.type_mapping:
                return self.type_mapping[format]

            # Special format handling
            if format == 'int32':
                return 'Integer'
            elif format == 'int64':
                return 'Long'
            elif format == 'float':
                return 'Float'
            elif format == 'double':
                return 'Double'
            elif format == 'date':
                return 'LocalDate'
            elif format == 'date-time':
                return 'LocalDateTime'

        # Fall back to type mapping
        return self.type_mapping.get(openapi_type, 'String')

    def _generate_operation_id(self, method: str, path: str) -> str:
        """Generate an operation ID from method and path"""
        # Remove path parameters and special characters
        clean_path = re.sub(r'\{[^}]+\}', '', path)
        clean_path = re.sub(r'[^a-zA-Z0-9]', ' ', clean_path)

        # Convert to camelCase
        parts = clean_path.split()
        if parts:
            operation_id = method.lower() + ''.join(p.capitalize() for p in parts)
        else:
            operation_id = method.lower()

        return operation_id

    def _to_pascal_case(self, text: str) -> str:
        """Convert text to PascalCase"""
        # Split by common separators
        parts = re.split(r'[_\-\s]+', text)
        return ''.join(p.capitalize() for p in parts if p)