from jinja2 import Environment, FileSystemLoader
from typing import Dict, List
from datetime import datetime
import os


class CodeGeneratorService:
    """Service to generate Spring Boot code using templates"""

    def __init__(self):
        template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'templates', 'java')
        self.env = Environment(loader=FileSystemLoader(template_dir))

    def generate_code(
        self,
        project_config: Dict,
        api_spec: Dict,
        generation_options: Dict
    ) -> Dict[str, str]:
        """
        Generate all code files based on specification
        Returns dict mapping file paths to file contents
        """
        generated_files = {}

        package_name = project_config.get('packageName', 'com.example.demo')
        controller_class_name = api_spec.get('controllerClassName', 'Api')
        service_name = f"{controller_class_name}Service"

        # Collect DTOs
        request_dtos = set()
        response_dtos = set()

        for endpoint in api_spec.get('endpoints', []):
            if endpoint.get('requestBody'):
                dto_name = self._generate_dto_name(endpoint['name'], 'Request')
                request_dtos.add(dto_name)
            if endpoint.get('response') and endpoint['response'].get('dataType'):
                response_dtos.add(endpoint['response']['dataType'])

        # Generate Controller
        if True:  # Always generate controller
            controller_code = self._generate_controller(
                package_name,
                controller_class_name,
                service_name,
                api_spec,
                list(request_dtos),
                list(response_dtos),
                generation_options
            )
            controller_path = self._get_file_path(package_name, 'controller', f"{controller_class_name}Controller.java")
            generated_files[controller_path] = controller_code

        # Generate Service Interface
        if generation_options.get('includeServiceLayer', True):
            service_code = self._generate_service(
                package_name,
                service_name,
                api_spec,
                list(request_dtos),
                list(response_dtos)
            )
            service_path = self._get_file_path(package_name, 'service', f"{service_name}.java")
            generated_files[service_path] = service_code

            # Generate Service Implementation
            service_impl_code = self._generate_service_impl(
                package_name,
                service_name,
                api_spec,
                list(request_dtos),
                list(response_dtos),
                generation_options
            )
            service_impl_path = self._get_file_path(package_name, 'service/impl', f"{service_name}Impl.java")
            generated_files[service_impl_path] = service_impl_code

        # Generate DTOs
        for endpoint in api_spec.get('endpoints', []):
            # Request DTOs
            if endpoint.get('requestBody'):
                dto_name = self._generate_dto_name(endpoint['name'], 'Request')
                dto_code = self._generate_dto(
                    package_name,
                    dto_name,
                    endpoint['requestBody'].get('fields', []),
                    'request'
                )
                dto_path = self._get_file_path(package_name, 'dto/request', f"{dto_name}.java")
                generated_files[dto_path] = dto_code

            # Response DTOs
            if endpoint.get('response') and endpoint['response'].get('fields'):
                dto_name = endpoint['response'].get('dataType', self._generate_dto_name(endpoint['name'], 'Response'))
                dto_code = self._generate_dto(
                    package_name,
                    dto_name,
                    endpoint['response'].get('fields', []),
                    'response'
                )
                dto_path = self._get_file_path(package_name, 'dto/response', f"{dto_name}.java")
                generated_files[dto_path] = dto_code

        # Generate Exception Handler
        if generation_options.get('includeExceptionHandling', True):
            exception_handler_code = self._generate_exception_handler(package_name)
            exception_path = self._get_file_path(package_name, 'exception', 'GlobalExceptionHandler.java')
            generated_files[exception_path] = exception_handler_code

            error_response_code = self._generate_error_response(package_name)
            error_response_path = self._get_file_path(package_name, 'exception', 'ErrorResponse.java')
            generated_files[error_response_path] = error_response_code

        # Generate Test Classes
        if generation_options.get('generateTests', False):
            # Generate Controller Test
            controller_test_code = self._generate_controller_test(
                package_name,
                controller_class_name,
                service_name,
                api_spec,
                list(request_dtos),
                list(response_dtos),
                generation_options
            )
            controller_test_path = self._get_test_file_path(package_name, 'controller', f"{controller_class_name}ControllerTest.java")
            generated_files[controller_test_path] = controller_test_code

            # Generate Service Test
            if generation_options.get('includeServiceLayer', True):
                service_test_code = self._generate_service_test(
                    package_name,
                    service_name,
                    api_spec,
                    list(request_dtos),
                    list(response_dtos),
                    generation_options
                )
                service_test_path = self._get_test_file_path(package_name, 'service/impl', f"{service_name}ImplTest.java")
                generated_files[service_test_path] = service_test_code

        # Generate Custom Exception Classes
        if generation_options.get('generateCustomExceptions', False):
            entity_name = controller_class_name

            # Generate NotFoundException
            not_found_exception = self._generate_custom_exception(
                package_name,
                f"{entity_name}NotFoundException",
                "RuntimeException",
                f"{entity_name} not found"
            )
            exception_path = self._get_file_path(package_name, 'exception', f"{entity_name}NotFoundException.java")
            generated_files[exception_path] = not_found_exception

            # Generate ValidationException
            validation_exception = self._generate_custom_exception(
                package_name,
                f"{entity_name}ValidationException",
                "RuntimeException",
                f"{entity_name} validation failed"
            )
            validation_path = self._get_file_path(package_name, 'exception', f"{entity_name}ValidationException.java")
            generated_files[validation_path] = validation_exception

        # Generate Repository Layer (JPA)
        if generation_options.get('generateRepository', False):
            entity_name = controller_class_name

            # Generate Entity class
            entity_code = self._generate_entity(
                package_name,
                entity_name,
                api_spec.get('endpoints', [])
            )
            entity_path = self._get_file_path(package_name, 'entity', f"{entity_name}.java")
            generated_files[entity_path] = entity_code

            # Generate Repository interface
            repository_code = self._generate_repository(
                package_name,
                entity_name
            )
            repository_path = self._get_file_path(package_name, 'repository', f"{entity_name}Repository.java")
            generated_files[repository_path] = repository_code

        return generated_files

    def _generate_controller(
        self,
        package_name: str,
        controller_class_name: str,
        service_name: str,
        api_spec: Dict,
        request_dtos: List[str],
        response_dtos: List[str],
        generation_options: Dict
    ) -> str:
        """Generate controller code"""
        template = self.env.get_template('controller.java.j2')

        methods = []
        for endpoint in api_spec.get('endpoints', []):
            method_info = self._extract_method_info(endpoint)
            methods.append(method_info)

        return template.render(
            packageName=package_name,
            controllerClassName=controller_class_name,
            serviceName=service_name,
            baseMapping=api_spec.get('baseControllerPath', '/api'),
            methods=methods,
            request_dtos=request_dtos,
            response_dtos=response_dtos,
            includeLogging=generation_options.get('includeLogging', True),
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_service(
        self,
        package_name: str,
        service_name: str,
        api_spec: Dict,
        request_dtos: List[str],
        response_dtos: List[str]
    ) -> str:
        """Generate service interface code"""
        template = self.env.get_template('service.java.j2')

        methods = []
        for endpoint in api_spec.get('endpoints', []):
            method_info = self._extract_method_info(endpoint)
            methods.append(method_info)

        return template.render(
            packageName=package_name,
            serviceName=service_name,
            methods=methods,
            request_dtos=request_dtos,
            response_dtos=response_dtos,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_service_impl(
        self,
        package_name: str,
        service_name: str,
        api_spec: Dict,
        request_dtos: List[str],
        response_dtos: List[str],
        generation_options: Dict
    ) -> str:
        """Generate service implementation code"""
        template = self.env.get_template('service_impl.java.j2')

        methods = []
        for endpoint in api_spec.get('endpoints', []):
            method_info = self._extract_method_info(endpoint)
            methods.append(method_info)

        return template.render(
            packageName=package_name,
            serviceName=service_name,
            methods=methods,
            request_dtos=request_dtos,
            response_dtos=response_dtos,
            includeLogging=generation_options.get('includeLogging', True),
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_dto(
        self,
        package_name: str,
        class_name: str,
        fields: List[Dict],
        dto_type: str
    ) -> str:
        """Generate DTO code"""
        template = self.env.get_template('dto.java.j2')

        has_validation = any(field.get('validation') for field in fields)
        has_date_types = any('Date' in field.get('type', '') for field in fields)
        has_big_decimal = any('BigDecimal' in field.get('type', '') for field in fields)

        return template.render(
            packageName=package_name,
            className=class_name,
            dtoType=dto_type,
            fields=fields,
            hasValidation=has_validation,
            hasDateTypes=has_date_types,
            hasBigDecimal=has_big_decimal,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_exception_handler(self, package_name: str) -> str:
        """Generate global exception handler"""
        template = self.env.get_template('exception_handler.java.j2')
        return template.render(
            packageName=package_name,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_error_response(self, package_name: str) -> str:
        """Generate error response class"""
        template = self.env.get_template('error_response.java.j2')
        return template.render(
            packageName=package_name,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_controller_test(
        self,
        package_name: str,
        controller_class_name: str,
        service_name: str,
        api_spec: Dict,
        request_dtos: List[str],
        response_dtos: List[str],
        generation_options: Dict
    ) -> str:
        """Generate controller test class"""
        template = self.env.get_template('controller_test.java.j2')

        endpoints = []
        for endpoint in api_spec.get('endpoints', []):
            method_info = self._extract_method_info(endpoint)
            endpoints.append({
                'name': endpoint['name'],
                'httpMethod': endpoint['httpMethod'],
                'path': endpoint['path'],
                'requestParameters': endpoint.get('requestParameters', []),
                'requestBody': endpoint.get('requestBody'),
                'response': endpoint.get('response', {})
            })

        return template.render(
            packageName=package_name,
            controllerClassName=controller_class_name,
            serviceName=service_name,
            baseMapping=api_spec.get('baseControllerPath', '/api'),
            endpoints=endpoints,
            requestDtos=request_dtos,
            responseDtos=response_dtos,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_service_test(
        self,
        package_name: str,
        service_name: str,
        api_spec: Dict,
        request_dtos: List[str],
        response_dtos: List[str],
        generation_options: Dict
    ) -> str:
        """Generate service test class"""
        template = self.env.get_template('service_test.java.j2')

        endpoints = []
        for endpoint in api_spec.get('endpoints', []):
            endpoints.append({
                'name': endpoint['name'],
                'httpMethod': endpoint['httpMethod'],
                'requestParameters': endpoint.get('requestParameters', []),
                'requestBody': endpoint.get('requestBody'),
                'response': endpoint.get('response', {})
            })

        return template.render(
            packageName=package_name,
            serviceName=service_name,
            endpoints=endpoints,
            requestDtos=request_dtos,
            responseDtos=response_dtos,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_custom_exception(
        self,
        package_name: str,
        exception_name: str,
        extends: str,
        default_message: str
    ) -> str:
        """Generate custom exception class"""
        return f"""package {package_name}.exception;

/**
 * Custom exception: {exception_name}
 * Generated by Spring Boot API Generator
 */
public class {exception_name} extends {extends} {{

    private static final long serialVersionUID = 1L;

    public {exception_name}() {{
        super("{default_message}");
    }}

    public {exception_name}(String message) {{
        super(message);
    }}

    public {exception_name}(String message, Throwable cause) {{
        super(message, cause);
    }}

    public {exception_name}(Throwable cause) {{
        super(cause);
    }}
}}"""

    def _extract_method_info(self, endpoint: Dict) -> Dict:
        """Extract method information from endpoint specification"""
        parameters = []

        # Extract path variables, query params, and request body
        for param in endpoint.get('requestParameters', []):
            parameters.append({
                'name': param['name'],
                'type': param['type'],
                'location': param['parameterLocation'],
                'required': param.get('required', False),
                'defaultValue': param.get('defaultValue')
            })

        if endpoint.get('requestBody'):
            dto_name = self._generate_dto_name(endpoint['name'], 'Request')
            parameters.append({
                'name': self._to_camel_case(dto_name.replace('Request', '') + 'Request'),
                'type': dto_name,
                'location': 'BODY',
                'required': endpoint['requestBody'].get('required', True)
            })

        # Determine return type
        response = endpoint.get('response', {})
        response_type = response.get('type', 'SINGLE_OBJECT')
        data_type = response.get('dataType', 'Void')

        if response_type == 'LIST':
            return_type = f"List<{data_type}>"
        elif response_type == 'VOID':
            return_type = 'Void'
        else:
            return_type = data_type

        return {
            'methodName': endpoint['name'],
            'httpMethod': endpoint['httpMethod'].capitalize(),
            'path': endpoint.get('path', ''),
            'description': endpoint.get('description', ''),
            'parameters': parameters,
            'returnType': return_type,
            'httpStatus': self._map_http_status(response.get('httpStatus', 200))
        }

    def _generate_dto_name(self, endpoint_name: str, suffix: str) -> str:
        """Generate DTO class name from endpoint name"""
        # Convert camelCase to PascalCase
        pascal_case = endpoint_name[0].upper() + endpoint_name[1:]
        return f"{pascal_case}{suffix}"

    def _to_camel_case(self, text: str) -> str:
        """Convert to camelCase"""
        return text[0].lower() + text[1:]

    def _map_http_status(self, status_code: int) -> str:
        """Map HTTP status code to Spring constant"""
        status_map = {
            200: 'OK',
            201: 'CREATED',
            204: 'NO_CONTENT',
            400: 'BAD_REQUEST',
            404: 'NOT_FOUND',
            500: 'INTERNAL_SERVER_ERROR'
        }
        return status_map.get(status_code, 'OK')

    def _get_file_path(self, package_name: str, sub_package: str, file_name: str) -> str:
        """Generate file path for generated code"""
        package_path = package_name.replace('.', '/')
        return f"src/main/java/{package_path}/{sub_package}/{file_name}"

    def _get_test_file_path(self, package_name: str, sub_package: str, file_name: str) -> str:
        """Generate test file path for generated test code"""
        package_path = package_name.replace('.', '/')
        return f"src/test/java/{package_path}/{sub_package}/{file_name}"

    def _generate_entity(self, package_name: str, entity_name: str, endpoints: List[Dict]) -> str:
        """Generate JPA entity class"""
        template = self.env.get_template('entity.java.j2')

        # Extract fields from endpoints (simplified approach)
        fields = []
        imports = set()

        # Add basic fields based on common patterns
        fields.append({
            'name': 'name',
            'type': 'String',
            'column': 'name',
            'nullable': 'false',
            'unique': True,
            'length': 100,
            'description': 'Name of the entity'
        })

        fields.append({
            'name': 'description',
            'type': 'String',
            'column': 'description',
            'nullable': 'true',
            'length': 500,
            'description': 'Description of the entity'
        })

        # Look for fields in request/response DTOs
        for endpoint in endpoints:
            if endpoint.get('requestBody') and endpoint['requestBody'].get('fields'):
                for field in endpoint['requestBody']['fields']:
                    field_def = {
                        'name': field['name'],
                        'type': self._map_to_jpa_type(field['type']),
                        'column': self._to_snake_case(field['name']),
                        'nullable': 'false' if field.get('required') else 'true',
                        'description': field.get('description')
                    }

                    if field['type'] == 'String':
                        field_def['length'] = 255

                    # Add validation annotations if present
                    field_def['validations'] = []
                    if field.get('validation'):
                        if field['validation'].get('notNull'):
                            field_def['validations'].append('@NotNull')
                            imports.add('jakarta.validation.constraints.NotNull')
                        if field['validation'].get('notBlank'):
                            field_def['validations'].append('@NotBlank')
                            imports.add('jakarta.validation.constraints.NotBlank')
                        if field['validation'].get('email'):
                            field_def['validations'].append('@Email')
                            imports.add('jakarta.validation.constraints.Email')

                    # Avoid duplicates
                    if not any(f['name'] == field_def['name'] for f in fields):
                        fields.append(field_def)

        return template.render(
            packageName=package_name,
            entityName=entity_name,
            entityClassName=entity_name,
            tableName=self._to_snake_case(entity_name),
            fields=fields,
            idType='Long',
            additionalImports=list(imports),
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _generate_repository(self, package_name: str, entity_name: str) -> str:
        """Generate JPA repository interface"""
        template = self.env.get_template('repository.java.j2')

        return template.render(
            packageName=package_name,
            entityPackage=f"{package_name}.entity",
            entityClassName=entity_name,
            repositoryName=f"{entity_name}Repository",
            idType='Long',
            customMethods=[],  # Can be extended based on requirements
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

    def _map_to_jpa_type(self, dto_type: str) -> str:
        """Map DTO type to JPA entity type"""
        type_mapping = {
            'String': 'String',
            'Integer': 'Integer',
            'Long': 'Long',
            'Boolean': 'Boolean',
            'Double': 'Double',
            'LocalDate': 'LocalDate',
            'LocalDateTime': 'LocalDateTime',
            'BigDecimal': 'BigDecimal'
        }
        return type_mapping.get(dto_type, 'String')

    def _to_snake_case(self, text: str) -> str:
        """Convert camelCase or PascalCase to snake_case"""
        import re
        # Insert underscore before uppercase letters and convert to lowercase
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', text)
        return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()
