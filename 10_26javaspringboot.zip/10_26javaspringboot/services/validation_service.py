"""
Validation Service with 4-layer validation strategy
Provides comprehensive input validation and sanitization
"""

import re
from typing import Dict, List, Optional, Any
from enum import Enum


class ValidationLayer(Enum):
    """Validation layers in order of execution"""
    INPUT_SANITIZATION = 1
    SCHEMA_VALIDATION = 2
    BUSINESS_RULES = 3
    DEPENDENCY_VALIDATION = 4


class ValidationService:
    """
    Four-layer validation service for Spring Boot API Generator

    Layers:
    1. Input Sanitization - Clean and normalize inputs
    2. Schema Validation - Check data types and required fields
    3. Business Rules - Validate business logic constraints
    4. Dependency Validation - Check inter-field dependencies
    """

    # Error codes for different validation failures
    ERROR_CODES = {
        'INVALID_INPUT': 'E001',
        'MISSING_FIELD': 'E002',
        'INVALID_FORMAT': 'E003',
        'CONSTRAINT_VIOLATION': 'E004',
        'DEPENDENCY_ERROR': 'E005',
        'INVALID_JAVA_IDENTIFIER': 'E006',
        'INVALID_URL_PATH': 'E007',
        'INCOMPATIBLE_VERSION': 'E008',
        'DUPLICATE_VALUE': 'E009',
        'RESERVED_KEYWORD': 'E010'
    }

    # Java reserved keywords
    JAVA_KEYWORDS = {
        'abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch', 'char',
        'class', 'const', 'continue', 'default', 'do', 'double', 'else', 'enum',
        'extends', 'final', 'finally', 'float', 'for', 'goto', 'if', 'implements',
        'import', 'instanceof', 'int', 'interface', 'long', 'native', 'new', 'package',
        'private', 'protected', 'public', 'return', 'short', 'static', 'strictfp',
        'super', 'switch', 'synchronized', 'this', 'throw', 'throws', 'transient',
        'try', 'void', 'volatile', 'while', 'true', 'false', 'null'
    }

    def __init__(self):
        self.errors = []
        self.warnings = []

    def validate(self, data: Dict) -> Dict:
        """
        Main validation entry point - runs all 4 validation layers

        Returns:
            {
                'valid': bool,
                'errors': [{'code': 'E001', 'field': 'name', 'message': '...'}],
                'warnings': [{'field': 'name', 'message': '...'}],
                'sanitized_data': {...}
            }
        """
        self.errors = []
        self.warnings = []

        # Layer 1: Input Sanitization
        sanitized_data = self._layer1_sanitization(data)

        # Layer 2: Schema Validation
        if not self._layer2_schema_validation(sanitized_data):
            return self._build_response(False, sanitized_data)

        # Layer 3: Business Rules Validation
        if not self._layer3_business_rules(sanitized_data):
            return self._build_response(False, sanitized_data)

        # Layer 4: Dependency Validation
        if not self._layer4_dependency_validation(sanitized_data):
            return self._build_response(False, sanitized_data)

        return self._build_response(True, sanitized_data)

    def _layer1_sanitization(self, data: Dict) -> Dict:
        """Layer 1: Input Sanitization - Clean and normalize inputs"""
        sanitized = {}

        # Sanitize project configuration
        if 'projectConfiguration' in data:
            proj_config = data['projectConfiguration']
            sanitized['projectConfiguration'] = {
                'projectName': self._sanitize_string(proj_config.get('projectName', ''), max_length=50),
                'description': self._sanitize_string(proj_config.get('description', ''), max_length=200),
                'groupId': self._sanitize_java_package(proj_config.get('groupId', '')),
                'artifactId': self._sanitize_artifact_id(proj_config.get('artifactId', '')),
                'packageName': self._sanitize_java_package(proj_config.get('packageName', '')),
                'springBootVersion': self._sanitize_version(proj_config.get('springBootVersion', '3.2.0')),
                'javaVersion': self._sanitize_version(proj_config.get('javaVersion', '17')),
                'buildTool': 'gradle',  # Force Gradle
                'packaging': proj_config.get('packaging', 'jar').lower()
            }

        # Sanitize dependency configuration
        if 'dependencyConfiguration' in data:
            dep_config = data['dependencyConfiguration']
            sanitized['dependencyConfiguration'] = {
                'database': self._sanitize_enum(dep_config.get('database'),
                                                 ['none', 'mysql', 'postgresql', 'h2', 'mongodb']),
                'security': bool(dep_config.get('security', False)),
                'documentation': bool(dep_config.get('documentation', True)),
                'caching': bool(dep_config.get('caching', False)),
                'messaging': bool(dep_config.get('messaging', False))
            }

        # Sanitize API specification
        if 'apiSpecification' in data:
            api_spec = data['apiSpecification']
            sanitized['apiSpecification'] = {
                'baseControllerPath': self._sanitize_url_path(api_spec.get('baseControllerPath', '/api')),
                'controllerClassName': self._sanitize_class_name(api_spec.get('controllerClassName', '')),
                'description': self._sanitize_string(api_spec.get('description', ''), max_length=500),
                'endpoints': self._sanitize_endpoints(api_spec.get('endpoints', []))
            }

        # Sanitize generation options
        if 'generationOptions' in data:
            gen_opts = data['generationOptions']
            sanitized['generationOptions'] = {
                'includeServiceLayer': bool(gen_opts.get('includeServiceLayer', True)),
                'includeExceptionHandling': bool(gen_opts.get('includeExceptionHandling', True)),
                'includeValidation': bool(gen_opts.get('includeValidation', True)),
                'includeLogging': bool(gen_opts.get('includeLogging', True)),
                'generateTests': bool(gen_opts.get('generateTests', False)),
                'enhanceWithLLM': bool(gen_opts.get('enhanceWithLLM', False)),
                'generateSwaggerDocs': bool(gen_opts.get('generateSwaggerDocs', True))
            }

        return sanitized

    def _layer2_schema_validation(self, data: Dict) -> bool:
        """Layer 2: Schema Validation - Check data types and required fields"""

        # Check required sections
        if 'projectConfiguration' not in data:
            self._add_error('MISSING_FIELD', 'projectConfiguration', 'Project configuration is required')
            return False

        if 'apiSpecification' not in data:
            self._add_error('MISSING_FIELD', 'apiSpecification', 'API specification is required')
            return False

        # Validate project configuration required fields
        proj_config = data['projectConfiguration']
        required_project_fields = ['projectName', 'groupId', 'artifactId', 'packageName']

        for field in required_project_fields:
            if not proj_config.get(field):
                self._add_error('MISSING_FIELD', f'projectConfiguration.{field}',
                              f'{field} is required')

        # Validate API specification required fields
        api_spec = data['apiSpecification']

        if not api_spec.get('baseControllerPath'):
            self._add_error('MISSING_FIELD', 'apiSpecification.baseControllerPath',
                          'Base controller path is required')

        if not api_spec.get('controllerClassName'):
            self._add_error('MISSING_FIELD', 'apiSpecification.controllerClassName',
                          'Controller class name is required')

        # Validate endpoints
        endpoints = api_spec.get('endpoints', [])
        if not endpoints:
            self._add_error('MISSING_FIELD', 'apiSpecification.endpoints',
                          'At least one endpoint is required')

        for i, endpoint in enumerate(endpoints):
            if not endpoint.get('name'):
                self._add_error('MISSING_FIELD', f'endpoints[{i}].name',
                              'Endpoint name is required')

            if not endpoint.get('httpMethod'):
                self._add_error('MISSING_FIELD', f'endpoints[{i}].httpMethod',
                              'HTTP method is required')

            if not endpoint.get('path'):
                self._add_error('MISSING_FIELD', f'endpoints[{i}].path',
                              'Endpoint path is required')

        return len(self.errors) == 0

    def _layer3_business_rules(self, data: Dict) -> bool:
        """Layer 3: Business Rules Validation"""
        proj_config = data['projectConfiguration']
        api_spec = data['apiSpecification']

        # Validate project name length
        project_name = proj_config.get('projectName', '')
        if len(project_name) < 3:
            self._add_error('CONSTRAINT_VIOLATION', 'projectName',
                          'Project name must be at least 3 characters')
        elif len(project_name) > 50:
            self._add_error('CONSTRAINT_VIOLATION', 'projectName',
                          'Project name must not exceed 50 characters')

        # Validate Java package format
        package_name = proj_config.get('packageName', '')
        if not self._is_valid_java_package(package_name):
            self._add_error('INVALID_FORMAT', 'packageName',
                          'Invalid Java package name format')

        group_id = proj_config.get('groupId', '')
        if not self._is_valid_java_package(group_id):
            self._add_error('INVALID_FORMAT', 'groupId',
                          'Invalid group ID format (use Java package format)')

        # Validate artifact ID format
        artifact_id = proj_config.get('artifactId', '')
        if not self._is_valid_artifact_id(artifact_id):
            self._add_error('INVALID_FORMAT', 'artifactId',
                          'Artifact ID must contain only lowercase letters, numbers, and hyphens')

        # Validate controller class name
        controller_name = api_spec.get('controllerClassName', '')
        if not self._is_valid_class_name(controller_name):
            self._add_error('INVALID_JAVA_IDENTIFIER', 'controllerClassName',
                          'Invalid Java class name')

        if controller_name.lower() in self.JAVA_KEYWORDS:
            self._add_error('RESERVED_KEYWORD', 'controllerClassName',
                          f'{controller_name} is a reserved Java keyword')

        # Validate base controller path
        base_path = api_spec.get('baseControllerPath', '')
        if not self._is_valid_url_path(base_path):
            self._add_error('INVALID_URL_PATH', 'baseControllerPath',
                          'Invalid URL path format')

        # Validate endpoints
        endpoints = api_spec.get('endpoints', [])
        endpoint_paths = set()

        for i, endpoint in enumerate(endpoints):
            # Check for duplicate paths with same HTTP method
            method = endpoint.get('httpMethod', '')
            path = endpoint.get('path', '')
            endpoint_key = f"{method}:{path}"

            if endpoint_key in endpoint_paths:
                self._add_error('DUPLICATE_VALUE', f'endpoints[{i}]',
                              f'Duplicate endpoint: {method} {path}')
            endpoint_paths.add(endpoint_key)

            # Validate endpoint method name
            method_name = endpoint.get('name', '')
            if not self._is_valid_method_name(method_name):
                self._add_error('INVALID_JAVA_IDENTIFIER', f'endpoints[{i}].name',
                              'Invalid Java method name')

            # Validate HTTP method
            valid_methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']
            if method not in valid_methods:
                self._add_error('INVALID_FORMAT', f'endpoints[{i}].httpMethod',
                              f'Invalid HTTP method. Must be one of: {", ".join(valid_methods)}')

            # Validate endpoint path
            if not self._is_valid_url_path(path):
                self._add_error('INVALID_URL_PATH', f'endpoints[{i}].path',
                              'Invalid endpoint URL path')

        return len(self.errors) == 0

    def _layer4_dependency_validation(self, data: Dict) -> bool:
        """Layer 4: Dependency Validation - Check inter-field dependencies"""
        proj_config = data['projectConfiguration']

        # Validate Java version compatibility with Spring Boot version
        java_version = proj_config.get('javaVersion', '17')
        boot_version = proj_config.get('springBootVersion', '3.2.0')

        # Spring Boot 3.x requires Java 17 or higher
        if boot_version.startswith('3.'):
            if java_version not in ['17', '21']:
                self._add_error('INCOMPATIBLE_VERSION', 'javaVersion',
                              f'Spring Boot {boot_version} requires Java 17 or higher')

        # Spring Boot 2.7.x works with Java 11, 17
        elif boot_version.startswith('2.7'):
            if java_version == '21':
                self.warnings.append({
                    'field': 'javaVersion',
                    'message': f'Java {java_version} might have compatibility issues with Spring Boot {boot_version}'
                })

        # Validate endpoint dependencies
        api_spec = data.get('apiSpecification', {})
        endpoints = api_spec.get('endpoints', [])

        for i, endpoint in enumerate(endpoints):
            # If request body is specified, validate its fields
            request_body = endpoint.get('requestBody', {})
            if request_body.get('required'):
                if not request_body.get('type'):
                    self._add_error('DEPENDENCY_ERROR', f'endpoints[{i}].requestBody.type',
                                  'Request body type is required when request body is enabled')

                fields = request_body.get('fields', [])
                if not fields:
                    self.warnings.append({
                        'field': f'endpoints[{i}].requestBody.fields',
                        'message': 'Request body has no fields defined'
                    })

            # Validate response configuration
            response = endpoint.get('response', {})
            response_type = response.get('type', 'SINGLE_OBJECT')

            if response_type in ['SINGLE_OBJECT', 'LIST', 'PAGINATED']:
                if not response.get('dataType'):
                    self._add_error('DEPENDENCY_ERROR', f'endpoints[{i}].response.dataType',
                                  f'Response data type is required for {response_type} response')

        # Validate generation options dependencies
        gen_opts = data.get('generationOptions', {})

        # If tests are to be generated, service layer must be included
        if gen_opts.get('generateTests') and not gen_opts.get('includeServiceLayer'):
            self.warnings.append({
                'field': 'generationOptions',
                'message': 'Test generation works better with service layer enabled'
            })

        return len(self.errors) == 0

    # Helper methods for sanitization
    def _sanitize_string(self, value: str, max_length: int = None) -> str:
        """Sanitize string input"""
        # Remove leading/trailing whitespace
        value = value.strip()

        # Remove dangerous characters (prevent injection)
        value = re.sub(r'[<>\"\'`]', '', value)

        # Limit length if specified
        if max_length and len(value) > max_length:
            value = value[:max_length]

        return value

    def _sanitize_java_package(self, value: str) -> str:
        """Sanitize Java package name"""
        # Convert to lowercase
        value = value.lower()

        # Replace invalid characters with dots
        value = re.sub(r'[^a-z0-9._]', '.', value)

        # Remove consecutive dots
        value = re.sub(r'\.+', '.', value)

        # Remove leading/trailing dots
        value = value.strip('.')

        return value

    def _sanitize_artifact_id(self, value: str) -> str:
        """Sanitize artifact ID"""
        # Convert to lowercase
        value = value.lower()

        # Replace invalid characters with hyphens
        value = re.sub(r'[^a-z0-9-]', '-', value)

        # Remove consecutive hyphens
        value = re.sub(r'-+', '-', value)

        # Remove leading/trailing hyphens
        value = value.strip('-')

        return value

    def _sanitize_class_name(self, value: str) -> str:
        """Sanitize Java class name"""
        # Remove invalid characters
        value = re.sub(r'[^a-zA-Z0-9_$]', '', value)

        # Ensure it starts with a letter
        if value and not value[0].isalpha():
            value = 'Class' + value

        # Convert to PascalCase if needed
        if value and value[0].islower():
            value = value[0].upper() + value[1:]

        return value

    def _sanitize_url_path(self, value: str) -> str:
        """Sanitize URL path"""
        # Ensure it starts with /
        if not value.startswith('/'):
            value = '/' + value

        # Remove dangerous characters
        value = re.sub(r'[<>\"\'`\\]', '', value)

        # Clean up multiple slashes
        value = re.sub(r'/+', '/', value)

        return value

    def _sanitize_version(self, value: str) -> str:
        """Sanitize version string"""
        # Remove non-version characters
        value = re.sub(r'[^0-9.]', '', value)

        return value

    def _sanitize_enum(self, value: Any, valid_values: List[str]) -> str:
        """Sanitize enum value"""
        if value in valid_values:
            return value
        return valid_values[0] if valid_values else 'none'

    def _sanitize_endpoints(self, endpoints: List[Dict]) -> List[Dict]:
        """Sanitize endpoint configurations"""
        sanitized = []

        for endpoint in endpoints:
            sanitized_endpoint = {
                'id': endpoint.get('id', ''),
                'name': self._sanitize_method_name(endpoint.get('name', '')),
                'httpMethod': endpoint.get('httpMethod', 'GET').upper(),
                'path': self._sanitize_url_path(endpoint.get('path', '/')),
                'description': self._sanitize_string(endpoint.get('description', ''), max_length=200),
                'requestParameters': self._sanitize_parameters(endpoint.get('requestParameters', [])),
                'requestBody': self._sanitize_request_body(endpoint.get('requestBody', {})),
                'response': self._sanitize_response(endpoint.get('response', {}))
            }
            sanitized.append(sanitized_endpoint)

        return sanitized

    def _sanitize_method_name(self, value: str) -> str:
        """Sanitize Java method name"""
        # Remove invalid characters
        value = re.sub(r'[^a-zA-Z0-9_$]', '', value)

        # Ensure it starts with a lowercase letter
        if value and value[0].isupper():
            value = value[0].lower() + value[1:]

        if not value:
            value = 'method'

        return value

    def _sanitize_parameters(self, parameters: List[Dict]) -> List[Dict]:
        """Sanitize request parameters"""
        sanitized = []

        for param in parameters:
            sanitized_param = {
                'name': self._sanitize_string(param.get('name', '')),
                'type': param.get('type', 'String'),
                'parameterLocation': param.get('parameterLocation', 'QUERY'),
                'required': bool(param.get('required', False)),
                'defaultValue': self._sanitize_string(param.get('defaultValue', '')),
                'description': self._sanitize_string(param.get('description', ''), max_length=200)
            }
            sanitized.append(sanitized_param)

        return sanitized

    def _sanitize_request_body(self, body: Dict) -> Dict:
        """Sanitize request body configuration"""
        return {
            'required': bool(body.get('required', False)),
            'type': self._sanitize_class_name(body.get('type', '')),
            'fields': self._sanitize_fields(body.get('fields', []))
        }

    def _sanitize_response(self, response: Dict) -> Dict:
        """Sanitize response configuration"""
        return {
            'type': response.get('type', 'SINGLE_OBJECT'),
            'wrapInResponseEntity': bool(response.get('wrapInResponseEntity', True)),
            'httpStatus': response.get('httpStatus', 200),
            'dataType': self._sanitize_class_name(response.get('dataType', '')),
            'fields': self._sanitize_fields(response.get('fields', []))
        }

    def _sanitize_fields(self, fields: List[Dict]) -> List[Dict]:
        """Sanitize field configurations"""
        sanitized = []

        for field in fields:
            sanitized_field = {
                'name': self._sanitize_string(field.get('name', '')),
                'type': field.get('type', 'String'),
                'required': bool(field.get('required', False)),
                'description': self._sanitize_string(field.get('description', ''), max_length=200),
                'validation': field.get('validation', {})
            }
            sanitized.append(sanitized_field)

        return sanitized

    # Validation helper methods
    def _is_valid_java_package(self, package: str) -> bool:
        """Check if string is valid Java package name"""
        if not package:
            return False

        pattern = r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$'
        return bool(re.match(pattern, package))

    def _is_valid_artifact_id(self, artifact_id: str) -> bool:
        """Check if string is valid artifact ID"""
        if not artifact_id:
            return False

        pattern = r'^[a-z][a-z0-9-]*$'
        return bool(re.match(pattern, artifact_id))

    def _is_valid_class_name(self, class_name: str) -> bool:
        """Check if string is valid Java class name"""
        if not class_name:
            return False

        # Must start with letter, can contain letters, numbers, _, $
        pattern = r'^[A-Z][a-zA-Z0-9_$]*$'
        return bool(re.match(pattern, class_name))

    def _is_valid_method_name(self, method_name: str) -> bool:
        """Check if string is valid Java method name"""
        if not method_name:
            return False

        # Must start with lowercase letter, can contain letters, numbers, _, $
        pattern = r'^[a-z][a-zA-Z0-9_$]*$'
        return bool(re.match(pattern, method_name))

    def _is_valid_url_path(self, path: str) -> bool:
        """Check if string is valid URL path"""
        if not path:
            return False

        # Basic URL path validation
        pattern = r'^/[a-zA-Z0-9/_\-{}]*$'
        return bool(re.match(pattern, path))

    # Error and warning management
    def _add_error(self, code: str, field: str, message: str):
        """Add validation error"""
        self.errors.append({
            'code': self.ERROR_CODES.get(code, 'E000'),
            'field': field,
            'message': message
        })

    def _build_response(self, valid: bool, sanitized_data: Dict) -> Dict:
        """Build validation response"""
        return {
            'valid': valid,
            'errors': self.errors,
            'warnings': self.warnings,
            'sanitized_data': sanitized_data if valid else None
        }