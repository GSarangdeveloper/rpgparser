import zipfile
import os
import tempfile
import shutil
from typing import Dict


class ProjectModifierService:
    """Service to modify Spring Boot projects by injecting generated code"""

    def __init__(self):
        self.generated_projects_dir = 'generated_projects'
        os.makedirs(self.generated_projects_dir, exist_ok=True)

    def inject_code(
        self,
        base_zip_path: str,
        generated_code: Dict[str, str],
        project_config: Dict,
        project_id: str
    ) -> str:
        """
        Inject generated code into base project
        Returns path to final project ZIP
        """
        try:
            # Create temp directory for project manipulation
            temp_dir = tempfile.mkdtemp()
            extract_dir = os.path.join(temp_dir, 'project')

            # Extract base project
            with zipfile.ZipFile(base_zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)

            # Find the project root (may be nested)
            project_root = self._find_project_root(extract_dir)

            # Inject generated files
            for file_path, file_content in generated_code.items():
                full_path = os.path.join(project_root, file_path)

                # Create directory if it doesn't exist
                os.makedirs(os.path.dirname(full_path), exist_ok=True)

                # Write file
                with open(full_path, 'w') as f:
                    f.write(file_content)

            # Update application.properties if needed
            self._update_application_properties(project_root, project_config)

            # Create final ZIP
            final_zip_path = os.path.join(self.generated_projects_dir, f'{project_id}.zip')
            self._create_zip(project_root, final_zip_path)

            # Cleanup
            shutil.rmtree(temp_dir)

            return final_zip_path

        except Exception as e:
            print(f"Error injecting code: {str(e)}")
            raise

    def _find_project_root(self, extract_dir: str) -> str:
        """Find the actual project root directory"""
        # Spring Initializr creates a directory with the artifact name
        for root, dirs, files in os.walk(extract_dir):
            if 'build.gradle' in files or 'pom.xml' in files:
                return root
        return extract_dir

    def _update_application_properties(self, project_root: str, project_config: Dict):
        """Update application.properties with additional configuration"""
        properties_path = os.path.join(project_root, 'src', 'main', 'resources', 'application.properties')

        if os.path.exists(properties_path):
            with open(properties_path, 'a') as f:
                f.write('\n# Application Configuration\n')
                f.write(f'spring.application.name={project_config.get("projectName", "demo")}\n')
                f.write('server.port=8080\n')
                f.write('\n# Logging Configuration\n')
                f.write('logging.level.root=INFO\n')
                f.write(f'logging.level.{project_config.get("packageName", "com.example.demo")}=DEBUG\n')

    def _create_zip(self, source_dir: str, output_path: str):
        """Create ZIP file from directory"""
        # Get the parent directory name to use as the root folder in ZIP
        parent_dir = os.path.basename(source_dir)

        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    # Calculate the archive name to preserve directory structure
                    arcname = os.path.join(
                        parent_dir,
                        os.path.relpath(file_path, source_dir)
                    )
                    zipf.write(file_path, arcname)
