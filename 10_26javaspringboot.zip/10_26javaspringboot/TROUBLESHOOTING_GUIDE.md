# Troubleshooting Guide - Spring Boot API Generator

## Table of Contents
1. [Common Issues](#common-issues)
2. [Installation Problems](#installation-problems)
3. [Runtime Errors](#runtime-errors)
4. [Generation Failures](#generation-failures)
5. [File Upload Issues](#file-upload-issues)
6. [Parser Errors](#parser-errors)
7. [Template Errors](#template-errors)
8. [Network Issues](#network-issues)
9. [Performance Problems](#performance-problems)
10. [Debugging Techniques](#debugging-techniques)

## Common Issues

### Issue: Application Won't Start

#### Symptoms
- Application fails to start
- ImportError or ModuleNotFoundError
- Flask application not found

#### Solutions

1. **Check Python Version**
```bash
python --version
# Should be 3.8 or higher
```

2. **Verify Virtual Environment**
```bash
# Check if virtual environment is activated
which python
# Should point to venv/bin/python

# Activate virtual environment
source venv/bin/activate  # Unix/MacOS
venv\Scripts\activate     # Windows
```

3. **Reinstall Dependencies**
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

4. **Check for Missing Modules**
```python
# Test imports
python -c "import flask; print(flask.__version__)"
python -c "import jinja2; print(jinja2.__version__)"
python -c "import yaml; print(yaml.__version__)"
```

5. **Environment Variables**
```bash
# Set Flask app
export FLASK_APP=app.py
export FLASK_ENV=development

# Or in .env file
echo "FLASK_APP=app.py" >> .env
echo "FLASK_ENV=development" >> .env
```

### Issue: Port Already in Use

#### Symptoms
```
OSError: [Errno 98] Address already in use
```

#### Solutions

1. **Find Process Using Port**
```bash
# Linux/Mac
sudo lsof -i :5000
sudo netstat -tulpn | grep :5000

# Windows
netstat -ano | findstr :5000
```

2. **Kill Process**
```bash
# Linux/Mac
sudo kill -9 <PID>

# Windows
taskkill /PID <PID> /F
```

3. **Use Different Port**
```python
# In app.py
app.run(port=5001)

# Or via environment
export FLASK_PORT=5001
```

### Issue: Permission Denied

#### Symptoms
- Cannot write to generated_projects directory
- File permission errors
- OSError: [Errno 13] Permission denied

#### Solutions

1. **Fix Directory Permissions**
```bash
# Linux/Mac
chmod -R 755 .
chmod -R 777 generated_projects

# Fix ownership
sudo chown -R $USER:$USER .
```

2. **Run with Proper User**
```bash
# Don't run as root
whoami  # Should not be root

# Create dedicated user
sudo useradd -m apiuser
sudo su - apiuser
```

## Installation Problems

### Issue: pip install fails

#### Symptoms
- Package installation errors
- Dependency conflicts
- SSL certificate errors

#### Solutions

1. **Update pip**
```bash
python -m pip install --upgrade pip
```

2. **Clear pip Cache**
```bash
pip cache purge
```

3. **Install with No Cache**
```bash
pip install --no-cache-dir -r requirements.txt
```

4. **SSL Issues**
```bash
# Temporary fix (not recommended for production)
pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org -r requirements.txt

# Better solution - update certificates
pip install --upgrade certifi
```

5. **Use Different Index**
```bash
pip install -i https://pypi.python.org/simple/ -r requirements.txt
```

### Issue: Missing System Dependencies

#### Symptoms
- Error installing Python packages
- Missing compiler
- Library not found

#### Solutions

1. **Ubuntu/Debian**
```bash
sudo apt-get update
sudo apt-get install -y \
    python3-dev \
    build-essential \
    libssl-dev \
    libffi-dev \
    libxml2-dev \
    libxslt1-dev \
    zlib1g-dev
```

2. **CentOS/RHEL**
```bash
sudo yum install -y \
    python3-devel \
    gcc \
    openssl-devel \
    libffi-devel \
    libxml2-devel \
    libxslt-devel \
    zlib-devel
```

3. **macOS**
```bash
# Install Xcode Command Line Tools
xcode-select --install

# Using Homebrew
brew install python3
```

## Runtime Errors

### Issue: 500 Internal Server Error

#### Symptoms
- Generic 500 error page
- No detailed error message
- Application crashes

#### Debugging Steps

1. **Enable Debug Mode**
```python
# Temporarily in app.py
app.config['DEBUG'] = True
app.config['PROPAGATE_EXCEPTIONS'] = True
```

2. **Check Logs**
```bash
# Application logs
tail -f app.log

# Flask logs
flask run --debug 2>&1 | tee debug.log

# Python traceback
python app.py 2>&1 | tee error.log
```

3. **Add Error Handler**
```python
@app.errorhandler(Exception)
def handle_exception(e):
    app.logger.error(f"Unhandled exception: {e}", exc_info=True)
    return jsonify({
        'error': str(e),
        'type': type(e).__name__
    }), 500
```

### Issue: JSON Decode Error

#### Symptoms
```
json.decoder.JSONDecodeError: Expecting value
```

#### Solutions

1. **Validate JSON**
```python
# Test JSON validity
import json

try:
    with open('file.json', 'r') as f:
        data = json.load(f)
    print("Valid JSON")
except json.JSONDecodeError as e:
    print(f"Invalid JSON: {e}")
```

2. **Check Content-Type**
```python
# In request handler
if request.content_type != 'application/json':
    return jsonify({'error': 'Content-Type must be application/json'}), 400
```

3. **Handle Empty Body**
```python
data = request.get_json(force=True, silent=True)
if not data:
    return jsonify({'error': 'No JSON data provided'}), 400
```

## Generation Failures

### Issue: Spring Initializr Timeout

#### Symptoms
- Request timeout after 30 seconds
- Connection to start.spring.io failed
- 503 Service Unavailable

#### Solutions

1. **Increase Timeout**
```python
# In services/initializr_service.py
TIMEOUT = 60  # Increase from 30
```

2. **Check Connectivity**
```bash
# Test connection
curl -I https://start.spring.io
ping start.spring.io

# Test with wget
wget --spider https://start.spring.io
```

3. **Use Retry Logic**
```python
# Already implemented, but can adjust
RETRY_COUNT = 5  # Increase retries
RETRY_DELAY_BASE = 2  # Increase delay
```

4. **Check Proxy Settings**
```bash
# Set proxy if needed
export HTTP_PROXY=http://proxy.server:port
export HTTPS_PROXY=http://proxy.server:port
```

### Issue: Generated Code Compilation Errors

#### Symptoms
- Generated Java code doesn't compile
- Missing imports
- Syntax errors

#### Solutions

1. **Verify Java Version**
```bash
java -version
# Should match configured version
```

2. **Check Template Syntax**
```python
# Validate template rendering
from jinja2 import Template

template = Template(open('templates/java/controller.java.j2').read())
rendered = template.render(context)
print(rendered)
```

3. **Validate Generated Code**
```bash
# Try to compile manually
cd generated_project
./gradlew build

# Check for errors
./gradlew build --stacktrace
```

## File Upload Issues

### Issue: File Upload Fails

#### Symptoms
- "No file provided" error
- File too large error
- Invalid file type

#### Solutions

1. **Check File Size**
```python
# Increase limit in app.py
app.config['MAX_CONTENT_LENGTH'] = 20 * 1024 * 1024  # 20MB
```

2. **Verify File Extension**
```python
ALLOWED_EXTENSIONS = {'json', 'yaml', 'yml'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
```

3. **Debug File Upload**
```javascript
// In browser console
const input = document.querySelector('input[type="file"]');
input.addEventListener('change', (e) => {
    const file = e.target.files[0];
    console.log('File:', file);
    console.log('Size:', file.size);
    console.log('Type:', file.type);
});
```

### Issue: Drag and Drop Not Working

#### Symptoms
- Files not accepted when dropped
- No visual feedback
- JavaScript errors

#### Solutions

1. **Check Browser Console**
```javascript
// Enable verbose logging
window.addEventListener('dragover', (e) => {
    console.log('Drag over:', e);
    e.preventDefault();
});

window.addEventListener('drop', (e) => {
    console.log('Drop:', e);
    e.preventDefault();
});
```

2. **Verify Event Handlers**
```javascript
// Check if handlers are attached
const dropZone = document.getElementById('drop-zone');
console.log('Drop zone:', dropZone);
console.log('Listeners:', getEventListeners(dropZone));
```

## Parser Errors

### Issue: OpenAPI Parsing Fails

#### Symptoms
- "Invalid specification format"
- "Unknown specification version"
- Parser exceptions

#### Solutions

1. **Validate OpenAPI Spec**
```bash
# Online validator
# https://editor.swagger.io/

# Or use Python
pip install openapi-spec-validator
openapi-spec-validator spec.yaml
```

2. **Check Version**
```yaml
# OpenAPI 3.0
openapi: 3.0.0  # Required

# Swagger 2.0
swagger: "2.0"  # Required
```

3. **Debug Parser**
```python
# Add logging to parser
import logging
logging.basicConfig(level=logging.DEBUG)

parser = OpenAPIParserService()
try:
    result = parser.parse_file('spec.yaml')
except Exception as e:
    logging.error(f"Parse error: {e}", exc_info=True)
```

### Issue: YAML Parsing Errors

#### Symptoms
```
yaml.scanner.ScannerError: mapping values are not allowed here
```

#### Solutions

1. **Fix Indentation**
```yaml
# Wrong
paths:
/users:  # Missing indentation
  get:

# Correct
paths:
  /users:
    get:
```

2. **Validate YAML**
```python
import yaml

try:
    with open('file.yaml', 'r') as f:
        data = yaml.safe_load(f)
    print("Valid YAML")
except yaml.YAMLError as e:
    print(f"YAML Error: {e}")
    if hasattr(e, 'problem_mark'):
        mark = e.problem_mark
        print(f"Error at line {mark.line + 1}, column {mark.column + 1}")
```

## Template Errors

### Issue: Template Not Found

#### Symptoms
```
jinja2.exceptions.TemplateNotFound: template.java.j2
```

#### Solutions

1. **Check Template Path**
```python
import os
template_dir = os.path.join(os.path.dirname(__file__), 'templates', 'java')
print(f"Template directory: {template_dir}")
print(f"Files: {os.listdir(template_dir)}")
```

2. **Fix Template Loader**
```python
from jinja2 import Environment, FileSystemLoader

# Absolute path
template_dir = os.path.abspath('templates/java')
env = Environment(loader=FileSystemLoader(template_dir))
```

### Issue: Template Rendering Errors

#### Symptoms
- Undefined variable errors
- Syntax errors in generated code

#### Solutions

1. **Check Context Variables**
```python
# Debug template context
context = {
    'package_name': 'com.example',
    'class_name': 'User',
    'endpoints': []
}
print(f"Context: {context}")

# Test render
template = env.get_template('controller.java.j2')
result = template.render(context)
```

2. **Add Default Values**
```jinja2
{# Use default filter #}
{{ variable_name | default('default_value') }}

{# Check if defined #}
{% if variable_name is defined %}
    {{ variable_name }}
{% endif %}
```

## Network Issues

### Issue: Connection Refused

#### Symptoms
- Cannot connect to localhost:5000
- ERR_CONNECTION_REFUSED

#### Solutions

1. **Check if App is Running**
```bash
ps aux | grep python
ps aux | grep flask
```

2. **Verify Binding Address**
```python
# Bind to all interfaces
app.run(host='0.0.0.0', port=5000)
```

3. **Check Firewall**
```bash
# Ubuntu
sudo ufw status
sudo ufw allow 5000

# CentOS
sudo firewall-cmd --zone=public --add-port=5000/tcp --permanent
sudo firewall-cmd --reload
```

### Issue: CORS Errors

#### Symptoms
- "Access-Control-Allow-Origin" errors
- Blocked by CORS policy

#### Solutions

1. **Enable CORS**
```python
from flask_cors import CORS

CORS(app)

# Or specific origins
CORS(app, origins=['http://localhost:3000'])
```

2. **Manual CORS Headers**
```python
@app.after_request
def after_request(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    return response
```

## Performance Problems

### Issue: Slow Generation

#### Symptoms
- Generation takes too long
- Timeouts
- High CPU usage

#### Solutions

1. **Profile Code**
```python
import cProfile
import pstats

profiler = cProfile.Profile()
profiler.enable()

# Code to profile
generate_project(config)

profiler.disable()
stats = pstats.Stats(profiler)
stats.sort_stats('cumulative')
stats.print_stats(10)
```

2. **Optimize Templates**
```python
# Cache compiled templates
from jinja2 import Environment, FileSystemLoader

env = Environment(
    loader=FileSystemLoader('templates'),
    cache_size=100
)
```

3. **Use Caching**
```python
from functools import lru_cache

@lru_cache(maxsize=100)
def expensive_operation(param):
    # Cached operation
    return result
```

### Issue: High Memory Usage

#### Symptoms
- Memory leaks
- Out of memory errors
- Server crashes

#### Solutions

1. **Monitor Memory**
```python
import psutil
import os

process = psutil.Process(os.getpid())
print(f"Memory usage: {process.memory_info().rss / 1024 / 1024:.2f} MB")
```

2. **Cleanup Resources**
```python
# Clean up after generation
import gc
import shutil

def cleanup():
    # Remove temporary files
    shutil.rmtree('temp', ignore_errors=True)

    # Force garbage collection
    gc.collect()
```

## Debugging Techniques

### Enable Verbose Logging

```python
import logging

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('debug.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)
```

### Use Python Debugger

```python
import pdb

def problematic_function():
    pdb.set_trace()  # Breakpoint
    # Code to debug
```

### Remote Debugging with VS Code

```json
// .vscode/launch.json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Python: Flask",
      "type": "python",
      "request": "launch",
      "module": "flask",
      "env": {
        "FLASK_APP": "app.py",
        "FLASK_ENV": "development"
      },
      "args": ["run", "--no-debugger", "--no-reload"],
      "jinja": true
    }
  ]
}
```

### HTTP Request Debugging

```python
import requests
import logging

# Enable request debugging
import http.client as http_client
http_client.HTTPConnection.debuglevel = 1

logging.basicConfig()
logging.getLogger().setLevel(logging.DEBUG)
requests_log = logging.getLogger("requests.packages.urllib3")
requests_log.setLevel(logging.DEBUG)
requests_log.propagate = True
```

### Memory Profiling

```python
from memory_profiler import profile

@profile
def memory_intensive_function():
    # Function to profile
    pass

# Run with: python -m memory_profiler app.py
```

### Performance Monitoring

```python
import time
from functools import wraps

def timeit(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end - start:.2f} seconds")
        return result
    return wrapper

@timeit
def slow_function():
    time.sleep(1)
```

## Getting Help

### Check Logs

```bash
# Application logs
tail -f app.log
tail -f generated_projects/*.log

# System logs
journalctl -u api-generator -f
dmesg | tail

# Web server logs
tail -f /var/log/nginx/error.log
tail -f /var/log/apache2/error.log
```

### Gather Information

```bash
# System information
uname -a
python --version
pip list

# Disk space
df -h

# Memory
free -m

# Network
netstat -tulpn
```

### Report Issues

When reporting issues, include:
1. Error message and stack trace
2. Steps to reproduce
3. Environment details (OS, Python version)
4. Configuration files
5. Log files
6. Sample input that causes the error

### Community Resources

- GitHub Issues: Report bugs and request features
- Stack Overflow: Tag with `spring-boot-api-generator`
- Discord/Slack: Real-time help from community

---

**Last Updated:** January 2024 | **Version:** 2.0.0