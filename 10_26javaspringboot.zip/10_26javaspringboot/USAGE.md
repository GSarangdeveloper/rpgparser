# Usage Guide - Spring Boot API Code Generator

## Quick Start

### Option 1: Using the Web Interface (Recommended)

1. **Start the application**:
   ```bash
   # On Linux/Mac
   ./run.sh

   # On Windows
   run.bat

   # Or manually
   pip install -r requirements.txt
   python app.py
   ```

2. **Open your browser**: Navigate to `http://localhost:5000`

3. **Fill the form**: Complete all sections of the form

4. **Generate**: Click "Generate Project" button

5. **Download**: Click the download link to get your ZIP file

6. **Run your project**:
   ```bash
   cd your-project-name
   ./gradlew bootRun
   ```

### Option 2: Using the API Directly

You can also use the REST API programmatically:

```bash
curl -X POST http://localhost:5000/api/generate \
  -H "Content-Type: application/json" \
  -d @example_config.json \
  -o response.json
```

## Form Fields Explanation

### Project Configuration

| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| Project Name | Yes | Name of your project | user-management-api |
| Description | No | Project description | User Management REST API |
| Group ID | Yes | Maven group ID (Java package format) | com.example |
| Artifact ID | Yes | Maven artifact ID (lowercase-hyphen) | user-management-api |
| Package Name | Yes | Base Java package | com.example.usermanagement |
| Spring Boot Version | Yes | Spring Boot version to use | 3.2.0 |
| Java Version | Yes | Java version (11, 17, or 21) | 17 |
| Packaging | Yes | JAR or WAR | jar |

### Dependencies

| Option | Description |
|--------|-------------|
| Database | Choose database: None, H2, MySQL, PostgreSQL, MongoDB |
| Spring Security | Add authentication/authorization support |
| OpenAPI Documentation | Add Swagger/OpenAPI documentation (recommended) |
| Caching Support | Add caching capabilities |

### API Specification

#### Base Controller Path
The base URL path for all endpoints (e.g., `/api/v1`)

#### Controller Class Name
The main entity name (e.g., `User` will generate `UserController`)

#### Endpoints
Define each REST endpoint:

**Endpoint Name**: Method name in camelCase (e.g., `getUser`, `createUser`)

**HTTP Method**: GET, POST, PUT, DELETE, or PATCH

**Path**: Endpoint path relative to base path (e.g., `/users/{id}`)
- Use `{paramName}` for path variables

**Description**: Optional description of what the endpoint does

**Response Type**:
- Single Object: Returns one entity
- List: Returns array of entities
- Void: No response body (e.g., DELETE)

**Response DTO Name**: Name of the response class (e.g., `UserResponse`)

### Generation Options

| Option | Description | Default |
|--------|-------------|---------|
| Include Service Layer | Generate service interfaces and implementations | Yes |
| Include Exception Handling | Generate global exception handler | Yes |
| Include Validation | Add validation annotations to DTOs | Yes |
| Include Logging | Add logging statements | Yes |

## Example Workflows

### Example 1: Simple CRUD API

**Scenario**: Create a basic User management API

1. **Project Configuration**:
   - Project Name: `user-api`
   - Group ID: `com.mycompany`
   - Artifact ID: `user-api`
   - Package Name: `com.mycompany.userapi`

2. **Dependencies**:
   - Database: H2
   - Documentation: Yes

3. **API Specification**:
   - Base Path: `/api/v1`
   - Controller: `User`
   - Endpoints:
     - GET `/users/{id}` → `getUser`
     - GET `/users` → `getAllUsers`
     - POST `/users` → `createUser`
     - PUT `/users/{id}` → `updateUser`
     - DELETE `/users/{id}` → `deleteUser`

### Example 2: Product Catalog API

**Scenario**: Create a product catalog with categories

1. **Project Configuration**:
   - Project Name: `product-catalog`
   - Group ID: `com.shop`
   - Package Name: `com.shop.catalog`

2. **Dependencies**:
   - Database: MySQL
   - Security: Yes
   - Documentation: Yes
   - Caching: Yes

3. **API Specification**:
   - Base Path: `/api/v1`
   - Controller: `Product`
   - Endpoints:
     - GET `/products` → `getAllProducts`
     - GET `/products/{id}` → `getProduct`
     - GET `/products/category/{categoryId}` → `getProductsByCategory`
     - POST `/products` → `createProduct`
     - PUT `/products/{id}` → `updateProduct`
     - DELETE `/products/{id}` → `deleteProduct`

## Generated Code Structure

Your downloaded project will have this structure:

```
your-project/
├── build.gradle                # Gradle build configuration
├── settings.gradle             # Gradle settings
├── gradlew                     # Gradle wrapper (Unix)
├── gradlew.bat                 # Gradle wrapper (Windows)
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/example/yourproject/
│   │   │       ├── YourProjectApplication.java
│   │   │       ├── controller/
│   │   │       │   └── YourController.java
│   │   │       ├── service/
│   │   │       │   ├── YourService.java
│   │   │       │   └── impl/
│   │   │       │       └── YourServiceImpl.java
│   │   │       ├── dto/
│   │   │       │   ├── request/
│   │   │       │   │   └── CreateYourRequest.java
│   │   │       │   └── response/
│   │   │       │       └── YourResponse.java
│   │   │       └── exception/
│   │   │           ├── GlobalExceptionHandler.java
│   │   │           └── ErrorResponse.java
│   │   └── resources/
│   │       └── application.properties
│   └── test/
│       └── java/
│           └── com/example/yourproject/
│               └── YourProjectApplicationTests.java
```

## Running Your Generated Project

1. **Extract the ZIP file**:
   ```bash
   unzip your-project.zip
   cd your-project
   ```

2. **Run the application**:
   ```bash
   ./gradlew bootRun
   ```

3. **Access the API**:
   - Base URL: `http://localhost:8080`
   - Your endpoints: `http://localhost:8080/api/v1/...`
   - Swagger UI (if enabled): `http://localhost:8080/swagger-ui.html`

4. **Build JAR file**:
   ```bash
   ./gradlew build
   ```
   The JAR will be in `build/libs/`

## Testing Your API

### Using curl

```bash
# GET request
curl http://localhost:8080/api/v1/users/1

# POST request
curl -X POST http://localhost:8080/api/v1/users \
  -H "Content-Type: application/json" \
  -d '{"username":"john","email":"john@example.com","password":"password123"}'

# PUT request
curl -X PUT http://localhost:8080/api/v1/users/1 \
  -H "Content-Type: application/json" \
  -d '{"username":"john_updated","email":"john.updated@example.com"}'

# DELETE request
curl -X DELETE http://localhost:8080/api/v1/users/1
```

### Using Swagger UI

If you enabled OpenAPI documentation:
1. Navigate to: `http://localhost:8080/swagger-ui.html`
2. Browse your API endpoints
3. Try out endpoints directly from the UI

## Customizing Generated Code

The generated code is meant to be a starting point. You'll need to:

1. **Implement business logic**:
   - Open service implementation files
   - Replace `// TODO: Implement business logic` with your code

2. **Add database entities** (if using JPA):
   - Create entity classes in a `model` or `entity` package
   - Update service implementations to use repositories

3. **Configure database**:
   - Edit `application.properties`
   - Add database connection details

4. **Add more dependencies**:
   - Edit `build.gradle`
   - Add any additional dependencies you need

## Preview Feature

Before generating the full project, you can preview the generated code:

1. Fill out the form
2. Click "Preview Code" button
3. Review the generated files
4. Make adjustments if needed
5. Generate the full project

## Tips and Best Practices

### Naming Conventions

- **Controller Class Name**: Use singular entity name (e.g., `User`, not `Users`)
- **Endpoint Names**: Use camelCase (e.g., `getUser`, `createProduct`)
- **Path Variables**: Use `{id}` format (e.g., `/users/{id}`)
- **Package Names**: Use lowercase with dots (e.g., `com.example.myapp`)

### Endpoint Design

- Use plural nouns for collections: `/users`, `/products`
- Use HTTP methods correctly:
  - GET: Retrieve data
  - POST: Create new resource
  - PUT: Update entire resource
  - PATCH: Partial update
  - DELETE: Remove resource

### Response Types

- **Single Object**: For GET by ID, POST, PUT operations
- **List**: For GET all operations
- **Void**: For DELETE operations (returns 204 No Content)

### Validation

When defining request DTOs, the generator supports:
- `@NotNull`: Field cannot be null
- `@NotBlank`: String cannot be blank
- `@Email`: Must be valid email format
- `@Size(min, max)`: String or collection size
- `@Min`, `@Max`: Number range validation

## Troubleshooting

### Common Issues

**Issue**: "Error connecting to Spring Initializr"
- **Solution**: Check your internet connection
- Verify `https://start.spring.io` is accessible

**Issue**: "Invalid package name"
- **Solution**: Use Java package format (e.g., `com.example.myapp`)
- Only lowercase letters, numbers, and dots

**Issue**: "Generated project won't run"
- **Solution**: Check Java version matches your system
- Ensure `JAVA_HOME` is set correctly

**Issue**: "Port 8080 already in use"
- **Solution**: Change port in `application.properties`:
  ```properties
  server.port=8081
  ```

## Advanced Features

### Custom Templates

You can modify the Jinja2 templates in `templates/java/` to customize code generation:
- `controller.java.j2`: Controller template
- `service.java.j2`: Service interface template
- `service_impl.java.j2`: Service implementation template
- `dto.java.j2`: DTO template
- `exception_handler.java.j2`: Exception handler template

After modifying templates, restart the Flask application.

## Next Steps

After generating your project:

1. Implement business logic in service classes
2. Add database entities and repositories
3. Configure database connection
4. Add authentication/authorization
5. Write unit and integration tests
6. Configure logging
7. Add API documentation
8. Set up CI/CD pipeline

## Support

For issues or questions:
- Check the README.md
- Review the specification: SPRING_BOOT_API_GENERATOR_SPEC.md
- Examine example_config.json for API usage
