# Enhanced Features - Detailed Request/Response Parameter Configuration

## Overview

The **enhanced version** of the Spring Boot API Code Generator now supports detailed configuration of:
- ✅ Request Parameters (PATH, QUERY, HEADER)
- ✅ Request Body with custom fields and validation
- ✅ Response fields with custom types
- ✅ Validation annotations (@NotNull, @NotBlank, @Email, @Size, @Pattern)

## Accessing the Enhanced Interface

### Enhanced Version (Full Features)
**URL:** `http://localhost:5000/`

This is the **default** version with all advanced features.

### Simple Version (Basic Features)
**URL:** `http://localhost:5000/simple`

Use this for quick project generation with minimal configuration.

---

## New Features in Enhanced Version

### 1. Request Parameters Section

For each endpoint, you can now add multiple request parameters with:

#### Configuration Options:
- **Parameter Name**: The name of the parameter (e.g., `id`, `page`, `sort`)
- **Type**: Data type (String, Integer, Long, Boolean, Double, LocalDate, LocalDateTime, BigDecimal)
- **Location**: Where the parameter comes from
  - **PATH**: Path variable (e.g., `/users/{id}`)
  - **QUERY**: Query parameter (e.g., `?page=1&size=10`)
  - **HEADER**: HTTP header (e.g., `X-Auth-Token`)
- **Required**: Whether the parameter is mandatory
- **Default Value**: Default value if not provided (for optional parameters)
- **Description**: Documentation for the parameter

#### Example: GET /users/{id}
```
Parameter 1:
- Name: id
- Type: Long
- Location: PATH
- Required: ✓
- Description: User ID
```

#### Example: GET /users with pagination
```
Parameter 1:
- Name: page
- Type: Integer
- Location: QUERY
- Required: ☐
- Default Value: 0
- Description: Page number

Parameter 2:
- Name: size
- Type: Integer
- Location: QUERY
- Required: ☐
- Default Value: 10
- Description: Page size
```

### 2. Request Body Configuration

For POST/PUT/PATCH endpoints, you can now define detailed request bodies:

#### Configuration Options:
- **Has Request Body**: Checkbox to enable/disable request body
- **DTO Class Name**: Name of the request DTO class (auto-generated if empty)
- **Required**: Whether the request body is mandatory
- **Fields**: List of fields in the request body

#### Field Configuration:
Each field in the request body can have:
- **Field Name**: Name of the field (e.g., `username`, `email`, `password`)
- **Type**: Data type
- **Required**: Whether the field is required
- **Description**: Field documentation

#### Validation Annotations:
For each field, you can add:
- **@NotNull**: Field cannot be null
- **@NotBlank**: String cannot be blank (for String fields)
- **@Email**: Must be a valid email format
- **@Size Min/Max**: String length or collection size constraints
- **@Pattern**: Regular expression pattern matching

#### Example: Create User Request Body
```
DTO Class Name: CreateUserRequest
Required: ✓

Field 1:
- Name: username
- Type: String
- Required: ✓
- Validations:
  ✓ @NotBlank
  ✓ @Size Min: 3, Max: 50

Field 2:
- Name: email
- Type: String
- Required: ✓
- Validations:
  ✓ @NotBlank
  ✓ @Email

Field 3:
- Name: password
- Type: String
- Required: ✓
- Validations:
  ✓ @NotBlank
  ✓ @Size Min: 8, Max: 100

Field 4:
- Name: age
- Type: Integer
- Required: ☐
- Validations:
  ✓ @Size Min: 18, Max: 120
```

### 3. Response Configuration

Define detailed response structures:

#### Configuration Options:
- **Response Type**:
  - **Single Object**: Returns one entity
  - **List**: Returns array of entities
  - **Void**: No response body (e.g., DELETE)
  - **Paginated**: Paginated response
- **Response DTO Name**: Name of the response DTO class
- **HTTP Status Code**: 200, 201, 204, 400, 404, etc.
- **Response Fields**: List of fields in the response

#### Response Field Configuration:
- **Field Name**: Name of the field
- **Type**: Data type
- **Description**: Field documentation

#### Example: User Response
```
Response Type: Single Object
Response DTO Name: UserResponse
HTTP Status: 200 OK

Field 1:
- Name: id
- Type: Long
- Description: User ID

Field 2:
- Name: username
- Type: String
- Description: Username

Field 3:
- Name: email
- Type: String
- Description: Email address

Field 4:
- Name: createdAt
- Type: LocalDateTime
- Description: Account creation timestamp

Field 5:
- Name: updatedAt
- Type: LocalDateTime
- Description: Last update timestamp
```

---

## Generated Code Examples

### Example 1: GET with Path Variable

**Configuration:**
```
Endpoint: getUser
Method: GET
Path: /users/{id}

Request Parameter:
- Name: id
- Type: Long
- Location: PATH
- Required: ✓
```

**Generated Controller Method:**
```java
@GetMapping("/users/{id}")
public ResponseEntity<UserResponse> getUser(@PathVariable Long id) {
    log.info("getUser called with parameters: id");
    UserResponse result = userService.getUser(id);
    return ResponseEntity.status(HttpStatus.OK).body(result);
}
```

### Example 2: POST with Request Body and Validation

**Configuration:**
```
Endpoint: createUser
Method: POST
Path: /users

Request Body:
- Class: CreateUserRequest
- Required: ✓

Fields:
1. username (String, Required)
   - @NotBlank
   - @Size(min=3, max=50)
2. email (String, Required)
   - @NotBlank
   - @Email
```

**Generated Request DTO:**
```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateUserRequest {

    @NotBlank(message = "username cannot be blank")
    @Size(min = 3, max = 50, message = "username size must be between 3 and 50")
    private String username;

    @NotBlank(message = "email cannot be blank")
    @Email(message = "email must be a valid email")
    private String email;
}
```

**Generated Controller Method:**
```java
@PostMapping("/users")
public ResponseEntity<UserResponse> createUser(@Valid @RequestBody CreateUserRequest createUserRequest) {
    log.info("createUser called with parameters: createUserRequest");
    UserResponse result = userService.createUser(createUserRequest);
    return ResponseEntity.status(HttpStatus.CREATED).body(result);
}
```

### Example 3: GET with Query Parameters

**Configuration:**
```
Endpoint: searchUsers
Method: GET
Path: /users/search

Request Parameters:
1. name (String, QUERY, Optional)
   - Default: ""
2. page (Integer, QUERY, Optional)
   - Default: 0
3. size (Integer, QUERY, Optional)
   - Default: 10
```

**Generated Controller Method:**
```java
@GetMapping("/users/search")
public ResponseEntity<List<UserResponse>> searchUsers(
    @RequestParam(value = "name", required = false, defaultValue = "") String name,
    @RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
    @RequestParam(value = "size", required = false, defaultValue = "10") Integer size
) {
    log.info("searchUsers called with parameters: name, page, size");
    List<UserResponse> result = userService.searchUsers(name, page, size);
    return ResponseEntity.status(HttpStatus.OK).body(result);
}
```

---

## Complete Example Workflow

### Step 1: Configure User Management API

**Project Configuration:**
- Project Name: user-management-api
- Package Name: com.example.usermanagement

**Endpoint 1: Get User by ID**
- Name: `getUser`
- Method: GET
- Path: `/users/{id}`
- Request Parameter: id (Long, PATH, Required)
- Response: Single Object, UserResponse

**Endpoint 2: Create User**
- Name: `createUser`
- Method: POST
- Path: `/users`
- Request Body: CreateUserRequest
  - username (String, @NotBlank, @Size(3-50))
  - email (String, @NotBlank, @Email)
  - password (String, @NotBlank, @Size(8-100))
- Response: Single Object, UserResponse, 201

**Endpoint 3: Update User**
- Name: `updateUser`
- Method: PUT
- Path: `/users/{id}`
- Request Parameters:
  - id (Long, PATH, Required)
- Request Body: UpdateUserRequest
  - username (String, Optional, @Size(3-50))
  - email (String, Optional, @Email)
- Response: Single Object, UserResponse

**Endpoint 4: Delete User**
- Name: `deleteUser`
- Method: DELETE
- Path: `/users/{id}`
- Request Parameter: id (Long, PATH, Required)
- Response: Void, 204

**Endpoint 5: Search Users**
- Name: `searchUsers`
- Method: GET
- Path: `/users/search`
- Request Parameters:
  - name (String, QUERY, Optional, default="")
  - page (Integer, QUERY, Optional, default=0)
  - size (Integer, QUERY, Optional, default=10)
- Response: List, UserResponse

### Step 2: Generate Project

Click "Generate Project" and download the ZIP file.

### Step 3: Review Generated Code

The generated project will include:

1. **UserController.java** with all 5 endpoints
2. **CreateUserRequest.java** with validation annotations
3. **UpdateUserRequest.java** with validation annotations
4. **UserResponse.java** with all response fields
5. **UserService.java** interface
6. **UserServiceImpl.java** implementation
7. **GlobalExceptionHandler.java** for validation errors
8. **ErrorResponse.java** for standardized error responses

---

## Tips for Using Enhanced Features

### 1. Path Variables
- Use `{paramName}` in the path (e.g., `/users/{id}`)
- Add corresponding PATH parameter with matching name
- Always mark as Required

### 2. Query Parameters
- Good for filters, pagination, sorting
- Can be optional with default values
- Use descriptive names (e.g., `page`, `size`, `sort`, `filter`)

### 3. Request Body Validation
- Always validate user input
- Use @NotBlank for required strings
- Use @Email for email fields
- Use @Size for length constraints
- Use @Pattern for complex validation (e.g., phone numbers)

### 4. Response Fields
- Include only necessary fields in responses
- Don't expose sensitive data (e.g., passwords)
- Use consistent field naming across DTOs
- Include timestamps (createdAt, updatedAt) for audit trails

### 5. HTTP Status Codes
- 200 OK: Successful GET, PUT
- 201 Created: Successful POST
- 204 No Content: Successful DELETE
- 400 Bad Request: Validation errors
- 404 Not Found: Resource not found

---

## Comparison: Simple vs Enhanced

| Feature | Simple Version | Enhanced Version |
|---------|---------------|------------------|
| Request Parameters | ❌ | ✅ Full support (PATH, QUERY, HEADER) |
| Request Body Fields | ❌ | ✅ Custom fields with validation |
| Response Fields | ❌ | ✅ Custom response structure |
| Validation Annotations | ❌ | ✅ Full validation support |
| Field Descriptions | ❌ | ✅ Documentation support |
| Default Values | ❌ | ✅ For optional parameters |
| Data Type Selection | ❌ | ✅ 8+ data types |

---

## Browser Access

**Enhanced Version (Recommended):**
```
http://localhost:5000/
```

**Simple Version:**
```
http://localhost:5000/simple
```

---

## Next Steps

1. Start the application: `python app.py`
2. Open `http://localhost:5000` in your browser
3. Configure your project with detailed parameters
4. Preview generated code
5. Generate and download project
6. Run: `./gradlew bootRun`
7. Test your API endpoints!

The enhanced version gives you **complete control** over your API structure, making it perfect for production-ready applications with proper validation and documentation.
