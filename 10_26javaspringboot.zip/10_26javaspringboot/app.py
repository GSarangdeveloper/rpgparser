from flask import Flask, render_template, request, jsonify, send_file, Response
from services.initializr_service import InitializrService
from services.code_generator_service import CodeGeneratorService
from services.project_modifier_service import ProjectModifierService
from services.validation_service import ValidationService
from services.openapi_parser_service import OpenAPIParserService
from services.postman_parser_service import PostmanParserService
from services.error_handler import (
    ErrorHandler, APIGeneratorError, ValidationError,
    ParsingError, GenerationError, validate_project_configuration,
    validate_api_endpoint, with_error_handling
)
import os
import uuid
import json
import time
import tempfile
from datetime import datetime
from threading import Thread
from queue import Queue
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Services
initializr_service = InitializrService()
code_generator_service = CodeGeneratorService()
project_modifier_service = ProjectModifierService()
validation_service = ValidationService()
openapi_parser_service = OpenAPIParserService()
postman_parser_service = PostmanParserService()

# Configuration
GENERATED_PROJECTS_DIR = 'generated_projects'
os.makedirs(GENERATED_PROJECTS_DIR, exist_ok=True)

# Progress tracking for SSE
progress_queues = {}


@app.route('/')
def index():
    """Render the enhanced main page with full request/response parameter support"""
    return render_template('index_enhanced.html')


@app.route('/simple')
def simple_index():
    """Render the simple version (basic form)"""
    return render_template('index.html')


@app.route('/v2')
def index_v2():
    """Render the new version 2 UI with file upload"""
    return render_template('index_v2.html')


# API v1 endpoints as per specification
@app.route('/api/v1/generate/preview', methods=['POST'])
def preview_code_v1():
    """Preview generated code without creating project - API v1"""
    try:
        data = request.json

        # Validate input using ValidationService
        validation_result = validation_service.validate(data)

        if not validation_result['valid']:
            return jsonify({
                'success': False,
                'errors': validation_result['errors'],
                'warnings': validation_result['warnings']
            }), 400

        # Use sanitized data
        sanitized_data = validation_result['sanitized_data']

        # Generate only the code
        generated_code = code_generator_service.generate_code(
            sanitized_data.get('projectConfiguration'),
            sanitized_data.get('apiSpecification'),
            sanitized_data.get('generationOptions', {})
        )

        response = jsonify({
            'success': True,
            'files': generated_code,
            'warnings': validation_result.get('warnings', [])
        })

        # Add custom headers
        response.headers['X-Build-Tool'] = 'gradle'
        response.headers['X-API-Version'] = '1.0'

        return response

    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'E500',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
        }), 500


@app.route('/api/v1/generate/project', methods=['POST'])
def generate_project_v1():
    """Main endpoint to generate Spring Boot project - API v1"""
    try:
        data = request.json

        # Validate input using ValidationService
        validation_result = validation_service.validate(data)

        if not validation_result['valid']:
            return jsonify({
                'success': False,
                'errors': validation_result['errors'],
                'warnings': validation_result['warnings']
            }), 400

        # Use sanitized data
        sanitized_data = validation_result['sanitized_data']

        # Generate unique project ID
        project_id = str(uuid.uuid4())

        # Create progress queue for SSE
        progress_queues[project_id] = Queue()

        # Step 1: Get base project from Spring Initializr
        progress_queues[project_id].put({
            'step': 1,
            'message': 'Calling Spring Initializr API...',
            'progress': 20
        })

        base_zip_path = initializr_service.generate_base_project(
            sanitized_data.get('projectConfiguration'),
            sanitized_data.get('dependencyConfiguration')
        )

        if not base_zip_path:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'E501',
                    'message': 'Failed to generate base project from Spring Initializr',
                    'timestamp': datetime.utcnow().isoformat()
                }
            }), 500

        progress_queues[project_id].put({
            'step': 2,
            'message': 'Generating business code from templates...',
            'progress': 50
        })

        # Step 2: Generate business code
        generated_code = code_generator_service.generate_code(
            sanitized_data.get('projectConfiguration'),
            sanitized_data.get('apiSpecification'),
            sanitized_data.get('generationOptions', {})
        )

        progress_queues[project_id].put({
            'step': 3,
            'message': 'Injecting code into project structure...',
            'progress': 75
        })

        # Step 3: Inject code into base project
        final_project_path = project_modifier_service.inject_code(
            base_zip_path,
            generated_code,
            sanitized_data.get('projectConfiguration'),
            project_id
        )

        progress_queues[project_id].put({
            'step': 4,
            'message': 'Project generation complete!',
            'progress': 100,
            'complete': True
        })

        response = jsonify({
            'success': True,
            'projectId': project_id,
            'downloadUrl': f'/api/v1/download/{project_id}',
            'generatedFiles': list(generated_code.keys()),
            'warnings': validation_result.get('warnings', []),
            'metadata': {
                'generatedAt': datetime.utcnow().isoformat(),
                'buildTool': 'gradle',
                'springBootVersion': sanitized_data['projectConfiguration']['springBootVersion'],
                'javaVersion': sanitized_data['projectConfiguration']['javaVersion']
            }
        })

        # Add custom headers
        response.headers['X-Build-Tool'] = 'gradle'
        response.headers['X-API-Version'] = '1.0'
        response.headers['X-Project-ID'] = project_id

        return response

    except Exception as e:
        print(f"Error generating project: {str(e)}")
        return jsonify({
            'success': False,
            'error': {
                'code': 'E500',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
        }), 500


@app.route('/api/v1/validate', methods=['POST'])
def validate_configuration():
    """Validate project configuration without generating - API v1"""
    try:
        data = request.json

        # Validate using ValidationService
        validation_result = validation_service.validate(data)

        # Also validate with InitializrService
        initializr_validation = initializr_service.validate_configuration(
            data.get('projectConfiguration', {}),
            data.get('dependencyConfiguration', {})
        )

        # Combine results
        all_errors = validation_result['errors']
        if not initializr_validation['valid']:
            for error in initializr_validation['errors']:
                all_errors.append({
                    'code': 'E100',
                    'field': 'configuration',
                    'message': error
                })

        all_warnings = validation_result['warnings'] + initializr_validation.get('warnings', [])

        response = jsonify({
            'valid': validation_result['valid'] and initializr_validation['valid'],
            'errors': all_errors,
            'warnings': all_warnings,
            'sanitized_data': validation_result.get('sanitized_data')
        })

        response.headers['X-Build-Tool'] = 'gradle'
        response.headers['X-API-Version'] = '1.0'

        return response

    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'E500',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
        }), 500


@app.route('/api/v1/metadata/spring-boot', methods=['GET'])
def get_spring_boot_metadata():
    """Get available Spring Boot versions and dependencies - API v1"""
    try:
        metadata = initializr_service.get_metadata()

        if metadata:
            # Extract relevant information
            response_data = {
                'success': True,
                'springBootVersions': [],
                'javaVersions': [],
                'dependencies': [],
                'buildTool': 'gradle'  # Always Gradle
            }

            # Extract Spring Boot versions
            if '_embedded' in metadata:
                if 'bootVersion' in metadata['_embedded']:
                    for version in metadata['_embedded']['bootVersion']['values']:
                        response_data['springBootVersions'].append({
                            'id': version['id'],
                            'name': version['name'],
                            'default': version.get('default', False)
                        })

                # Extract Java versions
                if 'javaVersion' in metadata['_embedded']:
                    for version in metadata['_embedded']['javaVersion']['values']:
                        response_data['javaVersions'].append({
                            'id': version['id'],
                            'name': version['name']
                        })

                # Extract dependencies
                if 'dependencies' in metadata['_embedded']:
                    for dep in metadata['_embedded']['dependencies']['values']:
                        response_data['dependencies'].append({
                            'id': dep['id'],
                            'name': dep['name'],
                            'description': dep.get('description', '')
                        })

            response = jsonify(response_data)
            response.headers['X-Build-Tool'] = 'gradle'
            response.headers['X-API-Version'] = '1.0'

            return response
        else:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'E502',
                    'message': 'Failed to fetch Spring Boot metadata',
                    'timestamp': datetime.utcnow().isoformat()
                }
            }), 502

    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'E500',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
        }), 500


@app.route('/api/v1/health', methods=['GET'])
def health_check():
    """Health check endpoint - API v1"""
    try:
        # Check if Spring Initializr is reachable
        metadata = initializr_service.get_metadata()
        spring_initializr_status = 'healthy' if metadata else 'unhealthy'

        response = jsonify({
            'status': 'healthy',
            'version': '1.0.0',
            'buildTool': 'gradle',
            'timestamp': datetime.utcnow().isoformat(),
            'services': {
                'springInitializr': spring_initializr_status,
                'codeGenerator': 'healthy',
                'projectModifier': 'healthy',
                'validation': 'healthy'
            }
        })

        response.headers['X-Build-Tool'] = 'gradle'
        response.headers['X-API-Version'] = '1.0'

        return response

    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 503


@app.route('/api/v1/download/<project_id>')
def download_project_v1(project_id):
    """Download generated project - API v1"""
    try:
        file_path = os.path.join(GENERATED_PROJECTS_DIR, f'{project_id}.zip')
        if os.path.exists(file_path):
            response = send_file(
                file_path,
                as_attachment=True,
                download_name=f'spring-boot-gradle-project-{project_id}.zip'
            )
            response.headers['X-Build-Tool'] = 'gradle'
            response.headers['X-API-Version'] = '1.0'
            return response
        return jsonify({
            'success': False,
            'error': {
                'code': 'E404',
                'message': 'Project not found',
                'timestamp': datetime.utcnow().isoformat()
            }
        }), 404
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'E500',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
        }), 500


@app.route('/api/v1/progress/<project_id>')
def progress_stream(project_id):
    """Server-Sent Events endpoint for progress updates"""
    def generate():
        if project_id in progress_queues:
            queue = progress_queues[project_id]
            while True:
                try:
                    # Get progress update from queue
                    progress = queue.get(timeout=30)
                    yield f"data: {json.dumps(progress)}\n\n"

                    # If complete, clean up and exit
                    if progress.get('complete'):
                        del progress_queues[project_id]
                        break
                except:
                    # Timeout - send heartbeat
                    yield f"data: {json.dumps({'heartbeat': True})}\n\n"

    return Response(generate(), mimetype="text/event-stream")


# Legacy endpoints for backward compatibility
@app.route('/api/generate', methods=['POST'])
def generate_project_legacy():
    """Legacy endpoint - redirects to v1"""
    return generate_project_v1()


@app.route('/api/preview', methods=['POST'])
def preview_code_legacy():
    """Legacy endpoint - redirects to v1"""
    return preview_code_v1()


@app.route('/api/download/<project_id>')
def download_project_legacy(project_id):
    """Legacy endpoint - redirects to v1"""
    return download_project_v1(project_id)


# File Upload and Parsing Endpoints
@app.route('/api/v1/upload/specification', methods=['POST'])
def upload_specification():
    """Upload and parse API specification file"""
    try:
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'error': 'No file provided'
            }), 400

        file = request.files['file']

        if file.filename == '':
            return jsonify({
                'success': False,
                'error': 'No file selected'
            }), 400

        # Validate file type
        allowed_extensions = {'json', 'yaml', 'yml'}
        file_extension = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''

        if file_extension not in allowed_extensions:
            return jsonify({
                'success': False,
                'error': f'Invalid file type. Allowed types: {", ".join(allowed_extensions)}'
            }), 400

        # Check file size (5MB limit)
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)

        if file_size > 5 * 1024 * 1024:  # 5MB
            return jsonify({
                'success': False,
                'error': 'File size exceeds 5MB limit'
            }), 400

        # Save file temporarily
        temp_dir = tempfile.gettempdir()
        filename = secure_filename(file.filename)
        temp_path = os.path.join(temp_dir, f"{uuid.uuid4()}_{filename}")

        try:
            file.save(temp_path)

            # Parse the file based on content
            with open(temp_path, 'r') as f:
                content = f.read()

            # Try to detect if it's a Postman collection
            try:
                json_content = json.loads(content) if file_extension == 'json' else None
                if json_content and 'info' in json_content and 'item' in json_content:
                    # Likely a Postman collection
                    parsed_data = postman_parser_service.parse_collection(content)
                    parse_type = 'Postman Collection'
                else:
                    # Try OpenAPI/Swagger parsing
                    parsed_data = openapi_parser_service.parse_file(temp_path)
                    parse_type = 'OpenAPI/Swagger'
            except:
                # Fallback to OpenAPI parser
                parsed_data = openapi_parser_service.parse_file(temp_path)
                parse_type = 'OpenAPI/Swagger'

            # Count endpoints
            endpoint_count = 0
            if 'apiSpecification' in parsed_data:
                endpoint_count = len(parsed_data['apiSpecification'].get('endpoints', []))
            elif 'endpoints' in parsed_data:
                endpoint_count = len(parsed_data.get('endpoints', []))

            return jsonify({
                'success': True,
                'data': parsed_data,
                'message': f'Successfully parsed {endpoint_count} endpoints from {parse_type}',
                'type': parse_type
            })

        except Exception as e:
            return jsonify({
                'success': False,
                'error': f'Failed to parse specification: {str(e)}'
            }), 400

        finally:
            # Clean up temp file
            if os.path.exists(temp_path):
                os.remove(temp_path)

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/v1/parse/specification', methods=['POST'])
def parse_specification():
    """Parse API specification from text content"""
    try:
        data = request.json

        if not data or 'content' not in data:
            return jsonify({
                'success': False,
                'error': 'No content provided'
            }), 400

        content = data['content']
        format = data.get('format', 'openapi-yaml')

        # Map format to parser format
        if 'yaml' in format:
            parser_format = 'yaml'
        else:
            parser_format = 'json'

        try:
            # Parse the content
            parsed_data = openapi_parser_service.parse_content(content, parser_format)

            return jsonify({
                'success': True,
                'data': parsed_data,
                'message': f'Successfully parsed {len(parsed_data.get("endpoints", []))} endpoints'
            })

        except Exception as e:
            return jsonify({
                'success': False,
                'error': f'Failed to parse specification: {str(e)}'
            }), 400

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/v1/import/url', methods=['POST'])
def import_from_url():
    """Import API specification from URL"""
    try:
        data = request.json

        if not data or 'url' not in data:
            return jsonify({
                'success': False,
                'error': 'No URL provided'
            }), 400

        url = data['url']

        try:
            # Fetch content from URL
            import requests
            response = requests.get(url, timeout=10)

            if response.status_code != 200:
                return jsonify({
                    'success': False,
                    'error': f'Failed to fetch URL: HTTP {response.status_code}'
                }), 400

            # Determine format from content type or URL
            content_type = response.headers.get('Content-Type', '')
            if 'yaml' in content_type or url.endswith(('.yaml', '.yml')):
                parser_format = 'yaml'
            else:
                parser_format = 'json'

            # Parse the content
            parsed_data = openapi_parser_service.parse_content(response.text, parser_format)

            return jsonify({
                'success': True,
                'data': parsed_data,
                'message': f'Successfully imported {len(parsed_data.get("endpoints", []))} endpoints'
            })

        except requests.exceptions.Timeout:
            return jsonify({
                'success': False,
                'error': 'Request timeout while fetching URL'
            }), 400
        except requests.exceptions.RequestException as e:
            return jsonify({
                'success': False,
                'error': f'Failed to fetch URL: {str(e)}'
            }), 400
        except Exception as e:
            return jsonify({
                'success': False,
                'error': f'Failed to parse specification: {str(e)}'
            }), 400

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)