# File Upload Feature Guide

## Overview
The Spring Boot API Generator now supports multiple input methods for API specification, including file upload, manual entry, paste content, and URL import. This guide covers the file upload feature and supported formats.

## Supported File Formats

### 1. OpenAPI/Swagger Specifications
- **OpenAPI 3.0** (.yaml, .yml, .json)
- **Swagger 2.0** (.yaml, .yml, .json)

The system automatically detects the specification version and parses accordingly.

### 2. Custom JSON Format
A proprietary JSON format specifically designed for this generator with enhanced configuration options.

### 3. Postman Collections (Coming Soon)
Support for Postman collection v2.1 format is under development.

## How to Use File Upload

### Method 1: Drag and Drop
1. Navigate to the V2 interface at `/v2`
2. Select "Upload File" as your input method
3. Drag your specification file into the drop zone
4. The file will be automatically parsed and validated
5. Review the parsed configuration
6. Click "Generate" to create your Spring Boot project

### Method 2: Browse and Select
1. Click the "Browse" button in the upload area
2. Select your specification file from your file system
3. The file will be uploaded and parsed automatically
4. Continue with project generation

## File Format Examples

### OpenAPI 3.0 Example
```yaml
openapi: 3.0.0
info:
  title: User Management API
  version: 1.0.0
paths:
  /api/users:
    get:
      summary: Get all users
      responses:
        '200':
          description: Success
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/User'
```

### Custom JSON Format Example
```json
{
  "projectConfiguration": {
    "projectName": "My API",
    "groupId": "com.example",
    "artifactId": "my-api"
  },
  "apiSpecification": {
    "endpoints": [
      {
        "name": "getAllItems",
        "httpMethod": "GET",
        "path": "/items"
      }
    ]
  }
}
```

## Validation and Error Handling

### File Validation
The system performs multiple validation checks:

1. **File Size**: Maximum 10MB
2. **File Type**: Must be .json, .yaml, .yml
3. **Content Validation**:
   - Proper JSON/YAML syntax
   - Required fields presence
   - Schema compliance

### Common Errors and Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| "Invalid file format" | Unsupported file extension | Use .json, .yaml, or .yml files |
| "File too large" | File exceeds 10MB | Reduce file size or split specification |
| "Invalid JSON/YAML syntax" | Parsing error | Validate syntax using online validators |
| "Missing required fields" | Incomplete specification | Add required fields (title, paths, etc.) |
| "Unsupported specification version" | Old or unknown format | Convert to OpenAPI 3.0 or Swagger 2.0 |

## Parsed Data Mapping

### From OpenAPI to Project Configuration

| OpenAPI Field | Maps To | Description |
|---------------|---------|-------------|
| `info.title` | Project Name | The name of your Spring Boot project |
| `info.description` | Project Description | Project description in generated README |
| `servers[0].url` | Base Path | Controller base path configuration |
| `paths` | API Endpoints | Controller methods and mappings |
| `components.schemas` | DTOs | Request/Response model classes |

### Endpoint Mapping

OpenAPI endpoints are converted to Spring Boot controller methods:

- **HTTP Method**: Maps to `@GetMapping`, `@PostMapping`, etc.
- **Path**: Becomes the endpoint path
- **Parameters**: Convert to method parameters with validation
- **Request Body**: Generates DTO classes
- **Responses**: Creates response DTOs and error handling

## Advanced Features

### 1. Automatic Validation Generation
The parser automatically generates validation annotations based on schema constraints:
- `minLength`, `maxLength` → `@Size`
- `pattern` → `@Pattern`
- `format: email` → `@Email`
- `required` → `@NotNull`, `@NotBlank`

### 2. Security Configuration
If your OpenAPI spec includes security schemes, the generator creates:
- Security configuration classes
- JWT authentication setup (if Bearer token is used)
- Role-based access control

### 3. Documentation Generation
Swagger/OpenAPI descriptions are preserved as:
- JavaDoc comments
- Swagger annotations for API documentation
- README documentation

## Best Practices

### 1. Specification Organization
- Keep specifications under 5MB for optimal performance
- Use `$ref` for reusable components
- Organize paths logically by resource

### 2. Naming Conventions
- Use camelCase for operation IDs
- Use kebab-case for URL paths
- Use PascalCase for schema names

### 3. Validation Rules
- Always specify required fields
- Include format for special types (email, date, uuid)
- Add constraints (min, max, pattern) where applicable

### 4. Error Handling
- Define error response schemas
- Include meaningful error descriptions
- Specify all possible HTTP status codes

## Sample Files

Sample specification files are available in `/static/samples/`:
- `openapi-sample.yaml` - Complete OpenAPI 3.0 example
- `custom-sample.json` - Custom format with all features
- `swagger-sample.json` - Swagger 2.0 example (coming soon)

## Troubleshooting

### File Upload Issues

**Problem**: File upload fails silently
- Check browser console for errors
- Ensure file size is under 10MB
- Verify file extension is supported

**Problem**: Parsing errors with valid OpenAPI
- Ensure OpenAPI version is 3.0.x or Swagger 2.0
- Check for YAML indentation issues
- Validate against OpenAPI schema

**Problem**: Generated code doesn't match specification
- Review field mapping in parsed configuration
- Check for unsupported OpenAPI features
- Verify custom extensions are properly handled

### Getting Help

If you encounter issues:
1. Check the browser console for detailed error messages
2. Review the server logs for parsing errors
3. Validate your specification using [swagger.io/tools/swagger-editor](https://editor.swagger.io)
4. Refer to the sample files for working examples

## Limitations

Current limitations of the file upload parser:
- Maximum file size: 10MB
- No support for external references ($ref to URLs)
- Limited support for OpenAPI extensions (x-*)
- Postman collections not yet supported
- No support for GraphQL schemas

## Future Enhancements

Planned improvements:
- Postman collection v2.1 support
- GraphQL schema parsing
- API Blueprint format
- RAML specification support
- AsyncAPI for event-driven APIs
- Direct import from Git repositories
- URL import with authentication