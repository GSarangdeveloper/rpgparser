let endpointCounter = 0;

// Initialize with one endpoint
document.addEventListener('DOMContentLoaded', function() {
    addEndpoint();
});

function addEndpoint() {
    const endpointsList = document.getElementById('endpointsList');
    const endpointId = `endpoint-${endpointCounter++}`;

    const endpointHtml = `
        <div class="endpoint-item" id="${endpointId}">
            <div class="endpoint-header">
                <h4>Endpoint ${endpointCounter}</h4>
                <button type="button" class="btn btn-danger" onclick="removeEndpoint('${endpointId}')">Remove</button>
            </div>

            <!-- Basic Endpoint Info -->
            <div class="form-grid">
                <div class="form-group">
                    <label>Endpoint Name *</label>
                    <input type="text" class="endpoint-name" required placeholder="getUser">
                </div>
                <div class="form-group">
                    <label>HTTP Method *</label>
                    <select class="endpoint-method" required>
                        <option value="GET">GET</option>
                        <option value="POST">POST</option>
                        <option value="PUT">PUT</option>
                        <option value="DELETE">DELETE</option>
                        <option value="PATCH">PATCH</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Path *</label>
                    <input type="text" class="endpoint-path" required placeholder="/users/{id}">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <input type="text" class="endpoint-description" placeholder="Get user by ID">
                </div>
            </div>

            <!-- Request Parameters Section -->
            <div class="parameter-section">
                <div class="section-header">
                    <h5>Request Parameters</h5>
                    <button type="button" class="btn btn-secondary btn-small" onclick="addParameter('${endpointId}')">Add Parameter</button>
                </div>
                <div class="parameters-list" id="${endpointId}-parameters"></div>
            </div>

            <!-- Request Body Section -->
            <div class="parameter-section">
                <div class="section-header">
                    <h5>Request Body</h5>
                    <label style="font-size: 0.9rem;">
                        <input type="checkbox" class="has-request-body" onchange="toggleRequestBody('${endpointId}')">
                        Has Request Body
                    </label>
                </div>
                <div class="request-body-section" id="${endpointId}-request-body" style="display: none;">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>DTO Class Name</label>
                            <input type="text" class="request-body-class" placeholder="CreateUserRequest">
                        </div>
                        <div class="form-group checkbox-group">
                            <label>
                                <input type="checkbox" class="request-body-required" checked>
                                Required
                            </label>
                        </div>
                    </div>
                    <div class="section-header">
                        <h6>Request Body Fields</h6>
                        <button type="button" class="btn btn-secondary btn-small" onclick="addRequestBodyField('${endpointId}')">Add Field</button>
                    </div>
                    <div class="request-body-fields" id="${endpointId}-request-body-fields"></div>
                </div>
            </div>

            <!-- Response Configuration Section -->
            <div class="parameter-section">
                <div class="section-header">
                    <h5>Response Configuration</h5>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Response Type</label>
                        <select class="response-type">
                            <option value="SINGLE_OBJECT">Single Object</option>
                            <option value="LIST">List</option>
                            <option value="VOID">Void</option>
                            <option value="PAGINATED">Paginated</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Response DTO Name</label>
                        <input type="text" class="response-data-type" placeholder="UserResponse">
                    </div>
                    <div class="form-group">
                        <label>HTTP Status Code</label>
                        <select class="response-status">
                            <option value="200">200 OK</option>
                            <option value="201">201 Created</option>
                            <option value="204">204 No Content</option>
                            <option value="400">400 Bad Request</option>
                            <option value="404">404 Not Found</option>
                        </select>
                    </div>
                </div>
                <div class="section-header">
                    <h6>Response Fields</h6>
                    <button type="button" class="btn btn-secondary btn-small" onclick="addResponseField('${endpointId}')">Add Field</button>
                </div>
                <div class="response-fields" id="${endpointId}-response-fields"></div>
            </div>
        </div>
    `;

    endpointsList.insertAdjacentHTML('beforeend', endpointHtml);
}

function removeEndpoint(endpointId) {
    const endpoint = document.getElementById(endpointId);
    if (endpoint) {
        endpoint.remove();
    }
}

function addParameter(endpointId) {
    const parametersList = document.getElementById(`${endpointId}-parameters`);
    const parameterId = `param-${Date.now()}`;

    const parameterHtml = `
        <div class="parameter-item" id="${parameterId}">
            <div class="form-grid">
                <div class="form-group">
                    <label>Parameter Name *</label>
                    <input type="text" class="param-name" required placeholder="id">
                </div>
                <div class="form-group">
                    <label>Type *</label>
                    <select class="param-type">
                        <option value="String">String</option>
                        <option value="Integer">Integer</option>
                        <option value="Long">Long</option>
                        <option value="Boolean">Boolean</option>
                        <option value="Double">Double</option>
                        <option value="LocalDate">LocalDate</option>
                        <option value="LocalDateTime">LocalDateTime</option>
                        <option value="BigDecimal">BigDecimal</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Location *</label>
                    <select class="param-location">
                        <option value="PATH">Path Variable</option>
                        <option value="QUERY">Query Parameter</option>
                        <option value="HEADER">Header</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Default Value</label>
                    <input type="text" class="param-default" placeholder="Optional">
                </div>
            </div>
            <div class="form-grid">
                <div class="form-group checkbox-group">
                    <label>
                        <input type="checkbox" class="param-required" checked>
                        Required
                    </label>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <input type="text" class="param-description" placeholder="Parameter description">
                </div>
                <div class="form-group">
                    <button type="button" class="btn btn-danger btn-small" onclick="removeElement('${parameterId}')">Remove</button>
                </div>
            </div>
        </div>
    `;

    parametersList.insertAdjacentHTML('beforeend', parameterHtml);
}

function toggleRequestBody(endpointId) {
    const checkbox = document.querySelector(`#${endpointId} .has-request-body`);
    const requestBodySection = document.getElementById(`${endpointId}-request-body`);
    requestBodySection.style.display = checkbox.checked ? 'block' : 'none';
}

function addRequestBodyField(endpointId) {
    const fieldsList = document.getElementById(`${endpointId}-request-body-fields`);
    const fieldId = `field-${Date.now()}`;

    const fieldHtml = `
        <div class="field-item" id="${fieldId}">
            <div class="form-grid">
                <div class="form-group">
                    <label>Field Name *</label>
                    <input type="text" class="field-name" required placeholder="username">
                </div>
                <div class="form-group">
                    <label>Type *</label>
                    <select class="field-type">
                        <option value="String">String</option>
                        <option value="Integer">Integer</option>
                        <option value="Long">Long</option>
                        <option value="Boolean">Boolean</option>
                        <option value="Double">Double</option>
                        <option value="LocalDate">LocalDate</option>
                        <option value="LocalDateTime">LocalDateTime</option>
                        <option value="BigDecimal">BigDecimal</option>
                    </select>
                </div>
                <div class="form-group checkbox-group">
                    <label>
                        <input type="checkbox" class="field-required">
                        Required
                    </label>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <input type="text" class="field-description" placeholder="Field description">
                </div>
            </div>
            <div class="validation-group">
                <strong>Validations:</strong>
                <div class="form-grid">
                    <div class="form-group checkbox-group">
                        <label><input type="checkbox" class="val-not-null"> @NotNull</label>
                    </div>
                    <div class="form-group checkbox-group">
                        <label><input type="checkbox" class="val-not-blank"> @NotBlank</label>
                    </div>
                    <div class="form-group checkbox-group">
                        <label><input type="checkbox" class="val-email"> @Email</label>
                    </div>
                    <div class="form-group">
                        <label>@Size Min</label>
                        <input type="number" class="val-size-min" placeholder="Min length">
                    </div>
                    <div class="form-group">
                        <label>@Size Max</label>
                        <input type="number" class="val-size-max" placeholder="Max length">
                    </div>
                    <div class="form-group">
                        <label>@Pattern</label>
                        <input type="text" class="val-pattern" placeholder="Regex pattern">
                    </div>
                </div>
            </div>
            <button type="button" class="btn btn-danger btn-small" onclick="removeElement('${fieldId}')">Remove Field</button>
        </div>
    `;

    fieldsList.insertAdjacentHTML('beforeend', fieldHtml);
}

function addResponseField(endpointId) {
    const fieldsList = document.getElementById(`${endpointId}-response-fields`);
    const fieldId = `resp-field-${Date.now()}`;

    const fieldHtml = `
        <div class="field-item" id="${fieldId}">
            <div class="form-grid">
                <div class="form-group">
                    <label>Field Name *</label>
                    <input type="text" class="resp-field-name" required placeholder="id">
                </div>
                <div class="form-group">
                    <label>Type *</label>
                    <select class="resp-field-type">
                        <option value="String">String</option>
                        <option value="Integer">Integer</option>
                        <option value="Long">Long</option>
                        <option value="Boolean">Boolean</option>
                        <option value="Double">Double</option>
                        <option value="LocalDate">LocalDate</option>
                        <option value="LocalDateTime">LocalDateTime</option>
                        <option value="BigDecimal">BigDecimal</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <input type="text" class="resp-field-description" placeholder="Field description">
                </div>
                <div class="form-group">
                    <button type="button" class="btn btn-danger btn-small" onclick="removeElement('${fieldId}')">Remove</button>
                </div>
            </div>
        </div>
    `;

    fieldsList.insertAdjacentHTML('beforeend', fieldHtml);
}

function removeElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.remove();
    }
}

function collectFormData() {
    const form = document.getElementById('generatorForm');
    const formData = new FormData(form);

    // Build project configuration
    const projectConfiguration = {
        projectName: formData.get('projectName'),
        description: formData.get('description') || '',
        groupId: formData.get('groupId'),
        artifactId: formData.get('artifactId'),
        packageName: formData.get('packageName'),
        springBootVersion: formData.get('springBootVersion'),
        javaVersion: formData.get('javaVersion'),
        buildTool: 'gradle',
        packaging: formData.get('packaging')
    };

    // Build dependency configuration
    const dependencyConfiguration = {
        database: formData.get('database'),
        security: form.querySelector('#security').checked,
        documentation: form.querySelector('#documentation').checked,
        caching: form.querySelector('#caching').checked
    };

    // Build endpoints
    const endpoints = [];
    const endpointElements = document.querySelectorAll('.endpoint-item');

    endpointElements.forEach((endpointEl, index) => {
        const endpointId = endpointEl.id;

        // Basic endpoint info
        const endpoint = {
            id: endpointId,
            name: endpointEl.querySelector('.endpoint-name').value,
            httpMethod: endpointEl.querySelector('.endpoint-method').value,
            path: endpointEl.querySelector('.endpoint-path').value,
            description: endpointEl.querySelector('.endpoint-description').value || '',
            requestParameters: [],
            response: {}
        };

        // Collect request parameters
        const parameterElements = endpointEl.querySelectorAll('.parameter-item');
        parameterElements.forEach(paramEl => {
            endpoint.requestParameters.push({
                name: paramEl.querySelector('.param-name').value,
                type: paramEl.querySelector('.param-type').value,
                parameterLocation: paramEl.querySelector('.param-location').value,
                required: paramEl.querySelector('.param-required').checked,
                defaultValue: paramEl.querySelector('.param-default').value || null,
                description: paramEl.querySelector('.param-description').value || ''
            });
        });

        // Collect request body if exists
        const hasRequestBody = endpointEl.querySelector('.has-request-body').checked;
        if (hasRequestBody) {
            const requestBodyFields = [];
            const fieldElements = endpointEl.querySelectorAll(`#${endpointId}-request-body-fields .field-item`);

            fieldElements.forEach(fieldEl => {
                const validation = {};

                if (fieldEl.querySelector('.val-not-null').checked) validation.notNull = true;
                if (fieldEl.querySelector('.val-not-blank').checked) validation.notBlank = true;
                if (fieldEl.querySelector('.val-email').checked) validation.email = true;

                const sizeMin = fieldEl.querySelector('.val-size-min').value;
                const sizeMax = fieldEl.querySelector('.val-size-max').value;
                if (sizeMin || sizeMax) {
                    validation.size = {
                        min: parseInt(sizeMin) || 0,
                        max: parseInt(sizeMax) || 255
                    };
                }

                const pattern = fieldEl.querySelector('.val-pattern').value;
                if (pattern) validation.pattern = pattern;

                requestBodyFields.push({
                    name: fieldEl.querySelector('.field-name').value,
                    type: fieldEl.querySelector('.field-type').value,
                    required: fieldEl.querySelector('.field-required').checked,
                    description: fieldEl.querySelector('.field-description').value || '',
                    validation: Object.keys(validation).length > 0 ? validation : null
                });
            });

            endpoint.requestBody = {
                required: endpointEl.querySelector('.request-body-required').checked,
                type: endpointEl.querySelector('.request-body-class').value || `${endpoint.name}Request`,
                fields: requestBodyFields
            };
        }

        // Collect response configuration
        const responseFields = [];
        const respFieldElements = endpointEl.querySelectorAll(`#${endpointId}-response-fields .field-item`);

        respFieldElements.forEach(fieldEl => {
            responseFields.push({
                name: fieldEl.querySelector('.resp-field-name').value,
                type: fieldEl.querySelector('.resp-field-type').value,
                description: fieldEl.querySelector('.resp-field-description').value || ''
            });
        });

        endpoint.response = {
            type: endpointEl.querySelector('.response-type').value,
            wrapInResponseEntity: true,
            httpStatus: parseInt(endpointEl.querySelector('.response-status').value),
            dataType: endpointEl.querySelector('.response-data-type').value || `${endpoint.name}Response`,
            fields: responseFields
        };

        endpoints.push(endpoint);
    });

    // Build API specification
    const apiSpecification = {
        baseControllerPath: formData.get('baseControllerPath'),
        controllerClassName: formData.get('controllerClassName'),
        description: 'Generated REST API Controller',
        endpoints: endpoints
    };

    // Build generation options
    const generationOptions = {
        includeServiceLayer: form.querySelector('#includeServiceLayer').checked,
        includeExceptionHandling: form.querySelector('#includeExceptionHandling').checked,
        includeValidation: form.querySelector('#includeValidation').checked,
        includeLogging: form.querySelector('#includeLogging').checked,
        generateTests: form.querySelector('#generateTests') ? form.querySelector('#generateTests').checked : false,
        generateCustomExceptions: form.querySelector('#generateCustomExceptions') ? form.querySelector('#generateCustomExceptions').checked : false,
        generateRepository: form.querySelector('#generateRepository') ? form.querySelector('#generateRepository').checked : false,
        enhanceWithLLM: false,
        generateSwaggerDocs: form.querySelector('#generateSwaggerDocs') ? form.querySelector('#generateSwaggerDocs').checked : true
    };

    return {
        projectConfiguration,
        dependencyConfiguration,
        apiSpecification,
        generationOptions
    };
}

// Handle form submission
document.getElementById('generatorForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const statusSection = document.getElementById('statusSection');
    const statusMessage = document.getElementById('statusMessage');
    const downloadSection = document.getElementById('downloadSection');
    let progressBar = document.getElementById('progressBar');

    // Create progress bar if it doesn't exist
    if (!progressBar) {
        progressBar = document.createElement('div');
        progressBar.id = 'progressBar';
        progressBar.style.marginTop = '10px';
        statusSection.appendChild(progressBar);
    }

    // Show loading status
    statusSection.style.display = 'block';
    statusMessage.className = 'status-loading';
    statusMessage.innerHTML = '<strong>Initializing...</strong> Preparing to generate your Spring Boot Gradle project...';
    downloadSection.style.display = 'none';

    // Show progress bar
    progressBar.style.display = 'block';
    progressBar.innerHTML = '<div style="background: #f0f0f0; border-radius: 4px; height: 20px; overflow: hidden;"><div id="progressBarFill" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); height: 100%; width: 0%; transition: width 0.3s; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px;">0%</div></div>';

    try {
        const data = collectFormData();

        // First validate the configuration using v1 API
        const validationResponse = await fetch('/api/v1/validate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const validationResult = await validationResponse.json();

        if (!validationResult.valid) {
            // Display validation errors
            let errorHtml = '<strong>Validation Errors:</strong><ul style="text-align: left;">';
            validationResult.errors.forEach(error => {
                errorHtml += `<li><strong>${error.field}:</strong> ${error.message} (Code: ${error.code})</li>`;
            });
            errorHtml += '</ul>';

            if (validationResult.warnings && validationResult.warnings.length > 0) {
                errorHtml += '<strong>Warnings:</strong><ul style="text-align: left;">';
                validationResult.warnings.forEach(warning => {
                    errorHtml += `<li>${warning.field}: ${warning.message}</li>`;
                });
                errorHtml += '</ul>';
            }

            statusMessage.className = 'status-error';
            statusMessage.innerHTML = errorHtml;
            progressBar.style.display = 'none';
            return;
        }

        // Use sanitized data from validation if available
        const finalData = validationResult.sanitized_data || data;

        // Update progress
        updateProgress(10, 'Validation complete. Starting generation...');

        // Call the v1 generation API
        const response = await fetch('/api/v1/generate/project', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(finalData)
        });

        const result = await response.json();

        if (response.ok && result.success) {
            // Setup SSE for real-time progress updates
            if (result.projectId) {
                const eventSource = new EventSource(`/api/v1/progress/${result.projectId}`);

                eventSource.onmessage = function(event) {
                    const progress = JSON.parse(event.data);

                    if (progress.heartbeat) {
                        return; // Just a heartbeat, ignore
                    }

                    // Update progress bar and message
                    updateProgress(progress.progress, progress.message);

                    // If complete, close SSE and show download
                    if (progress.complete) {
                        eventSource.close();
                        showGenerationSuccess(result);
                    }
                };

                eventSource.onerror = function(error) {
                    eventSource.close();
                    console.error('SSE Error:', error);
                    // Fallback to showing success without real-time progress
                    updateProgress(100, 'Generation complete!');
                    showGenerationSuccess(result);
                };
            } else {
                // No progress tracking available, show success immediately
                updateProgress(100, 'Generation complete!');
                showGenerationSuccess(result);
            }
        } else {
            const errorMessage = result.error ?
                (typeof result.error === 'string' ? result.error : result.error.message) :
                'Generation failed';
            throw new Error(errorMessage);
        }
    } catch (error) {
        statusMessage.className = 'status-error';
        statusMessage.innerHTML = `<strong>Error!</strong> ${error.message}`;
        progressBar.style.display = 'none';
    }
});

// Helper function to update progress
function updateProgress(percentage, message) {
    const progressBarFill = document.getElementById('progressBarFill');
    const statusMessage = document.getElementById('statusMessage');

    if (progressBarFill) {
        progressBarFill.style.width = `${percentage}%`;
        progressBarFill.textContent = `${percentage}%`;
    }

    if (statusMessage && message) {
        statusMessage.innerHTML = `<strong>Progress:</strong> ${message}`;
    }
}

// Helper function to show generation success
function showGenerationSuccess(result) {
    const statusMessage = document.getElementById('statusMessage');
    const downloadSection = document.getElementById('downloadSection');

    statusMessage.className = 'status-success';
    statusMessage.innerHTML = `
        <strong>✅ Success!</strong> Your Spring Boot Gradle project has been generated.<br>
        <strong>Build Tool:</strong> Gradle<br>
        <strong>Generated Files:</strong> ${result.generatedFiles.length}<br>
        <strong>Project ID:</strong> ${result.projectId}
    `;

    // Add metadata if available
    if (result.metadata) {
        statusMessage.innerHTML += `<br>
            <strong>Spring Boot Version:</strong> ${result.metadata.springBootVersion}<br>
            <strong>Java Version:</strong> ${result.metadata.javaVersion}
        `;
    }

    // Display warnings if any
    if (result.warnings && result.warnings.length > 0) {
        statusMessage.innerHTML += '<br><strong>⚠️ Warnings:</strong><ul style="text-align: left;">';
        result.warnings.forEach(warning => {
            statusMessage.innerHTML += `<li>${warning.field}: ${warning.message}</li>`;
        });
        statusMessage.innerHTML += '</ul>';
    }

    // Show download button
    const downloadLink = document.getElementById('downloadLink');
    downloadLink.href = result.downloadUrl;
    downloadSection.style.display = 'block';
}

async function previewCode() {
    try {
        const data = collectFormData();

        // Show loading indicator
        const previewBtn = document.querySelector('button[onclick="previewCode()"]');
        const originalText = previewBtn ? previewBtn.textContent : '';
        if (previewBtn) {
            previewBtn.textContent = 'Loading...';
            previewBtn.disabled = true;
        }

        // Use v1 API for preview
        const response = await fetch('/api/v1/generate/preview', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok && result.success) {
            showPreview(result.files);

            // Show warnings if any
            if (result.warnings && result.warnings.length > 0) {
                let warningMsg = 'Warnings:\n';
                result.warnings.forEach(warning => {
                    warningMsg += `- ${warning.field}: ${warning.message}\n`;
                });
                console.warn(warningMsg);
            }
        } else {
            let errorMsg = 'Error previewing code:\n';
            if (result.errors) {
                result.errors.forEach(error => {
                    errorMsg += `- ${error.field}: ${error.message} (${error.code})\n`;
                });
            } else if (result.error) {
                errorMsg += typeof result.error === 'string' ? result.error : result.error.message;
            }
            alert(errorMsg);
        }
    } catch (error) {
        alert('Error previewing code: ' + error.message);
    } finally {
        // Restore button
        const previewBtn = document.querySelector('button[onclick="previewCode()"]');
        if (previewBtn) {
            previewBtn.textContent = originalText || 'Preview Code';
            previewBtn.disabled = false;
        }
    }
}

function showPreview(files) {
    const modal = document.getElementById('previewModal');
    const previewContent = document.getElementById('previewContent');

    let html = '';
    for (const [filePath, fileContent] of Object.entries(files)) {
        html += `
            <div class="code-preview">
                <h4>${filePath}</h4>
                <pre><code>${escapeHtml(fileContent)}</code></pre>
            </div>
        `;
    }

    previewContent.innerHTML = html;
    modal.style.display = 'block';
}

function closePreview() {
    const modal = document.getElementById('previewModal');
    modal.style.display = 'none';
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('previewModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}
