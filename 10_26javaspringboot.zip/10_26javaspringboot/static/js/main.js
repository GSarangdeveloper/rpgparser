let endpointCounter = 0;

// Initialize with one endpoint
document.addEventListener('DOMContentLoaded', function() {
    addEndpoint();
});

function addEndpoint() {
    const endpointsList = document.getElementById('endpointsList');
    const endpointId = `endpoint-${endpointCounter++}`;

    const endpointHtml = `
        <div class="endpoint-item" id="${endpointId}">
            <div class="endpoint-header">
                <h4>Endpoint ${endpointCounter}</h4>
                <button type="button" class="btn btn-danger" onclick="removeEndpoint('${endpointId}')">Remove</button>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>Endpoint Name *</label>
                    <input type="text" name="endpointName[]" required placeholder="getUser">
                </div>
                <div class="form-group">
                    <label>HTTP Method *</label>
                    <select name="httpMethod[]" required>
                        <option value="GET">GET</option>
                        <option value="POST">POST</option>
                        <option value="PUT">PUT</option>
                        <option value="DELETE">DELETE</option>
                        <option value="PATCH">PATCH</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Path *</label>
                    <input type="text" name="endpointPath[]" required placeholder="/users/{id}">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <input type="text" name="endpointDescription[]" placeholder="Get user by ID">
                </div>
                <div class="form-group">
                    <label>Response Type</label>
                    <select name="responseType[]">
                        <option value="SINGLE_OBJECT">Single Object</option>
                        <option value="LIST">List</option>
                        <option value="VOID">Void</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Response DTO Name</label>
                    <input type="text" name="responseDataType[]" placeholder="UserResponse">
                </div>
            </div>
        </div>
    `;

    endpointsList.insertAdjacentHTML('beforeend', endpointHtml);
}

function removeEndpoint(endpointId) {
    const endpoint = document.getElementById(endpointId);
    if (endpoint) {
        endpoint.remove();
    }
}

function collectFormData() {
    const form = document.getElementById('generatorForm');
    const formData = new FormData(form);

    // Build project configuration
    const projectConfiguration = {
        projectName: formData.get('projectName'),
        description: formData.get('description') || '',
        groupId: formData.get('groupId'),
        artifactId: formData.get('artifactId'),
        packageName: formData.get('packageName'),
        springBootVersion: formData.get('springBootVersion'),
        javaVersion: formData.get('javaVersion'),
        buildTool: 'gradle',
        packaging: formData.get('packaging')
    };

    // Build dependency configuration
    const dependencyConfiguration = {
        database: formData.get('database'),
        security: form.querySelector('#security').checked,
        documentation: form.querySelector('#documentation').checked,
        caching: form.querySelector('#caching').checked
    };

    // Build endpoints
    const endpointNames = formData.getAll('endpointName[]');
    const httpMethods = formData.getAll('httpMethod[]');
    const endpointPaths = formData.getAll('endpointPath[]');
    const endpointDescriptions = formData.getAll('endpointDescription[]');
    const responseTypes = formData.getAll('responseType[]');
    const responseDataTypes = formData.getAll('responseDataType[]');

    const endpoints = endpointNames.map((name, index) => ({
        id: `endpoint-${index}`,
        name: name,
        httpMethod: httpMethods[index],
        path: endpointPaths[index],
        description: endpointDescriptions[index] || '',
        requestParameters: [],
        response: {
            type: responseTypes[index],
            wrapInResponseEntity: true,
            httpStatus: httpMethods[index] === 'POST' ? 201 : 200,
            dataType: responseDataTypes[index] || `${name.charAt(0).toUpperCase() + name.slice(1)}Response`,
            fields: [
                {
                    name: 'id',
                    type: 'Long',
                    description: 'Unique identifier'
                },
                {
                    name: 'message',
                    type: 'String',
                    description: 'Response message'
                }
            ]
        }
    }));

    // Build API specification
    const apiSpecification = {
        baseControllerPath: formData.get('baseControllerPath'),
        controllerClassName: formData.get('controllerClassName'),
        description: 'Generated REST API Controller',
        endpoints: endpoints
    };

    // Build generation options
    const generationOptions = {
        includeServiceLayer: form.querySelector('#includeServiceLayer').checked,
        includeExceptionHandling: form.querySelector('#includeExceptionHandling').checked,
        includeValidation: form.querySelector('#includeValidation').checked,
        includeLogging: form.querySelector('#includeLogging').checked,
        generateTests: false,
        enhanceWithLLM: false,
        generateSwaggerDocs: true
    };

    return {
        projectConfiguration,
        dependencyConfiguration,
        apiSpecification,
        generationOptions
    };
}

// Handle form submission
document.getElementById('generatorForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const statusSection = document.getElementById('statusSection');
    const statusMessage = document.getElementById('statusMessage');
    const downloadSection = document.getElementById('downloadSection');

    // Show loading status
    statusSection.style.display = 'block';
    statusMessage.className = 'status-loading';
    statusMessage.textContent = 'Generating your Spring Boot project... Please wait.';
    downloadSection.style.display = 'none';

    try {
        const data = collectFormData();

        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok && result.success) {
            statusMessage.className = 'status-success';
            statusMessage.innerHTML = `
                <strong>Success!</strong> Your Spring Boot project has been generated.<br>
                Generated files: ${result.generatedFiles.length}<br>
                Project ID: ${result.projectId}
            `;

            // Show download button
            const downloadLink = document.getElementById('downloadLink');
            downloadLink.href = result.downloadUrl;
            downloadSection.style.display = 'block';
        } else {
            throw new Error(result.error || 'Generation failed');
        }
    } catch (error) {
        statusMessage.className = 'status-error';
        statusMessage.innerHTML = `<strong>Error!</strong> ${error.message}`;
    }
});

async function previewCode() {
    try {
        const data = collectFormData();

        const response = await fetch('/api/preview', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok && result.success) {
            showPreview(result.files);
        } else {
            alert('Error previewing code: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Error previewing code: ' + error.message);
    }
}

function showPreview(files) {
    const modal = document.getElementById('previewModal');
    const previewContent = document.getElementById('previewContent');

    let html = '';
    for (const [filePath, fileContent] of Object.entries(files)) {
        html += `
            <div class="code-preview">
                <h4>${filePath}</h4>
                <pre><code>${escapeHtml(fileContent)}</code></pre>
            </div>
        `;
    }

    previewContent.innerHTML = html;
    modal.style.display = 'block';
}

function closePreview() {
    const modal = document.getElementById('previewModal');
    modal.style.display = 'none';
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('previewModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}
