// File Upload and UI Management JavaScript

let selectedFile = null;
let parsedSpecification = null;

// Initialize drag and drop when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setupDragAndDrop();
});

// Input method selection
function selectInputMethod(method) {
    // Hide all sections
    document.getElementById('inputMethodSelection').style.display = 'none';
    document.getElementById('fileUploadSection').style.display = 'none';
    document.getElementById('pasteSpecSection').style.display = 'none';
    document.getElementById('urlImportSection').style.display = 'none';
    document.getElementById('manualEntrySection').style.display = 'none';
    document.getElementById('parsedDataSection').style.display = 'none';

    // Show selected section
    switch(method) {
        case 'upload':
            document.getElementById('fileUploadSection').style.display = 'block';
            break;
        case 'manual':
            document.getElementById('manualEntrySection').style.display = 'block';
            break;
        case 'paste':
            document.getElementById('pasteSpecSection').style.display = 'block';
            break;
        case 'url':
            document.getElementById('urlImportSection').style.display = 'block';
            break;
    }
}

// Back to selection
function backToSelection() {
    document.getElementById('inputMethodSelection').style.display = 'block';
    document.getElementById('fileUploadSection').style.display = 'none';
    document.getElementById('pasteSpecSection').style.display = 'none';
    document.getElementById('urlImportSection').style.display = 'none';
    document.getElementById('manualEntrySection').style.display = 'none';
    document.getElementById('parsedDataSection').style.display = 'none';
}

// Setup drag and drop
function setupDragAndDrop() {
    const dropZone = document.getElementById('dropZone');

    if (!dropZone) return;

    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    // Highlight drop zone when item is dragged over it
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, unhighlight, false);
    });

    // Handle dropped files
    dropZone.addEventListener('drop', handleDrop, false);

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function highlight(e) {
        dropZone.classList.add('drag-over');
    }

    function unhighlight(e) {
        dropZone.classList.remove('drag-over');
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;

        if (files.length > 0) {
            handleFileSelection(files[0]);
        }
    }
}

// Handle file selection
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (file) {
        handleFileSelection(file);
    }
}

function handleFileSelection(file) {
    // Validate file
    if (!validateFile(file)) {
        return;
    }

    selectedFile = file;

    // Update UI
    const dropZone = document.getElementById('dropZone');
    const dropZoneContent = dropZone.querySelector('.drop-zone-content');

    dropZoneContent.innerHTML = `
        <div class="file-selected">
            <div class="upload-icon">✅</div>
            <h3>File Selected</h3>
            <p class="file-name">${file.name}</p>
            <p class="file-size">${formatFileSize(file.size)}</p>
            <button class="btn btn-secondary" onclick="clearFileSelection()">Choose Different File</button>
        </div>
    `;

    // Enable upload button
    document.getElementById('uploadParseBtn').disabled = false;
}

// Validate file
function validateFile(file) {
    // Check file size (5MB limit)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
        showError('File size exceeds 5MB limit');
        return false;
    }

    // Check file type
    const validExtensions = ['json', 'yaml', 'yml'];
    const fileExtension = file.name.split('.').pop().toLowerCase();

    if (!validExtensions.includes(fileExtension)) {
        showError('Invalid file type. Please upload a JSON or YAML file.');
        return false;
    }

    return true;
}

// Clear file selection
function clearFileSelection() {
    selectedFile = null;
    document.getElementById('fileInput').value = '';

    // Reset drop zone UI
    location.reload(); // Simple way to reset the UI
}

// Upload and parse file
async function uploadAndParse() {
    if (!selectedFile) {
        showError('Please select a file first');
        return;
    }

    showLoading('Uploading and parsing specification...');

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
        const response = await fetch('/api/v1/upload/specification', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (response.ok && result.success) {
            parsedSpecification = result.data;
            displayParsedData(result.data);
            hideLoading();
        } else {
            hideLoading();
            showError(result.error || 'Failed to parse specification');
        }
    } catch (error) {
        hideLoading();
        showError('Error uploading file: ' + error.message);
    }
}

// Parse specification content (from paste)
async function parseSpecContent() {
    const format = document.getElementById('specFormat').value;
    const content = document.getElementById('specContent').value;

    if (!content.trim()) {
        showError('Please paste a specification');
        return;
    }

    showLoading('Parsing specification...');

    try {
        const response = await fetch('/api/v1/parse/specification', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                format: format,
                content: content
            })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            parsedSpecification = result.data;
            displayParsedData(result.data);
            hideLoading();
        } else {
            hideLoading();
            showError(result.error || 'Failed to parse specification');
        }
    } catch (error) {
        hideLoading();
        showError('Error parsing specification: ' + error.message);
    }
}

// Import from URL
async function importFromUrl() {
    const url = document.getElementById('specUrl').value;

    if (!url.trim()) {
        showError('Please enter a URL');
        return;
    }

    showLoading('Importing from URL...');

    try {
        const response = await fetch('/api/v1/import/url', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: url })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            parsedSpecification = result.data;
            displayParsedData(result.data);
            hideLoading();
        } else {
            hideLoading();
            showError(result.error || 'Failed to import from URL');
        }
    } catch (error) {
        hideLoading();
        showError('Error importing from URL: ' + error.message);
    }
}

// Display parsed data
function displayParsedData(data) {
    // Hide upload section, show parsed data section
    document.getElementById('fileUploadSection').style.display = 'none';
    document.getElementById('pasteSpecSection').style.display = 'none';
    document.getElementById('urlImportSection').style.display = 'none';
    document.getElementById('parsedDataSection').style.display = 'block';

    // Populate API info
    document.getElementById('apiName').textContent = data.title || 'API';
    document.getElementById('endpointCount').textContent = data.endpoints ? data.endpoints.length : 0;
    document.getElementById('basePath').textContent = data.basePath || '/api';
    document.getElementById('apiVersion').textContent = data.version || '1.0.0';

    // Populate endpoints list
    const endpointsList = document.getElementById('endpointsList');
    endpointsList.innerHTML = '';

    if (data.endpoints && data.endpoints.length > 0) {
        data.endpoints.forEach((endpoint, index) => {
            const endpointHtml = `
                <div class="endpoint-item" data-index="${index}">
                    <input type="checkbox" checked>
                    <span class="endpoint-method method-${endpoint.method.toLowerCase()}">${endpoint.method}</span>
                    <span class="endpoint-path">${endpoint.path}</span>
                    <span class="endpoint-description">${endpoint.summary || endpoint.operationId || ''}</span>
                    <div class="endpoint-actions">
                        <button class="btn btn-small" onclick="editEndpoint(${index})">Edit</button>
                        <button class="btn btn-small" onclick="removeEndpoint(${index})">Remove</button>
                    </div>
                </div>
            `;
            endpointsList.innerHTML += endpointHtml;
        });
    }

    // Auto-fill some fields based on parsed data
    if (data.title) {
        const artifactId = data.title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
        document.getElementById('artifactId').value = artifactId;

        const packageName = `com.example.${artifactId.replace(/-/g, '')}`;
        document.getElementById('packageName').value = packageName;
    }
}

// Generate project with parsed data
async function generateProject() {
    // Validate required fields
    const groupId = document.getElementById('groupId').value;
    const artifactId = document.getElementById('artifactId').value;
    const packageName = document.getElementById('packageName').value;

    if (!groupId || !artifactId || !packageName) {
        showError('Please fill in all required fields');
        return;
    }

    // Build the complete configuration
    const configuration = {
        projectConfiguration: {
            projectName: parsedSpecification.title || artifactId,
            description: parsedSpecification.description || 'Generated API',
            groupId: groupId,
            artifactId: artifactId,
            packageName: packageName,
            springBootVersion: document.getElementById('springBootVersion').value,
            javaVersion: document.getElementById('javaVersion').value,
            buildTool: 'gradle',
            packaging: 'jar'
        },
        dependencyConfiguration: {
            database: 'none',
            security: false,
            documentation: document.getElementById('genSwagger').checked,
            caching: false,
            messaging: false
        },
        apiSpecification: {
            baseControllerPath: parsedSpecification.basePath || '/api',
            controllerClassName: artifactId.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(''),
            description: parsedSpecification.description || '',
            endpoints: parsedSpecification.endpoints || []
        },
        generationOptions: {
            includeServiceLayer: document.getElementById('genServiceLayer').checked,
            includeExceptionHandling: true,
            includeValidation: document.getElementById('genValidation').checked,
            includeLogging: true,
            generateTests: document.getElementById('genTests').checked,
            generateCustomExceptions: document.getElementById('genExceptions').checked,
            generateRepository: document.getElementById('genRepository').checked,
            generateSwaggerDocs: document.getElementById('genSwagger').checked
        }
    };

    // Show status section
    document.getElementById('parsedDataSection').style.display = 'none';
    document.getElementById('statusSection').style.display = 'block';

    // Call the generation API
    await callGenerationAPI(configuration);
}

// Call generation API
async function callGenerationAPI(configuration) {
    const statusMessage = document.getElementById('statusMessage');
    const progressBar = document.getElementById('progressBar');
    const downloadSection = document.getElementById('downloadSection');

    statusMessage.innerHTML = '<strong>Initializing...</strong> Preparing to generate your Spring Boot project...';
    progressBar.style.display = 'block';
    updateProgress(0);

    try {
        // Validate first
        const validationResponse = await fetch('/api/v1/validate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(configuration)
        });

        const validationResult = await validationResponse.json();

        if (!validationResult.valid) {
            let errorHtml = '<strong>Validation Errors:</strong><ul>';
            validationResult.errors.forEach(error => {
                errorHtml += `<li>${error.field}: ${error.message}</li>`;
            });
            errorHtml += '</ul>';
            statusMessage.innerHTML = errorHtml;
            statusMessage.className = 'status-error';
            progressBar.style.display = 'none';
            return;
        }

        updateProgress(20, 'Validation complete. Generating project...');

        // Generate project
        const response = await fetch('/api/v1/generate/project', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(configuration)
        });

        const result = await response.json();

        if (response.ok && result.success) {
            // Setup SSE for progress
            if (result.projectId) {
                const eventSource = new EventSource(`/api/v1/progress/${result.projectId}`);

                eventSource.onmessage = function(event) {
                    const progress = JSON.parse(event.data);

                    if (!progress.heartbeat) {
                        updateProgress(progress.progress, progress.message);

                        if (progress.complete) {
                            eventSource.close();

                            statusMessage.innerHTML = `
                                <strong>✅ Success!</strong> Your Spring Boot project has been generated.<br>
                                Generated files: ${result.generatedFiles.length}<br>
                                Project ID: ${result.projectId}
                            `;
                            statusMessage.className = 'status-success';

                            const downloadLink = document.getElementById('downloadLink');
                            downloadLink.href = result.downloadUrl;
                            downloadSection.style.display = 'block';
                        }
                    }
                };

                eventSource.onerror = function() {
                    eventSource.close();
                    updateProgress(100, 'Generation complete!');

                    statusMessage.innerHTML = `
                        <strong>✅ Success!</strong> Your project has been generated.
                    `;
                    statusMessage.className = 'status-success';

                    const downloadLink = document.getElementById('downloadLink');
                    downloadLink.href = result.downloadUrl;
                    downloadSection.style.display = 'block';
                };
            }
        } else {
            throw new Error(result.error || 'Generation failed');
        }
    } catch (error) {
        statusMessage.innerHTML = `<strong>Error!</strong> ${error.message}`;
        statusMessage.className = 'status-error';
        progressBar.style.display = 'none';
    }
}

// Update progress bar
function updateProgress(percentage, message) {
    const progressBarFill = document.getElementById('progressBarFill');
    const statusMessage = document.getElementById('statusMessage');

    if (progressBarFill) {
        progressBarFill.style.width = `${percentage}%`;
        progressBarFill.textContent = `${percentage}%`;
    }

    if (message && statusMessage) {
        statusMessage.innerHTML = `<strong>Progress:</strong> ${message}`;
    }
}

// UI Helper functions
function showLoading(message) {
    const overlay = document.getElementById('loadingOverlay');
    const loadingMessage = document.getElementById('loadingMessage');

    if (overlay) {
        overlay.style.display = 'flex';
        if (loadingMessage) {
            loadingMessage.textContent = message || 'Processing...';
        }
    }
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

function showError(message) {
    alert('Error: ' + message);
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// Navigation functions
function uploadDifferentFile() {
    backToSelection();
    setTimeout(() => selectInputMethod('upload'), 100);
}

function editManually() {
    // Convert parsed data to manual form
    alert('Manual editing feature coming soon!');
}

// Endpoint management
function editEndpoint(index) {
    alert(`Edit endpoint ${index} - Feature coming soon!`);
}

function removeEndpoint(index) {
    if (parsedSpecification && parsedSpecification.endpoints) {
        parsedSpecification.endpoints.splice(index, 1);
        displayParsedData(parsedSpecification);
    }
}

function addManualEndpoint() {
    alert('Add endpoint feature coming soon!');
}

// Download sample files
function downloadSampleOpenAPI() {
    window.open('/static/samples/openapi-sample.yaml', '_blank');
}

function downloadSampleJSON() {
    window.open('/static/samples/custom-sample.json', '_blank');
}