# Spring Boot API Generator 🚀

[![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)](https://github.com/yourusername/spring-boot-api-generator)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/)
[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.2.0-brightgreen.svg)](https://spring.io/projects/spring-boot)

A powerful, enterprise-grade tool for automatically generating production-ready Spring Boot REST APIs from various specification formats. Transform your API designs into fully functional Spring Boot applications with comprehensive features including validation, testing, documentation, and more.

## Features

- **Project Scaffolding**: Uses Spring Initializr for base project generation with Gradle
- **Code Generation**: Creates Controllers, Services, DTOs, and Exception Handlers
- **Customizable**: Configure project settings, dependencies, and API endpoints
- **Modern Stack**: Supports Spring Boot 3.x with Java 17/21
- **Best Practices**: Generated code follows Spring Boot best practices
- **Ready to Run**: Download and run with `./gradlew bootRun`

## Requirements

- Python 3.8+
- Internet connection (for Spring Initializr API)

## Installation

1. Clone or download this repository

2. Install Python dependencies:
```bash
pip install -r requirements.txt
```

## Usage

1. Start the Flask application:
```bash
python app.py
```

2. Open your browser and navigate to:
```
http://localhost:5000
```

3. Fill out the form with your project specifications:
   - **Project Configuration**: Set project name, group ID, package name, etc.
   - **Dependencies**: Choose database, security, documentation options
   - **API Specification**: Define your REST API endpoints
   - **Generation Options**: Select what to include in the generated code

4. Click "Generate Project" to create your Spring Boot project

5. Download the generated ZIP file

6. Extract and run:
```bash
cd your-project-name
./gradlew bootRun
```

## Generated Project Structure

```
your-project/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── {packagePath}/
│   │   │       ├── Application.java
│   │   │       ├── controller/
│   │   │       │   └── {ClassName}Controller.java
│   │   │       ├── service/
│   │   │       │   ├── {ClassName}Service.java
│   │   │       │   └── impl/
│   │   │       │       └── {ClassName}ServiceImpl.java
│   │   │       ├── dto/
│   │   │       │   ├── request/
│   │   │       │   └── response/
│   │   │       └── exception/
│   │   │           ├── GlobalExceptionHandler.java
│   │   │           └── ErrorResponse.java
│   │   └── resources/
│   │       └── application.properties
│   └── test/
├── build.gradle
├── settings.gradle
└── gradlew
```

## Example

Generate a User Management API:

1. **Project Configuration**:
   - Project Name: user-management-api
   - Group ID: com.example
   - Package Name: com.example.usermanagement

2. **API Specification**:
   - Base Path: /api/v1
   - Controller Name: User
   - Add endpoints like:
     - GET /users/{id}
     - POST /users
     - PUT /users/{id}
     - DELETE /users/{id}

3. Generate and download the project

4. The generated project will have:
   - UserController with all CRUD endpoints
   - UserService and UserServiceImpl
   - Request/Response DTOs
   - Global exception handling
   - Validation support
   - Logging configuration

## Features of Generated Code

### Controllers
- RESTful endpoints with proper HTTP methods
- Request validation with Jakarta Validation
- ResponseEntity with appropriate HTTP status codes
- Logging support with SLF4J

### Services
- Service interface and implementation
- Business logic placeholders
- Ready for dependency injection

### DTOs
- Lombok annotations for boilerplate reduction
- Validation constraints
- Builder pattern support

### Exception Handling
- Global exception handler
- Standardized error responses
- Validation error formatting

## Configuration

The application can be configured through environment variables or by modifying the services:

- **Spring Initializr URL**: Default is `https://start.spring.io`
- **Timeout**: API call timeout is 30 seconds
- **Generated Projects Directory**: Projects are saved in `generated_projects/`

## API Endpoints

### POST /api/generate
Generate a complete Spring Boot project

**Request Body**:
```json
{
  "projectConfiguration": { ... },
  "dependencyConfiguration": { ... },
  "apiSpecification": { ... },
  "generationOptions": { ... }
}
```

### POST /api/preview
Preview generated code without creating the full project

### GET /api/download/{project_id}
Download a generated project by ID

## Technologies Used

- **Backend**: Flask (Python)
- **Frontend**: HTML, CSS, JavaScript
- **Template Engine**: Jinja2
- **External API**: Spring Initializr
- **Generated Projects**: Spring Boot 3.x, Gradle, Java 17/21

## Project Structure

```
.
├── app.py                      # Flask application
├── requirements.txt            # Python dependencies
├── services/
│   ├── initializr_service.py   # Spring Initializr integration
│   ├── code_generator_service.py  # Code generation logic
│   └── project_modifier_service.py # ZIP manipulation
├── templates/
│   ├── index.html              # Main web interface
│   └── java/                   # Java code templates
│       ├── controller.java.j2
│       ├── service.java.j2
│       ├── service_impl.java.j2
│       ├── dto.java.j2
│       ├── exception_handler.java.j2
│       └── error_response.java.j2
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
└── generated_projects/         # Output directory
```

## Troubleshooting

### Spring Initializr Connection Issues
- Ensure you have internet connectivity
- Check if https://start.spring.io is accessible
- Verify firewall settings

### Generation Errors
- Validate all required fields are filled
- Ensure package names follow Java conventions
- Check that endpoint configurations are valid

### Port Already in Use
If port 5000 is already in use, modify `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```

## License

This project is provided as-is for educational and development purposes.

## Contributing

Feel free to submit issues, fork the repository, and create pull requests for any improvements.

## Future Enhancements

- Support for JPA entities and repositories
- Database schema generation
- Integration test generation
- OpenAPI/Swagger documentation enhancement
- Custom template support
- Docker configuration generation
- CI/CD pipeline templates
