# Deployment Guide - Spring Boot API Generator

## Table of Contents
1. [Overview](#overview)
2. [Development Deployment](#development-deployment)
3. [Docker Deployment](#docker-deployment)
4. [Production Deployment](#production-deployment)
5. [Cloud Deployment](#cloud-deployment)
6. [Server Configuration](#server-configuration)
7. [Security Configuration](#security-configuration)
8. [Monitoring & Logging](#monitoring--logging)
9. [Backup & Recovery](#backup--recovery)
10. [Troubleshooting Deployment](#troubleshooting-deployment)

## Overview

This guide covers deployment options for the Spring Boot API Generator application, from local development to production cloud environments.

### Deployment Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     Load Balancer                        │
│                    (Nginx/HAProxy)                       │
└────────────────────┬────────────────────────────────────┘
                     │
     ┌───────────────┼───────────────┐
     │               │               │
┌────▼────┐    ┌────▼────┐    ┌────▼────┐
│  App    │    │  App    │    │  App    │
│Instance │    │Instance │    │Instance │
│  (5001) │    │  (5002) │    │  (5003) │
└─────────┘    └─────────┘    └─────────┘
     │               │               │
     └───────────────┼───────────────┘
                     │
              ┌──────▼──────┐
              │  File Store │
              │    (NFS)    │
              └─────────────┘
```

## Development Deployment

### Local Development

#### 1. Basic Setup

```bash
# Clone repository
git clone https://github.com/yourusername/spring-boot-api-generator.git
cd spring-boot-api-generator

# Create virtual environment
python -m venv venv

# Activate virtual environment
source venv/bin/activate  # Unix/MacOS
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt

# Run application
python app.py
```

#### 2. Development Configuration

Create `.env` file:
```env
# Flask Configuration
FLASK_ENV=development
FLASK_DEBUG=True
FLASK_PORT=5000
SECRET_KEY=dev-secret-key-change-in-production

# Application Configuration
GENERATED_PROJECTS_DIR=generated_projects
MAX_FILE_SIZE_MB=10
CACHE_TIMEOUT=900

# Spring Initializr
INITIALIZR_BASE_URL=https://start.spring.io
INITIALIZR_TIMEOUT=30
RETRY_COUNT=3
RETRY_DELAY_BASE=1

# Logging
LOG_LEVEL=DEBUG
LOG_FILE=app.log
```

#### 3. Run with Flask CLI

```bash
# Set environment variables
export FLASK_APP=app.py
export FLASK_ENV=development

# Run with auto-reload
flask run --host=0.0.0.0 --port=5000 --reload

# Run with debugger
flask run --debug
```

### Development Tools

#### Using Make

Create `Makefile`:
```makefile
.PHONY: install run test clean

install:
	pip install -r requirements.txt

run:
	python app.py

test:
	python -m pytest

clean:
	find . -type d -name __pycache__ -exec rm -rf {} +
	rm -rf generated_projects/*

dev:
	FLASK_ENV=development flask run --reload

prod:
	gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

## Docker Deployment

### Dockerfile

```dockerfile
# Multi-stage build for smaller image
FROM python:3.9-slim as builder

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

# Production stage
FROM python:3.9-slim

WORKDIR /app

# Copy Python dependencies from builder
COPY --from=builder /root/.local /root/.local

# Copy application files
COPY . .

# Create non-root user
RUN useradd -m -r apiuser && \
    chown -R apiuser:apiuser /app && \
    mkdir -p /app/generated_projects && \
    chown -R apiuser:apiuser /app/generated_projects

USER apiuser

# Make sure scripts in .local are callable
ENV PATH=/root/.local/bin:$PATH

EXPOSE 5000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD python -c "import requests; requests.get('http://localhost:5000/api/v1/health')" || exit 1

CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "4", "--timeout", "120", "app:app"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  api-generator:
    build: .
    ports:
      - "5000:5000"
    environment:
      - FLASK_ENV=production
      - SECRET_KEY=${SECRET_KEY}
      - INITIALIZR_BASE_URL=https://start.spring.io
    volumes:
      - ./generated_projects:/app/generated_projects
      - ./logs:/app/logs
    restart: unless-stopped
    networks:
      - api-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5000/api/v1/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - api-generator
    networks:
      - api-network
    restart: unless-stopped

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"
    networks:
      - api-network
    restart: unless-stopped

networks:
  api-network:
    driver: bridge

volumes:
  generated_projects:
  logs:
```

### Building and Running

```bash
# Build image
docker build -t spring-boot-api-generator:latest .

# Run container
docker run -d \
  --name api-generator \
  -p 5000:5000 \
  -v $(pwd)/generated_projects:/app/generated_projects \
  -e FLASK_ENV=production \
  spring-boot-api-generator:latest

# Using Docker Compose
docker-compose up -d

# View logs
docker logs -f api-generator

# Stop container
docker stop api-generator

# Remove container
docker rm api-generator
```

## Production Deployment

### Using Gunicorn

#### Installation

```bash
pip install gunicorn
```

#### Configuration

Create `gunicorn_config.py`:
```python
import multiprocessing

# Server socket
bind = "0.0.0.0:5000"
backlog = 2048

# Worker processes
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"
worker_connections = 1000
max_requests = 1000
max_requests_jitter = 50
timeout = 120
graceful_timeout = 30
keepalive = 2

# Logging
accesslog = "/var/log/gunicorn/access.log"
errorlog = "/var/log/gunicorn/error.log"
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# Process naming
proc_name = "api-generator"

# Server mechanics
daemon = False
pidfile = "/var/run/gunicorn.pid"
user = "www-data"
group = "www-data"
tmp_upload_dir = "/tmp"

# SSL
keyfile = None
certfile = None
```

#### Running Gunicorn

```bash
# Basic command
gunicorn app:app

# With configuration file
gunicorn -c gunicorn_config.py app:app

# With command line options
gunicorn \
  --bind 0.0.0.0:5000 \
  --workers 4 \
  --timeout 120 \
  --log-level info \
  --access-logfile logs/access.log \
  --error-logfile logs/error.log \
  app:app
```

### Using uWSGI

#### Installation

```bash
pip install uwsgi
```

#### Configuration

Create `uwsgi.ini`:
```ini
[uwsgi]
module = app:app
master = true
processes = 4
threads = 2

socket = /tmp/api-generator.sock
chmod-socket = 666
vacuum = true

die-on-term = true

# Logging
logto = /var/log/uwsgi/api-generator.log

# Process management
pidfile = /var/run/uwsgi.pid
harakiri = 120
max-requests = 5000

# Static files
static-map = /static=static

# Buffer size
buffer-size = 32768
```

#### Running uWSGI

```bash
# With INI file
uwsgi --ini uwsgi.ini

# With command line
uwsgi --http :5000 --module app:app --processes 4 --threads 2

# As a service
sudo systemctl start uwsgi
```

### Systemd Service

Create `/etc/systemd/system/api-generator.service`:

```ini
[Unit]
Description=Spring Boot API Generator
After=network.target

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=/opt/api-generator
Environment="PATH=/opt/api-generator/venv/bin"
ExecStart=/opt/api-generator/venv/bin/gunicorn \
    --workers 4 \
    --bind unix:/tmp/api-generator.sock \
    --timeout 120 \
    --log-level info \
    --access-logfile /var/log/api-generator/access.log \
    --error-logfile /var/log/api-generator/error.log \
    app:app

Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

#### Service Management

```bash
# Reload systemd
sudo systemctl daemon-reload

# Start service
sudo systemctl start api-generator

# Enable auto-start
sudo systemctl enable api-generator

# Check status
sudo systemctl status api-generator

# View logs
sudo journalctl -u api-generator -f

# Restart service
sudo systemctl restart api-generator

# Stop service
sudo systemctl stop api-generator
```

### Nginx Configuration

Create `/etc/nginx/sites-available/api-generator`:

```nginx
upstream api_generator {
    server unix:/tmp/api-generator.sock fail_timeout=0;
    # Or for TCP
    # server 127.0.0.1:5000;
}

# Rate limiting
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
limit_conn_zone $binary_remote_addr zone=addr:10m;

server {
    listen 80;
    server_name api-generator.example.com;

    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api-generator.example.com;

    # SSL Configuration
    ssl_certificate /etc/ssl/certs/api-generator.crt;
    ssl_certificate_key /etc/ssl/private/api-generator.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # Security headers
    add_header X-Frame-Options "DENY";
    add_header X-Content-Type-Options "nosniff";
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Logging
    access_log /var/log/nginx/api-generator-access.log;
    error_log /var/log/nginx/api-generator-error.log;

    # Rate limiting
    limit_req zone=api burst=20 nodelay;
    limit_conn addr 10;

    # File upload size
    client_max_body_size 10M;

    # Timeouts
    proxy_connect_timeout 120s;
    proxy_send_timeout 120s;
    proxy_read_timeout 120s;

    location / {
        proxy_pass http://api_generator;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket support (for SSE)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    location /static {
        alias /opt/api-generator/static;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    location /api/v1/progress {
        proxy_pass http://api_generator;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;

        # SSE specific
        proxy_set_header Connection '';
        proxy_http_version 1.1;
        chunked_transfer_encoding off;
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 86400s;
    }

    location /health {
        access_log off;
        proxy_pass http://api_generator/api/v1/health;
    }
}
```

#### Enable Site

```bash
# Create symbolic link
sudo ln -s /etc/nginx/sites-available/api-generator /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

## Cloud Deployment

### AWS Deployment

#### EC2 Instance

```bash
# Launch EC2 instance (Ubuntu 22.04 LTS)
# Security group: Allow HTTP (80), HTTPS (443), SSH (22)

# Connect to instance
ssh -i your-key.pem ubuntu@ec2-instance-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install python3-pip python3-venv nginx supervisor git -y

# Clone repository
git clone https://github.com/yourusername/spring-boot-api-generator.git
cd spring-boot-api-generator

# Setup virtual environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install gunicorn

# Configure and start application
sudo supervisorctl start api-generator
```

#### Elastic Beanstalk

Create `.ebextensions/python.config`:
```yaml
option_settings:
  aws:elasticbeanstalk:container:python:
    WSGIPath: app.py
  aws:elasticbeanstalk:application:environment:
    FLASK_ENV: production
    INITIALIZR_BASE_URL: https://start.spring.io

packages:
  yum:
    git: []
    gcc: []

container_commands:
  01_install_dependencies:
    command: "pip install -r requirements.txt"
  02_create_directories:
    command: "mkdir -p generated_projects"
```

Deploy:
```bash
# Install EB CLI
pip install awsebcli

# Initialize Elastic Beanstalk
eb init -p python-3.9 api-generator

# Create environment
eb create api-generator-env

# Deploy
eb deploy

# Open in browser
eb open
```

### Google Cloud Platform

#### App Engine

Create `app.yaml`:
```yaml
runtime: python39
entrypoint: gunicorn -b :$PORT app:app

env_variables:
  FLASK_ENV: production
  INITIALIZR_BASE_URL: https://start.spring.io

automatic_scaling:
  target_cpu_utilization: 0.65
  min_instances: 1
  max_instances: 10

handlers:
- url: /static
  static_dir: static
  expiration: "30d"

- url: /.*
  script: auto
  secure: always
```

Deploy:
```bash
# Install gcloud CLI
# Initialize gcloud
gcloud init

# Deploy application
gcloud app deploy

# View application
gcloud app browse

# View logs
gcloud app logs tail -s default
```

#### Google Kubernetes Engine (GKE)

Create `k8s-deployment.yaml`:
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-generator
spec:
  replicas: 3
  selector:
    matchLabels:
      app: api-generator
  template:
    metadata:
      labels:
        app: api-generator
    spec:
      containers:
      - name: api-generator
        image: gcr.io/your-project/api-generator:latest
        ports:
        - containerPort: 5000
        env:
        - name: FLASK_ENV
          value: production
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 500m
            memory: 512Mi
---
apiVersion: v1
kind: Service
metadata:
  name: api-generator-service
spec:
  type: LoadBalancer
  selector:
    app: api-generator
  ports:
    - port: 80
      targetPort: 5000
```

Deploy to GKE:
```bash
# Create cluster
gcloud container clusters create api-generator-cluster \
  --num-nodes=3 \
  --zone=us-central1-a

# Get credentials
gcloud container clusters get-credentials api-generator-cluster

# Deploy application
kubectl apply -f k8s-deployment.yaml

# Get external IP
kubectl get services
```

### Azure Deployment

#### Azure App Service

```bash
# Create resource group
az group create --name api-generator-rg --location eastus

# Create app service plan
az appservice plan create \
  --name api-generator-plan \
  --resource-group api-generator-rg \
  --sku B1 \
  --is-linux

# Create web app
az webapp create \
  --resource-group api-generator-rg \
  --plan api-generator-plan \
  --name api-generator-app \
  --runtime "PYTHON|3.9"

# Configure deployment from GitHub
az webapp deployment source config \
  --name api-generator-app \
  --resource-group api-generator-rg \
  --repo-url https://github.com/yourusername/api-generator \
  --branch main \
  --manual-integration

# Set environment variables
az webapp config appsettings set \
  --resource-group api-generator-rg \
  --name api-generator-app \
  --settings FLASK_ENV=production
```

### Heroku Deployment

Create `Procfile`:
```
web: gunicorn app:app --timeout 120
```

Create `runtime.txt`:
```
python-3.9.16
```

Deploy:
```bash
# Install Heroku CLI
# Login to Heroku
heroku login

# Create app
heroku create api-generator-app

# Set buildpack
heroku buildpacks:set heroku/python

# Deploy
git push heroku main

# Set environment variables
heroku config:set FLASK_ENV=production

# Scale dynos
heroku ps:scale web=2

# View logs
heroku logs --tail
```

## Server Configuration

### Resource Requirements

#### Minimum Requirements
- **CPU**: 2 cores
- **RAM**: 2 GB
- **Storage**: 20 GB
- **Network**: 100 Mbps

#### Recommended Requirements
- **CPU**: 4 cores
- **RAM**: 8 GB
- **Storage**: 50 GB SSD
- **Network**: 1 Gbps

### Operating System Setup

#### Ubuntu 22.04 LTS

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y \
  python3-pip \
  python3-venv \
  python3-dev \
  build-essential \
  nginx \
  supervisor \
  git \
  curl \
  vim \
  htop \
  ufw

# Configure firewall
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# Create application user
sudo useradd -m -s /bin/bash apiuser
sudo usermod -aG sudo apiuser

# Set up application directory
sudo mkdir -p /opt/api-generator
sudo chown apiuser:apiuser /opt/api-generator
```

### Performance Tuning

#### System Limits

Edit `/etc/security/limits.conf`:
```
* soft nofile 65535
* hard nofile 65535
* soft nproc 32768
* hard nproc 32768
```

#### Sysctl Configuration

Edit `/etc/sysctl.conf`:
```
# Network tuning
net.core.somaxconn = 65535
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 30
net.ipv4.ip_local_port_range = 1024 65535

# File system
fs.file-max = 2097152
```

Apply changes:
```bash
sudo sysctl -p
```

## Security Configuration

### SSL/TLS Setup

#### Let's Encrypt with Certbot

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d api-generator.example.com

# Auto-renewal
sudo certbot renew --dry-run

# Add to crontab
0 0,12 * * * /usr/bin/certbot renew --quiet
```

### Application Security

#### Environment Variables

```bash
# Generate secret key
python -c 'import secrets; print(secrets.token_hex(32))'

# Set in production
export SECRET_KEY='your-generated-secret-key'
export FLASK_ENV='production'
export DEBUG='False'
```

#### Security Headers

```python
# In app.py
from flask_talisman import Talisman

# Force HTTPS
Talisman(app, force_https=True)

@app.after_request
def set_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response
```

### Firewall Configuration

```bash
# UFW (Ubuntu)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable

# iptables
sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 443 -j ACCEPT
sudo iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
sudo iptables -P INPUT DROP
```

## Monitoring & Logging

### Application Monitoring

#### Prometheus Integration

```python
# Install prometheus-flask-exporter
pip install prometheus-flask-exporter

# In app.py
from prometheus_flask_exporter import PrometheusMetrics

metrics = PrometheusMetrics(app)

# Custom metrics
metrics.info('api_generator_info', 'Application info', version='2.0.0')
```

#### Health Checks

```python
@app.route('/health')
def health():
    checks = {
        'database': check_database_connection(),
        'initializr': check_initializr_availability(),
        'disk_space': check_disk_space(),
        'memory': check_memory_usage()
    }

    status = 'healthy' if all(checks.values()) else 'unhealthy'
    status_code = 200 if status == 'healthy' else 503

    return jsonify({
        'status': status,
        'checks': checks,
        'timestamp': datetime.utcnow().isoformat()
    }), status_code
```

### Logging Configuration

#### Structured Logging

```python
import logging
import json
from pythonjsonlogger import jsonlogger

# Configure JSON logging
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter()
logHandler.setFormatter(formatter)

logger = logging.getLogger()
logger.addHandler(logHandler)
logger.setLevel(logging.INFO)
```

#### Log Rotation

```python
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler(
        'logs/api-generator.log',
        maxBytes=10485760,  # 10MB
        backupCount=10
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
```

### ELK Stack Integration

#### Filebeat Configuration

```yaml
filebeat.inputs:
- type: log
  enabled: true
  paths:
    - /var/log/api-generator/*.log
  json.keys_under_root: true
  json.add_error_key: true

output.elasticsearch:
  hosts: ["localhost:9200"]
  index: "api-generator-%{+yyyy.MM.dd}"

processors:
  - add_host_metadata:
      when.not.contains:
        tags: forwarded
```

## Backup & Recovery

### Backup Strategy

#### Automated Backups

```bash
#!/bin/bash
# backup.sh

# Configuration
BACKUP_DIR="/backup/api-generator"
APP_DIR="/opt/api-generator"
DATE=$(date +%Y%m%d_%H%M%S)

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup application files
tar -czf $BACKUP_DIR/app_$DATE.tar.gz $APP_DIR

# Backup generated projects
tar -czf $BACKUP_DIR/projects_$DATE.tar.gz $APP_DIR/generated_projects

# Backup configuration
cp /etc/nginx/sites-available/api-generator $BACKUP_DIR/nginx_$DATE.conf
cp /etc/systemd/system/api-generator.service $BACKUP_DIR/systemd_$DATE.service

# Remove old backups (keep last 7 days)
find $BACKUP_DIR -type f -mtime +7 -delete

# Upload to S3 (optional)
aws s3 sync $BACKUP_DIR s3://your-backup-bucket/api-generator/
```

Add to crontab:
```bash
0 2 * * * /opt/scripts/backup.sh
```

### Recovery Procedure

```bash
#!/bin/bash
# restore.sh

# Configuration
BACKUP_DIR="/backup/api-generator"
APP_DIR="/opt/api-generator"
RESTORE_DATE=$1

if [ -z "$RESTORE_DATE" ]; then
    echo "Usage: ./restore.sh YYYYMMDD_HHMMSS"
    exit 1
fi

# Stop services
sudo systemctl stop api-generator
sudo systemctl stop nginx

# Restore application files
tar -xzf $BACKUP_DIR/app_$RESTORE_DATE.tar.gz -C /

# Restore generated projects
tar -xzf $BACKUP_DIR/projects_$RESTORE_DATE.tar.gz -C /

# Restore configuration
sudo cp $BACKUP_DIR/nginx_$RESTORE_DATE.conf /etc/nginx/sites-available/api-generator
sudo cp $BACKUP_DIR/systemd_$RESTORE_DATE.service /etc/systemd/system/api-generator.service

# Reload configurations
sudo systemctl daemon-reload
sudo nginx -t && sudo systemctl reload nginx

# Start services
sudo systemctl start api-generator
sudo systemctl start nginx

echo "Restore completed"
```

## Troubleshooting Deployment

### Common Issues

#### 1. Port Already in Use

```bash
# Find process using port
sudo lsof -i :5000
sudo netstat -tulpn | grep :5000

# Kill process
sudo kill -9 <PID>
```

#### 2. Permission Denied

```bash
# Fix file permissions
sudo chown -R www-data:www-data /opt/api-generator
sudo chmod -R 755 /opt/api-generator
sudo chmod -R 777 /opt/api-generator/generated_projects
```

#### 3. Module Import Errors

```bash
# Verify virtual environment
which python
python --version

# Reinstall dependencies
pip install --upgrade -r requirements.txt
```

#### 4. Nginx 502 Bad Gateway

```bash
# Check if application is running
sudo systemctl status api-generator

# Check socket file exists
ls -la /tmp/api-generator.sock

# Check Nginx error logs
sudo tail -f /var/log/nginx/error.log
```

#### 5. SSL Certificate Issues

```bash
# Test SSL configuration
openssl s_client -connect api-generator.example.com:443

# Renew certificate
sudo certbot renew --force-renewal

# Verify Nginx configuration
sudo nginx -t
```

### Performance Issues

#### Slow Response Times

```bash
# Check CPU and memory usage
htop
free -h

# Check disk I/O
iostat -x 1

# Check network connections
netstat -an | grep ESTABLISHED | wc -l

# Increase worker processes
# In gunicorn_config.py
workers = multiprocessing.cpu_count() * 2 + 1
```

#### High Memory Usage

```python
# Add memory profiling
from memory_profiler import profile

@profile
def memory_intensive_function():
    pass

# Limit worker memory
# In gunicorn_config.py
max_requests = 1000
max_requests_jitter = 50
```

### Debugging Production Issues

#### Enable Debug Mode (Temporarily)

```python
# CAUTION: Only for debugging, disable immediately after
app.config['DEBUG'] = True
app.config['PROPAGATE_EXCEPTIONS'] = True
```

#### Remote Debugging

```python
# Using debugpy
import debugpy

debugpy.listen(("0.0.0.0", 5678))
debugpy.wait_for_client()
```

#### Application Logs

```bash
# View application logs
tail -f /var/log/api-generator/app.log

# View Gunicorn logs
tail -f /var/log/gunicorn/error.log

# View Nginx logs
tail -f /var/log/nginx/error.log
tail -f /var/log/nginx/access.log

# View system logs
journalctl -u api-generator -f
```

### Health Check Failures

```bash
# Manual health check
curl http://localhost:5000/api/v1/health

# Check service dependencies
ping start.spring.io
curl -I https://start.spring.io

# Check disk space
df -h

# Check memory
free -m
```

---

**Last Updated:** January 2024 | **Version:** 2.0.0