package com.example.testapi.dto.response;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;




/**
 * Response DTO for HelloResponse
 * Generated on: 2025-10-27 00:49:03
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HelloResponse {


    
    /**
     * Hello message
     */
    
    
    private String message;


}