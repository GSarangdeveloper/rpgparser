package com.example.testapi.service;


import com.example.testapi.dto.request.SayHelloRequest;


import com.example.testapi.dto.response.HelloResponse;

import java.util.List;

/**
 * Service interface for HelloService
 * Generated on: 2025-10-27 00:49:03
 */
public interface HelloService {


    /**
     * Say hello
     */
    HelloResponse sayHello(SayHelloRequest sayHelloRequest);


}