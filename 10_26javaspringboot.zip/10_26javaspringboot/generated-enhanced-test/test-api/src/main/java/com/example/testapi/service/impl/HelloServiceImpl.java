package com.example.testapi.service.impl;

import com.example.testapi.service.HelloService;

import com.example.testapi.dto.request.SayHelloRequest;


import com.example.testapi.dto.response.HelloResponse;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.ArrayList;

/**
 * Service implementation for HelloService
 * Generated on: 2025-10-27 00:49:03
 */
@Service

@Slf4j

public class HelloServiceImpl implements HelloService {


    @Override
    public HelloResponse sayHello(SayHelloRequest sayHelloRequest) {
        
        log.info("Executing sayHello");
        
        // TODO: Implement business logic
        
        return null; // Replace with actual implementation
        
    }


}