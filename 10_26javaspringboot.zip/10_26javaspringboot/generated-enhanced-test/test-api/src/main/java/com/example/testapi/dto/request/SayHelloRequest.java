package com.example.testapi.dto.request;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;




/**
 * Request DTO for SayHelloRequest
 * Generated on: 2025-10-27 00:49:03
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SayHelloRequest {


}