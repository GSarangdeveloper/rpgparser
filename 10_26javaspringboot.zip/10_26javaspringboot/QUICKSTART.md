# Quick Start Guide

## 🚀 Get Started in 3 Minutes

### Step 1: Install Dependencies (30 seconds)
```bash
pip install -r requirements.txt
```

### Step 2: Start the Application (10 seconds)
```bash
python app.py
```

### Step 3: Open Browser (5 seconds)
Navigate to: **http://localhost:5000**

---

## 📝 Minimal Example

### Using the Web Interface

1. **Project Configuration**
   - Project Name: `my-api`
   - Group ID: `com.example`
   - Artifact ID: `my-api`
   - Package Name: `com.example.myapi`

2. **Add One Endpoint**
   - Name: `hello`
   - HTTP Method: `GET`
   - Path: `/hello`
   - Response Type: `Single Object`
   - Response DTO: `HelloResponse`

3. Click **"Generate Project"**

4. Click **"Download Project"**

---

## 🎯 Run Your Generated Project

```bash
# Extract the ZIP
unzip my-api.zip
cd my-api

# Run the application
./gradlew bootRun

# Test the endpoint
curl http://localhost:8080/api/v1/hello
```

---

## 📚 Key Files

| File | Purpose |
|------|---------|
| `README.md` | Full documentation |
| `USAGE.md` | Detailed usage guide |
| `example_config.json` | Sample configuration |
| `PROJECT_SUMMARY.md` | Technical overview |

---

## 🔧 Troubleshooting

**Problem**: Port 5000 already in use
**Solution**: Edit `app.py`, change port to 5001

**Problem**: Can't connect to Spring Initializr
**Solution**: Check internet connection

**Problem**: Generated project won't run
**Solution**: Ensure Java 17+ is installed

---

## 💡 Next Steps

1. ✅ Generate your first project
2. ✅ Explore the generated code
3. ✅ Implement business logic in service classes
4. ✅ Add database configuration
5. ✅ Test your API endpoints

---

## 🎓 Learn More

- Full specification: `SPRING_BOOT_API_GENERATOR_SPEC.md`
- Usage examples: `USAGE.md`
- API reference: `example_config.json`

---

**Need Help?** Check the README.md for detailed instructions.
