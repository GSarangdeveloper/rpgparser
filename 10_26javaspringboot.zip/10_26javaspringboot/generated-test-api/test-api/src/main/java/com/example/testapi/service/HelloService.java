package com.example.testapi.service;



import com.example.testapi.dto.response.HelloResponse;

import java.util.List;

/**
 * Service interface for HelloService
 * Generated on: 2025-10-26 19:27:50
 */
public interface HelloService {


    /**
     * Say hello
     */
    HelloResponse sayHello();


}