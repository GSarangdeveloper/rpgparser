package com.example.testapi.controller;

import com.example.testapi.service.HelloService;


import com.example.testapi.dto.response.HelloResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.Validated;
import lombok.RequiredArgsConstructor;

import lombok.extern.slf4j.Slf4j;

import jakarta.validation.Valid;
import java.util.List;

/**
 * REST Controller for Hello
 * Generated on: 2025-10-26 19:27:50
 */
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Validated

@Slf4j

public class HelloController {

    private final HelloService helloservice;


    /**
     * Say hello
     */
    @GetMapping("/hello")
    public ResponseEntity<HelloResponse> sayHello() {
        
        log.info("sayHello called with parameters: ");
        
        HelloResponse result = helloservice.sayHello();
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }


}