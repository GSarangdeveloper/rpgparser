package com.example.testapi.service.impl;

import com.example.testapi.service.HelloService;


import com.example.testapi.dto.response.HelloResponse;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.ArrayList;

/**
 * Service implementation for HelloService
 * Generated on: 2025-10-26 19:27:50
 */
@Service

@Slf4j

public class HelloServiceImpl implements HelloService {


    @Override
    public HelloResponse sayHello() {
        
        log.info("Executing sayHello");
        
        // TODO: Implement business logic
        
        return null; // Replace with actual implementation
        
    }


}