# API Documentation - Spring Boot API Generator

## Table of Contents
1. [Overview](#overview)
2. [Authentication](#authentication)
3. [Base URL](#base-url)
4. [API Versioning](#api-versioning)
5. [Request/Response Format](#requestresponse-format)
6. [Error Handling](#error-handling)
7. [Rate Limiting](#rate-limiting)
8. [Endpoints](#endpoints)
   - [Project Generation](#project-generation)
   - [File Operations](#file-operations)
   - [System Operations](#system-operations)
   - [Legacy Endpoints](#legacy-endpoints)
9. [Webhooks](#webhooks)
10. [Examples](#examples)

## Overview

The Spring Boot API Generator provides a RESTful API for generating Spring Boot applications from various API specification formats. The API follows REST principles and returns JSON responses.

### Key Features
- RESTful design
- JSON request/response format
- Comprehensive error handling
- Real-time progress tracking via SSE
- File upload support
- Multiple specification format support

## Authentication

Currently, the API does not require authentication for public endpoints. Future versions will support:
- API key authentication
- OAuth 2.0
- JWT tokens

## Base URL

### Development
```
http://localhost:5000/api/v1
```

### Production
```
https://api-generator.example.com/api/v1
```

## API Versioning

The API uses URL path versioning:
- Current version: `v1`
- Legacy endpoints: `/api` (deprecated, redirects to v1)

Version changes will be communicated through:
- API response headers: `X-API-Version: 1.0.0`
- Deprecation notices: `X-API-Deprecated: true`
- Sunset headers: `Sunset: Sat, 31 Dec 2024 23:59:59 GMT`

## Request/Response Format

### Request Headers
```http
Content-Type: application/json
Accept: application/json
X-Request-ID: unique-request-id (optional)
```

### Response Headers
```http
Content-Type: application/json
X-Request-ID: unique-request-id
X-Response-Time: 123ms
X-Rate-Limit-Remaining: 99
```

### Standard Response Format

#### Success Response
```json
{
  "success": true,
  "data": {},
  "message": "Operation completed successfully",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

#### Error Response
```json
{
  "success": false,
  "error": {
    "id": "20240101120000",
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": {
      "field": "specific_field",
      "additional": "context"
    },
    "timestamp": "2024-01-01T12:00:00Z"
  }
}
```

## Error Handling

### HTTP Status Codes

| Status Code | Description | When Used |
|-------------|-------------|-----------|
| 200 OK | Successful request | GET, PUT, PATCH success |
| 201 Created | Resource created | POST success |
| 204 No Content | Success with no content | DELETE success |
| 400 Bad Request | Invalid request | Validation errors |
| 401 Unauthorized | Authentication required | Missing/invalid auth |
| 403 Forbidden | Access denied | Insufficient permissions |
| 404 Not Found | Resource not found | Invalid ID/path |
| 408 Request Timeout | Request timed out | Long operations |
| 413 Payload Too Large | Request too large | File size exceeded |
| 429 Too Many Requests | Rate limit exceeded | Too many requests |
| 500 Internal Server Error | Server error | Unexpected errors |
| 503 Service Unavailable | Service down | Maintenance/overload |

### Error Codes

| Code | Description | Resolution |
|------|-------------|------------|
| `VALIDATION_ERROR` | Input validation failed | Check field requirements |
| `PARSING_ERROR` | Specification parsing failed | Verify specification format |
| `GENERATION_ERROR` | Code generation failed | Check configuration |
| `INITIALIZR_ERROR` | Spring Initializr error | Retry or check service status |
| `FILE_SYSTEM_ERROR` | File operation failed | Check disk space/permissions |
| `UPLOAD_TIMEOUT` | Upload timed out | Reduce file size or retry |
| `FILE_TOO_LARGE` | File exceeds limit | Use smaller file (<10MB) |
| `NOT_FOUND` | Resource not found | Verify resource ID |
| `INTERNAL_ERROR` | Unexpected error | Contact support |

## Rate Limiting

### Limits
- Anonymous: 100 requests per hour
- Authenticated: 1000 requests per hour
- File uploads: 10 per hour

### Headers
```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 99
X-RateLimit-Reset: 1609459200
```

### Rate Limit Response
```json
{
  "success": false,
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Too many requests",
    "retry_after": 3600
  }
}
```

## Endpoints

### Project Generation

#### 1. Generate Project

Generate a complete Spring Boot project from specification.

**Endpoint:** `POST /api/v1/generate/project`

**Request Body:**
```json
{
  "projectConfiguration": {
    "projectName": "string",
    "description": "string",
    "groupId": "string",
    "artifactId": "string",
    "packageName": "string",
    "springBootVersion": "string",
    "javaVersion": "string",
    "buildTool": "gradle|gradle-kotlin",
    "packaging": "jar|war"
  },
  "dependencyConfiguration": {
    "database": "h2|postgresql|mysql|mongodb",
    "security": boolean,
    "documentation": boolean,
    "caching": boolean,
    "messaging": boolean
  },
  "apiSpecification": {
    "baseControllerPath": "string",
    "controllerClassName": "string",
    "description": "string",
    "endpoints": [
      {
        "id": "string",
        "name": "string",
        "httpMethod": "GET|POST|PUT|DELETE|PATCH",
        "path": "string",
        "description": "string",
        "operationId": "string",
        "requestParameters": [
          {
            "name": "string",
            "type": "string",
            "parameterLocation": "PATH|QUERY|HEADER",
            "required": boolean,
            "defaultValue": "string",
            "description": "string"
          }
        ],
        "requestBody": {
          "required": boolean,
          "type": "string",
          "fields": [
            {
              "name": "string",
              "type": "string",
              "required": boolean,
              "description": "string",
              "validation": {
                "notNull": boolean,
                "notBlank": boolean,
                "size": {
                  "min": number,
                  "max": number
                },
                "pattern": "string",
                "email": boolean
              }
            }
          ]
        },
        "response": {
          "type": "SINGLE_OBJECT|LIST|VOID|CUSTOM",
          "httpStatus": "string",
          "dataType": "string",
          "wrapInResponseEntity": boolean,
          "fields": []
        },
        "errorResponses": [
          {
            "httpStatus": number,
            "description": "string",
            "exceptionType": "string"
          }
        ]
      }
    ]
  },
  "generationOptions": {
    "includeServiceLayer": boolean,
    "includeExceptionHandling": boolean,
    "includeValidation": boolean,
    "includeLogging": boolean,
    "generateTests": boolean,
    "generateCustomExceptions": boolean,
    "generateRepository": boolean,
    "generateSwaggerDocs": boolean
  }
}
```

**Response:**
```json
{
  "success": true,
  "projectId": "uuid-string",
  "message": "Project generated successfully",
  "downloadUrl": "/api/v1/download/uuid-string",
  "expiresAt": "2024-01-01T01:00:00Z"
}
```

**Curl Example:**
```bash
curl -X POST http://localhost:5000/api/v1/generate/project \
  -H "Content-Type: application/json" \
  -d '{
    "projectConfiguration": {
      "projectName": "User API",
      "groupId": "com.example",
      "artifactId": "user-api",
      "packageName": "com.example.userapi",
      "springBootVersion": "3.2.0",
      "javaVersion": "17",
      "buildTool": "gradle",
      "packaging": "jar"
    },
    "apiSpecification": {
      "baseControllerPath": "/api/v1",
      "controllerClassName": "User",
      "endpoints": []
    },
    "generationOptions": {
      "includeServiceLayer": true,
      "generateTests": true
    }
  }'
```

#### 2. Preview Code

Preview generated code without creating full project.

**Endpoint:** `POST /api/v1/preview/code`

**Request Body:**
```json
{
  "projectConfiguration": {
    "packageName": "string"
  },
  "apiSpecification": {
    "controllerClassName": "string",
    "baseControllerPath": "string",
    "endpoints": []
  }
}
```

**Response:**
```json
{
  "success": true,
  "preview": {
    "controller": "// Controller code...",
    "service": "// Service interface...",
    "serviceImpl": "// Service implementation...",
    "dto": "// DTO classes...",
    "test": "// Test code..."
  }
}
```

#### 3. Download Project

Download generated project as ZIP file.

**Endpoint:** `GET /api/v1/download/{projectId}`

**Path Parameters:**
- `projectId` (required): UUID of generated project

**Response:**
- Content-Type: `application/zip`
- Content-Disposition: `attachment; filename="project-name.zip"`
- Binary ZIP file data

**Curl Example:**
```bash
curl -O http://localhost:5000/api/v1/download/123e4567-e89b-12d3-a456-426614174000
```

### File Operations

#### 1. Upload Specification

Upload and parse API specification file.

**Endpoint:** `POST /api/v1/upload/specification`

**Request:**
- Content-Type: `multipart/form-data`
- Body: Form data with file

**Form Fields:**
- `file` (required): Specification file (.json, .yaml, .yml)

**Response:**
```json
{
  "success": true,
  "data": {
    "projectConfiguration": {},
    "apiSpecification": {}
  },
  "message": "Successfully parsed 10 endpoints from OpenAPI/Swagger",
  "type": "OpenAPI/Swagger|Postman Collection",
  "statistics": {
    "endpoints": 10,
    "controllers": 1,
    "dtos": 5
  }
}
```

**Curl Example:**
```bash
curl -X POST http://localhost:5000/api/v1/upload/specification \
  -F "file=@openapi.yaml"
```

#### 2. Parse Specification Content

Parse specification from text content.

**Endpoint:** `POST /api/v1/parse/specification`

**Request Body:**
```json
{
  "content": "string",
  "format": "openapi-yaml|openapi-json|swagger-yaml|swagger-json|postman-json|custom-json"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "projectConfiguration": {},
    "apiSpecification": {}
  },
  "message": "Successfully parsed specification"
}
```

#### 3. Import from URL

Import specification from remote URL.

**Endpoint:** `POST /api/v1/import/url`

**Request Body:**
```json
{
  "url": "string",
  "headers": {
    "Authorization": "Bearer token"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "projectConfiguration": {},
    "apiSpecification": {}
  }
}
```

### System Operations

#### 1. Health Check

Check system health and service status.

**Endpoint:** `GET /api/v1/health`

**Response:**
```json
{
  "status": "healthy|degraded|unhealthy",
  "timestamp": "2024-01-01T00:00:00Z",
  "services": {
    "initializr": "operational|degraded|down",
    "generator": "operational|degraded|down",
    "validation": "operational|degraded|down",
    "parser": "operational|degraded|down"
  },
  "version": "2.0.0",
  "uptime": 3600,
  "metrics": {
    "projects_generated": 100,
    "active_generations": 2,
    "cache_hit_rate": 0.85
  }
}
```

**HTTP Status:**
- 200: All services operational
- 503: One or more services degraded/down

#### 2. Progress Tracking (SSE)

Track generation progress in real-time.

**Endpoint:** `GET /api/v1/progress/{projectId}`

**Headers:**
```http
Accept: text/event-stream
Cache-Control: no-cache
```

**Response Stream:**
```
event: progress
data: {"stage": "initializing", "progress": 10, "message": "Starting generation", "details": {}}

event: progress
data: {"stage": "downloading", "progress": 30, "message": "Downloading from Spring Initializr", "details": {"url": "https://start.spring.io"}}

event: progress
data: {"stage": "generating", "progress": 60, "message": "Generating controllers", "details": {"current": "UserController", "total": 3}}

event: progress
data: {"stage": "packaging", "progress": 90, "message": "Creating zip file", "details": {"size": "2.5MB"}}

event: complete
data: {"complete": true, "progress": 100, "message": "Generation complete", "projectId": "uuid", "downloadUrl": "/api/v1/download/uuid"}

event: error
data: {"error": true, "message": "Generation failed", "code": "GENERATION_ERROR"}
```

**JavaScript Example:**
```javascript
const eventSource = new EventSource('/api/v1/progress/project-id');

eventSource.addEventListener('progress', (event) => {
  const data = JSON.parse(event.data);
  console.log(`Progress: ${data.progress}% - ${data.message}`);
});

eventSource.addEventListener('complete', (event) => {
  const data = JSON.parse(event.data);
  console.log('Generation complete:', data.downloadUrl);
  eventSource.close();
});

eventSource.addEventListener('error', (event) => {
  console.error('SSE Error:', event);
  eventSource.close();
});
```

#### 3. Get Configuration Options

Get available configuration options and constraints.

**Endpoint:** `GET /api/v1/config/options`

**Response:**
```json
{
  "springBootVersions": ["3.2.0", "3.1.5", "3.0.11"],
  "javaVersions": ["8", "11", "17", "21"],
  "buildTools": ["gradle", "gradle-kotlin"],
  "databases": ["h2", "postgresql", "mysql", "mongodb"],
  "packaging": ["jar", "war"],
  "dependencies": {
    "web": ["spring-web", "spring-webflux"],
    "data": ["spring-data-jpa", "spring-data-mongodb"],
    "security": ["spring-security"],
    "cloud": ["spring-cloud-config", "spring-cloud-eureka"]
  }
}
```

#### 4. Validate Specification

Validate specification without generating project.

**Endpoint:** `POST /api/v1/validate`

**Request Body:**
```json
{
  "specification": {},
  "strict": boolean
}
```

**Response:**
```json
{
  "valid": boolean,
  "errors": [
    {
      "field": "string",
      "message": "string",
      "code": "string"
    }
  ],
  "warnings": [
    {
      "field": "string",
      "message": "string"
    }
  ]
}
```

### Legacy Endpoints

These endpoints are deprecated and will be removed in v2.0.0.

#### Generate Project (Legacy)
- **Endpoint:** `POST /api/generate`
- **Deprecation:** Use `/api/v1/generate/project` instead
- **Removal Date:** December 31, 2024

#### Preview Code (Legacy)
- **Endpoint:** `POST /api/preview`
- **Deprecation:** Use `/api/v1/preview/code` instead
- **Removal Date:** December 31, 2024

#### Download Project (Legacy)
- **Endpoint:** `GET /api/download/{projectId}`
- **Deprecation:** Use `/api/v1/download/{projectId}` instead
- **Removal Date:** December 31, 2024

## Webhooks

Webhooks allow you to receive notifications about generation events.

### Configuration

Register webhook endpoint:
```json
POST /api/v1/webhooks
{
  "url": "https://your-server.com/webhook",
  "events": ["generation.started", "generation.completed", "generation.failed"],
  "secret": "your-webhook-secret"
}
```

### Events

#### generation.started
```json
{
  "event": "generation.started",
  "projectId": "uuid",
  "timestamp": "2024-01-01T00:00:00Z",
  "data": {
    "projectName": "string",
    "type": "string"
  }
}
```

#### generation.completed
```json
{
  "event": "generation.completed",
  "projectId": "uuid",
  "timestamp": "2024-01-01T00:00:00Z",
  "data": {
    "downloadUrl": "string",
    "expiresAt": "string",
    "size": number
  }
}
```

#### generation.failed
```json
{
  "event": "generation.failed",
  "projectId": "uuid",
  "timestamp": "2024-01-01T00:00:00Z",
  "data": {
    "error": "string",
    "code": "string"
  }
}
```

### Webhook Security

Verify webhook signature:
```python
import hmac
import hashlib

def verify_webhook(payload, signature, secret):
    expected = hmac.new(
        secret.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)
```

## Examples

### Complete Example: User Management API

#### 1. Upload OpenAPI Specification

```yaml
# user-api.yaml
openapi: 3.0.0
info:
  title: User Management API
  version: 1.0.0
paths:
  /users:
    get:
      summary: Get all users
      parameters:
        - name: page
          in: query
          schema:
            type: integer
      responses:
        '200':
          description: Success
    post:
      summary: Create user
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                username:
                  type: string
                email:
                  type: string
      responses:
        '201':
          description: Created
```

#### 2. Upload and Parse

```bash
curl -X POST http://localhost:5000/api/v1/upload/specification \
  -F "file=@user-api.yaml" \
  -o parsed.json
```

#### 3. Generate Project

```bash
# Extract parsed data and generate
curl -X POST http://localhost:5000/api/v1/generate/project \
  -H "Content-Type: application/json" \
  -d @parsed.json \
  -o response.json

# Extract project ID
PROJECT_ID=$(jq -r '.projectId' response.json)
```

#### 4. Track Progress

```bash
# Monitor generation progress
curl -N http://localhost:5000/api/v1/progress/$PROJECT_ID
```

#### 5. Download Project

```bash
# Download generated project
curl -O http://localhost:5000/api/v1/download/$PROJECT_ID
```

### Python Client Example

```python
import requests
import json
import time

class APIGeneratorClient:
    def __init__(self, base_url='http://localhost:5000'):
        self.base_url = base_url
        self.session = requests.Session()

    def generate_project(self, config):
        """Generate Spring Boot project"""
        response = self.session.post(
            f'{self.base_url}/api/v1/generate/project',
            json=config
        )
        response.raise_for_status()
        return response.json()

    def track_progress(self, project_id):
        """Track generation progress"""
        url = f'{self.base_url}/api/v1/progress/{project_id}'
        with self.session.get(url, stream=True) as response:
            for line in response.iter_lines():
                if line:
                    if line.startswith(b'data: '):
                        data = json.loads(line[6:])
                        yield data
                        if data.get('complete'):
                            break

    def download_project(self, project_id, output_file):
        """Download generated project"""
        response = self.session.get(
            f'{self.base_url}/api/v1/download/{project_id}'
        )
        response.raise_for_status()
        with open(output_file, 'wb') as f:
            f.write(response.content)
        return output_file

# Usage
client = APIGeneratorClient()

# Generate project
config = {
    'projectConfiguration': {
        'projectName': 'My API',
        'groupId': 'com.example',
        'artifactId': 'my-api',
        'packageName': 'com.example.api'
    },
    'apiSpecification': {
        'endpoints': []
    }
}

result = client.generate_project(config)
project_id = result['projectId']

# Track progress
for progress in client.track_progress(project_id):
    print(f"Progress: {progress['progress']}% - {progress['message']}")

# Download
client.download_project(project_id, 'my-api.zip')
```

### JavaScript/Node.js Client Example

```javascript
const axios = require('axios');
const fs = require('fs');
const EventSource = require('eventsource');

class APIGeneratorClient {
  constructor(baseUrl = 'http://localhost:5000') {
    this.baseUrl = baseUrl;
  }

  async generateProject(config) {
    const response = await axios.post(
      `${this.baseUrl}/api/v1/generate/project`,
      config
    );
    return response.data;
  }

  trackProgress(projectId) {
    return new Promise((resolve, reject) => {
      const eventSource = new EventSource(
        `${this.baseUrl}/api/v1/progress/${projectId}`
      );

      const progress = [];

      eventSource.addEventListener('progress', (event) => {
        const data = JSON.parse(event.data);
        console.log(`Progress: ${data.progress}% - ${data.message}`);
        progress.push(data);
      });

      eventSource.addEventListener('complete', (event) => {
        const data = JSON.parse(event.data);
        eventSource.close();
        resolve({ ...data, progress });
      });

      eventSource.addEventListener('error', (event) => {
        eventSource.close();
        reject(new Error('Progress tracking failed'));
      });
    });
  }

  async downloadProject(projectId, outputFile) {
    const response = await axios.get(
      `${this.baseUrl}/api/v1/download/${projectId}`,
      { responseType: 'arraybuffer' }
    );

    fs.writeFileSync(outputFile, response.data);
    return outputFile;
  }
}

// Usage
async function generateAPI() {
  const client = new APIGeneratorClient();

  try {
    // Generate project
    const config = {
      projectConfiguration: {
        projectName: 'My API',
        groupId: 'com.example',
        artifactId: 'my-api',
        packageName: 'com.example.api'
      },
      apiSpecification: {
        endpoints: []
      }
    };

    const result = await client.generateProject(config);
    console.log('Project ID:', result.projectId);

    // Track progress
    const completion = await client.trackProgress(result.projectId);
    console.log('Generation complete:', completion);

    // Download
    await client.downloadProject(result.projectId, 'my-api.zip');
    console.log('Project downloaded');

  } catch (error) {
    console.error('Error:', error);
  }
}

generateAPI();
```

## API Testing

### Using Postman

Import the Postman collection from `/static/samples/api-generator.postman_collection.json`

### Using curl

Test health check:
```bash
curl http://localhost:5000/api/v1/health
```

### Using httpie

```bash
# Install httpie
pip install httpie

# Test health check
http GET localhost:5000/api/v1/health

# Generate project
http POST localhost:5000/api/v1/generate/project < config.json
```

## SDK Support

Official SDKs are planned for:
- Python
- JavaScript/TypeScript
- Java
- Go
- Ruby

## API Limits

### Request Limits
- Max request size: 10MB
- Max endpoints per project: 100
- Max fields per DTO: 50
- Max path parameters: 10
- Max query parameters: 20

### File Limits
- Max file size: 10MB
- Supported formats: JSON, YAML
- Max files per hour: 10

### Generation Limits
- Max concurrent generations: 5
- Generation timeout: 5 minutes
- Project retention: 24 hours

## Changelog

### v1.0.0 (2024-01-01)
- Initial API release
- Basic project generation
- OpenAPI/Swagger support

### v1.1.0 (2024-02-01)
- Added Postman collection support
- Improved error handling
- Added progress tracking

### v2.0.0 (2024-03-01)
- Complete API redesign
- Added file upload
- Enhanced validation
- Real-time SSE progress
- Custom exception generation

## Support

For API support, please:
1. Check this documentation
2. Review error messages
3. Contact support@example.com
4. Open GitHub issue

## Terms of Service

By using this API, you agree to:
- Not abuse the service
- Respect rate limits
- Not use for malicious purposes
- Provide attribution when required

---

**Last Updated:** January 2024 | **API Version:** 1.0.0 | **Status:** Stable