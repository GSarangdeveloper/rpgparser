# Spring Boot API Generator - Complete POC Specification
## Using Spring Initializr + Traditional Templates + Optional LLM

**Version:** 1.0 POC  
**Last Updated:** January 2025  
**Build Tool:** Gradle  

---

## 📋 TABLE OF CONTENTS

1. [System Overview](#1-system-overview)
2. [Architecture Design](#2-architecture-design)
3. [Data Flow Specification](#3-data-flow-specification)
4. [Component Specifications](#4-component-specifications)
5. [API Specifications](#5-api-specifications)
6. [Template System Design](#6-template-system-design)
7. [User Interface Specification](#7-user-interface-specification)
8. [File Structure & Organization](#8-file-structure--organization)
9. [Integration Points](#9-integration-points)
10. [Configuration & Settings](#10-configuration--settings)
11. [Error Handling Strategy](#11-error-handling-strategy)
12. [POC Implementation Roadmap](#12-poc-implementation-roadmap)

---

## 1. SYSTEM OVERVIEW

### 1.1 Purpose
A web-based tool that generates production-ready Spring Boot REST API projects by:
- Leveraging Spring Initializr for project scaffolding
- Using deterministic templates for business code generation
- Optionally enhancing with LLM-generated documentation

### 1.2 Key Principles
- **Don't Reinvent**: Use Spring Initializr for project structure
- **Deterministic Core**: Use templates for reliable code generation
- **Smart Enhancement**: Use LLM only for value-added features
- **Fast & Reliable**: Prioritize speed and consistency
- **Gradle Build Tool**: All generated projects use Gradle

### 1.3 User Journey
```
Step 1: User fills form with API requirements
        ↓
Step 2: User configures Spring Boot settings
        ↓
Step 3: System generates base project (Spring Initializr with Gradle)
        ↓
Step 4: System generates business code (Templates)
        ↓
Step 5: System injects code into project
        ↓
Step 6: (Optional) System enhances with documentation
        ↓
Step 7: User downloads complete Spring Boot Gradle project
```

### 1.4 Success Metrics for POC
- **Generation Time**: < 10 seconds (acceptable for POC)
- **Success Rate**: > 95% for valid inputs
- **Code Quality**: Compilable, runnable projects
- **User Satisfaction**: Can run `gradle bootRun` immediately

---

## 2. ARCHITECTURE DESIGN

### 2.1 High-Level Architecture

```
┌────────────────────────────────────────────────────────────┐
│                     PRESENTATION LAYER                      │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐ │
│  │  Input Form  │  │ Code Preview │  │  Download UI    │ │
│  │   Module     │  │    Module    │  │     Module      │ │
│  └──────────────┘  └──────────────┘  └─────────────────┘ │
└────────────┬───────────────────────────────────────────────┘
             │
             │ HTTP REST API
             ↓
┌────────────────────────────────────────────────────────────┐
│                     APPLICATION LAYER                       │
│  ┌──────────────────────────────────────────────────────┐ │
│  │         Flask Application (Orchestrator)             │ │
│  │  • Request validation                                │ │
│  │  • Workflow coordination                             │ │
│  │  • Response formatting                               │ │
│  └──────────────┬───────────────────────────────────────┘ │
└─────────────────┼──────────────────────────────────────────┘
                  │
                  ├───────────────┬──────────────┬─────────────
                  ↓               ↓              ↓
┌─────────────────────────────────────────────────────────────┐
│                     SERVICE LAYER                            │
│                                                              │
│  ┌──────────────────┐  ┌──────────────────┐               │
│  │  Initializr      │  │  Code Generator  │               │
│  │  Service         │  │  Service         │               │
│  │                  │  │                  │               │
│  │ • Call API       │  │ • Controllers    │               │
│  │ • Download ZIP   │  │ • Services       │               │
│  │ • Validate       │  │ • DTOs           │               │
│  └──────────────────┘  │ • Exceptions     │               │
│                         └──────────────────┘               │
│                                                              │
│  ┌──────────────────┐  ┌──────────────────┐               │
│  │  Project         │  │  LLM Enhancement │               │
│  │  Modifier        │  │  Service         │               │
│  │                  │  │  (Optional)      │               │
│  │ • Unzip project  │  │                  │               │
│  │ • Inject code    │  │ • JavaDoc        │               │
│  │ • Update configs │  │ • README         │               │
│  │ • Re-zip         │  │ • Examples       │               │
│  └──────────────────┘  └──────────────────┘               │
└─────────────────────────────────────────────────────────────┘
                  │
                  ↓
┌─────────────────────────────────────────────────────────────┐
│                     INTEGRATION LAYER                        │
│                                                              │
│  ┌──────────────────┐  ┌──────────────────┐               │
│  │  Spring          │  │  Vertex AI       │               │
│  │  Initializr API  │  │  API             │               │
│  │  (Gradle build)  │  │  (Optional)      │               │
│  │ start.spring.io  │  │                  │               │
│  └──────────────────┘  └──────────────────┘               │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Component Interaction Flow

```
User Request
     ↓
┌─────────────────────────────────────────┐
│ 1. REQUEST VALIDATION                   │
│    • Validate input schema              │
│    • Check required fields              │
│    • Sanitize inputs                    │
└──────────────┬──────────────────────────┘
               ↓
┌─────────────────────────────────────────┐
│ 2. SPRING INITIALIZR CALL               │
│    • Build configuration (Gradle)       │
│    • Call start.spring.io API           │
│    • Receive base project ZIP           │
│    • Validate ZIP integrity             │
│    Duration: ~2 seconds                 │
└──────────────┬──────────────────────────┘
               ↓
┌─────────────────────────────────────────┐
│ 3. CODE GENERATION                      │
│    • Generate controllers               │
│    • Generate services                  │
│    • Generate DTOs                      │
│    • Generate exception handlers        │
│    • Generate validators                │
│    Duration: ~500ms                     │
└──────────────┬──────────────────────────┘
               ↓
┌─────────────────────────────────────────┐
│ 4. PROJECT MODIFICATION                 │
│    • Unzip base project                 │
│    • Identify package structure         │
│    • Inject generated files             │
│    • Update application.properties      │
│    • Update build.gradle (if needed)    │
│    • Create directory structure         │
│    Duration: ~1 second                  │
└──────────────┬──────────────────────────┘
               ↓
               ├──→ (Optional Path)
               │    ┌──────────────────────┐
               │    │ 5a. LLM ENHANCEMENT  │
               │    │    • Generate JavaDoc│
               │    │    • Create README   │
               │    │    • Add examples    │
               │    │    Duration: ~5-8s   │
               │    └──────────────────────┘
               │
               ↓
┌─────────────────────────────────────────┐
│ 6. FINAL PACKAGING                      │
│    • Re-zip complete project            │
│    • Generate metadata                  │
│    • Create download link               │
│    Duration: ~500ms                     │
└──────────────┬──────────────────────────┘
               ↓
         Download ZIP
```

### 2.3 Layer Responsibilities

#### Presentation Layer
- Collect user inputs
- Display generated code preview
- Handle file downloads
- Show progress indicators
- Display error messages

#### Application Layer
- Coordinate service calls
- Manage application state
- Handle session management
- Format responses
- Error orchestration

#### Service Layer
- Business logic execution
- External API integration
- Code generation logic
- File manipulation
- Data transformation

#### Integration Layer
- External API clients
- Third-party service wrappers
- Basic retry mechanisms

---

## 3. DATA FLOW SPECIFICATION

### 3.1 Input Data Schema

```json
{
  "projectConfiguration": {
    "projectName": "string (required, 3-50 chars)",
    "description": "string (optional, max 200 chars)",
    "groupId": "string (required, Java package format)",
    "artifactId": "string (required, lowercase-hyphen)",
    "packageName": "string (required, Java package format)",
    "springBootVersion": "string (enum: 3.2.0, 3.1.5, 2.7.18)",
    "javaVersion": "string (enum: 17, 21, 11)",
    "buildTool": "gradle",
    "packaging": "string (enum: jar, war)"
  },
  
  "dependencyConfiguration": {
    "database": "string (enum: none, mysql, postgresql, h2, mongodb)",
    "security": "boolean",
    "documentation": "boolean",
    "caching": "boolean",
    "messaging": "boolean"
  },
  
  "apiSpecification": {
    "baseControllerPath": "string (required, URL path format)",
    "controllerClassName": "string (required, PascalCase)",
    "description": "string (optional)",
    
    "endpoints": [
      {
        "id": "string (UUID)",
        "name": "string (required, camelCase)",
        "httpMethod": "enum (GET, POST, PUT, DELETE, PATCH)",
        "path": "string (required, URL path)",
        "description": "string (optional)",
        "operationId": "string (optional)",
        
        "requestParameters": [
          {
            "name": "string (required)",
            "type": "enum (String, Integer, Long, Boolean, Double, LocalDate, LocalDateTime, BigDecimal, Custom)",
            "parameterLocation": "enum (PATH, QUERY, BODY, HEADER)",
            "required": "boolean",
            "defaultValue": "string (optional)",
            "description": "string (optional)",
            "validation": {
              "min": "number (optional)",
              "max": "number (optional)",
              "pattern": "string (regex, optional)",
              "notNull": "boolean",
              "notBlank": "boolean",
              "email": "boolean",
              "size": {"min": number, "max": number}
            }
          }
        ],
        
        "requestBody": {
          "required": "boolean",
          "type": "string (DTO class name)",
          "fields": [
            {
              "name": "string (required)",
              "type": "string (required)",
              "required": "boolean",
              "description": "string (optional)",
              "validation": {object}
            }
          ]
        },
        
        "response": {
          "type": "enum (SINGLE_OBJECT, LIST, PAGINATED, VOID)",
          "wrapInResponseEntity": "boolean (default: true)",
          "httpStatus": "enum (200, 201, 204, etc.)",
          "dataType": "string (DTO class name)",
          "fields": [
            {
              "name": "string",
              "type": "string",
              "description": "string (optional)"
            }
          ]
        },
        
        "errorResponses": [
          {
            "httpStatus": "number",
            "description": "string",
            "exceptionType": "string"
          }
        ]
      }
    ]
  },
  
  "generationOptions": {
    "includeServiceLayer": "boolean (default: true)",
    "includeExceptionHandling": "boolean (default: true)",
    "includeValidation": "boolean (default: true)",
    "includeLogging": "boolean (default: true)",
    "generateTests": "boolean (default: false)",
    "enhanceWithLLM": "boolean (default: false)",
    "generateSwaggerDocs": "boolean (default: true)"
  }
}
```

### 3.2 Spring Initializr Request Mapping (Gradle)

```
User Input → Initializr Parameters

projectConfiguration.projectName → name
projectConfiguration.groupId → groupId
projectConfiguration.artifactId → artifactId
projectConfiguration.packageName → packageName
projectConfiguration.springBootVersion → bootVersion
projectConfiguration.javaVersion → javaVersion
projectConfiguration.buildTool → type (gradle-project)
projectConfiguration.packaging → packaging

dependencyConfiguration → dependencies (comma-separated string)
  database: mysql → mysql-connector-java
  database: postgresql → postgresql
  security: true → spring-boot-starter-security
  documentation: true → springdoc-openapi-starter-webmvc-ui
  caching: true → spring-boot-starter-cache
  messaging: true → spring-boot-starter-amqp

Always included:
  - web (spring-boot-starter-web)
  - lombok
  - validation (spring-boot-starter-validation)
  - devtools (spring-boot-devtools)
  - test (spring-boot-starter-test)
```

### 3.3 Template Data Mapping

```
For Controller Generation:

Input: apiSpecification
Output: {
  packageName: from projectConfiguration.packageName + ".controller",
  className: apiSpecification.controllerClassName + "Controller",
  baseMapping: apiSpecification.baseControllerPath,
  imports: [calculated based on used types],
  methods: [
    for each endpoint in apiSpecification.endpoints: {
      annotation: httpMethod + "Mapping",
      path: endpoint.path,
      methodName: endpoint.name,
      parameters: [mapped from endpoint.requestParameters],
      returnType: calculated from endpoint.response,
      httpStatus: endpoint.response.httpStatus,
      requestBody: mapped from endpoint.requestBody,
      validations: derived from validation rules
    }
  ]
}

For DTO Generation:

Input: endpoint.requestBody or endpoint.response
Output: {
  packageName: projectConfiguration.packageName + ".dto.request" or ".dto.response",
  className: derived from endpoint name or explicit type,
  fields: [
    for each field: {
      name: field.name,
      type: field.type,
      validationAnnotations: [derived from field.validation],
      javadoc: field.description
    }
  ],
  lombokAnnotations: ["@Data", "@Builder", "@NoArgsConstructor", "@AllArgsConstructor"]
}

For Service Generation:

Input: apiSpecification
Output: {
  packageName: projectConfiguration.packageName + ".service",
  interfaceName: controllerClassName + "Service",
  implementationName: controllerClassName + "ServiceImpl",
  methods: [
    for each endpoint: {
      methodName: endpoint.name,
      parameters: mapped from endpoint.requestParameters,
      returnType: mapped from endpoint.response
    }
  ]
}
```

### 3.4 File Structure Mapping

```
Spring Initializr Base Project (Gradle):
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── {packagePath}/
│   │   │       └── Application.java
│   │   └── resources/
│   │       └── application.properties
│   └── test/
│       └── java/
│           └── {packagePath}/
│               └── ApplicationTests.java
├── build.gradle
├── settings.gradle
├── gradlew
├── gradlew.bat
├── gradle/
│   └── wrapper/
│       ├── gradle-wrapper.jar
│       └── gradle-wrapper.properties
└── README.md

After Code Injection:
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── {packagePath}/
│   │   │       ├── Application.java (existing)
│   │   │       ├── controller/
│   │   │       │   └── {ClassName}Controller.java (NEW)
│   │   │       ├── service/
│   │   │       │   ├── {ClassName}Service.java (NEW)
│   │   │       │   └── impl/
│   │   │       │       └── {ClassName}ServiceImpl.java (NEW)
│   │   │       ├── dto/
│   │   │       │   ├── request/
│   │   │       │   │   └── {Name}Request.java (NEW)
│   │   │       │   └── response/
│   │   │       │       └── {Name}Response.java (NEW)
│   │   │       ├── exception/
│   │   │       │   ├── GlobalExceptionHandler.java (NEW)
│   │   │       │   └── CustomException.java (NEW)
│   │   │       └── config/
│   │   │           └── WebConfig.java (NEW, if needed)
│   │   └── resources/
│   │       ├── application.properties (MODIFIED)
│   │       └── application-dev.properties (NEW)
│   └── test/
│       └── java/
│           └── {packagePath}/
│               ├── ApplicationTests.java (existing)
│               └── controller/
│                   └── {ClassName}ControllerTest.java (NEW, optional)
├── build.gradle (existing, possibly MODIFIED)
├── settings.gradle (existing)
├── README.md (ENHANCED with LLM)
└── API_DOCUMENTATION.md (NEW with LLM)
```

---

## 4. COMPONENT SPECIFICATIONS

### 4.1 Spring Initializr Service

#### Purpose
Interface with Spring Initializr REST API to generate base Spring Boot Gradle projects

#### Responsibilities
1. Construct API request parameters for Gradle projects
2. Call Spring Initializr API
3. Download ZIP file
4. Validate ZIP integrity
5. Handle API errors and retries

#### Configuration Parameters
```
Spring Initializr API:
  Base URL: https://start.spring.io
  Timeout: 30 seconds
  Retry Count: 3
  Retry Delay: 1 second exponential backoff
  Build Tool: gradle-project (fixed)
```

#### Key Operations

**Operation 1: Fetch Metadata**
```
Purpose: Get available Spring Boot versions, dependencies, Java versions
Endpoint: GET https://start.spring.io
Response Format: JSON with available options
Cache Duration: 1 hour
Use Case: Populate dropdown options in UI
```

**Operation 2: Generate Gradle Project**
```
Purpose: Generate base Spring Boot Gradle project
Endpoint: POST https://start.spring.io/starter.zip
Method: POST with form data
Content-Type: application/x-www-form-urlencoded
Parameters: type=gradle-project (always)
Response: Binary ZIP file
Validation: Check ZIP file size > 0, valid ZIP format
```

**Operation 3: Validate Configuration**
```
Purpose: Pre-validate configuration before generation
Checks:
  - Spring Boot version exists
  - Dependencies are valid
  - Java version compatible with Boot version
  - Package name follows Java conventions
  - Gradle-specific validations
```

#### Error Handling
```
Error Scenarios:
1. API Unavailable
   - Retry with exponential backoff
   - After 3 attempts, return error (no fallback in POC)
   
2. Invalid Parameters
   - Return validation error with details
   - Suggest corrections
   
3. Timeout
   - Retry once
   - If fails, return error
   
4. Invalid Response
   - Log error details
   - Return error to user with support ID
```

---

### 4.2 Code Generator Service

#### Purpose
Generate Spring Boot business code using deterministic templates

#### Responsibilities
1. Generate controller classes
2. Generate service interfaces and implementations
3. Generate DTO classes (request/response)
4. Generate exception handlers
5. Generate configuration classes
6. Ensure code quality and consistency

#### Template Categories

**Controller Templates**
```
Template Types:
1. Basic REST Controller
   - Simple CRUD operations
   - Standard HTTP methods
   - ResponseEntity returns
   
2. Advanced REST Controller
   - Pagination support
   - Sorting and filtering
   - Custom exception handling
   - Request/Response validation
   
3. Specialized Controllers
   - File upload/download
   - Batch operations
   - Async operations
```

**Service Templates**
```
Template Types:
1. Service Interface
   - Method signatures
   - JavaDoc documentation
   
2. Service Implementation
   - Business logic placeholders
   - Transaction management
   - Logging statements
   
3. Repository Integration (future)
   - JPA repository calls
   - Query method generation
```

**DTO Templates**
```
Template Types:
1. Request DTOs
   - Validation annotations
   - Lombok annotations
   - Builder pattern support
   
2. Response DTOs
   - Serialization configuration
   - Custom field formatting
   - Nested object support
   
3. Specialized DTOs
   - Paginated responses
   - Error responses
   - File upload DTOs
```

#### Template Variables

```
Common Variables:
- ${packageName}: Base package path
- ${className}: Class name
- ${baseMapping}: Controller base path
- ${javaVersion}: Target Java version
- ${springBootVersion}: Spring Boot version
- ${author}: Generated by system
- ${timestamp}: Generation timestamp

Controller Variables:
- ${methods}: Generated method implementations
- ${imports}: Required import statements
- ${annotations}: Class-level annotations
- ${serviceName}: Injected service name
- ${validationGroups}: Validation group classes

Method Variables:
- ${httpMethod}: GET, POST, PUT, DELETE, PATCH
- ${pathVariable}: Path variable name
- ${requestParam}: Query parameter name
- ${requestBody}: Request body DTO
- ${responseType}: Return type
- ${httpStatus}: HTTP status code
- ${methodName}: Method name

DTO Variables:
- ${fields}: Field declarations
- ${validations}: Validation annotations
- ${constructors}: Constructor methods
- ${gettersSetters}: Getter/setter methods (if not using Lombok)
```

#### Code Generation Rules

**Naming Conventions**
```
Controllers: {Entity}Controller.java
Services: {Entity}Service.java (interface)
Service Impl: {Entity}ServiceImpl.java
Request DTOs: {Action}{Entity}Request.java
Response DTOs: {Entity}Response.java
Exceptions: {Entity}NotFoundException.java
```

**Package Structure Rules**
```
Controllers: {basePackage}.controller
Services: {basePackage}.service
Service Impl: {basePackage}.service.impl
DTOs: {basePackage}.dto.{request|response}
Exceptions: {basePackage}.exception
Config: {basePackage}.config
Utils: {basePackage}.util
```

**Annotation Rules**
```
Required Controller Annotations:
- @RestController
- @RequestMapping (with base path)
- @RequiredArgsConstructor (if using Lombok)
- @Validated (if using validation)
- @Slf4j (if logging enabled)

Required Method Annotations:
- HTTP Method Mapping (@GetMapping, @PostMapping, etc.)
- @Valid (for request body validation)
- @PathVariable, @RequestParam, @RequestBody (as needed)

Required DTO Annotations:
- @Data (Lombok)
- @Builder (Lombok)
- @NoArgsConstructor, @AllArgsConstructor (Lombok)
- Validation annotations (@NotNull, @NotBlank, @Size, etc.)
```

#### Import Management
```
Strategy: Collect all required imports based on:
1. Used annotations
2. Parameter types
3. Return types
4. Exception types
5. Utility classes

Organization:
1. Java standard library imports
2. Spring Framework imports
3. Third-party library imports
4. Application imports

Optimization:
- Avoid wildcard imports
- Remove unused imports
- Order alphabetically within groups
```

#### Code Quality Standards
```
Standards to Enforce:
1. Proper indentation (4 spaces)
2. Line length < 120 characters
3. Consistent brace style (K&R)
4. JavaDoc for all public methods
5. Meaningful variable names
6. No magic numbers
7. Proper exception handling
8. Logging at appropriate levels
```

---

### 4.3 Project Modifier Service

#### Purpose
Inject generated code into Spring Initializr base Gradle project

#### Responsibilities
1. Unzip base project into memory
2. Analyze project structure
3. Inject generated files
4. Update configuration files
5. Create new directories as needed
6. Re-zip modified project

#### Key Operations

**Operation 1: Project Analysis**
```
Purpose: Understand base Gradle project structure
Steps:
1. Extract ZIP to in-memory file system
2. Locate Application.java (main class)
3. Determine package structure
4. Identify existing directories
5. Find configuration files
6. Parse build.gradle and settings.gradle

Output:
{
  "basePackage": "com.example.demo",
  "mainClass": "DemoApplication.java",
  "sourcePath": "src/main/java/com/example/demo",
  "resourcePath": "src/main/resources",
  "buildFile": "build.gradle",
  "settingsFile": "settings.gradle",
  "existingFiles": [...],
  "projectStructure": {...}
}
```

**Operation 2: File Injection**
```
Purpose: Add generated files to project structure

Process:
1. Create directory structure if missing:
   - controller/
   - service/
   - service/impl/
   - dto/request/
   - dto/response/
   - exception/
   - config/

2. Write generated files:
   - Check if file already exists
   - If exists, create with suffix (e.g., Controller_1.java)
   - Write with proper encoding (UTF-8)
   - Maintain file permissions

3. Track injected files:
   - Log all added files
   - Create file manifest
   - Record timestamps
```

**Operation 3: Configuration Update**
```
Purpose: Update application configuration files

application.properties modifications:
1. Add server configuration
   - server.port (if specified)
   - server.servlet.context-path
   
2. Add API documentation config
   - springdoc.api-docs.path=/api-docs
   - springdoc.swagger-ui.path=/swagger-ui.html
   
3. Add logging configuration
   - logging.level.{package}=DEBUG
   
4. Add database configuration (if applicable)
   - spring.datasource.url
   - spring.datasource.username
   - spring.jpa.hibernate.ddl-auto

Strategy:
- Append to existing file
- Add section comments
- Preserve existing properties
- Format consistently
```

**Operation 4: Build File Modification (Gradle)**
```
Purpose: Add additional dependencies if needed

build.gradle modifications:
- Add springdoc-openapi dependency (if documentation enabled)
- Add custom dependencies
- Update Gradle plugin configuration

Process:
1. Parse Groovy structure
2. Locate dependencies block
3. Check if dependency already exists
4. Add new dependency with proper formatting
5. Maintain Groovy syntax validity
6. Write back formatted Gradle script

Example Addition:
dependencies {
    // Existing dependencies...
    
    // API Documentation
    implementation 'org.springdoc:springdoc-openapi-starter-webmvc-ui:2.2.0'
}
```

**Operation 5: Re-packaging**
```
Purpose: Create final downloadable ZIP

Process:
1. Validate all files are valid
2. Create ZIP with proper compression
3. Maintain directory structure
4. Preserve Gradle wrapper files
5. Set appropriate file permissions
6. Add generated manifest file
7. Calculate ZIP checksum

ZIP Structure Validation:
- All Java files have valid syntax
- Gradle files are valid
- No empty directories
- Proper file extensions
```

#### In-Memory File System

```
Structure:
{
  "files": {
    "src/main/java/...": {
      "content": "string",
      "encoding": "UTF-8",
      "modified": true/false,
      "isNew": true/false
    },
    "build.gradle": {
      "content": "string",
      "encoding": "UTF-8",
      "modified": true/false
    }
  },
  "directories": [...],
  "metadata": {
    "baseProject": "spring-initializr-gradle",
    "modified": timestamp,
    "addedFilesCount": number
  }
}

Operations:
- readFile(path) → content
- writeFile(path, content) → success
- createDirectory(path) → success
- fileExists(path) → boolean
- listFiles(directory) → [files]
- deleteFile(path) → success
```

#### Conflict Resolution

```
Scenarios and Strategies:

1. File Already Exists
   Strategy: Append version number
   Example: UserController.java → UserController_2.java
   
2. Directory Structure Mismatch
   Strategy: Create expected structure
   Log: Warning about non-standard structure
   
3. Configuration Conflicts
   Strategy: Merge configurations intelligently
   Example: Combine properties, prefer new values
   
4. Package Name Mismatch
   Strategy: Use detected package, update generated code
   
5. Encoding Issues
   Strategy: Force UTF-8, log warning if conversion needed

6. Gradle File Conflicts
   Strategy: Append new dependencies at end of block
   Log: Warning if manual review needed
```

---

### 4.4 LLM Enhancement Service (Optional)

#### Purpose
Enhance generated code with intelligent documentation and examples

#### Responsibilities
1. Generate comprehensive JavaDoc
2. Create project README
3. Generate API usage examples
4. Suggest best practices
5. Create test templates

#### When to Use
```
Enable LLM Enhancement when:
- User explicitly requests it
- Project complexity is high (> 5 endpoints)
- Documentation quality is priority
- User opts for "Enhanced Generation"

Skip LLM Enhancement when:
- User wants fast generation
- Simple project (1-2 endpoints)
- API unavailable
- POC testing phase
```

#### Enhancement Types

**1. JavaDoc Enhancement**
```
Purpose: Add comprehensive method and class documentation

Process:
1. Analyze method signature
2. Understand business context from names
3. Generate detailed JavaDoc including:
   - Purpose description
   - Parameter explanations
   - Return value description
   - Exception documentation
   - Usage examples
   - Since tags
   - Author tags

Example Output:
/**
 * Retrieves a user by their unique identifier.
 * 
 * This endpoint fetches user details from the database using the provided ID.
 * The response includes all user profile information except sensitive data
 * like passwords.
 * 
 * <p>Example request:</p>
 * <pre>
 * GET /api/users/123
 * </pre>
 * 
 * <p>Example response (200 OK):</p>
 * <pre>
 * {
 *   "id": 123,
 *   "username": "john.doe",
 *   "email": "john@example.com",
 *   "createdAt": "2024-01-15T10:30:00Z"
 * }
 * </pre>
 * 
 * @param id the unique identifier of the user (must be positive)
 * @return ResponseEntity containing the user data and HTTP 200 status
 * @throws UserNotFoundException if no user exists with the given ID
 * @throws IllegalArgumentException if the provided ID is null or negative
 * @since 1.0
 * @author API Generator
 */
```

**2. README Generation**
```
Purpose: Create comprehensive project documentation

Sections to Include:
1. Project Title and Description
2. Features and Capabilities
3. Requirements
   - Java version
   - Gradle
   - Database (if applicable)
4. Installation Instructions
   - Clone repository
   - Build project: gradle build
   - Run application: gradle bootRun
5. Configuration
   - application.properties setup
   - Database configuration
   - Environment variables
6. API Endpoints Documentation
   - List all endpoints
   - Request/response examples
   - Error codes
7. Usage Examples
   - cURL commands
   - Postman collection link
8. Development
   - Running tests: gradle test
   - Code structure
   - Adding new endpoints
9. Gradle Tasks
   - Common commands
   - Build and run
10. Troubleshooting
```

**3. API Examples Generation**
```
Purpose: Create executable API call examples

Generate for each endpoint:

cURL Examples:
# Get user by ID
curl -X GET "http://localhost:8080/api/users/123" \
  -H "Content-Type: application/json"

# Create new user
curl -X POST "http://localhost:8080/api/users" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john.doe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe"
  }'

Gradle Commands:
# Build the project
./gradlew build

# Run the application
./gradlew bootRun

# Run tests
./gradlew test

# Create JAR
./gradlew bootJar
```

**4. Best Practice Suggestions**
```
Purpose: Suggest improvements to generated code

Analysis Areas:
1. Security
   - Missing authentication
   - Input validation gaps
   
2. Gradle Configuration
   - Dependency optimization
   - Plugin recommendations
   
3. Maintainability
   - Code duplication
   - Complex methods
   - Missing tests
   
4. Spring Boot Conventions
   - Non-standard patterns
   - Better annotation usage
   - Configuration improvements

Output Format:
Suggestions document with:
- Issue description
- Severity (High, Medium, Low)
- Recommended fix
- Code example
```

#### LLM Prompt Templates

**Controller JavaDoc Prompt**
```
Context: You are a senior Java developer documenting Spring Boot REST APIs.

Task: Generate comprehensive JavaDoc for the following REST controller method.

Method Information:
- Name: {methodName}
- HTTP Method: {httpMethod}
- Path: {path}
- Parameters: {parameters}
- Return Type: {returnType}
- Purpose: {inferredPurpose}

Requirements:
1. Write clear, professional JavaDoc
2. Include method description (2-3 sentences)
3. Document all parameters with @param tags
4. Document return value with @return tag
5. Document exceptions with @throws tags
6. Add example HTTP request in <pre> tags
7. Add example HTTP response in <pre> tags
8. Use proper HTML formatting
9. Keep examples realistic and helpful
10. Follow JavaDoc best practices

Output: JavaDoc comment block only, starting with /** and ending with */
```

**README Generation Prompt**
```
Context: You are a technical writer creating documentation for a Spring Boot REST API built with Gradle.

Project Information:
- Name: {projectName}
- Description: {description}
- Spring Boot Version: {version}
- Build Tool: Gradle
- Endpoints: {endpointList}
- Dependencies: {dependencies}

Task: Create a comprehensive README.md file

Requirements:
1. Professional, clear writing
2. Markdown format
3. Include all standard sections
4. Add Gradle-specific instructions
5. Include realistic examples
6. Include troubleshooting tips
7. Make it beginner-friendly
8. Add badges for build status, version, etc.
9. Include table of contents
10. Keep instructions accurate and testable
11. Include Gradle wrapper usage

Output: Complete README.md in markdown format
```

#### Quality Control
```
Generated Content Validation:
1. Check for hallucinated APIs
2. Verify code syntax in examples
3. Ensure Gradle commands are correct
4. Validate JSON structure
5. Check markdown formatting
6. Remove any placeholder text
7. Verify technical accuracy

Fallback Strategy:
If LLM generation fails:
1. Use template-based documentation
2. Log failure reason
3. Continue with basic comments
4. Notify user of limited documentation
```

---

### 4.5 Validation Service

#### Purpose
Validate all inputs and outputs throughout the generation process

#### Validation Layers

**Layer 1: Input Validation**
```
Validate User Input:

Project Configuration:
- projectName: not empty, alphanumeric+hyphen, 3-50 chars
- groupId: valid Java package format (e.g., com.example)
- artifactId: lowercase, hyphen-separated, no spaces
- packageName: valid Java package, must start with groupId
- springBootVersion: must be in available versions list
- javaVersion: must be compatible with Spring Boot version
- buildTool: must be "gradle"

API Specification:
- controllerClassName: PascalCase, valid Java identifier
- baseControllerPath: valid URL path, starts with /
- endpoints: at least one endpoint required
- endpoint.httpMethod: must be valid HTTP method
- endpoint.path: valid URL path segment
- endpoint.name: camelCase, valid Java method name
- parameters: type must be supported Java type
- response: must have valid structure

Validation Rules:
- No SQL injection patterns
- No path traversal attempts
- No XSS patterns
- Reasonable size limits
```

**Layer 2: Spring Initializr Validation**
```
Pre-API Call Validation:
1. Check if Boot version exists
2. Verify all dependencies are available
3. Check Java version compatibility:
   - Java 17: Boot 2.7+
   - Java 21: Boot 3.2+
4. Validate dependency combinations
5. Check for deprecated dependencies
6. Verify Gradle project type

Post-API Call Validation:
1. Verify ZIP file received
2. Check ZIP file size > 10KB
3. Validate ZIP structure
4. Verify presence of key files:
   - build.gradle
   - settings.gradle
   - gradlew
   - Application.java
   - application.properties
```

**Layer 3: Generated Code Validation**
```
Code Quality Checks:

Syntax Validation:
- Valid Java syntax (can use regex patterns)
- Proper bracket matching
- Valid string literals
- Correct annotation syntax

Semantic Validation:
- All imports are resolvable
- Class names don't conflict
- Method signatures are unique
- Annotations are used correctly
- Return types match method signatures

Spring Boot Validation:
- Controller paths are unique
- HTTP methods are properly used
- Request mappings don't conflict
- Validation annotations are correct
- Service dependencies can be injected

Code Style Validation:
- Consistent indentation
- Proper naming conventions
- No unused imports
- JavaDoc present for public methods
- Line length within limits
```

**Layer 4: Project Structure Validation**
```
Validate Final Project:

Directory Structure:
- Standard Gradle structure
- Source directories exist
- Resource directories exist
- Test directories present
- Gradle wrapper present

File Presence:
- All generated files present
- Configuration files valid
- Build file is valid Groovy
- Settings file present
- No missing dependencies

Final Checks:
- ZIP file size reasonable (< 10MB)
- All paths are relative
- No absolute file references
- File permissions correct
- Gradle wrapper executable
```

#### Validation Error Handling

```
Error Response Format:
{
  "valid": false,
  "errors": [
    {
      "field": "projectConfiguration.groupId",
      "message": "Invalid Java package format",
      "value": "123invalid",
      "suggestion": "Use lowercase letters and dots (e.g., com.example)"
    }
  ],
  "warnings": [
    {
      "field": "apiSpecification.endpoints[0].path",
      "message": "Path does not follow REST conventions",
      "suggestion": "Consider using plural nouns (e.g., /users instead of /user)"
    }
  ]
}

Error Severity Levels:
1. CRITICAL: Prevents generation, must be fixed
2. ERROR: Should be fixed, generation might fail
3. WARNING: Best practice violation, can proceed
4. INFO: Suggestions for improvement
```

#### Sanitization Rules

```
Input Sanitization:

Strings:
- Trim whitespace
- Remove control characters
- Escape special characters
- Limit length

Paths:
- Normalize separators (/ vs \)
- Remove .. and .
- Prevent path traversal
- Validate against whitelist

Package Names:
- Convert to lowercase
- Remove invalid characters
- Validate Java identifier rules
- Check reserved keywords

Method Names:
- Ensure camelCase
- Remove special characters
- Check Java reserved words
- Validate length (< 50 chars)
```

---

## 5. API SPECIFICATIONS

### 5.1 REST API Endpoints

#### Endpoint 1: Generate Code Preview
```
POST /api/v1/generate/preview

Purpose: Generate code without full project, for preview

Request Body: {Full input schema from Section 3.1}

Response:
{
  "success": true,
  "generatedCode": {
    "controller": {
      "className": "UserController.java",
      "content": "package com.example...",
      "lineCount": 145,
      "dependencies": ["ResponseEntity", "GetMapping"]
    },
    "services": [
      {
        "className": "UserService.java",
        "content": "...",
        "type": "interface"
      }
    ],
    "dtos": [
      {
        "className": "UserResponse.java",
        "content": "...",
        "type": "response"
      }
    ]
  },
  "statistics": {
    "totalFiles": 5,
    "totalLines": 450,
    "endpoints": 3,
    "generationTime": "1.2s"
  },
  "metadata": {
    "timestamp": "2025-01-15T10:30:00Z",
    "version": "1.0"
  }
}

HTTP Status Codes:
- 200: Success
- 400: Validation error
- 500: Internal error

Timeout: 15 seconds
```

#### Endpoint 2: Generate Full Gradle Project
```
POST /api/v1/generate/project

Purpose: Generate complete Spring Boot Gradle project ZIP

Request Body: {Full input schema from Section 3.1}

Response: Binary ZIP file
Content-Type: application/zip
Content-Disposition: attachment; filename="generated-api-{timestamp}.zip"

Headers:
- X-Generation-Id: Unique generation ID
- X-Project-Name: Project name
- X-Build-Tool: gradle
- X-Files-Count: Number of files in ZIP
- X-Generation-Time: Time taken in ms

HTTP Status Codes:
- 200: Success, ZIP file in body
- 400: Validation error (JSON response)
- 500: Internal error (JSON response)

Timeout: 30 seconds
Max Size: 10MB
```

#### Endpoint 3: Validate Input
```
POST /api/v1/validate

Purpose: Validate input before generation

Request Body: {Full input schema}

Response:
{
  "valid": true/false,
  "errors": [...],
  "warnings": [...],
  "suggestions": [
    {
      "type": "naming",
      "message": "Consider using RESTful naming",
      "examples": ["Use /users instead of /getUsers"]
    }
  ],
  "estimatedTime": "8-12 seconds",
  "estimatedSize": "2.5 MB",
  "buildTool": "gradle"
}

HTTP Status Codes:
- 200: Validation complete (check 'valid' field)
- 400: Malformed request
- 500: Internal error

Timeout: 5 seconds
```

#### Endpoint 4: Get Spring Boot Metadata
```
GET /api/v1/metadata/spring-boot

Purpose: Get available Spring Boot versions and dependencies

Query Parameters:
- refresh: boolean (force refresh from Spring Initializr)

Response:
{
  "bootVersions": [
    {
      "version": "3.2.0",
      "default": true,
      "minJavaVersion": "17"
    }
  ],
  "javaVersions": ["11", "17", "21"],
  "buildTools": [
    {
      "id": "gradle",
      "name": "Gradle",
      "default": true
    }
  ],
  "dependencies": [
    {
      "id": "web",
      "name": "Spring Web",
      "description": "Build web applications",
      "compatibleBootVersions": ["3.0.0+"]
    }
  ],
  "lastUpdated": "2025-01-15T10:00:00Z",
  "cacheExpiresAt": "2025-01-15T11:00:00Z"
}

HTTP Status Codes:
- 200: Success
- 500: Internal error

Cache: 1 hour
```

#### Endpoint 5: Health Check
```
GET /api/v1/health

Purpose: Check service health and dependencies

Response:
{
  "status": "UP|DOWN",
  "components": {
    "springInitializr": {
      "status": "UP",
      "responseTime": "245ms",
      "lastChecked": "2025-01-15T10:30:00Z"
    },
    "vertexAI": {
      "status": "UP",
      "enabled": true,
      "lastChecked": "2025-01-15T10:30:00Z"
    },
    "templateEngine": {
      "status": "UP"
    }
  },
  "version": "1.0.0-POC",
  "uptime": "2h 30m"
}

HTTP Status Codes:
- 200: Service healthy
- 503: Service unhealthy
```

### 5.2 Error Response Format

```
Standard Error Response:
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "User-friendly error message",
    "details": "Technical details for debugging",
    "field": "specific field name (if applicable)",
    "timestamp": "2025-01-15T10:30:00Z",
    "requestId": "uuid",
    "suggestedAction": "How to fix the error"
  }
}

Error Codes:
VALIDATION_ERROR: Input validation failed
SPRING_INITIALIZR_ERROR: Spring Initializr API error
CODE_GENERATION_ERROR: Code generation failed
PROJECT_MODIFICATION_ERROR: Failed to inject code
GRADLE_FILE_ERROR: Failed to modify build.gradle
ZIP_CREATION_ERROR: Failed to create ZIP
LLM_ERROR: LLM enhancement failed (non-critical)
SERVICE_UNAVAILABLE: Service temporarily down
TIMEOUT_ERROR: Request timeout
INTERNAL_ERROR: Unexpected internal error
```

### 5.3 Request/Response Headers

```
Standard Request Headers:
- Content-Type: application/json
- Accept: application/json or application/zip
- X-Client-Version: Client version
- X-Request-Id: Unique request identifier (optional)

Standard Response Headers:
- Content-Type: application/json or application/zip
- X-Request-Id: Echo request ID or generate new
- X-Response-Time: Time taken to process (ms)
- X-Build-Tool: gradle
```

---

## 6. TEMPLATE SYSTEM DESIGN

### 6.1 Template Organization

```
Template Directory Structure:
templates/
├── controllers/
│   ├── basic-rest-controller.java.template
│   ├── crud-controller.java.template
│   └── paginated-controller.java.template
├── services/
│   ├── service-interface.java.template
│   └── service-impl.java.template
├── dtos/
│   ├── request-dto.java.template
│   ├── response-dto.java.template
│   └── error-response.java.template
├── exceptions/
│   ├── global-exception-handler.java.template
│   └── custom-exception.java.template
├── config/
│   └── web-config.java.template
├── documentation/
│   ├── readme-gradle.md.template
│   └── api-doc.md.template
└── properties/
    ├── application.properties.template
    └── application-dev.properties.template
```

### 6.2 Template Syntax

```
Variable Syntax: ${variableName}
Conditional: {{#if condition}}...{{/if}}
Loop: {{#each items}}...{{/each}}
Comment: {{!-- comment --}}

Examples:

Basic Variable:
package ${packageName}.controller;

Conditional:
{{#if includeValidation}}
import javax.validation.Valid;
{{/if}}

Loop:
{{#each endpoints}}
@${httpMethod}Mapping("${path}")
public ResponseEntity<${responseType}> ${methodName}() {
    // Implementation
}
{{/each}}
```

### 6.3 Template Examples

#### Controller Template
```java
package ${packageName}.controller;

{{#each imports}}
import ${this};
{{/each}}

/**
 * REST controller for ${entityName} operations.
 * Generated on ${timestamp}
 */
@Slf4j
@RestController
@RequestMapping("${baseMapping}")
@RequiredArgsConstructor
{{#if includeValidation}}
@Validated
{{/if}}
public class ${className}Controller {

    {{#if includeServiceLayer}}
    private final ${serviceName} ${serviceVariable};
    {{/if}}

    {{#each methods}}
    /**
     * ${description}
     */
    @${httpAnnotation}("${path}")
    public ResponseEntity<${returnType}> ${methodName}(
        {{#each parameters}}
        @${paramAnnotation} {{#if required}}@NotNull{{/if}} ${type} ${name}{{#unless @last}},{{/unless}}
        {{/each}}
    ) {
        log.info("${className}.${methodName} called");
        {{#if includeServiceLayer}}
        ${returnType} result = ${serviceVariable}.${methodName}({{parameterNames}});
        return ResponseEntity.{{httpStatusMethod}}(result);
        {{else}}
        // TODO: Implement business logic
        return ResponseEntity.{{httpStatusMethod}}(null);
        {{/if}}
    }
    
    {{/each}}
}
```

#### DTO Template
```java
package ${packageName}.dto.${dtoType};

{{#each imports}}
import ${this};
{{/each}}

/**
 * ${description}
 * Generated on ${timestamp}
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ${className} {

    {{#each fields}}
    /**
     * ${description}
     */
    {{#each validations}}
    @${annotationName}{{#if hasParams}}(${params}){{/if}}
    {{/each}}
    private ${type} ${name};
    
    {{/each}}
}
```

#### Gradle README Template
```markdown
# ${projectName}

${description}

## Requirements

- Java ${javaVersion}
- Gradle 7.x or higher (wrapper included)

## Build and Run

### Using Gradle Wrapper (Recommended)

```bash
# Build the project
./gradlew build

# Run the application
./gradlew bootRun

# Run tests
./gradlew test

# Create executable JAR
./gradlew bootJar
```

### Using Installed Gradle

```bash
gradle build
gradle bootRun
```

## Project Structure

```
${projectName}/
├── src/
│   ├── main/
│   │   ├── java/
│   │   └── resources/
│   └── test/
├── build.gradle
├── settings.gradle
└── gradlew
```

## API Endpoints

{{#each endpoints}}
### ${httpMethod} ${path}
${description}

**Request:**
```
${requestExample}
```

**Response:**
```
${responseExample}
```
{{/each}}

## Configuration

Edit `src/main/resources/application.properties`:

```properties
server.port=8080
spring.application.name=${projectName}
```

## Common Gradle Tasks

- `./gradlew tasks` - List all available tasks
- `./gradlew dependencies` - Show dependency tree
- `./gradlew clean` - Clean build directory
- `./gradlew build --info` - Build with detailed output

## Troubleshooting

**Issue:** Permission denied on gradlew
**Solution:** `chmod +x gradlew`

**Issue:** Build fails
**Solution:** `./gradlew clean build --refresh-dependencies`

## Documentation

API documentation available at: http://localhost:8080/swagger-ui.html
```

### 6.4 Template Selection Logic

```
Template Selection Rules:

Controller Template Selection:
IF endpoints.length == 1 AND endpoint.method == "GET"
  → use "basic-rest-controller.java.template"
ELSE IF all endpoints are CRUD operations
  → use "crud-controller.java.template"
ELSE IF any endpoint has pagination
  → use "paginated-controller.java.template"
ELSE
  → use "basic-rest-controller.java.template"

Service Template Selection:
IF includeServiceLayer == false
  → skip service generation
ELSE
  → use "service-impl.java.template"

DTO Template Selection:
IF dtoType == "request"
  → use "request-dto.java.template"
ELSE IF dtoType == "response"
  → use "response-dto.java.template"

Documentation Template Selection:
  → use "readme-gradle.md.template" (Gradle-specific)
```

### 6.5 Template Variables Dictionary

```
Global Variables (available in all templates):
- ${packageName}: Base package (e.g., com.example.api)
- ${timestamp}: Generation timestamp
- ${author}: "Generated API"
- ${javaVersion}: Target Java version
- ${springBootVersion}: Spring Boot version
- ${buildTool}: "gradle"
- ${generatorVersion}: Generator version

Controller Variables:
- ${className}: Controller class name
- ${baseMapping}: Base URL path
- ${serviceName}: Service class name
- ${serviceVariable}: Service variable name (camelCase)
- ${entityName}: Entity name (singular)
- ${methods}: Array of method objects
- ${includeServiceLayer}: Boolean
- ${includeValidation}: Boolean
- ${imports}: Array of import statements

Method Variables:
- ${methodName}: Java method name
- ${description}: Method description
- ${httpAnnotation}: GetMapping, PostMapping, etc.
- ${path}: URL path segment
- ${returnType}: Return type (e.g., UserResponse)
- ${httpStatusMethod}: ok, created, noContent
- ${parameters}: Array of parameter objects
- ${parameterNames}: Comma-separated parameter names

Parameter Variables:
- ${name}: Parameter name
- ${type}: Java type
- ${paramAnnotation}: PathVariable, RequestParam, RequestBody
- ${required}: Boolean
- ${defaultValue}: Default value (if any)
- ${validation}: Array of validation annotations

DTO Variables:
- ${className}: DTO class name
- ${dtoType}: request or response
- ${description}: DTO description
- ${fields}: Array of field objects
- ${imports}: Required imports

Field Variables:
- ${name}: Field name
- ${type}: Java type
- ${description}: Field description
- ${validations}: Array of validation objects
- ${defaultValue}: Default value

Gradle-Specific Variables:
- ${gradleVersion}: Gradle version
- ${gradleWrapperVersion}: Wrapper version
- ${gradleTasks}: Common tasks list
```

### 6.6 Template Rendering Process

```
Rendering Pipeline:

Step 1: Template Selection
- Analyze input specification
- Select appropriate template(s)
- Load template content

Step 2: Variable Preparation
- Extract data from input
- Transform to template variables
- Calculate derived values
- Build variable context

Step 3: Conditional Processing
- Evaluate {{#if}} conditions
- Remove false branches
- Keep true branches

Step 4: Loop Processing
- Evaluate {{#each}} loops
- Generate repeated content
- Handle nested loops

Step 5: Variable Substitution
- Replace ${variable} with values
- Handle missing variables (error or default)
- Preserve formatting

Step 6: Import Optimization
- Collect all required imports
- Remove duplicates
- Sort alphabetically
- Group by package

Step 7: Formatting
- Apply consistent indentation
- Format code style
- Remove extra whitespace
- Ensure line endings

Step 8: Validation
- Check syntax validity
- Verify bracket matching
- Validate annotations

Output: Rendered Java code as string
```

---

## 7. USER INTERFACE SPECIFICATION

### 7.1 UI Layout Structure

```
Application Layout:

┌─────────────────────────────────────────────────────────────┐
│  Header                                                      │
│  ┌──────────────┐  ┌──────────┐  ┌────────────────────┐   │
│  │ Logo & Title │  │   Help   │  │  GitHub | Docs     │   │
│  └──────────────┘  └──────────┘  └────────────────────────┘│
├─────────────────────────────────────────────────────────────┤
│  Progress Indicator                                          │
│  ○━━━○━━━○━━━○━━━○                                          │
│  1   2   3   4   5                                           │
│  Project  API   Options  Generate  Download                 │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Main Content Area (Step-based)                             │
│                                                              │
│  [Dynamic content based on current step]                    │
│                                                              │
│                                                              │
│                                                              │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│  Actions Bar                                                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────────┐ │
│  │ Previous │  │ Validate │  │   Next   │  │  Generate │ │
│  └──────────┘  └──────────┘  └──────────┘  └───────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### 7.2 Step-by-Step Flow

#### Step 1: Project Configuration

```
┌─────────────────────────────────────────────────────────────┐
│  Project Configuration                                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Basic Information                                           │
│  ┌────────────────────────────────────────────────────────┐│
│  │ Project Name *          [_____________________]        ││
│  │ Description (optional)  [_____________________]        ││
│  │                         [_____________________]        ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  Maven Coordinates                                           │
│  ┌────────────────────────────────────────────────────────┐│
│  │ Group ID *             [com.example.api]              ││
│  │ Artifact ID *          [my-api]                       ││
│  │ Package Name *         [com.example.api]              ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  Technology Stack                                            │
│  ┌────────────────────────────────────────────────────────┐│
│  │ Spring Boot Version *  [3.2.0 ▼]                      ││
│  │ Java Version *         [17 ▼]                         ││
│  │ Build Tool             ⦿ Gradle  ○ Maven (disabled)   ││
│  │ Packaging *            ⦿ JAR    ○ WAR                 ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  Dependencies (Optional)                                     │
│  ┌────────────────────────────────────────────────────────┐│
│  │ □ MySQL Database                                       ││
│  │ □ PostgreSQL Database                                  ││
│  │ □ Spring Security                                      ││
│  │ □ API Documentation (Swagger)                          ││
│  │ □ Caching Support                                      ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│              [Validate]  [Next: API Design →]              │
└─────────────────────────────────────────────────────────────┘

Field Validation:
- Real-time validation on blur
- Show green checkmark for valid fields
- Show red X with error message for invalid
- Disable Next button until all required fields valid
- Build tool locked to Gradle
```

#### Step 2: API Design

```
┌─────────────────────────────────────────────────────────────┐
│  API Design                                                  │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Controller Configuration                                    │
│  ┌────────────────────────────────────────────────────────┐│
│  │ Controller Name *      [User]                          ││
│  │ Base Path *            [/api/users]                    ││
│  │ Description           [User management endpoints]      ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  Endpoints                                                   │
│  ┌────────────────────────────────────────────────────────┐│
│  │                                                          ││
│  │  Endpoint #1                              [− Remove]    ││
│  │  ────────────────────────────────────────────────────  ││
│  │  • Method:        [GET ▼]                              ││
│  │  • Path:          [/{id}]                              ││
│  │  • Operation:     [getUserById]                        ││
│  │  • Description:   [Get user by ID]                     ││
│  │                                                          ││
│  │  Parameters                              [+ Add Param]  ││
│  │  ┌─────────────────────────────────────────────────┐  ││
│  │  │ id | Long | PATH | Required ☑ | User ID    [×] │  ││
│  │  └─────────────────────────────────────────────────┘  ││
│  │                                                          ││
│  │  Response                                               ││
│  │  ┌─────────────────────────────────────────────────┐  ││
│  │  │ Type: Single Object                             │  ││
│  │  │ Status: 200 OK                                  │  ││
│  │  │                                [+ Add Field]     │  ││
│  │  │ • id (Long) - User ID                      [×]  │  ││
│  │  │ • username (String) - Username             [×]  │  ││
│  │  │ • email (String) - Email address           [×]  │  ││
│  │  └─────────────────────────────────────────────────┘  ││
│  │                                                          ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  [+ Add Endpoint]                                           │
│                                                              │
│  Quick Templates:                                            │
│  [Basic CRUD]  [Read-Only]  [Custom]                       │
│                                                              │
│              [← Previous]  [Validate]  [Next: Options →]   │
└─────────────────────────────────────────────────────────────┘

Features:
- Drag-to-reorder endpoints
- Collapsible endpoint sections
- Inline validation
- Preview REST paths as you type
- Quick templates for common patterns
- Duplicate endpoint functionality
```

#### Step 3: Generation Options

```
┌─────────────────────────────────────────────────────────────┐
│  Generation Options                                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Code Structure                                              │
│  ┌────────────────────────────────────────────────────────┐│
│  │ ☑ Generate Service Layer                              ││
│  │   Create service interfaces and implementations        ││
│  │                                                          ││
│  │ ☑ Generate Exception Handling                          ││
│  │   Add global exception handler                         ││
│  │                                                          ││
│  │ ☑ Include Request Validation                           ││
│  │   Add Bean Validation annotations                      ││
│  │                                                          ││
│  │ ☑ Add Logging                                           ││
│  │   Include SLF4J logging statements                     ││
│  │                                                          ││
│  │ □ Generate Unit Tests (Coming Soon)                    ││
│  │   Create basic controller tests                        ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  Documentation                                               │
│  ┌────────────────────────────────────────────────────────┐│
│  │ ☑ Generate Swagger/OpenAPI Documentation              ││
│  │                                                          ││
│  │ □ Enhance with AI Documentation (Optional) ⚡          ││
│  │   ├─ Comprehensive JavaDoc                             ││
│  │   ├─ Detailed README with Gradle commands              ││
│  │   ├─ API usage examples                                ││
│  │   └─ Best practice suggestions                         ││
│  │   Note: Adds 5-8 seconds to generation time            ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  Application Configuration                                   │
│  ┌────────────────────────────────────────────────────────┐│
│  │ Server Port            [8080]                          ││
│  │ Context Path           [/]                             ││
│  │ Enable CORS            [Yes ▼]                         ││
│  │ Log Level              [INFO ▼]                        ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  ┌────────────────────────────────────────────────────────┐│
│  │ ℹ️  Build Tool: Gradle                                 ││
│  │    Estimated Generation Time: 3-5 seconds              ││
│  │    With AI Enhancement: 8-12 seconds                   ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│              [← Previous]  [Validate]  [Next: Review →]    │
└─────────────────────────────────────────────────────────────┘
```

#### Step 4: Review & Generate

```
┌─────────────────────────────────────────────────────────────┐
│  Review Configuration                                        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Project Summary                                             │
│  ┌────────────────────────────────────────────────────────┐│
│  │ Project: my-api-project                                ││
│  │ Package: com.example.api                               ││
│  │ Spring Boot: 3.2.0 | Java: 17 | Gradle                ││
│  │ Controller: UserController                              ││
│  │ Endpoints: 5                                            ││
│  │                                         [Edit Project] ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  Endpoints Overview                                          │
│  ┌────────────────────────────────────────────────────────┐│
│  │ GET    /api/users/{id}      - Get user by ID          ││
│  │ GET    /api/users           - Get all users           ││
│  │ POST   /api/users           - Create user             ││
│  │ PUT    /api/users/{id}      - Update user             ││
│  │ DELETE /api/users/{id}      - Delete user             ││
│  │                                         [Edit Design]  ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  Generated Files Preview                                     │
│  ┌────────────────────────────────────────────────────────┐│
│  │ 📁 src/main/java/com/example/api/                     ││
│  │   ├─ 📄 Application.java                               ││
│  │   ├─ 📁 controller/                                    ││
│  │   │   └─ 📄 UserController.java                        ││
│  │   ├─ 📁 service/                                       ││
│  │   │   ├─ 📄 UserService.java                           ││
│  │   │   └─ 📄 UserServiceImpl.java                       ││
│  │   ├─ 📁 dto/                                           ││
│  │   │   ├─ 📁 request/                                   ││
│  │   │   │   └─ 📄 CreateUserRequest.java                 ││
│  │   │   └─ 📁 response/                                  ││
│  │   │       └─ 📄 UserResponse.java                      ││
│  │   └─ 📁 exception/                                     ││
│  │       └─ 📄 GlobalExceptionHandler.java                ││
│  │ 📁 Gradle files                                         ││
│  │   ├─ 📄 build.gradle                                   ││
│  │   ├─ 📄 settings.gradle                                ││
│  │   ├─ 📄 gradlew                                        ││
│  │   └─ 📄 gradlew.bat                                    ││
│  │                                                          ││
│  │ Estimated Size: 2.5 MB                                 ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  ┌────────────────────────────────────────────────────────┐│
│  │     [← Previous]              [🚀 Generate Project]    ││
│  └────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

#### Step 5: Generation Progress & Download

```
┌─────────────────────────────────────────────────────────────┐
│  Generating Your Gradle Project...                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────────┐│
│  │                                                          ││
│  │       Progress                                           ││
│  │       ████████████████████░░░░  75%                     ││
│  │                                                          ││
│  │  ✓ Creating base Gradle project (Spring Initializr)    ││
│  │  ✓ Generating controller code                           ││
│  │  ✓ Generating service layer                             ││
│  │  ⏳ Injecting code into project...                      ││
│  │  ○ Creating ZIP file                                    ││
│  │                                                          ││
│  │       Elapsed: 3.2s | Estimated: 1.5s remaining         ││
│  │                                                          ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
└─────────────────────────────────────────────────────────────┘

After Completion:

┌─────────────────────────────────────────────────────────────┐
│  ✓ Gradle Project Generated Successfully!                   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────────┐│
│  │  🎉 Your Spring Boot Gradle project is ready!          ││
│  │                                                          ││
│  │  Project: my-api-project.zip                            ││
│  │  Build Tool: Gradle                                     ││
│  │  Size: 2.4 MB                                           ││
│  │  Files: 18                                               ││
│  │  Generated in: 4.2 seconds                              ││
│  │                                                          ││
│  │           [📥 Download Project]                         ││
│  │                                                          ││
│  │  Quick Start:                                            ││
│  │  1. Extract the ZIP file                                ││
│  │  2. Run: ./gradlew bootRun                              ││
│  │  3. Open: http://localhost:8080                         ││
│  │                                                          ││
│  │  Common Gradle Commands:                                ││
│  │  • ./gradlew build    - Build project                  ││
│  │  • ./gradlew test     - Run tests                      ││
│  │  • ./gradlew tasks    - List all tasks                 ││
│  │                                                          ││
│  │           [👀 Preview Code]                             ││
│  └────────────────────────────────────────────────────────┘│
│                                                              │
│  What's Next?                                                │
│  ┌────────────────────────────────────────────────────────┐│
│  │ • [Generate Another Project]                            ││
│  │ • [View Documentation]                                  ││
│  │ • [Share Feedback]                                      ││
│  └────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

### 7.3 Code Preview Modal

```
┌─────────────────────────────────────────────────────────────┐
│  Code Preview                                        [×]     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  File Explorer (Left Sidebar)                               │
│  ┌──────────────────────────┐ ┌────────────────────────────┤
│  │ 📁 src/                  │ │  UserController.java    [×]│
│  │  ├─ 📁 main/             │ ├────────────────────────────┤
│  │  │  ├─ 📁 java/          │ │                            │
│  │  │  │  ├─ 📄 App...      │ │  package com.example.api;  │
│  │  │  │  ├─ 📁 controller/ │ │                            │
│  │  │  │  │  └─ 📄 User...►│ │  import org.springframework│
│  │  │  │  ├─ 📁 service/    │ │  ...                       │
│  │  │  │  └─ 📁 dto/        │ │                            │
│  │  │  └─ 📁 resources/     │ │  @RestController           │
│  │  │      └─ 📄 app...     │ │  @RequestMapping("/api/... │
│  │  └─ 📁 test/             │ │  public class UserControl..│
│  │ 📄 build.gradle          │ │  {                         │
│  │ 📄 settings.gradle       │ │      // Generated code     │
│  │ 📄 gradlew               │ │      ...                   │
│  │ 📄 README.md             │ │                            │
│  └──────────────────────────┘ │  [Copy Code]  [Download]  │
│                                 └────────────────────────────┘
│                                                              │
│                          [Close]                             │
└─────────────────────────────────────────────────────────────┘

Features:
- Syntax highlighting
- Line numbers
- Search within code
- Multiple file tabs
- Copy code button
- Download individual file
- Gradle-specific file highlighting
```

### 7.4 Responsive Design Specifications

```
Desktop (> 1024px):
- Full layout with sidebars
- Multi-column forms
- Expanded file tree
- Code preview in modal

Tablet (768px - 1024px):
- Single column forms
- Collapsible sidebars
- Stacked sections
- Full-screen code preview

Mobile (< 768px):
- Vertical layout
- One section at a time
- Bottom action buttons
- Simplified forms
- Full-screen modals
```

### 7.5 UI Component Specifications

#### Input Fields
```
Text Input:
- Height: 40px
- Border: 1px solid #d1d5db
- Border radius: 6px
- Focus: Blue border, box-shadow
- Error: Red border, error icon, error message below
- Success: Green border, checkmark icon

Dropdown:
- Height: 40px
- Chevron icon on right
- Searchable for long lists
- Group related options

Checkbox:
- Size: 20x20px
- Rounded corners
- Blue when checked
- Label on right

Radio Button:
- Size: 20x20px
- Circular
- Blue when selected
- "Gradle" option pre-selected and locked

Button:
- Primary: Blue background, white text
- Secondary: Gray background
- Disabled: Gray, cursor not-allowed
- Height: 40px
- Border radius: 6px
- Hover: Slightly darker
```

#### Validation Messages
```
Error Message:
- Red text (#ef4444)
- Icon: ⚠️
- Position: Below field
- Animation: Fade in

Success Message:
- Green text (#10b981)
- Icon: ✓
- Position: Inline with field
- Animation: Slide in

Info Message:
- Blue text (#3b82f6)
- Icon: ℹ️
- Position: Below field
```

#### Progress Indicators
```
Linear Progress:
- Height: 8px
- Background: Light gray
- Fill: Blue gradient
- Animated fill
- Percentage text above

Step Progress:
- Circles for each step
- Lines connecting steps
- Completed: Blue fill
- Current: Blue border
- Pending: Gray border

Loading Spinner:
- Size: 40px
- Color: Blue
- Animation: Spin
- Centered in container
```

---

## 8. FILE STRUCTURE & ORGANIZATION

### 8.1 Project Directory Structure

```
spring-boot-api-generator/
├── backend/
│   ├── app.py                          # Flask application entry
│   ├── requirements.txt                # Python dependencies
│   ├── config/
│   │   ├── __init__.py
│   │   ├── settings.py                 # Configuration settings
│   │   └── logging_config.py           # Logging configuration
│   ├── api/
│   │   ├── __init__.py
│   │   ├── routes.py                   # API route definitions
│   │   └── schemas.py                  # Request/response schemas
│   ├── services/
│   │   ├── __init__.py
│   │   ├── spring_initializr_service.py
│   │   ├── code_generator_service.py
│   │   ├── project_modifier_service.py
│   │   ├── llm_enhancement_service.py
│   │   └── validation_service.py
│   ├── templates/
│   │   ├── controllers/
│   │   ├── services/
│   │   ├── dtos/
│   │   ├── exceptions/
│   │   ├── config/
│   │   └── documentation/
│   │       └── readme-gradle.md.template
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── file_utils.py
│   │   ├── validation_utils.py
│   │   └── template_utils.py
│   └── tests/
│       ├── __init__.py
│       ├── test_services.py
│       ├── test_routes.py
│       └── fixtures/
├── frontend/
│   ├── index.html                      # Main HTML page
│   ├── css/
│   │   ├── main.css                    # Main styles
│   │   ├── components.css              # Component styles
│   │   └── responsive.css              # Responsive styles
│   ├── js/
│   │   ├── app.js                      # Main application logic
│   │   ├── api-client.js               # API communication
│   │   ├── form-manager.js             # Form handling
│   │   ├── code-preview.js             # Code display
│   │   └── validation.js               # Client-side validation
│   └── assets/
│       ├── images/
│       └── icons/
├── docs/
│   ├── API.md                          # API documentation
│   ├── ARCHITECTURE.md                 # Architecture overview
│   └── USER_GUIDE.md                   # User manual
├── .env.example                        # Environment variables template
├── .gitignore
├── README.md
└── LICENSE
```

### 8.2 Generated Gradle Project Structure

```
{project-name}/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── {package-path}/
│   │   │       ├── Application.java           # Main application class
│   │   │       ├── controller/
│   │   │       │   └── {Entity}Controller.java
│   │   │       ├── service/
│   │   │       │   ├── {Entity}Service.java    # Interface
│   │   │       │   └── impl/
│   │   │       │       └── {Entity}ServiceImpl.java
│   │   │       ├── dto/
│   │   │       │   ├── request/
│   │   │       │   │   ├── Create{Entity}Request.java
│   │   │       │   │   └── Update{Entity}Request.java
│   │   │       │   └── response/
│   │   │       │       ├── {Entity}Response.java
│   │   │       │       └── PagedResponse.java (if pagination)
│   │   │       ├── exception/
│   │   │       │   ├── GlobalExceptionHandler.java
│   │   │       │   ├── ResourceNotFoundException.java
│   │   │       │   ├── ValidationException.java
│   │   │       │   └── ApiError.java
│   │   │       ├── config/
│   │   │       │   ├── WebConfig.java (if needed)
│   │   │       │   ├── CorsConfig.java (if enabled)
│   │   │       │   └── SwaggerConfig.java (if docs enabled)
│   │   │       └── util/
│   │   │           └── DateUtil.java (if date operations)
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── application-dev.properties
│   │       └── application-prod.properties
│   └── test/
│       └── java/
│           └── {package-path}/
│               ├── ApplicationTests.java
│               └── controller/
│                   └── {Entity}ControllerTest.java (if generated)
├── gradle/
│   └── wrapper/
│       ├── gradle-wrapper.jar
│       └── gradle-wrapper.properties
├── build/                               # Generated by Gradle (gitignored)
├── .gradle/                             # Gradle cache (gitignored)
├── build.gradle                         # Gradle build configuration
├── settings.gradle                      # Gradle settings
├── gradlew                              # Gradle wrapper script (Unix)
├── gradlew.bat                          # Gradle wrapper script (Windows)
├── README.md                            # Project documentation
├── API_DOCUMENTATION.md                 # API reference
├── .gitignore
└── HELP.md                              # Getting started guide
```

### 8.3 Configuration Files

#### application.properties Template
```properties
# Server Configuration
server.port=${serverPort:8080}
server.servlet.context-path=${contextPath:/}

# Application
spring.application.name=${projectName}

# Logging
logging.level.root=INFO
logging.level.${packageName}=${logLevel:DEBUG}
logging.pattern.console=%d{yyyy-MM-dd HH:mm:ss} - %msg%n

# Jackson JSON
spring.jackson.default-property-inclusion=non_null
spring.jackson.serialization.write-dates-as-timestamps=false

# API Documentation (if enabled)
springdoc.api-docs.path=/api-docs
springdoc.swagger-ui.path=/swagger-ui.html
springdoc.swagger-ui.tags-sorter=alpha
springdoc.swagger-ui.operations-sorter=method

# CORS (if enabled)
cors.allowed-origins=*
cors.allowed-methods=GET,POST,PUT,DELETE,OPTIONS
cors.allowed-headers=*

# Validation
spring.mvc.throw-exception-if-no-handler-found=true
spring.web.resources.add-mappings=false
```

#### build.gradle Structure
```groovy
plugins {
    id 'java'
    id 'org.springframework.boot' version '${springBootVersion}'
    id 'io.spring.dependency-management' version '1.1.4'
}

group = '${groupId}'
version = '0.0.1-SNAPSHOT'

java {
    sourceCompatibility = '${javaVersion}'
}

configurations {
    compileOnly {
        extendsFrom annotationProcessor
    }
}

repositories {
    mavenCentral()
}

dependencies {
    // Spring Boot Starters
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'org.springframework.boot:spring-boot-starter-validation'
    
    // Lombok
    compileOnly 'org.projectlombok:lombok'
    annotationProcessor 'org.projectlombok:lombok'
    
    {{#if includeDocumentation}}
    // OpenAPI Documentation
    implementation 'org.springdoc:springdoc-openapi-starter-webmvc-ui:2.2.0'
    {{/if}}
    
    {{#if database}}
    // Database
    implementation '${databaseDependency}'
    {{/if}}
    
    {{#if security}}
    // Security
    implementation 'org.springframework.boot:spring-boot-starter-security'
    {{/if}}
    
    // Dev Tools
    developmentOnly 'org.springframework.boot:spring-boot-devtools'
    
    // Test
    testImplementation 'org.springframework.boot:spring-boot-starter-test'
}

tasks.named('test') {
    useJUnitPlatform()
}
```

#### settings.gradle Structure
```groovy
rootProject.name = '${artifactId}'
```

---

## 9. INTEGRATION POINTS

### 9.1 Spring Initializr Integration

#### API Endpoint Details
```
Production Endpoint:
URL: https://start.spring.io
Protocol: HTTPS
Method: POST
Content-Type: application/x-www-form-urlencoded

Build Tool Configuration:
type: gradle-project (ALWAYS)
language: java
```

#### Request Format for Gradle
```
Form Data Parameters:
type=gradle-project
language=java
bootVersion=3.2.0
baseDir=demo
groupId=com.example
artifactId=demo
name=demo
description=Demo+project
packageName=com.example.demo
packaging=jar
javaVersion=17
dependencies=web,lombok,validation

Example Full URL:
https://start.spring.io/starter.zip?type=gradle-project&language=java&bootVersion=3.2.0&groupId=com.example&artifactId=demo&name=demo&description=Demo+project&packageName=com.example.demo&packaging=jar&javaVersion=17&dependencies=web,lombok,validation
```

#### Response Handling
```
Success Response:
- Status: 200 OK
- Content-Type: application/zip
- Content-Disposition: attachment; filename="demo.zip"
- Body: Binary ZIP file containing Gradle project

ZIP Contents Verification:
- Must contain: build.gradle
- Must contain: settings.gradle
- Must contain: gradlew and gradlew.bat
- Must contain: gradle/ directory with wrapper files
- Must contain: src/ directory structure

Error Responses:
- 400: Invalid parameters
  Response format: {"message": "error details"}
  
- 404: Boot version or dependency not found
  
- 503: Service temporarily unavailable
  Action: Retry with exponential backoff
```

#### Error Recovery Strategy
```
Retry Logic:
1. Attempt 1: Immediate
2. Attempt 2: Wait 1 second
3. Attempt 3: Wait 2 seconds
4. If all fail: Return error (no fallback in POC)

Logging:
- Log all API calls
- Log response times
- Log failures for monitoring

User Notification:
- Clear error messages
- Suggest checking Spring Initializr status
- Provide retry option
```

### 9.2 Vertex AI Integration (Optional)

#### Authentication
```
Authentication Method: Service Account
Required Permissions:
- aiplatform.endpoints.predict
- aiplatform.models.get

Environment Variables:
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
VERTEX_AI_PROJECT_ID=your-project-id
VERTEX_AI_LOCATION=us-central1
VERTEX_AI_MODEL=gemini-pro

SDK Initialization:
- Import: google.cloud.aiplatform
- Initialize: aiplatform.init(project=..., location=...)
- Model: GenerativeModel('gemini-pro')
```

#### API Call Structure
```
Request Format:
{
  "contents": [
    {
      "role": "user",
      "parts": [
        {
          "text": "{prompt}"
        }
      ]
    }
  ],
  "generation_config": {
    "temperature": 0.2,
    "top_p": 0.8,
    "top_k": 40,
    "max_output_tokens": 2048,
    "stop_sequences": []
  },
  "safety_settings": [
    {
      "category": "HARM_CATEGORY_HARASSMENT",
      "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    }
  ]
}
```

#### Configuration Parameters
```
Model Configuration:
Model: gemini-pro
Temperature: 0.2 (low for consistency)
Top P: 0.8
Top K: 40
Max Tokens: 2048
Timeout: 30 seconds

Retry Configuration:
Max Retries: 3
Backoff: Exponential (1s, 2s, 4s)
Timeout Handling: Skip enhancement, use basic documentation

For POC:
- Optional feature
- Can be disabled
- Graceful fallback to template docs
```

#### Error Handling
```
Common Errors:

1. Authentication Error:
   - Check service account credentials
   - Verify permissions
   - Fallback: Skip LLM enhancement

2. Rate Limit Exceeded:
   - Wait and retry
   - Fallback: Template documentation

3. Timeout:
   - Cancel request
   - Don't retry for timeouts
   - Fallback: Skip enhancement

4. Content Safety Block:
   - Log blocked content
   - Fallback: Basic documentation

For POC: All LLM errors result in graceful fallback
```

---

## 10. CONFIGURATION & SETTINGS

### 10.1 Environment Variables

```
# Application
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-secret-key-here
PORT=5000

# Spring Initializr
SPRING_INITIALIZR_URL=https://start.spring.io
SPRING_INITIALIZR_TIMEOUT=30
SPRING_INITIALIZR_RETRY_COUNT=3
SPRING_INITIALIZR_CACHE_TTL=3600
BUILD_TOOL=gradle

# Vertex AI (Optional - for POC can be disabled)
GOOGLE_APPLICATION_CREDENTIALS=/path/to/credentials.json
VERTEX_AI_PROJECT_ID=your-project-id
VERTEX_AI_LOCATION=us-central1
VERTEX_AI_MODEL=gemini-pro
VERTEX_AI_TEMPERATURE=0.2
VERTEX_AI_MAX_TOKENS=2048
VERTEX_AI_TIMEOUT=30
VERTEX_AI_ENABLED=False

# File Storage
MAX_UPLOAD_SIZE=10485760  # 10MB
TEMP_DIR=/tmp/api-generator
CLEANUP_INTERVAL=3600  # 1 hour
FILE_RETENTION_HOURS=24

# Logging
LOG_LEVEL=DEBUG
LOG_FILE=/var/log/api-generator/app.log

# CORS (for POC - allow all)
CORS_ENABLED=True
CORS_ORIGINS=*
```

### 10.2 Application Settings

```
Application Configuration (settings.py):

general:
  app_name: "Spring Boot API Generator"
  version: "1.0.0-POC"
  environment: "development"
  
server:
  host: "0.0.0.0"
  port: 5000
  workers: 2
  timeout: 30
  
spring_initializr:
  url: "https://start.spring.io"
  timeout: 30
  retry_attempts: 3
  retry_delay: 1
  cache_metadata: true
  cache_ttl: 3600
  build_tool: "gradle"
  
  default_config:
    type: "gradle-project"
    language: "java"
    bootVersion: "3.2.0"
    javaVersion: "17"
    packaging: "jar"
    
  available_boot_versions:
    - "3.2.0"
    - "3.1.5"
    
  available_java_versions:
    - "17"
    - "21"

code_generation:
  template_dir: "./templates"
  include_comments: true
  include_logging: true
  java_indentation: 4
  max_line_length: 120
  build_tool: "gradle"
  
  naming_conventions:
    controller_suffix: "Controller"
    service_suffix: "Service"
    service_impl_suffix: "ServiceImpl"
    request_suffix: "Request"
    response_suffix: "Response"
    
  packages:
    controller: "controller"
    service: "service"
    service_impl: "service.impl"
    dto_request: "dto.request"
    dto_response: "dto.response"
    exception: "exception"
    config: "config"

llm_enhancement:
  enabled: false  # Disabled by default for POC
  provider: "vertex_ai"
  model: "gemini-pro"
  temperature: 0.2
  max_tokens: 2048
  timeout: 30
  
  features:
    javadoc_generation: true
    readme_generation: true
    examples_generation: true
    
validation:
  strict_mode: false  # Relaxed for POC
  max_endpoints: 10
  max_parameters_per_endpoint: 10
  max_fields_per_dto: 20
  
file_handling:
  temp_directory: "/tmp/api-generator"
  max_file_size: 10485760  # 10MB
  retention_hours: 24
  cleanup_enabled: true
```

### 10.3 Gradle-Specific Configuration

```
Gradle Configuration (gradle_config.yaml):

gradle:
  version: "8.5"
  wrapper_version: "8.5"
  java_compatibility: "17"
  
  default_plugins:
    - java
    - org.springframework.boot
    - io.spring.dependency-management
    
  repositories:
    - mavenCentral()
    
  standard_dependencies:
    implementation:
      - org.springframework.boot:spring-boot-starter-web
      - org.springframework.boot:spring-boot-starter-validation
    compileOnly:
      - org.projectlombok:lombok
    annotationProcessor:
      - org.projectlombok:lombok
    developmentOnly:
      - org.springframework.boot:spring-boot-devtools
    testImplementation:
      - org.springframework.boot:spring-boot-starter-test
      
  tasks:
    test:
      useJUnitPlatform: true
      
  gradle_properties:
    org.gradle.daemon: true
    org.gradle.parallel: true
    org.gradle.caching: true
```

---

## 11. ERROR HANDLING STRATEGY

### 11.1 Error Categories

```
Error Classification:

1. Client Errors (4xx)
   - Invalid input
   - Validation failures
   - Missing required fields
   
2. Server Errors (5xx)
   - Internal processing errors
   - External service failures
   - Timeout errors
   
3. Integration Errors
   - Spring Initializr unavailable
   - Vertex AI errors (optional)
   - Network issues
   
4. Resource Errors
   - File system errors
   - Memory issues
```

### 11.2 Error Handling Flow

```
Error Handling Pipeline:

User Request
     ↓
[Input Validation]
     ├─ Invalid → Return 400 with details
     ↓
[Service Processing]
     ├─ Error Occurred
     │     ↓
     │  [Determine Error Type]
     │     ├─ Retryable? → Retry with backoff
     │     └─ Critical? → Return error
     ↓
[Error Logging]
     ├─ Log error details
     ├─ Log stack trace
     └─ Log request context
     ↓
[Error Response]
     ├─ Format error message
     ├─ Add request ID
     ├─ Include suggestions
     └─ Return to user
```

### 11.3 Specific Error Scenarios

#### Scenario 1: Spring Initializr Unavailable
```
Detection:
- HTTP timeout
- Connection refused
- 503 response

Response Strategy:
1. Retry 3 times with exponential backoff
2. If all retries fail:
   - Log incident
   - Return error to user
   - Suggest trying again later

User Message:
"Spring Initializr is temporarily unavailable. Please try again in a few minutes. 
If the problem persists, visit https://start.spring.io to check service status."

No Fallback: POC focuses on successful path, no fallback template
```

#### Scenario 2: Invalid User Input
```
Detection:
- Validation service identifies issues
- Required fields missing
- Invalid format
- Build tool not Gradle

Response:
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Your input contains validation errors",
    "errors": [
      {
        "field": "projectConfiguration.groupId",
        "value": "123invalid",
        "error": "Must be valid Java package format",
        "suggestion": "Use lowercase letters and dots (e.g., com.example)"
      },
      {
        "field": "projectConfiguration.buildTool",
        "value": "maven",
        "error": "Only Gradle is supported in this version",
        "suggestion": "Build tool is automatically set to Gradle"
      }
    ]
  }
}

Status Code: 400
Recovery: User fixes input and resubmits
```

#### Scenario 3: Code Generation Failure
```
Detection:
- Template rendering error
- Variable missing
- Invalid template syntax

Response Strategy:
1. Log error with full context
2. Return error to user
3. Include which component failed
4. Provide error ID for support

User Message:
"We encountered an issue generating your project. Error ID: {uuid}
Please check your inputs and try again. If the problem persists, 
contact support with the error ID."

POC Approach: Fail fast, log clearly, no partial generation
```

#### Scenario 4: LLM Enhancement Failure (Optional Feature)
```
Detection:
- Vertex AI timeout
- Rate limit exceeded
- Authentication error

Response Strategy:
1. Log error
2. Skip LLM enhancement
3. Use basic template comments
4. Continue with generation
5. Notify user (non-blocking)

User Message:
"AI documentation enhancement is temporarily unavailable. 
We've included standard code comments instead. 
Your project functionality is not affected."

Fallback:
- Use template-based JavaDoc
- Use standard README template
- Project generation completes successfully
```

#### Scenario 5: Gradle File Modification Failure
```
Detection:
- build.gradle parsing error
- Invalid Groovy syntax
- File write error

Response Strategy:
1. Log error with context
2. Attempt with minimal modifications
3. If still fails, create project without custom dependencies
4. Notify user of limitations

User Message:
"We couldn't add some custom configurations to build.gradle. 
The project has been generated with standard settings. 
You can manually add additional dependencies if needed."

Recovery:
- Provide instructions for manual dependency addition
- Include dependency list in README
```

### 11.4 Error Logging Format

```
Log Entry Structure:

{
  "timestamp": "2025-01-15T10:30:45.123Z",
  "level": "ERROR",
  "logger": "service.CodeGeneratorService",
  "requestId": "uuid-here",
  "errorCode": "CODE_GENERATION_ERROR",
  "errorMessage": "Failed to render controller template",
  "stackTrace": "...",
  "context": {
    "serviceName": "CodeGeneratorService",
    "methodName": "generate_controller",
    "buildTool": "gradle",
    "inputSpec": {
      "className": "UserController",
      "endpoints": [...]
    },
    "templateName": "basic-rest-controller.java.template"
  },
  "systemInfo": {
    "memoryUsage": "65%",
    "diskSpace": "80%"
  }
}
```

### 11.5 User-Facing Error Messages

```
Error Message Principles for POC:
1. Be clear and specific
2. Explain what happened
3. Suggest what to do next
4. Provide error ID for support
5. Avoid technical jargon
6. Be honest about limitations

Examples:

Good Error Message:
"We couldn't generate your project because the controller name contains 
invalid characters. Please use only letters and numbers. (Error ID: abc-123)"

Bad Error Message:
"NullPointerException in template renderer at line 45"

Good Error Message:
"Spring Initializr is temporarily unavailable. Please wait a few minutes 
and try again. You can check service status at https://start.spring.io"

Bad Error Message:
"HTTP 503 Service Unavailable"
```

---

## 12. POC IMPLEMENTATION ROADMAP

### Phase 1: Core Setup (Week 1)
**Goal:** Basic application structure and Spring Initializr integration

**Tasks:**
1. Setup Flask application structure
   - Create project directories
   - Setup virtual environment
   - Install dependencies
   
2. Implement Spring Initializr client
   - API communication
   - Gradle project type (fixed)
   - Basic error handling
   - Response validation
   
3. Create simple UI
   - Single-page application
   - Basic form for project config
   - Gradle option pre-selected
   
4. Basic validation service
   - Input validation
   - Error messages
   
**Deliverable:** Can call Spring Initializr and download Gradle ZIP

---

### Phase 2: Code Generation (Week 2)
**Goal:** Template-based code generation for core components

**Tasks:**
1. Setup template system
   - Create template directory structure
   - Implement template engine
   - Variable substitution
   
2. Create basic templates
   - Controller template
   - Service interface template
   - DTO templates
   - Exception handler template
   
3. Implement code generator service
   - Template selection logic
   - Variable mapping
   - Code generation methods
   
4. Add generated code preview
   - Syntax highlighting
   - Copy functionality
   
**Deliverable:** Can generate controllers, services, and DTOs

---

### Phase 3: Project Modification (Week 3)
**Goal:** Inject generated code into Gradle project

**Tasks:**
1. Implement project modifier service
   - ZIP extraction
   - File system operations
   - Gradle project analysis
   
2. Code injection logic
   - Create package directories
   - Write generated files
   - Maintain project structure
   
3. Configuration updates
   - application.properties modifications
   - build.gradle additions (optional)
   - Handle Gradle wrapper
   
4. Re-packaging
   - Create final ZIP
   - Validation
   - Download functionality
   
**Deliverable:** Complete Gradle project generation end-to-end

---

### Phase 4: UI Enhancement (Week 4)
**Goal:** Improve user experience and add multi-step flow

**Tasks:**
1. Multi-step form
   - Step 1: Project configuration
   - Step 2: API design
   - Step 3: Options
   - Step 4: Review
   
2. Dynamic endpoint management
   - Add/remove endpoints
   - Parameter management
   - Response configuration
   
3. Validation improvements
   - Real-time validation
   - Error highlighting
   - Suggestions
   
4. Progress indicators
   - Generation progress
   - Status messages
   - Time estimates
   
**Deliverable:** Polished, intuitive user interface

---

### Phase 5: LLM Integration (Week 5 - Optional)
**Goal:** Add optional AI-powered documentation

**Tasks:**
1. Vertex AI client setup
   - Authentication
   - API integration
   - Error handling
   
2. Prompt engineering
   - JavaDoc generation prompts
   - README generation prompts
   - Example generation
   
3. Integration with generation flow
   - Optional enhancement step
   - Fallback mechanisms
   - User notification
   
4. Documentation templates
   - Gradle-specific README
   - API documentation
   - Usage examples with Gradle commands
   
**Deliverable:** Optional AI documentation enhancement

---

### Phase 6: Testing & Polish (Week 6)
**Goal:** Ensure reliability and fix issues

**Tasks:**
1. Manual testing
   - Test all user flows
   - Try different configurations
   - Edge cases
   - Error scenarios
   
2. Bug fixes
   - Address found issues
   - Improve error messages
   - Fix UI glitches
   
3. Documentation
   - User guide
   - API documentation
   - README with setup instructions
   - Troubleshooting guide
   
4. Code cleanup
   - Remove debug code
   - Add comments
   - Improve naming
   - Format code
   
**Deliverable:** Stable, documented POC

---

### POC Success Criteria

**Must Have:**
- ✅ Generate Gradle projects via Spring Initializr
- ✅ Generate controllers with endpoints
- ✅ Generate service layer
- ✅ Generate DTOs
- ✅ Generate exception handlers
- ✅ Working multi-step UI
- ✅ Input validation
- ✅ Code preview
- ✅ Project download
- ✅ Gradle wrapper included
- ✅ Basic error handling

**Should Have:**
- ✅ Multiple endpoint support
- ✅ Request/response configuration
- ✅ Swagger documentation
- ✅ Application properties configuration
- ✅ Logging setup
- ✅ Progress indicators

**Nice to Have:**
- 🎯 LLM documentation enhancement
- 🎯 Gradle task examples
- 🎯 Advanced validation
- 🎯 Template customization
- 🎯 Export configuration

**Out of Scope for POC:**
- ❌ User authentication
- ❌ Project history
- ❌ Database integration code
- ❌ Test generation
- ❌ CI/CD configuration
- ❌ Deployment scripts
- ❌ Maven support (Gradle only)
- ❌ Multiple language support (Java only)

---

### POC Timeline Summary

```
Week 1: Core Setup + Spring Initializr Integration
Week 2: Code Generation Templates
Week 3: Project Modification & Injection
Week 4: UI Enhancement
Week 5: LLM Integration (Optional)
Week 6: Testing & Polish

Total: 6 weeks for complete POC
Minimum Viable: 4 weeks (without LLM and advanced features)
```

---

### POC Testing Checklist

**Functional Tests:**
- [ ] Generate simple project (1 endpoint)
- [ ] Generate complex project (5+ endpoints)
- [ ] All HTTP methods work (GET, POST, PUT, DELETE, PATCH)
- [ ] Path parameters work
- [ ] Query parameters work
- [ ] Request body validation works
- [ ] Response DTOs generated correctly
- [ ] Service layer generated
- [ ] Exception handling works
- [ ] Gradle project builds successfully
- [ ] Gradle bootRun starts application
- [ ] Swagger UI accessible
- [ ] All generated files have valid syntax

**UI Tests:**
- [ ] All form fields validate correctly
- [ ] Multi-step flow works
- [ ] Add/remove endpoints works
- [ ] Code preview displays correctly
- [ ] Download works
- [ ] Progress indicators show
- [ ] Error messages display clearly
- [ ] Responsive on tablet/mobile

**Integration Tests:**
- [ ] Spring Initializr API calls succeed
- [ ] ZIP extraction works
- [ ] Code injection works
- [ ] Gradle files modified correctly
- [ ] Re-packaging creates valid ZIP
- [ ] LLM enhancement works (if enabled)

**Error Handling Tests:**
- [ ] Invalid input shows errors
- [ ] Spring Initializr down handled gracefully
- [ ] Gradle file modification errors handled
- [ ] Large projects (10+ endpoints) work
- [ ] Special characters in names handled
- [ ] Network timeout handled

---

## APPENDIX A: Gradle vs Maven Key Differences

### Build File
```
Maven: pom.xml (XML format)
Gradle: build.gradle (Groovy/Kotlin DSL format)

Maven is more verbose, Gradle is more concise
```

### Wrapper
```
Maven: mvnw, mvnw.cmd
Gradle: gradlew, gradlew.bat

Both serve same purpose: version-locked build tool
```

### Commands
```
Maven:
- ./mvnw spring-boot:run
- ./mvnw clean install
- ./mvnw test

Gradle:
- ./gradlew bootRun
- ./gradlew build
- ./gradlew test
```

### Dependencies
```
Maven:
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-web</artifactId>
</dependency>

Gradle:
implementation 'org.springframework.boot:spring-boot-starter-web'
```

### Project Structure
```
Both use same source structure:
src/main/java
src/main/resources
src/test/java

Build output:
Maven: target/
Gradle: build/
```

---

## APPENDIX B: Quick Reference

### Common Gradle Commands
```bash
# Build project
./gradlew build

# Run application
./gradlew bootRun

# Run tests
./gradlew test

# Clean build directory
./gradlew clean

# List all tasks
./gradlew tasks

# Show dependencies
./gradlew dependencies

# Create executable JAR
./gradlew bootJar

# Build without tests
./gradlew build -x test
```

### Generated Project Quick Start
```bash
# 1. Extract ZIP
unzip generated-project.zip

# 2. Navigate to project
cd generated-project

# 3. Make gradlew executable (Unix/Mac)
chmod +x gradlew

# 4. Build project
./gradlew build

# 5. Run application
./gradlew bootRun

# 6. Access application
# http://localhost:8080

# 7. Access Swagger UI (if enabled)
# http://localhost:8080/swagger-ui.html
```

### Troubleshooting
```bash
# Permission denied on gradlew
chmod +x gradlew

# Build fails
./gradlew clean build --refresh-dependencies

# Port already in use
# Change port in application.properties:
# server.port=8081

# Gradle daemon issues
./gradlew --stop
```

---

## CONCLUSION

This POC specification provides a complete blueprint for building a Spring Boot API Generator that:

1. **Leverages Spring Initializr** for reliable Gradle project generation
2. **Uses deterministic templates** for fast, consistent code generation
3. **Focuses on Gradle** as the modern build tool
4. **Provides optional LLM enhancement** for documentation
5. **Delivers production-ready code** that developers can run immediately

The POC approach allows for rapid development and validation of core concepts before investing in advanced features like security, performance optimization, and deployment infrastructure.

**Key Success Factor:** The generated Gradle projects must be immediately runnable with `./gradlew bootRun` - this is the primary measure of success.

**Next Steps After POC:**
1. Gather user feedback
2. Identify most-used features
3. Prioritize enhancements
4. Add security and production features
5. Consider adding Maven support
6. Implement user accounts and project history

---

**Document Version:** 1.0 POC  
**Last Updated:** January 2025  
**Target Audience:** Development Team  
**Status:** Ready for Implementation
