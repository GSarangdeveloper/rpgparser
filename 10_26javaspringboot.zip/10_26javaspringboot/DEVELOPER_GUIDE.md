# Developer Guide - Spring Boot API Generator

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Development Setup](#development-setup)
3. [Project Structure](#project-structure)
4. [Core Components](#core-components)
5. [Services Documentation](#services-documentation)
6. [Templates System](#templates-system)
7. [Adding New Features](#adding-new-features)
8. [Testing](#testing)
9. [Debugging](#debugging)
10. [Contributing](#contributing)

## Architecture Overview

### System Architecture

The Spring Boot API Generator follows a 4-layer architecture pattern:

```
┌─────────────────────────────────────────────────────────────┐
│                    Presentation Layer                        │
│                  (Web UI & REST Controllers)                 │
├─────────────────────────────────────────────────────────────┤
│                    Application Layer                         │
│              (Validation & Business Logic)                   │
├─────────────────────────────────────────────────────────────┤
│                     Service Layer                           │
│            (Parsers, Generators, Modifiers)                 │
├─────────────────────────────────────────────────────────────┤
│                   Integration Layer                         │
│           (Spring Initializr, File System)                  │
└─────────────────────────────────────────────────────────────┘
```

### Data Flow

```mermaid
graph LR
    A[User Input] --> B[Validation]
    B --> C[Parser Service]
    C --> D[Configuration]
    D --> E[Spring Initializr]
    E --> F[Code Generator]
    F --> G[Project Modifier]
    G --> H[ZIP Output]
```

### Technology Stack

- **Backend**: Flask 3.0.0 (Python 3.8+)
- **Template Engine**: Jinja2 3.1.2
- **HTTP Client**: Requests 2.31.0
- **Configuration**: python-dotenv 1.0.0
- **YAML Parser**: PyYAML 6.0.1
- **Generated Code**: Spring Boot 3.2.0, Java 17/21, Gradle

## Development Setup

### Prerequisites

```bash
# Check Python version (3.8+ required)
python --version

# Check pip version
pip --version

# Check git version
git --version
```

### Local Development

1. **Clone Repository**
```bash
git clone https://github.com/yourusername/spring-boot-api-generator.git
cd spring-boot-api-generator
```

2. **Create Virtual Environment**
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows
venv\Scripts\activate
# On Unix/MacOS
source venv/bin/activate
```

3. **Install Dependencies**
```bash
# Install production dependencies
pip install -r requirements.txt

# Install development dependencies
pip install -r requirements-dev.txt
```

4. **Environment Configuration**
```bash
# Create .env file
cp .env.example .env

# Edit .env file
FLASK_ENV=development
FLASK_DEBUG=True
FLASK_PORT=5000
LOG_LEVEL=DEBUG
```

5. **Run Application**
```bash
# Development mode with auto-reload
python app.py

# Or using Flask CLI
flask run --debug
```

### Development Tools

#### IDE Setup

**VS Code**
```json
// .vscode/settings.json
{
  "python.linting.enabled": true,
  "python.linting.pylintEnabled": true,
  "python.formatting.provider": "black",
  "python.testing.pytestEnabled": true,
  "python.testing.unittestEnabled": false,
  "editor.formatOnSave": true
}
```

**PyCharm**
- Configure Python interpreter to use virtual environment
- Enable Flask support in project settings
- Configure code style to use PEP 8

#### Pre-commit Hooks

```bash
# Install pre-commit
pip install pre-commit

# Install git hooks
pre-commit install

# Run manually
pre-commit run --all-files
```

`.pre-commit-config.yaml`:
```yaml
repos:
  - repo: https://github.com/psf/black
    rev: 23.0.0
    hooks:
      - id: black
  - repo: https://github.com/PyCQA/flake8
    rev: 6.0.0
    hooks:
      - id: flake8
  - repo: https://github.com/PyCQA/isort
    rev: 5.12.0
    hooks:
      - id: isort
```

## Project Structure

### Directory Structure

```
spring-boot-api-generator/
├── app.py                          # Main Flask application
├── requirements.txt                # Production dependencies
├── requirements-dev.txt            # Development dependencies
├── .env.example                    # Environment variables template
├── run.sh                         # Unix startup script
├── run.bat                        # Windows startup script
│
├── services/                      # Service layer
│   ├── __init__.py               # Package initializer
│   ├── initializr_service.py     # Spring Initializr integration
│   ├── code_generator_service.py # Code generation logic
│   ├── project_modifier_service.py # Project modification
│   ├── validation_service.py     # Input validation
│   ├── openapi_parser_service.py # OpenAPI/Swagger parser
│   ├── postman_parser_service.py # Postman collection parser
│   └── error_handler.py         # Error handling utilities
│
├── templates/                     # Jinja2 templates
│   ├── java/                     # Java code templates
│   │   ├── controller.java.j2    # REST controller
│   │   ├── controller_test.java.j2 # Controller tests
│   │   ├── service.java.j2       # Service interface
│   │   ├── service_impl.java.j2  # Service implementation
│   │   ├── dto_request.java.j2   # Request DTOs
│   │   ├── dto_response.java.j2  # Response DTOs
│   │   ├── entity.java.j2        # JPA entities
│   │   ├── repository.java.j2    # JPA repositories
│   │   ├── exception.java.j2     # Custom exceptions
│   │   └── global_exception_handler.java.j2
│   ├── index.html                # Main UI
│   ├── index_enhanced.html       # Enhanced UI
│   └── index_v2.html             # V2 UI with file upload
│
├── static/                        # Static assets
│   ├── css/                      # Stylesheets
│   │   ├── style.css            # Main styles
│   │   └── components.css       # Component styles
│   ├── js/                       # JavaScript files
│   │   ├── main.js              # Main application JS
│   │   ├── file-upload.js       # File upload handler
│   │   └── api-client.js        # API client
│   └── samples/                  # Sample files
│       ├── openapi-sample.yaml
│       ├── custom-sample.json
│       └── postman-sample.json
│
├── tests/                        # Test files
│   ├── __init__.py
│   ├── test_integration.py      # Integration tests
│   ├── test_parsers.py          # Parser tests
│   ├── test_generators.py       # Generator tests
│   └── test_validation.py       # Validation tests
│
├── generated_projects/           # Output directory
│   └── .gitkeep
│
└── docs/                        # Documentation
    ├── API.md                   # API documentation
    ├── DEVELOPER.md             # Developer guide
    └── DEPLOYMENT.md            # Deployment guide
```

### Module Organization

```python
# services/__init__.py
from .initializr_service import InitializrService
from .code_generator_service import CodeGeneratorService
from .project_modifier_service import ProjectModifierService
from .validation_service import ValidationService
from .openapi_parser_service import OpenAPIParserService
from .postman_parser_service import PostmanParserService
from .error_handler import ErrorHandler

__all__ = [
    'InitializrService',
    'CodeGeneratorService',
    'ProjectModifierService',
    'ValidationService',
    'OpenAPIParserService',
    'PostmanParserService',
    'ErrorHandler'
]
```

## Core Components

### Flask Application (app.py)

```python
# Main application structure
app = Flask(__name__)

# Service initialization
initializr_service = InitializrService()
code_generator_service = CodeGeneratorService()
project_modifier_service = ProjectModifierService()
validation_service = ValidationService()
openapi_parser_service = OpenAPIParserService()
postman_parser_service = PostmanParserService()

# Route registration
@app.route('/api/v1/generate/project', methods=['POST'])
def generate_project_v1():
    # Implementation
    pass
```

### Request Flow

1. **Request Reception**: Flask route handler receives request
2. **Validation**: ValidationService validates input
3. **Parsing**: Parser services process specification
4. **Generation**: CodeGeneratorService creates code
5. **Modification**: ProjectModifierService integrates code
6. **Response**: ZIP file or JSON response sent

### Error Handling

```python
@app.errorhandler(ValidationError)
def handle_validation_error(e):
    return jsonify({
        'success': False,
        'error': {
            'code': e.code,
            'message': e.message,
            'details': e.details
        }
    }), 400

@app.errorhandler(Exception)
def handle_generic_error(e):
    return ErrorHandler.handle_error(e, 'request_handler'), 500
```

## Services Documentation

### InitializrService

**Purpose**: Integrates with Spring Initializr to download base projects.

**Key Features**:
- Retry logic with exponential backoff
- Metadata caching for performance
- Configurable timeout
- Error handling for service unavailability

```python
class InitializrService:
    BASE_URL = "https://start.spring.io"
    TIMEOUT = 30
    RETRY_COUNT = 3
    RETRY_DELAY_BASE = 1

    def __init__(self):
        self.session = requests.Session()
        self.metadata_cache = {}
        self.cache_timestamp = None

    def download_project(self, config: Dict) -> bytes:
        """Download Spring Boot starter project"""
        # Implementation with retry logic
        pass

    def get_metadata(self) -> Dict:
        """Get Spring Initializr metadata with caching"""
        # Implementation with caching
        pass
```

### CodeGeneratorService

**Purpose**: Generates Java code using Jinja2 templates.

**Key Methods**:
```python
class CodeGeneratorService:
    def generate_code(
        self,
        project_config: Dict,
        api_spec: Dict,
        generation_options: Dict
    ) -> Dict[str, str]:
        """Generate all code files"""
        pass

    def _generate_controller(self, ...):
        """Generate controller class"""
        pass

    def _generate_service(self, ...):
        """Generate service interface and implementation"""
        pass

    def _generate_dto(self, ...):
        """Generate request/response DTOs"""
        pass
```

### ProjectModifierService

**Purpose**: Modifies ZIP files to add generated code.

**Key Methods**:
```python
class ProjectModifierService:
    def modify_project(
        self,
        zip_content: bytes,
        generated_files: Dict[str, str]
    ) -> bytes:
        """Add generated files to project ZIP"""
        pass

    def _find_src_path(self, zip_file):
        """Find source directory in ZIP"""
        pass

    def _update_build_file(self, zip_file, dependencies):
        """Update build.gradle with dependencies"""
        pass
```

### ValidationService

**Purpose**: 4-layer validation architecture.

**Validation Layers**:
1. **Input Sanitization**: Clean and normalize input
2. **Schema Validation**: Validate against schema
3. **Business Rules**: Apply business logic rules
4. **Dependency Validation**: Check dependencies

```python
class ValidationService:
    def validate(self, data: Dict, layer: ValidationLayer) -> Dict:
        """Validate data at specified layer"""
        validators = {
            ValidationLayer.INPUT_SANITIZATION: self._sanitize_input,
            ValidationLayer.SCHEMA_VALIDATION: self._validate_schema,
            ValidationLayer.BUSINESS_RULES: self._validate_business_rules,
            ValidationLayer.DEPENDENCY_VALIDATION: self._validate_dependencies
        }
        return validators[layer](data)
```

### OpenAPIParserService

**Purpose**: Parse OpenAPI 3.0 and Swagger 2.0 specifications.

**Key Methods**:
```python
class OpenAPIParserService:
    def parse_specification(self, spec: Dict) -> Dict:
        """Parse OpenAPI/Swagger specification"""
        if 'openapi' in spec:
            return self._parse_openapi_3(spec)
        elif 'swagger' in spec:
            return self._parse_swagger_2(spec)
        else:
            raise ParsingError("Unknown specification format")

    def parse_file(self, file_path: str) -> Dict:
        """Parse specification from file"""
        pass

    def parse_content(self, content: str, format: str) -> Dict:
        """Parse specification from string content"""
        pass
```

### PostmanParserService

**Purpose**: Parse Postman Collection v2.1 format.

**Key Features**:
- Nested folder support
- Variable resolution
- Request/response extraction
- Authentication detection

```python
class PostmanParserService:
    def parse_collection(self, collection_data: str) -> Dict:
        """Parse Postman collection"""
        pass

    def _parse_items(self, items: List, ...):
        """Recursively parse collection items"""
        pass

    def _parse_request(self, item: Dict, ...):
        """Parse individual request"""
        pass
```

### ErrorHandler

**Purpose**: Centralized error handling and formatting.

**Key Components**:
```python
class ErrorHandler:
    @staticmethod
    def handle_error(error: Exception, context: str = None) -> Dict:
        """Handle and format errors"""
        pass

    @staticmethod
    def validate_required_fields(data: Dict, fields: List, context: str):
        """Validate required fields"""
        pass

    @staticmethod
    def with_error_handling(context: str = None):
        """Decorator for error handling"""
        pass
```

## Templates System

### Template Structure

Templates use Jinja2 templating engine with custom filters and macros.

### Available Variables

All templates have access to:
- `package_name`: Base package name
- `class_name`: Controller/Service class name
- `endpoints`: List of endpoint configurations
- `imports`: Required import statements
- `timestamp`: Generation timestamp

### Custom Filters

```python
# In code_generator_service.py
def setup_filters(env):
    env.filters['camelcase'] = to_camel_case
    env.filters['pascalcase'] = to_pascal_case
    env.filters['snakecase'] = to_snake_case
    env.filters['kebabcase'] = to_kebab_case
    env.filters['pluralize'] = pluralize
```

### Example Template (controller.java.j2)

```jinja2
package {{ package_name }}.controller;

{% for import in imports %}
import {{ import }};
{% endfor %}

@RestController
@RequestMapping("{{ base_path }}")
@Slf4j
public class {{ class_name }}Controller {

    private final {{ class_name }}Service {{ class_name|lower }}Service;

    @Autowired
    public {{ class_name }}Controller({{ class_name }}Service {{ class_name|lower }}Service) {
        this.{{ class_name|lower }}Service = {{ class_name|lower }}Service;
    }

    {% for endpoint in endpoints %}
    @{{ endpoint.httpMethod|capitalize }}Mapping("{{ endpoint.path }}")
    public ResponseEntity<?> {{ endpoint.name }}(
        {% for param in endpoint.parameters %}
        @{{ param.annotation }} {{ param.type }} {{ param.name }}{% if not loop.last %},{% endif %}
        {% endfor %}
    ) {
        log.info("{{ endpoint.description }}");
        // TODO: Implement business logic
        return ResponseEntity.ok().build();
    }
    {% endfor %}
}
```

### Creating New Templates

1. Create template file in `templates/java/`
2. Define variables and structure
3. Register in CodeGeneratorService
4. Test with sample data

## Adding New Features

### Adding a New Parser

1. **Create Parser Service**
```python
# services/my_format_parser_service.py
class MyFormatParserService:
    def parse_specification(self, spec: str) -> Dict:
        """Parse custom format specification"""
        # Parse logic
        return {
            'projectConfiguration': {},
            'apiSpecification': {}
        }
```

2. **Register in app.py**
```python
from services.my_format_parser_service import MyFormatParserService
my_format_parser = MyFormatParserService()
```

3. **Update Upload Endpoint**
```python
@app.route('/api/v1/upload/specification', methods=['POST'])
def upload_specification():
    # Add format detection
    if is_my_format(file_content):
        parsed = my_format_parser.parse_specification(file_content)
```

### Adding New Generation Options

1. **Update Generation Options**
```python
# In request handler
generation_options = {
    'includeNewFeature': request_data.get('includeNewFeature', False)
}
```

2. **Update Code Generator**
```python
# In code_generator_service.py
if generation_options.get('includeNewFeature'):
    generated_files.update(self._generate_new_feature(...))
```

3. **Create Template**
```jinja2
# templates/java/new_feature.java.j2
package {{ package_name }}.feature;

public class NewFeature {
    // Implementation
}
```

### Adding New Endpoints

1. **Define Route**
```python
@app.route('/api/v1/new-endpoint', methods=['GET', 'POST'])
def new_endpoint():
    """New endpoint implementation"""
    pass
```

2. **Add Validation**
```python
def validate_new_endpoint_input(data):
    """Validate input for new endpoint"""
    ErrorHandler.validate_required_fields(data, ['field1', 'field2'])
```

3. **Document in API.md**
```markdown
### New Endpoint
**Endpoint:** `POST /api/v1/new-endpoint`
**Description:** ...
```

## Testing

### Test Structure

```python
# tests/test_example.py
import unittest
from services.example_service import ExampleService

class TestExampleService(unittest.TestCase):
    def setUp(self):
        """Set up test fixtures"""
        self.service = ExampleService()

    def test_functionality(self):
        """Test specific functionality"""
        result = self.service.method()
        self.assertEqual(result, expected)

    def tearDown(self):
        """Clean up after tests"""
        pass
```

### Running Tests

```bash
# Run all tests
python -m pytest

# Run specific test file
python -m pytest tests/test_parsers.py

# Run with coverage
python -m pytest --cov=services --cov-report=html

# Run with verbose output
python -m pytest -v

# Run specific test method
python -m pytest tests/test_parsers.py::TestOpenAPIParser::test_parse_openapi_3
```

### Test Categories

1. **Unit Tests**: Test individual components
2. **Integration Tests**: Test component interaction
3. **End-to-End Tests**: Test complete workflows
4. **Performance Tests**: Test response times and load

### Writing Tests

```python
# Test with mocking
from unittest.mock import Mock, patch

class TestWithMocking(unittest.TestCase):
    @patch('services.initializr_service.requests.get')
    def test_with_mock(self, mock_get):
        mock_get.return_value.status_code = 200
        mock_get.return_value.content = b'mock content'

        result = self.service.download_project({})
        self.assertIsNotNone(result)
        mock_get.assert_called_once()
```

### Test Data

Create test fixtures in `tests/fixtures/`:
```python
# tests/fixtures/sample_data.py
SAMPLE_OPENAPI = {
    'openapi': '3.0.0',
    'info': {'title': 'Test API', 'version': '1.0.0'},
    'paths': {}
}

SAMPLE_PROJECT_CONFIG = {
    'projectName': 'Test Project',
    'groupId': 'com.test',
    'artifactId': 'test-api'
}
```

## Debugging

### Debug Mode

```python
# Enable debug mode in .env
FLASK_ENV=development
FLASK_DEBUG=True
LOG_LEVEL=DEBUG
```

### Logging

```python
import logging

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Use in code
logger.debug('Debug message')
logger.info('Info message')
logger.warning('Warning message')
logger.error('Error message')
```

### Debug Tools

1. **Flask Debug Toolbar**
```bash
pip install flask-debugtoolbar
```

```python
from flask_debugtoolbar import DebugToolbarExtension
app.config['DEBUG_TB_ENABLED'] = True
toolbar = DebugToolbarExtension(app)
```

2. **Python Debugger (pdb)**
```python
import pdb

def debug_function():
    pdb.set_trace()  # Breakpoint
    # Code to debug
```

3. **VS Code Debugging**
```json
// .vscode/launch.json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Flask Debug",
      "type": "python",
      "request": "launch",
      "module": "flask",
      "env": {
        "FLASK_APP": "app.py",
        "FLASK_ENV": "development"
      },
      "args": ["run", "--debug"],
      "jinja": true
    }
  ]
}
```

### Common Issues

1. **Import Errors**
```python
# Add project root to Python path
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
```

2. **Template Not Found**
```python
# Check template path
template_dir = os.path.join(os.path.dirname(__file__), 'templates')
app = Flask(__name__, template_folder=template_dir)
```

3. **Service Initialization**
```python
# Lazy initialization
_service_instance = None

def get_service():
    global _service_instance
    if _service_instance is None:
        _service_instance = MyService()
    return _service_instance
```

## Contributing

### Development Workflow

1. **Fork Repository**
2. **Create Feature Branch**
```bash
git checkout -b feature/amazing-feature
```

3. **Make Changes**
```bash
# Make your changes
# Add tests
# Update documentation
```

4. **Run Tests**
```bash
python -m pytest
pre-commit run --all-files
```

5. **Commit Changes**
```bash
git add .
git commit -m "feat: add amazing feature"
```

6. **Push Branch**
```bash
git push origin feature/amazing-feature
```

7. **Create Pull Request**

### Code Style

- **Python**: Follow PEP 8
- **Docstrings**: Use Google style
- **Type Hints**: Use where applicable
- **Comments**: Clear and concise

### Commit Messages

Follow conventional commits:
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation
- `style:` Code style
- `refactor:` Refactoring
- `test:` Tests
- `chore:` Maintenance

### Pull Request Guidelines

1. **Description**: Clear description of changes
2. **Tests**: Include tests for new features
3. **Documentation**: Update relevant docs
4. **Screenshots**: Include for UI changes
5. **Breaking Changes**: Clearly marked

### Code Review Process

1. Automated tests must pass
2. Code style checks must pass
3. At least one reviewer approval
4. Documentation updated
5. No merge conflicts

## Performance Optimization

### Caching

```python
from functools import lru_cache

@lru_cache(maxsize=128)
def expensive_operation(param):
    """Cache expensive operations"""
    return result
```

### Async Operations

```python
from concurrent.futures import ThreadPoolExecutor

executor = ThreadPoolExecutor(max_workers=4)

def async_operation():
    future = executor.submit(long_running_task)
    return future.result()
```

### Database Optimization

```python
# Use connection pooling
# Batch operations
# Index frequently queried fields
```

## Security Considerations

### Input Validation

```python
# Always validate and sanitize input
def validate_input(data):
    # Remove dangerous characters
    # Validate against schema
    # Check business rules
    pass
```

### File Upload Security

```python
ALLOWED_EXTENSIONS = {'json', 'yaml', 'yml'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
```

### Secret Management

```python
# Never commit secrets
# Use environment variables
# Rotate keys regularly
import os
SECRET_KEY = os.environ.get('SECRET_KEY')
```

## Monitoring

### Health Checks

```python
@app.route('/api/v1/health')
def health_check():
    """Health check endpoint"""
    checks = {
        'database': check_database(),
        'services': check_services(),
        'disk_space': check_disk_space()
    }

    status = 'healthy' if all(checks.values()) else 'unhealthy'
    return jsonify({'status': status, 'checks': checks})
```

### Metrics Collection

```python
# Track generation metrics
metrics = {
    'projects_generated': 0,
    'average_generation_time': 0,
    'error_rate': 0
}
```

### Logging

```python
# Structured logging
import json

def log_event(event_type, data):
    log_entry = {
        'timestamp': datetime.utcnow().isoformat(),
        'event': event_type,
        'data': data
    }
    logger.info(json.dumps(log_entry))
```

## Resources

### Documentation
- [Flask Documentation](https://flask.palletsprojects.com/)
- [Jinja2 Documentation](https://jinja.palletsprojects.com/)
- [Spring Boot Reference](https://spring.io/projects/spring-boot)
- [OpenAPI Specification](https://swagger.io/specification/)

### Tools
- [Postman](https://www.postman.com/)
- [Swagger Editor](https://editor.swagger.io/)
- [Spring Initializr](https://start.spring.io/)

### Community
- GitHub Issues
- Stack Overflow
- Discord/Slack Channel

---

**Last Updated:** January 2024 | **Version:** 2.0.0