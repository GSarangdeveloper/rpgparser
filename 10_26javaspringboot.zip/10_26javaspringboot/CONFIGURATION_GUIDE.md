# Configuration Guide - Spring Boot API Generator

## Table of Contents
1. [Overview](#overview)
2. [Environment Configuration](#environment-configuration)
3. [Application Configuration](#application-configuration)
4. [Project Configuration](#project-configuration)
5. [Dependency Configuration](#dependency-configuration)
6. [API Specification](#api-specification)
7. [Generation Options](#generation-options)
8. [Template Configuration](#template-configuration)
9. [Service Configuration](#service-configuration)
10. [Advanced Configuration](#advanced-configuration)

## Overview

This guide covers all configuration options available in the Spring Boot API Generator, from environment variables to project generation settings.

## Environment Configuration

### Environment Variables

Environment variables can be set in a `.env` file or exported in your shell.

```bash
# Create .env file from template
cp .env.example .env
```

### Flask Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `FLASK_ENV` | string | `production` | Flask environment (development/production) |
| `FLASK_DEBUG` | boolean | `False` | Enable Flask debug mode |
| `FLASK_APP` | string | `app.py` | Flask application entry point |
| `FLASK_PORT` | integer | `5000` | Port for Flask server |
| `SECRET_KEY` | string | (generated) | Secret key for session encryption |

**Example:**
```env
FLASK_ENV=development
FLASK_DEBUG=True
FLASK_PORT=5000
SECRET_KEY=your-secret-key-here
```

### Application Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `GENERATED_PROJECTS_DIR` | string | `generated_projects` | Directory for generated projects |
| `MAX_FILE_SIZE_MB` | integer | `10` | Maximum upload file size in MB |
| `CACHE_TIMEOUT` | integer | `900` | Cache timeout in seconds |
| `ALLOWED_EXTENSIONS` | string | `json,yaml,yml` | Allowed file extensions |
| `MAX_ENDPOINTS_PER_PROJECT` | integer | `100` | Maximum endpoints per project |

**Example:**
```env
GENERATED_PROJECTS_DIR=/var/lib/api-generator/projects
MAX_FILE_SIZE_MB=20
CACHE_TIMEOUT=1800
```

### Spring Initializr Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `INITIALIZR_BASE_URL` | string | `https://start.spring.io` | Spring Initializr URL |
| `INITIALIZR_TIMEOUT` | integer | `30` | Request timeout in seconds |
| `RETRY_COUNT` | integer | `3` | Number of retry attempts |
| `RETRY_DELAY_BASE` | integer | `1` | Base delay for exponential backoff |
| `CACHE_DURATION` | integer | `900` | Metadata cache duration |

**Example:**
```env
INITIALIZR_BASE_URL=https://start.spring.io
INITIALIZR_TIMEOUT=60
RETRY_COUNT=5
```

### Logging Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `LOG_LEVEL` | string | `INFO` | Logging level (DEBUG/INFO/WARNING/ERROR) |
| `LOG_FILE` | string | `app.log` | Log file path |
| `LOG_FORMAT` | string | (default) | Log message format |
| `LOG_MAX_BYTES` | integer | `10485760` | Maximum log file size |
| `LOG_BACKUP_COUNT` | integer | `10` | Number of backup log files |

**Example:**
```env
LOG_LEVEL=DEBUG
LOG_FILE=/var/log/api-generator/app.log
LOG_MAX_BYTES=52428800
```

## Application Configuration

### Server Configuration

Configure the Flask server and deployment settings.

```python
# config.py
class Config:
    # Basic Configuration
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-key'

    # Session Configuration
    SESSION_TYPE = 'filesystem'
    SESSION_PERMANENT = False
    PERMANENT_SESSION_LIFETIME = 3600

    # File Upload
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10MB
    UPLOAD_FOLDER = 'uploads'

    # CORS Configuration
    CORS_ORIGINS = ['http://localhost:3000']

    # Rate Limiting
    RATELIMIT_STORAGE_URL = 'redis://localhost:6379'
    RATELIMIT_DEFAULT = '100/hour'

class DevelopmentConfig(Config):
    DEBUG = True
    TESTING = False

class ProductionConfig(Config):
    DEBUG = False
    TESTING = False
```

### Database Configuration (Optional)

If using a database for caching or persistence:

```python
# Database URLs
SQLALCHEMY_DATABASE_URI = 'postgresql://user:pass@localhost/dbname'
SQLALCHEMY_TRACK_MODIFICATIONS = False

# Redis Configuration
REDIS_URL = 'redis://localhost:6379/0'
CACHE_TYPE = 'redis'
CACHE_REDIS_URL = REDIS_URL
```

## Project Configuration

### Project Configuration Schema

Configuration for the Spring Boot project to be generated.

```json
{
  "projectConfiguration": {
    "projectName": "string",
    "description": "string",
    "groupId": "string",
    "artifactId": "string",
    "packageName": "string",
    "springBootVersion": "string",
    "javaVersion": "string",
    "buildTool": "string",
    "packaging": "string"
  }
}
```

### Field Descriptions

| Field | Type | Required | Constraints | Example |
|-------|------|----------|-------------|---------|
| `projectName` | string | Yes | 1-100 chars | "User Management API" |
| `description` | string | No | 0-500 chars | "REST API for user management" |
| `groupId` | string | Yes | Reverse domain | "com.example" |
| `artifactId` | string | Yes | Lowercase, hyphens | "user-api" |
| `packageName` | string | Yes | Java package | "com.example.userapi" |
| `springBootVersion` | string | Yes | Valid version | "3.2.0" |
| `javaVersion` | string | Yes | 8, 11, 17, 21 | "17" |
| `buildTool` | string | Yes | gradle, gradle-kotlin | "gradle" |
| `packaging` | string | Yes | jar, war | "jar" |

### Validation Rules

```python
# Project Name
- Pattern: ^[a-zA-Z0-9\s\-_]+$
- Min length: 1
- Max length: 100

# Group ID
- Pattern: ^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$
- Example: com.example, org.springframework

# Artifact ID
- Pattern: ^[a-z][a-z0-9-]*$
- Example: my-api, user-service

# Package Name
- Pattern: ^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$
- Must be valid Java package name
```

### Spring Boot Versions

Supported versions:
- 3.2.0 (latest)
- 3.1.5
- 3.0.11
- 2.7.16 (legacy)

### Java Versions

| Version | Spring Boot Compatibility |
|---------|--------------------------|
| Java 8 | Spring Boot 2.x only |
| Java 11 | Spring Boot 2.x, 3.x |
| Java 17 | Spring Boot 2.6+, 3.x (recommended) |
| Java 21 | Spring Boot 3.1+ |

## Dependency Configuration

### Dependency Categories

```json
{
  "dependencyConfiguration": {
    "database": "string",
    "security": boolean,
    "documentation": boolean,
    "caching": boolean,
    "messaging": boolean,
    "monitoring": boolean,
    "testing": boolean
  }
}
```

### Database Options

| Database | Dependency ID | Description |
|----------|--------------|-------------|
| `h2` | spring-boot-starter-data-jpa, h2 | In-memory database |
| `postgresql` | spring-boot-starter-data-jpa, postgresql | PostgreSQL driver |
| `mysql` | spring-boot-starter-data-jpa, mysql | MySQL driver |
| `mongodb` | spring-boot-starter-data-mongodb | MongoDB support |
| `none` | - | No database |

### Security Options

When `security: true`:
- Adds `spring-boot-starter-security`
- Adds JWT dependencies
- Generates security configuration
- Creates authentication endpoints

### Additional Dependencies

```python
DEPENDENCY_MAPPING = {
    'web': 'spring-boot-starter-web',
    'webflux': 'spring-boot-starter-webflux',
    'data-jpa': 'spring-boot-starter-data-jpa',
    'data-mongodb': 'spring-boot-starter-data-mongodb',
    'security': 'spring-boot-starter-security',
    'oauth2': 'spring-boot-starter-oauth2-client',
    'actuator': 'spring-boot-starter-actuator',
    'cache': 'spring-boot-starter-cache',
    'validation': 'spring-boot-starter-validation',
    'mail': 'spring-boot-starter-mail',
    'thymeleaf': 'spring-boot-starter-thymeleaf',
    'websocket': 'spring-boot-starter-websocket',
    'amqp': 'spring-boot-starter-amqp',
    'kafka': 'spring-kafka'
}
```

## API Specification

### Endpoint Configuration

```json
{
  "apiSpecification": {
    "baseControllerPath": "/api/v1",
    "controllerClassName": "User",
    "description": "User management API",
    "endpoints": [
      {
        "id": "1",
        "name": "getAllUsers",
        "httpMethod": "GET",
        "path": "/users",
        "description": "Get all users",
        "operationId": "getAllUsers",
        "requestParameters": [],
        "requestBody": null,
        "response": {
          "type": "LIST",
          "httpStatus": "200",
          "dataType": "UserResponse"
        }
      }
    ]
  }
}
```

### Endpoint Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | Yes | Unique endpoint identifier |
| `name` | string | Yes | Method name in controller |
| `httpMethod` | string | Yes | HTTP method (GET/POST/PUT/DELETE/PATCH) |
| `path` | string | Yes | URL path pattern |
| `description` | string | No | Endpoint description |
| `operationId` | string | No | OpenAPI operation ID |

### Request Parameters

```json
{
  "requestParameters": [
    {
      "name": "id",
      "type": "Long",
      "parameterLocation": "PATH",
      "required": true,
      "defaultValue": null,
      "description": "User ID",
      "validation": {
        "min": 1
      }
    }
  ]
}
```

#### Parameter Locations

| Location | Description | Example |
|----------|-------------|---------|
| `PATH` | URL path parameter | `/users/{id}` |
| `QUERY` | Query string parameter | `/users?page=1` |
| `HEADER` | HTTP header | `X-API-Key: value` |

#### Parameter Types

Supported Java types:
- `String`
- `Integer` / `int`
- `Long` / `long`
- `Boolean` / `boolean`
- `Double` / `double`
- `Float` / `float`
- `LocalDate`
- `LocalDateTime`
- `UUID`

### Request Body

```json
{
  "requestBody": {
    "required": true,
    "type": "CreateUserRequest",
    "fields": [
      {
        "name": "username",
        "type": "String",
        "required": true,
        "description": "Username",
        "validation": {
          "notBlank": true,
          "size": {
            "min": 3,
            "max": 20
          },
          "pattern": "^[a-zA-Z0-9_]+$"
        }
      }
    ]
  }
}
```

### Validation Configuration

```json
{
  "validation": {
    "notNull": true,
    "notBlank": true,
    "notEmpty": true,
    "size": {
      "min": 1,
      "max": 100
    },
    "pattern": "regex-pattern",
    "email": true,
    "min": 0,
    "max": 100,
    "positive": true,
    "negative": false,
    "future": true,
    "past": false
  }
}
```

#### Validation Annotations Mapping

| Configuration | Generated Annotation |
|--------------|---------------------|
| `notNull: true` | `@NotNull` |
| `notBlank: true` | `@NotBlank` |
| `size: {min: 3, max: 20}` | `@Size(min = 3, max = 20)` |
| `pattern: "^[A-Z]"` | `@Pattern(regexp = "^[A-Z]")` |
| `email: true` | `@Email` |
| `min: 1` | `@Min(1)` |
| `max: 100` | `@Max(100)` |

### Response Configuration

```json
{
  "response": {
    "type": "SINGLE_OBJECT",
    "httpStatus": "200",
    "dataType": "UserResponse",
    "wrapInResponseEntity": true,
    "fields": [
      {
        "name": "id",
        "type": "Long",
        "description": "User ID"
      }
    ]
  }
}
```

#### Response Types

| Type | Description | Generated Code |
|------|-------------|----------------|
| `SINGLE_OBJECT` | Single entity | `ResponseEntity<UserResponse>` |
| `LIST` | List of entities | `ResponseEntity<List<UserResponse>>` |
| `VOID` | No content | `ResponseEntity<Void>` |
| `CUSTOM` | Custom response | `ResponseEntity<?>` |

## Generation Options

### Available Options

```json
{
  "generationOptions": {
    "includeServiceLayer": true,
    "includeExceptionHandling": true,
    "includeValidation": true,
    "includeLogging": true,
    "generateTests": true,
    "generateCustomExceptions": true,
    "generateRepository": true,
    "generateSwaggerDocs": true,
    "enhanceWithLLM": false
  }
}
```

### Option Descriptions

| Option | Default | Description |
|--------|---------|-------------|
| `includeServiceLayer` | true | Generate service interfaces and implementations |
| `includeExceptionHandling` | true | Generate global exception handler |
| `includeValidation` | true | Add Bean Validation annotations |
| `includeLogging` | true | Add SLF4J logging |
| `generateTests` | true | Generate JUnit 5 tests |
| `generateCustomExceptions` | true | Create custom exception classes |
| `generateRepository` | true | Generate JPA repository interfaces |
| `generateSwaggerDocs` | true | Add Swagger/OpenAPI annotations |
| `enhanceWithLLM` | false | Use AI for code enhancement |

### Impact on Generated Code

#### With Service Layer

```java
// Controller
@RestController
public class UserController {
    private final UserService userService;

    @GetMapping("/users")
    public List<User> getUsers() {
        return userService.findAll();
    }
}

// Service Interface
public interface UserService {
    List<User> findAll();
}

// Service Implementation
@Service
public class UserServiceImpl implements UserService {
    public List<User> findAll() {
        // Implementation
    }
}
```

#### Without Service Layer

```java
// Controller only
@RestController
public class UserController {
    @GetMapping("/users")
    public List<User> getUsers() {
        // Direct implementation
        return new ArrayList<>();
    }
}
```

## Template Configuration

### Template Variables

Templates have access to these variables:

```python
TEMPLATE_CONTEXT = {
    'package_name': 'com.example.api',
    'class_name': 'User',
    'base_path': '/api/v1',
    'endpoints': [...],
    'imports': [...],
    'timestamp': datetime.now(),
    'generator_version': '2.0.0'
}
```

### Custom Templates

Add custom templates to `templates/java/custom/`:

```jinja2
{# custom_service.java.j2 #}
package {{ package_name }}.service.custom;

import org.springframework.stereotype.Service;

@Service
public class {{ class_name }}CustomService {
    // Custom implementation
}
```

Register in `code_generator_service.py`:

```python
def _generate_custom(self, context):
    template = self.env.get_template('custom/custom_service.java.j2')
    return template.render(context)
```

### Template Filters

Available Jinja2 filters:

```python
# String transformations
{{ "hello_world" | camelcase }}  # helloWorld
{{ "hello_world" | pascalcase }} # HelloWorld
{{ "HelloWorld" | snakecase }}   # hello_world
{{ "hello_world" | kebabcase }}  # hello-world
{{ "user" | pluralize }}          # users

# Type conversions
{{ "String" | to_java_type }}
{{ "email" | to_validation_annotation }}
```

## Service Configuration

### InitializrService

```python
# services/initializr_service.py
class InitializrService:
    # Configuration
    BASE_URL = os.getenv('INITIALIZR_URL', 'https://start.spring.io')
    TIMEOUT = int(os.getenv('INITIALIZR_TIMEOUT', '30'))
    RETRY_COUNT = int(os.getenv('RETRY_COUNT', '3'))
    RETRY_DELAY_BASE = int(os.getenv('RETRY_DELAY', '1'))
    CACHE_DURATION = int(os.getenv('CACHE_DURATION', '900'))
```

### ValidationService

```python
# Validation layers configuration
VALIDATION_CONFIG = {
    'strict_mode': False,
    'allow_empty_strings': False,
    'max_field_length': 1000,
    'max_array_size': 100,
    'allowed_http_methods': ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    'allowed_param_locations': ['PATH', 'QUERY', 'HEADER'],
    'allowed_response_types': ['SINGLE_OBJECT', 'LIST', 'VOID', 'CUSTOM']
}
```

### Parser Configuration

```python
# OpenAPI Parser
OPENAPI_CONFIG = {
    'supported_versions': ['3.0', '3.1'],
    'resolve_references': True,
    'strict_validation': False,
    'default_response_code': '200'
}

# Postman Parser
POSTMAN_CONFIG = {
    'supported_versions': ['2.1', '2.0'],
    'resolve_variables': True,
    'flatten_folders': False,
    'extract_auth': True
}
```

## Advanced Configuration

### Custom Validators

Add custom validation rules:

```python
# validators/custom.py
from services.validation_service import Validator

class CustomValidator(Validator):
    def validate_custom_rule(self, value, rule):
        # Custom validation logic
        if not self.check_condition(value, rule):
            raise ValidationError(f"Custom validation failed: {rule}")
```

### Plugin System

Create plugins for extended functionality:

```python
# plugins/custom_generator.py
class CustomGeneratorPlugin:
    def before_generation(self, config):
        """Called before code generation"""
        pass

    def after_generation(self, files):
        """Called after code generation"""
        pass

    def modify_template_context(self, context):
        """Modify template context"""
        context['custom_data'] = self.get_custom_data()
        return context
```

### Hook Configuration

```python
# hooks.py
HOOKS = {
    'before_validation': [],
    'after_validation': ['log_validation'],
    'before_generation': ['check_limits'],
    'after_generation': ['cleanup_temp_files'],
    'before_download': ['scan_for_issues'],
    'after_download': ['log_download']
}

def register_hook(event, callback):
    HOOKS[event].append(callback)
```

### Performance Tuning

```python
# Performance configuration
PERFORMANCE_CONFIG = {
    'enable_caching': True,
    'cache_ttl': 900,
    'max_workers': 4,
    'request_timeout': 120,
    'generation_timeout': 300,
    'zip_compression_level': 6,
    'chunk_size': 8192,
    'max_concurrent_generations': 5
}
```

### Security Configuration

```python
# Security settings
SECURITY_CONFIG = {
    'enable_csrf': True,
    'enable_cors': True,
    'cors_origins': ['http://localhost:3000'],
    'max_request_size': 10 * 1024 * 1024,  # 10MB
    'allowed_file_extensions': ['json', 'yaml', 'yml'],
    'sanitize_input': True,
    'validate_schemas': True,
    'rate_limit': '100/hour',
    'require_auth': False  # Set to True for production
}
```

### Feature Flags

```python
# Feature toggles
FEATURES = {
    'file_upload': True,
    'openapi_import': True,
    'postman_import': True,
    'custom_templates': False,
    'ai_enhancement': False,
    'async_generation': False,
    'webhooks': False,
    'batch_generation': False
}

def is_feature_enabled(feature):
    return FEATURES.get(feature, False)
```

---

**Last Updated:** January 2024 | **Version:** 2.0.0