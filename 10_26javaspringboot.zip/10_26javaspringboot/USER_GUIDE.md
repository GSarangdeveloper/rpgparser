# Spring Boot API Generator - Complete User Guide

## Table of Contents
1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Input Methods](#input-methods)
4. [Configuration Options](#configuration-options)
5. [API Specification](#api-specification)
6. [Generation Options](#generation-options)
7. [Generated Code Structure](#generated-code-structure)
8. [Advanced Features](#advanced-features)
9. [Best Practices](#best-practices)
10. [Troubleshooting](#troubleshooting)
11. [API Reference](#api-reference)

## Introduction

The Spring Boot API Generator is a powerful tool that automatically creates production-ready Spring Boot applications based on API specifications. It supports multiple input formats including OpenAPI, Swagger, Postman Collections, and custom JSON formats.

### Key Features
- **Multiple Input Methods**: File upload, manual configuration, paste content, URL import
- **Format Support**: OpenAPI 3.0, Swagger 2.0, Postman Collections, Custom JSON
- **Complete Code Generation**: Controllers, Services, DTOs, Repositories, Tests
- **Validation**: Comprehensive input validation with detailed error messages
- **Real-time Progress**: Server-sent events for progress tracking
- **Customization**: Extensive configuration options for generated code

## Getting Started

### Prerequisites
- Python 3.8+ installed
- Internet connection for Spring Initializr access
- Modern web browser (Chrome, Firefox, Safari, Edge)

### Installation

1. **Clone the repository**:
```bash
git clone <repository-url>
cd spring-boot-api-generator
```

2. **Install dependencies**:
```bash
pip install -r requirements.txt
```

3. **Start the application**:
```bash
python app.py
```

4. **Access the application**:
- Default UI: http://localhost:5000
- V2 UI (with file upload): http://localhost:5000/v2
- Simple UI: http://localhost:5000/simple

### Quick Start

1. Navigate to http://localhost:5000/v2
2. Choose an input method (Upload, Manual, Paste, or URL)
3. Provide your API specification
4. Configure project settings
5. Click "Generate"
6. Download the generated Spring Boot project

## Input Methods

### 1. File Upload
Upload API specification files directly through the web interface.

**Supported formats**:
- OpenAPI 3.0 (.yaml, .yml, .json)
- Swagger 2.0 (.yaml, .yml, .json)
- Postman Collection (.json)
- Custom JSON format (.json)

**How to use**:
1. Select "Upload File" input method
2. Drag and drop or browse for your file
3. File will be automatically parsed and validated
4. Review the configuration and generate

### 2. Manual Configuration
Build your API specification using the visual form builder.

**Features**:
- Add endpoints with full parameter support
- Configure request/response DTOs
- Set up validation rules
- Define error responses

**How to use**:
1. Select "Manual Configuration"
2. Fill in project details
3. Add endpoints using the "Add Endpoint" button
4. Configure each endpoint's parameters and responses
5. Generate the project

### 3. Paste Content
Paste API specification content directly into a text editor.

**Supported formats**:
- OpenAPI/Swagger YAML
- OpenAPI/Swagger JSON
- Custom JSON format

**How to use**:
1. Select "Paste Content"
2. Choose the format
3. Paste your specification
4. Click "Parse" to validate
5. Generate the project

### 4. URL Import (Coming Soon)
Import specifications directly from URLs.

## Configuration Options

### Project Configuration

| Field | Description | Required | Example |
|-------|-------------|----------|---------|
| projectName | Name of your project | Yes | "User Management API" |
| description | Project description | No | "RESTful API for user management" |
| groupId | Maven/Gradle group ID | Yes | "com.example" |
| artifactId | Maven/Gradle artifact ID | Yes | "user-api" |
| packageName | Base package name | Yes | "com.example.userapi" |
| springBootVersion | Spring Boot version | Yes | "3.2.0" |
| javaVersion | Java version | Yes | "17" |
| buildTool | Build tool | Yes | "gradle" |
| packaging | Package type | Yes | "jar" |

### Dependency Configuration

| Option | Description | Default |
|--------|-------------|---------|
| database | Database type (h2, postgresql, mysql, mongodb) | h2 |
| security | Include Spring Security | false |
| documentation | Include Swagger/OpenAPI docs | true |
| caching | Include Spring Cache | false |
| messaging | Include messaging (RabbitMQ/Kafka) | false |

## API Specification

### Endpoint Configuration

Each endpoint can be configured with:

#### Basic Properties
- **name**: Method name in controller
- **httpMethod**: GET, POST, PUT, DELETE, PATCH
- **path**: URL path (e.g., "/users/{id}")
- **description**: Endpoint description
- **operationId**: Unique operation identifier

#### Request Parameters

Parameters can be located in:
- **PATH**: URL path parameters (e.g., {id})
- **QUERY**: Query string parameters
- **HEADER**: HTTP headers

Each parameter supports:
- Type (String, Integer, Long, Boolean, etc.)
- Required flag
- Default value
- Description
- Validation rules

#### Request Body

Configure request body with:
- Field definitions
- Required fields
- Validation rules (size, pattern, email, etc.)
- Nested objects

#### Response Configuration

Define response with:
- Response type (SINGLE_OBJECT, LIST, VOID)
- HTTP status code
- Response DTO fields
- Error responses

### Validation Rules

Supported validation annotations:

| Validation | Description | Example |
|------------|-------------|---------|
| notNull | Field cannot be null | `@NotNull` |
| notBlank | String cannot be blank | `@NotBlank` |
| size | String/Collection size | `@Size(min=3, max=50)` |
| pattern | Regex pattern | `@Pattern(regexp="^[A-Z]")` |
| email | Valid email format | `@Email` |
| min/max | Numeric constraints | `@Min(0) @Max(100)` |

## Generation Options

| Option | Description | Default |
|--------|-------------|---------|
| includeServiceLayer | Generate service layer | true |
| includeExceptionHandling | Global exception handler | true |
| includeValidation | Bean validation | true |
| includeLogging | Logging configuration | true |
| generateTests | Generate unit tests | true |
| generateCustomExceptions | Custom exception classes | true |
| generateRepository | JPA repositories | true |
| generateSwaggerDocs | API documentation | true |

## Generated Code Structure

```
generated-project/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/example/api/
│   │   │       ├── controller/
│   │   │       │   ├── UserController.java
│   │   │       │   └── advice/
│   │   │       │       └── GlobalExceptionHandler.java
│   │   │       ├── service/
│   │   │       │   ├── UserService.java
│   │   │       │   └── impl/
│   │   │       │       └── UserServiceImpl.java
│   │   │       ├── dto/
│   │   │       │   ├── request/
│   │   │       │   │   └── CreateUserRequest.java
│   │   │       │   └── response/
│   │   │       │       └── UserResponse.java
│   │   │       ├── entity/
│   │   │       │   └── User.java
│   │   │       ├── repository/
│   │   │       │   └── UserRepository.java
│   │   │       ├── exception/
│   │   │       │   └── UserNotFoundException.java
│   │   │       └── Application.java
│   │   └── resources/
│   │       ├── application.properties
│   │       └── application.yml
│   └── test/
│       └── java/
│           └── com/example/api/
│               └── controller/
│                   └── UserControllerTest.java
├── build.gradle
└── README.md
```

## Advanced Features

### 1. Custom Exceptions
The generator creates custom exception classes for each entity:
- `EntityNotFoundException`
- `EntityAlreadyExistsException`
- `InvalidEntityException`

### 2. Global Exception Handler
Centralized error handling with:
- Consistent error response format
- HTTP status code mapping
- Validation error details
- Request tracing

### 3. Service Layer Pattern
Clean separation of concerns:
- Controllers handle HTTP
- Services contain business logic
- Repositories handle data access

### 4. DTO Pattern
Data Transfer Objects for:
- Request validation
- Response transformation
- API versioning support

### 5. Comprehensive Testing
Generated tests include:
- Controller unit tests with MockMvc
- Service layer tests
- Integration tests
- Test data builders

### 6. API Documentation
Automatic Swagger/OpenAPI documentation:
- Interactive API explorer
- Request/response examples
- Model definitions
- Authentication details

## Best Practices

### 1. API Design
- Use RESTful conventions
- Version your APIs (/api/v1)
- Use proper HTTP methods
- Return appropriate status codes

### 2. Naming Conventions
- **Controllers**: PascalCase with "Controller" suffix
- **Services**: PascalCase with "Service" suffix
- **DTOs**: PascalCase with "Request/Response" suffix
- **Endpoints**: camelCase for operation names

### 3. Validation
- Always validate input
- Use appropriate validation constraints
- Provide meaningful error messages
- Validate at the edge (controllers)

### 4. Error Handling
- Use custom exceptions
- Provide detailed error responses
- Include error codes
- Log errors appropriately

### 5. Security
- Enable security for production
- Use JWT for stateless auth
- Validate all inputs
- Implement rate limiting

## Troubleshooting

### Common Issues

#### 1. Generation Fails
**Problem**: Project generation fails with error
**Solutions**:
- Check Internet connectivity
- Verify Spring Initializr is accessible
- Validate input specification
- Check error logs for details

#### 2. Invalid Specification
**Problem**: Specification parsing fails
**Solutions**:
- Validate JSON/YAML syntax
- Check required fields
- Verify format compatibility
- Use sample files as reference

#### 3. Missing Dependencies
**Problem**: Generated project won't compile
**Solutions**:
- Ensure correct Java version
- Run dependency download
- Check proxy settings
- Verify repository access

#### 4. File Upload Errors
**Problem**: File upload fails
**Solutions**:
- Check file size (< 10MB)
- Verify file extension
- Ensure valid content
- Try different browser

### Error Codes

| Code | Description | Solution |
|------|-------------|----------|
| E400 | Bad Request | Check input validation |
| E404 | Not Found | Verify resource exists |
| E500 | Server Error | Check logs, retry |
| E503 | Service Unavailable | Wait and retry |
| VALIDATION_ERROR | Input validation failed | Fix validation errors |
| PARSING_ERROR | Specification parsing failed | Check format |
| GENERATION_ERROR | Code generation failed | Verify configuration |
| INITIALIZR_ERROR | Spring Initializr error | Check connectivity |

## API Reference

### REST Endpoints

#### Generate Project
```
POST /api/v1/generate/project
Content-Type: application/json

{
  "projectConfiguration": {...},
  "apiSpecification": {...},
  "generationOptions": {...}
}

Response: 200 OK
{
  "success": true,
  "projectId": "uuid",
  "message": "Project generated successfully"
}
```

#### Preview Code
```
POST /api/v1/preview/code
Content-Type: application/json

{
  "projectConfiguration": {...},
  "apiSpecification": {...}
}

Response: 200 OK
{
  "success": true,
  "preview": {
    "controller": "...",
    "service": "..."
  }
}
```

#### Upload Specification
```
POST /api/v1/upload/specification
Content-Type: multipart/form-data

file: specification.yaml

Response: 200 OK
{
  "success": true,
  "data": {...},
  "message": "Successfully parsed X endpoints"
}
```

#### Download Project
```
GET /api/v1/download/{projectId}

Response: 200 OK
Content-Type: application/zip
```

#### Health Check
```
GET /api/v1/health

Response: 200 OK
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00Z",
  "services": {
    "initializr": "operational",
    "generator": "operational"
  }
}
```

### Progress Tracking (SSE)
```
GET /api/v1/progress/{projectId}
Accept: text/event-stream

data: {"stage": "initializing", "progress": 10, "message": "Starting generation"}
data: {"stage": "downloading", "progress": 30, "message": "Downloading from Spring Initializr"}
data: {"stage": "generating", "progress": 60, "message": "Generating code"}
data: {"stage": "packaging", "progress": 90, "message": "Creating zip file"}
data: {"complete": true, "progress": 100, "message": "Generation complete"}
```

## Support and Contributing

### Getting Help
- Check the documentation
- Review sample files
- Search existing issues
- Contact support

### Contributing
1. Fork the repository
2. Create feature branch
3. Make your changes
4. Add tests
5. Submit pull request

### Reporting Issues
When reporting issues, include:
- Error messages
- Steps to reproduce
- Input specification
- Browser and OS
- Screenshots if applicable

## License

This project is licensed under the MIT License. See LICENSE file for details.

## Changelog

### Version 2.0.0
- Added file upload support
- Postman collection parser
- Enhanced error handling
- Real-time progress tracking
- Comprehensive validation

### Version 1.0.0
- Initial release
- Basic API generation
- OpenAPI/Swagger support
- Manual configuration