#!/bin/bash

echo "🧪 Angular UI Testing Tool with Playwright MCP Server"
echo "======================================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Install requirements
echo "📥 Installing dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "⚙️ Creating .env file from template..."
    cp .env.example .env
    echo "📝 Please edit .env file with your configuration"
fi

# Create necessary directories
echo "📁 Creating required directories..."
mkdir -p reports/allure-results
mkdir -p reports/allure-report
mkdir -p scripts
mkdir -p tests
mkdir -p logs

# Check if MCP server is configured
echo ""
echo "🔌 MCP Server Configuration:"
echo "----------------------------"
echo "Make sure your Playwright MCP server is running at:"
echo "Host: ${MCP_SERVER_HOST:-localhost}"
echo "Port: ${MCP_SERVER_PORT:-3000}"
echo ""

# Run the application
echo "🚀 Starting Angular UI Testing Tool..."
echo "======================================="
echo ""
streamlit run app.py --server.port 8501 --server.address localhost