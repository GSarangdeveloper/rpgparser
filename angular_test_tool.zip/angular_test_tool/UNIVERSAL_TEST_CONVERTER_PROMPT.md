# 🌐 Universal Test Scenario Converter Prompt

**Purpose:** Convert ANY existing test scenarios to Angular UI Testing Tool format  
**Use with:** ChatGPT, Claude, Gemini, or any LLM  
**Output:** Ready-to-use CSV file for the Angular UI Testing Tool  

---

## 📋 **COPY THIS PROMPT TO YOUR LLM:**

```
# UNIVERSAL TEST SCENARIO CONVERTER
## Convert ANY test format to Angular UI Testing Tool CSV format

You are an expert test automation engineer. Your task is to convert ANY existing test scenarios (manual test cases, user stories, acceptance criteria, Gherkin scenarios, etc.) into the EXACT CSV format required by the Angular UI Testing Tool.

## TARGET APPLICATION:
- **Name:** [ENTER YOUR APPLICATION NAME]
- **URL:** [ENTER YOUR APPLICATION URL]
- **Tool:** Angular UI Testing Tool with Playwright automation

## REQUIRED OUTPUT FORMAT:
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
```

## CONVERSION INSTRUCTIONS:

### 1. ANALYZE INPUT SCENARIOS
Look for these patterns in ANY format:
- **Steps/Actions**: "Click", "Enter", "Navigate", "Verify", "Check", "Select"
- **Elements**: Buttons, inputs, links, forms, menus, dropdowns
- **Data**: Usernames, passwords, text inputs, selections, uploads
- **Expectations**: "Should see", "Verify", "Confirm", "Check", "Validate"

### 2. MAP TO AUTOMATION ACTIONS
| Manual Step | Automation Action | Example |
|-------------|------------------|---------|
| "Go to page" | `navigate` | navigate,,https://app.com |
| "Click button" | `click` | click,button.submit |
| "Enter text" | `fill` | fill,input[name="email"],test@example.com |
| "Select option" | `select` | select,select[name="country"],USA |
| "Verify visible" | `assert_visible` | assert_visible,.success-message |
| "Check text" | `assert_text` | assert_text,h1,Welcome |
| "Wait for element" | `wait` | wait,.loading-spinner |
| "Hover over" | `hover` | hover,.menu-item |

### 3. GENERATE REALISTIC SELECTORS
- **Inputs**: `input[name="username"]`, `input[type="email"]`, `#password`, `.search-box`
- **Buttons**: `button.submit`, `input[type="submit"]`, `.btn-primary`, `#login-btn`
- **Links**: `a[href="/login"]`, `nav a`, `.menu-item`, `text="Sign Up"`
- **Text Elements**: `.error-message`, `.success-alert`, `h1`, `.title`, `.notification`
- **Forms**: `form.login`, `.registration-form`, `#contact-form`
- **Dropdowns**: `select[name="category"]`, `.dropdown-menu`, `option[value="admin"]`

### 4. CREATE TEST SUITES
Group related tests:
- **Authentication**: Login, logout, registration, password reset, 2FA
- **Navigation**: Menu navigation, page routing, breadcrumbs, search
- **Forms**: Contact forms, registration, data entry, validation
- **E-commerce**: Cart, checkout, payments, orders, wishlist
- **User Management**: Profile, settings, preferences, permissions
- **Content**: CRUD operations, file uploads, comments, reviews
- **API Integration**: Data loading, synchronization, external services

### 5. ASSIGN PRIORITIES
- **high**: Critical user flows (login, checkout, core business features)
- **medium**: Important features (search, navigation, forms, reports)
- **low**: Nice-to-have features (tooltips, animations, help, preferences)

## EXAMPLE CONVERSIONS:

### INPUT: Manual Test Case
```
Test: User Registration
1. Navigate to registration page
2. Fill in first name "John"
3. Fill in last name "Doe"
4. Enter email "john.doe@example.com"
5. Enter password "SecurePass123"
6. Confirm password "SecurePass123"
7. Select country "United States"
8. Check terms and conditions
9. Click Register button
10. Verify success message appears
```

### OUTPUT: CSV Format
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
TC001,User Registration Test,Authentication,Test new user registration flow,high,navigate,,https://app.com/register,Registration page loads,
TC001,,,,,fill,input[name="firstName"],John,First name entered,
TC001,,,,,fill,input[name="lastName"],Doe,Last name entered,
TC001,,,,,fill,input[type="email"],john.doe@example.com,Email entered,
TC001,,,,,fill,input[name="password"],SecurePass123,Password entered,
TC001,,,,,fill,input[name="confirmPassword"],SecurePass123,Password confirmed,
TC001,,,,,select,select[name="country"],United States,Country selected,
TC001,,,,,click,input[type="checkbox"],,Terms accepted,
TC001,,,,,click,button.register,,Register button clicked,
TC001,,,,,assert_visible,.success-message,,Success message displayed,
```

### INPUT: User Story (Agile)
```
As a customer, I want to search for products by category so that I can find relevant items quickly.

Acceptance Criteria:
- User can select a category from dropdown
- Search results show products in selected category
- User can filter results by price range
- Results show product name, price, and image
```

### OUTPUT: CSV Format
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
TC002,Category Search Test,Search,Test product search by category,high,navigate,,https://app.com,Homepage loads,
TC002,,,,,click,.category-dropdown,,Category dropdown opened,
TC002,,,,,select,select[name="category"],Electronics,Electronics category selected,
TC002,,,,,click,button.search,,Search button clicked,
TC002,,,,,assert_visible,.search-results,,Search results displayed,
TC002,,,,,assert_text,.category-filter,Electronics,Category filter applied,
TC002,,,,,assert_visible,.product-card,,Product cards visible,
TC002,,,,,assert_visible,.product-name,,Product names shown,
TC002,,,,,assert_visible,.product-price,,Product prices shown,
TC002,,,,,assert_visible,.product-image,,Product images shown,
```

### INPUT: Gherkin/BDD Scenario
```
Feature: Shopping Cart
Scenario: Add item to cart
  Given I am on the product page
  When I click "Add to Cart" button
  And I view my cart
  Then I should see the item in my cart
  And the cart count should be updated
```

### OUTPUT: CSV Format
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
TC003,Add to Cart Test,E-commerce,Test adding product to shopping cart,high,navigate,,https://app.com/product/123,Product page loads,
TC003,,,,,click,button.add-to-cart,,Add to cart clicked,
TC003,,,,,assert_visible,.cart-notification,,Cart notification shown,
TC003,,,,,click,.cart-icon,,Cart opened,
TC003,,,,,assert_visible,.cart-item,,Item visible in cart,
TC003,,,,,assert_text,.cart-count,1,Cart count updated,
```

## YOUR TASK:
Convert the following test scenarios to the required CSV format:

[PASTE YOUR TEST SCENARIOS HERE - ANY FORMAT]

## OUTPUT REQUIREMENTS:
1. **Start with exact CSV header row**
2. **Generate complete test cases** (3-10 steps each)
3. **Use realistic selectors** for the application type
4. **Include proper test data** (realistic usernames, emails, etc.)
5. **Cover positive and negative scenarios**
6. **Ensure proper CSV formatting** (no extra quotes, proper escaping)
7. **Group related tests** in appropriate test suites
8. **Assign realistic priorities** based on business importance

Generate the complete CSV output now:
```

---

## 🚀 **HOW TO USE:**

### **Step 1: Customize the Prompt**
- Replace `[ENTER YOUR APPLICATION NAME]` with your app name
- Replace `[ENTER YOUR APPLICATION URL]` with your app URL

### **Step 2: Add Your Test Scenarios**
- Replace `[PASTE YOUR TEST SCENARIOS HERE - ANY FORMAT]` with your existing test cases
- Can be: Manual test cases, User stories, Gherkin scenarios, Acceptance criteria, etc.

### **Step 3: Use with Any LLM**
- Copy the entire prompt to ChatGPT, Claude, Gemini, etc.
- Get CSV output ready for Angular UI Testing Tool

### **Step 4: Validate & Use**
- Save LLM output as `.csv` file
- Validate with: `python llm_scenario_helper.py`
- Upload to Angular UI Testing Tool

---

## 📋 **SUPPORTED INPUT FORMATS:**

- ✅ **Manual Test Cases** (step-by-step instructions)
- ✅ **User Stories** (As a... I want... So that...)
- ✅ **Acceptance Criteria** (Given/When/Then)
- ✅ **Gherkin/BDD Scenarios** (Feature/Scenario/Steps)
- ✅ **Test Plans** (structured test documentation)
- ✅ **Requirements** (functional specifications)
- ✅ **Bug Reports** (reproduction steps)
- ✅ **Use Cases** (actor-goal-scenario format)

---

## 🎯 **EXAMPLE APPLICATIONS:**

- **E-commerce**: Product search, cart, checkout, user accounts
- **Banking**: Login, transfers, account management, transactions
- **Social Media**: Posts, comments, messaging, profiles
- **CRM**: Lead management, contact forms, reporting
- **Healthcare**: Patient records, appointments, prescriptions
- **Education**: Course enrollment, assignments, grading

**This universal prompt can convert ANY test scenario format to work with the Angular UI Testing Tool! 🌐**
