#!/bin/bash

echo "========================================"
echo "Angular UI Testing Tool - Installation"
echo "========================================"
echo

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python
echo "[1/7] Checking Python installation..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python3 not found! Please install Python 3.8+${NC}"
    exit 1
fi
python3 --version
echo -e "${GREEN}✅ Python found${NC}"

# Check Node.js
echo
echo "[2/7] Checking Node.js installation..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js not found! Please install Node.js 16+${NC}"
    exit 1
fi
node --version
npm --version
echo -e "${GREEN}✅ Node.js found${NC}"

# Create Python virtual environment
echo
echo "[3/7] Creating Python virtual environment..."
if [ -d "venv" ]; then
    echo -e "${YELLOW}⚠️ Virtual environment already exists, skipping...${NC}"
else
    python3 -m venv venv
    echo -e "${GREEN}✅ Virtual environment created${NC}"
fi

# Activate virtual environment and install Python dependencies
echo
echo "[4/7] Installing Python dependencies..."
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to install Python dependencies${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Python dependencies installed${NC}"

# Install Node.js dependencies
echo
echo "[5/7] Installing Node.js dependencies..."
echo -e "${YELLOW}ℹ️ This recreates the node_modules folder with all required packages${NC}"
npm install
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to install Node.js dependencies${NC}"
    echo -e "${YELLOW}    Try running: npm cache clean --force${NC}"
    echo -e "${YELLOW}    Then run this script again${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Node.js dependencies installed (node_modules recreated)${NC}"

# Install Playwright browsers
echo
echo "[6/7] Installing Playwright browsers..."
npx playwright install chromium
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to install Playwright browsers${NC}"
    exit 1
fi

# Install system dependencies for Playwright (Linux)
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "Installing Playwright system dependencies..."
    npx playwright install-deps
fi

echo -e "${GREEN}✅ Playwright browsers installed${NC}"

# Install MCP server globally
echo
echo "[7/7] Installing Playwright MCP server..."
npm install -g @playwright/mcp@latest
if [ $? -ne 0 ]; then
    echo -e "${YELLOW}⚠️ Failed to install MCP server globally (may need sudo)${NC}"
    echo "    You can install it later with: sudo npm install -g @playwright/mcp@latest"
else
    echo -e "${GREEN}✅ MCP server installed globally${NC}"
fi

# Verification
echo
echo "========================================"
echo "Installation Verification"
echo "========================================"
echo

echo "Testing Python dependencies..."
python3 -c "import streamlit, playwright; print('✅ Python dependencies OK')" 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Python dependencies verification failed${NC}"
else
    echo -e "${GREEN}✅ Python dependencies verified${NC}"
fi

echo
echo "Testing Node.js dependencies..."
npx playwright --version >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Playwright verification failed${NC}"
else
    echo -e "${GREEN}✅ Playwright verified${NC}"
fi

npx allure --version >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Allure CLI verification failed${NC}"
else
    echo -e "${GREEN}✅ Allure CLI verified${NC}"
fi

npx @playwright/mcp@latest --version >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo -e "${YELLOW}⚠️ MCP server verification failed (may need global install)${NC}"
else
    echo -e "${GREEN}✅ MCP server verified${NC}"
fi

echo
echo "========================================"
echo "Installation Complete!"
echo "========================================"
echo
echo "To start the application:"
echo "  1. source venv/bin/activate"
echo "  2. streamlit run app.py"
echo
echo "Or use the quick start:"
echo "  python start_streamlit.py"
echo

# Make the script executable
chmod +x install.sh
