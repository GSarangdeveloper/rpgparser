# Developer Setup Guide

## Required Dependencies

### Core Requirements
- **Python 3.8+** with pip
- **Node.js 16+** with npm
- **Git** for version control

### Installation Steps

#### 1. Python Environment
```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

#### 2. Node.js Dependencies
```bash
npm install
```

#### 3. Playwright Setup
```bash
# Install Playwright browsers
npx playwright install chromium
npx playwright install firefox  # Optional
npx playwright install webkit   # Optional

# Install system dependencies (Linux/Mac)
npx playwright install-deps
```

#### 4. MCP Server Installation
```bash
# Install Playwright MCP Server globally
npm install -g @playwright/mcp@latest

# Verify installation
npx @playwright/mcp@latest --version
```

#### 5. Allure CLI Setup
```bash
# Verify Allure CLI (included in package.json)
npx allure --version

# If not working, install globally
npm install -g allure-commandline
```

#### 6. Verification
```bash
# Test Python dependencies
python -c "import streamlit, playwright; print('Python deps OK')"

# Test Node dependencies
npx playwright --version
npx allure --version
npx @playwright/mcp@latest --version
```

## Quick Start
```bash
# Start the application
streamlit run app.py

# Or use the launcher
python start_streamlit.py
```

## Dependencies Breakdown

### Python (requirements.txt)
- **streamlit** - Web UI framework
- **playwright** - Browser automation
- **allure-pytest** - Test reporting
- **pandas** - Data processing
- **websockets** - MCP communication
- **gitpython** - Git integration

### Node.js (package.json)
- **@playwright/test** - Testing framework
- **@playwright/mcp** - MCP server
- **allure-playwright** - Allure integration
- **allure-commandline** - Allure CLI
- **typescript** - Script generation

## Troubleshooting

### Playwright Issues
```bash
# Reinstall browsers
npx playwright install --force

# Check browser installation
npx playwright install --dry-run
```

### MCP Server Issues
```bash
# Reinstall MCP server
npm uninstall -g @playwright/mcp
npm install -g @playwright/mcp@latest

# Test MCP server
npx @playwright/mcp@latest --help
```

### Allure Issues
```bash
# Reinstall Allure CLI
npm install -g allure-commandline

# Test Allure
npx allure --version
```

### Python Issues
```bash
# Upgrade pip
python -m pip install --upgrade pip

# Reinstall requirements
pip install --upgrade -r requirements.txt
```

## Environment Variables (Optional)
```bash
# Create .env file
PLAYWRIGHT_BROWSERS_PATH=/path/to/browsers
ALLURE_RESULTS_DIR=reports/allure-results
MCP_SERVER_PORT=3000
```

## Development Mode
```bash
# Install development dependencies
npm install --include=dev

# Run tests
npm test

# Generate reports
npm run allure:serve
```
