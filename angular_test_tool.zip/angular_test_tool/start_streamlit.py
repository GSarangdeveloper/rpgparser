#!/usr/bin/env python3
"""
Start Streamlit App for ParaBank Testing
"""

import subprocess
import sys
import time
import webbrowser
from pathlib import Path

def start_streamlit_app():
    """Start the Streamlit application"""
    
    print("🚀 Starting Angular UI Testing Tool")
    print("=" * 40)
    print("Target Application: ParaBank")
    print("URL: https://parabank.parasoft.com")
    print("Testing Method: MCP Server Integration")
    print()
    
    # Check if required files exist
    required_files = [
        "app.py",
        "parabank_tests_correct.csv",
        ".env"
    ]
    
    print("📋 Checking required files...")
    for file in required_files:
        if Path(file).exists():
            print(f"   ✅ {file}")
        else:
            print(f"   ❌ {file} - Missing!")
            return False
    
    print()
    print("🔧 Configuration Summary:")
    print("   📄 Test Cases: parabank_tests_correct.csv (10 scenarios)")
    print("   🎭 MCP Server: @playwright/mcp@latest")
    print("   🌐 Target URL: https://parabank.parasoft.com")
    print("   🖥️ Browser: Chromium")
    print("   📊 Reports: HTML, JSON, Screenshots")
    print()
    
    print("🚀 Starting Streamlit server...")
    print("   URL: http://localhost:8501")
    print("   Press Ctrl+C to stop")
    print()
    
    try:
        # Start Streamlit
        result = subprocess.run([
            sys.executable, "-m", "streamlit", "run", "app.py",
            "--server.port", "8501",
            "--server.address", "localhost"
        ], check=True)
        
    except KeyboardInterrupt:
        print("\n🛑 Streamlit server stopped by user")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to start Streamlit: {e}")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    """Main function"""
    print("🎭 Angular UI Testing Tool - Streamlit Launcher")
    print("=" * 55)
    
    success = start_streamlit_app()
    
    if success:
        print("\n✅ Application started successfully!")
    else:
        print("\n❌ Failed to start application")
        print("\n🔧 Troubleshooting:")
        print("   - Ensure virtual environment is activated")
        print("   - Check that all dependencies are installed")
        print("   - Verify port 8501 is available")
    
    return success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
