# 🤖 LLM Test Scenario Format Guide

**Question:** Do we need exact format for LLM-generated test scenarios?  
**Answer:** ✅ **YES** - Format is crucial for successful automation  
**Solution:** Use this guide to generate properly formatted scenarios  

---

## 🎯 **REQUIRED CSV FORMAT**

### ✅ **Required Columns:**
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
```

### 📋 **Column Descriptions:**

| Column | Required | Description | Example |
|--------|----------|-------------|---------|
| `test_id` | ✅ **YES** | Unique test identifier | `TC001` |
| `test_name` | ✅ **YES** | Test case name (only on first row) | `Login Test` |
| `test_suite` | ❌ No | Test category/group | `Authentication` |
| `description` | ❌ No | Test description (only on first row) | `Test user login` |
| `priority` | ❌ No | Test priority level | `high`, `medium`, `low` |
| `action` | ✅ **YES** | Action to perform | `navigate`, `click`, `fill` |
| `selector` | ✅ **YES** | Element selector | `input[name="username"]` |
| `input_data` | ❌ No | Data to input | `testuser` |
| `expected_result` | ❌ No | Expected outcome | `Login successful` |
| `wait_condition` | ❌ No | Wait condition | `element_visible` |

---

## 🔧 **SUPPORTED ACTIONS**

### **Navigation Actions:**
- `navigate` - Navigate to URL
- `wait` - Wait for condition
- `refresh` - Refresh page

### **Interaction Actions:**
- `click` - Click element
- `fill` - Fill input field
- `select` - Select dropdown option
- `hover` - Hover over element
- `scroll` - Scroll to element

### **Assertion Actions:**
- `assert_visible` - Check element is visible
- `assert_text` - Check element contains text
- `assert_url` - Check current URL
- `assert_title` - Check page title
- `assert_attribute` - Check element attribute

---

## 📝 **CORRECT FORMAT EXAMPLE**

```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
TC001,User Login Test,Authentication,Test user login functionality,high,navigate,,https://example.com,Page loads,
TC001,,,,,fill,input[name="username"],testuser,Username entered,
TC001,,,,,fill,input[name="password"],password123,Password entered,
TC001,,,,,click,button[type="submit"],,Login button clicked,
TC001,,,,,assert_visible,.welcome-message,,Welcome message appears,
TC002,Homepage Navigation,Navigation,Test homepage navigation,medium,navigate,,https://example.com,Page loads,
TC002,,,,,assert_visible,nav.main-menu,,Main menu visible,
TC002,,,,,click,a[href="/products"],,Products link clicked,
TC002,,,,,assert_url,,/products,Products page loaded,
```

---

## 🤖 **LLM PROMPT TEMPLATE**

Use this prompt template to generate properly formatted test scenarios:

```
Generate test scenarios in CSV format for [APPLICATION_NAME] with the following requirements:

FORMAT: CSV with these exact columns:
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition

RULES:
1. test_id: Use format TC001, TC002, etc.
2. test_name: Only on first row of each test
3. test_suite: Group related tests (Authentication, Navigation, etc.)
4. description: Only on first row of each test
5. priority: high, medium, or low
6. action: Use navigate, click, fill, assert_visible, assert_text, etc.
7. selector: CSS selectors for elements
8. input_data: Data to enter (for fill actions)
9. expected_result: What should happen
10. wait_condition: Optional wait conditions

ACTIONS TO USE:
- navigate: Go to URL
- fill: Enter text in input
- click: Click button/link
- assert_visible: Check element exists
- assert_text: Check text content
- assert_url: Check current URL

APPLICATION: [DESCRIBE YOUR APPLICATION]
SCENARIOS NEEDED: [LIST SCENARIOS TO TEST]

Generate 5-10 test scenarios covering the main functionality.
```

---

## ✅ **EXAMPLE LLM PROMPTS**

### **For E-commerce Site:**
```
Generate test scenarios for an e-commerce website in the required CSV format.
Test scenarios needed:
1. User registration
2. Product search
3. Add to cart
4. Checkout process
5. User profile update

Use selectors like: input[name="email"], button.add-to-cart, .product-title
```

### **For Banking App:**
```
Generate test scenarios for ParaBank banking application in CSV format.
Test scenarios needed:
1. Login/logout
2. Account overview
3. Transfer funds
4. Bill payment
5. Account services

Use ParaBank-specific selectors: input[name="username"], #leftPanel, .title
```

---

## 🔧 **FORMAT VALIDATION**

### ✅ **Valid Row Examples:**
```csv
# New test case (has test_name)
TC001,Login Test,Auth,Test login,high,navigate,,https://app.com,Page loads,

# Additional steps (no test_name)
TC001,,,,,fill,input[name="user"],admin,User entered,
TC001,,,,,click,button.login,,Login clicked,
```

### ❌ **Invalid Examples:**
```csv
# Missing required columns
test_id,action
TC001,navigate

# Wrong action names
TC001,Test,Auth,Test,high,goto,,,, # 'goto' should be 'navigate'

# Missing test_id
,Login Test,Auth,Test,high,navigate,,,
```

---

## 🚀 **AUTOMATED VALIDATION**

I can create a validator script for your LLM-generated scenarios:

```python
def validate_llm_scenarios(csv_file):
    """Validate LLM-generated test scenarios"""
    
    required_columns = ['test_id', 'test_name', 'action', 'selector']
    valid_actions = ['navigate', 'click', 'fill', 'assert_visible', 
                    'assert_text', 'assert_url', 'wait', 'hover']
    
    # Check format and provide feedback
    # Returns: validation_results, suggestions
```

---

## 📊 **BEST PRACTICES FOR LLM GENERATION**

### ✅ **Do:**
- **Use specific selectors** (CSS/XPath)
- **Include wait conditions** for dynamic content
- **Group related tests** in same test_suite
- **Use descriptive test names**
- **Include both positive and negative scenarios**

### ❌ **Don't:**
- **Use generic selectors** like `button` (too vague)
- **Skip required columns**
- **Mix different applications** in same file
- **Use invalid action names**
- **Forget to test error conditions**

---

## 🎯 **INTEGRATION WITH YOUR TOOL**

### **Current Workflow:**
1. **Generate scenarios** using LLM with proper format
2. **Save as CSV file** with required columns
3. **Upload to Streamlit app** (Step 2)
4. **Validate parsing** - check for errors
5. **Generate scripts** (Step 3)
6. **Execute tests** (Step 4)

### **Format Benefits:**
- ✅ **Automatic script generation** from scenarios
- ✅ **Playwright test creation** with proper structure
- ✅ **Allure reporting** with test metadata
- ✅ **Error handling** and validation

---

## 🔧 **TROUBLESHOOTING**

### **Common LLM Issues:**
1. **Wrong column names** → Use exact column names from template
2. **Invalid actions** → Use only supported actions list
3. **Missing test_id** → Every row needs test_id
4. **Inconsistent format** → Follow the exact CSV structure

### **Quick Fixes:**
- **Use the prompt template** provided above
- **Validate with test parser** before using
- **Check sample files** for reference
- **Test with small scenarios** first

---

## 🎉 **CONCLUSION**

**YES, exact format is required for LLM-generated scenarios!**

✅ **Use the CSV format** with required columns  
✅ **Follow the action naming** conventions  
✅ **Include proper selectors** for elements  
✅ **Validate before using** in the tool  

**With proper formatting, your LLM-generated scenarios will work seamlessly with the Angular UI Testing Tool!** 🎯
