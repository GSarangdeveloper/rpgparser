"""
Allure Reporter Module
Generates Allure reports from test execution results
"""

import json
import os
from typing import List, Dict, Any, Optional
from datetime import datetime
from pathlib import Path
import subprocess
import logging

logger = logging.getLogger(__name__)


class AllureReporter:
    """Generate and manage Allure reports"""
    
    def __init__(self, results_dir: str = "./reports/allure-results", 
                 report_dir: str = "./reports/allure-report"):
        self.results_dir = Path(results_dir)
        self.report_dir = Path(report_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        self.report_dir.mkdir(parents=True, exist_ok=True)
    
    def generate_test_result(self, test_case: Dict[str, Any], 
                           execution_result: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Allure test result format"""
        
        # Map status
        status_map = {
            "passed": "passed",
            "failed": "failed",
            "skipped": "skipped",
            "error": "broken"
        }
        
        allure_result = {
            "uuid": f"{test_case.get('test_id')}_{datetime.now().timestamp()}",
            "historyId": test_case.get('test_id'),
            "testCaseId": test_case.get('test_id'),
            "name": test_case.get('test_name'),
            "fullName": f"{test_case.get('test_suite', 'Default')}.{test_case.get('test_name')}",
            "status": status_map.get(execution_result.get('status', 'failed'), 'failed'),
            "statusDetails": {},
            "stage": "finished",
            "steps": [],
            "attachments": [],
            "parameters": [],
            "labels": [],
            "links": [],
            "start": execution_result.get('start_time', datetime.now().timestamp() * 1000),
            "stop": execution_result.get('end_time', datetime.now().timestamp() * 1000)
        }
        
        # Add labels
        allure_result['labels'].extend([
            {"name": "suite", "value": test_case.get('test_suite', 'Default')},
            {"name": "feature", "value": test_case.get('test_suite', 'Default')},
            {"name": "story", "value": test_case.get('test_name')},
            {"name": "severity", "value": test_case.get('priority', 'normal')},
            {"name": "framework", "value": "playwright"},
            {"name": "language", "value": "typescript"}
        ])
        
        # Add tags
        for tag in test_case.get('tags', []):
            allure_result['labels'].append({"name": "tag", "value": tag})
        
        # Add test data as parameters
        if test_case.get('test_data'):
            for key, value in test_case.get('test_data', {}).items():
                allure_result['parameters'].append({
                    "name": key,
                    "value": str(value)
                })
        
        # Add steps
        for i, step in enumerate(test_case.get('steps', [])):
            step_result = execution_result.get('steps', [])[i] if i < len(execution_result.get('steps', [])) else {}
            
            allure_step = {
                "name": step.get('description', f"Step {i+1}"),
                "status": step_result.get('status', 'passed'),
                "stage": "finished",
                "steps": [],
                "attachments": [],
                "parameters": [],
                "start": step_result.get('start_time', datetime.now().timestamp() * 1000),
                "stop": step_result.get('end_time', datetime.now().timestamp() * 1000)
            }
            
            # Add step parameters
            if step.get('selector'):
                allure_step['parameters'].append({
                    "name": "selector",
                    "value": step.get('selector')
                })
            if step.get('data'):
                allure_step['parameters'].append({
                    "name": "data",
                    "value": step.get('data')
                })
            
            # Add screenshot if available
            if step_result.get('screenshot'):
                allure_step['attachments'].append({
                    "name": "Screenshot",
                    "source": step_result.get('screenshot'),
                    "type": "image/png"
                })
            
            allure_result['steps'].append(allure_step)
        
        # Add error details if failed
        if execution_result.get('status') == 'failed':
            errors = execution_result.get('errors', [])
            if errors:
                allure_result['statusDetails'] = {
                    "message": errors[0].get('error', 'Test failed'),
                    "trace": "\n".join([e.get('error', '') for e in errors])
                }
        
        # Add attachments
        if execution_result.get('screenshots'):
            for screenshot in execution_result.get('screenshots', []):
                allure_result['attachments'].append({
                    "name": "Screenshot",
                    "source": screenshot,
                    "type": "image/png"
                })
        
        if execution_result.get('console_logs'):
            # Save console logs as attachment
            log_file = self.results_dir / f"console_{allure_result['uuid']}.txt"
            with open(log_file, 'w') as f:
                f.write('\n'.join(execution_result.get('console_logs', [])))
            
            allure_result['attachments'].append({
                "name": "Console Logs",
                "source": str(log_file),
                "type": "text/plain"
            })
        
        return allure_result
    
    def save_test_results(self, test_cases: List[Dict[str, Any]], 
                         execution_results: List[Dict[str, Any]]):
        """Save test results in Allure format"""
        
        # Map execution results by test_id
        results_map = {r.get('test_id'): r for r in execution_results}
        
        for test_case in test_cases:
            test_id = test_case.get('test_id')
            execution_result = results_map.get(test_id, {})
            
            if execution_result:
                allure_result = self.generate_test_result(test_case, execution_result)
                
                # Save result file
                result_file = self.results_dir / f"{allure_result['uuid']}-result.json"
                with open(result_file, 'w') as f:
                    json.dump(allure_result, f, indent=2)
                
                logger.info(f"Saved Allure result for test {test_id}")
    
    def generate_environment_properties(self, config: Dict[str, Any]):
        """Generate environment properties file"""
        env_file = self.results_dir / "environment.properties"
        
        with open(env_file, 'w') as f:
            f.write(f"Application={config.get('app_name', 'Angular App')}\n")
            f.write(f"URL={config.get('app_url', '')}\n")
            f.write(f"Environment={config.get('environment', 'Test')}\n")
            f.write(f"Browser={config.get('browser', 'chromium')}\n")
            f.write(f"Headless={config.get('headless', False)}\n")
            f.write(f"Timestamp={datetime.now().isoformat()}\n")
        
        logger.info("Generated environment properties")
    
    def generate_executor_info(self):
        """Generate executor information"""
        executor_info = {
            "name": "Angular UI Testing Tool",
            "type": "playwright",
            "url": "http://localhost:8501",
            "buildName": f"Build-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
            "buildUrl": "http://localhost:8501",
            "reportUrl": "http://localhost:8501/reports",
            "reportName": "Allure Report"
        }
        
        executor_file = self.results_dir / "executor.json"
        with open(executor_file, 'w') as f:
            json.dump(executor_info, f, indent=2)
        
        logger.info("Generated executor info")
    
    def generate_categories(self):
        """Generate test categories"""
        categories = [
            {
                "name": "Test Failures",
                "matchedStatuses": ["failed"],
                "messageRegex": ".*"
            },
            {
                "name": "Broken Tests",
                "matchedStatuses": ["broken"],
                "messageRegex": ".*"
            },
            {
                "name": "Skipped Tests",
                "matchedStatuses": ["skipped"],
                "messageRegex": ".*"
            },
            {
                "name": "Flaky Tests",
                "matchedStatuses": ["passed", "failed"],
                "flaky": True
            }
        ]
        
        categories_file = self.results_dir / "categories.json"
        with open(categories_file, 'w') as f:
            json.dump(categories, f, indent=2)
        
        logger.info("Generated categories")
    
    def generate_history_trend(self, previous_results: List[Dict[str, Any]] = None):
        """Generate history trend data"""
        if not previous_results:
            previous_results = []
        
        history_trend = []
        
        for i, results in enumerate(previous_results[-5:]):  # Last 5 runs
            build_data = {
                "buildOrder": i + 1,
                "reportUrl": f"#{i+1}",
                "reportName": f"Run {i+1}",
                "data": {
                    "passed": results.get('passed', 0),
                    "failed": results.get('failed', 0),
                    "skipped": results.get('skipped', 0),
                    "broken": results.get('broken', 0),
                    "unknown": results.get('unknown', 0)
                }
            }
            history_trend.append(build_data)
        
        trend_file = self.results_dir / "history-trend.json"
        with open(trend_file, 'w') as f:
            json.dump(history_trend, f, indent=2)
        
        logger.info("Generated history trend")
    
    def generate_html_report(self) -> bool:
        """Generate HTML report using Allure CLI"""
        try:
            # Check if Allure CLI is installed
            result = subprocess.run(['allure', '--version'], 
                                  capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error("Allure CLI not found. Please install it first.")
                return False
            
            # Generate report
            cmd = [
                'allure', 'generate',
                str(self.results_dir),
                '-o', str(self.report_dir),
                '--clean'
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info(f"HTML report generated at {self.report_dir}")
                return True
            else:
                logger.error(f"Failed to generate report: {result.stderr}")
                return False
                
        except FileNotFoundError:
            logger.error("Allure CLI not found. Please install it first.")
            return False
        except Exception as e:
            logger.error(f"Error generating HTML report: {e}")
            return False
    
    def serve_report(self, port: int = 8080):
        """Serve Allure report on local server"""
        try:
            cmd = ['allure', 'serve', str(self.results_dir), '-p', str(port)]
            subprocess.run(cmd)
        except Exception as e:
            logger.error(f"Error serving report: {e}")
    
    def generate_summary(self, execution_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate test execution summary"""
        total = len(execution_results)
        passed = sum(1 for r in execution_results if r.get('status') == 'passed')
        failed = sum(1 for r in execution_results if r.get('status') == 'failed')
        skipped = sum(1 for r in execution_results if r.get('status') == 'skipped')
        broken = sum(1 for r in execution_results if r.get('status') == 'error')
        
        duration = sum(r.get('duration', 0) for r in execution_results)
        
        summary = {
            "total": total,
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "broken": broken,
            "pass_rate": (passed / total * 100) if total > 0 else 0,
            "duration": duration,
            "average_duration": duration / total if total > 0 else 0,
            "timestamp": datetime.now().isoformat()
        }
        
        # Save summary
        summary_file = self.report_dir / "summary.json"
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)
        
        return summary
    
    def export_to_formats(self, summary: Dict[str, Any], formats: List[str]):
        """Export report to different formats"""
        exported_files = []
        
        if "JSON" in formats:
            json_file = self.report_dir / "report.json"
            with open(json_file, 'w') as f:
                json.dump(summary, f, indent=2)
            exported_files.append(str(json_file))
        
        if "CSV" in formats:
            import csv
            csv_file = self.report_dir / "report.csv"
            
            with open(csv_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(summary.keys())
                writer.writerow(summary.values())
            
            exported_files.append(str(csv_file))
        
        if "PDF" in formats:
            # PDF generation would require additional libraries like reportlab
            # Simplified for POC
            pdf_file = self.report_dir / "report.pdf"
            # Would generate PDF here
            exported_files.append(str(pdf_file))
        
        return exported_files
    
    def generate_complete_report(self, test_cases: List[Dict[str, Any]], 
                                execution_results: List[Dict[str, Any]],
                                config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate complete Allure report"""
        
        # Save test results
        self.save_test_results(test_cases, execution_results)
        
        # Generate metadata files
        self.generate_environment_properties(config)
        self.generate_executor_info()
        self.generate_categories()
        self.generate_history_trend()
        
        # Generate HTML report
        html_generated = self.generate_html_report()
        
        # Generate summary
        summary = self.generate_summary(execution_results)
        
        # Export to additional formats
        exported_files = self.export_to_formats(summary, ["JSON", "CSV"])
        
        report_info = {
            "summary": summary,
            "html_report": str(self.report_dir / "index.html") if html_generated else None,
            "exported_files": exported_files,
            "results_dir": str(self.results_dir),
            "report_dir": str(self.report_dir)
        }
        
        return report_info