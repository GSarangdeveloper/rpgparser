"""
Git Manager Module
Handles Git repository operations for test script uploads
"""

try:
    import git
    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False
    git = None

from typing import List, Dict, Any, Optional
import os
from pathlib import Path
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class GitManager:
    """Manage Git repository operations"""
    
    def __init__(self, repo_url: str, branch: str = "main",
                 token: str = None, username: str = None, password: str = None):
        if not GIT_AVAILABLE:
            logger.warning("Git is not available. Git operations will be disabled.")

        self.repo_url = repo_url
        self.branch = branch
        self.token = token
        self.username = username
        self.password = password
        self.repo = None
        self.local_path = Path("./temp_repo")
    
    def _get_authenticated_url(self) -> str:
        """Get authenticated repository URL"""
        if self.token:
            # Use token authentication
            if "github.com" in self.repo_url:
                return self.repo_url.replace("https://", f"https://{self.token}@")
            else:
                return self.repo_url.replace("https://", f"https://oauth2:{self.token}@")
        elif self.username and self.password:
            # Use username/password authentication
            return self.repo_url.replace("https://", f"https://{self.username}:{self.password}@")
        else:
            return self.repo_url
    
    def clone_repository(self) -> bool:
        """Clone repository to local path"""
        if not GIT_AVAILABLE:
            logger.error("Git is not available. Cannot clone repository.")
            return False

        try:
            # Remove existing local repo if exists
            if self.local_path.exists():
                import shutil
                shutil.rmtree(self.local_path)

            # Clone repository
            auth_url = self._get_authenticated_url()
            self.repo = git.Repo.clone_from(auth_url, self.local_path, branch=self.branch)
            logger.info(f"Successfully cloned repository to {self.local_path}")
            return True

        except Exception as e:
            logger.error(f"Failed to clone repository: {e}")
            return False
    
    def add_files(self, files: List[Dict[str, Any]], target_folder: str = "tests") -> List[str]:
        """Add files to repository"""
        if not GIT_AVAILABLE:
            logger.error("Git is not available. Cannot add files to repository.")
            return []

        added_files = []

        try:
            # Create target folder if it doesn't exist
            target_path = self.local_path / target_folder
            target_path.mkdir(parents=True, exist_ok=True)

            # Add each file
            for file_data in files:
                filename = file_data.get('filename', 'test.spec.ts')
                content = file_data.get('script', '')

                file_path = target_path / filename

                # Write file
                with open(file_path, 'w') as f:
                    f.write(content)

                # Add to git
                self.repo.index.add([str(file_path.relative_to(self.local_path))])
                added_files.append(str(file_path))

                logger.info(f"Added file: {filename}")

            return added_files

        except Exception as e:
            logger.error(f"Failed to add files: {e}")
            return []
    
    def commit_changes(self, message: str = None) -> str:
        """Commit changes to repository"""
        if not GIT_AVAILABLE:
            logger.error("Git is not available. Cannot commit changes.")
            return ""

        try:
            if not message:
                message = f"Add test scripts - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

            # Commit changes
            commit = self.repo.index.commit(message)
            logger.info(f"Created commit: {commit.hexsha}")

            return commit.hexsha

        except Exception as e:
            logger.error(f"Failed to commit changes: {e}")
            return ""

    def push_changes(self) -> bool:
        """Push changes to remote repository"""
        if not GIT_AVAILABLE:
            logger.error("Git is not available. Cannot push changes.")
            return False

        try:
            # Push to remote
            origin = self.repo.remote('origin')
            origin.push(self.branch)

            logger.info(f"Successfully pushed changes to {self.branch}")
            return True

        except Exception as e:
            logger.error(f"Failed to push changes: {e}")
            return False
    
    def create_pull_request(self, title: str, description: str = "") -> Dict[str, Any]:
        """Create pull request (GitHub specific)"""
        # This would require GitHub API integration
        # Simplified for POC
        return {
            "status": "created",
            "pr_number": "123",
            "url": f"{self.repo_url}/pull/123"
        }
    
    def upload_test_scripts(self, scripts: List[Dict[str, Any]],
                          folder_path: str = "tests",
                          commit_message: str = None) -> Dict[str, Any]:
        """Complete workflow to upload test scripts"""
        result = {
            "success": False,
            "files_uploaded": 0,
            "commit_hash": "",
            "errors": []
        }

        if not GIT_AVAILABLE:
            result["errors"].append("Git is not available. Cannot upload test scripts.")
            return result

        try:
            # Clone repository
            if not self.clone_repository():
                result["errors"].append("Failed to clone repository")
                return result
            
            # Add files
            added_files = self.add_files(scripts, folder_path)
            if not added_files:
                result["errors"].append("Failed to add files")
                return result
            
            result["files_uploaded"] = len(added_files)
            
            # Commit changes
            commit_hash = self.commit_changes(commit_message)
            if not commit_hash:
                result["errors"].append("Failed to commit changes")
                return result
            
            result["commit_hash"] = commit_hash
            
            # Push changes
            if not self.push_changes():
                result["errors"].append("Failed to push changes")
                return result
            
            result["success"] = True
            logger.info(f"Successfully uploaded {len(added_files)} files")
            
        except Exception as e:
            result["errors"].append(str(e))
            logger.error(f"Upload failed: {e}")
        
        finally:
            # Cleanup
            self.cleanup()
        
        return result
    
    def cleanup(self):
        """Clean up local repository"""
        try:
            if self.local_path.exists():
                import shutil
                shutil.rmtree(self.local_path)
                logger.info("Cleaned up local repository")
        except Exception as e:
            logger.error(f"Failed to cleanup: {e}")
    
    def get_repository_info(self) -> Dict[str, Any]:
        """Get repository information"""
        info = {
            "url": self.repo_url,
            "branch": self.branch,
            "authenticated": bool(self.token or (self.username and self.password))
        }
        
        if self.repo:
            info.update({
                "current_commit": self.repo.head.commit.hexsha,
                "active_branch": self.repo.active_branch.name,
                "remotes": [r.name for r in self.repo.remotes]
            })
        
        return info