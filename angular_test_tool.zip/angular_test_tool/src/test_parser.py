"""
Test Parser Module
Parses test cases from CSV/JSON files and converts to internal format
"""

import csv
import json
import pandas as pd
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
import re
from pathlib import Path


class TestAction(Enum):
    """Supported test actions"""
    NAVIGATE = "navigate"
    CLICK = "click"
    TYPE = "type"
    SELECT = "select"
    WAIT = "wait"
    ASSERT_VISIBLE = "assert_visible"
    ASSERT_TEXT = "assert_text"
    ASSERT_URL = "assert_url"
    ASSERT_ATTRIBUTE = "assert_attribute"
    SCREENSHOT = "screenshot"
    SCROLL = "scroll"
    HOVER = "hover"
    DRAG_DROP = "drag_drop"
    CLEAR = "clear"
    REFRESH = "refresh"
    BACK = "back"
    FORWARD = "forward"


@dataclass
class TestStep:
    """Individual test step"""
    action: TestAction
    selector: Optional[str] = None
    data: Optional[str] = None
    description: Optional[str] = None
    wait_condition: Optional[str] = None
    timeout: int = 30000
    screenshot: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "action": self.action.value,
            "selector": self.selector,
            "data": self.data,
            "description": self.description,
            "wait_condition": self.wait_condition,
            "timeout": self.timeout,
            "screenshot": self.screenshot
        }


@dataclass
class TestCase:
    """Complete test case"""
    test_id: str
    test_name: str
    test_suite: Optional[str] = None
    description: Optional[str] = None
    priority: str = "medium"
    preconditions: Optional[str] = None
    steps: List[TestStep] = None
    expected_result: Optional[str] = None
    test_data: Optional[Dict[str, Any]] = None
    tags: List[str] = None
    
    def __post_init__(self):
        if self.steps is None:
            self.steps = []
        if self.tags is None:
            self.tags = []
        if self.test_data is None:
            self.test_data = {}
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "test_id": self.test_id,
            "test_name": self.test_name,
            "test_suite": self.test_suite,
            "description": self.description,
            "priority": self.priority,
            "preconditions": self.preconditions,
            "steps": [step.to_dict() for step in self.steps],
            "expected_result": self.expected_result,
            "test_data": self.test_data,
            "tags": self.tags
        }


class TestParser:
    """Parse test cases from various formats"""
    
    def __init__(self):
        self.parsed_tests = []
        self.parsing_errors = []
        self.parsing_warnings = []
    
    def parse_csv(self, file_path: str) -> List[TestCase]:
        """Parse test cases from CSV file"""
        test_cases = []
        current_test = None
        
        try:
            df = pd.read_csv(file_path)
            
            # Expected columns
            required_columns = ['test_id', 'test_name', 'action', 'selector']
            optional_columns = ['input_data', 'expected_result', 'wait_condition', 
                              'description', 'priority', 'test_suite', 'tags']
            
            # Validate columns
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                self.parsing_errors.append(f"Missing required columns: {missing_columns}")
                return []
            
            # Process rows
            for index, row in df.iterrows():
                test_id = str(row['test_id'])
                
                # Check if this is a new test case
                if pd.notna(row['test_name']):
                    # Save previous test if exists
                    if current_test:
                        test_cases.append(current_test)
                    
                    # Create new test case
                    current_test = TestCase(
                        test_id=test_id,
                        test_name=row['test_name'],
                        test_suite=row.get('test_suite') if 'test_suite' in row else None,
                        description=row.get('description') if 'description' in row else None,
                        priority=row.get('priority', 'medium') if 'priority' in row else 'medium',
                        tags=row.get('tags').split(',') if 'tags' in row and pd.notna(row.get('tags')) else []
                    )
                
                # Add step to current test
                if current_test:
                    try:
                        action = TestAction(row['action'].lower())
                        step = TestStep(
                            action=action,
                            selector=row.get('selector') if pd.notna(row.get('selector')) else None,
                            data=str(row.get('input_data')) if pd.notna(row.get('input_data')) else None,
                            description=row.get('description') if pd.notna(row.get('description')) else None,
                            wait_condition=row.get('wait_condition') if pd.notna(row.get('wait_condition')) else None
                        )
                        current_test.steps.append(step)
                        
                        # Set expected result if provided
                        if pd.notna(row.get('expected_result')):
                            current_test.expected_result = row['expected_result']
                            
                    except ValueError as e:
                        self.parsing_warnings.append(f"Row {index}: Invalid action '{row['action']}'")
            
            # Add last test case
            if current_test:
                test_cases.append(current_test)
            
            self.parsed_tests = test_cases
            return test_cases
            
        except Exception as e:
            self.parsing_errors.append(f"Error parsing CSV: {str(e)}")
            return []
    
    def parse_json(self, file_path: str) -> List[TestCase]:
        """Parse test cases from JSON file"""
        test_cases = []
        
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            # Handle both single test and multiple tests
            tests_data = data if isinstance(data, list) else [data]
            
            for test_data in tests_data:
                test_case = self._parse_json_test(test_data)
                if test_case:
                    test_cases.append(test_case)
            
            self.parsed_tests = test_cases
            return test_cases
            
        except Exception as e:
            self.parsing_errors.append(f"Error parsing JSON: {str(e)}")
            return []
    
    def _parse_json_test(self, test_data: Dict[str, Any]) -> Optional[TestCase]:
        """Parse individual test from JSON data"""
        try:
            # Create test case
            test_case = TestCase(
                test_id=test_data.get('test_id', ''),
                test_name=test_data.get('test_name', ''),
                test_suite=test_data.get('test_suite'),
                description=test_data.get('description'),
                priority=test_data.get('priority', 'medium'),
                preconditions=test_data.get('preconditions'),
                expected_result=test_data.get('expected_result'),
                test_data=test_data.get('test_data', {}),
                tags=test_data.get('tags', [])
            )
            
            # Parse steps
            steps_data = test_data.get('steps', [])
            for step_data in steps_data:
                try:
                    action = TestAction(step_data.get('action', '').lower())
                    step = TestStep(
                        action=action,
                        selector=step_data.get('selector'),
                        data=step_data.get('data'),
                        description=step_data.get('description'),
                        wait_condition=step_data.get('wait_condition'),
                        timeout=step_data.get('timeout', 30000),
                        screenshot=step_data.get('screenshot', False)
                    )
                    test_case.steps.append(step)
                except ValueError:
                    self.parsing_warnings.append(
                        f"Test {test_case.test_id}: Invalid action '{step_data.get('action')}'"
                    )
            
            return test_case
            
        except Exception as e:
            self.parsing_errors.append(f"Error parsing test: {str(e)}")
            return None
    
    def parse_manual_input(self, test_data: Dict[str, Any]) -> TestCase:
        """Parse manually entered test case"""
        return self._parse_json_test(test_data)
    
    def validate_test_cases(self, test_cases: List[TestCase]) -> Dict[str, Any]:
        """Validate parsed test cases"""
        validation_results = {
            "valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {}
        }
        
        # Check for duplicate test IDs
        test_ids = [tc.test_id for tc in test_cases]
        duplicates = [id for id in test_ids if test_ids.count(id) > 1]
        if duplicates:
            validation_results["errors"].append(f"Duplicate test IDs found: {set(duplicates)}")
            validation_results["valid"] = False
        
        # Validate each test case
        for test_case in test_cases:
            # Check required fields
            if not test_case.test_id:
                validation_results["errors"].append(f"Test case missing ID")
                validation_results["valid"] = False
            
            if not test_case.test_name:
                validation_results["errors"].append(f"Test {test_case.test_id}: Missing name")
                validation_results["valid"] = False
            
            if not test_case.steps:
                validation_results["warnings"].append(f"Test {test_case.test_id}: No steps defined")
            
            # Validate steps
            for i, step in enumerate(test_case.steps):
                # Check if selector is required for action
                selector_required = step.action not in [
                    TestAction.NAVIGATE, TestAction.SCREENSHOT, 
                    TestAction.REFRESH, TestAction.BACK, TestAction.FORWARD
                ]
                
                if selector_required and not step.selector:
                    validation_results["warnings"].append(
                        f"Test {test_case.test_id}, Step {i+1}: Missing selector for {step.action.value}"
                    )
                
                # Check if data is required
                data_required = step.action in [
                    TestAction.NAVIGATE, TestAction.TYPE, TestAction.SELECT,
                    TestAction.ASSERT_TEXT, TestAction.ASSERT_URL, TestAction.ASSERT_ATTRIBUTE
                ]
                
                if data_required and not step.data:
                    validation_results["warnings"].append(
                        f"Test {test_case.test_id}, Step {i+1}: Missing data for {step.action.value}"
                    )
        
        # Calculate statistics
        validation_results["statistics"] = {
            "total_tests": len(test_cases),
            "total_steps": sum(len(tc.steps) for tc in test_cases),
            "tests_by_priority": {
                "high": len([tc for tc in test_cases if tc.priority == "high"]),
                "medium": len([tc for tc in test_cases if tc.priority == "medium"]),
                "low": len([tc for tc in test_cases if tc.priority == "low"])
            },
            "tests_by_suite": {}
        }
        
        # Group by test suite
        for tc in test_cases:
            suite = tc.test_suite or "default"
            if suite not in validation_results["statistics"]["tests_by_suite"]:
                validation_results["statistics"]["tests_by_suite"][suite] = 0
            validation_results["statistics"]["tests_by_suite"][suite] += 1
        
        return validation_results
    
    def export_to_json(self, test_cases: List[TestCase], output_path: str):
        """Export test cases to JSON format"""
        data = [tc.to_dict() for tc in test_cases]
        
        with open(output_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def generate_sample_csv(self, output_path: str):
        """Generate sample CSV template"""
        sample_data = [
            {
                'test_id': 'TC001',
                'test_name': 'User Login Test',
                'test_suite': 'Authentication',
                'action': 'navigate',
                'selector': '',
                'input_data': 'https://example.com/login',
                'expected_result': 'User successfully logged in',
                'wait_condition': 'networkidle',
                'description': 'Navigate to login page',
                'priority': 'high',
                'tags': 'login,critical'
            },
            {
                'test_id': 'TC001',
                'test_name': '',
                'test_suite': '',
                'action': 'type',
                'selector': '#username',
                'input_data': 'testuser@example.com',
                'expected_result': '',
                'wait_condition': '',
                'description': 'Enter username',
                'priority': '',
                'tags': ''
            },
            {
                'test_id': 'TC001',
                'test_name': '',
                'test_suite': '',
                'action': 'type',
                'selector': '#password',
                'input_data': 'SecurePassword123',
                'expected_result': '',
                'wait_condition': '',
                'description': 'Enter password',
                'priority': '',
                'tags': ''
            },
            {
                'test_id': 'TC001',
                'test_name': '',
                'test_suite': '',
                'action': 'click',
                'selector': '#login-button',
                'input_data': '',
                'expected_result': '',
                'wait_condition': 'networkidle',
                'description': 'Click login button',
                'priority': '',
                'tags': ''
            },
            {
                'test_id': 'TC001',
                'test_name': '',
                'test_suite': '',
                'action': 'assert_visible',
                'selector': '#dashboard',
                'input_data': '',
                'expected_result': '',
                'wait_condition': '',
                'description': 'Verify dashboard is visible',
                'priority': '',
                'tags': ''
            }
        ]
        
        df = pd.DataFrame(sample_data)
        df.to_csv(output_path, index=False)
    
    def generate_sample_json(self, output_path: str):
        """Generate sample JSON template"""
        sample_data = [
            {
                "test_id": "TC001",
                "test_name": "User Login Test",
                "test_suite": "Authentication",
                "description": "Test user login functionality",
                "priority": "high",
                "preconditions": "User account exists in the system",
                "steps": [
                    {
                        "action": "navigate",
                        "data": "https://example.com/login",
                        "description": "Navigate to login page",
                        "wait_condition": "networkidle"
                    },
                    {
                        "action": "type",
                        "selector": "#username",
                        "data": "testuser@example.com",
                        "description": "Enter username"
                    },
                    {
                        "action": "type",
                        "selector": "#password",
                        "data": "SecurePassword123",
                        "description": "Enter password"
                    },
                    {
                        "action": "click",
                        "selector": "#login-button",
                        "description": "Click login button",
                        "wait_condition": "networkidle"
                    },
                    {
                        "action": "assert_visible",
                        "selector": "#dashboard",
                        "description": "Verify dashboard is visible"
                    }
                ],
                "expected_result": "User successfully logged in and dashboard is displayed",
                "test_data": {
                    "username": "testuser@example.com",
                    "password": "SecurePassword123"
                },
                "tags": ["login", "critical", "smoke"]
            }
        ]
        
        with open(output_path, 'w') as f:
            json.dump(sample_data, f, indent=2)