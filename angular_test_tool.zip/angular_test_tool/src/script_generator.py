"""
Script Generator Module
Generates Playwright test scripts from test cases
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
from jinja2 import Template
from datetime import datetime
import re
from pathlib import Path


class ScriptTemplate(Enum):
    """Available script templates"""
    BASIC = "basic"
    PAGE_OBJECT = "page_object"
    DATA_DRIVEN = "data_driven"
    BDD = "bdd"
    CUSTOM = "custom"


class ScriptGenerator:
    """Generate Playwright test scripts from test cases"""
    
    def __init__(self):
        self.templates = self._load_templates()
        self.generated_scripts = []
    
    def _load_templates(self) -> Dict[str, Template]:
        """Load script templates"""
        templates = {}
        
        # Basic Template
        templates[ScriptTemplate.BASIC.value] = Template("""import { test, expect } from '@playwright/test';
import allure from '@playwright/test';

test.describe('{{ test_suite }}', () => {
{% for test_case in test_cases %}
  test('{{ test_case.test_name }}', async ({ page }) => {
    // Test ID: {{ test_case.test_id }}
    // Priority: {{ test_case.priority }}
    // Description: {{ test_case.description }}
    {% if test_case.preconditions %}
    // Preconditions: {{ test_case.preconditions }}
    {% endif %}
    
    allure.feature('{{ test_case.test_suite }}');
    allure.story('{{ test_case.test_name }}');
    allure.severity('{{ test_case.priority }}');
    
    {% for step in test_case.steps %}
    // Step {{ loop.index }}: {{ step.description }}
    {% if step.action == 'navigate' %}
    await page.goto('{{ step.data }}', { waitUntil: '{{ step.wait_condition or "networkidle" }}' });
    {% elif step.action == 'click' %}
    await page.click('{{ step.selector }}'{% if step.timeout %}, { timeout: {{ step.timeout }} }{% endif %});
    {% elif step.action == 'type' %}
    await page.fill('{{ step.selector }}', '{{ step.data }}');
    {% elif step.action == 'select' %}
    await page.selectOption('{{ step.selector }}', '{{ step.data }}');
    {% elif step.action == 'wait' %}
    await page.waitForSelector('{{ step.selector }}'{% if step.wait_condition %}, { state: '{{ step.wait_condition }}' }{% endif %});
    {% elif step.action == 'assert_visible' %}
    await expect(page.locator('{{ step.selector }}')).toBeVisible();
    {% elif step.action == 'assert_text' %}
    await expect(page.locator('{{ step.selector }}')).toContainText('{{ step.data }}');
    {% elif step.action == 'assert_url' %}
    await expect(page).toHaveURL('{{ step.data }}');
    {% elif step.action == 'assert_attribute' %}
    await expect(page.locator('{{ step.selector }}')).toHaveAttribute('{{ step.data.split(":")[0] }}', '{{ step.data.split(":")[1] }}');
    {% elif step.action == 'screenshot' %}
    await page.screenshot({ path: '{{ step.data or "screenshot_" + test_case.test_id + "_" + loop.index|string + ".png" }}', fullPage: {{ step.full_page|lower }} });
    {% elif step.action == 'scroll' %}
    await page.locator('{{ step.selector }}').scrollIntoViewIfNeeded();
    {% elif step.action == 'hover' %}
    await page.hover('{{ step.selector }}');
    {% elif step.action == 'clear' %}
    await page.fill('{{ step.selector }}', '');
    {% elif step.action == 'refresh' %}
    await page.reload();
    {% elif step.action == 'back' %}
    await page.goBack();
    {% elif step.action == 'forward' %}
    await page.goForward();
    {% endif %}
    {% if step.screenshot %}
    await allure.attachment('Step {{ loop.index }} Screenshot', await page.screenshot(), 'image/png');
    {% endif %}
    {% endfor %}
    
    {% if test_case.expected_result %}
    // Expected Result: {{ test_case.expected_result }}
    {% endif %}
  });
  
{% endfor %}
});
""")
        
        # Page Object Model Template
        templates[ScriptTemplate.PAGE_OBJECT.value] = Template("""import { test, expect, Page } from '@playwright/test';
import allure from '@playwright/test';

// Page Objects
{% for page_name, page_elements in page_objects.items() %}
class {{ page_name }}Page {
  constructor(private page: Page) {}
  
  // Locators
{% for element_name, selector in page_elements.items() %}
  {{ element_name }} = () => this.page.locator('{{ selector }}');
{% endfor %}
  
  // Actions
  async navigate(url: string) {
    await this.page.goto(url);
  }
  
  async waitForLoad() {
    await this.page.waitForLoadState('networkidle');
  }
}
{% endfor %}

// Tests
test.describe('{{ test_suite }}', () => {
{% for test_case in test_cases %}
  test('{{ test_case.test_name }}', async ({ page }) => {
    // Initialize page objects
{% for page_name in page_objects.keys() %}
    const {{ page_name|lower }}Page = new {{ page_name }}Page(page);
{% endfor %}
    
    allure.feature('{{ test_case.test_suite }}');
    allure.story('{{ test_case.test_name }}');
    
    {% for step in test_case.steps %}
    // {{ step.description }}
    {{ step.generated_code }}
    {% endfor %}
  });
  
{% endfor %}
});
""")
        
        # Data-Driven Template
        templates[ScriptTemplate.DATA_DRIVEN.value] = Template("""import { test, expect } from '@playwright/test';
import allure from '@playwright/test';

// Test Data
const testData = {{ test_data|tojson }};

test.describe('{{ test_suite }}', () => {
  testData.forEach((data) => {
    test(`{{ test_name }} - ${data.name}`, async ({ page }) => {
      allure.feature('{{ test_suite }}');
      allure.story('{{ test_name }}');
      allure.parameter('Test Data', JSON.stringify(data));
      
      {% for step in test_steps %}
      // {{ step.description }}
      {% if step.uses_data %}
      {{ step.generated_code|replace('${data}', 'data') }}
      {% else %}
      {{ step.generated_code }}
      {% endif %}
      {% endfor %}
    });
  });
});
""")
        
        # BDD Template
        templates[ScriptTemplate.BDD.value] = Template("""import { test, expect } from '@playwright/test';
import allure from '@playwright/test';

test.describe('{{ feature }}', () => {
{% for scenario in scenarios %}
  test('{{ scenario.name }}', async ({ page }) => {
    allure.feature('{{ feature }}');
    allure.story('{{ scenario.name }}');
    
    {% for step in scenario.steps %}
    // {{ step.type }}: {{ step.description }}
    await test.step('{{ step.type }}: {{ step.description }}', async () => {
      {{ step.generated_code }}
    });
    {% endfor %}
  });
  
{% endfor %}
});
""")
        
        return templates
    
    def generate_script(self, test_cases: List[Dict[str, Any]], 
                       template_type: ScriptTemplate = ScriptTemplate.BASIC,
                       config: Dict[str, Any] = None) -> str:
        """Generate test script from test cases"""
        
        if not test_cases:
            return ""
        
        config = config or {}
        
        # Group test cases by suite
        test_suites = {}
        for test_case in test_cases:
            suite = test_case.get('test_suite', 'Default Suite')
            if suite not in test_suites:
                test_suites[suite] = []
            test_suites[suite].append(test_case)
        
        scripts = []
        
        for suite_name, suite_tests in test_suites.items():
            if template_type == ScriptTemplate.BASIC:
                script = self._generate_basic_script(suite_name, suite_tests, config)
            elif template_type == ScriptTemplate.PAGE_OBJECT:
                script = self._generate_page_object_script(suite_name, suite_tests, config)
            elif template_type == ScriptTemplate.DATA_DRIVEN:
                script = self._generate_data_driven_script(suite_name, suite_tests, config)
            elif template_type == ScriptTemplate.BDD:
                script = self._generate_bdd_script(suite_name, suite_tests, config)
            else:
                script = self._generate_custom_script(suite_name, suite_tests, config)
            
            scripts.append({
                'suite_name': suite_name,
                'script': script,
                'filename': self._generate_filename(suite_name),
                'test_count': len(suite_tests)
            })
        
        self.generated_scripts = scripts
        return scripts
    
    def _generate_basic_script(self, suite_name: str, test_cases: List[Dict[str, Any]], 
                              config: Dict[str, Any]) -> str:
        """Generate basic test script"""
        template = self.templates[ScriptTemplate.BASIC.value]
        
        return template.render(
            test_suite=suite_name,
            test_cases=test_cases,
            config=config
        )
    
    def _generate_page_object_script(self, suite_name: str, test_cases: List[Dict[str, Any]], 
                                    config: Dict[str, Any]) -> str:
        """Generate page object model script"""
        # Extract page objects from test cases
        page_objects = self._extract_page_objects(test_cases)
        
        # Generate code for each step
        for test_case in test_cases:
            for step in test_case.get('steps', []):
                step['generated_code'] = self._generate_pom_step_code(step, page_objects)
        
        template = self.templates[ScriptTemplate.PAGE_OBJECT.value]
        
        return template.render(
            test_suite=suite_name,
            test_cases=test_cases,
            page_objects=page_objects,
            config=config
        )
    
    def _generate_data_driven_script(self, suite_name: str, test_cases: List[Dict[str, Any]], 
                                    config: Dict[str, Any]) -> str:
        """Generate data-driven test script"""
        # Extract test data
        test_data = []
        for test_case in test_cases:
            if test_case.get('test_data'):
                test_data.append({
                    'name': test_case.get('test_name'),
                    **test_case.get('test_data', {})
                })
        
        # Use first test case as template
        template_test = test_cases[0] if test_cases else {}
        
        template = self.templates[ScriptTemplate.DATA_DRIVEN.value]
        
        return template.render(
            test_suite=suite_name,
            test_name=template_test.get('test_name', 'Data Driven Test'),
            test_steps=template_test.get('steps', []),
            test_data=test_data,
            config=config
        )
    
    def _generate_bdd_script(self, suite_name: str, test_cases: List[Dict[str, Any]], 
                            config: Dict[str, Any]) -> str:
        """Generate BDD-style test script"""
        # Convert test cases to BDD scenarios
        scenarios = []
        
        for test_case in test_cases:
            scenario = {
                'name': test_case.get('test_name'),
                'steps': []
            }
            
            # Convert steps to Given/When/Then format
            for i, step in enumerate(test_case.get('steps', [])):
                step_type = 'Given' if i == 0 else 'When' if step.get('action') in ['click', 'type', 'select'] else 'Then'
                scenario['steps'].append({
                    'type': step_type,
                    'description': step.get('description', f"Step {i+1}"),
                    'generated_code': self._generate_step_code(step)
                })
            
            scenarios.append(scenario)
        
        template = self.templates[ScriptTemplate.BDD.value]
        
        return template.render(
            feature=suite_name,
            scenarios=scenarios,
            config=config
        )
    
    def _generate_custom_script(self, suite_name: str, test_cases: List[Dict[str, Any]], 
                               config: Dict[str, Any]) -> str:
        """Generate script using custom template"""
        custom_template = config.get('custom_template')
        
        if not custom_template:
            return self._generate_basic_script(suite_name, test_cases, config)
        
        template = Template(custom_template)
        
        return template.render(
            test_suite=suite_name,
            test_cases=test_cases,
            config=config
        )
    
    def _extract_page_objects(self, test_cases: List[Dict[str, Any]]) -> Dict[str, Dict[str, str]]:
        """Extract page objects from test cases"""
        page_objects = {}
        
        for test_case in test_cases:
            for step in test_case.get('steps', []):
                selector = step.get('selector')
                if selector:
                    # Determine page name from selector or URL
                    page_name = self._determine_page_name(step)
                    
                    if page_name not in page_objects:
                        page_objects[page_name] = {}
                    
                    # Generate element name from selector
                    element_name = self._generate_element_name(selector)
                    page_objects[page_name][element_name] = selector
        
        return page_objects
    
    def _determine_page_name(self, step: Dict[str, Any]) -> str:
        """Determine page name from step"""
        # Simple heuristic - can be improved
        if step.get('action') == 'navigate':
            url = step.get('data', '')
            if 'login' in url.lower():
                return 'Login'
            elif 'dashboard' in url.lower():
                return 'Dashboard'
            elif 'profile' in url.lower():
                return 'Profile'
        
        # Default based on selector
        selector = step.get('selector', '')
        if 'login' in selector.lower():
            return 'Login'
        elif 'dashboard' in selector.lower():
            return 'Dashboard'
        
        return 'Main'
    
    def _generate_element_name(self, selector: str) -> str:
        """Generate element name from selector"""
        # Remove special characters and convert to camelCase
        name = re.sub(r'[#\.\[\]=\"\']+', ' ', selector)
        name = re.sub(r'[^a-zA-Z0-9\s]', '', name)
        words = name.split()
        
        if words:
            return words[0].lower() + ''.join(word.capitalize() for word in words[1:])
        
        return 'element'
    
    def _generate_pom_step_code(self, step: Dict[str, Any], page_objects: Dict[str, Dict[str, str]]) -> str:
        """Generate page object model step code"""
        action = step.get('action')
        selector = step.get('selector')
        data = step.get('data')
        
        # Find element in page objects
        element_name = None
        page_name = None
        
        for p_name, elements in page_objects.items():
            for e_name, e_selector in elements.items():
                if e_selector == selector:
                    element_name = e_name
                    page_name = p_name.lower()
                    break
        
        if not element_name:
            return self._generate_step_code(step)
        
        # Generate POM-style code
        if action == 'click':
            return f"await {page_name}Page.{element_name}().click();"
        elif action == 'type':
            return f"await {page_name}Page.{element_name}().fill('{data}');"
        elif action == 'assert_visible':
            return f"await expect({page_name}Page.{element_name}()).toBeVisible();"
        
        return self._generate_step_code(step)
    
    def _generate_step_code(self, step: Dict[str, Any]) -> str:
        """Generate code for a single step"""
        action = step.get('action')
        selector = step.get('selector')
        data = step.get('data')
        
        code_map = {
            'navigate': f"await page.goto('{data}');",
            'click': f"await page.click('{selector}');",
            'type': f"await page.fill('{selector}', '{data}');",
            'select': f"await page.selectOption('{selector}', '{data}');",
            'wait': f"await page.waitForSelector('{selector}');",
            'assert_visible': f"await expect(page.locator('{selector}')).toBeVisible();",
            'assert_text': f"await expect(page.locator('{selector}')).toContainText('{data}');",
            'assert_url': f"await expect(page).toHaveURL('{data}');",
            'screenshot': f"await page.screenshot({{ path: '{data or 'screenshot.png'}' }});",
            'scroll': f"await page.locator('{selector}').scrollIntoViewIfNeeded();",
            'hover': f"await page.hover('{selector}');",
            'clear': f"await page.fill('{selector}', '');",
            'refresh': "await page.reload();",
            'back': "await page.goBack();",
            'forward': "await page.goForward();"
        }
        
        return code_map.get(action, f"// Unknown action: {action}")
    
    def _generate_filename(self, suite_name: str) -> str:
        """Generate filename for test script"""
        # Clean suite name
        filename = re.sub(r'[^a-zA-Z0-9\s]', '', suite_name)
        filename = filename.replace(' ', '_').lower()
        
        return f"{filename}_test.spec.ts"
    
    def validate_script(self, script: str) -> Dict[str, Any]:
        """Validate generated script"""
        validation = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        # Check for basic syntax issues
        if not script:
            validation['valid'] = False
            validation['errors'].append("Empty script generated")
            return validation
        
        # Check for required imports
        if '@playwright/test' not in script:
            validation['warnings'].append("Missing Playwright import")
        
        # Check for test structure
        if 'test.describe' not in script and 'test(' not in script:
            validation['errors'].append("No test structure found")
            validation['valid'] = False
        
        # Check for unescaped quotes
        lines = script.split('\n')
        for i, line in enumerate(lines):
            if line.strip().startswith('await'):
                # Simple check for unescaped quotes
                if line.count("'") % 2 != 0:
                    validation['warnings'].append(f"Line {i+1}: Possible unescaped quote")
        
        return validation
    
    def export_scripts(self, output_dir: str):
        """Export generated scripts to files"""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        exported_files = []
        
        for script_data in self.generated_scripts:
            file_path = output_path / script_data['filename']
            
            with open(file_path, 'w') as f:
                f.write(script_data['script'])
            
            exported_files.append(str(file_path))
        
        return exported_files