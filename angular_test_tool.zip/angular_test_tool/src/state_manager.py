"""
State Manager for Workflow Management
Handles session state, workflow steps, and approval gates
"""

from enum import Enum
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from datetime import datetime
import json
import pickle
import os


class WorkflowStep(Enum):
    """Workflow steps enumeration"""
    CONFIGURATION = "configuration"
    TEST_DEFINITION = "test_definition"
    SCRIPT_GENERATION = "script_generation"
    TEST_EXECUTION = "test_execution"
    REPORT_GENERATION = "report_generation"
    GIT_UPLOAD = "git_upload"
    COMPLETED = "completed"


class ApprovalStatus(Enum):
    """Approval status for each step"""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EDITED = "edited"


@dataclass
class StepState:
    """State for individual workflow step"""
    step: WorkflowStep
    status: ApprovalStatus
    data: Dict[str, Any]
    timestamp: str
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    artifacts: List[str] = field(default_factory=list)


class StateManager:
    """Manages application state and workflow"""
    
    def __init__(self):
        self.current_step = WorkflowStep.CONFIGURATION
        self.steps_state = {}
        self.session_id = None
        self.session_start = datetime.now()
        self.configuration = {}
        self.test_cases = []
        self.generated_scripts = []
        self.execution_results = []
        self.report_data = {}
        self.git_info = {}
        self._initialize_steps()
    
    def _initialize_steps(self):
        """Initialize all workflow steps"""
        for step in WorkflowStep:
            if step != WorkflowStep.COMPLETED:
                self.steps_state[step] = StepState(
                    step=step,
                    status=ApprovalStatus.PENDING,
                    data={},
                    timestamp=datetime.now().isoformat()
                )
    
    def get_current_step(self) -> WorkflowStep:
        """Get current workflow step"""
        return self.current_step
    
    def get_step_state(self, step: WorkflowStep) -> Optional[StepState]:
        """Get state of specific step"""
        return self.steps_state.get(step)
    
    def update_step_data(self, step: WorkflowStep, data: Dict[str, Any]):
        """Update data for a specific step"""
        if step in self.steps_state:
            self.steps_state[step].data.update(data)
            self.steps_state[step].timestamp = datetime.now().isoformat()
    
    def approve_step(self, step: WorkflowStep) -> bool:
        """Approve current step and move to next"""
        if step != self.current_step:
            return False
        
        self.steps_state[step].status = ApprovalStatus.APPROVED
        
        # Move to next step
        step_order = list(WorkflowStep)
        current_index = step_order.index(step)
        
        if current_index < len(step_order) - 1:
            self.current_step = step_order[current_index + 1]
            return True
        
        return False
    
    def reject_step(self, step: WorkflowStep) -> bool:
        """Reject current step and go back"""
        if step != self.current_step:
            return False
        
        self.steps_state[step].status = ApprovalStatus.REJECTED
        
        # Move to previous step
        step_order = list(WorkflowStep)
        current_index = step_order.index(step)
        
        if current_index > 0:
            self.current_step = step_order[current_index - 1]
            self.steps_state[self.current_step].status = ApprovalStatus.EDITED
            return True
        
        return False
    
    def edit_step(self, step: WorkflowStep) -> bool:
        """Mark step for editing"""
        if step != self.current_step:
            return False
        
        self.steps_state[step].status = ApprovalStatus.EDITED
        return True
    
    def can_proceed(self) -> bool:
        """Check if can proceed to next step"""
        current_state = self.steps_state.get(self.current_step)
        return current_state and current_state.status == ApprovalStatus.APPROVED
    
    def can_go_back(self) -> bool:
        """Check if can go back to previous step"""
        step_order = list(WorkflowStep)
        current_index = step_order.index(self.current_step)
        return current_index > 0
    
    def get_workflow_progress(self) -> Dict[str, Any]:
        """Get overall workflow progress"""
        total_steps = len(WorkflowStep) - 1  # Exclude COMPLETED
        approved_steps = sum(
            1 for state in self.steps_state.values() 
            if state.status == ApprovalStatus.APPROVED
        )
        
        return {
            "current_step": self.current_step.value,
            "total_steps": total_steps,
            "completed_steps": approved_steps,
            "progress_percentage": (approved_steps / total_steps) * 100,
            "session_duration": (datetime.now() - self.session_start).total_seconds()
        }
    
    def save_configuration(self, config: Dict[str, Any]):
        """Save project configuration"""
        self.configuration = config
        self.update_step_data(WorkflowStep.CONFIGURATION, config)
    
    def save_test_cases(self, test_cases: List[Dict[str, Any]]):
        """Save test case definitions"""
        self.test_cases = test_cases
        self.update_step_data(WorkflowStep.TEST_DEFINITION, {
            "test_cases": test_cases,
            "total_tests": len(test_cases)
        })
    
    def save_generated_scripts(self, scripts: List[Dict[str, Any]]):
        """Save generated test scripts"""
        self.generated_scripts = scripts
        self.update_step_data(WorkflowStep.SCRIPT_GENERATION, {
            "scripts": scripts,
            "total_scripts": len(scripts)
        })
    
    def save_execution_results(self, results: List[Dict[str, Any]]):
        """Save test execution results"""
        self.execution_results = results
        
        # Calculate statistics
        total_tests = len(results)
        passed_tests = sum(1 for r in results if r.get("status") == "passed")
        failed_tests = sum(1 for r in results if r.get("status") == "failed")
        
        self.update_step_data(WorkflowStep.TEST_EXECUTION, {
            "results": results,
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "success_rate": (passed_tests / total_tests * 100) if total_tests > 0 else 0
        })
    
    def save_report_data(self, report: Dict[str, Any]):
        """Save generated report data"""
        self.report_data = report
        self.update_step_data(WorkflowStep.REPORT_GENERATION, report)
    
    def save_git_info(self, git_info: Dict[str, Any]):
        """Save Git upload information"""
        self.git_info = git_info
        self.update_step_data(WorkflowStep.GIT_UPLOAD, git_info)
    
    def add_error(self, step: WorkflowStep, error: str):
        """Add error to step"""
        if step in self.steps_state:
            self.steps_state[step].errors.append(error)
    
    def add_warning(self, step: WorkflowStep, warning: str):
        """Add warning to step"""
        if step in self.steps_state:
            self.steps_state[step].warnings.append(warning)
    
    def add_artifact(self, step: WorkflowStep, artifact_path: str):
        """Add artifact to step"""
        if step in self.steps_state:
            self.steps_state[step].artifacts.append(artifact_path)
    
    def get_step_errors(self, step: WorkflowStep) -> List[str]:
        """Get errors for a step"""
        state = self.steps_state.get(step)
        return state.errors if state else []
    
    def get_step_warnings(self, step: WorkflowStep) -> List[str]:
        """Get warnings for a step"""
        state = self.steps_state.get(step)
        return state.warnings if state else []
    
    def export_state(self, filepath: str):
        """Export current state to file"""
        state_data = {
            "session_id": self.session_id,
            "session_start": self.session_start.isoformat(),
            "current_step": self.current_step.value,
            "configuration": self.configuration,
            "test_cases": self.test_cases,
            "generated_scripts": self.generated_scripts,
            "execution_results": self.execution_results,
            "report_data": self.report_data,
            "git_info": self.git_info,
            "steps_state": {
                step.value: {
                    "status": state.status.value,
                    "data": state.data,
                    "timestamp": state.timestamp,
                    "errors": state.errors,
                    "warnings": state.warnings,
                    "artifacts": state.artifacts
                }
                for step, state in self.steps_state.items()
            }
        }
        
        with open(filepath, 'w') as f:
            json.dump(state_data, f, indent=2)
    
    def import_state(self, filepath: str):
        """Import state from file"""
        with open(filepath, 'r') as f:
            state_data = json.load(f)
        
        self.session_id = state_data.get("session_id")
        self.session_start = datetime.fromisoformat(state_data.get("session_start"))
        self.current_step = WorkflowStep(state_data.get("current_step"))
        self.configuration = state_data.get("configuration", {})
        self.test_cases = state_data.get("test_cases", [])
        self.generated_scripts = state_data.get("generated_scripts", [])
        self.execution_results = state_data.get("execution_results", [])
        self.report_data = state_data.get("report_data", {})
        self.git_info = state_data.get("git_info", {})
        
        # Restore steps state
        for step_name, step_data in state_data.get("steps_state", {}).items():
            step = WorkflowStep(step_name)
            self.steps_state[step] = StepState(
                step=step,
                status=ApprovalStatus(step_data["status"]),
                data=step_data["data"],
                timestamp=step_data["timestamp"],
                errors=step_data.get("errors", []),
                warnings=step_data.get("warnings", []),
                artifacts=step_data.get("artifacts", [])
            )
    
    def reset(self):
        """Reset state to initial"""
        self.__init__()
    
    def get_summary(self) -> Dict[str, Any]:
        """Get complete state summary"""
        return {
            "session": {
                "id": self.session_id,
                "start_time": self.session_start.isoformat(),
                "duration": (datetime.now() - self.session_start).total_seconds()
            },
            "workflow": self.get_workflow_progress(),
            "configuration": self.configuration,
            "test_statistics": {
                "total_test_cases": len(self.test_cases),
                "total_scripts": len(self.generated_scripts),
                "total_executed": len(self.execution_results),
                "passed": sum(1 for r in self.execution_results if r.get("status") == "passed"),
                "failed": sum(1 for r in self.execution_results if r.get("status") == "failed")
            },
            "artifacts": {
                step.value: self.steps_state[step].artifacts 
                for step in self.steps_state
            }
        }


# Singleton instance for Streamlit session state
_state_manager = None

def get_state_manager() -> StateManager:
    """Get or create state manager singleton"""
    global _state_manager
    if _state_manager is None:
        _state_manager = StateManager()
    return _state_manager