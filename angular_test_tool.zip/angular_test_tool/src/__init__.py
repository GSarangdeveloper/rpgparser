"""
Angular UI Testing Tool - Core Modules
"""

from .mcp_client import MCPClient, MCPTestExecutor, MCPCommandType
from .state_manager import StateManager, WorkflowStep, ApprovalStatus
from .test_parser import TestParser, TestCase, TestStep, TestAction
from .script_generator import ScriptGenerator, ScriptTemplate
from .allure_reporter import AllureReporter

# Import GitManager with error handling
try:
    from .git_manager import GitManager
    GIT_MANAGER_AVAILABLE = True
except ImportError:
    GitManager = None
    GIT_MANAGER_AVAILABLE = False

__version__ = "1.0.0"
__author__ = "Angular Testing Team"

__all__ = [
    'MCPClient',
    'MCPTestExecutor',
    'MCPCommandType',
    'StateManager',
    'WorkflowStep',
    'ApprovalStatus',
    'TestParser',
    'TestCase',
    'TestStep',
    'TestAction',
    'ScriptGenerator',
    'ScriptTemplate',
    'AllureReporter'
]

# Add GitManager to __all__ if available
if GIT_MANAGER_AVAILABLE:
    __all__.append('GitManager')