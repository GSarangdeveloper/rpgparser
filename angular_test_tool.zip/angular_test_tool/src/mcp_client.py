"""
MCP Server Client for Playwright Integration
Handles communication with MCP server for browser automation
"""

import asyncio
import websockets
import json
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from enum import Enum
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class MCPCommandType(Enum):
    """MCP command types for Playwright operations"""
    BROWSER_LAUNCH = "browser.launch"
    BROWSER_CLOSE = "browser.close"
    PAGE_NAVIGATE = "page.goto"
    PAGE_CLICK = "page.click"
    PAGE_TYPE = "page.type"
    PAGE_SELECT = "page.select"
    PAGE_WAIT = "page.wait"
    PAGE_SCREENSHOT = "page.screenshot"
    PAGE_EVALUATE = "page.evaluate"
    ELEMENT_WAIT = "element.wait"
    ELEMENT_GET_TEXT = "element.getText"
    ELEMENT_GET_ATTRIBUTE = "element.getAttribute"
    ASSERT_VISIBLE = "assert.visible"
    ASSERT_TEXT = "assert.text"
    ASSERT_URL = "assert.url"
    NETWORK_MONITOR = "network.monitor"
    CONSOLE_MONITOR = "console.monitor"


@dataclass
class MCPRequest:
    """MCP request structure"""
    id: str
    method: str
    params: Dict[str, Any]
    timeout: int = 30000


@dataclass
class MCPResponse:
    """MCP response structure"""
    id: str
    success: bool
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    timestamp: str = None


class MCPClient:
    """Client for communicating with MCP Playwright server"""
    
    def __init__(self, host: str = "localhost", port: int = 3000, path: str = "/mcp/playwright"):
        self.host = host
        self.port = port
        self.path = path
        self.uri = f"ws://{host}:{port}{path}"
        self.websocket = None
        self.request_counter = 0
        self.browser_context = None
        self.page_context = None
        self.network_logs = []
        self.console_logs = []
        
    async def connect(self) -> bool:
        """Establish connection to MCP server"""
        try:
            self.websocket = await websockets.connect(self.uri)
            logger.info(f"Connected to MCP server at {self.uri}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to MCP server: {e}")
            return False
    
    async def disconnect(self):
        """Close connection to MCP server"""
        if self.websocket:
            await self.websocket.close()
            logger.info("Disconnected from MCP server")
    
    async def send_command(self, command_type: MCPCommandType, params: Dict[str, Any], 
                          timeout: int = 30000) -> MCPResponse:
        """Send command to MCP server and wait for response"""
        if not self.websocket:
            return MCPResponse(
                id="", 
                success=False, 
                error="Not connected to MCP server"
            )
        
        self.request_counter += 1
        request = MCPRequest(
            id=f"req_{self.request_counter}",
            method=command_type.value,
            params=params,
            timeout=timeout
        )
        
        try:
            # Send request
            await self.websocket.send(json.dumps({
                "id": request.id,
                "method": request.method,
                "params": request.params,
                "timeout": request.timeout
            }))
            
            # Wait for response with timeout
            response_text = await asyncio.wait_for(
                self.websocket.recv(),
                timeout=timeout / 1000
            )
            
            response_data = json.loads(response_text)
            
            return MCPResponse(
                id=response_data.get("id"),
                success=response_data.get("success", False),
                result=response_data.get("result"),
                error=response_data.get("error"),
                timestamp=datetime.now().isoformat()
            )
            
        except asyncio.TimeoutError:
            return MCPResponse(
                id=request.id,
                success=False,
                error=f"Command timed out after {timeout}ms"
            )
        except Exception as e:
            return MCPResponse(
                id=request.id,
                success=False,
                error=str(e)
            )
    
    async def launch_browser(self, browser_type: str = "chromium", 
                           headless: bool = False, 
                           viewport: Dict[str, int] = None) -> MCPResponse:
        """Launch browser instance"""
        params = {
            "browserType": browser_type,
            "options": {
                "headless": headless,
                "viewport": viewport or {"width": 1920, "height": 1080}
            }
        }
        
        response = await self.send_command(MCPCommandType.BROWSER_LAUNCH, params)
        if response.success and response.result:
            self.browser_context = response.result.get("contextId")
        
        return response
    
    async def navigate_to(self, url: str, wait_until: str = "networkidle") -> MCPResponse:
        """Navigate to URL"""
        params = {
            "url": url,
            "options": {
                "waitUntil": wait_until
            }
        }
        
        response = await self.send_command(MCPCommandType.PAGE_NAVIGATE, params)
        if response.success and response.result:
            self.page_context = response.result.get("pageId")
        
        return response
    
    async def click_element(self, selector: str, options: Dict[str, Any] = None) -> MCPResponse:
        """Click on element"""
        params = {
            "selector": selector,
            "options": options or {}
        }
        
        return await self.send_command(MCPCommandType.PAGE_CLICK, params)
    
    async def type_text(self, selector: str, text: str, delay: int = 0) -> MCPResponse:
        """Type text into element"""
        params = {
            "selector": selector,
            "text": text,
            "options": {
                "delay": delay
            }
        }
        
        return await self.send_command(MCPCommandType.PAGE_TYPE, params)
    
    async def select_option(self, selector: str, value: str) -> MCPResponse:
        """Select dropdown option"""
        params = {
            "selector": selector,
            "value": value
        }
        
        return await self.send_command(MCPCommandType.PAGE_SELECT, params)
    
    async def wait_for_selector(self, selector: str, state: str = "visible", 
                               timeout: int = 30000) -> MCPResponse:
        """Wait for element to appear"""
        params = {
            "selector": selector,
            "options": {
                "state": state,
                "timeout": timeout
            }
        }
        
        return await self.send_command(MCPCommandType.ELEMENT_WAIT, params, timeout)
    
    async def get_text(self, selector: str) -> MCPResponse:
        """Get text content of element"""
        params = {"selector": selector}
        return await self.send_command(MCPCommandType.ELEMENT_GET_TEXT, params)
    
    async def get_attribute(self, selector: str, attribute: str) -> MCPResponse:
        """Get attribute value of element"""
        params = {
            "selector": selector,
            "attribute": attribute
        }
        
        return await self.send_command(MCPCommandType.ELEMENT_GET_ATTRIBUTE, params)
    
    async def take_screenshot(self, path: str = None, full_page: bool = False) -> MCPResponse:
        """Take screenshot"""
        params = {
            "options": {
                "path": path,
                "fullPage": full_page
            }
        }
        
        return await self.send_command(MCPCommandType.PAGE_SCREENSHOT, params)
    
    async def assert_element_visible(self, selector: str) -> MCPResponse:
        """Assert element is visible"""
        params = {"selector": selector}
        return await self.send_command(MCPCommandType.ASSERT_VISIBLE, params)
    
    async def assert_text_content(self, selector: str, expected_text: str) -> MCPResponse:
        """Assert element contains text"""
        params = {
            "selector": selector,
            "expectedText": expected_text
        }
        
        return await self.send_command(MCPCommandType.ASSERT_TEXT, params)
    
    async def assert_url(self, expected_url: str, exact: bool = False) -> MCPResponse:
        """Assert current URL"""
        params = {
            "expectedUrl": expected_url,
            "exact": exact
        }
        
        return await self.send_command(MCPCommandType.ASSERT_URL, params)
    
    async def evaluate_script(self, script: str) -> MCPResponse:
        """Execute JavaScript in page context"""
        params = {"script": script}
        return await self.send_command(MCPCommandType.PAGE_EVALUATE, params)
    
    async def start_network_monitoring(self) -> MCPResponse:
        """Start monitoring network traffic"""
        params = {"enable": True}
        response = await self.send_command(MCPCommandType.NETWORK_MONITOR, params)
        
        if response.success:
            self.network_logs = []
        
        return response
    
    async def start_console_monitoring(self) -> MCPResponse:
        """Start monitoring console logs"""
        params = {"enable": True}
        response = await self.send_command(MCPCommandType.CONSOLE_MONITOR, params)
        
        if response.success:
            self.console_logs = []
        
        return response
    
    async def close_browser(self) -> MCPResponse:
        """Close browser instance"""
        response = await self.send_command(MCPCommandType.BROWSER_CLOSE, {})
        
        if response.success:
            self.browser_context = None
            self.page_context = None
        
        return response
    
    async def execute_test_step(self, step: Dict[str, Any]) -> MCPResponse:
        """Execute a single test step"""
        action = step.get("action")
        selector = step.get("selector")
        data = step.get("data")
        
        if action == "navigate":
            return await self.navigate_to(data)
        elif action == "click":
            return await self.click_element(selector)
        elif action == "type":
            return await self.type_text(selector, data)
        elif action == "select":
            return await self.select_option(selector, data)
        elif action == "wait":
            return await self.wait_for_selector(selector)
        elif action == "assert_visible":
            return await self.assert_element_visible(selector)
        elif action == "assert_text":
            return await self.assert_text_content(selector, data)
        elif action == "assert_url":
            return await self.assert_url(data)
        elif action == "screenshot":
            return await self.take_screenshot(data)
        else:
            return MCPResponse(
                id="",
                success=False,
                error=f"Unknown action: {action}"
            )
    
    def get_network_logs(self) -> List[Dict[str, Any]]:
        """Get collected network logs"""
        return self.network_logs
    
    def get_console_logs(self) -> List[Dict[str, Any]]:
        """Get collected console logs"""
        return self.console_logs


class MCPTestExecutor:
    """High-level test executor using MCP client"""
    
    def __init__(self, mcp_client: MCPClient):
        self.client = mcp_client
        self.test_results = []
        self.current_test = None
        
    async def setup(self, config: Dict[str, Any]) -> bool:
        """Setup test environment"""
        # Connect to MCP server
        connected = await self.client.connect()
        if not connected:
            return False
        
        # Launch browser
        browser_response = await self.client.launch_browser(
            browser_type=config.get("browser", "chromium"),
            headless=config.get("headless", False),
            viewport=config.get("viewport")
        )
        
        if not browser_response.success:
            logger.error(f"Failed to launch browser: {browser_response.error}")
            return False
        
        # Start monitoring if enabled
        if config.get("network_monitoring", True):
            await self.client.start_network_monitoring()
        
        if config.get("console_monitoring", True):
            await self.client.start_console_monitoring()
        
        return True
    
    async def execute_test(self, test_case: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single test case"""
        self.current_test = test_case
        test_result = {
            "test_id": test_case.get("id"),
            "test_name": test_case.get("name"),
            "status": "running",
            "steps": [],
            "start_time": datetime.now().isoformat(),
            "errors": []
        }
        
        try:
            # Execute each test step
            for step_index, step in enumerate(test_case.get("steps", [])):
                step_result = {
                    "step_index": step_index,
                    "description": step.get("description"),
                    "action": step.get("action"),
                    "status": "running"
                }
                
                # Execute step through MCP
                response = await self.client.execute_test_step(step)
                
                if response.success:
                    step_result["status"] = "passed"
                    step_result["result"] = response.result
                else:
                    step_result["status"] = "failed"
                    step_result["error"] = response.error
                    test_result["errors"].append({
                        "step": step_index,
                        "error": response.error
                    })
                    
                    # Take screenshot on failure
                    screenshot_path = f"screenshots/failure_{test_case.get('id')}_{step_index}.png"
                    await self.client.take_screenshot(screenshot_path)
                    step_result["screenshot"] = screenshot_path
                
                test_result["steps"].append(step_result)
                
                # Stop on failure if configured
                if not response.success and test_case.get("stop_on_failure", True):
                    break
            
            # Determine overall test status
            if test_result["errors"]:
                test_result["status"] = "failed"
            else:
                test_result["status"] = "passed"
            
        except Exception as e:
            test_result["status"] = "error"
            test_result["errors"].append({
                "type": "execution_error",
                "message": str(e)
            })
        
        test_result["end_time"] = datetime.now().isoformat()
        self.test_results.append(test_result)
        
        return test_result
    
    async def teardown(self):
        """Cleanup test environment"""
        await self.client.close_browser()
        await self.client.disconnect()
    
    def get_results(self) -> List[Dict[str, Any]]:
        """Get all test results"""
        return self.test_results