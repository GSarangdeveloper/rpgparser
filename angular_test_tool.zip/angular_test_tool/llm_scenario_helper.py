#!/usr/bin/env python3
"""
LLM Test Scenario Helper
Generates prompts and validates LLM-generated test scenarios
"""

import csv
import pandas as pd
from pathlib import Path
from typing import List, Dict, Any, Tuple

class LLMScenarioHelper:
    """Helper for LLM-generated test scenarios"""
    
    def __init__(self):
        self.required_columns = ['test_id', 'test_name', 'action', 'selector']
        self.optional_columns = ['test_suite', 'description', 'priority', 
                               'input_data', 'expected_result', 'wait_condition']
        self.valid_actions = [
            'navigate', 'click', 'fill', 'select', 'hover', 'scroll',
            'assert_visible', 'assert_text', 'assert_url', 'assert_title',
            'assert_attribute', 'wait', 'refresh'
        ]
        self.valid_priorities = ['high', 'medium', 'low']
    
    def generate_prompt(self, app_name: str, app_url: str, scenarios: List[str],
                       selectors: Dict[str, str] = None) -> str:
        """Generate comprehensive LLM prompt for test scenario creation"""

        selectors_text = ""
        if selectors:
            selectors_text = "\nKNOWN SELECTORS (use these when possible):\n"
            for element, selector in selectors.items():
                selectors_text += f"- {element}: {selector}\n"

        prompt = f"""
# CONVERT ANY TEST SCENARIO TO ANGULAR UI TESTING TOOL FORMAT

You are a test automation expert. Convert the provided test scenarios into the EXACT CSV format required by the Angular UI Testing Tool.

## TARGET APPLICATION:
- **Application:** {app_name}
- **URL:** {app_url}
- **Framework:** Angular UI Testing Tool with Playwright automation

## REQUIRED CSV FORMAT (EXACT HEADERS):
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
```

## COLUMN SPECIFICATIONS:

### REQUIRED COLUMNS:
- **test_id**: TC001, TC002, etc. (REQUIRED on every row)
- **action**: {', '.join(self.valid_actions)}
- **selector**: CSS/XPath selector for target element

### CONDITIONAL COLUMNS:
- **test_name**: Only on FIRST row of each test case (leave empty on subsequent rows)
- **test_suite**: Group name (Authentication, Navigation, Forms, etc.)
- **description**: Only on FIRST row of each test case (leave empty on subsequent rows)
- **priority**: high, medium, low (only on first row)
- **input_data**: Data to enter (required for 'fill' actions)
- **expected_result**: What should happen after action
- **wait_condition**: Optional wait condition

## ACTION TYPES & USAGE:

### NAVIGATION ACTIONS:
- **navigate**: Go to URL (selector can be empty, put URL in input_data)
- **refresh**: Refresh current page
- **wait**: Wait for condition

### INTERACTION ACTIONS:
- **click**: Click button/link/element
- **fill**: Enter text in input field (requires input_data)
- **select**: Select dropdown option
- **hover**: Hover over element
- **scroll**: Scroll to element

### ASSERTION ACTIONS:
- **assert_visible**: Check element is visible
- **assert_text**: Check element contains specific text
- **assert_url**: Check current URL matches pattern
- **assert_title**: Check page title
- **assert_attribute**: Check element attribute value

## SELECTOR GUIDELINES:
- Use CSS selectors: `input[name="username"]`, `.login-button`, `#submit-btn`
- Be specific: `button.primary` not just `button`
- Use data attributes when available: `[data-testid="login-form"]`
- For text content: `text="Login"` or `//button[contains(text(), "Login")]`

## MULTI-STEP TEST FORMAT:
```csv
TC001,Login Test,Authentication,Test user login functionality,high,navigate,,{app_url},Page loads,
TC001,,,,,fill,input[name="username"],testuser,Username entered,
TC001,,,,,fill,input[name="password"],password123,Password entered,
TC001,,,,,click,button[type="submit"],,Login button clicked,
TC001,,,,,assert_visible,.welcome-message,,Login successful,
```

## CONVERSION RULES:

### FROM MANUAL STEPS TO AUTOMATION:
1. **"Open browser and go to..."** → `navigate` action
2. **"Click on..."** → `click` action with appropriate selector
3. **"Enter text..."** → `fill` action with input_data
4. **"Verify that..."** → `assert_visible`, `assert_text`, etc.
5. **"Select from dropdown..."** → `select` action
6. **"Check if element exists..."** → `assert_visible` action

### COMMON PATTERNS:
- **Login Flow**: navigate → fill username → fill password → click submit → assert success
- **Form Submission**: navigate → fill fields → click submit → assert confirmation
- **Navigation Test**: navigate → click links → assert page loads → assert content
- **Search Test**: navigate → fill search → click search → assert results

{selectors_text}

## SCENARIOS TO CONVERT:
{chr(10).join(f'{i+1}. {scenario}' for i, scenario in enumerate(scenarios))}

## OUTPUT REQUIREMENTS:
1. **Start with the exact CSV header row**
2. **Generate {len(scenarios)} complete test cases**
3. **Each test case should have 3-8 steps minimum**
4. **Include both positive and negative test scenarios**
5. **Use realistic selectors and test data**
6. **Ensure proper CSV formatting (no extra quotes, proper escaping)**

## EXAMPLE OUTPUT:
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
TC001,User Login Test,Authentication,Test successful user login,high,navigate,,{app_url},Page loads successfully,
TC001,,,,,fill,input[name="username"],validuser,Username entered,
TC001,,,,,fill,input[name="password"],validpass123,Password entered,
TC001,,,,,click,button.login-btn,,Login button clicked,
TC001,,,,,assert_visible,.dashboard,,Dashboard visible after login,
TC002,Invalid Login Test,Authentication,Test login with invalid credentials,medium,navigate,,{app_url},Page loads successfully,
TC002,,,,,fill,input[name="username"],invaliduser,Invalid username entered,
TC002,,,,,fill,input[name="password"],wrongpass,Invalid password entered,
TC002,,,,,click,button.login-btn,,Login button clicked,
TC002,,,,,assert_visible,.error-message,,Error message displayed,
```

Generate the complete CSV output now:
"""
        return prompt.strip()
    
    def validate_csv(self, csv_file: str) -> Tuple[bool, List[str], List[str]]:
        """Validate LLM-generated CSV file"""
        
        errors = []
        warnings = []
        
        try:
            # Check if file exists
            if not Path(csv_file).exists():
                errors.append(f"File not found: {csv_file}")
                return False, errors, warnings
            
            # Read CSV
            df = pd.read_csv(csv_file)
            
            # Check required columns
            missing_cols = [col for col in self.required_columns if col not in df.columns]
            if missing_cols:
                errors.append(f"Missing required columns: {missing_cols}")
            
            # Check for empty dataframe
            if df.empty:
                errors.append("CSV file is empty")
                return False, errors, warnings
            
            # Validate each row
            test_cases = {}
            
            for index, row in df.iterrows():
                row_num = index + 2  # +2 for header and 0-based index
                
                # Check test_id
                if pd.isna(row['test_id']) or str(row['test_id']).strip() == '':
                    errors.append(f"Row {row_num}: Missing test_id")
                    continue
                
                test_id = str(row['test_id']).strip()
                
                # Check action
                if pd.isna(row['action']) or str(row['action']).strip() == '':
                    errors.append(f"Row {row_num}: Missing action")
                    continue
                
                action = str(row['action']).strip()
                if action not in self.valid_actions:
                    errors.append(f"Row {row_num}: Invalid action '{action}'. Valid actions: {self.valid_actions}")
                
                # Check selector (required for most actions)
                if action != 'navigate' and (pd.isna(row['selector']) or str(row['selector']).strip() == ''):
                    errors.append(f"Row {row_num}: Missing selector for action '{action}'")
                
                # Check test_name logic
                if pd.notna(row['test_name']) and str(row['test_name']).strip() != '':
                    # This is a new test case
                    test_name = str(row['test_name']).strip()
                    if test_id in test_cases:
                        warnings.append(f"Row {row_num}: Test ID '{test_id}' already used")
                    test_cases[test_id] = test_name
                else:
                    # This is a continuation of existing test
                    if test_id not in test_cases:
                        errors.append(f"Row {row_num}: Test ID '{test_id}' not defined (missing test_name in first occurrence)")
                
                # Check priority
                if 'priority' in row and pd.notna(row['priority']):
                    priority = str(row['priority']).strip()
                    if priority and priority not in self.valid_priorities:
                        warnings.append(f"Row {row_num}: Invalid priority '{priority}'. Valid: {self.valid_priorities}")
                
                # Check input_data for fill actions
                if action == 'fill' and (pd.isna(row.get('input_data', '')) or str(row.get('input_data', '')).strip() == ''):
                    warnings.append(f"Row {row_num}: Fill action without input_data")
            
            # Summary
            if not errors:
                num_tests = len(test_cases)
                warnings.append(f"Validation passed: {num_tests} test cases found with {len(df)} total steps")
            
            return len(errors) == 0, errors, warnings
            
        except Exception as e:
            errors.append(f"Error reading CSV: {str(e)}")
            return False, errors, warnings
    
    def generate_sample_scenarios(self, app_type: str = "banking") -> Dict[str, Any]:
        """Generate sample scenarios for different app types"""
        
        samples = {
            "banking": {
                "app_name": "ParaBank",
                "app_url": "https://parabank.parasoft.com",
                "scenarios": [
                    "User login with valid credentials",
                    "User login with invalid credentials", 
                    "Navigate to account overview",
                    "Transfer funds between accounts",
                    "Pay bills functionality",
                    "User logout"
                ],
                "selectors": {
                    "username_field": "input[name='username']",
                    "password_field": "input[name='password']", 
                    "login_button": "input[value='Log In']",
                    "logout_link": "a[href*='logout']",
                    "account_overview": "#showOverview",
                    "transfer_funds": "a[href*='transfer']"
                }
            },
            "ecommerce": {
                "app_name": "Online Store",
                "app_url": "https://example-store.com",
                "scenarios": [
                    "User registration",
                    "Product search",
                    "Add product to cart",
                    "View shopping cart",
                    "Checkout process",
                    "User profile update"
                ],
                "selectors": {
                    "search_box": "input[name='search']",
                    "add_to_cart": "button.add-to-cart",
                    "cart_icon": ".cart-icon",
                    "checkout_button": "button.checkout",
                    "email_field": "input[type='email']"
                }
            },
            "social": {
                "app_name": "Social Media App", 
                "app_url": "https://social-app.com",
                "scenarios": [
                    "User login",
                    "Create new post",
                    "Like a post",
                    "Comment on post",
                    "Follow user",
                    "Update profile"
                ],
                "selectors": {
                    "post_textarea": "textarea.post-content",
                    "post_button": "button.post-submit",
                    "like_button": "button.like",
                    "comment_box": "input.comment-input",
                    "follow_button": "button.follow"
                }
            }
        }
        
        return samples.get(app_type, samples["banking"])

    def generate_universal_prompt(self, app_name: str, app_url: str,
                                 existing_scenarios: str = None) -> str:
        """Generate universal prompt to convert ANY test scenario format"""

        prompt = f"""
# UNIVERSAL TEST SCENARIO CONVERTER
## Convert ANY test format to Angular UI Testing Tool CSV format

You are an expert test automation engineer. Your task is to convert ANY existing test scenarios (manual test cases, user stories, acceptance criteria, etc.) into the EXACT CSV format required by the Angular UI Testing Tool.

## TARGET APPLICATION:
- **Name:** {app_name}
- **URL:** {app_url}
- **Tool:** Angular UI Testing Tool with Playwright automation

## REQUIRED OUTPUT FORMAT:
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
```

## CONVERSION INSTRUCTIONS:

### 1. ANALYZE INPUT SCENARIOS
Look for these patterns in ANY format:
- **Steps/Actions**: "Click", "Enter", "Navigate", "Verify", "Check"
- **Elements**: Buttons, inputs, links, forms, menus
- **Data**: Usernames, passwords, text inputs, selections
- **Expectations**: "Should see", "Verify", "Confirm", "Check"

### 2. MAP TO AUTOMATION ACTIONS
| Manual Step | Automation Action | Example |
|-------------|------------------|---------|
| "Go to page" | `navigate` | navigate,,{app_url} |
| "Click button" | `click` | click,button.submit |
| "Enter text" | `fill` | fill,input[name="email"],test@example.com |
| "Select option" | `select` | select,select[name="country"],USA |
| "Verify visible" | `assert_visible` | assert_visible,.success-message |
| "Check text" | `assert_text` | assert_text,h1,Welcome |

### 3. GENERATE REALISTIC SELECTORS
- **Inputs**: `input[name="username"]`, `input[type="email"]`, `#password`
- **Buttons**: `button.submit`, `input[type="submit"]`, `.btn-primary`
- **Links**: `a[href="/login"]`, `nav a`, `.menu-item`
- **Text**: `.error-message`, `.success-alert`, `h1`, `.title`
- **Forms**: `form.login`, `.registration-form`, `#contact-form`

### 4. CREATE TEST SUITES
Group related tests:
- **Authentication**: Login, logout, registration, password reset
- **Navigation**: Menu navigation, page routing, breadcrumbs
- **Forms**: Contact forms, registration, data entry
- **Search**: Search functionality, filters, results
- **E-commerce**: Cart, checkout, payments, orders
- **User Management**: Profile, settings, preferences

### 5. ASSIGN PRIORITIES
- **high**: Critical user flows (login, checkout, core features)
- **medium**: Important features (search, navigation, forms)
- **low**: Nice-to-have features (tooltips, animations, help)

## EXAMPLE CONVERSIONS:

### INPUT: Manual Test Case
```
Test: User Login
1. Open the application
2. Enter username "testuser"
3. Enter password "password123"
4. Click Login button
5. Verify user is logged in
```

### OUTPUT: CSV Format
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
TC001,User Login Test,Authentication,Test successful user login,high,navigate,,{app_url},Application opens,
TC001,,,,,fill,input[name="username"],testuser,Username entered,
TC001,,,,,fill,input[name="password"],password123,Password entered,
TC001,,,,,click,button.login,,Login button clicked,
TC001,,,,,assert_visible,.dashboard,,User dashboard visible,
```

### INPUT: User Story
```
As a user, I want to search for products so that I can find items to purchase.
Acceptance Criteria:
- User can enter search terms
- Search results are displayed
- User can filter results
```

### OUTPUT: CSV Format
```csv
test_id,test_name,test_suite,description,priority,action,selector,input_data,expected_result,wait_condition
TC002,Product Search Test,Search,Test product search functionality,high,navigate,,{app_url},Homepage loads,
TC002,,,,,fill,input[name="search"],"laptop",Search term entered,
TC002,,,,,click,button.search,,Search button clicked,
TC002,,,,,assert_visible,.search-results,,Search results displayed,
TC002,,,,,assert_text,.results-count,"results found",Results count shown,
```

## YOUR TASK:
Convert the following test scenarios to the required CSV format:

{existing_scenarios if existing_scenarios else "PASTE YOUR TEST SCENARIOS HERE"}

## OUTPUT REQUIREMENTS:
1. **Start with exact CSV header**
2. **Generate complete test cases** (3-8 steps each)
3. **Use realistic selectors** for the application type
4. **Include proper test data**
5. **Cover positive and negative scenarios**
6. **Ensure proper CSV formatting**

Generate the complete CSV output now:
"""
        return prompt.strip()

def main():
    """Demo the LLM scenario helper"""

    print("🤖 LLM Test Scenario Helper - Universal Converter")
    print("=" * 55)

    helper = LLMScenarioHelper()

    # Show menu options
    print("\n📋 Available Options:")
    print("1. 🎯 Generate specific app prompt (ParaBank example)")
    print("2. 🌐 Generate universal converter prompt")
    print("3. 🔍 Validate existing CSV file")

    choice = input("\nSelect option (1-3): ").strip()

    if choice == "1":
        # Generate sample prompt for specific app
        print("\n📝 Generating specific prompt for ParaBank...")
        sample = helper.generate_sample_scenarios("banking")

        prompt = helper.generate_prompt(
            app_name=sample["app_name"],
            app_url=sample["app_url"],
            scenarios=sample["scenarios"],
            selectors=sample["selectors"]
        )

        print("\n🎯 Generated Specific LLM Prompt:")
        print("-" * 40)
        print(prompt[:1000] + "..." if len(prompt) > 1000 else prompt)

    elif choice == "2":
        # Generate universal converter prompt
        print("\n🌐 Generating universal converter prompt...")

        app_name = input("Enter application name (or press Enter for 'My Application'): ").strip() or "My Application"
        app_url = input("Enter application URL (or press Enter for 'https://example.com'): ").strip() or "https://example.com"

        universal_prompt = helper.generate_universal_prompt(app_name, app_url)

        print(f"\n🎯 Universal Converter Prompt:")
        print("-" * 35)
        print(universal_prompt)

        # Save to file
        with open("universal_converter_prompt.txt", "w", encoding="utf-8") as f:
            f.write(universal_prompt)
        print(f"\n💾 Prompt saved to: universal_converter_prompt.txt")

    elif choice == "3":
        # Validate existing file
        csv_file = input("Enter CSV file path (or press Enter for 'parabank_tests_correct.csv'): ").strip() or "parabank_tests_correct.csv"

        print(f"\n🔍 Validating: {csv_file}")

        if Path(csv_file).exists():
            is_valid, errors, warnings = helper.validate_csv(csv_file)

            print(f"\n📊 Validation Results:")
            print(f"Valid: {'✅ Yes' if is_valid else '❌ No'}")

            if errors:
                print(f"\n❌ Errors ({len(errors)}):")
                for error in errors[:5]:  # Show first 5 errors
                    print(f"  - {error}")
                if len(errors) > 5:
                    print(f"  ... and {len(errors) - 5} more errors")

            if warnings:
                print(f"\n⚠️ Warnings ({len(warnings)}):")
                for warning in warnings[:5]:  # Show first 5 warnings
                    print(f"  - {warning}")
                if len(warnings) > 5:
                    print(f"  ... and {len(warnings) - 5} more warnings")
        else:
            print(f"❌ File not found: {csv_file}")

    else:
        print("❌ Invalid option selected")

    print(f"\n💡 Usage Tips:")
    print(f"1. Use the generated prompt with ChatGPT, Claude, or any LLM")
    print(f"2. Copy your existing test scenarios into the prompt")
    print(f"3. Save LLM output as CSV file")
    print(f"4. Validate with option 3 before using")
    print(f"5. Upload to Streamlit app if validation passes")

    print(f"\n🚀 Ready to convert ANY test scenario format to Angular UI Testing Tool format!")

if __name__ == "__main__":
    main()
