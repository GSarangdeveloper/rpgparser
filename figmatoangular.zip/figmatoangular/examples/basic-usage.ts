/**
 * Basic Usage Examples
 * Demonstrates how to use the Figma-to-Angular converter
 */

import { FigmaToAngularConverter, DEFAULT_CONFIG } from '../src/index';

/**
 * Example 1: Simple conversion with default settings
 */
async function example1_basicConversion() {
  console.log('=== Example 1: Basic Conversion ===\n');

  const converter = new FigmaToAngularConverter();

  const result = await converter.convert({
    figmaUrl: 'https://figma.com/file/YOUR_FILE_KEY/MyDesign?node-id=1:2',
    outputDir: './output/example1',
    ...DEFAULT_CONFIG,
  });

  if (result.success) {
    console.log('✅ Conversion successful!');
    console.log(`Generated ${result.generatedFiles.length} files`);
    console.log(`Conversion time: ${result.metadata.conversionTime}ms`);
  } else {
    console.error('❌ Conversion failed:', result.error);
  }
}

/**
 * Example 2: Custom Angular configuration
 */
async function example2_customAngularConfig() {
  console.log('\n=== Example 2: Custom Angular Configuration ===\n');

  const converter = new FigmaToAngularConverter();

  const result = await converter.convert({
    figmaUrl: 'https://figma.com/file/YOUR_FILE_KEY/MyDesign?node-id=1:2',
    outputDir: './output/example2',
    componentName: 'MyButton',
    angular: {
      selector: 'my-button',
      standalone: true,
      changeDetection: 'OnPush',
      styleEncapsulation: 'Emulated',
      generateTests: true,
      generateModule: false,
    },
    transformation: {
      reuseComponents: true,
      useDesignTokens: true,
      generateDocumentation: true,
      semanticHtml: true,
      accessibility: true,
    },
    assets: {
      downloadAssets: true,
      optimizeImages: true,
      inlineSvgs: true,
      assetPath: './assets',
    },
    validation: {
      visualComparison: true,
      compileCheck: true,
      lintCheck: false,
      accessibilityCheck: true,
      similarityThreshold: 95,
    },
  });

  console.log('Result:', result);
}

/**
 * Example 3: With design system integration
 */
async function example3_designSystemIntegration() {
  console.log('\n=== Example 3: Design System Integration ===\n');

  const converter = new FigmaToAngularConverter();

  const result = await converter.convert({
    figmaUrl: 'https://figma.com/file/YOUR_FILE_KEY/MyDesign?node-id=1:2',
    outputDir: './output/example3',
    componentName: 'CustomCard',
    angular: {
      standalone: true,
      changeDetection: 'OnPush',
    },
    transformation: {
      reuseComponents: true,
      useDesignTokens: true,
    },
    designSystem: {
      componentsPath: './src/app/shared/components',
      tokensPath: './src/styles/tokens.scss',
      codeConnectMappings: {
        'Button': 'ButtonComponent',
        'Card': 'CardComponent',
        'Input': 'InputComponent',
      },
    },
  });

  console.log('Result:', result);
}

/**
 * Example 4: Authentication flow
 */
async function example4_authentication() {
  console.log('\n=== Example 4: Authentication ===\n');

  const converter = new FigmaToAngularConverter();

  // Check if authenticated
  const isAuth = await converter.isAuthenticated();
  console.log('Authenticated:', isAuth);

  if (!isAuth) {
    console.log('Starting authentication...');
    await converter.authenticate();
    // User would need to complete OAuth flow in browser
  }

  // Now you can convert
  // const result = await converter.convert({ ... });
}

/**
 * Example 5: Batch conversion
 */
async function example5_batchConversion() {
  console.log('\n=== Example 5: Batch Conversion ===\n');

  const converter = new FigmaToAngularConverter();

  const components = [
    { url: 'https://figma.com/file/KEY/Design?node-id=1:2', name: 'Button' },
    { url: 'https://figma.com/file/KEY/Design?node-id=1:3', name: 'Card' },
    { url: 'https://figma.com/file/KEY/Design?node-id=1:4', name: 'Input' },
  ];

  for (const component of components) {
    console.log(`\nConverting ${component.name}...`);

    const result = await converter.convert({
      figmaUrl: component.url,
      componentName: component.name,
      outputDir: `./output/batch/${component.name}`,
      ...DEFAULT_CONFIG,
    });

    if (result.success) {
      console.log(`✅ ${component.name} converted successfully`);
    } else {
      console.error(`❌ ${component.name} failed:`, result.error);
    }
  }
}

/**
 * Example 6: Using manual access token
 */
async function example6_manualToken() {
  console.log('\n=== Example 6: Manual Access Token ===\n');

  const converter = new FigmaToAngularConverter();

  // Use a manually provided token (from .env or direct input)
  const result = await converter.convert({
    figmaUrl: 'https://figma.com/file/YOUR_FILE_KEY/MyDesign?node-id=1:2',
    figmaAccessToken: process.env.FIGMA_ACCESS_TOKEN,
    outputDir: './output/example6',
    ...DEFAULT_CONFIG,
  });

  console.log('Result:', result);
}

// Run examples
if (require.main === module) {
  (async () => {
    // Uncomment the example you want to run:

    // await example1_basicConversion();
    // await example2_customAngularConfig();
    // await example3_designSystemIntegration();
    // await example4_authentication();
    // await example5_batchConversion();
    // await example6_manualToken();

    console.log('\n✨ Examples complete!\n');
    console.log('Note: Replace YOUR_FILE_KEY with actual Figma file key');
    console.log('Set FIGMA_ACCESS_TOKEN in .env for authentication');
  })();
}

export {
  example1_basicConversion,
  example2_customAngularConfig,
  example3_designSystemIntegration,
  example4_authentication,
  example5_batchConversion,
  example6_manualToken,
};
