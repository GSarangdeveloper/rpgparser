# Figma-to-Angular Converter

[![CI](https://github.com/figma-to-angular/figma-to-angular/actions/workflows/ci.yml/badge.svg)](https://github.com/figma-to-angular/figma-to-angular/actions/workflows/ci.yml)
[![npm version](https://badge.fury.io/js/figma-to-angular.svg)](https://badge.fury.io/js/figma-to-angular)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Automated tool that converts Figma designs into production-ready Angular components using Figma's Remote MCP Server.**

---

## 🚀 Features

✨ **Intelligent Conversion**
- Converts React + Tailwind designs to Angular components
- Prioritizes component reuse over generation
- Maps design tokens automatically
- Handles complex layouts and interactions

🎨 **Design System Integration**
- Integrates with existing Angular component libraries
- Maps Figma variables to CSS custom properties
- Supports Code Connect mappings
- Generates BEM-style CSS

✅ **Quality Assurance**
- Visual comparison with pixel-perfect validation
- TypeScript compilation validation
- WCAG 2.1 AA accessibility compliance
- Comprehensive error reporting

🚀 **Developer Experience**
- Interactive CLI with progress tracking
- Standalone Angular components (v14+)
- OnPush change detection
- Production-ready code output

---

## 📋 Prerequisites

- **Node.js** 18+ LTS
- **Figma Account** (Pro/Org/Enterprise) with Dev or Full seat
- **Figma OAuth App** - Register at [Figma Developers](https://www.figma.com/developers/api)

---

## 🛠️ Installation

### Global Installation (Recommended)

```bash
npm install -g figma-to-angular
```

### Local Installation

```bash
npm install figma-to-angular --save-dev
```

### From Binary

Download the latest binary for your platform from the [releases page](https://github.com/figma-to-angular/figma-to-angular/releases):

- **Windows**: `figma-to-angular-win.exe`
- **macOS**: `figma-to-angular-macos`
- **Linux**: `figma-to-angular-linux`

### From Source

```bash
# Clone repository
git clone <repo-url>
cd figma-to-angular

# Install dependencies
npm install

# Build
npm run build

# Link globally
npm link
```

---

## ⚙️ Configuration

Create a `.env` file with your Figma OAuth credentials:

```env
FIGMA_CLIENT_ID=your_client_id_here
FIGMA_CLIENT_SECRET=your_client_secret_here
FIGMA_REDIRECT_URI=http://localhost:3000/callback

MCP_SERVER_URL=https://mcp.figma.com/mcp
PORT=3000
NODE_ENV=development
LOG_LEVEL=info
DEFAULT_OUTPUT_DIR=./output

# LLM Configuration (Optional - for AI-powered conversion)
LLM_PROVIDER=openai  # or 'anthropic' or 'azure'
LLM_API_KEY=your_api_key_here
LLM_MODEL=gpt-4-vision-preview  # or 'claude-3-sonnet' etc.
LLM_MAX_COST=1.00  # Maximum cost per conversion
CONVERSION_APPROACH=llm  # 'llm', 'rule-based', or 'hybrid'
```

---

## 🚦 Quick Start

### 1. Initialize Project

```bash
figma-to-angular init
```

This creates:
- `figma-to-angular.config.json` - Configuration file
- `output/` - Generated components directory
- `design-system/` - Design tokens directory

### 2. Authenticate with Figma

```bash
figma-to-angular auth
```

You'll need:
- Figma OAuth Client ID
- Figma OAuth Client Secret

Get these from your [Figma account settings](https://www.figma.com/developers/api#authentication).

### 3. Convert a Design

```bash
figma-to-angular convert --url <figma-url>
```

Or use interactive mode:

```bash
figma-to-angular convert
```

### CLI Commands

#### `convert`
Convert Figma designs to Angular components

```bash
figma-to-angular convert [options]

Options:
  -u, --url <url>         Figma file URL
  -n, --node <id>         Node ID to convert
  -o, --output <dir>      Output directory (default: ./output)
  -c, --config <path>     Path to config file
  --approach <type>       Conversion approach: 'llm', 'rule-based', 'hybrid' (default: llm)
  --no-validation         Skip validation
  --no-optimization       Skip asset optimization
  --llm-provider <name>   LLM provider: 'openai', 'anthropic', 'azure'
  --llm-model <name>      LLM model to use
```

#### `auth`
Authenticate with Figma

```bash
figma-to-angular auth
```

#### `config`
Generate a configuration file

```bash
figma-to-angular config [options]

Options:
  -o, --output <path>     Output path (default: ./figma-to-angular.config.json)
```

#### `validate`
Validate generated components

```bash
figma-to-angular validate [options]

Options:
  -d, --dir <directory>   Directory containing components
  --compilation           Run compilation validation only
  --accessibility         Run accessibility validation only
  --visual                Run visual validation only
```

---

## 📖 Usage

### Basic Conversion

```typescript
import { FigmaToAngularConverter } from './src/converter';

const converter = new FigmaToAngularConverter();

const result = await converter.convert({
  figmaUrl: 'https://figma.com/file/abc123/MyDesign?node-id=1:2',
  outputDir: './output',
  angular: {
    standalone: true,
    changeDetection: 'OnPush',
  },
  transformation: {
    reuseComponents: true,
    useDesignTokens: true,
    accessibility: true,
  },
  validation: {
    visualComparison: true,
    similarityThreshold: 90,
  },
});

console.log(result);
```

---

## 🏗️ Architecture

```
src/
├── auth/                 # OAuth 2.0 authentication
├── mcp/                  # MCP protocol client
│   ├── tools/           # MCP tools (get_code, get_screenshot, etc.)
│   └── models/          # Request/response models
├── figma/               # Figma URL parsing and processing
├── transform/           # React → Angular transformation
├── llm/                 # LLM-powered transformation (NEW)
│   ├── service/         # LLM service and orchestrator
│   ├── prompts/         # Conversion prompt templates
│   └── cost-tracker/    # Usage and cost tracking
├── codegen/             # Angular code generation
├── validation/          # Visual validation and quality checks
├── assets/              # Asset management
├── output/              # File output
├── design-system/       # Component/token registry
├── config/              # Configuration
└── shared/              # Shared utilities
```

---

## 🔄 MCP Tool Sequence

The tool follows Figma's recommended MCP tool calling sequence:

```
1. ✅ get_code (FIRST, REQUIRED)
   - Fetch structured React+Tailwind code
   - If truncated → get_metadata → re-fetch specific nodes

2. ✅ get_screenshot (SECOND, REQUIRED)
   - Get visual reference

⛔ CHECKPOINT: Must have both before proceeding

3. ✅ Download assets

4. ✅ Optional: get_variable_defs, get_code_connect_map
```

---

## 📏 Quality Rules

### Component Reuse (HIGHEST PRIORITY)
- Always check for existing components before generating new ones
- Use Code Connect mappings when available
- Map Figma components to design system components

### Design Token Integration (REQUIRED)
- Never hardcode colors, spacing, typography
- Extract and use design tokens from Figma variables
- Map to existing project tokens when available

### Accessibility (WCAG 2.1 AA REQUIRED)
- Semantic HTML5 elements
- ARIA attributes where needed
- Keyboard navigation support
- Color contrast validation

---

## 🤖 LLM-Powered Conversion (NEW)

The tool now supports AI-powered conversion using Large Language Models (LLMs) as an alternative to rule-based transformation. This approach offers several advantages:

### Benefits of LLM Approach

✅ **Simpler Architecture**: 50% less code to maintain
✅ **Better Quality**: Handles edge cases naturally
✅ **Faster Development**: No need to build complex parsers
✅ **Easy Updates**: Update prompts instead of code
✅ **Context Aware**: Understands design intent better

### Supported Providers

- **OpenAI**: GPT-4, GPT-4 Vision, GPT-3.5 Turbo
- **Anthropic**: Claude 3 Opus, Sonnet, Haiku
- **Azure OpenAI**: Enterprise deployments

### Configuration

```javascript
// figma-to-angular.config.json
{
  "conversion": {
    "approach": "llm",  // or "rule-based" or "hybrid"
    "llm": {
      "provider": "openai",
      "model": "gpt-4-vision-preview",
      "temperature": 0.3,
      "maxCost": 1.00  // Per conversion limit
    }
  }
}
```

### Cost Tracking

The tool includes comprehensive cost tracking:

```bash
# View cost summary
figma-to-angular cost --summary

# Export cost data
figma-to-angular cost --export costs.csv

# Set limits
figma-to-angular cost --set-limit daily=10.00
```

### Conversion Examples

```typescript
// Using LLM approach
const result = await converter.convert({
  figmaUrl: 'https://figma.com/file/abc123/MyDesign',
  approach: 'llm',
  llmConfig: {
    provider: 'openai',
    model: 'gpt-4-vision-preview',
    temperature: 0.3
  }
});

// Hybrid approach (rules + LLM enhancement)
const result = await converter.convert({
  figmaUrl: 'https://figma.com/file/abc123/MyDesign',
  approach: 'hybrid'
});
```

### Prompt Templates

The LLM approach uses specialized prompts for different component types:

- **Forms**: Reactive forms with validation
- **Tables**: Data grids with sorting/filtering
- **Navigation**: Menus with routing
- **Cards**: Reusable card components
- **Modals**: Dialogs with accessibility
- **Charts**: Data visualizations
- **Layouts**: Responsive containers

### Quality Validation

LLM-generated code goes through comprehensive validation:

- **Syntax**: TypeScript compilation
- **Structure**: Angular best practices
- **Accessibility**: WCAG compliance
- **Performance**: OnPush, trackBy, etc.
- **Visual**: Screenshot comparison

### Cost Optimization Tips

1. **Use caching**: Avoid re-processing same designs
2. **Choose appropriate models**: Use cheaper models for simple components
3. **Batch processing**: Convert multiple components together
4. **Set limits**: Configure daily/monthly cost limits

---

## 🧪 Testing

```bash
# Run all tests
npm test

# Watch mode
npm run test:watch

# Coverage report
npm run test:coverage
```

**Target: 80%+ coverage**

---

## 📊 Success Metrics

### Technical Metrics
- ✅ Visual fidelity: >90% average
- ✅ Compilation success: >95%
- ✅ Component reuse rate: >60%
- ✅ Test coverage: >80%

### Performance
- ✅ Small component: <5 seconds
- ✅ Medium component: <15 seconds
- ✅ Large component: <30 seconds

---

## 🐛 Troubleshooting

### Authentication Issues
```bash
# Clear cached tokens
rm -rf ~/.figma-to-angular/tokens.enc

# Re-authenticate
npm run dev
```

### MCP Errors
- Ensure valid Figma access token
- Check network connectivity
- Verify file/node permissions

### Visual Validation Issues
- Ensure Puppeteer dependencies installed
- Check screenshot quality settings
- Verify output directory permissions

---

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

---

## 📝 License

MIT License - see LICENSE file for details

---

## 🔗 Resources

- [Figma MCP Server Docs](https://developers.figma.com/docs/figma-mcp-server/)
- [Figma API](https://www.figma.com/developers/api)
- [Angular Style Guide](https://angular.io/guide/styleguide)
- [WCAG Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)

---

## 📞 Support

- GitHub Issues: [Report bugs or request features]
- Documentation: [Full documentation site]
- Email: support@figma2angular.dev

---

**Built with ❤️ for the Angular community**
