/**
 * File Writer Service
 * Handles writing generated files to disk
 */

import * as path from 'path';
import * as prettier from 'prettier';
import { logger } from '../shared/utils/logger.service';
import { FileUtils } from '../shared/utils/file.utils';
import { GeneratedFile } from '../shared/models/conversion-result.model';

export class FileWriterService {
  /**
   * Write a single file
   */
  async writeFile(filePath: string, content: string, format: boolean = true): Promise<void> {
    try {
      // Ensure directory exists
      const dir = path.dirname(filePath);
      await FileUtils.ensureDir(dir);

      // Format content if requested
      let finalContent = content;
      if (format) {
        finalContent = await this.formatContent(filePath, content);
      }

      // Write file
      await FileUtils.writeFile(filePath, finalContent);
      logger.success(`File written: ${filePath}`);
    } catch (error) {
      logger.error(`Failed to write file: ${filePath}`, error);
      throw error;
    }
  }

  /**
   * Write multiple files
   */
  async writeFiles(files: GeneratedFile[]): Promise<void> {
    logger.info(`Writing ${files.length} files...`);

    for (const file of files) {
      await this.writeFile(file.path, file.content, true);
    }

    logger.success(`All files written successfully`);
  }

  /**
   * Format content with Prettier
   */
  private async formatContent(filePath: string, content: string): Promise<string> {
    try {
      const ext = path.extname(filePath);
      let parser: prettier.BuiltInParserName | undefined;

      switch (ext) {
        case '.ts':
          parser = 'typescript';
          break;
        case '.html':
          parser = 'angular';
          break;
        case '.scss':
        case '.css':
          parser = 'scss';
          break;
        case '.json':
          parser = 'json';
          break;
        default:
          return content; // Don't format unknown types
      }

      const formatted = prettier.format(content, {
        parser,
        printWidth: 100,
        tabWidth: 2,
        useTabs: false,
        semi: true,
        singleQuote: true,
        trailingComma: 'es5',
        bracketSpacing: true,
        arrowParens: 'always',
      });

      return formatted;
    } catch (error) {
      logger.warn(`Failed to format file: ${filePath}`, error);
      return content; // Return unformatted on error
    }
  }

  /**
   * Create component directory structure
   */
  async createComponentDirectory(
    basePath: string,
    componentName: string
  ): Promise<string> {
    const kebabName = componentName
      .replace(/Component$/, '')
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .toLowerCase();

    const componentDir = path.join(basePath, kebabName);
    await FileUtils.ensureDir(componentDir);

    logger.debug(`Created component directory: ${componentDir}`);
    return componentDir;
  }

  /**
   * Generate README for component
   */
  generateComponentReadme(
    componentName: string,
    inputs: string[],
    outputs: string[],
    description?: string
  ): string {
    const lines: string[] = [
      `# ${componentName}`,
      '',
      description || 'Component generated from Figma design.',
      '',
      '## Usage',
      '',
      '```typescript',
      `import { ${componentName} } from './path-to-component';`,
      '```',
      '',
      '```html',
      `<app-${this.toKebabCase(componentName)}>`,
      '</app->',
      '```',
      '',
    ];

    if (inputs.length > 0) {
      lines.push('## Inputs', '');
      for (const input of inputs) {
        lines.push(`- \`${input}\`: any`);
      }
      lines.push('');
    }

    if (outputs.length > 0) {
      lines.push('## Outputs', '');
      for (const output of outputs) {
        lines.push(`- \`${output}\`: EventEmitter<any>`);
      }
      lines.push('');
    }

    lines.push('## Generated', '');
    lines.push(`Generated on: ${new Date().toISOString()}`);
    lines.push('Generator: Figma-to-Angular Converter');

    return lines.join('\n');
  }

  /**
   * Convert to kebab-case
   */
  private toKebabCase(str: string): string {
    return str
      .replace(/Component$/, '')
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .toLowerCase();
  }

  /**
   * Check if file exists
   */
  async fileExists(filePath: string): Promise<boolean> {
    return FileUtils.fileExists(filePath);
  }

  /**
   * Backup existing file before overwriting
   */
  async backupFile(filePath: string): Promise<void> {
    if (await this.fileExists(filePath)) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = `${filePath}.backup.${timestamp}`;
      await FileUtils.copyFile(filePath, backupPath);
      logger.info(`Backed up existing file: ${backupPath}`);
    }
  }
}
