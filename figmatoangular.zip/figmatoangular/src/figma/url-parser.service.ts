/**
 * Figma URL Parser
 * Parses Figma URLs to extract file keys and node IDs
 */

import { logger } from '../shared/utils/logger.service';

export interface ParsedFigmaUrl {
  fileKey: string;
  nodeId?: string;
  isValid: boolean;
  url: string;
}

export class FigmaUrlParser {
  /**
   * Parse Figma URL
   * Supports formats:
   * - https://www.figma.com/file/{file_key}/{title}
   * - https://www.figma.com/file/{file_key}/{title}?node-id={node_id}
   * - https://www.figma.com/design/{file_key}/{title}?node-id={node_id}
   */
  static parse(url: string): ParsedFigmaUrl {
    try {
      logger.debug(`Parsing Figma URL: ${url}`);

      const urlObj = new URL(url);

      // Validate domain
      if (!urlObj.hostname.includes('figma.com')) {
        logger.error('Invalid Figma URL: not from figma.com domain');
        return { fileKey: '', isValid: false, url };
      }

      // Extract file key from path
      // Path format: /file/{file_key}/... or /design/{file_key}/...
      const pathMatch = urlObj.pathname.match(/\/(file|design)\/([a-zA-Z0-9]+)/);
      if (!pathMatch) {
        logger.error('Invalid Figma URL: could not extract file key');
        return { fileKey: '', isValid: false, url };
      }

      const fileKey = pathMatch[2];

      // Extract node ID from query params
      const nodeId = urlObj.searchParams.get('node-id') || undefined;

      // Convert node-id format from "123-456" to "123:456" if needed
      const formattedNodeId = nodeId ? nodeId.replace(/-/g, ':') : undefined;

      logger.success(`Parsed Figma URL - File: ${fileKey}, Node: ${formattedNodeId || 'N/A'}`);

      return {
        fileKey,
        nodeId: formattedNodeId,
        isValid: true,
        url,
      };
    } catch (error) {
      logger.error('Failed to parse Figma URL', error);
      return { fileKey: '', isValid: false, url };
    }
  }

  /**
   * Validate Figma URL
   */
  static isValid(url: string): boolean {
    const parsed = this.parse(url);
    return parsed.isValid && !!parsed.fileKey;
  }

  /**
   * Extract file key only
   */
  static extractFileKey(url: string): string | null {
    const parsed = this.parse(url);
    return parsed.isValid ? parsed.fileKey : null;
  }

  /**
   * Extract node ID only
   */
  static extractNodeId(url: string): string | null {
    const parsed = this.parse(url);
    return parsed.nodeId || null;
  }
}
