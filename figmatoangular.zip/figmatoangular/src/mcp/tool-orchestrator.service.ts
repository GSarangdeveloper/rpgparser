/**
 * Tool Orchestrator Service
 * Coordinates MCP tool calls in the correct sequence
 */

import { McpClientService } from './mcp-client.service';
import { GetCodeTool } from './tools/get-code.tool';
import { GetScreenshotTool } from './tools/get-screenshot.tool';
import { GetMetadataTool } from './tools/get-metadata.tool';
import { GetVariableDefsTool } from './tools/get-variable-defs.tool';
import { logger } from '../shared/utils/logger.service';

export interface FigmaNodeData {
  fileKey: string;
  nodeId: string;
  code: string;
  screenshotPath: string;
  designTokens?: any;
  metadata?: any;
}

export class ToolOrchestratorService {
  private getCodeTool: GetCodeTool;
  private getScreenshotTool: GetScreenshotTool;
  private getMetadataTool: GetMetadataTool;
  private getVariableDefsTool: GetVariableDefsTool;
  // private mcpClient: McpClientService; // Stored but not used directly

  constructor(mcpClient: McpClientService) {
    // this.mcpClient = mcpClient; // Commented out as it's not used
    this.getCodeTool = new GetCodeTool(mcpClient);
    this.getScreenshotTool = new GetScreenshotTool(mcpClient);
    this.getMetadataTool = new GetMetadataTool(mcpClient);
    this.getVariableDefsTool = new GetVariableDefsTool(mcpClient);
  }

  /**
   * Execute the MANDATORY tool sequence
   * 1. get_code (FIRST, REQUIRED)
   * 2. get_screenshot (SECOND, REQUIRED)
   * ⛔ CHECKPOINT: Must have both before proceeding
   * 3. Optional: get_variable_defs, get_code_connect_map
   */
  async fetchNodeData(
    fileKey: string,
    nodeId: string,
    outputDir: string
  ): Promise<FigmaNodeData> {
    logger.group('🔄 Starting MCP Tool Sequence');

    try {
      // STEP 1: Get Code (PRIMARY - MUST BE FIRST)
      logger.info('Step 1/2: Calling get_code (PRIMARY)');
      const codeResult = await this.getCodeTool.execute({
        file_key: fileKey,
        node_id: nodeId,
      });

      // Check if truncated
      if (this.getCodeTool.isTruncated(codeResult)) {
        logger.warn('⚠️  Code response truncated - fetching metadata');
        const metadataResult = await this.getMetadataTool.execute({ file_key: fileKey });
        const nodeIds = this.getMetadataTool.parseNodeIds(metadataResult.xml);
        logger.info(`Found ${nodeIds.length} nodes - re-fetching specific node`);

        // Re-fetch with specific node
        const retryResult = await this.getCodeTool.execute({
          file_key: fileKey,
          node_id: nodeId,
        });

        if (this.getCodeTool.isTruncated(retryResult)) {
          throw new Error('Code still truncated after metadata fallback');
        }

        Object.assign(codeResult, retryResult);
      }

      logger.success('✅ Step 1/2: Code retrieved');

      // STEP 2: Get Screenshot (REQUIRED - MUST BE SECOND)
      logger.info('Step 2/2: Calling get_screenshot (REQUIRED)');
      const screenshotResult = await this.getScreenshotTool.execute({
        file_key: fileKey,
        node_id: nodeId,
        scale: 2,
      });

      const screenshotPath = await this.getScreenshotTool.saveScreenshot(
        screenshotResult,
        outputDir,
        `${nodeId}-figma`
      );

      logger.success('✅ Step 2/2: Screenshot retrieved');

      // ⛔ CHECKPOINT: Both required tools complete
      logger.success('✅ CHECKPOINT PASSED: Both get_code and get_screenshot complete');

      // STEP 3: Optional - Get Design Tokens
      let designTokens;
      try {
        logger.info('Step 3: Calling get_variable_defs (OPTIONAL)');
        const variablesResult = await this.getVariableDefsTool.execute({ file_key: fileKey });
        designTokens = this.getVariableDefsTool.toCssVariables(variablesResult.variables);
        logger.success('✅ Design tokens retrieved');
      } catch (error) {
        logger.warn('Failed to get design tokens (non-critical)', error);
      }

      logger.groupEnd();

      return {
        fileKey,
        nodeId,
        code: codeResult.code,
        screenshotPath,
        designTokens,
      };
    } catch (error) {
      logger.groupEnd();
      logger.error('❌ MCP Tool Sequence Failed', error);
      throw error;
    }
  }

  /**
   * Verify checkpoint - ensure both required tools were called
   */
  private _verifyCheckpoint(_hasCode: boolean, _hasScreenshot: boolean): void {
    if (!_hasCode || !_hasScreenshot) {
      const missing = [];
      if (!_hasCode) missing.push('get_code');
      if (!_hasScreenshot) missing.push('get_screenshot');

      throw new Error(
        `⛔ CHECKPOINT FAILED: Missing required tools: ${missing.join(', ')}`
      );
    }
  }
}
