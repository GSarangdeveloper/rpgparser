/**
 * MCP Client Service
 * Implements the Model Context Protocol client for Figma
 */

import axios, { AxiosInstance } from 'axios';
import { logger } from '../shared/utils/logger.service';
import { MCP_CONFIG, MCP_TIMEOUTS, MCP_ERRORS } from '../shared/constants/mcp-constants';
import { McpRequest, McpResponse } from './models';

export class McpClientService {
  private httpClient: AxiosInstance;
  private requestId: number = 1;
  private accessToken: string;

  constructor(accessToken: string) {
    this.accessToken = accessToken;
    this.httpClient = axios.create({
      baseURL: MCP_CONFIG.serverUrl,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      timeout: MCP_TIMEOUTS.DEFAULT,
    });

    logger.info('MCP Client initialized');
  }

  /**
   * Make a JSON-RPC 2.0 request to MCP server
   */
  async call<T = any>(method: string, params?: Record<string, any>): Promise<T> {
    const request: McpRequest = {
      jsonrpc: '2.0',
      method,
      params,
      id: this.requestId++,
    };

    logger.debug(`MCP Request: ${method}`, params);

    try {
      const response = await this.httpClient.post<McpResponse<T>>('', request);

      if (response.data.error) {
        logger.error('MCP Error', response.data.error);
        throw new Error(`MCP Error: ${response.data.error.message}`);
      }

      if (!response.data.result) {
        throw new Error('MCP returned no result');
      }

      logger.debug(`MCP Response: ${method}`, response.data.result);
      return response.data.result;
    } catch (error: any) {
      if (error.response?.status === 401) {
        logger.error('MCP Authentication failed');
        throw new Error(MCP_ERRORS.AUTHENTICATION_FAILED);
      }

      if (error.response?.status === 404) {
        logger.error('MCP Tool not found');
        throw new Error(MCP_ERRORS.TOOL_NOT_FOUND);
      }

      if (error.code === 'ECONNABORTED') {
        logger.error('MCP Request timeout');
        throw new Error(MCP_ERRORS.TIMEOUT);
      }

      logger.error('MCP Request failed', error);
      throw error;
    }
  }

  /**
   * Update access token
   */
  setAccessToken(token: string): void {
    this.accessToken = token;
    this.httpClient.defaults.headers.Authorization = `Bearer ${token}`;
    logger.debug('MCP access token updated');
  }
}
