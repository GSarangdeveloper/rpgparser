/**
 * MCP Request Models
 */

export interface McpRequest {
  jsonrpc: '2.0';
  method: string;
  params?: Record<string, any>;
  id: string | number;
}

export interface GetCodeParams {
  file_key: string;
  node_id: string;
}

export interface GetScreenshotParams {
  file_key: string;
  node_id: string;
  scale?: number;
}

export interface GetMetadataParams {
  file_key: string;
  node_id?: string;
}

export interface GetVariableDefsParams {
  file_key: string;
}

export interface GetCodeConnectMapParams {
  file_key: string;
}
