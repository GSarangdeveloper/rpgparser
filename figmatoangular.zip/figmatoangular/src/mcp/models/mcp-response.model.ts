/**
 * MCP Response Models
 */

export interface McpResponse<T = any> {
  jsonrpc: '2.0';
  result?: T;
  error?: McpError;
  id: string | number;
}

export interface McpError {
  code: number;
  message: string;
  data?: any;
}

export interface GetCodeResult {
  code: string; // React + Tailwind code
  truncated?: boolean;
  node_info?: {
    id: string;
    name: string;
    type: string;
  };
}

export interface GetScreenshotResult {
  image: string; // Base64 encoded image
  format: 'png' | 'jpg';
  width: number;
  height: number;
}

export interface GetMetadataResult {
  xml: string; // XML representation of node structure
  truncated?: boolean;
}

export interface DesignToken {
  name: string;
  type: 'color' | 'number' | 'string';
  value: any;
  scopes?: string[];
}

export interface GetVariableDefsResult {
  variables: DesignToken[];
  collections: {
    id: string;
    name: string;
    modes: string[];
  }[];
}

export interface CodeConnectMapping {
  figma_node_id: string;
  component_path: string;
  props_mapping?: Record<string, string>;
}

export interface GetCodeConnectMapResult {
  mappings: CodeConnectMapping[];
}
