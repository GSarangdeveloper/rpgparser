/**
 * Get Code Tool
 * Fetches React + Tailwind code representation from Figma
 */

import { McpClientService } from '../mcp-client.service';
import { GetCodeParams } from '../models/mcp-request.model';
import { GetCodeResult } from '../models/mcp-response.model';
import { logger } from '../../shared/utils/logger.service';
import { MCP_TOOLS } from '../../shared/constants/mcp-constants';

export class GetCodeTool {
  constructor(private mcpClient: McpClientService) {}

  /**
   * Get code representation for a Figma node
   * This should ALWAYS be called FIRST
   */
  async execute(params: GetCodeParams): Promise<GetCodeResult> {
    logger.info(`Getting code for node: ${params.node_id}`);

    try {
      const result = await this.mcpClient.call<GetCodeResult>(MCP_TOOLS.GET_CODE.name, params);

      if (result.truncated) {
        logger.warn(
          'Response was truncated - consider using get_metadata to identify specific nodes'
        );
      }

      logger.success(`Code retrieved for node: ${params.node_id}`);
      return result;
    } catch (error) {
      logger.error('Failed to get code', error);
      throw error;
    }
  }

  /**
   * Check if response is truncated and needs metadata fallback
   */
  isTruncated(result: GetCodeResult): boolean {
    return result.truncated === true;
  }

  /**
   * Parse the React code to extract component structure
   */
  parseCode(code: string): {
    imports: string[];
    component: string;
    props: string[];
    jsx: string;
  } {
    // Simple regex-based parsing (will be improved with Babel parser later)
    const imports = code.match(/import .+ from ['"].+['"];/g) || [];
    const props =
      code.match(/(?:interface|type)\s+\w+Props\s*=\s*{([^}]+)}/)?.[1]?.split(';') || [];

    return {
      imports,
      component: code,
      props,
      jsx: code,
    };
  }
}
