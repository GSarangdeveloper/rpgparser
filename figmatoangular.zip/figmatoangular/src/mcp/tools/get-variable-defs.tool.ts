/**
 * Get Variable Definitions Tool
 * Extracts design tokens from Figma variables
 */

import { McpClientService } from '../mcp-client.service';
import { GetVariableDefsParams } from '../models/mcp-request.model';
import { GetVariableDefsResult, DesignToken } from '../models/mcp-response.model';
import { logger } from '../../shared/utils/logger.service';
import { MCP_TOOLS } from '../../shared/constants/mcp-constants';

export class GetVariableDefsTool {
  constructor(private mcpClient: McpClientService) {}

  /**
   * Get design tokens (variables) from Figma file
   */
  async execute(params: GetVariableDefsParams): Promise<GetVariableDefsResult> {
    logger.info(`Getting variable definitions for file: ${params.file_key}`);

    try {
      const result = await this.mcpClient.call<GetVariableDefsResult>(
        MCP_TOOLS.GET_VARIABLE_DEFS.name,
        params
      );

      logger.success(`Retrieved ${result.variables.length} design tokens`);
      return result;
    } catch (error) {
      logger.error('Failed to get variable definitions', error);
      throw error;
    }
  }

  /**
   * Organize tokens by type
   */
  organizeByType(variables: DesignToken[]): {
    colors: DesignToken[];
    spacing: DesignToken[];
    typography: DesignToken[];
    other: DesignToken[];
  } {
    const colors = variables.filter((v) => v.type === 'color');
    const spacing = variables.filter(
      (v) => v.type === 'number' && v.name.toLowerCase().includes('spacing')
    );
    const typography = variables.filter(
      (v) => v.type === 'string' && v.name.toLowerCase().includes('font')
    );
    const other = variables.filter(
      (v) => !colors.includes(v) && !spacing.includes(v) && !typography.includes(v)
    );

    return { colors, spacing, typography, other };
  }

  /**
   * Convert Figma tokens to CSS custom properties
   */
  toCssVariables(variables: DesignToken[]): Record<string, string> {
    const cssVars: Record<string, string> = {};

    for (const variable of variables) {
      const name = this.sanitizeVariableName(variable.name);
      const value = this.formatValue(variable);
      cssVars[`--${name}`] = value;
    }

    return cssVars;
  }

  /**
   * Sanitize variable name for CSS
   */
  private sanitizeVariableName(name: string): string {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  }

  /**
   * Format value based on type
   */
  private formatValue(variable: DesignToken): string {
    if (variable.type === 'color') {
      return this.formatColor(variable.value);
    }
    if (variable.type === 'number') {
      return `${variable.value}px`;
    }
    return String(variable.value);
  }

  /**
   * Format color value
   */
  private formatColor(value: any): string {
    if (typeof value === 'string') {
      return value;
    }
    if (value.r !== undefined && value.g !== undefined && value.b !== undefined) {
      const r = Math.round(value.r * 255);
      const g = Math.round(value.g * 255);
      const b = Math.round(value.b * 255);
      const a = value.a !== undefined ? value.a : 1;

      if (a < 1) {
        return `rgba(${r}, ${g}, ${b}, ${a})`;
      }
      return `rgb(${r}, ${g}, ${b})`;
    }
    return String(value);
  }
}
