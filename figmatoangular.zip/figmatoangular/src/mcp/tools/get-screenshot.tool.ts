/**
 * Get Screenshot Tool
 * Fetches visual screenshot of Figma node
 */

import * as fs from 'fs-extra';
import * as path from 'path';
import { McpClientService } from '../mcp-client.service';
import { GetScreenshotParams } from '../models/mcp-request.model';
import { GetScreenshotResult } from '../models/mcp-response.model';
import { logger } from '../../shared/utils/logger.service';
import { MCP_TOOLS } from '../../shared/constants/mcp-constants';

export class GetScreenshotTool {
  constructor(private mcpClient: McpClientService) {}

  /**
   * Get screenshot for a Figma node
   * This should ALWAYS be called SECOND (after get_code)
   */
  async execute(params: GetScreenshotParams): Promise<GetScreenshotResult> {
    logger.info(`Getting screenshot for node: ${params.node_id}`);

    try {
      const result = await this.mcpClient.call<GetScreenshotResult>(
        MCP_TOOLS.GET_SCREENSHOT.name,
        {
          ...params,
          scale: params.scale || 2, // Default to 2x for better quality
        }
      );

      logger.success(
        `Screenshot retrieved: ${result.width}x${result.height} (${result.format})`
      );
      return result;
    } catch (error) {
      logger.error('Failed to get screenshot', error);
      throw error;
    }
  }

  /**
   * Save screenshot to disk
   */
  async saveScreenshot(
    result: GetScreenshotResult,
    outputPath: string,
    filename: string = 'figma-screenshot'
  ): Promise<string> {
    try {
      await fs.ensureDir(outputPath);

      const ext = result.format === 'png' ? 'png' : 'jpg';
      const filePath = path.join(outputPath, `${filename}.${ext}`);

      // Decode base64 and save
      const buffer = Buffer.from(result.image, 'base64');
      await fs.writeFile(filePath, buffer);

      logger.success(`Screenshot saved: ${filePath}`);
      return filePath;
    } catch (error) {
      logger.error('Failed to save screenshot', error);
      throw error;
    }
  }

  /**
   * Get screenshot dimensions
   */
  getDimensions(result: GetScreenshotResult): { width: number; height: number } {
    return {
      width: result.width,
      height: result.height,
    };
  }
}
