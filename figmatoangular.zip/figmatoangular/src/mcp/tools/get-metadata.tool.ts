/**
 * Get Metadata Tool
 * Fetches XML metadata for large/complex Figma files
 */

import { McpClientService } from '../mcp-client.service';
import { GetMetadataParams } from '../models/mcp-request.model';
import { GetMetadataResult } from '../models/mcp-response.model';
import { logger } from '../../shared/utils/logger.service';
import { MCP_TOOLS } from '../../shared/constants/mcp-constants';

export class GetMetadataTool {
  constructor(private mcpClient: McpClientService) {}

  /**
   * Get metadata (XML structure) for a Figma file
   * Use this when get_code returns truncated response
   */
  async execute(params: GetMetadataParams): Promise<GetMetadataResult> {
    logger.info(`Getting metadata for file: ${params.file_key}`);

    try {
      const result = await this.mcpClient.call<GetMetadataResult>(
        MCP_TOOLS.GET_METADATA.name,
        params
      );

      logger.success('Metadata retrieved');
      return result;
    } catch (error) {
      logger.error('Failed to get metadata', error);
      throw error;
    }
  }

  /**
   * Parse XML to extract node IDs
   */
  parseNodeIds(xml: string): string[] {
    // Simple regex to extract node IDs from XML
    // Format: <node id="123:456" ...>
    const nodeIdRegex = /id="([^"]+)"/g;
    const matches = xml.matchAll(nodeIdRegex);
    const nodeIds: string[] = [];

    for (const match of matches) {
      nodeIds.push(match[1]);
    }

    logger.debug(`Found ${nodeIds.length} nodes in metadata`);
    return nodeIds;
  }

  /**
   * Parse XML to get node hierarchy
   */
  parseHierarchy(xml: string): any {
    // TODO: Implement proper XML parsing
    // For now, return raw XML
    return xml;
  }
}
