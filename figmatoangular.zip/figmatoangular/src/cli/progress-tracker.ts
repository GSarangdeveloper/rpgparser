/**
 * Progress Tracker
 * Tracks and displays conversion progress
 */

import ora, { Ora } from 'ora';
import chalk from 'chalk';
import cliProgress from 'cli-progress';

export interface ProgressStep {
  name: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  message?: string;
  startTime?: number;
  endTime?: number;
  error?: string;
}

export interface ProgressOptions {
  verbose?: boolean;
  silent?: boolean;
}

export class ProgressTracker {
  private steps: Map<string, ProgressStep> = new Map();
  private currentSpinner: Ora | null = null;
  private progressBar: cliProgress.SingleBar | null = null;
  private options: ProgressOptions;
  private totalSteps: number = 0;
  private completedSteps: number = 0;

  constructor(options: ProgressOptions = {}) {
    this.options = options;
  }

  /**
   * Initialize progress tracking with steps
   */
  init(stepNames: string[]): void {
    this.totalSteps = stepNames.length;
    this.completedSteps = 0;

    for (const name of stepNames) {
      this.steps.set(name, {
        name,
        status: 'pending',
      });
    }

    if (!this.options.silent) {
      console.log(chalk.bold(`\n🚀 Starting conversion (${this.totalSteps} steps)\n`));
    }
  }

  /**
   * Start a step
   */
  startStep(stepName: string, message?: string): void {
    const step = this.steps.get(stepName);
    if (!step) {
      throw new Error(`Step not found: ${stepName}`);
    }

    step.status = 'in_progress';
    step.startTime = Date.now();
    step.message = message;

    if (!this.options.silent) {
      if (this.currentSpinner) {
        this.currentSpinner.stop();
      }

      const displayMessage = message || stepName;
      this.currentSpinner = ora(displayMessage).start();
    }
  }

  /**
   * Update step message
   */
  updateStep(stepName: string, message: string): void {
    const step = this.steps.get(stepName);
    if (!step) return;

    step.message = message;

    if (!this.options.silent && this.currentSpinner) {
      this.currentSpinner.text = message;
    }
  }

  /**
   * Complete a step
   */
  completeStep(stepName: string, message?: string): void {
    const step = this.steps.get(stepName);
    if (!step) return;

    step.status = 'completed';
    step.endTime = Date.now();
    step.message = message;
    this.completedSteps++;

    if (!this.options.silent) {
      if (this.currentSpinner) {
        this.currentSpinner.succeed(message || stepName);
        this.currentSpinner = null;
      }

      if (this.options.verbose && step.startTime && step.endTime) {
        const duration = step.endTime - step.startTime;
        console.log(chalk.gray(`  Duration: ${this.formatDuration(duration)}`));
      }
    }
  }

  /**
   * Fail a step
   */
  failStep(stepName: string, error: string): void {
    const step = this.steps.get(stepName);
    if (!step) return;

    step.status = 'failed';
    step.endTime = Date.now();
    step.error = error;

    if (!this.options.silent) {
      if (this.currentSpinner) {
        this.currentSpinner.fail(stepName);
        this.currentSpinner = null;
      }
      console.log(chalk.red(`  Error: ${error}`));
    }
  }

  /**
   * Show progress bar
   */
  showProgressBar(): void {
    if (this.options.silent) return;

    if (!this.progressBar) {
      this.progressBar = new cliProgress.SingleBar(
        {
          format: `Progress |${chalk.cyan('{bar}')}| {percentage}% | {value}/{total} steps | {step}`,
          barCompleteChar: '\u2588',
          barIncompleteChar: '\u2591',
          hideCursor: true,
        },
        cliProgress.Presets.shades_classic
      );

      this.progressBar.start(this.totalSteps, 0, { step: 'Starting...' });
    }

    this.progressBar.update(this.completedSteps, {
      step: this.getCurrentStepName(),
    });
  }

  /**
   * Update progress bar
   */
  updateProgressBar(current: number, total: number, stepName: string): void {
    if (this.options.silent || !this.progressBar) return;

    this.progressBar.setTotal(total);
    this.progressBar.update(current, { step: stepName });
  }

  /**
   * Stop progress bar
   */
  stopProgressBar(): void {
    if (this.progressBar) {
      this.progressBar.stop();
      this.progressBar = null;
    }
  }

  /**
   * Log info message
   */
  info(message: string): void {
    if (!this.options.silent) {
      console.log(chalk.blue(`ℹ ${message}`));
    }
  }

  /**
   * Log success message
   */
  success(message: string): void {
    if (!this.options.silent) {
      console.log(chalk.green(`✓ ${message}`));
    }
  }

  /**
   * Log warning message
   */
  warn(message: string): void {
    if (!this.options.silent) {
      console.log(chalk.yellow(`⚠ ${message}`));
    }
  }

  /**
   * Log error message
   */
  error(message: string): void {
    if (!this.options.silent) {
      console.log(chalk.red(`✗ ${message}`));
    }
  }

  /**
   * Show summary
   */
  showSummary(): void {
    if (this.options.silent) return;

    const completed = Array.from(this.steps.values()).filter(
      s => s.status === 'completed'
    );
    const failed = Array.from(this.steps.values()).filter(s => s.status === 'failed');

    console.log(chalk.bold('\n📊 Summary\n'));

    console.log(`Total steps: ${this.totalSteps}`);
    console.log(chalk.green(`Completed: ${completed.length}`));
    if (failed.length > 0) {
      console.log(chalk.red(`Failed: ${failed.length}`));
    }

    // Calculate total duration
    const totalDuration = completed.reduce((sum, step) => {
      if (step.startTime && step.endTime) {
        return sum + (step.endTime - step.startTime);
      }
      return sum;
    }, 0);

    console.log(`Total time: ${this.formatDuration(totalDuration)}`);

    // Show failed steps
    if (failed.length > 0) {
      console.log(chalk.bold('\n❌ Failed Steps:\n'));
      for (const step of failed) {
        console.log(chalk.red(`  • ${step.name}`));
        if (step.error) {
          console.log(chalk.gray(`    ${step.error}`));
        }
      }
    }

    // Verbose: show all steps with timings
    if (this.options.verbose) {
      console.log(chalk.bold('\n📋 Detailed Steps:\n'));
      for (const [name, step] of this.steps) {
        const statusIcon =
          step.status === 'completed'
            ? chalk.green('✓')
            : step.status === 'failed'
            ? chalk.red('✗')
            : chalk.gray('○');

        let duration = '';
        if (step.startTime && step.endTime) {
          duration = ` (${this.formatDuration(step.endTime - step.startTime)})`;
        }

        console.log(`  ${statusIcon} ${name}${duration}`);
      }
    }

    console.log('');
  }

  /**
   * Get current step name
   */
  private getCurrentStepName(): string {
    for (const [name, step] of this.steps) {
      if (step.status === 'in_progress') {
        return name;
      }
    }
    return 'Completed';
  }

  /**
   * Format duration in human-readable format
   */
  private formatDuration(ms: number): string {
    if (ms < 1000) {
      return `${ms}ms`;
    }
    if (ms < 60000) {
      return `${(ms / 1000).toFixed(1)}s`;
    }
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(0);
    return `${minutes}m ${seconds}s`;
  }

  /**
   * Get step status
   */
  getStepStatus(stepName: string): ProgressStep['status'] | null {
    const step = this.steps.get(stepName);
    return step ? step.status : null;
  }

  /**
   * Get all steps
   */
  getAllSteps(): ProgressStep[] {
    return Array.from(this.steps.values());
  }

  /**
   * Reset tracker
   */
  reset(): void {
    this.steps.clear();
    this.totalSteps = 0;
    this.completedSteps = 0;
    if (this.currentSpinner) {
      this.currentSpinner.stop();
      this.currentSpinner = null;
    }
    if (this.progressBar) {
      this.progressBar.stop();
      this.progressBar = null;
    }
  }

  /**
   * Create a sub-tracker for nested progress
   */
  createSubTracker(prefix: string): SubProgressTracker {
    return new SubProgressTracker(this, prefix);
  }
}

/**
 * Sub-tracker for nested progress
 */
export class SubProgressTracker {
  constructor(private parent: ProgressTracker, private prefix: string) {}

  info(message: string): void {
    this.parent.info(`${this.prefix}: ${message}`);
  }

  success(message: string): void {
    this.parent.success(`${this.prefix}: ${message}`);
  }

  warn(message: string): void {
    this.parent.warn(`${this.prefix}: ${message}`);
  }

  error(message: string): void {
    this.parent.error(`${this.prefix}: ${message}`);
  }

  updateStep(message: string): void {
    this.parent.updateStep(this.prefix, `${this.prefix}: ${message}`);
  }
}

/**
 * Default progress tracker instance
 */
export const progressTracker = new ProgressTracker();
