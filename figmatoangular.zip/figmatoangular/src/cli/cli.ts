#!/usr/bin/env node
/**
 * CLI Interface
 * Interactive command-line interface for Figma-to-Angular converter
 */

import { Command } from 'commander';
import inquirer from 'inquirer';
import chalk from 'chalk';
import ora from 'ora';
import * as path from 'path';
import * as fs from 'fs-extra';
import { FigmaToAngularConverter } from '../index';
import { ConversionConfig } from '../types';
// import { logger } from '../shared/utils/logger.service'; // Unused import

const program = new Command();

program
  .name('figma-to-angular')
  .description('Convert Figma designs to Angular components')
  .version('1.0.0');

/**
 * Convert command
 */
program
  .command('convert')
  .description('Convert a Figma design to Angular component')
  .option('-u, --url <url>', 'Figma file URL')
  .option('-n, --node <id>', 'Node ID to convert')
  .option('-o, --output <dir>', 'Output directory', './output')
  .option('-c, --config <path>', 'Path to config file')
  .option('--no-validation', 'Skip validation')
  .option('--no-optimization', 'Skip asset optimization')
  .action(async (options) => {
    try {
      let config: ConversionConfig;

      // Load from config file if provided
      if (options.config) {
        const configPath = path.resolve(options.config);
        if (await fs.pathExists(configPath)) {
          config = await fs.readJson(configPath);
          console.log(chalk.blue(`📄 Loaded config from: ${configPath}`));
        } else {
          console.error(chalk.red(`❌ Config file not found: ${configPath}`));
          process.exit(1);
        }
      } else if (options.url) {
        // Use command-line options
        config = {
          figmaUrl: options.url,
          outputDir: path.resolve(options.output),
          validation: {
            visualComparison: options.validation !== false,
            compileCheck: options.validation !== false,
            accessibilityCheck: options.validation !== false,
          },
          angular: {
            standalone: true,
            changeDetection: 'OnPush',
            styleEncapsulation: 'Emulated',
            generateTests: false,
            generateModule: false,
          },
          transformation: {
            reuseComponents: true,
            useDesignTokens: true,
            generateDocumentation: true,
            semanticHtml: true,
            accessibility: true,
          },
          assets: {
            downloadAssets: true,
            optimizeImages: options.optimization !== false,
            inlineSvgs: true,
            assetPath: './assets',
          },
        };
      } else {
        // Interactive mode
        config = await interactiveConfig();
      }

      // Run conversion
      const spinner = ora('Converting Figma design to Angular...').start();

      const converter = new FigmaToAngularConverter();
      const result = await converter.convert(config);

      spinner.stop();

      if (result.success) {
        console.log(chalk.green('\n✓ Conversion completed successfully!\n'));
        console.log(chalk.bold('Generated files:'));
        for (const file of result.generatedFiles) {
          console.log(chalk.gray(`  • ${file}`));
        }

        if (result.validationReport) {
          console.log(chalk.bold('\nValidation Results:'));
          if (result.validationReport.compilation) {
            console.log(
              result.validationReport.compilation.success
                ? chalk.green('  ✓ Compilation: PASS')
                : chalk.red('  ✗ Compilation: FAIL')
            );
          }
          if (result.validationReport.accessibility) {
            console.log(
              result.validationReport.accessibility.score >= 80
                ? chalk.green(`  ✓ Accessibility: PASS (${result.validationReport.accessibility.score}/100)`)
                : chalk.red(`  ✗ Accessibility: FAIL (${result.validationReport.accessibility.score}/100)`)
            );
          }
          if (result.validationReport.visual) {
            console.log(
              result.validationReport.visual.overallSimilarity >= 90
                ? chalk.green(`  ✓ Visual: ${result.validationReport.visual.overallSimilarity.toFixed(1)}% similar`)
                : chalk.yellow(`  ⚠ Visual: ${result.validationReport.visual.overallSimilarity.toFixed(1)}% similar`)
            );
          }
        }

        console.log(chalk.blue(`\n📁 Output directory: ${config.outputDir}`));
      } else {
        console.log(chalk.red('\n✗ Conversion failed\n'));
        if (result.error) {
          console.log(chalk.bold('Error:'));
          console.log(chalk.red(`  • ${result.error}`));
        }
        process.exit(1);
      }
    } catch (error: any) {
      console.error(chalk.red(`\n❌ Error: ${error.message}`));
      process.exit(1);
    }
  });

/**
 * Auth command
 */
program
  .command('auth')
  .description('Authenticate with Figma')
  .action(async () => {
    try {
      console.log(chalk.blue('\n🔐 Figma Authentication\n'));

      const answers = await inquirer.prompt([
        {
          type: 'input',
          name: 'clientId',
          message: 'Enter your Figma OAuth Client ID:',
          validate: (input) => input.length > 0 || 'Client ID is required',
        },
        {
          type: 'password',
          name: 'clientSecret',
          message: 'Enter your Figma OAuth Client Secret:',
          validate: (input) => input.length > 0 || 'Client Secret is required',
        },
      ]);

      const spinner = ora('Authenticating with Figma...').start();

      const converter = new FigmaToAngularConverter();
      // Note: OAuth credentials should be set in environment variables
      // FIGMA_CLIENT_ID, FIGMA_CLIENT_SECRET, FIGMA_REDIRECT_URI
      console.log(`Client ID: ${answers.clientId}`);
      console.log(`Client Secret: ${answers.clientSecret.substring(0, 4)}...`);
      await converter.authenticate();

      spinner.stop();
      console.log(chalk.green('\n✓ Authentication successful!\n'));
    } catch (error: any) {
      console.error(chalk.red(`\n❌ Authentication failed: ${error.message}`));
      process.exit(1);
    }
  });

/**
 * Config command
 */
program
  .command('config')
  .description('Generate a configuration file')
  .option('-o, --output <path>', 'Output path for config file', './figma-to-angular.config.json')
  .action(async (options) => {
    try {
      const config = await interactiveConfig();

      const outputPath = path.resolve(options.output);
      await fs.writeJson(outputPath, config, { spaces: 2 });

      console.log(chalk.green(`\n✓ Configuration saved to: ${outputPath}\n`));
      console.log(chalk.gray('Use it with: figma-to-angular convert --config ' + outputPath));
    } catch (error: any) {
      console.error(chalk.red(`\n❌ Error: ${error.message}`));
      process.exit(1);
    }
  });

/**
 * Validate command
 */
program
  .command('validate')
  .description('Validate generated Angular components')
  .option('-d, --dir <directory>', 'Directory containing components', './output')
  .option('--compilation', 'Run compilation validation only')
  .option('--accessibility', 'Run accessibility validation only')
  .option('--visual', 'Run visual validation only')
  .action(async (options) => {
    try {
      const dir = path.resolve(options.dir);

      if (!(await fs.pathExists(dir))) {
        console.error(chalk.red(`❌ Directory not found: ${dir}`));
        process.exit(1);
      }

      console.log(chalk.blue('\n🔍 Running validations...\n'));

      // const converter = new FigmaToAngularConverter(); // Unused variable

      // TODO: Implement standalone validation
      // This would run validations on already-generated components

      console.log(chalk.green('\n✓ Validation completed!\n'));
    } catch (error: any) {
      console.error(chalk.red(`\n❌ Error: ${error.message}`));
      process.exit(1);
    }
  });

/**
 * Init command
 */
program
  .command('init')
  .description('Initialize a new Figma-to-Angular project')
  .option('-d, --dir <directory>', 'Project directory', '.')
  .action(async (options) => {
    try {
      const projectDir = path.resolve(options.dir);

      console.log(chalk.blue('\n🚀 Initializing Figma-to-Angular project...\n'));

      // Create directories
      await fs.ensureDir(path.join(projectDir, 'output'));
      await fs.ensureDir(path.join(projectDir, 'config'));
      await fs.ensureDir(path.join(projectDir, 'design-system'));

      // Create default config
      const defaultConfig: ConversionConfig = {
        figmaUrl: '',
        outputDir: './output',
        angular: {
          standalone: true,
          changeDetection: 'OnPush',
          styleEncapsulation: 'Emulated',
          generateTests: false,
          generateModule: false,
        },
        transformation: {
          reuseComponents: true,
          useDesignTokens: true,
          generateDocumentation: true,
          semanticHtml: true,
          accessibility: true,
        },
        assets: {
          downloadAssets: true,
          optimizeImages: true,
          inlineSvgs: true,
          assetPath: './assets',
        },
        validation: {
          visualComparison: true,
          compileCheck: true,
          accessibilityCheck: true,
        },
      };

      await fs.writeJson(
        path.join(projectDir, 'figma-to-angular.config.json'),
        defaultConfig,
        { spaces: 2 }
      );

      // Create README
      const readme = `# Figma-to-Angular Project

This project uses Figma-to-Angular converter to generate Angular components from Figma designs.

## Getting Started

1. Configure your Figma credentials:
   \`\`\`
   figma-to-angular auth
   \`\`\`

2. Edit \`figma-to-angular.config.json\` with your Figma file URL

3. Run conversion:
   \`\`\`
   figma-to-angular convert --config figma-to-angular.config.json
   \`\`\`

## Output

Generated components will be placed in the \`output/\` directory.

## Documentation

Visit https://github.com/figma-to-angular for full documentation.
`;

      await fs.writeFile(path.join(projectDir, 'README.md'), readme);

      console.log(chalk.green('✓ Project initialized successfully!\n'));
      console.log(chalk.bold('Created:'));
      console.log(chalk.gray('  • output/'));
      console.log(chalk.gray('  • config/'));
      console.log(chalk.gray('  • design-system/'));
      console.log(chalk.gray('  • figma-to-angular.config.json'));
      console.log(chalk.gray('  • README.md'));
      console.log(chalk.blue('\n📖 Next steps:'));
      console.log(chalk.gray('  1. Run: figma-to-angular auth'));
      console.log(chalk.gray('  2. Edit figma-to-angular.config.json'));
      console.log(chalk.gray('  3. Run: figma-to-angular convert\n'));
    } catch (error: any) {
      console.error(chalk.red(`\n❌ Error: ${error.message}`));
      process.exit(1);
    }
  });

/**
 * Interactive configuration
 */
async function interactiveConfig(): Promise<ConversionConfig> {
  console.log(chalk.blue('\n⚙️  Configuration\n'));

  const answers = await inquirer.prompt([
    {
      type: 'input',
      name: 'figmaUrl',
      message: 'Figma file URL:',
      validate: (input) =>
        input.includes('figma.com') || 'Please enter a valid Figma URL',
    },
    {
      type: 'input',
      name: 'nodeId',
      message: 'Node ID (optional, leave empty for entire file):',
    },
    {
      type: 'input',
      name: 'outputDir',
      message: 'Output directory:',
      default: './output',
    },
    {
      type: 'confirm',
      name: 'validation',
      message: 'Enable validation?',
      default: true,
    },
    {
      type: 'confirm',
      name: 'optimization',
      message: 'Enable asset optimization?',
      default: true,
    },
    {
      type: 'confirm',
      name: 'standalone',
      message: 'Generate standalone components?',
      default: true,
    },
    {
      type: 'confirm',
      name: 'useDesignTokens',
      message: 'Use design tokens?',
      default: true,
    },
  ]);

  return {
    figmaUrl: answers.figmaUrl,
    outputDir: path.resolve(answers.outputDir),
    angular: {
      standalone: answers.standalone,
      changeDetection: 'OnPush',
      styleEncapsulation: 'Emulated',
      generateTests: false,
      generateModule: false,
    },
    transformation: {
      reuseComponents: true,
      useDesignTokens: answers.useDesignTokens,
      generateDocumentation: true,
      semanticHtml: true,
      accessibility: true,
    },
    assets: {
      downloadAssets: true,
      optimizeImages: answers.optimization,
      inlineSvgs: true,
      assetPath: './assets',
    },
    validation: {
      visualComparison: answers.validation,
      compileCheck: answers.validation,
      accessibilityCheck: answers.validation,
    },
  };
}

// Parse command-line arguments
program.parse();
