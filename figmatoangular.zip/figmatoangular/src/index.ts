/**
 * Figma-to-Angular Converter
 * Main entry point
 */

import * as dotenv from 'dotenv';
import * as path from 'path';
import { logger } from './shared/utils/logger.service';
import { AuthService } from './auth/auth.service';
import { McpClientService } from './mcp/mcp-client.service';
import { ToolOrchestratorService } from './mcp/tool-orchestrator.service';
import { FigmaUrlParser } from './figma/url-parser.service';
import { ConversionConfig, DEFAULT_CONFIG } from './shared/models/conversion-config.model';
import { ConversionResult, GeneratedFile } from './shared/models/conversion-result.model';
import { TransformOrchestrator } from './transform/orchestrator.service';
import { ComponentRegistry } from './design-system/component-registry';
import { TokenRegistry } from './design-system/token-registry';
import { TypeScriptGenerator } from './codegen/typescript-generator';
import { TemplateGenerator } from './codegen/template-generator';
import { StyleGenerator } from './codegen/style-generator';
import { FileWriterService } from './output/file-writer.service';

// Load environment variables
dotenv.config();

/**
 * Main Converter Class
 */
export class FigmaToAngularConverter {
  private authService: AuthService;

  constructor() {
    this.authService = new AuthService();
    logger.info('🚀 Figma-to-Angular Converter initialized');
  }

  /**
   * Convert Figma design to Angular component
   */
  async convert(config: ConversionConfig): Promise<ConversionResult> {
    const startTime = Date.now();

    try {
      logger.info('🎨 Starting conversion process');
      logger.group('Configuration');
      logger.info(`Figma URL: ${config.figmaUrl}`);
      logger.info(`Output Dir: ${config.outputDir}`);
      logger.groupEnd();

      // Step 1: Parse Figma URL
      const parsed = FigmaUrlParser.parse(config.figmaUrl);
      if (!parsed.isValid || !parsed.fileKey) {
        throw new Error('Invalid Figma URL');
      }

      if (!parsed.nodeId) {
        throw new Error('Node ID is required in Figma URL');
      }

      // Step 2: Authenticate
      const accessToken = config.figmaAccessToken || (await this.authService.getValidAccessToken());

      // Step 3: Initialize MCP Client
      const mcpClient = new McpClientService(accessToken);
      const orchestrator = new ToolOrchestratorService(mcpClient);

      // Step 4: Fetch node data from Figma (MCP sequence)
      logger.info('📡 Fetching data from Figma via MCP...');
      const nodeData = await orchestrator.fetchNodeData(
        parsed.fileKey,
        parsed.nodeId,
        config.outputDir
      );

      logger.success('✅ Data fetched successfully');

      // Step 5: Initialize registries and transformation
      logger.info('🔧 Initializing transformation engine...');
      const componentRegistry = new ComponentRegistry();
      const tokenRegistry = new TokenRegistry();

      // Load design system components if provided
      if (config.designSystem?.componentsPath) {
        // TODO: Load existing components from project
        logger.debug('Design system integration enabled');
      }

      // Load design tokens from Figma
      if (nodeData.designTokens) {
        const tokens = Object.entries(nodeData.designTokens).map(([name, value]) => ({
          name,
          value: String(value),
          type: this.inferTokenType(name) as any,
        }));
        tokenRegistry.loadFromConfig(tokens);
      }

      // Create transformation orchestrator
      const transformOrchestrator = new TransformOrchestrator(
        componentRegistry,
        tokenRegistry,
        config.designSystem?.codeConnectMappings || {}
      );

      // Step 6: Transform React → Angular
      logger.info('🔄 Transforming React to Angular...');
      const transformResult = await transformOrchestrator.transform(nodeData.code, {
        reuseComponents: config.transformation?.reuseComponents ?? true,
        useDesignTokens: config.transformation?.useDesignTokens ?? true,
        reuseThreshold: 0.8,
        codeConnectMappings: config.designSystem?.codeConnectMappings,
      });

      logger.success('✅ Transformation complete');

      // Check if we should reuse existing component
      if (transformResult.type === 'reuse') {
        logger.success(`Using existing component: ${transformResult.existingComponentPath}`);

        const conversionTime = Date.now() - startTime;
        return {
          success: true,
          componentName: transformResult.componentName,
          generatedFiles: [],
          validationReport: {
            success: true,
            issues: [],
          },
          metadata: {
            figmaUrl: config.figmaUrl,
            figmaNodeId: parsed.nodeId,
            conversionTime,
            timestamp: new Date(),
          },
          reusedComponents: [transformResult.existingComponentPath!],
        };
      }

      // Step 7: Generate Angular files
      logger.info('📝 Generating Angular files...');

      const tsGenerator = new TypeScriptGenerator();
      const templateGenerator = new TemplateGenerator();
      const styleGenerator = new StyleGenerator();
      const fileWriter = new FileWriterService();

      // Create component directory
      const componentDir = await fileWriter.createComponentDirectory(
        config.outputDir,
        transformResult.componentName
      );

      const kebabName = transformResult.componentName
        .replace(/Component$/, '')
        .replace(/([a-z])([A-Z])/g, '$1-$2')
        .toLowerCase();

      // Generate TypeScript component
      const tsContent = tsGenerator.generate(transformResult, {
        standalone: config.angular?.standalone ?? true,
        changeDetection: config.angular?.changeDetection || 'OnPush',
        styleEncapsulation: config.angular?.styleEncapsulation || 'Emulated',
        generateTests: config.angular?.generateTests ?? false,
      });

      // Generate HTML template
      const htmlContent = config.transformation?.generateDocumentation
        ? templateGenerator.generateWithComments(transformResult)
        : templateGenerator.generate(transformResult);

      // Generate SCSS styles
      const scssContent = config.transformation?.generateDocumentation
        ? styleGenerator.generateWithComments(transformResult)
        : styleGenerator.generate(transformResult);

      // Prepare files
      const generatedFiles: GeneratedFile[] = [
        {
          path: path.join(componentDir, `${kebabName}.component.ts`),
          type: 'component',
          content: tsContent,
          size: tsContent.length,
        },
        {
          path: path.join(componentDir, `${kebabName}.component.html`),
          type: 'template',
          content: htmlContent,
          size: htmlContent.length,
        },
        {
          path: path.join(componentDir, `${kebabName}.component.scss`),
          type: 'style',
          content: scssContent,
          size: scssContent.length,
        },
      ];

      // Generate test file if requested
      if (config.angular?.generateTests) {
        const testContent = tsGenerator.generateTestFile(transformResult, {
          standalone: config.angular?.standalone ?? true,
          changeDetection: config.angular?.changeDetection || 'OnPush',
          styleEncapsulation: config.angular?.styleEncapsulation || 'Emulated',
          generateTests: true,
        });

        generatedFiles.push({
          path: path.join(componentDir, `${kebabName}.component.spec.ts`),
          type: 'test',
          content: testContent,
          size: testContent.length,
        });
      }

      // Generate README if documentation enabled
      if (config.transformation?.generateDocumentation) {
        const readmeContent = fileWriter.generateComponentReadme(
          transformResult.componentName,
          transformResult.inputs || [],
          transformResult.outputs || [],
          `Component generated from Figma design: ${config.figmaUrl}`
        );

        generatedFiles.push({
          path: path.join(componentDir, 'README.md'),
          type: 'documentation',
          content: readmeContent,
          size: readmeContent.length,
        });
      }

      // Step 8: Write files to disk
      logger.info('💾 Writing files to disk...');
      await fileWriter.writeFiles(generatedFiles);

      // Step 9: Validate (basic validation for now)
      logger.info('✅ Validating output...');
      const templateValidation = templateGenerator.validateTemplate(htmlContent);

      const conversionTime = Date.now() - startTime;

      const result: ConversionResult = {
        success: true,
        componentName: transformResult.componentName,
        generatedFiles,
        validationReport: {
          success: templateValidation.valid,
          issues: templateValidation.errors.map(err => ({
            type: 'warning' as const,
            category: 'compilation' as const,
            message: err,
          })),
        },
        metadata: {
          figmaUrl: config.figmaUrl,
          figmaNodeId: parsed.nodeId,
          conversionTime,
          timestamp: new Date(),
        },
        designTokens: nodeData.designTokens,
      };

      logger.success(`✨ Conversion completed in ${conversionTime}ms`);
      logger.info(`Generated ${generatedFiles.length} files in: ${componentDir}`);
      return result;
    } catch (error: any) {
      logger.error('❌ Conversion failed', error);

      const conversionTime = Date.now() - startTime;

      return {
        success: false,
        componentName: config.componentName || 'FailedComponent',
        generatedFiles: [],
        validationReport: {
          success: false,
          issues: [
            {
              type: 'error',
              category: 'compilation',
              message: error.message,
            },
          ],
        },
        metadata: {
          figmaUrl: config.figmaUrl,
          figmaNodeId: '',
          conversionTime,
          timestamp: new Date(),
        },
        error: error.message,
      };
    }
  }

  /**
   * Authenticate with Figma
   */
  async authenticate(): Promise<void> {
    logger.info('🔐 Starting authentication...');

    if (await this.authService.isAuthenticated()) {
      logger.success('Already authenticated');
      return;
    }

    const authUrl = this.authService.getAuthorizationUrl();
    logger.info('Please open this URL in your browser:');
    console.log('\n' + authUrl + '\n');

    // TODO: Implement OAuth callback server
    logger.warn('⚠️  OAuth callback server not yet implemented');
    logger.info('For now, you can set FIGMA_ACCESS_TOKEN in your .env file');
  }

  /**
   * Check authentication status
   */
  async isAuthenticated(): Promise<boolean> {
    return this.authService.isAuthenticated();
  }

  /**
   * Logout
   */
  async logout(): Promise<void> {
    await this.authService.logout();
    logger.success('Logged out successfully');
  }

  /**
   * Infer token type from name
   */
  private inferTokenType(name: string): 'color' | 'spacing' | 'typography' | 'other' {
    const nameLower = name.toLowerCase();
    if (nameLower.includes('color') || nameLower.includes('bg') || nameLower.includes('text')) {
      return 'color';
    }
    if (nameLower.includes('spacing') || nameLower.includes('padding') || nameLower.includes('margin')) {
      return 'spacing';
    }
    if (nameLower.includes('font') || nameLower.includes('text') || nameLower.includes('size')) {
      return 'typography';
    }
    return 'other';
  }
}

// Export for library usage
export * from './shared/models/conversion-config.model';
export * from './shared/models/conversion-result.model';
export { FigmaUrlParser } from './figma/url-parser.service';
export { logger } from './shared/utils/logger.service';

// CLI entry point
if (require.main === module) {
  (async () => {
    const converter = new FigmaToAngularConverter();

    // Example usage
    const result = await converter.convert({
      figmaUrl: 'https://figma.com/file/example?node-id=1:2',
      outputDir: './output',
      ...DEFAULT_CONFIG,
      angular: DEFAULT_CONFIG.angular!,
    } as ConversionConfig);

    console.log(result);
  })();
}
