/**
 * Component Registry
 * Registry of existing Angular components in the project
 */

import { logger } from '../shared/utils/logger.service';

export interface RegisteredComponent {
  name: string;
  path: string;
  selector: string;
  props: string[];
  description?: string;
}

export class ComponentRegistry {
  private components: Map<string, RegisteredComponent> = new Map();

  /**
   * Register a component
   */
  register(component: RegisteredComponent): void {
    this.components.set(component.name.toLowerCase(), component);
    logger.debug(`Registered component: ${component.name}`);
  }

  /**
   * Find component by name (case-insensitive)
   */
  findByName(name: string): RegisteredComponent | null {
    return this.components.get(name.toLowerCase()) || null;
  }

  /**
   * Find component by selector
   */
  findBySelector(selector: string): RegisteredComponent | null {
    for (const component of this.components.values()) {
      if (component.selector === selector) {
        return component;
      }
    }
    return null;
  }

  /**
   * Get all registered components
   */
  getAll(): RegisteredComponent[] {
    return Array.from(this.components.values());
  }

  /**
   * Load components from configuration
   */
  loadFromConfig(components: RegisteredComponent[]): void {
    for (const component of components) {
      this.register(component);
    }
    logger.info(`Loaded ${components.length} components into registry`);
  }

  /**
   * Clear registry
   */
  clear(): void {
    this.components.clear();
  }
}
