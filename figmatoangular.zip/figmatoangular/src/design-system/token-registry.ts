/**
 * Design Token Registry
 * Registry of design tokens (colors, spacing, typography, etc.)
 */

import { logger } from '../shared/utils/logger.service';

export interface DesignTokenDefinition {
  name: string;
  value: string;
  type: 'color' | 'spacing' | 'typography' | 'shadow' | 'other';
  category?: string;
}

export class TokenRegistry {
  private tokens: Map<string, DesignTokenDefinition> = new Map();
  private valueIndex: Map<string, DesignTokenDefinition[]> = new Map();

  /**
   * Register a design token
   */
  register(token: DesignTokenDefinition): void {
    const key = token.name.toLowerCase();
    this.tokens.set(key, token);

    // Index by value for reverse lookup
    const normalizedValue = this.normalizeValue(token.value);
    if (!this.valueIndex.has(normalizedValue)) {
      this.valueIndex.set(normalizedValue, []);
    }
    this.valueIndex.get(normalizedValue)!.push(token);

    logger.debug(`Registered token: ${token.name} = ${token.value}`);
  }

  /**
   * Find token by name
   */
  findByName(name: string): DesignTokenDefinition | null {
    return this.tokens.get(name.toLowerCase()) || null;
  }

  /**
   * Find token by value
   */
  findByValue(value: string): DesignTokenDefinition | null {
    const normalized = this.normalizeValue(value);
    const matches = this.valueIndex.get(normalized);
    return matches?.[0] || null;
  }

  /**
   * Find all tokens by type
   */
  findByType(type: DesignTokenDefinition['type']): DesignTokenDefinition[] {
    return Array.from(this.tokens.values()).filter((t) => t.type === type);
  }

  /**
   * Get all tokens
   */
  getAll(): DesignTokenDefinition[] {
    return Array.from(this.tokens.values());
  }

  /**
   * Load tokens from configuration
   */
  loadFromConfig(tokens: DesignTokenDefinition[]): void {
    for (const token of tokens) {
      this.register(token);
    }
    logger.info(`Loaded ${tokens.length} design tokens into registry`);
  }

  /**
   * Clear registry
   */
  clear(): void {
    this.tokens.clear();
    this.valueIndex.clear();
  }

  /**
   * Normalize value for comparison
   */
  private normalizeValue(value: string): string {
    // Remove whitespace
    let normalized = value.replace(/\s+/g, '');

    // Normalize color formats
    if (value.startsWith('#')) {
      // Convert 3-char hex to 6-char: #abc → #aabbcc
      if (normalized.length === 4) {
        normalized = `#${normalized[1]}${normalized[1]}${normalized[2]}${normalized[2]}${normalized[3]}${normalized[3]}`;
      }
      return normalized.toLowerCase();
    }

    // Normalize rgb/rgba
    if (value.startsWith('rgb')) {
      const match = value.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
      if (match) {
        const [, r, g, b, a] = match;
        return a ? `rgba(${r},${g},${b},${a})` : `rgb(${r},${g},${b})`;
      }
    }

    // Normalize units (rem, em, px)
    const unitMatch = value.match(/^([\d.]+)(rem|em|px)$/);
    if (unitMatch) {
      const [, num, unit] = unitMatch;
      return `${parseFloat(num)}${unit}`;
    }

    return normalized.toLowerCase();
  }
}
