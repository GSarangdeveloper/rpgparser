/**
 * Accessibility Validator
 * Validates WCAG 2.1 AA compliance using axe-core
 */

import * as fs from 'fs-extra';
import * as path from 'path';
import puppeteer, { Browser } from 'puppeteer';
import { logger } from '../shared/utils/logger.service';

export interface AccessibilityOptions {
  standard?: 'wcag2a' | 'wcag2aa' | 'wcag2aaa' | 'wcag21a' | 'wcag21aa' | 'wcag21aaa';
  rules?: string[]; // Specific rules to run
  runOnly?: string[]; // Run only specific rule tags
  timeout?: number;
}

export interface AccessibilityViolation {
  id: string;
  impact: 'critical' | 'serious' | 'moderate' | 'minor';
  description: string;
  help: string;
  helpUrl: string;
  tags: string[];
  nodes: ViolationNode[];
}

export interface ViolationNode {
  html: string;
  target: string[];
  failureSummary: string;
}

export interface AccessibilityResult {
  success: boolean;
  violations: AccessibilityViolation[];
  passes: number;
  incomplete: number;
  inapplicable: number;
  score: number; // 0-100
  wcagLevel: 'A' | 'AA' | 'AAA' | 'fail';
}

export class AccessibilityValidator {
  private browser: Browser | null = null;

  /**
   * Initialize browser
   */
  async init(): Promise<void> {
    if (!this.browser) {
      logger.debug('Launching Puppeteer for accessibility validation...');
      this.browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
      });
    }
  }

  /**
   * Close browser
   */
  async close(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
  }

  /**
   * Validate HTML file for accessibility
   */
  async validateHtmlFile(
    htmlPath: string,
    options: AccessibilityOptions = {}
  ): Promise<AccessibilityResult> {
    try {
      await this.init();

      logger.debug(`Validating accessibility: ${htmlPath}`);

      const page = await this.browser!.newPage();

      // Load HTML file
      const fileUrl = `file://${path.resolve(htmlPath)}`;
      await page.goto(fileUrl, { waitUntil: 'networkidle0' });

      // Inject axe-core
      await this.injectAxe(page);

      // Run axe analysis
      const results = await this.runAxe(page, options);

      await page.close();

      const result = this.processResults(results);

      if (result.success) {
        logger.success(`✓ Accessibility validation passed (score: ${result.score})`);
      } else {
        logger.error(
          `✗ Accessibility validation failed: ${result.violations.length} violations`
        );
      }

      return result;
    } catch (error: any) {
      logger.error('Failed to validate accessibility', error);
      return {
        success: false,
        violations: [],
        passes: 0,
        incomplete: 0,
        inapplicable: 0,
        score: 0,
        wcagLevel: 'fail',
      };
    }
  }

  /**
   * Validate HTML string for accessibility
   */
  async validateHtmlString(
    html: string,
    options: AccessibilityOptions = {}
  ): Promise<AccessibilityResult> {
    try {
      await this.init();

      logger.debug('Validating accessibility from HTML string');

      const page = await this.browser!.newPage();

      // Set HTML content
      await page.setContent(html, { waitUntil: 'networkidle0' });

      // Inject axe-core
      await this.injectAxe(page);

      // Run axe analysis
      const results = await this.runAxe(page, options);

      await page.close();

      return this.processResults(results);
    } catch (error: any) {
      logger.error('Failed to validate accessibility', error);
      return {
        success: false,
        violations: [],
        passes: 0,
        incomplete: 0,
        inapplicable: 0,
        score: 0,
        wcagLevel: 'fail',
      };
    }
  }

  /**
   * Validate Angular component for accessibility
   */
  async validateComponent(
    componentHtml: string,
    componentCss: string,
    options: AccessibilityOptions = {}
  ): Promise<AccessibilityResult> {
    // Create complete HTML with styles
    const fullHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Accessibility Test</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      padding: 20px;
      background: #ffffff;
    }
    ${componentCss}
  </style>
</head>
<body>
  ${componentHtml}
</body>
</html>
    `;

    return this.validateHtmlString(fullHtml, options);
  }

  /**
   * Inject axe-core library
   */
  private async injectAxe(page: any): Promise<void> {
    // Use CDN version of axe-core
    await page.addScriptTag({
      url: 'https://cdnjs.cloudflare.com/ajax/libs/axe-core/4.7.2/axe.min.js',
    });

    // Wait for axe to be available
    await page.waitForFunction('typeof axe !== "undefined"');
  }

  /**
   * Run axe analysis
   */
  private async runAxe(page: any, options: AccessibilityOptions): Promise<any> {
    const axeOptions: any = {
      runOnly: {
        type: 'tag',
        values: options.runOnly || [options.standard || 'wcag21aa'],
      },
    };

    if (options.rules && options.rules.length > 0) {
      axeOptions.rules = options.rules.reduce((acc: any, ruleId: string) => {
        acc[ruleId] = { enabled: true };
        return acc;
      }, {});
    }

    const results = await page.evaluate((opts: any) => {
      return (window as any).axe.run(document, opts);
    }, axeOptions);

    return results;
  }

  /**
   * Process axe results
   */
  private processResults(results: any): AccessibilityResult {
    const violations: AccessibilityViolation[] = results.violations.map(
      (violation: any) => ({
        id: violation.id,
        impact: violation.impact,
        description: violation.description,
        help: violation.help,
        helpUrl: violation.helpUrl,
        tags: violation.tags,
        nodes: violation.nodes.map((node: any) => ({
          html: node.html,
          target: node.target,
          failureSummary: node.failureSummary || '',
        })),
      })
    );

    // Calculate score (0-100)
    const totalTests = results.passes.length + violations.length + results.incomplete.length;
    const score = totalTests > 0 ? Math.round((results.passes.length / totalTests) * 100) : 0;

    // Determine WCAG level
    let wcagLevel: 'A' | 'AA' | 'AAA' | 'fail' = 'fail';
    const criticalViolations = violations.filter(v => v.impact === 'critical').length;
    const seriousViolations = violations.filter(v => v.impact === 'serious').length;
    const moderateViolations = violations.filter(v => v.impact === 'moderate').length;

    if (criticalViolations === 0 && seriousViolations === 0 && moderateViolations === 0) {
      wcagLevel = 'AAA';
    } else if (criticalViolations === 0 && seriousViolations === 0) {
      wcagLevel = 'AA';
    } else if (criticalViolations === 0) {
      wcagLevel = 'A';
    }

    return {
      success: violations.length === 0,
      violations,
      passes: results.passes.length,
      incomplete: results.incomplete.length,
      inapplicable: results.inapplicable.length,
      score,
      wcagLevel,
    };
  }

  /**
   * Check specific accessibility criteria
   */
  async checkCriteria(
    html: string,
    criteria: string[]
  ): Promise<{ [key: string]: boolean }> {
    try {
      const result = await this.validateHtmlString(html, {
        runOnly: criteria,
      });

      const checks: { [key: string]: boolean } = {};

      for (const criterion of criteria) {
        const hasViolation = result.violations.some(v =>
          v.tags.includes(criterion)
        );
        checks[criterion] = !hasViolation;
      }

      return checks;
    } catch (error) {
      logger.error('Failed to check accessibility criteria', error);
      return criteria.reduce((acc, c) => {
        acc[c] = false;
        return acc;
      }, {} as { [key: string]: boolean });
    }
  }

  /**
   * Get common accessibility issues
   */
  getCommonIssues(result: AccessibilityResult): string[] {
    const issues: string[] = [];

    const issueMap: { [key: string]: string } = {
      'color-contrast': 'Insufficient color contrast',
      'image-alt': 'Images missing alt text',
      'label': 'Form inputs missing labels',
      'button-name': 'Buttons missing accessible names',
      'link-name': 'Links missing accessible names',
      'aria-required-attr': 'Missing required ARIA attributes',
      'aria-valid-attr-value': 'Invalid ARIA attribute values',
      'heading-order': 'Incorrect heading hierarchy',
      'html-has-lang': 'Missing language attribute',
      'landmark-one-main': 'Missing main landmark',
      'page-has-heading-one': 'Missing h1 heading',
      'region': 'Content not in landmark regions',
    };

    for (const violation of result.violations) {
      if (issueMap[violation.id]) {
        issues.push(issueMap[violation.id]);
      }
    }

    return [...new Set(issues)];
  }

  /**
   * Format accessibility result as string
   */
  formatResult(result: AccessibilityResult): string {
    const lines: string[] = [];

    lines.push(`Accessibility Result: ${result.success ? '✓ PASS' : '✗ FAIL'}`);
    lines.push(`WCAG Level: ${result.wcagLevel}`);
    lines.push(`Score: ${result.score}/100`);
    lines.push(`Passes: ${result.passes}`);
    lines.push(`Violations: ${result.violations.length}`);
    lines.push(`Incomplete: ${result.incomplete}`);

    if (result.violations.length > 0) {
      lines.push('\nViolations:');

      const criticalViolations = result.violations.filter(v => v.impact === 'critical');
      const seriousViolations = result.violations.filter(v => v.impact === 'serious');
      const moderateViolations = result.violations.filter(v => v.impact === 'moderate');
      const minorViolations = result.violations.filter(v => v.impact === 'minor');

      if (criticalViolations.length > 0) {
        lines.push(`\n  Critical (${criticalViolations.length}):`);
        for (const violation of criticalViolations) {
          lines.push(`    • ${violation.help}`);
          lines.push(`      ${violation.helpUrl}`);
          lines.push(`      Affects ${violation.nodes.length} element(s)`);
        }
      }

      if (seriousViolations.length > 0) {
        lines.push(`\n  Serious (${seriousViolations.length}):`);
        for (const violation of seriousViolations) {
          lines.push(`    • ${violation.help}`);
          lines.push(`      ${violation.helpUrl}`);
          lines.push(`      Affects ${violation.nodes.length} element(s)`);
        }
      }

      if (moderateViolations.length > 0) {
        lines.push(`\n  Moderate (${moderateViolations.length}):`);
        for (const violation of moderateViolations) {
          lines.push(`    • ${violation.help}`);
        }
      }

      if (minorViolations.length > 0) {
        lines.push(`\n  Minor (${minorViolations.length}):`);
        for (const violation of minorViolations) {
          lines.push(`    • ${violation.help}`);
        }
      }
    }

    return lines.join('\n');
  }

  /**
   * Generate HTML accessibility report
   */
  async generateReport(
    result: AccessibilityResult,
    outputPath: string
  ): Promise<string> {
    try {
      const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Accessibility Report</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
      background: #f5f5f5;
      padding: 40px 20px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      padding: 40px;
    }
    h1 { font-size: 32px; margin-bottom: 30px; color: #333; }
    h2 { font-size: 24px; margin: 30px 0 20px; color: #333; }
    .score {
      display: inline-block;
      padding: 20px 40px;
      border-radius: 8px;
      font-size: 48px;
      font-weight: 700;
      background: ${result.score >= 90 ? '#4CAF50' : result.score >= 70 ? '#FF9800' : '#F44336'};
      color: white;
      margin-bottom: 30px;
    }
    .metrics {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 40px;
    }
    .metric {
      background: #f9f9f9;
      padding: 20px;
      border-radius: 8px;
      border-left: 4px solid #2196F3;
    }
    .metric-label { font-size: 14px; color: #666; margin-bottom: 8px; }
    .metric-value { font-size: 32px; font-weight: 600; color: #333; }
    .violation {
      background: #fff5f5;
      border-left: 4px solid #F44336;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 4px;
    }
    .violation.serious { background: #fff8e1; border-left-color: #FF9800; }
    .violation.moderate { background: #e3f2fd; border-left-color: #2196F3; }
    .violation.minor { background: #f1f8e9; border-left-color: #8BC34A; }
    .violation-title { font-size: 18px; font-weight: 600; margin-bottom: 10px; }
    .violation-description { color: #666; margin-bottom: 10px; }
    .violation-link { color: #2196F3; text-decoration: none; }
    .violation-nodes { font-size: 14px; color: #999; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Accessibility Report</h1>

    <div class="score">${result.score}/100</div>

    <div class="metrics">
      <div class="metric">
        <div class="metric-label">WCAG Level</div>
        <div class="metric-value">${result.wcagLevel}</div>
      </div>
      <div class="metric">
        <div class="metric-label">Passes</div>
        <div class="metric-value">${result.passes}</div>
      </div>
      <div class="metric">
        <div class="metric-label">Violations</div>
        <div class="metric-value">${result.violations.length}</div>
      </div>
      <div class="metric">
        <div class="metric-label">Incomplete</div>
        <div class="metric-value">${result.incomplete}</div>
      </div>
    </div>

    ${result.violations.length > 0 ? `
      <h2>Violations</h2>
      ${result.violations
        .map(
          v => `
        <div class="violation ${v.impact}">
          <div class="violation-title">${v.help}</div>
          <div class="violation-description">${v.description}</div>
          <a href="${v.helpUrl}" target="_blank" class="violation-link">Learn more →</a>
          <div class="violation-nodes">${v.nodes.length} element(s) affected</div>
        </div>
      `
        )
        .join('')}
    ` : '<p style="color: #4CAF50; font-size: 18px;">✓ No accessibility violations found!</p>'}

    <p style="color: #666; font-size: 14px; margin-top: 40px;">
      Generated on: ${new Date().toLocaleString()}<br>
      Figma-to-Angular Converter - WCAG 2.1 AA Validation
    </p>
  </div>
</body>
</html>
      `;

      await fs.writeFile(outputPath, html, 'utf-8');
      logger.success(`Accessibility report saved: ${outputPath}`);

      return outputPath;
    } catch (error) {
      logger.error('Failed to generate accessibility report', error);
      throw error;
    }
  }
}
