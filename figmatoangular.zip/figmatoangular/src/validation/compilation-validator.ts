/**
 * Compilation Validator
 * Validates that generated TypeScript code compiles successfully
 */

import * as ts from 'typescript';
import * as fs from 'fs-extra';
import * as path from 'path';
import { logger } from '../shared/utils/logger.service';

export interface CompilationOptions {
  strict?: boolean;
  target?: ts.ScriptTarget;
  module?: ts.ModuleKind;
  lib?: string[];
  skipLibCheck?: boolean;
}

export interface CompilationError {
  file: string;
  line: number;
  column: number;
  code: number;
  message: string;
  severity: 'error' | 'warning';
}

export interface CompilationResult {
  success: boolean;
  errors: CompilationError[];
  warnings: CompilationError[];
  diagnostics: ts.Diagnostic[];
  compiledFiles: number;
}

export class CompilationValidator {
  /**
   * Validate a single TypeScript file
   */
  async validateFile(
    filePath: string,
    options: CompilationOptions = {}
  ): Promise<CompilationResult> {
    try {
      logger.debug(`Validating TypeScript file: ${filePath}`);

      const fileContent = await fs.readFile(filePath, 'utf-8');
      const compilerOptions = this.createCompilerOptions(options);

      // Create a virtual file system
      const sourceFile = ts.createSourceFile(
        filePath,
        fileContent,
        compilerOptions.target || ts.ScriptTarget.ES2020,
        true
      );

      // Create program
      const host = this.createCompilerHost(
        { [filePath]: fileContent },
        compilerOptions
      );

      const program = ts.createProgram([filePath], compilerOptions, host);

      // Get diagnostics
      const allDiagnostics = [
        ...program.getSyntacticDiagnostics(sourceFile),
        ...program.getSemanticDiagnostics(sourceFile),
      ];

      const result = this.processDiagnostics(allDiagnostics);

      if (result.success) {
        logger.success(`✓ TypeScript validation passed: ${filePath}`);
      } else {
        logger.error(
          `✗ TypeScript validation failed: ${result.errors.length} errors, ${result.warnings.length} warnings`
        );
      }

      return result;
    } catch (error: any) {
      logger.error('Failed to validate TypeScript file', error);
      return {
        success: false,
        errors: [
          {
            file: filePath,
            line: 0,
            column: 0,
            code: 0,
            message: error.message,
            severity: 'error',
          },
        ],
        warnings: [],
        diagnostics: [],
        compiledFiles: 0,
      };
    }
  }

  /**
   * Validate multiple TypeScript files
   */
  async validateFiles(
    filePaths: string[],
    options: CompilationOptions = {}
  ): Promise<CompilationResult> {
    try {
      logger.info(`Validating ${filePaths.length} TypeScript files...`);

      const compilerOptions = this.createCompilerOptions(options);

      // Read all files
      const fileContents: Record<string, string> = {};
      for (const filePath of filePaths) {
        fileContents[filePath] = await fs.readFile(filePath, 'utf-8');
      }

      // Create compiler host
      const host = this.createCompilerHost(fileContents, compilerOptions);

      // Create program
      const program = ts.createProgram(filePaths, compilerOptions, host);

      // Get all diagnostics
      const allDiagnostics = [
        ...program.getGlobalDiagnostics(),
        ...program.getSemanticDiagnostics(),
        ...program.getSyntacticDiagnostics(),
      ];

      const result = this.processDiagnostics(allDiagnostics);
      result.compiledFiles = filePaths.length;

      if (result.success) {
        logger.success(
          `✓ All TypeScript files validated successfully (${filePaths.length} files)`
        );
      } else {
        logger.error(
          `✗ TypeScript validation failed: ${result.errors.length} errors, ${result.warnings.length} warnings`
        );
      }

      return result;
    } catch (error: any) {
      logger.error('Failed to validate TypeScript files', error);
      return {
        success: false,
        errors: [
          {
            file: 'unknown',
            line: 0,
            column: 0,
            code: 0,
            message: error.message,
            severity: 'error',
          },
        ],
        warnings: [],
        diagnostics: [],
        compiledFiles: 0,
      };
    }
  }

  /**
   * Validate an Angular component (all files)
   */
  async validateComponent(
    componentDir: string,
    componentName: string,
    options: CompilationOptions = {}
  ): Promise<CompilationResult> {
    try {
      logger.debug(`Validating Angular component: ${componentName}`);

      // Find component TypeScript file
      const tsFile = path.join(componentDir, `${componentName}.component.ts`);

      if (!(await fs.pathExists(tsFile))) {
        return {
          success: false,
          errors: [
            {
              file: tsFile,
              line: 0,
              column: 0,
              code: 0,
              message: 'Component TypeScript file not found',
              severity: 'error',
            },
          ],
          warnings: [],
          diagnostics: [],
          compiledFiles: 0,
        };
      }

      return this.validateFile(tsFile, options);
    } catch (error: any) {
      logger.error('Failed to validate component', error);
      return {
        success: false,
        errors: [
          {
            file: componentDir,
            line: 0,
            column: 0,
            code: 0,
            message: error.message,
            severity: 'error',
          },
        ],
        warnings: [],
        diagnostics: [],
        compiledFiles: 0,
      };
    }
  }

  /**
   * Create TypeScript compiler options
   */
  private createCompilerOptions(options: CompilationOptions): ts.CompilerOptions {
    return {
      target: options.target || ts.ScriptTarget.ES2020,
      module: options.module || ts.ModuleKind.ES2020,
      lib: options.lib || ['lib.es2020.d.ts', 'lib.dom.d.ts'],
      strict: options.strict ?? true,
      skipLibCheck: options.skipLibCheck ?? true,
      esModuleInterop: true,
      allowSyntheticDefaultImports: true,
      experimentalDecorators: true,
      emitDecoratorMetadata: true,
      moduleResolution: ts.ModuleResolutionKind.NodeJs,
      resolveJsonModule: true,
      noEmit: true,
      noImplicitAny: true,
      strictNullChecks: true,
      strictFunctionTypes: true,
      strictBindCallApply: true,
      strictPropertyInitialization: false, // Angular inputs
      noImplicitThis: true,
      alwaysStrict: true,
      noUnusedLocals: true,
      noUnusedParameters: true,
      noImplicitReturns: true,
      noFallthroughCasesInSwitch: true,
    };
  }

  /**
   * Create a virtual compiler host
   */
  private createCompilerHost(
    files: Record<string, string>,
    options: ts.CompilerOptions
  ): ts.CompilerHost {
    const host = ts.createCompilerHost(options);

    // Override file reading methods
    host.getSourceFile = (fileName, languageVersion) => {
      if (files[fileName]) {
        return ts.createSourceFile(fileName, files[fileName], languageVersion, true);
      }
      // Try to read from actual file system for library files
      try {
        const content = fs.readFileSync(fileName, 'utf-8');
        return ts.createSourceFile(fileName, content, languageVersion, true);
      } catch {
        return undefined;
      }
    };

    host.fileExists = (fileName) => {
      return !!files[fileName] || fs.existsSync(fileName);
    };

    host.readFile = (fileName) => {
      return files[fileName] || (fs.existsSync(fileName) ? fs.readFileSync(fileName, 'utf-8') : undefined);
    };

    return host;
  }

  /**
   * Process TypeScript diagnostics
   */
  private processDiagnostics(diagnostics: readonly ts.Diagnostic[]): CompilationResult {
    const errors: CompilationError[] = [];
    const warnings: CompilationError[] = [];

    for (const diagnostic of diagnostics) {
      const severity =
        diagnostic.category === ts.DiagnosticCategory.Error ? 'error' : 'warning';

      let file = 'unknown';
      let line = 0;
      let column = 0;

      if (diagnostic.file && diagnostic.start !== undefined) {
        file = diagnostic.file.fileName;
        const position = diagnostic.file.getLineAndCharacterOfPosition(diagnostic.start);
        line = position.line + 1;
        column = position.character + 1;
      }

      const error: CompilationError = {
        file,
        line,
        column,
        code: diagnostic.code,
        message: ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'),
        severity,
      };

      if (severity === 'error') {
        errors.push(error);
      } else {
        warnings.push(error);
      }
    }

    return {
      success: errors.length === 0,
      errors,
      warnings,
      diagnostics: [...diagnostics],
      compiledFiles: 1,
    };
  }

  /**
   * Format compilation result as string
   */
  formatResult(result: CompilationResult): string {
    const lines: string[] = [];

    lines.push(`Compilation Result: ${result.success ? '✓ PASS' : '✗ FAIL'}`);
    lines.push(`Files compiled: ${result.compiledFiles}`);
    lines.push(`Errors: ${result.errors.length}`);
    lines.push(`Warnings: ${result.warnings.length}`);

    if (result.errors.length > 0) {
      lines.push('\nErrors:');
      for (const error of result.errors) {
        lines.push(
          `  ${error.file}:${error.line}:${error.column} - TS${error.code}: ${error.message}`
        );
      }
    }

    if (result.warnings.length > 0) {
      lines.push('\nWarnings:');
      for (const warning of result.warnings) {
        lines.push(
          `  ${warning.file}:${warning.line}:${warning.column} - TS${warning.code}: ${warning.message}`
        );
      }
    }

    return lines.join('\n');
  }
}
