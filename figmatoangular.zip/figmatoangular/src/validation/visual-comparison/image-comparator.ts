/**
 * Image Comparator
 * Compares images using pixelmatch and generates similarity metrics
 */

import * as fs from 'fs-extra';
import { PNG } from 'pngjs';
import pixelmatch from 'pixelmatch';
import { logger } from '../../shared/utils/logger.service';

export interface ComparisonResult {
  similarity: number; // 0-100 (percentage)
  pixelDifference: number; // number of different pixels
  totalPixels: number;
  diffImagePath?: string;
  success: boolean;
  error?: string;
}

export interface ComparisonOptions {
  threshold?: number; // 0-1, sensitivity (default: 0.1)
  includeAntialiasing?: boolean;
  generateDiff?: boolean;
  diffOutputPath?: string;
}

export class ImageComparator {
  /**
   * Compare two images
   */
  async compare(
    image1Path: string,
    image2Path: string,
    options: ComparisonOptions = {}
  ): Promise<ComparisonResult> {
    try {
      logger.debug(`Comparing images: ${image1Path} vs ${image2Path}`);

      // Read images
      const img1 = PNG.sync.read(await fs.readFile(image1Path));
      const img2 = PNG.sync.read(await fs.readFile(image2Path));

      // Check dimensions match
      if (img1.width !== img2.width || img1.height !== img2.height) {
        logger.warn(
          `Image dimensions don't match: ${img1.width}x${img1.height} vs ${img2.width}x${img2.height}`
        );
        // Resize images to match
        return this.compareWithResize(image1Path, image2Path, options);
      }

      const { width, height } = img1;
      const totalPixels = width * height;

      // Create diff image
      const diff = options.generateDiff
        ? new PNG({ width, height })
        : undefined;

      // Compare pixels
      const pixelDifference = pixelmatch(
        img1.data,
        img2.data,
        diff?.data || null,
        width,
        height,
        {
          threshold: options.threshold ?? 0.1,
          includeAA: options.includeAntialiasing ?? false,
        }
      );

      // Calculate similarity
      const similarity = ((totalPixels - pixelDifference) / totalPixels) * 100;

      // Save diff image if requested
      let diffImagePath: string | undefined;
      if (options.generateDiff && diff && options.diffOutputPath) {
        await fs.writeFile(options.diffOutputPath, PNG.sync.write(diff));
        diffImagePath = options.diffOutputPath;
        logger.debug(`Diff image saved: ${diffImagePath}`);
      }

      logger.success(
        `Images compared: ${similarity.toFixed(2)}% similar (${pixelDifference} different pixels)`
      );

      return {
        similarity,
        pixelDifference,
        totalPixels,
        diffImagePath,
        success: true,
      };
    } catch (error: any) {
      logger.error('Failed to compare images', error);
      return {
        similarity: 0,
        pixelDifference: 0,
        totalPixels: 0,
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Compare images with auto-resize
   */
  private async compareWithResize(
    image1Path: string,
    image2Path: string,
    options: ComparisonOptions = {}
  ): Promise<ComparisonResult> {
    try {
      // Read images
      const img1 = PNG.sync.read(await fs.readFile(image1Path));
      const img2 = PNG.sync.read(await fs.readFile(image2Path));

      // Use smaller dimensions
      const width = Math.min(img1.width, img2.width);
      const height = Math.min(img1.height, img2.height);
      const totalPixels = width * height;

      // Create resized buffers
      const resized1 = this.resizeImage(img1, width, height);
      const resized2 = this.resizeImage(img2, width, height);

      // Create diff image
      const diff = options.generateDiff
        ? new PNG({ width, height })
        : undefined;

      // Compare pixels
      const pixelDifference = pixelmatch(
        resized1.data,
        resized2.data,
        diff?.data || null,
        width,
        height,
        {
          threshold: options.threshold ?? 0.1,
          includeAA: options.includeAntialiasing ?? false,
        }
      );

      // Calculate similarity
      const similarity = ((totalPixels - pixelDifference) / totalPixels) * 100;

      // Save diff image if requested
      let diffImagePath: string | undefined;
      if (options.generateDiff && diff && options.diffOutputPath) {
        await fs.writeFile(options.diffOutputPath, PNG.sync.write(diff));
        diffImagePath = options.diffOutputPath;
      }

      logger.success(
        `Images compared (resized): ${similarity.toFixed(2)}% similar`
      );

      return {
        similarity,
        pixelDifference,
        totalPixels,
        diffImagePath,
        success: true,
      };
    } catch (error: any) {
      logger.error('Failed to compare images with resize', error);
      return {
        similarity: 0,
        pixelDifference: 0,
        totalPixels: 0,
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Simple image resize (nearest neighbor)
   */
  private resizeImage(img: PNG, newWidth: number, newHeight: number): PNG {
    const resized = new PNG({ width: newWidth, height: newHeight });

    const xRatio = img.width / newWidth;
    const yRatio = img.height / newHeight;

    for (let y = 0; y < newHeight; y++) {
      for (let x = 0; x < newWidth; x++) {
        const srcX = Math.floor(x * xRatio);
        const srcY = Math.floor(y * yRatio);

        const srcIdx = (srcY * img.width + srcX) * 4;
        const dstIdx = (y * newWidth + x) * 4;

        resized.data[dstIdx] = img.data[srcIdx];
        resized.data[dstIdx + 1] = img.data[srcIdx + 1];
        resized.data[dstIdx + 2] = img.data[srcIdx + 2];
        resized.data[dstIdx + 3] = img.data[srcIdx + 3];
      }
    }

    return resized;
  }

  /**
   * Calculate SSIM (Structural Similarity Index)
   */
  async calculateSSIM(image1Path: string, image2Path: string): Promise<number> {
    try {
      const img1 = PNG.sync.read(await fs.readFile(image1Path));
      const img2 = PNG.sync.read(await fs.readFile(image2Path));

      if (img1.width !== img2.width || img1.height !== img2.height) {
        logger.warn('Images have different dimensions for SSIM calculation');
        return 0;
      }

      // Simplified SSIM calculation (luminance only)
      let sum1 = 0;
      let sum2 = 0;
      let sum1Sq = 0;
      let sum2Sq = 0;
      let sum12 = 0;

      const totalPixels = img1.width * img1.height;

      for (let i = 0; i < img1.data.length; i += 4) {
        // Convert to grayscale
        const gray1 =
          0.299 * img1.data[i] + 0.587 * img1.data[i + 1] + 0.114 * img1.data[i + 2];
        const gray2 =
          0.299 * img2.data[i] + 0.587 * img2.data[i + 1] + 0.114 * img2.data[i + 2];

        sum1 += gray1;
        sum2 += gray2;
        sum1Sq += gray1 * gray1;
        sum2Sq += gray2 * gray2;
        sum12 += gray1 * gray2;
      }

      const mean1 = sum1 / totalPixels;
      const mean2 = sum2 / totalPixels;
      const variance1 = sum1Sq / totalPixels - mean1 * mean1;
      const variance2 = sum2Sq / totalPixels - mean2 * mean2;
      const covariance = sum12 / totalPixels - mean1 * mean2;

      const c1 = 6.5025; // (0.01 * 255)^2
      const c2 = 58.5225; // (0.03 * 255)^2

      const ssim =
        ((2 * mean1 * mean2 + c1) * (2 * covariance + c2)) /
        ((mean1 * mean1 + mean2 * mean2 + c1) * (variance1 + variance2 + c2));

      return Math.max(0, Math.min(1, ssim));
    } catch (error) {
      logger.error('Failed to calculate SSIM', error);
      return 0;
    }
  }
}
