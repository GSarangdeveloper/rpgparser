/**
 * Screenshot Capturer
 * Captures screenshots using Puppeteer
 */

import puppeteer, { Browser, Page } from 'puppeteer';
import * as path from 'path';
import { logger } from '../../shared/utils/logger.service';

export interface ScreenshotOptions {
  width?: number;
  height?: number;
  fullPage?: boolean;
  selector?: string;
  delay?: number; // ms to wait before capturing
}

export interface ScreenshotResult {
  path: string;
  width: number;
  height: number;
  success: boolean;
  error?: string;
}

export class ScreenshotCapturer {
  private browser: Browser | null = null;

  /**
   * Initialize browser
   */
  async init(): Promise<void> {
    if (!this.browser) {
      logger.debug('Launching Puppeteer browser...');
      this.browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
      });
      logger.success('Browser launched');
    }
  }

  /**
   * Close browser
   */
  async close(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      logger.debug('Browser closed');
    }
  }

  /**
   * Capture screenshot from HTML file
   */
  async captureFromHtml(
    htmlPath: string,
    outputPath: string,
    options: ScreenshotOptions = {}
  ): Promise<ScreenshotResult> {
    try {
      await this.init();

      logger.debug(`Capturing screenshot from: ${htmlPath}`);

      const page = await this.browser!.newPage();

      // Set viewport
      await page.setViewport({
        width: options.width || 1280,
        height: options.height || 800,
      });

      // Load HTML file
      const fileUrl = `file://${path.resolve(htmlPath)}`;
      await page.goto(fileUrl, { waitUntil: 'networkidle0' });

      // Wait if specified
      if (options.delay) {
        await page.waitForTimeout(options.delay);
      }

      // Capture screenshot
      let screenshotOptions: any = {
        path: outputPath,
        fullPage: options.fullPage ?? false,
      };

      if (options.selector) {
        const element = await page.$(options.selector);
        if (element) {
          await element.screenshot({ path: outputPath });
        } else {
          throw new Error(`Selector not found: ${options.selector}`);
        }
      } else {
        await page.screenshot(screenshotOptions);
      }

      // Get dimensions
      const dimensions = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        height: document.documentElement.scrollHeight,
      }));

      await page.close();

      logger.success(`Screenshot captured: ${outputPath}`);

      return {
        path: outputPath,
        width: dimensions.width,
        height: dimensions.height,
        success: true,
      };
    } catch (error: any) {
      logger.error('Failed to capture screenshot', error);
      return {
        path: outputPath,
        width: 0,
        height: 0,
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Capture screenshot from HTML string
   */
  async captureFromHtmlString(
    html: string,
    outputPath: string,
    options: ScreenshotOptions = {}
  ): Promise<ScreenshotResult> {
    try {
      await this.init();

      logger.debug('Capturing screenshot from HTML string');

      const page = await this.browser!.newPage();

      // Set viewport
      await page.setViewport({
        width: options.width || 1280,
        height: options.height || 800,
      });

      // Set content
      await page.setContent(html, { waitUntil: 'networkidle0' });

      // Wait if specified
      if (options.delay) {
        await page.waitForTimeout(options.delay);
      }

      // Capture screenshot
      await page.screenshot({
        path: outputPath,
        fullPage: options.fullPage ?? false,
      });

      // Get dimensions
      const dimensions = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        height: document.documentElement.scrollHeight,
      }));

      await page.close();

      logger.success(`Screenshot captured: ${outputPath}`);

      return {
        path: outputPath,
        width: dimensions.width,
        height: dimensions.height,
        success: true,
      };
    } catch (error: any) {
      logger.error('Failed to capture screenshot', error);
      return {
        path: outputPath,
        width: 0,
        height: 0,
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Render Angular component and capture screenshot
   */
  async captureAngularComponent(
    componentHtml: string,
    componentCss: string,
    outputPath: string,
    options: ScreenshotOptions = {}
  ): Promise<ScreenshotResult> {
    // Create complete HTML with styles
    const fullHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Component Preview</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      padding: 20px;
      background: #ffffff;
    }
    ${componentCss}
  </style>
</head>
<body>
  ${componentHtml}
</body>
</html>
    `;

    return this.captureFromHtmlString(fullHtml, outputPath, options);
  }
}
