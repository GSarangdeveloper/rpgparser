/**
 * Diff Generator
 * Generates visual diff images and reports
 */

import * as fs from 'fs-extra';
import * as path from 'path';
import { PNG } from 'pngjs';
import { logger } from '../../shared/utils/logger.service';
import { ComparisonResult } from './image-comparator';

export interface DiffReport {
  figmaImage: string;
  generatedImage: string;
  diffImage: string;
  similarity: number;
  differences: DifferenceDetail[];
  htmlReportPath?: string;
}

export interface DifferenceDetail {
  area: 'layout' | 'color' | 'spacing' | 'typography' | 'other';
  severity: 'critical' | 'major' | 'minor';
  description: string;
  location?: { x: number; y: number; width: number; height: number };
}

export class DiffGenerator {
  /**
   * Generate side-by-side comparison image
   */
  async generateSideBySide(
    image1Path: string,
    image2Path: string,
    outputPath: string
  ): Promise<string> {
    try {
      logger.debug('Generating side-by-side comparison');

      const img1 = PNG.sync.read(await fs.readFile(image1Path));
      const img2 = PNG.sync.read(await fs.readFile(image2Path));

      const maxHeight = Math.max(img1.height, img2.height);
      const totalWidth = img1.width + img2.width + 20; // 20px gap

      // Create output image
      const output = new PNG({ width: totalWidth, height: maxHeight });

      // Fill with white background
      output.data.fill(255);

      // Copy first image
      for (let y = 0; y < img1.height; y++) {
        for (let x = 0; x < img1.width; x++) {
          const srcIdx = (y * img1.width + x) * 4;
          const dstIdx = (y * totalWidth + x) * 4;

          output.data[dstIdx] = img1.data[srcIdx];
          output.data[dstIdx + 1] = img1.data[srcIdx + 1];
          output.data[dstIdx + 2] = img1.data[srcIdx + 2];
          output.data[dstIdx + 3] = img1.data[srcIdx + 3];
        }
      }

      // Copy second image (offset)
      const offsetX = img1.width + 20;
      for (let y = 0; y < img2.height; y++) {
        for (let x = 0; x < img2.width; x++) {
          const srcIdx = (y * img2.width + x) * 4;
          const dstIdx = (y * totalWidth + (x + offsetX)) * 4;

          output.data[dstIdx] = img2.data[srcIdx];
          output.data[dstIdx + 1] = img2.data[srcIdx + 1];
          output.data[dstIdx + 2] = img2.data[srcIdx + 2];
          output.data[dstIdx + 3] = img2.data[srcIdx + 3];
        }
      }

      await fs.writeFile(outputPath, PNG.sync.write(output));
      logger.success(`Side-by-side comparison saved: ${outputPath}`);

      return outputPath;
    } catch (error) {
      logger.error('Failed to generate side-by-side comparison', error);
      throw error;
    }
  }

  /**
   * Generate HTML comparison report
   */
  async generateHtmlReport(
    figmaImagePath: string,
    generatedImagePath: string,
    diffImagePath: string,
    comparison: ComparisonResult,
    outputPath: string
  ): Promise<string> {
    try {
      logger.debug('Generating HTML comparison report');

      const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Visual Comparison Report</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      background: #f5f5f5;
      padding: 40px 20px;
    }

    .container {
      max-width: 1400px;
      margin: 0 auto;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      padding: 40px;
    }

    h1 {
      font-size: 32px;
      margin-bottom: 30px;
      color: #333;
    }

    .metrics {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 40px;
    }

    .metric {
      background: #f9f9f9;
      padding: 20px;
      border-radius: 8px;
      border-left: 4px solid #4CAF50;
    }

    .metric.warning {
      border-left-color: #FF9800;
    }

    .metric.error {
      border-left-color: #F44336;
    }

    .metric-label {
      font-size: 14px;
      color: #666;
      margin-bottom: 8px;
    }

    .metric-value {
      font-size: 32px;
      font-weight: 600;
      color: #333;
    }

    .metric-unit {
      font-size: 18px;
      color: #999;
    }

    .comparison-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
      gap: 30px;
      margin-bottom: 40px;
    }

    .image-box {
      background: #fafafa;
      border-radius: 8px;
      overflow: hidden;
      border: 1px solid #e0e0e0;
    }

    .image-box h3 {
      padding: 15px 20px;
      background: #333;
      color: white;
      font-size: 16px;
    }

    .image-box img {
      width: 100%;
      display: block;
      background: white;
    }

    .status {
      display: inline-block;
      padding: 8px 16px;
      border-radius: 4px;
      font-weight: 600;
      font-size: 14px;
    }

    .status.success {
      background: #4CAF50;
      color: white;
    }

    .status.warning {
      background: #FF9800;
      color: white;
    }

    .status.error {
      background: #F44336;
      color: white;
    }

    .slider-container {
      position: relative;
      margin-bottom: 40px;
    }

    .slider {
      width: 100%;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Visual Comparison Report</h1>

    <div class="metrics">
      <div class="metric ${comparison.similarity >= 90 ? '' : comparison.similarity >= 70 ? 'warning' : 'error'}">
        <div class="metric-label">Similarity</div>
        <div class="metric-value">${comparison.similarity.toFixed(1)}<span class="metric-unit">%</span></div>
      </div>

      <div class="metric">
        <div class="metric-label">Different Pixels</div>
        <div class="metric-value">${comparison.pixelDifference.toLocaleString()}</div>
      </div>

      <div class="metric">
        <div class="metric-label">Total Pixels</div>
        <div class="metric-value">${comparison.totalPixels.toLocaleString()}</div>
      </div>

      <div class="metric">
        <div class="metric-label">Status</div>
        <div>
          <span class="status ${comparison.similarity >= 90 ? 'success' : comparison.similarity >= 70 ? 'warning' : 'error'}">
            ${comparison.similarity >= 90 ? 'PASS' : comparison.similarity >= 70 ? 'WARNING' : 'FAIL'}
          </span>
        </div>
      </div>
    </div>

    <div class="comparison-grid">
      <div class="image-box">
        <h3>Figma Design</h3>
        <img src="${path.basename(figmaImagePath)}" alt="Figma Design">
      </div>

      <div class="image-box">
        <h3>Generated Component</h3>
        <img src="${path.basename(generatedImagePath)}" alt="Generated Component">
      </div>

      <div class="image-box" style="grid-column: 1 / -1;">
        <h3>Visual Diff (Differences in Red)</h3>
        <img src="${path.basename(diffImagePath)}" alt="Visual Diff">
      </div>
    </div>

    <p style="color: #666; font-size: 14px;">
      Generated on: ${new Date().toLocaleString()}<br>
      Figma-to-Angular Converter
    </p>
  </div>
</body>
</html>
      `;

      await fs.writeFile(outputPath, html, 'utf-8');
      logger.success(`HTML report saved: ${outputPath}`);

      return outputPath;
    } catch (error) {
      logger.error('Failed to generate HTML report', error);
      throw error;
    }
  }

  /**
   * Analyze differences and categorize
   */
  async analyzeDifferences(
    diffImagePath: string
  ): Promise<DifferenceDetail[]> {
    try {
      const diff = PNG.sync.read(await fs.readFile(diffImagePath));
      const differences: DifferenceDetail[] = [];

      // Count different pixels by region
      let diffPixelCount = 0;
      for (let i = 0; i < diff.data.length; i += 4) {
        // Check if pixel is marked as different (red in diff image)
        if (diff.data[i] > 200 && diff.data[i + 1] < 100 && diff.data[i + 2] < 100) {
          diffPixelCount++;
        }
      }

      const totalPixels = diff.width * diff.height;
      const diffPercentage = (diffPixelCount / totalPixels) * 100;

      if (diffPercentage > 10) {
        differences.push({
          area: 'layout',
          severity: 'critical',
          description: `Significant layout differences detected (${diffPercentage.toFixed(1)}% of pixels)`,
        });
      } else if (diffPercentage > 5) {
        differences.push({
          area: 'layout',
          severity: 'major',
          description: `Moderate layout differences detected (${diffPercentage.toFixed(1)}% of pixels)`,
        });
      } else if (diffPercentage > 1) {
        differences.push({
          area: 'color',
          severity: 'minor',
          description: `Minor color or styling differences detected (${diffPercentage.toFixed(1)}% of pixels)`,
        });
      }

      return differences;
    } catch (error) {
      logger.error('Failed to analyze differences', error);
      return [];
    }
  }
}
