import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from '../../../environments/environment';

export interface ConversionSettings {
  approach: 'llm' | 'rule-based' | 'hybrid';
  llmProvider?: 'openai' | 'anthropic' | 'azure';
  llmModel?: string;
  temperature?: number;
  maxTokens?: number;
  maxCost?: number;
  validation: {
    validateVisual: boolean;
    validateAccessibility: boolean;
    validateCompilation: boolean;
    strictMode: boolean;
  };
  optimization: {
    optimizeImages: boolean;
    minifyCode: boolean;
    treeshake: boolean;
  };
  output: {
    generateTests: boolean;
    generateStorybook: boolean;
    generateDocumentation: boolean;
  };
  useCache: boolean;
  parallelProcessing: boolean;
}

@Component({
  selector: 'app-conversion-settings',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './conversion-settings.component.html',
  styleUrls: ['./conversion-settings.component.scss']
})
export class ConversionSettingsComponent implements OnInit {
  @Input() initialSettings?: Partial<ConversionSettings>;
  @Output() settingsChanged = new EventEmitter<ConversionSettings>();
  @Output() startConversion = new EventEmitter<ConversionSettings>();

  settingsForm: FormGroup;
  showAdvancedSettings = false;
  costEstimate = 0;

  // Available options
  approaches = [
    { value: 'llm', label: 'AI-Powered (LLM)', description: 'Uses AI to understand and convert designs intelligently' },
    { value: 'rule-based', label: 'Rule-Based', description: 'Traditional parsing and transformation rules' },
    { value: 'hybrid', label: 'Hybrid', description: 'Combines both approaches for best results' }
  ];

  llmProviders = [
    { value: 'openai', label: 'OpenAI', models: ['gpt-4-vision-preview', 'gpt-4-turbo', 'gpt-3.5-turbo'] },
    { value: 'anthropic', label: 'Anthropic', models: ['claude-3-opus', 'claude-3-sonnet', 'claude-3-haiku'] },
    { value: 'azure', label: 'Azure OpenAI', models: ['gpt-4', 'gpt-35-turbo'] }
  ];

  availableModels: string[] = [];

  constructor(private fb: FormBuilder) {
    this.settingsForm = this.createForm();
  }

  ngOnInit(): void {
    // Load initial settings from environment or input
    const defaultSettings = this.getDefaultSettings();
    const settings = { ...defaultSettings, ...this.initialSettings };

    this.settingsForm.patchValue(settings);
    this.updateAvailableModels();
    this.calculateCostEstimate();

    // Subscribe to form changes
    this.settingsForm.valueChanges.subscribe((value) => {
      this.calculateCostEstimate();
      this.settingsChanged.emit(value as ConversionSettings);
    });

    // Update models when provider changes
    this.settingsForm.get('llmProvider')?.valueChanges.subscribe(() => {
      this.updateAvailableModels();
    });
  }

  private createForm(): FormGroup {
    return this.fb.group({
      approach: ['llm', Validators.required],
      llmProvider: ['openai'],
      llmModel: ['gpt-4-vision-preview'],
      temperature: [0.3, [Validators.min(0), Validators.max(1)]],
      maxTokens: [8000, [Validators.min(100), Validators.max(32000)]],
      maxCost: [1.00, [Validators.min(0.01), Validators.max(10)]],
      validation: this.fb.group({
        validateVisual: [true],
        validateAccessibility: [true],
        validateCompilation: [true],
        strictMode: [false]
      }),
      optimization: this.fb.group({
        optimizeImages: [true],
        minifyCode: [false],
        treeshake: [true]
      }),
      output: this.fb.group({
        generateTests: [true],
        generateStorybook: [false],
        generateDocumentation: [true]
      }),
      useCache: [true],
      parallelProcessing: [true]
    });
  }

  private getDefaultSettings(): ConversionSettings {
    return {
      approach: (environment.conversion?.defaultApproach || 'llm') as 'llm' | 'rule-based' | 'hybrid',
      llmProvider: (environment.llm?.provider || 'openai') as 'openai' | 'anthropic' | 'azure',
      llmModel: environment.llm?.model || 'gpt-4-vision-preview',
      temperature: environment.llm?.temperature || 0.3,
      maxTokens: environment.llm?.maxTokens || 8000,
      maxCost: environment.llm?.maxCostPerConversion || 1.00,
      validation: {
        validateVisual: environment.conversion?.validation?.validateVisual ?? true,
        validateAccessibility: environment.conversion?.validation?.validateAccessibility ?? true,
        validateCompilation: environment.conversion?.validation?.validateCompilation ?? true,
        strictMode: environment.conversion?.validation?.strictMode ?? false
      },
      optimization: {
        optimizeImages: environment.conversion?.optimization?.optimizeImages ?? true,
        minifyCode: environment.conversion?.optimization?.minifyCode ?? false,
        treeshake: environment.conversion?.optimization?.treeshake ?? true
      },
      output: {
        generateTests: environment.conversion?.output?.generateTests ?? true,
        generateStorybook: environment.conversion?.output?.generateStorybook ?? false,
        generateDocumentation: environment.conversion?.output?.generateDocumentation ?? true
      },
      useCache: true,
      parallelProcessing: environment.conversion?.parallelProcessing ?? true
    };
  }

  onApproachChange(): void {
    const approach = this.settingsForm.get('approach')?.value;

    // Enable/disable LLM settings based on approach
    if (approach === 'rule-based') {
      this.settingsForm.get('llmProvider')?.disable();
      this.settingsForm.get('llmModel')?.disable();
      this.settingsForm.get('temperature')?.disable();
      this.settingsForm.get('maxTokens')?.disable();
      this.settingsForm.get('maxCost')?.disable();
    } else {
      this.settingsForm.get('llmProvider')?.enable();
      this.settingsForm.get('llmModel')?.enable();
      this.settingsForm.get('temperature')?.enable();
      this.settingsForm.get('maxTokens')?.enable();
      this.settingsForm.get('maxCost')?.enable();
    }
  }

  updateAvailableModels(): void {
    const provider = this.settingsForm.get('llmProvider')?.value;
    const providerConfig = this.llmProviders.find(p => p.value === provider);
    this.availableModels = providerConfig?.models || [];

    // Set first model as default if current model not available
    const currentModel = this.settingsForm.get('llmModel')?.value;
    if (!this.availableModels.includes(currentModel) && this.availableModels.length > 0) {
      this.settingsForm.get('llmModel')?.setValue(this.availableModels[0]);
    }
  }

  calculateCostEstimate(): void {
    const approach = this.settingsForm.get('approach')?.value;
    // const provider = this.settingsForm.get('llmProvider')?.value; // Unused variable
    const model = this.settingsForm.get('llmModel')?.value;

    if (approach === 'rule-based') {
      this.costEstimate = 0;
      return;
    }

    // Estimate based on average tokens and model pricing
    const avgInputTokens = 4000;
    const avgOutputTokens = 2000;

    const pricing: any = {
      'gpt-4-vision-preview': { input: 0.01, output: 0.03 },
      'gpt-4-turbo': { input: 0.01, output: 0.03 },
      'gpt-3.5-turbo': { input: 0.0005, output: 0.0015 },
      'claude-3-opus': { input: 0.015, output: 0.075 },
      'claude-3-sonnet': { input: 0.003, output: 0.015 },
      'claude-3-haiku': { input: 0.00025, output: 0.00125 }
    };

    const modelPricing = pricing[model] || { input: 0.01, output: 0.03 };

    this.costEstimate = (avgInputTokens / 1000) * modelPricing.input +
                       (avgOutputTokens / 1000) * modelPricing.output;

    if (approach === 'hybrid') {
      this.costEstimate *= 1.5; // Hybrid uses more LLM calls
    }
  }

  toggleAdvancedSettings(): void {
    this.showAdvancedSettings = !this.showAdvancedSettings;
  }

  resetToDefaults(): void {
    const defaultSettings = this.getDefaultSettings();
    this.settingsForm.patchValue(defaultSettings);
  }

  saveAsProfile(): void {
    const settings = this.settingsForm.value;
    const profileName = prompt('Enter a name for this profile:');

    if (profileName) {
      const profiles = JSON.parse(localStorage.getItem('conversion-profiles') || '{}');
      profiles[profileName] = settings;
      localStorage.setItem('conversion-profiles', JSON.stringify(profiles));
      alert(`Profile "${profileName}" saved successfully!`);
    }
  }

  loadProfile(): void {
    const profiles = JSON.parse(localStorage.getItem('conversion-profiles') || '{}');
    const profileNames = Object.keys(profiles);

    if (profileNames.length === 0) {
      alert('No saved profiles found');
      return;
    }

    const profileName = prompt(`Select a profile:\n${profileNames.join('\n')}`);

    if (profileName && profiles[profileName]) {
      this.settingsForm.patchValue(profiles[profileName]);
      alert(`Profile "${profileName}" loaded successfully!`);
    }
  }

  onStartConversion(): void {
    if (this.settingsForm.valid) {
      const settings = this.settingsForm.value as ConversionSettings;

      // Check API key configuration
      if (settings.approach !== 'rule-based' && !this.hasApiKey(settings.llmProvider)) {
        alert(`Please configure your ${settings.llmProvider} API key in the environment settings`);
        return;
      }

      this.startConversion.emit(settings);
    } else {
      alert('Please fix the validation errors before starting conversion');
    }
  }

  private hasApiKey(_provider?: string): boolean {
    // Check if API key is configured (this is simplified - real implementation would check securely)
    return !!environment.llm?.apiKey;
  }

  getApproachDescription(): string {
    const approach = this.settingsForm.get('approach')?.value;
    const descriptions: { [key: string]: string } = {
      'llm': 'AI analyzes your design and generates Angular components intelligently, understanding context and intent.',
      'rule-based': 'Uses predefined transformation rules to convert React/Tailwind to Angular systematically.',
      'hybrid': 'Combines rule-based transformation with AI enhancement for optimal results.'
    };
    return descriptions[approach] || '';
  }

  getCostWarning(): string {
    const maxCost = this.settingsForm.get('maxCost')?.value;

    if (this.costEstimate > maxCost) {
      return `Estimated cost ($${this.costEstimate.toFixed(2)}) exceeds max cost limit ($${maxCost.toFixed(2)})`;
    }

    if (this.costEstimate > 0.5) {
      return `Higher cost due to premium model selection`;
    }

    return '';
  }
}