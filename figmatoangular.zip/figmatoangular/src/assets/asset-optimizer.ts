/**
 * Asset Optimizer
 * Optimizes images using Sharp
 */

import sharp from 'sharp';
import * as fs from 'fs-extra';
import * as path from 'path';
import { logger } from '../shared/utils/logger.service';

export interface OptimizationOptions {
  quality?: number; // 1-100
  maxWidth?: number;
  maxHeight?: number;
  convertToWebP?: boolean;
  generateResponsive?: boolean; // Generate @2x, @3x versions
}

export interface OptimizationResult {
  originalPath: string;
  optimizedPath: string;
  originalSize: number;
  optimizedSize: number;
  savings: number; // percentage
  success: boolean;
  error?: string;
}

export class AssetOptimizer {
  /**
   * Optimize a single image
   */
  async optimizeImage(
    inputPath: string,
    outputPath: string,
    options: OptimizationOptions = {}
  ): Promise<OptimizationResult> {
    try {
      logger.debug(`Optimizing image: ${inputPath}`);

      const originalSize = await this.getFileSize(inputPath);

      // Load image
      let image = sharp(inputPath);

      // Resize if needed
      if (options.maxWidth || options.maxHeight) {
        image = image.resize(options.maxWidth, options.maxHeight, {
          fit: 'inside',
          withoutEnlargement: true,
        });
      }

      // Get format
      const ext = path.extname(inputPath).toLowerCase();

      // Optimize based on format
      if (options.convertToWebP) {
        image = image.webp({ quality: options.quality || 80 });
        outputPath = outputPath.replace(/\.(png|jpg|jpeg)$/, '.webp');
      } else if (ext === '.png') {
        image = image.png({
          quality: options.quality || 80,
          compressionLevel: 9,
        });
      } else if (ext === '.jpg' || ext === '.jpeg') {
        image = image.jpeg({
          quality: options.quality || 80,
          progressive: true,
        });
      }

      // Save optimized image
      await fs.ensureDir(path.dirname(outputPath));
      await image.toFile(outputPath);

      const optimizedSize = await this.getFileSize(outputPath);
      const savings = ((originalSize - optimizedSize) / originalSize) * 100;

      logger.success(
        `Image optimized: ${this.formatSize(originalSize)} → ${this.formatSize(optimizedSize)} (${savings.toFixed(1)}% saved)`
      );

      return {
        originalPath: inputPath,
        optimizedPath: outputPath,
        originalSize,
        optimizedSize,
        savings,
        success: true,
      };
    } catch (error: any) {
      logger.error(`Failed to optimize image: ${inputPath}`, error);
      return {
        originalPath: inputPath,
        optimizedPath: outputPath,
        originalSize: 0,
        optimizedSize: 0,
        savings: 0,
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Optimize multiple images
   */
  async optimizeImages(
    inputPaths: string[],
    outputDir: string,
    options: OptimizationOptions = {}
  ): Promise<OptimizationResult[]> {
    logger.info(`Optimizing ${inputPaths.length} images...`);

    const results: OptimizationResult[] = [];

    for (const inputPath of inputPaths) {
      const fileName = path.basename(inputPath);
      const outputPath = path.join(outputDir, fileName);

      const result = await this.optimizeImage(inputPath, outputPath, options);
      results.push(result);
    }

    const successCount = results.filter(r => r.success).length;
    const totalSavings = results.reduce((sum, r) => sum + r.savings, 0) / results.length;

    logger.success(
      `Optimized ${successCount}/${inputPaths.length} images (avg ${totalSavings.toFixed(1)}% saved)`
    );

    return results;
  }

  /**
   * Generate responsive images (@2x, @3x)
   */
  async generateResponsiveImages(
    inputPath: string,
    outputDir: string
  ): Promise<string[]> {
    try {
      logger.debug(`Generating responsive images for: ${inputPath}`);

      const baseName = path.basename(inputPath, path.extname(inputPath));
      const ext = path.extname(inputPath);

      const scales = [
        { suffix: '', scale: 1 },
        { suffix: '@2x', scale: 2 },
        { suffix: '@3x', scale: 3 },
      ];

      const outputPaths: string[] = [];

      // Get original dimensions
      const metadata = await sharp(inputPath).metadata();
      const baseWidth = metadata.width;
      const baseHeight = metadata.height;

      if (!baseWidth || !baseHeight) {
        throw new Error('Could not determine image dimensions');
      }

      for (const { suffix, scale } of scales) {
        const outputPath = path.join(outputDir, `${baseName}${suffix}${ext}`);

        await sharp(inputPath)
          .resize(Math.round(baseWidth * scale), Math.round(baseHeight * scale))
          .toFile(outputPath);

        outputPaths.push(outputPath);
      }

      logger.success(`Generated ${scales.length} responsive images`);
      return outputPaths;
    } catch (error) {
      logger.error('Failed to generate responsive images', error);
      throw error;
    }
  }

  /**
   * Convert image to WebP
   */
  async convertToWebP(inputPath: string, outputPath?: string): Promise<string> {
    try {
      if (!outputPath) {
        outputPath = inputPath.replace(/\.(png|jpg|jpeg)$/, '.webp');
      }

      await sharp(inputPath).webp({ quality: 80 }).toFile(outputPath);

      logger.success(`Converted to WebP: ${outputPath}`);
      return outputPath;
    } catch (error) {
      logger.error('Failed to convert to WebP', error);
      throw error;
    }
  }

  /**
   * Get file size
   */
  private async getFileSize(filePath: string): Promise<number> {
    try {
      const stats = await fs.stat(filePath);
      return stats.size;
    } catch {
      return 0;
    }
  }

  /**
   * Format file size
   */
  private formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
}
