/**
 * Asset Downloader
 * Downloads images, icons, and other assets from Figma
 */

import axios from 'axios';
import * as fs from 'fs-extra';
import * as path from 'path';
import { logger } from '../shared/utils/logger.service';

export interface AssetInfo {
  id: string;
  name: string;
  url: string;
  format: 'png' | 'jpg' | 'svg' | 'pdf';
  size?: number;
}

export interface DownloadResult {
  asset: AssetInfo;
  localPath: string;
  success: boolean;
  error?: string;
}

export class AssetDownloader {
  constructor(private accessToken: string) {}

  /**
   * Get image URLs for nodes from Figma API
   */
  async getImageUrls(
    fileKey: string,
    nodeIds: string[],
    format: 'png' | 'jpg' | 'svg' | 'pdf' = 'png',
    scale: number = 2
  ): Promise<Record<string, string>> {
    try {
      logger.info(`Fetching image URLs for ${nodeIds.length} nodes`);

      const response = await axios.get(
        `https://api.figma.com/v1/images/${fileKey}`,
        {
          params: {
            ids: nodeIds.join(','),
            format,
            scale,
          },
          headers: {
            'X-Figma-Token': this.accessToken,
          },
        }
      );

      const images = response.data.images || {};
      logger.success(`Retrieved ${Object.keys(images).length} image URLs`);
      return images;
    } catch (error) {
      logger.error('Failed to get image URLs from Figma', error);
      throw error;
    }
  }

  /**
   * Download a single asset
   */
  async downloadAsset(url: string, outputPath: string): Promise<void> {
    try {
      logger.debug(`Downloading asset: ${url}`);

      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 30000,
      });

      await fs.ensureDir(path.dirname(outputPath));
      await fs.writeFile(outputPath, response.data);

      logger.success(`Asset downloaded: ${outputPath}`);
    } catch (error) {
      logger.error(`Failed to download asset: ${url}`, error);
      throw error;
    }
  }

  /**
   * Download multiple assets
   */
  async downloadAssets(
    assets: AssetInfo[],
    outputDir: string
  ): Promise<DownloadResult[]> {
    logger.info(`Downloading ${assets.length} assets...`);

    const results: DownloadResult[] = [];

    for (const asset of assets) {
      try {
        const fileName = this.sanitizeFileName(asset.name);
        const ext = asset.format;
        const localPath = path.join(outputDir, `${fileName}.${ext}`);

        await this.downloadAsset(asset.url, localPath);

        results.push({
          asset,
          localPath,
          success: true,
        });
      } catch (error: any) {
        logger.error(`Failed to download asset: ${asset.name}`, error);
        results.push({
          asset,
          localPath: '',
          success: false,
          error: error.message,
        });
      }
    }

    const successCount = results.filter(r => r.success).length;
    logger.success(`Downloaded ${successCount}/${assets.length} assets`);

    return results;
  }

  /**
   * Download all assets from Figma file
   */
  async downloadFileAssets(
    fileKey: string,
    nodeIds: string[],
    outputDir: string,
    format: 'png' | 'jpg' | 'svg' = 'png'
  ): Promise<DownloadResult[]> {
    try {
      // Get image URLs from Figma
      const imageUrls = await this.getImageUrls(fileKey, nodeIds, format);

      // Prepare asset info
      const assets: AssetInfo[] = Object.entries(imageUrls).map(([id, url]) => ({
        id,
        name: id.replace(/:/g, '-'),
        url,
        format,
      }));

      // Download all assets
      return await this.downloadAssets(assets, outputDir);
    } catch (error) {
      logger.error('Failed to download file assets', error);
      throw error;
    }
  }

  /**
   * Sanitize file name
   */
  private sanitizeFileName(name: string): string {
    return name
      .replace(/[^a-z0-9-_]/gi, '-')
      .replace(/-+/g, '-')
      .toLowerCase();
  }

  /**
   * Get asset file size
   */
  async getAssetSize(filePath: string): Promise<number> {
    try {
      const stats = await fs.stat(filePath);
      return stats.size;
    } catch {
      return 0;
    }
  }
}
