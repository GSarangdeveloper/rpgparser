/**
 * SVG Processor
 * Processes and optimizes SVG files using SVGO
 */

import { optimize, Config } from 'svgo';
import * as fs from 'fs-extra';
import * as path from 'path';
import { logger } from '../shared/utils/logger.service';

export interface SvgProcessingOptions {
  removeViewBox?: boolean;
  removeDimensions?: boolean;
  cleanupIds?: boolean;
  minifyStyles?: boolean;
  convertColors?: boolean;
  inlineStyles?: boolean;
}

export interface SvgProcessingResult {
  originalPath: string;
  processedPath: string;
  originalSize: number;
  processedSize: number;
  savings: number;
  success: boolean;
  error?: string;
}

export class SvgProcessor {
  /**
   * Process and optimize a single SVG
   */
  async processSvg(
    inputPath: string,
    outputPath: string,
    options: SvgProcessingOptions = {}
  ): Promise<SvgProcessingResult> {
    try {
      logger.debug(`Processing SVG: ${inputPath}`);

      // Read SVG file
      const svgContent = await fs.readFile(inputPath, 'utf-8');
      const originalSize = Buffer.byteLength(svgContent, 'utf-8');

      // Configure SVGO
      const plugins: any[] = [
        {
          name: 'preset-default',
          params: {
            overrides: {
              removeViewBox: options.removeViewBox ?? false,
              cleanupIds: false,
            },
          },
        },
      ];

      if (options.removeDimensions) plugins.push('removeDimensions');
      if (options.minifyStyles) plugins.push('minifyStyles');
      if (options.convertColors) plugins.push('convertColors');
      if (options.inlineStyles) plugins.push('inlineStyles');

      const svgoConfig: Config = {
        plugins,
      };

      // Optimize SVG
      const result = optimize(svgContent, svgoConfig);
      const optimizedSvg = result.data;

      // Write optimized SVG
      await fs.ensureDir(path.dirname(outputPath));
      await fs.writeFile(outputPath, optimizedSvg, 'utf-8');

      const processedSize = Buffer.byteLength(optimizedSvg, 'utf-8');
      const savings = ((originalSize - processedSize) / originalSize) * 100;

      logger.success(
        `SVG processed: ${this.formatSize(originalSize)} → ${this.formatSize(processedSize)} (${savings.toFixed(1)}% saved)`
      );

      return {
        originalPath: inputPath,
        processedPath: outputPath,
        originalSize,
        processedSize,
        savings,
        success: true,
      };
    } catch (error: any) {
      logger.error(`Failed to process SVG: ${inputPath}`, error);
      return {
        originalPath: inputPath,
        processedPath: outputPath,
        originalSize: 0,
        processedSize: 0,
        savings: 0,
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Process multiple SVG files
   */
  async processSvgs(
    inputPaths: string[],
    outputDir: string,
    options: SvgProcessingOptions = {}
  ): Promise<SvgProcessingResult[]> {
    logger.info(`Processing ${inputPaths.length} SVG files...`);

    const results: SvgProcessingResult[] = [];

    for (const inputPath of inputPaths) {
      const fileName = path.basename(inputPath);
      const outputPath = path.join(outputDir, fileName);

      const result = await this.processSvg(inputPath, outputPath, options);
      results.push(result);
    }

    const successCount = results.filter(r => r.success).length;
    const totalSavings = results.reduce((sum, r) => sum + r.savings, 0) / results.length;

    logger.success(
      `Processed ${successCount}/${inputPaths.length} SVGs (avg ${totalSavings.toFixed(1)}% saved)`
    );

    return results;
  }

  /**
   * Convert SVG to inline data URI
   */
  async svgToDataUri(inputPath: string): Promise<string> {
    try {
      const svgContent = await fs.readFile(inputPath, 'utf-8');

      // Optimize first
      const result = optimize(svgContent, {
        plugins: ['preset-default'],
      });

      // Convert to data URI
      const encoded = Buffer.from(result.data).toString('base64');
      return `data:image/svg+xml;base64,${encoded}`;
    } catch (error) {
      logger.error('Failed to convert SVG to data URI', error);
      throw error;
    }
  }

  /**
   * Extract SVG as Angular component
   */
  async svgToAngularComponent(inputPath: string, componentName: string): Promise<string> {
    try {
      const svgContent = await fs.readFile(inputPath, 'utf-8');

      // Optimize SVG
      const result = optimize(svgContent, {
        plugins: ['preset-default'],
      });

      // Extract SVG content (remove <?xml...> and comments)
      let svgTag = result.data
        .replace(/<\?xml[^?]*\?>/g, '')
        .replace(/<!--[\s\S]*?-->/g, '')
        .trim();

      // Generate Angular component
      const component = `
import { Component } from '@angular/core';

@Component({
  selector: 'app-${this.toKebabCase(componentName)}',
  template: \`
    ${svgTag}
  \`,
  standalone: true,
})
export class ${componentName}Component {}
`;

      return component;
    } catch (error) {
      logger.error('Failed to convert SVG to Angular component', error);
      throw error;
    }
  }

  /**
   * Check if file is SVG
   */
  async isSvg(filePath: string): Promise<boolean> {
    try {
      const content = await fs.readFile(filePath, 'utf-8');
      return content.trim().startsWith('<svg') || content.includes('xmlns="http://www.w3.org/2000/svg"');
    } catch {
      return false;
    }
  }

  /**
   * Convert to kebab-case
   */
  private toKebabCase(str: string): string {
    return str
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .replace(/\s+/g, '-')
      .toLowerCase();
  }

  /**
   * Format file size
   */
  private formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    return `${(bytes / 1024).toFixed(1)} KB`;
  }
}
