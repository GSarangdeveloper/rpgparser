/**
 * Angular Transformer
 * Transforms React JSX to Angular templates
 */

import * as t from '@babel/types';
import { logger } from '../shared/utils/logger.service';
import { FileUtils } from '../shared/utils/file.utils';

export interface TransformResult {
  template: string;
  inputs: string[];
  outputs: string[];
  twoWayBindings: string[];
}

export class AngularTransformer {
  /**
   * Transform JSX element to Angular template
   */
  transformJSX(jsx: t.JSXElement | null): TransformResult {
    if (!jsx) {
      return {
        template: '',
        inputs: [],
        outputs: [],
        twoWayBindings: [],
      };
    }

    logger.debug('Transforming JSX to Angular template');

    const inputs = new Set<string>();
    const outputs = new Set<string>();
    const twoWayBindings = new Set<string>();

    const template = this.transformElement(jsx, inputs, outputs, twoWayBindings);

    return {
      template,
      inputs: Array.from(inputs),
      outputs: Array.from(outputs),
      twoWayBindings: Array.from(twoWayBindings),
    };
  }

  /**
   * Transform a single JSX element
   */
  private transformElement(
    element: t.JSXElement | t.JSXFragment | t.JSXText | t.JSXExpressionContainer | any,
    inputs: Set<string>,
    outputs: Set<string>,
    twoWayBindings: Set<string>,
    indent: number = 0
  ): string {
    const indentStr = '  '.repeat(indent);

    // Handle JSX text
    if (t.isJSXText(element)) {
      const text = element.value.trim();
      return text ? `${indentStr}${text}` : '';
    }

    // Handle JSX expression: {variable}
    if (t.isJSXExpressionContainer(element)) {
      return `${indentStr}{{${this.transformExpression(element.expression, inputs)}}}`;
    }

    // Handle JSX fragment: <>...</>
    if (t.isJSXFragment(element)) {
      return element.children
        .map((child) => this.transformElement(child, inputs, outputs, twoWayBindings, indent))
        .filter((s) => s)
        .join('\n');
    }

    // Handle JSX element: <div>...</div>
    if (t.isJSXElement(element)) {
      const tagName = this.getTagName(element.openingElement);
      const attributes = this.transformAttributes(
        element.openingElement.attributes,
        inputs,
        outputs,
        twoWayBindings
      );

      const children = element.children
        .map((child) => this.transformElement(child, inputs, outputs, twoWayBindings, indent + 1))
        .filter((s) => s)
        .join('\n');

      // Self-closing tag
      if (element.openingElement.selfClosing || !children) {
        return `${indentStr}<${tagName}${attributes ? ' ' + attributes : ''}>`;
      }

      // Tag with children
      return `${indentStr}<${tagName}${attributes ? ' ' + attributes : ''}>
${children}
${indentStr}</${tagName}>`;
    }

    return '';
  }

  /**
   * Get tag name from JSX opening element
   */
  private getTagName(opening: t.JSXOpeningElement): string {
    const name = opening.name;

    if (t.isJSXIdentifier(name)) {
      // Check if it's a component (PascalCase) or HTML element
      const tagName = name.name;
      if (tagName[0] === tagName[0].toUpperCase()) {
        // Component - convert to kebab-case
        return FileUtils.toKebabCase(tagName);
      }
      return tagName;
    }

    if (t.isJSXMemberExpression(name)) {
      // e.g., React.Fragment
      return 'ng-container';
    }

    return 'div';
  }

  /**
   * Transform JSX attributes to Angular attributes
   */
  private transformAttributes(
    attributes: (t.JSXAttribute | t.JSXSpreadAttribute)[],
    inputs: Set<string>,
    outputs: Set<string>,
    twoWayBindings: Set<string>
  ): string {
    const attrs: string[] = [];

    for (const attr of attributes) {
      if (t.isJSXSpreadAttribute(attr)) {
        // Spread attributes not directly supported
        logger.warn('Spread attributes not fully supported, skipping');
        continue;
      }

      if (t.isJSXAttribute(attr) && t.isJSXIdentifier(attr.name)) {
        const attrName = attr.name.name;
        const transformed = this.transformAttribute(
          attrName,
          attr.value,
          inputs,
          outputs,
          twoWayBindings
        );
        if (transformed) {
          attrs.push(transformed);
        }
      }
    }

    return attrs.join(' ');
  }

  /**
   * Transform a single attribute
   */
  private transformAttribute(
    name: string,
    value: t.JSXAttribute['value'],
    inputs: Set<string>,
    outputs: Set<string>,
    twoWayBindings: Set<string>
  ): string {
    // className → class or [ngClass]
    if (name === 'className') {
      if (!value) return 'class=""';

      if (t.isStringLiteral(value)) {
        return `class="${value.value}"`;
      }

      if (t.isJSXExpressionContainer(value)) {
        const expr = this.transformExpression(value.expression, inputs);
        return `[ngClass]="${expr}"`;
      }
    }

    // style → [ngStyle]
    if (name === 'style') {
      if (t.isJSXExpressionContainer(value)) {
        const expr = this.transformExpression(value.expression, inputs);
        return `[ngStyle]="${expr}"`;
      }
    }

    // Event handlers: onClick → (click)
    if (name.startsWith('on')) {
      const eventName = name.substring(2).toLowerCase(); // onClick → click
      if (t.isJSXExpressionContainer(value)) {
        const handler = this.transformEventHandler(value.expression);
        outputs.add(eventName);
        return `(${eventName})="${handler}"`;
      }
    }

    // value with onChange → [(ngModel)]
    if (name === 'value' && value && t.isJSXExpressionContainer(value)) {
      const expr = this.transformExpression(value.expression, inputs);
      // Check if there's an onChange handler (two-way binding)
      twoWayBindings.add(expr);
      return `[(ngModel)]="${expr}"`;
    }

    // checked → [checked] or [(ngModel)]
    if (name === 'checked' && value && t.isJSXExpressionContainer(value)) {
      const expr = this.transformExpression(value.expression, inputs);
      return `[checked]="${expr}"`;
    }

    // disabled, readonly, etc. → [disabled]
    if (['disabled', 'readonly', 'required'].includes(name)) {
      if (!value) return name; // Boolean attribute

      if (t.isJSXExpressionContainer(value)) {
        const expr = this.transformExpression(value.expression, inputs);
        return `[${name}]="${expr}"`;
      }
    }

    // htmlFor → for
    if (name === 'htmlFor') {
      if (t.isStringLiteral(value)) {
        return `for="${value.value}"`;
      }
    }

    // Regular attributes
    if (t.isStringLiteral(value)) {
      return `${name}="${value.value}"`;
    }

    if (t.isJSXExpressionContainer(value)) {
      const expr = this.transformExpression(value.expression, inputs);
      return `[${name}]="${expr}"`;
    }

    // Boolean attribute (no value)
    if (!value) {
      return name;
    }

    return '';
  }

  /**
   * Transform JSX expression to Angular expression
   */
  private transformExpression(expr: t.Expression | t.JSXEmptyExpression, inputs: Set<string>): string {
    if (t.isJSXEmptyExpression(expr)) {
      return '';
    }

    // Identifier: {name}
    if (t.isIdentifier(expr)) {
      inputs.add(expr.name);
      return expr.name;
    }

    // String literal: {"text"}
    if (t.isStringLiteral(expr)) {
      return `'${expr.value}'`;
    }

    // Number literal: {42}
    if (t.isNumericLiteral(expr)) {
      return String(expr.value);
    }

    // Boolean literal: {true}
    if (t.isBooleanLiteral(expr)) {
      return String(expr.value);
    }

    // Member expression: {obj.prop}
    if (t.isMemberExpression(expr)) {
      return this.transformMemberExpression(expr, inputs);
    }

    // Binary expression: {a + b}
    if (t.isBinaryExpression(expr)) {
      const left = this.transformExpression(expr.left as any, inputs);
      const right = this.transformExpression(expr.right, inputs);
      return `${left} ${expr.operator} ${right}`;
    }

    // Logical expression: {a && b} → *ngIf
    if (t.isLogicalExpression(expr)) {
      const left = this.transformExpression(expr.left, inputs);
      const right = this.transformExpression(expr.right, inputs);
      return `${left} ${expr.operator} ${right}`;
    }

    // Conditional: {condition ? a : b}
    if (t.isConditionalExpression(expr)) {
      const test = this.transformExpression(expr.test, inputs);
      const consequent = this.transformExpression(expr.consequent, inputs);
      const alternate = this.transformExpression(expr.alternate, inputs);
      return `${test} ? ${consequent} : ${alternate}`;
    }

    // Call expression: {fn()}
    if (t.isCallExpression(expr)) {
      return this.transformCallExpression(expr, inputs);
    }

    // Array expression: {[1, 2, 3]}
    if (t.isArrayExpression(expr)) {
      const elements = expr.elements.map((el) =>
        el ? this.transformExpression(el as t.Expression, inputs) : ''
      );
      return `[${elements.join(', ')}]`;
    }

    // Object expression: {{ key: value }}
    if (t.isObjectExpression(expr)) {
      const props = expr.properties.map((prop) => {
        if (t.isObjectProperty(prop)) {
          const key = t.isIdentifier(prop.key) ? prop.key.name : 'key';
          const val = this.transformExpression(prop.value as t.Expression, inputs);
          return `${key}: ${val}`;
        }
        return '';
      });
      return `{ ${props.join(', ')} }`;
    }

    return 'unknown';
  }

  /**
   * Transform member expression
   */
  private transformMemberExpression(expr: t.MemberExpression, inputs: Set<string>): string {
    let obj = '';
    if (t.isIdentifier(expr.object)) {
      obj = expr.object.name;
      inputs.add(obj);
    } else if (t.isMemberExpression(expr.object)) {
      obj = this.transformMemberExpression(expr.object, inputs);
    }

    let prop = '';
    if (t.isIdentifier(expr.property)) {
      prop = expr.property.name;
    }

    return `${obj}.${prop}`;
  }

  /**
   * Transform call expression
   */
  private transformCallExpression(expr: t.CallExpression, inputs: Set<string>): string {
    let callee = '';
    if (t.isIdentifier(expr.callee)) {
      callee = expr.callee.name;
    } else if (t.isMemberExpression(expr.callee)) {
      callee = this.transformMemberExpression(expr.callee, inputs);
    }

    const args = expr.arguments.map((arg) =>
      this.transformExpression(arg as t.Expression, inputs)
    );

    return `${callee}(${args.join(', ')})`;
  }

  /**
   * Transform event handler
   */
  private transformEventHandler(expr: t.Expression | t.JSXEmptyExpression): string {
    if (t.isJSXEmptyExpression(expr)) {
      return '';
    }

    // Function call: onClick={handleClick}
    if (t.isIdentifier(expr)) {
      return `${expr.name}()`;
    }

    // Arrow function: onClick={() => doSomething()}
    if (t.isArrowFunctionExpression(expr)) {
      return 'handleEvent()'; // Simplified
    }

    return 'handleEvent()';
  }

  /**
   * Handle conditional rendering: {condition && <Component />}
   * This should be detected and converted to *ngIf
   */
  detectConditionalRendering(
    expr: t.Expression
  ): { condition: string; element: t.JSXElement } | null {
    if (t.isLogicalExpression(expr) && expr.operator === '&&') {
      if (t.isJSXElement(expr.right)) {
        return {
          condition: this.transformExpression(expr.left, new Set()),
          element: expr.right,
        };
      }
    }
    return null;
  }

  /**
   * Handle array mapping: {items.map(item => <Component />)}
   * This should be detected and converted to *ngFor
   */
  detectArrayMapping(expr: t.Expression): {
    array: string;
    item: string;
    element: t.JSXElement;
  } | null {
    if (t.isCallExpression(expr)) {
      const callee = expr.callee;
      if (
        t.isMemberExpression(callee) &&
        t.isIdentifier(callee.property) &&
        callee.property.name === 'map'
      ) {
        // Extract array name
        const array = t.isIdentifier(callee.object) ? callee.object.name : 'items';

        // Extract callback
        const callback = expr.arguments[0];
        if (t.isArrowFunctionExpression(callback)) {
          const param = callback.params[0];
          const item = t.isIdentifier(param) ? param.name : 'item';

          // Extract JSX from callback
          let element: t.JSXElement | null = null;
          if (t.isJSXElement(callback.body)) {
            element = callback.body;
          } else if (t.isBlockStatement(callback.body)) {
            for (const stmt of callback.body.body) {
              if (t.isReturnStatement(stmt) && t.isJSXElement(stmt.argument)) {
                element = stmt.argument;
                break;
              }
            }
          }

          if (element) {
            return { array, item, element };
          }
        }
      }
    }
    return null;
  }
}
