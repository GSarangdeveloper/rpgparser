/**
 * Design Token Mapper
 * Maps hardcoded values to design tokens
 */

import { logger } from '../shared/utils/logger.service';
import { TokenRegistry, DesignTokenDefinition } from '../design-system/token-registry';

export interface TokenMappingResult {
  original: string;
  token?: string;
  mapped: boolean;
  type: 'color' | 'spacing' | 'typography' | 'shadow' | 'other';
}

export class TokenMapper {
  constructor(private registry: TokenRegistry) {}

  /**
   * Map a CSS value to a design token
   */
  mapValue(property: string, value: string): TokenMappingResult {
    const type = this.inferType(property, value);

    // Try to find existing token
    const token = this.registry.findByValue(value);
    if (token) {
      logger.debug(`Mapped ${property}: ${value} → var(--${token.name})`);
      return {
        original: value,
        token: `var(--${token.name})`,
        mapped: true,
        type: token.type,
      };
    }

    // No token found - return original value
    logger.debug(`No token found for ${property}: ${value}`);
    return {
      original: value,
      mapped: false,
      type,
    };
  }

  /**
   * Map all styles in an object
   */
  mapStyles(styles: Record<string, string>): Record<string, string> {
    const mapped: Record<string, string> = {};

    for (const [property, value] of Object.entries(styles)) {
      const result = this.mapValue(property, value);
      mapped[property] = result.token || result.original;
    }

    return mapped;
  }

  /**
   * Map color value to token
   */
  mapColor(value: string): string {
    const token = this.findColorToken(value);
    if (token) {
      return `var(--${token.name})`;
    }

    // Try to find close match
    const closeMatch = this.findCloseColorMatch(value);
    if (closeMatch) {
      logger.warn(`Using close color match: ${value} → ${closeMatch.name}`);
      return `var(--${closeMatch.name})`;
    }

    return value;
  }

  /**
   * Map spacing value to token
   */
  mapSpacing(value: string): string {
    const token = this.findSpacingToken(value);
    if (token) {
      return `var(--${token.name})`;
    }

    // Try to find close match (±2px tolerance)
    const closeMatch = this.findCloseSpacingMatch(value);
    if (closeMatch) {
      logger.warn(`Using close spacing match: ${value} → ${closeMatch.name}`);
      return `var(--${closeMatch.name})`;
    }

    return value;
  }

  /**
   * Map typography value to token
   */
  mapTypography(property: string, value: string): string {
    const token = this.findTypographyToken(property, value);
    if (token) {
      return `var(--${token.name})`;
    }
    return value;
  }

  /**
   * Generate new token for unmapped value
   */
  generateToken(property: string, value: string, name?: string): DesignTokenDefinition {
    const type = this.inferType(property, value);
    const tokenName = name || this.generateTokenName(property, value, type);

    const token: DesignTokenDefinition = {
      name: tokenName,
      value,
      type,
    };

    this.registry.register(token);
    logger.info(`Generated new token: ${tokenName} = ${value}`);

    return token;
  }

  /**
   * Infer token type from property
   */
  private inferType(property: string, value: string): DesignTokenDefinition['type'] {
    // Color properties
    if (
      property.includes('color') ||
      property.includes('background') ||
      property === 'fill' ||
      property === 'stroke'
    ) {
      return 'color';
    }

    // Spacing properties
    if (
      property.includes('padding') ||
      property.includes('margin') ||
      property.includes('gap') ||
      property === 'top' ||
      property === 'right' ||
      property === 'bottom' ||
      property === 'left'
    ) {
      return 'spacing';
    }

    // Typography properties
    if (
      property.includes('font') ||
      property.includes('text') ||
      property.includes('line-height') ||
      property.includes('letter-spacing')
    ) {
      return 'typography';
    }

    // Shadow properties
    if (property.includes('shadow')) {
      return 'shadow';
    }

    return 'other';
  }

  /**
   * Find color token
   */
  private findColorToken(value: string): DesignTokenDefinition | null {
    const colors = this.registry.findByType('color');
    for (const token of colors) {
      if (this.colorsEqual(token.value, value)) {
        return token;
      }
    }
    return null;
  }

  /**
   * Find close color match (within tolerance)
   */
  private findCloseColorMatch(value: string): DesignTokenDefinition | null {
    const rgb = this.parseColor(value);
    if (!rgb) return null;

    const colors = this.registry.findByType('color');
    const tolerance = 10; // RGB difference tolerance

    for (const token of colors) {
      const tokenRgb = this.parseColor(token.value);
      if (!tokenRgb) continue;

      const distance = Math.sqrt(
        Math.pow(rgb.r - tokenRgb.r, 2) +
          Math.pow(rgb.g - tokenRgb.g, 2) +
          Math.pow(rgb.b - tokenRgb.b, 2)
      );

      if (distance <= tolerance) {
        return token;
      }
    }

    return null;
  }

  /**
   * Find spacing token
   */
  private findSpacingToken(value: string): DesignTokenDefinition | null {
    const tokens = this.registry.findByType('spacing');
    for (const token of tokens) {
      if (token.value === value) {
        return token;
      }
    }
    return null;
  }

  /**
   * Find close spacing match (±2px)
   */
  private findCloseSpacingMatch(value: string): DesignTokenDefinition | null {
    const px = this.parsePixels(value);
    if (px === null) return null;

    const tokens = this.registry.findByType('spacing');
    const tolerance = 2;

    for (const token of tokens) {
      const tokenPx = this.parsePixels(token.value);
      if (tokenPx !== null && Math.abs(px - tokenPx) <= tolerance) {
        return token;
      }
    }

    return null;
  }

  /**
   * Find typography token
   */
  private findTypographyToken(property: string, value: string): DesignTokenDefinition | null {
    const tokens = this.registry.findByType('typography');
    for (const token of tokens) {
      if (
        token.category === property.replace('-', '_') &&
        token.value === value
      ) {
        return token;
      }
    }
    return null;
  }

  /**
   * Compare colors for equality
   */
  private colorsEqual(color1: string, color2: string): boolean {
    const rgb1 = this.parseColor(color1);
    const rgb2 = this.parseColor(color2);
    if (!rgb1 || !rgb2) return false;
    return rgb1.r === rgb2.r && rgb1.g === rgb2.g && rgb1.b === rgb2.b && rgb1.a === rgb2.a;
  }

  /**
   * Parse color to RGB
   */
  private parseColor(color: string): { r: number; g: number; b: number; a: number } | null {
    // Hex format: #rrggbb or #rgb
    if (color.startsWith('#')) {
      const hex = color.substring(1);
      let r: number, g: number, b: number;

      if (hex.length === 3) {
        r = parseInt(hex[0] + hex[0], 16);
        g = parseInt(hex[1] + hex[1], 16);
        b = parseInt(hex[2] + hex[2], 16);
      } else if (hex.length === 6) {
        r = parseInt(hex.substring(0, 2), 16);
        g = parseInt(hex.substring(2, 4), 16);
        b = parseInt(hex.substring(4, 6), 16);
      } else {
        return null;
      }

      return { r, g, b, a: 1 };
    }

    // RGB/RGBA format
    const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (match) {
      return {
        r: parseInt(match[1]),
        g: parseInt(match[2]),
        b: parseInt(match[3]),
        a: match[4] ? parseFloat(match[4]) : 1,
      };
    }

    return null;
  }

  /**
   * Parse pixel value
   */
  private parsePixels(value: string): number | null {
    if (value.endsWith('px')) {
      return parseFloat(value);
    }
    if (value.endsWith('rem')) {
      return parseFloat(value) * 16; // Assume 1rem = 16px
    }
    return null;
  }

  /**
   * Generate token name
   */
  private generateTokenName(property: string, value: string, type: DesignTokenDefinition['type']): string {
    // Generate semantic name based on value
    if (type === 'color') {
      const rgb = this.parseColor(value);
      if (rgb) {
        // Simple color naming (could be improved)
        return `color-custom-${Math.round(rgb.r)}-${Math.round(rgb.g)}-${Math.round(rgb.b)}`;
      }
    }

    if (type === 'spacing') {
      const px = this.parsePixels(value);
      if (px !== null) {
        return `spacing-${Math.round(px / 4)}`; // Assume 4px scale
      }
    }

    return `${type}-${property.replace(/[^a-z0-9]/g, '-')}`;
  }
}
