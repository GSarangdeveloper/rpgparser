/**
 * Transform Orchestrator Service
 * Coordinates all transformation steps from React to Angular
 */

import { logger } from '../shared/utils/logger.service';
import { ReactParser, ParsedComponent } from './react-parser.service';
import { AngularTransformer, TransformResult } from './angular-transformer';
import { TailwindConverter, ConversionResult as TailwindResult } from './tailwind-converter';
import { ComponentMapper, ComponentMatch } from './component-mapper';
import { TokenMapper } from './token-mapper.service';
import { ComponentRegistry } from '../design-system/component-registry';
import { TokenRegistry } from '../design-system/token-registry';

export interface TransformConfig {
  reuseComponents: boolean;
  useDesignTokens: boolean;
  reuseThreshold: number; // 0-1
  codeConnectMappings?: Record<string, string>;
}

export interface ComponentTransformResult {
  type: 'reuse' | 'generate';
  componentName: string;
  selector: string;

  // For reuse
  existingComponentPath?: string;

  // For generate
  template?: string;
  styles?: Record<string, string>;
  responsiveStyles?: Record<string, Record<string, string>>;
  hoverStyles?: Record<string, string>;
  focusStyles?: Record<string, string>;
  inputs?: string[];
  outputs?: string[];
  twoWayBindings?: string[];
  classNames?: string[];
  imports?: string[];

  // Metadata
  parsedComponent?: ParsedComponent;
  componentMatch?: ComponentMatch;
  designTokensUsed?: string[];
}

export class TransformOrchestrator {
  private reactParser: ReactParser;
  private angularTransformer: AngularTransformer;
  private tailwindConverter: TailwindConverter;
  private componentMapper: ComponentMapper;
  private tokenMapper: TokenMapper;

  constructor(
    componentRegistry: ComponentRegistry,
    tokenRegistry: TokenRegistry,
    codeConnectMappings: Record<string, string> = {}
  ) {
    this.reactParser = new ReactParser();
    this.angularTransformer = new AngularTransformer();
    this.tailwindConverter = new TailwindConverter();
    this.componentMapper = new ComponentMapper(componentRegistry, codeConnectMappings);
    this.tokenMapper = new TokenMapper(tokenRegistry);

    logger.info('Transform Orchestrator initialized');
  }

  /**
   * Main transformation pipeline
   */
  async transform(reactCode: string, config: TransformConfig): Promise<ComponentTransformResult> {
    logger.group('🔄 Starting Transformation Pipeline');

    try {
      // Step 1: Parse React component
      logger.info('Step 1/6: Parsing React component');
      const parsed = this.reactParser.parse(reactCode);
      logger.success(`Parsed component: ${parsed.name}`);

      // Step 2: Check for existing component (if reuse enabled)
      if (config.reuseComponents) {
        logger.info('Step 2/6: Checking for existing component');
        const match = this.componentMapper.findMatch(parsed);

        if (this.componentMapper.shouldReuse(match, config.reuseThreshold)) {
          logger.success(`Reusing existing component: ${match.component!.name}`);
          logger.groupEnd();

          return {
            type: 'reuse',
            componentName: match.component!.name,
            selector: match.component!.selector,
            existingComponentPath: match.component!.path,
            parsedComponent: parsed,
            componentMatch: match,
          };
        }

        logger.info('No suitable component found for reuse, generating new component');
      } else {
        logger.info('Step 2/6: Component reuse disabled, will generate new');
      }

      // Step 3: Transform JSX to Angular template
      logger.info('Step 3/6: Transforming JSX to Angular template');
      const angularResult = this.angularTransformer.transformJSX(parsed.jsx);
      logger.success('JSX transformed to Angular template');

      // Step 4: Convert Tailwind classes to CSS
      logger.info('Step 4/6: Converting Tailwind to CSS');
      const allClassNames = parsed.classNames.join(' ');
      const tailwindResult = this.tailwindConverter.convert(allClassNames);
      logger.success('Tailwind converted to CSS');

      // Step 5: Map to design tokens (if enabled)
      let styles = tailwindResult.baseStyles;
      let hoverStyles = tailwindResult.hoverStyles;
      let focusStyles = tailwindResult.focusStyles;
      let responsiveStyles = tailwindResult.responsiveStyles;
      const designTokensUsed: string[] = [];

      if (config.useDesignTokens) {
        logger.info('Step 5/6: Mapping values to design tokens');
        styles = this.tokenMapper.mapStyles(styles);
        hoverStyles = this.tokenMapper.mapStyles(hoverStyles);
        focusStyles = this.tokenMapper.mapStyles(focusStyles);

        // Map responsive styles
        for (const [breakpoint, breakpointStyles] of Object.entries(responsiveStyles)) {
          responsiveStyles[breakpoint] = this.tokenMapper.mapStyles(breakpointStyles);
        }

        // Collect used tokens
        const allStyleValues = [
          ...Object.values(styles),
          ...Object.values(hoverStyles),
          ...Object.values(focusStyles),
          ...Object.values(responsiveStyles).flatMap(s => Object.values(s)),
        ];

        for (const value of allStyleValues) {
          if (value.startsWith('var(--')) {
            const tokenName = value.match(/var\(--(.*?)\)/)?.[1];
            if (tokenName) {
              designTokensUsed.push(tokenName);
            }
          }
        }

        logger.success(`Mapped to design tokens (${designTokensUsed.length} tokens used)`);
      } else {
        logger.info('Step 5/6: Design token mapping disabled');
      }

      // Step 6: Generate component metadata
      logger.info('Step 6/6: Generating component metadata');
      const componentName = this.generateComponentName(parsed.name);
      const selector = this.generateSelector(parsed.name);

      logger.success('✨ Transformation complete');
      logger.groupEnd();

      return {
        type: 'generate',
        componentName,
        selector,
        template: angularResult.template,
        styles,
        responsiveStyles,
        hoverStyles,
        focusStyles,
        inputs: angularResult.inputs,
        outputs: angularResult.outputs,
        twoWayBindings: angularResult.twoWayBindings,
        classNames: parsed.classNames,
        imports: parsed.imports.map(i => i.source),
        parsedComponent: parsed,
        designTokensUsed,
      };

    } catch (error) {
      logger.groupEnd();
      logger.error('❌ Transformation failed', error);
      throw error;
    }
  }

  /**
   * Generate Angular component name (PascalCase)
   */
  private generateComponentName(reactName: string): string {
    // Remove common suffixes/prefixes
    let name = reactName
      .replace(/^React/, '')
      .replace(/Component$/, '');

    // Ensure it ends with Component
    if (!name.endsWith('Component')) {
      name += 'Component';
    }

    // Ensure PascalCase
    return name.charAt(0).toUpperCase() + name.slice(1);
  }

  /**
   * Generate Angular selector (kebab-case)
   */
  private generateSelector(reactName: string): string {
    // Convert to kebab-case
    const kebab = reactName
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .toLowerCase()
      .replace(/^react-/, '')
      .replace(/-component$/, '');

    // Add app prefix
    return `app-${kebab}`;
  }
}
