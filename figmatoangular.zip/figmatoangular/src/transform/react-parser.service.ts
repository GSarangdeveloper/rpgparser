/**
 * React Parser Service
 * Parses React components using Babel to extract structure
 */

import { parse } from '@babel/parser';
import traverse, { NodePath } from '@babel/traverse';
import * as t from '@babel/types';
import { logger } from '../shared/utils/logger.service';

export interface ParsedComponent {
  name: string;
  type: 'function' | 'arrow' | 'class';
  props: PropDefinition[];
  state: StateDefinition[];
  jsx: t.JSXElement | null;
  imports: ImportStatement[];
  exports: ExportStatement[];
  hooks: HookCall[];
  events: EventHandler[];
  classNames: string[];
}

export interface PropDefinition {
  name: string;
  type: string;
  required: boolean;
  defaultValue?: string;
}

export interface StateDefinition {
  name: string;
  initialValue: string;
  setter: string;
}

export interface ImportStatement {
  source: string;
  specifiers: string[];
  defaultImport?: string;
}

export interface ExportStatement {
  name: string;
  isDefault: boolean;
}

export interface HookCall {
  name: string;
  arguments: string[];
}

export interface EventHandler {
  name: string; // onClick, onChange, etc.
  handler: string; // function name or inline function
}

export class ReactParser {
  /**
   * Parse React component code to extract structure
   */
  parse(code: string): ParsedComponent {
    logger.debug('Parsing React component code');

    try {
      // Parse code to AST
      const ast = parse(code, {
        sourceType: 'module',
        plugins: ['jsx', 'typescript'],
      });

      const component: ParsedComponent = {
        name: '',
        type: 'function',
        props: [],
        state: [],
        jsx: null,
        imports: [],
        exports: [],
        hooks: [],
        events: [],
        classNames: [],
      };

      // Traverse AST
      traverse(ast, {
        // Extract imports
        ImportDeclaration: (path) => {
          component.imports.push(this.extractImport(path));
        },

        // Extract function components
        FunctionDeclaration: (path) => {
          if (this.isReactComponent(path)) {
            component.name = path.node.id?.name || 'Component';
            component.type = 'function';
            component.props = this.extractFunctionProps(path);
            this.extractJSXFromFunction(path, component);
          }
        },

        // Extract arrow function components
        VariableDeclarator: (path) => {
          if (
            path.node.init &&
            t.isArrowFunctionExpression(path.node.init) &&
            this.hasJSXReturn(path.node.init)
          ) {
            component.name = t.isIdentifier(path.node.id) ? path.node.id.name : 'Component';
            component.type = 'arrow';
            component.props = this.extractArrowFunctionProps(path);
            this.extractJSXFromArrowFunction(path, component);
          }
        },

        // Extract class components
        ClassDeclaration: (path) => {
          if (this.isReactClassComponent(path)) {
            component.name = path.node.id?.name || 'Component';
            component.type = 'class';
            this.extractClassComponent(path, component);
          }
        },

        // Extract exports
        ExportDefaultDeclaration: (path) => {
          component.exports.push({
            name: component.name,
            isDefault: true,
          });
        },

        ExportNamedDeclaration: (path) => {
          if (path.node.declaration && t.isFunctionDeclaration(path.node.declaration)) {
            component.exports.push({
              name: path.node.declaration.id?.name || '',
              isDefault: false,
            });
          }
        },
      });

      // Extract classNames from JSX
      if (component.jsx) {
        component.classNames = this.extractClassNames(component.jsx);
      }

      logger.success(`Parsed component: ${component.name}`);
      return component;
    } catch (error) {
      logger.error('Failed to parse React component', error);
      throw error;
    }
  }

  /**
   * Check if function declaration is a React component
   */
  private isReactComponent(path: NodePath<t.FunctionDeclaration>): boolean {
    // Check if function returns JSX
    let hasJSX = false;
    path.traverse({
      ReturnStatement: (returnPath) => {
        if (returnPath.node.argument && t.isJSXElement(returnPath.node.argument)) {
          hasJSX = true;
        }
      },
    });
    return hasJSX;
  }

  /**
   * Check if arrow function returns JSX
   */
  private hasJSXReturn(node: t.ArrowFunctionExpression): boolean {
    if (t.isJSXElement(node.body)) {
      return true;
    }
    if (t.isBlockStatement(node.body)) {
      for (const statement of node.body.body) {
        if (t.isReturnStatement(statement) && t.isJSXElement(statement.argument)) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Check if class extends React.Component
   */
  private isReactClassComponent(path: NodePath<t.ClassDeclaration>): boolean {
    const superClass = path.node.superClass;
    if (!superClass) return false;

    if (t.isIdentifier(superClass) && superClass.name === 'Component') {
      return true;
    }

    if (
      t.isMemberExpression(superClass) &&
      t.isIdentifier(superClass.object) &&
      superClass.object.name === 'React' &&
      t.isIdentifier(superClass.property) &&
      superClass.property.name === 'Component'
    ) {
      return true;
    }

    return false;
  }

  /**
   * Extract import statement
   */
  private extractImport(path: NodePath<t.ImportDeclaration>): ImportStatement {
    const source = path.node.source.value;
    const specifiers: string[] = [];
    let defaultImport: string | undefined;

    for (const spec of path.node.specifiers) {
      if (t.isImportDefaultSpecifier(spec)) {
        defaultImport = spec.local.name;
      } else if (t.isImportSpecifier(spec)) {
        specifiers.push(spec.local.name);
      }
    }

    return { source, specifiers, defaultImport };
  }

  /**
   * Extract props from function component parameters
   */
  private extractFunctionProps(path: NodePath<t.FunctionDeclaration>): PropDefinition[] {
    const props: PropDefinition[] = [];
    const params = path.node.params;

    if (params.length > 0) {
      const firstParam = params[0];

      // Destructured props: function Button({ label, onClick })
      if (t.isObjectPattern(firstParam)) {
        for (const prop of firstParam.properties) {
          if (t.isObjectProperty(prop) && t.isIdentifier(prop.key)) {
            props.push({
              name: prop.key.name,
              type: 'any',
              required: true,
            });
          }
        }
      }

      // Named props: function Button(props)
      if (t.isIdentifier(firstParam)) {
        props.push({
          name: 'props',
          type: 'any',
          required: true,
        });
      }
    }

    return props;
  }

  /**
   * Extract props from arrow function
   */
  private extractArrowFunctionProps(path: NodePath<t.VariableDeclarator>): PropDefinition[] {
    const props: PropDefinition[] = [];
    const init = path.node.init;

    if (init && t.isArrowFunctionExpression(init)) {
      const params = init.params;

      if (params.length > 0) {
        const firstParam = params[0];

        if (t.isObjectPattern(firstParam)) {
          for (const prop of firstParam.properties) {
            if (t.isObjectProperty(prop) && t.isIdentifier(prop.key)) {
              props.push({
                name: prop.key.name,
                type: 'any',
                required: true,
              });
            }
          }
        }
      }
    }

    return props;
  }

  /**
   * Extract JSX from function component
   */
  private extractJSXFromFunction(
    path: NodePath<t.FunctionDeclaration>,
    component: ParsedComponent
  ): void {
    path.traverse({
      ReturnStatement: (returnPath) => {
        if (returnPath.node.argument && t.isJSXElement(returnPath.node.argument)) {
          component.jsx = returnPath.node.argument;
          component.events = this.extractEventHandlers(returnPath.node.argument);
        }
      },
      CallExpression: (callPath) => {
        // Extract React hooks (useState, useEffect, etc.)
        if (t.isIdentifier(callPath.node.callee) && callPath.node.callee.name.startsWith('use')) {
          component.hooks.push({
            name: callPath.node.callee.name,
            arguments: callPath.node.arguments.map((arg) => this.nodeToString(arg)),
          });

          // Extract useState
          if (callPath.node.callee.name === 'useState') {
            const parent = callPath.parent;
            if (t.isVariableDeclarator(parent) && t.isArrayPattern(parent.id)) {
              const elements = parent.id.elements;
              if (elements.length >= 2) {
                const stateVar = elements[0];
                const setter = elements[1];
                if (t.isIdentifier(stateVar) && t.isIdentifier(setter)) {
                  component.state.push({
                    name: stateVar.name,
                    setter: setter.name,
                    initialValue: this.nodeToString(callPath.node.arguments[0]),
                  });
                }
              }
            }
          }
        }
      },
    });
  }

  /**
   * Extract JSX from arrow function
   */
  private extractJSXFromArrowFunction(
    path: NodePath<t.VariableDeclarator>,
    component: ParsedComponent
  ): void {
    const init = path.node.init;
    if (!init || !t.isArrowFunctionExpression(init)) return;

    // Direct JSX return: () => <div>...</div>
    if (t.isJSXElement(init.body)) {
      component.jsx = init.body;
      component.events = this.extractEventHandlers(init.body);
      return;
    }

    // Block with return: () => { return <div>...</div> }
    if (t.isBlockStatement(init.body)) {
      for (const statement of init.body.body) {
        if (t.isReturnStatement(statement) && t.isJSXElement(statement.argument)) {
          component.jsx = statement.argument;
          component.events = this.extractEventHandlers(statement.argument);
          break;
        }
      }
    }
  }

  /**
   * Extract class component details
   */
  private extractClassComponent(
    path: NodePath<t.ClassDeclaration>,
    component: ParsedComponent
  ): void {
    path.traverse({
      ClassMethod: (methodPath) => {
        if (methodPath.node.key && t.isIdentifier(methodPath.node.key)) {
          const methodName = methodPath.node.key.name;

          // Extract render method
          if (methodName === 'render') {
            methodPath.traverse({
              ReturnStatement: (returnPath) => {
                if (returnPath.node.argument && t.isJSXElement(returnPath.node.argument)) {
                  component.jsx = returnPath.node.argument;
                  component.events = this.extractEventHandlers(returnPath.node.argument);
                }
              },
            });
          }
        }
      },
    });
  }

  /**
   * Extract event handlers from JSX
   */
  private extractEventHandlers(jsx: t.JSXElement): EventHandler[] {
    const events: EventHandler[] = [];

    const extractFromNode = (node: any) => {
      if (t.isJSXElement(node)) {
        const attrs = node.openingElement.attributes;
        for (const attr of attrs) {
          if (t.isJSXAttribute(attr) && t.isJSXIdentifier(attr.name)) {
            const attrName = attr.name.name;
            if (attrName.startsWith('on')) {
              events.push({
                name: attrName,
                handler: attr.value ? this.nodeToString(attr.value) : '',
              });
            }
          }
        }

        // Recurse into children
        for (const child of node.children) {
          extractFromNode(child);
        }
      }
    };

    extractFromNode(jsx);
    return events;
  }

  /**
   * Extract className values from JSX
   */
  private extractClassNames(jsx: t.JSXElement): string[] {
    const classNames: string[] = [];

    const extractFromNode = (node: any) => {
      if (t.isJSXElement(node)) {
        const attrs = node.openingElement.attributes;
        for (const attr of attrs) {
          if (
            t.isJSXAttribute(attr) &&
            t.isJSXIdentifier(attr.name) &&
            attr.name.name === 'className'
          ) {
            if (attr.value && t.isStringLiteral(attr.value)) {
              classNames.push(attr.value.value);
            }
          }
        }

        // Recurse into children
        for (const child of node.children) {
          extractFromNode(child);
        }
      }
    };

    extractFromNode(jsx);
    return classNames;
  }

  /**
   * Convert AST node to string
   */
  private nodeToString(node: any): string {
    if (!node) return '';
    if (t.isStringLiteral(node)) return node.value;
    if (t.isNumericLiteral(node)) return String(node.value);
    if (t.isBooleanLiteral(node)) return String(node.value);
    if (t.isIdentifier(node)) return node.name;
    if (t.isJSXExpressionContainer(node)) return this.nodeToString(node.expression);
    return '';
  }

  /**
   * Get JSX as string (for debugging)
   */
  getJSXString(jsx: t.JSXElement | null): string {
    if (!jsx) return '';
    // Simple string representation (would need @babel/generator for full code)
    return '<jsx>...</jsx>';
  }
}
