/**
 * Tailwind to CSS Converter
 * Converts Tailwind utility classes to standard CSS
 */

import { logger } from '../shared/utils/logger.service';

export interface ConversionResult {
  baseStyles: Record<string, string>;
  hoverStyles: Record<string, string>;
  focusStyles: Record<string, string>;
  responsiveStyles: Record<string, Record<string, string>>; // breakpoint -> styles
}

export class TailwindConverter {
  // Tailwind utility class mappings
  private static readonly mappings: Record<string, Record<string, string>> = {
    // Layout
    flex: { display: 'flex' },
    'inline-flex': { display: 'inline-flex' },
    block: { display: 'block' },
    'inline-block': { display: 'inline-block' },
    inline: { display: 'inline' },
    hidden: { display: 'none' },
    grid: { display: 'grid' },

    // Flexbox Direction
    'flex-row': { 'flex-direction': 'row' },
    'flex-row-reverse': { 'flex-direction': 'row-reverse' },
    'flex-col': { 'flex-direction': 'column' },
    'flex-col-reverse': { 'flex-direction': 'column-reverse' },

    // Flexbox Wrap
    'flex-wrap': { 'flex-wrap': 'wrap' },
    'flex-wrap-reverse': { 'flex-wrap': 'wrap-reverse' },
    'flex-nowrap': { 'flex-wrap': 'nowrap' },

    // Align Items
    'items-start': { 'align-items': 'flex-start' },
    'items-end': { 'align-items': 'flex-end' },
    'items-center': { 'align-items': 'center' },
    'items-baseline': { 'align-items': 'baseline' },
    'items-stretch': { 'align-items': 'stretch' },

    // Justify Content
    'justify-start': { 'justify-content': 'flex-start' },
    'justify-end': { 'justify-content': 'flex-end' },
    'justify-center': { 'justify-content': 'center' },
    'justify-between': { 'justify-content': 'space-between' },
    'justify-around': { 'justify-content': 'space-around' },
    'justify-evenly': { 'justify-content': 'space-evenly' },

    // Align Self
    'self-auto': { 'align-self': 'auto' },
    'self-start': { 'align-self': 'flex-start' },
    'self-end': { 'align-self': 'flex-end' },
    'self-center': { 'align-self': 'center' },
    'self-stretch': { 'align-self': 'stretch' },

    // Position
    static: { position: 'static' },
    fixed: { position: 'fixed' },
    absolute: { position: 'absolute' },
    relative: { position: 'relative' },
    sticky: { position: 'sticky' },

    // Overflow
    'overflow-auto': { overflow: 'auto' },
    'overflow-hidden': { overflow: 'hidden' },
    'overflow-visible': { overflow: 'visible' },
    'overflow-scroll': { overflow: 'scroll' },
    'overflow-x-auto': { 'overflow-x': 'auto' },
    'overflow-y-auto': { 'overflow-y': 'auto' },

    // Text Align
    'text-left': { 'text-align': 'left' },
    'text-center': { 'text-align': 'center' },
    'text-right': { 'text-align': 'right' },
    'text-justify': { 'text-align': 'justify' },

    // Font Weight
    'font-thin': { 'font-weight': '100' },
    'font-extralight': { 'font-weight': '200' },
    'font-light': { 'font-weight': '300' },
    'font-normal': { 'font-weight': '400' },
    'font-medium': { 'font-weight': '500' },
    'font-semibold': { 'font-weight': '600' },
    'font-bold': { 'font-weight': '700' },
    'font-extrabold': { 'font-weight': '800' },
    'font-black': { 'font-weight': '900' },

    // Text Transform
    uppercase: { 'text-transform': 'uppercase' },
    lowercase: { 'text-transform': 'lowercase' },
    capitalize: { 'text-transform': 'capitalize' },
    'normal-case': { 'text-transform': 'none' },

    // Text Decoration
    underline: { 'text-decoration': 'underline' },
    'line-through': { 'text-decoration': 'line-through' },
    'no-underline': { 'text-decoration': 'none' },

    // White Space
    'whitespace-normal': { 'white-space': 'normal' },
    'whitespace-nowrap': { 'white-space': 'nowrap' },
    'whitespace-pre': { 'white-space': 'pre' },
    'whitespace-pre-line': { 'white-space': 'pre-line' },
    'whitespace-pre-wrap': { 'white-space': 'pre-wrap' },

    // Cursor
    'cursor-auto': { cursor: 'auto' },
    'cursor-pointer': { cursor: 'pointer' },
    'cursor-wait': { cursor: 'wait' },
    'cursor-text': { cursor: 'text' },
    'cursor-move': { cursor: 'move' },
    'cursor-not-allowed': { cursor: 'not-allowed' },

    // User Select
    'select-none': { 'user-select': 'none' },
    'select-text': { 'user-select': 'text' },
    'select-all': { 'user-select': 'all' },
    'select-auto': { 'user-select': 'auto' },

    // Pointer Events
    'pointer-events-none': { 'pointer-events': 'none' },
    'pointer-events-auto': { 'pointer-events': 'auto' },

    // Border Style
    'border-solid': { 'border-style': 'solid' },
    'border-dashed': { 'border-style': 'dashed' },
    'border-dotted': { 'border-style': 'dotted' },
    'border-double': { 'border-style': 'double' },
    'border-none': { 'border-style': 'none' },

    // Box Sizing
    'box-border': { 'box-sizing': 'border-box' },
    'box-content': { 'box-sizing': 'content-box' },
  };

  // Spacing scale (Tailwind default: 0.25rem = 4px)
  private static readonly spacingScale: Record<string, string> = {
    '0': '0',
    '0.5': '0.125rem',
    '1': '0.25rem',
    '1.5': '0.375rem',
    '2': '0.5rem',
    '2.5': '0.625rem',
    '3': '0.75rem',
    '3.5': '0.875rem',
    '4': '1rem',
    '5': '1.25rem',
    '6': '1.5rem',
    '7': '1.75rem',
    '8': '2rem',
    '10': '2.5rem',
    '12': '3rem',
    '14': '3.5rem',
    '16': '4rem',
    '20': '5rem',
    '24': '6rem',
    '28': '7rem',
    '32': '8rem',
    '36': '9rem',
    '40': '10rem',
    '44': '11rem',
    '48': '12rem',
    '52': '13rem',
    '56': '14rem',
    '60': '15rem',
    '64': '16rem',
    '72': '18rem',
    '80': '20rem',
    '96': '24rem',
    px: '1px',
  };

  // Font sizes
  private static readonly fontSizes: Record<string, { 'font-size': string; 'line-height': string }> = {
    xs: { 'font-size': '0.75rem', 'line-height': '1rem' },
    sm: { 'font-size': '0.875rem', 'line-height': '1.25rem' },
    base: { 'font-size': '1rem', 'line-height': '1.5rem' },
    lg: { 'font-size': '1.125rem', 'line-height': '1.75rem' },
    xl: { 'font-size': '1.25rem', 'line-height': '1.75rem' },
    '2xl': { 'font-size': '1.5rem', 'line-height': '2rem' },
    '3xl': { 'font-size': '1.875rem', 'line-height': '2.25rem' },
    '4xl': { 'font-size': '2.25rem', 'line-height': '2.5rem' },
    '5xl': { 'font-size': '3rem', 'line-height': '1' },
    '6xl': { 'font-size': '3.75rem', 'line-height': '1' },
    '7xl': { 'font-size': '4.5rem', 'line-height': '1' },
    '8xl': { 'font-size': '6rem', 'line-height': '1' },
    '9xl': { 'font-size': '8rem', 'line-height': '1' },
  };

  // Breakpoints
  private static readonly breakpoints: Record<string, string> = {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
    '2xl': '1536px',
  };

  /**
   * Convert Tailwind classes to CSS
   */
  convert(classes: string): ConversionResult {
    logger.debug(`Converting Tailwind classes: ${classes}`);

    const result: ConversionResult = {
      baseStyles: {},
      hoverStyles: {},
      focusStyles: {},
      responsiveStyles: {},
    };

    const classList = classes.split(/\s+/).filter(Boolean);

    for (const cls of classList) {
      this.convertClass(cls, result);
    }

    return result;
  }

  /**
   * Convert a single Tailwind class
   */
  private convertClass(cls: string, result: ConversionResult): void {
    // Check for state modifiers: hover:, focus:, active:
    if (cls.includes(':')) {
      const [modifier, ...rest] = cls.split(':');
      const baseClass = rest.join(':');

      // Handle responsive modifiers
      if (TailwindConverter.breakpoints[modifier]) {
        if (!result.responsiveStyles[modifier]) {
          result.responsiveStyles[modifier] = {};
        }
        const styles = this.getStylesForClass(baseClass);
        Object.assign(result.responsiveStyles[modifier], styles);
        return;
      }

      // Handle state modifiers
      const styles = this.getStylesForClass(baseClass);
      if (modifier === 'hover') {
        Object.assign(result.hoverStyles, styles);
      } else if (modifier === 'focus') {
        Object.assign(result.focusStyles, styles);
      }
      return;
    }

    // Base class
    const styles = this.getStylesForClass(cls);
    Object.assign(result.baseStyles, styles);
  }

  /**
   * Get CSS styles for a Tailwind class
   */
  private getStylesForClass(cls: string): Record<string, string> {
    // Check direct mapping
    if (TailwindConverter.mappings[cls]) {
      return TailwindConverter.mappings[cls];
    }

    // Padding: p-4, px-2, py-4, pt-1, pr-2, pb-3, pl-4
    if (cls.startsWith('p-') || cls.startsWith('p')) {
      return this.convertSpacing('padding', cls);
    }

    // Margin: m-4, mx-2, my-4, mt-1, mr-2, mb-3, ml-4
    if (cls.startsWith('m-') || cls.startsWith('m')) {
      return this.convertSpacing('margin', cls);
    }

    // Gap: gap-4, gap-x-2, gap-y-4
    if (cls.startsWith('gap-')) {
      return this.convertGap(cls);
    }

    // Width: w-full, w-1/2, w-64, w-screen
    if (cls.startsWith('w-')) {
      return this.convertWidth(cls);
    }

    // Height: h-full, h-screen, h-64
    if (cls.startsWith('h-')) {
      return this.convertHeight(cls);
    }

    // Font size: text-lg, text-2xl
    if (cls.startsWith('text-')) {
      return this.convertTextSize(cls);
    }

    // Colors: bg-blue-500, text-red-600, border-gray-300
    if (cls.startsWith('bg-') || cls.startsWith('text-') || cls.startsWith('border-')) {
      return this.convertColor(cls);
    }

    // Border width: border, border-2, border-t-4
    if (cls.startsWith('border')) {
      return this.convertBorder(cls);
    }

    // Border radius: rounded, rounded-lg, rounded-full
    if (cls.startsWith('rounded')) {
      return this.convertBorderRadius(cls);
    }

    // Opacity: opacity-50
    if (cls.startsWith('opacity-')) {
      return this.convertOpacity(cls);
    }

    logger.warn(`Unknown Tailwind class: ${cls}`);
    return {};
  }

  /**
   * Convert spacing utilities (padding/margin)
   */
  private convertSpacing(property: string, cls: string): Record<string, string> {
    const match = cls.match(/^([pm])([xytrbl]?)-(.+)$/);
    if (!match) return {};

    const [, type, direction, value] = match;
    const spacing = TailwindConverter.spacingScale[value];
    if (!spacing) return {};

    const prop = type === 'p' ? 'padding' : 'margin';

    // No direction: p-4 → padding: 1rem
    if (!direction) {
      return { [prop]: spacing };
    }

    // x/y: px-4 → padding-left + padding-right
    if (direction === 'x') {
      return {
        [`${prop}-left`]: spacing,
        [`${prop}-right`]: spacing,
      };
    }
    if (direction === 'y') {
      return {
        [`${prop}-top`]: spacing,
        [`${prop}-bottom`]: spacing,
      };
    }

    // Specific side: pt-4 → padding-top
    const sides: Record<string, string> = {
      t: 'top',
      r: 'right',
      b: 'bottom',
      l: 'left',
    };
    return { [`${prop}-${sides[direction]}`]: spacing };
  }

  /**
   * Convert gap utilities
   */
  private convertGap(cls: string): Record<string, string> {
    const match = cls.match(/^gap-([xy])-(.+)$/) || cls.match(/^gap-(.+)$/);
    if (!match) return {};

    if (match.length === 3) {
      // gap-x-4 or gap-y-4
      const [, direction, value] = match;
      const spacing = TailwindConverter.spacingScale[value];
      if (!spacing) return {};
      return { [`gap-${direction}`]: spacing };
    }

    // gap-4
    const value = match[1];
    const spacing = TailwindConverter.spacingScale[value];
    if (!spacing) return {};
    return { gap: spacing };
  }

  /**
   * Convert width utilities
   */
  private convertWidth(cls: string): Record<string, string> {
    const value = cls.substring(2); // Remove 'w-'

    if (value === 'full') return { width: '100%' };
    if (value === 'screen') return { width: '100vw' };
    if (value === 'auto') return { width: 'auto' };
    if (value === 'min') return { width: 'min-content' };
    if (value === 'max') return { width: 'max-content' };

    // Fractions: w-1/2
    if (value.includes('/')) {
      const [num, denom] = value.split('/').map(Number);
      const percent = (num / denom) * 100;
      return { width: `${percent}%` };
    }

    // Fixed size: w-64
    const spacing = TailwindConverter.spacingScale[value];
    if (spacing) return { width: spacing };

    return {};
  }

  /**
   * Convert height utilities
   */
  private convertHeight(cls: string): Record<string, string> {
    const value = cls.substring(2); // Remove 'h-'

    if (value === 'full') return { height: '100%' };
    if (value === 'screen') return { height: '100vh' };
    if (value === 'auto') return { height: 'auto' };

    const spacing = TailwindConverter.spacingScale[value];
    if (spacing) return { height: spacing };

    return {};
  }

  /**
   * Convert text size utilities
   */
  private convertTextSize(cls: string): Record<string, string> {
    const size = cls.substring(5); // Remove 'text-'
    const fontSize = TailwindConverter.fontSizes[size];
    if (fontSize) return fontSize;
    return {};
  }

  /**
   * Convert color utilities
   */
  private convertColor(cls: string): Record<string, string> {
    // For now, return placeholder - should map to design tokens
    if (cls.startsWith('bg-')) {
      return { 'background-color': `var(--color-${cls.substring(3)})` };
    }
    if (cls.startsWith('text-')) {
      return { color: `var(--color-${cls.substring(5)})` };
    }
    if (cls.startsWith('border-')) {
      return { 'border-color': `var(--color-${cls.substring(7)})` };
    }
    return {};
  }

  /**
   * Convert border width utilities
   */
  private convertBorder(cls: string): Record<string, string> {
    if (cls === 'border') return { 'border-width': '1px' };

    const match = cls.match(/^border-([trbl])?-?(\d+)?$/);
    if (!match) return {};

    const [, direction, width] = match;
    const borderWidth = width ? `${width}px` : '1px';

    if (!direction) {
      return { 'border-width': borderWidth };
    }

    const sides: Record<string, string> = {
      t: 'top',
      r: 'right',
      b: 'bottom',
      l: 'left',
    };
    return { [`border-${sides[direction]}-width`]: borderWidth };
  }

  /**
   * Convert border radius utilities
   */
  private convertBorderRadius(cls: string): Record<string, string> {
    if (cls === 'rounded') return { 'border-radius': '0.25rem' };
    if (cls === 'rounded-none') return { 'border-radius': '0' };
    if (cls === 'rounded-sm') return { 'border-radius': '0.125rem' };
    if (cls === 'rounded-md') return { 'border-radius': '0.375rem' };
    if (cls === 'rounded-lg') return { 'border-radius': '0.5rem' };
    if (cls === 'rounded-xl') return { 'border-radius': '0.75rem' };
    if (cls === 'rounded-2xl') return { 'border-radius': '1rem' };
    if (cls === 'rounded-3xl') return { 'border-radius': '1.5rem' };
    if (cls === 'rounded-full') return { 'border-radius': '9999px' };
    return {};
  }

  /**
   * Convert opacity utilities
   */
  private convertOpacity(cls: string): Record<string, string> {
    const value = cls.substring(8); // Remove 'opacity-'
    const opacity = parseInt(value) / 100;
    return { opacity: String(opacity) };
  }

  /**
   * Generate CSS string from conversion result
   */
  generateCSS(result: ConversionResult, className: string): string {
    const lines: string[] = [];

    // Base styles
    if (Object.keys(result.baseStyles).length > 0) {
      lines.push(`.${className} {`);
      for (const [prop, value] of Object.entries(result.baseStyles)) {
        lines.push(`  ${prop}: ${value};`);
      }
      lines.push('}');
    }

    // Hover styles
    if (Object.keys(result.hoverStyles).length > 0) {
      lines.push('');
      lines.push(`.${className}:hover {`);
      for (const [prop, value] of Object.entries(result.hoverStyles)) {
        lines.push(`  ${prop}: ${value};`);
      }
      lines.push('}');
    }

    // Focus styles
    if (Object.keys(result.focusStyles).length > 0) {
      lines.push('');
      lines.push(`.${className}:focus {`);
      for (const [prop, value] of Object.entries(result.focusStyles)) {
        lines.push(`  ${prop}: ${value};`);
      }
      lines.push('}');
    }

    // Responsive styles
    for (const [breakpoint, styles] of Object.entries(result.responsiveStyles)) {
      if (Object.keys(styles).length > 0) {
        lines.push('');
        lines.push(`@media (min-width: ${TailwindConverter.breakpoints[breakpoint]}) {`);
        lines.push(`  .${className} {`);
        for (const [prop, value] of Object.entries(styles)) {
          lines.push(`    ${prop}: ${value};`);
        }
        lines.push('  }');
        lines.push('}');
      }
    }

    return lines.join('\n');
  }
}
