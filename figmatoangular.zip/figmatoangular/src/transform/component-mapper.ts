/**
 * Component Mapper
 * Maps Figma components to existing Angular components
 */

import { logger } from '../shared/utils/logger.service';
import { ComponentRegistry, RegisteredComponent } from '../design-system/component-registry';
import { ParsedComponent } from './react-parser.service';

export interface ComponentMatch {
  matched: boolean;
  component?: RegisteredComponent;
  similarity: number;
  reason: string;
}

export class ComponentMapper {
  constructor(
    private registry: ComponentRegistry,
    private codeConnectMappings: Record<string, string> = {}
  ) {}

  /**
   * Find matching component for Figma component
   * Priority:
   * 1. Code Connect mappings (explicit)
   * 2. Exact name match
   * 3. Similar name match
   * 4. Props similarity
   */
  findMatch(figmaComponent: ParsedComponent): ComponentMatch {
    logger.debug(`Finding match for component: ${figmaComponent.name}`);

    // 1. Check Code Connect mappings (HIGHEST PRIORITY)
    if (this.codeConnectMappings[figmaComponent.name]) {
      const componentPath = this.codeConnectMappings[figmaComponent.name];
      const component = this.findByPath(componentPath);
      if (component) {
        logger.success(`Found Code Connect mapping: ${figmaComponent.name} → ${component.name}`);
        return {
          matched: true,
          component,
          similarity: 100,
          reason: 'Code Connect mapping',
        };
      }
    }

    // 2. Exact name match
    const exactMatch = this.registry.findByName(figmaComponent.name);
    if (exactMatch) {
      logger.success(`Found exact name match: ${figmaComponent.name}`);
      return {
        matched: true,
        component: exactMatch,
        similarity: 100,
        reason: 'Exact name match',
      };
    }

    // 3. Similar name match (fuzzy)
    const similarMatch = this.findSimilarByName(figmaComponent.name);
    if (similarMatch && similarMatch.similarity >= 0.8) {
      logger.success(
        `Found similar name match: ${figmaComponent.name} → ${similarMatch.component.name} (${similarMatch.similarity * 100}%)`
      );
      return similarMatch;
    }

    // 4. Props similarity
    const propsMatch = this.findByPropsSimilarity(figmaComponent);
    if (propsMatch && propsMatch.similarity >= 0.7) {
      logger.success(
        `Found props similarity match: ${figmaComponent.name} → ${propsMatch.component.name} (${propsMatch.similarity * 100}%)`
      );
      return propsMatch;
    }

    // No match found
    logger.info(`No match found for: ${figmaComponent.name} - will generate new component`);
    return {
      matched: false,
      similarity: 0,
      reason: 'No suitable match found',
    };
  }

  /**
   * Find component by path (from Code Connect)
   */
  private findByPath(path: string): RegisteredComponent | null {
    const all = this.registry.getAll();
    for (const component of all) {
      if (component.path === path || component.path.endsWith(path)) {
        return component;
      }
    }
    return null;
  }

  /**
   * Find similar component by name (fuzzy matching)
   */
  private findSimilarByName(name: string): ComponentMatch | null {
    const all = this.registry.getAll();
    let bestMatch: ComponentMatch | null = null;

    for (const component of all) {
      const similarity = this.calculateNameSimilarity(name, component.name);
      if (similarity > 0.7 && (!bestMatch || similarity > bestMatch.similarity)) {
        bestMatch = {
          matched: true,
          component,
          similarity,
          reason: 'Similar name',
        };
      }
    }

    return bestMatch;
  }

  /**
   * Find component by props similarity
   */
  private findByPropsSimilarity(figmaComponent: ParsedComponent): ComponentMatch | null {
    const all = this.registry.getAll();
    let bestMatch: ComponentMatch | null = null;

    const figmaProps = new Set(figmaComponent.props.map((p) => p.name.toLowerCase()));

    for (const component of all) {
      const componentProps = new Set(component.props.map((p) => p.toLowerCase()));

      // Calculate Jaccard similarity
      const intersection = new Set([...figmaProps].filter((x) => componentProps.has(x)));
      const union = new Set([...figmaProps, ...componentProps]);

      const similarity = intersection.size / union.size;

      if (similarity > 0.6 && (!bestMatch || similarity > bestMatch.similarity)) {
        bestMatch = {
          matched: true,
          component,
          similarity,
          reason: 'Similar props',
        };
      }
    }

    return bestMatch;
  }

  /**
   * Calculate name similarity (Levenshtein-based)
   */
  private calculateNameSimilarity(name1: string, name2: string): number {
    const s1 = name1.toLowerCase().replace(/[^a-z0-9]/g, '');
    const s2 = name2.toLowerCase().replace(/[^a-z0-9]/g, '');

    if (s1 === s2) return 1.0;

    // Simple substring match
    if (s1.includes(s2) || s2.includes(s1)) {
      return 0.85;
    }

    // Levenshtein distance
    const distance = this.levenshteinDistance(s1, s2);
    const maxLen = Math.max(s1.length, s2.length);
    const similarity = 1 - distance / maxLen;

    return similarity;
  }

  /**
   * Calculate Levenshtein distance
   */
  private levenshteinDistance(s1: string, s2: string): number {
    const m = s1.length;
    const n = s2.length;
    const dp: number[][] = [];

    for (let i = 0; i <= m; i++) {
      dp[i] = [i];
    }

    for (let j = 0; j <= n; j++) {
      dp[0][j] = j;
    }

    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        if (s1[i - 1] === s2[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1];
        } else {
          dp[i][j] = Math.min(
            dp[i - 1][j] + 1, // deletion
            dp[i][j - 1] + 1, // insertion
            dp[i - 1][j - 1] + 1 // substitution
          );
        }
      }
    }

    return dp[m][n];
  }

  /**
   * Check if component should be reused based on config
   */
  shouldReuse(match: ComponentMatch, reuseThreshold: number = 0.8): boolean {
    return match.matched && match.similarity >= reuseThreshold;
  }
}
