import { Injectable } from '@angular/core';
// import { Observable, from, of } from 'rxjs'; // Unused imports
import { environment } from '../../environments/environment';

export interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number;
  key: string;
  size: number;
}

export interface CacheStats {
  entries: number;
  totalSize: number;
  hits: number;
  misses: number;
  hitRate: number;
  oldestEntry: Date | null;
  newestEntry: Date | null;
}

export type CacheStrategy = 'memory' | 'localStorage' | 'indexedDB' | 'hybrid';

@Injectable({
  providedIn: 'root'
})
export class CacheService {
  private memoryCache = new Map<string, CacheEntry<any>>();
  private stats = {
    hits: 0,
    misses: 0
  };
  private maxSize = environment.cache?.maxSize || 52428800; // 50MB default
  private defaultTTL = environment.cache?.ttl || 3600000; // 1 hour default
  private strategy: CacheStrategy = (environment.cache?.strategy as CacheStrategy) || 'memory';

  /**
   * Get item from cache
   */
  async get<T>(key: string): Promise<T | null> {
    try {
      let entry: CacheEntry<T> | null = null;

      switch (this.strategy) {
        case 'memory':
          entry = this.getFromMemory<T>(key);
          break;
        case 'localStorage':
          entry = this.getFromLocalStorage<T>(key);
          break;
        case 'indexedDB':
          entry = await this.getFromIndexedDB<T>(key);
          break;
        case 'hybrid':
          // Try memory first, then localStorage
          entry = this.getFromMemory<T>(key);
          if (!entry) {
            entry = this.getFromLocalStorage<T>(key);
            if (entry) {
              // Promote to memory cache
              this.memoryCache.set(key, entry);
            }
          }
          break;
      }

      if (entry && this.isValid(entry)) {
        this.stats.hits++;
        return entry.data;
      }

      this.stats.misses++;
      return null;
    } catch (error) {
      console.error(`Cache get error for key ${key}:`, error);
      return null;
    }
  }

  /**
   * Set item in cache
   */
  async set<T>(key: string, data: T, ttl?: number): Promise<void> {
    const entry: CacheEntry<T> = {
      data,
      timestamp: Date.now(),
      ttl: ttl || this.defaultTTL,
      key,
      size: this.calculateSize(data)
    };

    // Check size constraints
    if (entry.size > this.maxSize) {
      console.warn(`Cache entry ${key} exceeds max size (${entry.size} > ${this.maxSize})`);
      return;
    }

    // Evict if needed
    await this.evictIfNeeded(entry.size);

    switch (this.strategy) {
      case 'memory':
        this.setInMemory(key, entry);
        break;
      case 'localStorage':
        this.setInLocalStorage(key, entry);
        break;
      case 'indexedDB':
        await this.setInIndexedDB(key, entry);
        break;
      case 'hybrid':
        // Store in both memory and localStorage
        this.setInMemory(key, entry);
        this.setInLocalStorage(key, entry);
        break;
    }
  }

  /**
   * Remove item from cache
   */
  async remove(key: string): Promise<void> {
    switch (this.strategy) {
      case 'memory':
        this.memoryCache.delete(key);
        break;
      case 'localStorage':
        localStorage.removeItem(this.getCacheKey(key));
        break;
      case 'indexedDB':
        await this.removeFromIndexedDB(key);
        break;
      case 'hybrid':
        this.memoryCache.delete(key);
        localStorage.removeItem(this.getCacheKey(key));
        break;
    }
  }

  /**
   * Clear all cache
   */
  async clear(): Promise<void> {
    switch (this.strategy) {
      case 'memory':
        this.memoryCache.clear();
        break;
      case 'localStorage':
        this.clearLocalStorage();
        break;
      case 'indexedDB':
        await this.clearIndexedDB();
        break;
      case 'hybrid':
        this.memoryCache.clear();
        this.clearLocalStorage();
        break;
    }

    this.stats.hits = 0;
    this.stats.misses = 0;
  }

  /**
   * Clear expired entries
   */
  async clearExpired(): Promise<number> {
    let cleared = 0;

    switch (this.strategy) {
      case 'memory':
        for (const [key, entry] of this.memoryCache.entries()) {
          if (!this.isValid(entry)) {
            this.memoryCache.delete(key);
            cleared++;
          }
        }
        break;
      case 'localStorage':
        cleared = this.clearExpiredLocalStorage();
        break;
      case 'indexedDB':
        cleared = await this.clearExpiredIndexedDB();
        break;
      case 'hybrid':
        // Clear from both
        for (const [key, entry] of this.memoryCache.entries()) {
          if (!this.isValid(entry)) {
            this.memoryCache.delete(key);
            cleared++;
          }
        }
        cleared += this.clearExpiredLocalStorage();
        break;
    }

    console.log(`Cleared ${cleared} expired cache entries`);
    return cleared;
  }

  /**
   * Get cache statistics
   */
  getStats(): CacheStats {
    let entries = 0;
    let totalSize = 0;
    let oldestEntry: Date | null = null;
    let newestEntry: Date | null = null;

    switch (this.strategy) {
      case 'memory':
        entries = this.memoryCache.size;
        for (const entry of this.memoryCache.values()) {
          totalSize += entry.size;
          const date = new Date(entry.timestamp);
          if (!oldestEntry || date < oldestEntry) oldestEntry = date;
          if (!newestEntry || date > newestEntry) newestEntry = date;
        }
        break;
      case 'localStorage':
        const lsStats = this.getLocalStorageStats();
        entries = lsStats.entries;
        totalSize = lsStats.totalSize;
        oldestEntry = lsStats.oldestEntry;
        newestEntry = lsStats.newestEntry;
        break;
      // Add other strategies as needed
    }

    const hitRate = this.stats.hits + this.stats.misses > 0
      ? (this.stats.hits / (this.stats.hits + this.stats.misses)) * 100
      : 0;

    return {
      entries,
      totalSize,
      hits: this.stats.hits,
      misses: this.stats.misses,
      hitRate,
      oldestEntry,
      newestEntry
    };
  }

  /**
   * Check if cache has key
   */
  async has(key: string): Promise<boolean> {
    const value = await this.get(key);
    return value !== null;
  }

  /**
   * Get all keys
   */
  async keys(): Promise<string[]> {
    switch (this.strategy) {
      case 'memory':
        return Array.from(this.memoryCache.keys());
      case 'localStorage':
        return this.getLocalStorageKeys();
      case 'indexedDB':
        return await this.getIndexedDBKeys();
      case 'hybrid':
        const memoryKeys = Array.from(this.memoryCache.keys());
        const lsKeys = this.getLocalStorageKeys();
        return [...new Set([...memoryKeys, ...lsKeys])];
      default:
        return [];
    }
  }

  // Private helper methods

  private getFromMemory<T>(key: string): CacheEntry<T> | null {
    return this.memoryCache.get(key) || null;
  }

  private setInMemory<T>(key: string, entry: CacheEntry<T>): void {
    this.memoryCache.set(key, entry);
  }

  private getFromLocalStorage<T>(key: string): CacheEntry<T> | null {
    try {
      const item = localStorage.getItem(this.getCacheKey(key));
      if (!item) return null;
      return JSON.parse(item);
    } catch (error) {
      console.error(`Failed to get from localStorage: ${key}`, error);
      return null;
    }
  }

  private setInLocalStorage<T>(key: string, entry: CacheEntry<T>): void {
    try {
      localStorage.setItem(this.getCacheKey(key), JSON.stringify(entry));
    } catch (error) {
      console.error(`Failed to set in localStorage: ${key}`, error);
      // If quota exceeded, clear some space
      if (error instanceof DOMException && error.code === 22) {
        this.clearOldestLocalStorageEntries(5);
        // Retry
        try {
          localStorage.setItem(this.getCacheKey(key), JSON.stringify(entry));
        } catch (retryError) {
          console.error('Failed to set after clearing space', retryError);
        }
      }
    }
  }

  private clearLocalStorage(): void {
    const keys = Object.keys(localStorage);
    keys.forEach(key => {
      if (key.startsWith('cache:')) {
        localStorage.removeItem(key);
      }
    });
  }

  private clearExpiredLocalStorage(): number {
    let cleared = 0;
    const keys = Object.keys(localStorage);

    keys.forEach(key => {
      if (key.startsWith('cache:')) {
        try {
          const entry = JSON.parse(localStorage.getItem(key) || '');
          if (!this.isValid(entry)) {
            localStorage.removeItem(key);
            cleared++;
          }
        } catch (error) {
          // Remove invalid entries
          localStorage.removeItem(key);
          cleared++;
        }
      }
    });

    return cleared;
  }

  private getLocalStorageKeys(): string[] {
    const keys: string[] = [];
    Object.keys(localStorage).forEach(key => {
      if (key.startsWith('cache:')) {
        keys.push(key.replace('cache:', ''));
      }
    });
    return keys;
  }

  private getLocalStorageStats(): {
    entries: number;
    totalSize: number;
    oldestEntry: Date | null;
    newestEntry: Date | null;
  } {
    let entries = 0;
    let totalSize = 0;
    let oldestEntry: Date | null = null;
    let newestEntry: Date | null = null;

    Object.keys(localStorage).forEach(key => {
      if (key.startsWith('cache:')) {
        try {
          const entry = JSON.parse(localStorage.getItem(key) || '');
          entries++;
          totalSize += entry.size || 0;
          const date = new Date(entry.timestamp);
          if (!oldestEntry || date < oldestEntry) oldestEntry = date;
          if (!newestEntry || date > newestEntry) newestEntry = date;
        } catch (error) {
          // Skip invalid entries
        }
      }
    });

    return { entries, totalSize, oldestEntry, newestEntry };
  }

  private clearOldestLocalStorageEntries(count: number): void {
    const entries: Array<{ key: string; timestamp: number }> = [];

    Object.keys(localStorage).forEach(key => {
      if (key.startsWith('cache:')) {
        try {
          const entry = JSON.parse(localStorage.getItem(key) || '');
          entries.push({ key, timestamp: entry.timestamp });
        } catch (error) {
          // Remove invalid entries
          localStorage.removeItem(key);
        }
      }
    });

    // Sort by timestamp (oldest first)
    entries.sort((a, b) => a.timestamp - b.timestamp);

    // Remove oldest entries
    entries.slice(0, count).forEach(entry => {
      localStorage.removeItem(entry.key);
    });
  }

  // IndexedDB implementation (simplified)
  private async getFromIndexedDB<T>(_key: string): Promise<CacheEntry<T> | null> {
    // Implementation would require IndexedDB setup
    // This is a placeholder
    return null;
  }

  private async setInIndexedDB<T>(_key: string, _entry: CacheEntry<T>): Promise<void> {
    // Implementation would require IndexedDB setup
    // This is a placeholder
  }

  private async removeFromIndexedDB(_key: string): Promise<void> {
    // Implementation would require IndexedDB setup
    // This is a placeholder
  }

  private async clearIndexedDB(): Promise<void> {
    // Implementation would require IndexedDB setup
    // This is a placeholder
  }

  private async clearExpiredIndexedDB(): Promise<number> {
    // Implementation would require IndexedDB setup
    // This is a placeholder
    return 0;
  }

  private async getIndexedDBKeys(): Promise<string[]> {
    // Implementation would require IndexedDB setup
    // This is a placeholder
    return [];
  }

  // Utility methods

  private isValid(entry: CacheEntry<any>): boolean {
    if (!environment.cache?.enabled) {
      return false;
    }

    const now = Date.now();
    const age = now - entry.timestamp;
    return age < entry.ttl;
  }

  private calculateSize(data: any): number {
    try {
      const str = JSON.stringify(data);
      // Rough estimate: 2 bytes per character
      return str.length * 2;
    } catch (error) {
      return 0;
    }
  }

  private getCacheKey(key: string): string {
    return `cache:${key}`;
  }

  private async evictIfNeeded(newEntrySize: number): Promise<void> {
    const stats = this.getStats();

    if (stats.totalSize + newEntrySize <= this.maxSize) {
      return;
    }

    // Need to evict - use LRU strategy
    const toEvict = Math.ceil((stats.totalSize + newEntrySize - this.maxSize) / (this.maxSize * 0.1));

    switch (this.strategy) {
      case 'memory':
        this.evictFromMemory(toEvict);
        break;
      case 'localStorage':
        this.clearOldestLocalStorageEntries(toEvict);
        break;
      // Add other strategies as needed
    }
  }

  private evictFromMemory(count: number): void {
    const entries = Array.from(this.memoryCache.entries());
    entries.sort((a, b) => a[1].timestamp - b[1].timestamp);

    for (let i = 0; i < Math.min(count, entries.length); i++) {
      this.memoryCache.delete(entries[i][0]);
    }
  }
}