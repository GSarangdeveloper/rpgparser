import { Injectable } from '@angular/core';
import { Observable, from, of, forkJoin, throwError } from 'rxjs';
import { map, switchMap, catchError, tap } from 'rxjs/operators';
import { LLMService, TransformContext, GeneratedComponent } from './llm.service';
import { AuthService } from '../../auth/auth.service';
import { McpClientService } from '../../mcp/mcp-client.service';
// import { AssetManagerService } from '../assets/asset-manager.service'; // Module not found
import { ProjectContextService } from '../project/project-context.service';
// import { ValidationService } from '../validation/validation.service'; // Module not found
// import { FileService } from '../file/file.service'; // Module not found

export interface ConversionConfig {
  figmaUrl: string;
  outputDir: string;
  approach: 'llm' | 'rule-based' | 'hybrid';
  llmConfig?: {
    provider: 'openai' | 'anthropic' | 'azure';
    model: string;
    temperature?: number;
    maxRetries?: number;
  };
  validation?: {
    validateVisual: boolean;
    validateAccessibility: boolean;
    validateCompilation: boolean;
    strictMode: boolean;
  };
  optimization?: {
    optimizeImages: boolean;
    minifyCode: boolean;
    treeshake: boolean;
  };
}

export interface ConversionResult {
  success: boolean;
  components: GeneratedComponent[];
  assets: AssetInfo[];
  validation: ValidationResult;
  cost?: {
    llmCost: number;
    requests: number;
  };
  duration: number;
  errors?: string[];
  warnings?: string[];
}

export interface AssetInfo {
  url: string;
  localPath: string;
  type: 'image' | 'icon' | 'font';
  optimized: boolean;
  originalSize: number;
  optimizedSize: number;
}

export interface ValidationResult {
  visual: {
    passed: boolean;
    similarity: number;
    differences?: string[];
  };
  accessibility: {
    passed: boolean;
    violations?: AccessibilityViolation[];
  };
  compilation: {
    passed: boolean;
    errors?: string[];
    warnings?: string[];
  };
  quality: {
    score: number;
    metrics: QualityMetrics;
  };
}

export interface AccessibilityViolation {
  rule: string;
  severity: 'error' | 'warning' | 'info';
  element: string;
  message: string;
}

export interface QualityMetrics {
  codeComplexity: number;
  maintainability: number;
  testCoverage: number;
  performance: number;
  accessibility: number;
}

export interface FigmaData {
  code: string;
  screenshot?: Buffer;
  designTokens?: any;
  codeConnect?: any;
  assets?: string[];
}

@Injectable({
  providedIn: 'root'
})
export class LLMOrchestratorService {
  private conversionHistory: ConversionResult[] = [];
  private totalLLMCost = 0;

  constructor(
    private llmService: LLMService,
    private authService: AuthService,
    private mcpClient: McpClientService,
    private assetManager: any, // AssetManagerService - module not found
    private projectContext: ProjectContextService,
    private validationService: any, // ValidationService - module not found
    private fileService: any // FileService - module not found
  ) {}

  /**
   * Main conversion method
   */
  convert(config: ConversionConfig): Observable<ConversionResult> {
    const startTime = Date.now();

    return from(this.authService.isAuthenticated()).pipe(
      switchMap(() => {
        switch (config.approach) {
          case 'llm':
            return this.convertWithLLM(config, startTime);
          case 'rule-based':
            return this.convertWithRules(config, startTime);
          case 'hybrid':
            return this.convertWithHybrid(config, startTime);
          default:
            return throwError(() => new Error(`Unknown approach: ${config.approach}`));
        }
      }),
      tap(result => {
        this.conversionHistory.push(result);
        if (result.cost) {
          this.totalLLMCost += result.cost.llmCost;
        }
      }),
      catchError(error => {
        console.error('Conversion failed:', error);
        return of({
          success: false,
          components: [],
          assets: [],
          validation: this.getEmptyValidation(),
          duration: Date.now() - startTime,
          errors: [error.message]
        });
      })
    );
  }

  /**
   * LLM-powered conversion
   */
  private convertWithLLM(config: ConversionConfig, startTime: number): Observable<ConversionResult> {
    return from(this.fetchFigmaData(config.figmaUrl)).pipe(
      switchMap(figmaData =>
        from(this.loadProjectContext(config)).pipe(
          map(context => ({ figmaData, context }))
        )
      ),
      switchMap(({ figmaData, context }) =>
        from(this.transformWithLLM(figmaData, context, config))
      ),
      switchMap(components =>
        forkJoin({
          components: of(components),
          assets: from(this.downloadAndOptimizeAssets(components, config)),
          validation: config.validation?.validateVisual || config.validation?.validateAccessibility || config.validation?.validateCompilation
            ? from(this.validateComponents(components, config))
            : of(this.getEmptyValidation())
        })
      ),
      switchMap(result =>
        from(this.saveComponents(result.components, config.outputDir)).pipe(
          map(() => result)
        )
      ),
      map(result => {
        const stats = this.llmService.getUsageStats();
        return {
          success: true,
          components: result.components,
          assets: result.assets,
          validation: result.validation,
          cost: {
            llmCost: stats.totalCost,
            requests: stats.requests
          },
          duration: Date.now() - startTime,
          warnings: this.collectWarnings(result)
        };
      })
    );
  }

  /**
   * Rule-based conversion (fallback or when LLM not available)
   */
  private convertWithRules(_config: ConversionConfig, _startTime: number): Observable<ConversionResult> {
    // This would use the existing rule-based transformation logic
    // Placeholder for integration with existing services
    return throwError(() => new Error('Rule-based conversion not yet implemented'));
  }

  /**
   * Hybrid approach - rules first, then LLM enhancement
   */
  private convertWithHybrid(_config: ConversionConfig, _startTime: number): Observable<ConversionResult> {
    // Start with rule-based, then enhance with LLM
    // Placeholder for hybrid implementation
    return throwError(() => new Error('Hybrid conversion not yet implemented'));
  }

  /**
   * Fetch all data from Figma via MCP
   */
  private async fetchFigmaData(figmaUrl: string): Promise<FigmaData> {
    console.log('Fetching Figma data via MCP...');

    // Required: get_code first
    // Note: McpClientService doesn't have these methods directly
    // They should be called through ToolOrchestratorService
    const code = await (this.mcpClient as any).getCode?.(figmaUrl)?.toPromise?.() || null;
    if (!code) {
      console.warn('Failed to fetch code from Figma - using placeholder');
    }

    // Required: get_screenshot after code
    let screenshot: Buffer | undefined;
    try {
      screenshot = await (this.mcpClient as any).getScreenshot?.(figmaUrl)?.toPromise?.();
    } catch (error) {
      console.warn('Failed to fetch screenshot:', error);
    }

    // Optional: get design tokens
    let designTokens: any;
    try {
      designTokens = await (this.mcpClient as any).getVariableDefs?.(figmaUrl)?.toPromise?.();
    } catch (error) {
      console.warn('Failed to fetch design tokens:', error);
    }

    // Optional: get code connect mappings
    let codeConnect: any;
    try {
      codeConnect = await (this.mcpClient as any).getCodeConnectMap?.(figmaUrl)?.toPromise?.();
    } catch (error) {
      console.warn('Failed to fetch code connect:', error);
    }

    return {
      code,
      screenshot,
      designTokens,
      codeConnect
    };
  }

  /**
   * Load project context for transformation
   */
  private async loadProjectContext(_config: ConversionConfig): Promise<TransformContext> {
    const [existingComponents, projectRules, designSystem] = await Promise.all([
      this.projectContext.getExistingComponents(),
      this.projectContext.getProjectRules(),
      this.projectContext.getDesignSystem()
    ]);

    return {
      reactCode: '',  // Will be filled from figmaData
      existingComponents,
      projectRules,
      designSystem
    };
  }

  /**
   * Transform using LLM
   */
  private async transformWithLLM(
    figmaData: FigmaData,
    context: TransformContext,
    config: ConversionConfig
  ): Promise<GeneratedComponent[]> {
    console.log('Transforming with LLM...');

    // Update context with Figma data
    context.reactCode = figmaData.code;
    context.screenshot = figmaData.screenshot;
    context.designTokens = figmaData.designTokens;

    // Configure LLM if custom settings provided
    if (config.llmConfig) {
      // Update LLM configuration
      // This would need to be implemented in the LLM service
    }

    const components: GeneratedComponent[] = [];
    let retries = 0;
    const maxRetries = config.llmConfig?.maxRetries || 3;

    while (retries < maxRetries) {
      try {
        const component = await this.llmService.transformToAngular(context);

        // Validate the generated component
        const validation = await this.llmService.validateComponent(component);
        if (!validation.valid) {
          console.warn('Component validation failed:', validation.errors);
          if (retries === maxRetries - 1) {
            throw new Error(`Failed to generate valid component: ${validation.errors.join(', ')}`);
          }
        } else {
          components.push(component);
          break;
        }
      } catch (error) {
        console.error(`LLM transformation attempt ${retries + 1} failed:`, error);
        if (retries === maxRetries - 1) {
          throw error;
        }
      }
      retries++;
    }

    // Handle sub-components if needed
    for (const component of components) {
      if (component.newComponents && component.newComponents.length > 0) {
        console.log(`Generating ${component.newComponents.length} sub-components...`);
        // Recursively generate sub-components
        // This would need additional implementation
      }
    }

    return components;
  }

  /**
   * Download and optimize assets
   */
  private async downloadAndOptimizeAssets(
    components: GeneratedComponent[],
    config: ConversionConfig
  ): Promise<AssetInfo[]> {
    const assets: AssetInfo[] = [];

    // Extract asset URLs from components
    const assetUrls = this.extractAssetUrls(components);

    for (const url of assetUrls) {
      try {
        const asset = await this.assetManager.downloadAsset(url).toPromise();

        if (config.optimization?.optimizeImages && asset.type === 'image') {
          const optimized = await this.assetManager.optimizeImage(asset.localPath).toPromise();
          assets.push({
            ...asset,
            optimized: true,
            optimizedSize: optimized.size
          });
        } else {
          assets.push({
            ...asset,
            optimized: false,
            optimizedSize: asset.originalSize
          });
        }
      } catch (error) {
        console.warn(`Failed to download asset ${url}:`, error);
      }
    }

    return assets;
  }

  /**
   * Extract asset URLs from components
   */
  private extractAssetUrls(components: GeneratedComponent[]): string[] {
    const urls: string[] = [];

    for (const component of components) {
      // Extract from template
      const templateUrls = component.template.match(/src="([^"]+)"/g) || [];
      urls.push(...templateUrls.map(u => u.replace(/src="|"/g, '')));

      // Extract from styles
      const styleUrls = component.styles.match(/url\(['"]?([^'")]+)['"]?\)/g) || [];
      urls.push(...styleUrls.map(u => u.replace(/url\(['"]?|['"]?\)/g, '')));
    }

    // Remove duplicates and filter out data URLs
    return [...new Set(urls)].filter(url => !url.startsWith('data:'));
  }

  /**
   * Validate generated components
   */
  private async validateComponents(
    components: GeneratedComponent[],
    config: ConversionConfig
  ): Promise<ValidationResult> {
    const result: ValidationResult = {
      visual: { passed: true, similarity: 100 },
      accessibility: { passed: true },
      compilation: { passed: true },
      quality: { score: 100, metrics: this.getDefaultMetrics() }
    };

    for (const component of components) {
      // Visual validation
      if (config.validation?.validateVisual) {
        const visual = await this.validationService.validateVisual(component).toPromise();
        if (!visual.passed) {
          result.visual.passed = false;
          result.visual.similarity = Math.min(result.visual.similarity, visual.similarity);
          result.visual.differences = [...(result.visual.differences || []), ...visual.differences];
        }
      }

      // Accessibility validation
      if (config.validation?.validateAccessibility) {
        const a11y = await this.validationService.validateAccessibility(component).toPromise();
        if (!a11y.passed) {
          result.accessibility.passed = false;
          result.accessibility.violations = [...(result.accessibility.violations || []), ...a11y.violations];
        }
      }

      // Compilation validation
      if (config.validation?.validateCompilation) {
        const compilation = await this.validationService.validateCompilation(component).toPromise();
        if (!compilation.passed) {
          result.compilation.passed = false;
          result.compilation.errors = [...(result.compilation.errors || []), ...compilation.errors];
          result.compilation.warnings = [...(result.compilation.warnings || []), ...compilation.warnings];
        }
      }

      // Quality metrics
      const quality = await this.validationService.calculateQuality(component).toPromise();
      result.quality.score = Math.min(result.quality.score, quality.score);
      result.quality.metrics = this.mergeMetrics(result.quality.metrics, quality.metrics);
    }

    return result;
  }

  /**
   * Save generated components to files
   */
  private async saveComponents(components: GeneratedComponent[], outputDir: string): Promise<void> {
    for (const component of components) {
      const componentDir = `${outputDir}/${component.name}`;

      // Save TypeScript file
      await this.fileService.saveFile(
        `${componentDir}/${component.name}.component.ts`,
        component.typescript
      ).toPromise();

      // Save template file
      await this.fileService.saveFile(
        `${componentDir}/${component.name}.component.html`,
        component.template
      ).toPromise();

      // Save styles file
      const styleExt = component.styles.includes('@import') || component.styles.includes('$') ? 'scss' : 'css';
      await this.fileService.saveFile(
        `${componentDir}/${component.name}.component.${styleExt}`,
        component.styles
      ).toPromise();

      // Save module file if provided
      if (component.module) {
        await this.fileService.saveFile(
          `${componentDir}/${component.name}.module.ts`,
          component.module
        ).toPromise();
      }

      // Save spec file if provided
      if (component.spec) {
        await this.fileService.saveFile(
          `${componentDir}/${component.name}.component.spec.ts`,
          component.spec
        ).toPromise();
      }
    }
  }

  /**
   * Collect warnings from results
   */
  private collectWarnings(result: any): string[] {
    const warnings: string[] = [];

    if (result.validation?.visual?.similarity < 95) {
      warnings.push(`Visual similarity is ${result.validation.visual.similarity}%`);
    }

    if (result.validation?.accessibility?.violations?.length > 0) {
      warnings.push(`Found ${result.validation.accessibility.violations.length} accessibility issues`);
    }

    if (result.validation?.compilation?.warnings?.length > 0) {
      warnings.push(`Compilation has ${result.validation.compilation.warnings.length} warnings`);
    }

    if (result.validation?.quality?.score < 80) {
      warnings.push(`Quality score is ${result.validation.quality.score}/100`);
    }

    return warnings;
  }

  /**
   * Get empty validation result
   */
  private getEmptyValidation(): ValidationResult {
    return {
      visual: { passed: true, similarity: 100 },
      accessibility: { passed: true },
      compilation: { passed: true },
      quality: { score: 100, metrics: this.getDefaultMetrics() }
    };
  }

  /**
   * Get default quality metrics
   */
  private getDefaultMetrics(): QualityMetrics {
    return {
      codeComplexity: 0,
      maintainability: 100,
      testCoverage: 0,
      performance: 100,
      accessibility: 100
    };
  }

  /**
   * Merge quality metrics
   */
  private mergeMetrics(metrics1: QualityMetrics, metrics2: QualityMetrics): QualityMetrics {
    return {
      codeComplexity: Math.max(metrics1.codeComplexity, metrics2.codeComplexity),
      maintainability: Math.min(metrics1.maintainability, metrics2.maintainability),
      testCoverage: Math.min(metrics1.testCoverage, metrics2.testCoverage),
      performance: Math.min(metrics1.performance, metrics2.performance),
      accessibility: Math.min(metrics1.accessibility, metrics2.accessibility)
    };
  }

  /**
   * Get conversion history
   */
  getHistory(): ConversionResult[] {
    return this.conversionHistory;
  }

  /**
   * Get total LLM cost
   */
  getTotalCost(): number {
    return this.totalLLMCost;
  }

  /**
   * Clear history
   */
  clearHistory(): void {
    this.conversionHistory = [];
    this.totalLLMCost = 0;
  }
}