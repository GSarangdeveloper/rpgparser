/**
 * Specialized prompt templates for different conversion scenarios
 */

export class ConversionPrompts {
  /**
   * Main component conversion prompt
   */
  static readonly COMPONENT_CONVERSION = `
You are an expert Angular developer converting Figma designs to production-ready Angular components.

## Input: React + Tailwind Code from Figma

{reactCode}

## Design Context

### Design Tokens Available
{designTokens}

### Existing Components to Reuse
{existingComponents}

### Project Configuration
- Style Format: {styleFormat}
- Change Detection: {changeDetection}
- Naming Convention: {namingConvention}
- Accessibility Level: {accessibilityLevel}

## Conversion Requirements

1. **Component Architecture**
   - Use Angular best practices and style guide
   - Implement proper lifecycle hooks
   - Use dependency injection appropriately
   - Apply {changeDetection} change detection strategy

2. **Styling**
   - Convert Tailwind classes to {styleFormat}
   - Use BEM methodology for class naming
   - Utilize CSS custom properties for theming
   - Ensure responsive design (mobile-first)

3. **Type Safety**
   - Define all types and interfaces
   - Use strict TypeScript
   - No 'any' types unless absolutely necessary

4. **Accessibility**
   - Ensure {accessibilityLevel} compliance
   - Add proper ARIA labels and roles
   - Implement keyboard navigation
   - Maintain focus management

5. **Performance**
   - Lazy load where appropriate
   - Use trackBy for ngFor loops
   - Implement OnPush change detection
   - Avoid unnecessary subscriptions

## Output Format

Return ONLY valid JSON:

{
  "component": {
    "name": "component-name",
    "selector": "app-component-name",
    "typescript": "// Complete component.ts",
    "template": "<!-- Complete component.html -->",
    "styles": "/* Complete component.{styleFormat} */"
  },
  "imports": ["required", "angular", "modules"],
  "providers": ["required", "services"],
  "reusedComponents": ["existing", "components", "used"],
  "reasoning": "Brief explanation of key decisions"
}`;

  /**
   * Form component conversion with validation
   */
  static readonly FORM_CONVERSION = `
Convert this Figma form design to an Angular reactive form with validation.

## Input Code
{reactCode}

## Form Requirements

1. **Reactive Forms**
   - Use FormBuilder and FormGroup
   - Implement proper validation (required, email, pattern, custom)
   - Add async validators where needed
   - Handle form state (pristine, dirty, touched, errors)

2. **Error Handling**
   - Display field-level error messages
   - Show validation errors appropriately
   - Implement error summary if multiple fields

3. **Accessibility**
   - Associate labels with inputs
   - Announce errors to screen readers
   - Proper tab order and focus management
   - Use aria-describedby for error messages

4. **User Experience**
   - Show errors on blur or submit
   - Clear error indication (border, color)
   - Disable submit when invalid
   - Loading states for async operations

## Field Validation Rules
{validationRules}

## Output Format

{
  "component": {
    "typescript": "// Component with FormGroup setup",
    "template": "<!-- Template with form bindings -->",
    "styles": "/* Form styles with error states */"
  },
  "validators": ["list", "of", "custom", "validators"],
  "formStructure": {
    "fields": [],
    "validations": {},
    "asyncValidators": {}
  }
}`;

  /**
   * Data table/grid conversion
   */
  static readonly TABLE_CONVERSION = `
Convert this Figma table/list design to an Angular component with data handling.

## Input Code
{reactCode}

## Table Requirements

1. **Data Management**
   - Support sorting (multi-column)
   - Implement filtering (client/server)
   - Add pagination (with page size options)
   - Handle large datasets efficiently

2. **Features**
   - Column resizing
   - Row selection (single/multi)
   - Expandable rows if needed
   - Column visibility toggle
   - Export functionality (CSV/Excel)

3. **Responsive Design**
   - Mobile-friendly layout
   - Horizontal scrolling for wide tables
   - Stack columns on small screens
   - Touch-friendly controls

4. **Performance**
   - Virtual scrolling for large datasets
   - TrackBy functions
   - OnPush change detection
   - Lazy loading of data

## Column Configuration
{columnConfig}

## Output Format

{
  "component": {
    "typescript": "// Component with data source",
    "template": "<!-- Table template -->",
    "styles": "/* Responsive table styles */"
  },
  "dataHandling": {
    "dataSource": "MatTableDataSource or custom",
    "sorting": "implementation details",
    "filtering": "implementation details",
    "pagination": "implementation details"
  }
}`;

  /**
   * Navigation/menu conversion
   */
  static readonly NAVIGATION_CONVERSION = `
Convert this Figma navigation design to an Angular navigation component.

## Input Code
{reactCode}

## Navigation Requirements

1. **Routing Integration**
   - Use Angular Router
   - Active route highlighting
   - Route guards if needed
   - Lazy loading support

2. **Responsive Behavior**
   - Mobile hamburger menu
   - Collapsible sidebar
   - Dropdown submenus
   - Touch gestures

3. **Accessibility**
   - Keyboard navigation (arrow keys)
   - ARIA landmarks and roles
   - Skip navigation link
   - Focus management

4. **User Experience**
   - Smooth transitions
   - Loading indicators
   - Breadcrumbs if applicable
   - Search functionality

## Route Configuration
{routeConfig}

## Output Format

{
  "component": {
    "typescript": "// Navigation component",
    "template": "<!-- Navigation template -->",
    "styles": "/* Responsive nav styles */"
  },
  "routing": {
    "routes": [],
    "guards": [],
    "modules": []
  }
}`;

  /**
   * Card/tile component conversion
   */
  static readonly CARD_CONVERSION = `
Convert this Figma card/tile design to a reusable Angular component.

## Input Code
{reactCode}

## Card Requirements

1. **Content Flexibility**
   - Support multiple content types
   - Optional sections (header, footer)
   - Content projection slots
   - Dynamic rendering

2. **Interactions**
   - Hover effects
   - Click handlers
   - Expand/collapse if applicable
   - Drag and drop support

3. **Styling Variants**
   - Multiple themes/colors
   - Different sizes
   - Elevation/shadow options
   - Border styles

## Configuration
{cardConfig}

## Output Format

{
  "component": {
    "typescript": "// Card component with inputs",
    "template": "<!-- Card template with ng-content -->",
    "styles": "/* Card styles with variants */"
  },
  "inputs": ["list", "of", "@Input", "properties"],
  "outputs": ["list", "of", "@Output", "events"],
  "variants": ["available", "style", "variants"]
}`;

  /**
   * Modal/dialog conversion
   */
  static readonly MODAL_CONVERSION = `
Convert this Figma modal/dialog design to an Angular dialog component.

## Input Code
{reactCode}

## Dialog Requirements

1. **Dialog Management**
   - Use Angular Material Dialog or custom
   - Pass data to dialog
   - Return results from dialog
   - Handle backdrop clicks

2. **Accessibility**
   - Focus trap
   - Escape key to close
   - Return focus on close
   - Screen reader announcements

3. **Animations**
   - Open/close transitions
   - Backdrop fade
   - Content animations

## Dialog Configuration
{dialogConfig}

## Output Format

{
  "component": {
    "typescript": "// Dialog component",
    "template": "<!-- Dialog template -->",
    "styles": "/* Dialog styles */"
  },
  "service": "// Dialog service if needed",
  "configuration": {
    "width": "",
    "height": "",
    "position": "",
    "animations": []
  }
}`;

  /**
   * Chart/visualization conversion
   */
  static readonly CHART_CONVERSION = `
Convert this Figma chart/graph design to an Angular component using a charting library.

## Input Code
{reactCode}

## Chart Requirements

1. **Data Visualization**
   - Use Chart.js, D3.js, or ng2-charts
   - Support dynamic data updates
   - Interactive tooltips
   - Legend configuration

2. **Responsiveness**
   - Resize with container
   - Mobile-optimized views
   - Touch interactions

3. **Customization**
   - Theme support
   - Color schemes
   - Animation options

## Chart Configuration
{chartConfig}

## Output Format

{
  "component": {
    "typescript": "// Chart component",
    "template": "<!-- Chart container -->",
    "styles": "/* Chart styles */"
  },
  "chartLibrary": "library name",
  "configuration": {
    "type": "chart type",
    "options": {},
    "data": {}
  }
}`;

  /**
   * Layout/container conversion
   */
  static readonly LAYOUT_CONVERSION = `
Convert this Figma layout to an Angular layout component.

## Input Code
{reactCode}

## Layout Requirements

1. **Grid System**
   - Use CSS Grid or Flexbox
   - Responsive breakpoints
   - Container queries if needed

2. **Content Areas**
   - Header, footer, sidebar
   - Content projection slots
   - Scrollable regions

3. **Responsive Behavior**
   - Mobile-first approach
   - Breakpoint-specific layouts
   - Fluid typography

## Layout Configuration
{layoutConfig}

## Output Format

{
  "component": {
    "typescript": "// Layout component",
    "template": "<!-- Layout template with slots -->",
    "styles": "/* Responsive layout styles */"
  },
  "slots": ["available", "content", "projection", "slots"],
  "breakpoints": {
    "mobile": "",
    "tablet": "",
    "desktop": ""
  }
}`;

  /**
   * Animation-heavy component conversion
   */
  static readonly ANIMATED_CONVERSION = `
Convert this Figma design to an Angular component with animations.

## Input Code
{reactCode}

## Animation Requirements

1. **Angular Animations API**
   - Define animation triggers
   - State transitions
   - Animation sequences
   - Stagger animations

2. **Performance**
   - Use CSS transforms
   - GPU acceleration
   - Avoid layout thrashing
   - RequestAnimationFrame

3. **Interactions**
   - Hover animations
   - Click animations
   - Scroll-triggered animations
   - Gesture animations

## Animation Configuration
{animationConfig}

## Output Format

{
  "component": {
    "typescript": "// Component with animations",
    "template": "<!-- Template with animation triggers -->",
    "styles": "/* Styles supporting animations */",
    "animations": "// Animation definitions"
  },
  "triggers": ["animation", "trigger", "names"],
  "states": ["animation", "states"]
}`;

  /**
   * Get prompt by component type
   */
  static getPromptByType(componentType: string): string {
    const prompts: { [key: string]: string } = {
      'form': this.FORM_CONVERSION,
      'table': this.TABLE_CONVERSION,
      'navigation': this.NAVIGATION_CONVERSION,
      'card': this.CARD_CONVERSION,
      'modal': this.MODAL_CONVERSION,
      'chart': this.CHART_CONVERSION,
      'layout': this.LAYOUT_CONVERSION,
      'animated': this.ANIMATED_CONVERSION,
      'default': this.COMPONENT_CONVERSION
    };

    return prompts[componentType] || prompts['default'];
  }

  /**
   * Build prompt with context
   */
  static buildPrompt(template: string, context: any): string {
    let prompt = template;

    // Replace placeholders with actual values
    Object.keys(context).forEach(key => {
      const placeholder = `{${key}}`;
      const value = typeof context[key] === 'object'
        ? JSON.stringify(context[key], null, 2)
        : context[key];
      prompt = prompt.replace(new RegExp(placeholder, 'g'), value);
    });

    return prompt;
  }

  /**
   * Component type detection prompt
   */
  static readonly DETECT_COMPONENT_TYPE = `
Analyze this React component and determine what type of Angular component it should become.

## React Component Code
{code}

## Available Component Types
- form: Forms with validation
- table: Data tables or grids
- navigation: Navigation menus or breadcrumbs
- card: Card or tile components
- modal: Modals or dialogs
- chart: Charts or data visualizations
- layout: Layout containers
- animated: Animation-heavy components
- default: Standard components

## Analysis Criteria
1. Look for form elements (input, select, textarea)
2. Check for data iteration (tables, lists)
3. Identify navigation patterns (links, menus)
4. Detect modal/dialog patterns
5. Find chart/visualization libraries
6. Identify animation libraries or complex transitions

## Output Format
{
  "type": "detected component type",
  "confidence": 0.95,
  "reasoning": "Why this type was chosen",
  "features": ["detected", "features"],
  "suggestions": ["optimization", "suggestions"]
}`;
}

/**
 * Prompt optimization utilities
 */
export class PromptOptimizer {
  /**
   * Optimize prompt for token usage
   */
  static optimize(prompt: string): string {
    // Remove excessive whitespace
    prompt = prompt.replace(/\s+/g, ' ').trim();

    // Remove unnecessary comments in code blocks
    prompt = prompt.replace(/\/\/\s*TODO:.*$/gm, '');
    prompt = prompt.replace(/\/\*[\s\S]*?\*\//g, '');

    // Compress JSON formatting
    prompt = prompt.replace(/(\{|\[)\s+/g, '$1');
    prompt = prompt.replace(/\s+(\}|\])/g, '$1');
    prompt = prompt.replace(/,\s+/g, ',');

    return prompt;
  }

  /**
   * Add examples to prompt for better results
   */
  static addExamples(prompt: string, examples: any[]): string {
    if (examples.length === 0) return prompt;

    const exampleSection = `
## Examples

${examples.map((ex, i) => `
### Example ${i + 1}
Input: ${ex.input}
Output: ${ex.output}
`).join('\n')}
`;

    return prompt + exampleSection;
  }

  /**
   * Add constraints to prompt
   */
  static addConstraints(prompt: string, constraints: string[]): string {
    if (constraints.length === 0) return prompt;

    const constraintSection = `
## Additional Constraints

${constraints.map(c => `- ${c}`).join('\n')}
`;

    return prompt + constraintSection;
  }
}