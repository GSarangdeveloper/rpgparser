import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface CostEntry {
  id: string;
  timestamp: Date;
  provider: 'openai' | 'anthropic' | 'azure';
  model: string;
  operation: string;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  cost: number;
  duration: number;
  success: boolean;
  error?: string;
}

export interface CostSummary {
  total: number;
  byProvider: { [key: string]: number };
  byModel: { [key: string]: number };
  byOperation: { [key: string]: number };
  byDate: { [key: string]: number };
  averageCost: number;
  averageTokens: number;
  successRate: number;
  totalRequests: number;
}

export interface CostLimit {
  daily: number;
  weekly: number;
  monthly: number;
  perOperation: number;
}

export interface CostAlert {
  id: string;
  type: 'warning' | 'error';
  message: string;
  threshold: number;
  current: number;
  timestamp: Date;
}

@Injectable({
  providedIn: 'root'
})
export class CostTrackerService {
  private costHistory: CostEntry[] = [];
  private costAlerts = new BehaviorSubject<CostAlert[]>([]);
  private currentCost = new BehaviorSubject<number>(0);
  private costLimits: CostLimit = {
    daily: 10.00,
    weekly: 50.00,
    monthly: 150.00,
    perOperation: 1.00
  };

  // Pricing tables per 1K tokens
  private pricing = {
    openai: {
      'gpt-4-vision-preview': { input: 0.01, output: 0.03 },
      'gpt-4-turbo-preview': { input: 0.01, output: 0.03 },
      'gpt-4-turbo': { input: 0.01, output: 0.03 },
      'gpt-4': { input: 0.03, output: 0.06 },
      'gpt-3.5-turbo': { input: 0.0005, output: 0.0015 },
      'gpt-3.5-turbo-16k': { input: 0.003, output: 0.004 }
    },
    anthropic: {
      'claude-3-opus': { input: 0.015, output: 0.075 },
      'claude-3-sonnet': { input: 0.003, output: 0.015 },
      'claude-3-haiku': { input: 0.00025, output: 0.00125 },
      'claude-2.1': { input: 0.008, output: 0.024 },
      'claude-2': { input: 0.008, output: 0.024 }
    },
    azure: {
      'gpt-4': { input: 0.03, output: 0.06 },
      'gpt-4-32k': { input: 0.06, output: 0.12 },
      'gpt-35-turbo': { input: 0.0005, output: 0.0015 },
      'gpt-35-turbo-16k': { input: 0.003, output: 0.004 }
    }
  };

  constructor() {
    this.loadHistory();
    this.loadLimits();
  }

  /**
   * Track a new cost entry
   */
  trackCost(entry: Omit<CostEntry, 'id' | 'timestamp'>): void {
    const fullEntry: CostEntry = {
      ...entry,
      id: this.generateId(),
      timestamp: new Date()
    };

    this.costHistory.push(fullEntry);
    this.updateCurrentCost();
    this.checkLimits(fullEntry);
    this.saveHistory();
  }

  /**
   * Calculate cost for token usage
   */
  calculateCost(
    provider: string,
    model: string,
    promptTokens: number,
    completionTokens: number
  ): number {
    const modelPricing = this.pricing[provider]?.[model];

    if (!modelPricing) {
      console.warn(`No pricing found for ${provider}/${model}, using default`);
      return (promptTokens * 0.01 + completionTokens * 0.03) / 1000;
    }

    const inputCost = (promptTokens / 1000) * modelPricing.input;
    const outputCost = (completionTokens / 1000) * modelPricing.output;

    return inputCost + outputCost;
  }

  /**
   * Get cost summary
   */
  getCostSummary(startDate?: Date, endDate?: Date): CostSummary {
    const filtered = this.filterByDateRange(startDate, endDate);

    const summary: CostSummary = {
      total: 0,
      byProvider: {},
      byModel: {},
      byOperation: {},
      byDate: {},
      averageCost: 0,
      averageTokens: 0,
      successRate: 0,
      totalRequests: filtered.length
    };

    let totalTokens = 0;
    let successCount = 0;

    for (const entry of filtered) {
      // Total cost
      summary.total += entry.cost;

      // By provider
      summary.byProvider[entry.provider] = (summary.byProvider[entry.provider] || 0) + entry.cost;

      // By model
      summary.byModel[entry.model] = (summary.byModel[entry.model] || 0) + entry.cost;

      // By operation
      summary.byOperation[entry.operation] = (summary.byOperation[entry.operation] || 0) + entry.cost;

      // By date
      const dateKey = entry.timestamp.toISOString().split('T')[0];
      summary.byDate[dateKey] = (summary.byDate[dateKey] || 0) + entry.cost;

      // Totals for averages
      totalTokens += entry.totalTokens;
      if (entry.success) successCount++;
    }

    // Calculate averages
    if (filtered.length > 0) {
      summary.averageCost = summary.total / filtered.length;
      summary.averageTokens = totalTokens / filtered.length;
      summary.successRate = (successCount / filtered.length) * 100;
    }

    return summary;
  }

  /**
   * Get cost by time period
   */
  getCostByPeriod(period: 'hour' | 'day' | 'week' | 'month'): { [key: string]: number } {
    const costs: { [key: string]: number } = {};
    const now = new Date();

    for (const entry of this.costHistory) {
      const key = this.getTimeKey(entry.timestamp, period);
      costs[key] = (costs[key] || 0) + entry.cost;
    }

    return costs;
  }

  /**
   * Get top spending operations
   */
  getTopOperations(limit = 10): { operation: string; cost: number; count: number }[] {
    const operations: { [key: string]: { cost: number; count: number } } = {};

    for (const entry of this.costHistory) {
      if (!operations[entry.operation]) {
        operations[entry.operation] = { cost: 0, count: 0 };
      }
      operations[entry.operation].cost += entry.cost;
      operations[entry.operation].count++;
    }

    return Object.entries(operations)
      .map(([operation, data]) => ({ operation, ...data }))
      .sort((a, b) => b.cost - a.cost)
      .slice(0, limit);
  }

  /**
   * Get cost trends
   */
  getCostTrends(days = 30): {
    daily: number[];
    cumulative: number[];
    dates: string[];
    trend: 'increasing' | 'decreasing' | 'stable';
  } {
    const daily: number[] = [];
    const cumulative: number[] = [];
    const dates: string[] = [];

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - days);

    let cumulativeTotal = 0;

    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      const dateStr = d.toISOString().split('T')[0];
      const dayCost = this.getCostForDate(new Date(dateStr));

      daily.push(dayCost);
      cumulativeTotal += dayCost;
      cumulative.push(cumulativeTotal);
      dates.push(dateStr);
    }

    // Calculate trend
    const firstWeekAvg = daily.slice(0, 7).reduce((a, b) => a + b, 0) / 7;
    const lastWeekAvg = daily.slice(-7).reduce((a, b) => a + b, 0) / 7;
    const change = ((lastWeekAvg - firstWeekAvg) / firstWeekAvg) * 100;

    let trend: 'increasing' | 'decreasing' | 'stable';
    if (change > 10) trend = 'increasing';
    else if (change < -10) trend = 'decreasing';
    else trend = 'stable';

    return { daily, cumulative, dates, trend };
  }

  /**
   * Set cost limits
   */
  setCostLimits(limits: Partial<CostLimit>): void {
    this.costLimits = { ...this.costLimits, ...limits };
    this.saveLimits();
    this.checkAllLimits();
  }

  /**
   * Get cost limits
   */
  getCostLimits(): CostLimit {
    return { ...this.costLimits };
  }

  /**
   * Get current alerts
   */
  getAlerts(): Observable<CostAlert[]> {
    return this.costAlerts.asObservable();
  }

  /**
   * Get current total cost
   */
  getCurrentCost(): Observable<number> {
    return this.currentCost.asObservable();
  }

  /**
   * Export cost data
   */
  exportCostData(format: 'json' | 'csv' = 'json'): string {
    if (format === 'json') {
      return JSON.stringify(this.costHistory, null, 2);
    }

    // CSV export
    const headers = ['Date', 'Provider', 'Model', 'Operation', 'Prompt Tokens', 'Completion Tokens', 'Total Tokens', 'Cost', 'Duration', 'Success'];
    const rows = this.costHistory.map(entry => [
      entry.timestamp.toISOString(),
      entry.provider,
      entry.model,
      entry.operation,
      entry.promptTokens,
      entry.completionTokens,
      entry.totalTokens,
      entry.cost.toFixed(4),
      entry.duration,
      entry.success
    ]);

    return [headers, ...rows].map(row => row.join(',')).join('\n');
  }

  /**
   * Clear cost history
   */
  clearHistory(before?: Date): void {
    if (before) {
      this.costHistory = this.costHistory.filter(entry => entry.timestamp > before);
    } else {
      this.costHistory = [];
    }
    this.updateCurrentCost();
    this.saveHistory();
  }

  /**
   * Get optimization suggestions
   */
  getOptimizationSuggestions(): string[] {
    const suggestions: string[] = [];
    const summary = this.getCostSummary();

    // Check average cost per operation
    if (summary.averageCost > 0.5) {
      suggestions.push('Consider using a cheaper model for simple transformations');
    }

    // Check model usage
    const modelCosts = Object.entries(summary.byModel);
    const expensiveModels = modelCosts.filter(([model, cost]) => model.includes('gpt-4') || model.includes('opus'));
    if (expensiveModels.length > 0) {
      const expensiveCost = expensiveModels.reduce((sum, [, cost]) => sum + cost, 0);
      if (expensiveCost > summary.total * 0.7) {
        suggestions.push('70% of costs from expensive models - consider using cheaper alternatives for some tasks');
      }
    }

    // Check token usage
    if (summary.averageTokens > 4000) {
      suggestions.push('High average token usage - consider optimizing prompts or breaking into smaller tasks');
    }

    // Check failure rate
    if (summary.successRate < 90) {
      suggestions.push('High failure rate increasing costs - investigate and fix common errors');
    }

    // Check for repeated operations
    const topOps = this.getTopOperations(5);
    if (topOps.length > 0 && topOps[0].count > 10) {
      suggestions.push(`"${topOps[0].operation}" repeated ${topOps[0].count} times - consider caching results`);
    }

    return suggestions;
  }

  // Private helper methods

  private filterByDateRange(startDate?: Date, endDate?: Date): CostEntry[] {
    if (!startDate && !endDate) return this.costHistory;

    return this.costHistory.filter(entry => {
      if (startDate && entry.timestamp < startDate) return false;
      if (endDate && entry.timestamp > endDate) return false;
      return true;
    });
  }

  private getCostForDate(date: Date): number {
    const dateStr = date.toISOString().split('T')[0];
    return this.costHistory
      .filter(entry => entry.timestamp.toISOString().startsWith(dateStr))
      .reduce((sum, entry) => sum + entry.cost, 0);
  }

  private getTimeKey(date: Date, period: 'hour' | 'day' | 'week' | 'month'): string {
    const d = new Date(date);
    switch (period) {
      case 'hour':
        return `${d.toISOString().slice(0, 13)}:00`;
      case 'day':
        return d.toISOString().split('T')[0];
      case 'week':
        const weekStart = new Date(d);
        weekStart.setDate(d.getDate() - d.getDay());
        return weekStart.toISOString().split('T')[0];
      case 'month':
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    }
  }

  private updateCurrentCost(): void {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayCost = this.getCostForDate(today);
    this.currentCost.next(todayCost);
  }

  private checkLimits(entry: CostEntry): void {
    const alerts: CostAlert[] = [];

    // Check per-operation limit
    if (entry.cost > this.costLimits.perOperation) {
      alerts.push({
        id: this.generateId(),
        type: 'error',
        message: `Operation cost ($${entry.cost.toFixed(2)}) exceeded limit ($${this.costLimits.perOperation})`,
        threshold: this.costLimits.perOperation,
        current: entry.cost,
        timestamp: new Date()
      });
    }

    // Check daily limit
    const todayCost = this.getCostForDate(new Date());
    if (todayCost > this.costLimits.daily * 0.8) {
      alerts.push({
        id: this.generateId(),
        type: todayCost > this.costLimits.daily ? 'error' : 'warning',
        message: `Daily cost ($${todayCost.toFixed(2)}) ${todayCost > this.costLimits.daily ? 'exceeded' : 'approaching'} limit ($${this.costLimits.daily})`,
        threshold: this.costLimits.daily,
        current: todayCost,
        timestamp: new Date()
      });
    }

    if (alerts.length > 0) {
      this.costAlerts.next(alerts);
    }
  }

  private checkAllLimits(): void {
    this.checkLimits(this.costHistory[this.costHistory.length - 1]);
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private loadHistory(): void {
    const saved = localStorage.getItem('llm-cost-history');
    if (saved) {
      try {
        this.costHistory = JSON.parse(saved).map((entry: any) => ({
          ...entry,
          timestamp: new Date(entry.timestamp)
        }));
      } catch (error) {
        console.error('Failed to load cost history:', error);
      }
    }
  }

  private saveHistory(): void {
    localStorage.setItem('llm-cost-history', JSON.stringify(this.costHistory));
  }

  private loadLimits(): void {
    const saved = localStorage.getItem('llm-cost-limits');
    if (saved) {
      try {
        this.costLimits = JSON.parse(saved);
      } catch (error) {
        console.error('Failed to load cost limits:', error);
      }
    }
  }

  private saveLimits(): void {
    localStorage.setItem('llm-cost-limits', JSON.stringify(this.costLimits));
  }
}