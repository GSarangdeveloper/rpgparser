import { Injectable } from '@angular/core';
import { Observable, from, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface LLMConfig {
  provider: 'openai' | 'anthropic' | 'azure';
  model: string;
  apiKey: string;
  endpoint?: string;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
}

export interface LLMPrompt {
  system?: string;
  user: string;
  images?: Buffer[];
  temperature?: number;
  maxTokens?: number;
}

export interface LLMResponse {
  content: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    cost: number;
  };
  model: string;
  provider: string;
}

export interface TransformContext {
  reactCode: string;
  screenshot?: Buffer;
  designTokens?: any;
  existingComponents?: ComponentInfo[];
  projectRules?: ProjectRules;
  designSystem?: DesignSystemConfig;
}

export interface ComponentInfo {
  name: string;
  selector: string;
  description: string;
  inputs: string[];
  outputs: string[];
  filePath: string;
}

export interface ProjectRules {
  namingConvention: 'kebab-case' | 'camelCase' | 'PascalCase';
  styleFormat: 'scss' | 'css' | 'less';
  changeDetection: 'OnPush' | 'Default';
  strictMode: boolean;
  accessibility: 'WCAG-A' | 'WCAG-AA' | 'WCAG-AAA';
  customRules?: string[];
}

export interface DesignSystemConfig {
  tokens: DesignToken[];
  spacing: SpacingSystem;
  typography: TypographySystem;
  colors: ColorPalette;
}

export interface DesignToken {
  name: string;
  value: string;
  category: 'color' | 'spacing' | 'typography' | 'shadow' | 'border' | 'other';
  cssVariable?: string;
}

export interface SpacingSystem {
  base: number;
  scale: number[];
}

export interface TypographySystem {
  fonts: { [key: string]: string };
  sizes: { [key: string]: string };
  weights: { [key: string]: number };
  lineHeights: { [key: string]: number };
}

export interface ColorPalette {
  primary: { [key: string]: string };
  secondary: { [key: string]: string };
  neutral: { [key: string]: string };
  semantic: { [key: string]: string };
}

export interface GeneratedComponent {
  name: string;
  selector: string;
  typescript: string;
  template: string;
  styles: string;
  module?: string;
  spec?: string;
  reusedComponents: string[];
  newComponents: string[];
  tokensMapped: { [key: string]: string };
  reasoning: string;
}

@Injectable({
  providedIn: 'root'
})
export class LLMService {
  private config: LLMConfig;
  private totalCost = 0;
  private requestCount = 0;

  constructor() {
    this.config = this.loadConfig();
  }

  private loadConfig(): LLMConfig {
    return {
      provider: (environment.llm?.provider || 'openai') as 'openai' | 'anthropic' | 'azure',
      model: environment.llm?.model || 'gpt-4-vision-preview',
      apiKey: environment.llm?.apiKey || '',
      endpoint: (environment.llm as any)?.endpoint,
      temperature: environment.llm?.temperature || 0.3,
      maxTokens: environment.llm?.maxTokens || 8000
    };
  }

  /**
   * Main transformation method using LLM
   */
  async transformToAngular(context: TransformContext): Promise<GeneratedComponent> {
    const prompt = this.buildTransformationPrompt(context);

    const response = await this.complete({
      system: this.getSystemPrompt(),
      user: prompt,
      images: context.screenshot ? [context.screenshot] : undefined,
      temperature: this.config.temperature,
      maxTokens: this.config.maxTokens
    });

    try {
      const result = this.parseGeneratedCode(response.content);
      this.trackUsage(response.usage);
      return result;
    } catch (error) {
      throw new Error(`Failed to parse LLM response: ${error}`);
    }
  }

  /**
   * Complete a prompt with optional vision support
   */
  async complete(prompt: LLMPrompt): Promise<LLMResponse> {
    switch (this.config.provider) {
      case 'openai':
        return this.completeOpenAI(prompt);
      case 'anthropic':
        return this.completeAnthropic(prompt);
      case 'azure':
        return this.completeAzure(prompt);
      default:
        throw new Error(`Unsupported LLM provider: ${this.config.provider}`);
    }
  }

  /**
   * OpenAI completion
   */
  private async completeOpenAI(prompt: LLMPrompt): Promise<LLMResponse> {
    const headers = {
      'Authorization': `Bearer ${this.config.apiKey}`,
      'Content-Type': 'application/json'
    };

    const messages = [];

    if (prompt.system) {
      messages.push({ role: 'system', content: prompt.system });
    }

    const userContent: any[] = [{ type: 'text', text: prompt.user }];

    if (prompt.images && prompt.images.length > 0) {
      for (const image of prompt.images) {
        userContent.push({
          type: 'image_url',
          image_url: {
            url: `data:image/png;base64,${image.toString('base64')}`
          }
        });
      }
    }

    messages.push({ role: 'user', content: userContent });

    const body = {
      model: this.config.model,
      messages,
      temperature: prompt.temperature || this.config.temperature,
      max_tokens: prompt.maxTokens || this.config.maxTokens,
      top_p: this.config.topP || 1
    };

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      content: data.choices[0].message.content,
      usage: {
        promptTokens: data.usage.prompt_tokens,
        completionTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens,
        cost: this.calculateCost(data.usage, 'openai')
      },
      model: this.config.model,
      provider: 'openai'
    };
  }

  /**
   * Anthropic completion
   */
  private async completeAnthropic(prompt: LLMPrompt): Promise<LLMResponse> {
    const headers = {
      'x-api-key': this.config.apiKey,
      'anthropic-version': '2023-06-01',
      'Content-Type': 'application/json'
    };

    const messages = [];
    const userContent: any[] = [{ type: 'text', text: prompt.user }];

    if (prompt.images && prompt.images.length > 0) {
      for (const image of prompt.images) {
        userContent.push({
          type: 'image',
          source: {
            type: 'base64',
            media_type: 'image/png',
            data: image.toString('base64')
          }
        });
      }
    }

    messages.push({ role: 'user', content: userContent });

    const body = {
      model: this.config.model,
      system: prompt.system,
      messages,
      max_tokens: prompt.maxTokens || this.config.maxTokens,
      temperature: prompt.temperature || this.config.temperature
    };

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      throw new Error(`Anthropic API error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      content: data.content[0].text,
      usage: {
        promptTokens: data.usage.input_tokens,
        completionTokens: data.usage.output_tokens,
        totalTokens: data.usage.input_tokens + data.usage.output_tokens,
        cost: this.calculateCost(data.usage, 'anthropic')
      },
      model: this.config.model,
      provider: 'anthropic'
    };
  }

  /**
   * Azure OpenAI completion
   */
  private async completeAzure(prompt: LLMPrompt): Promise<LLMResponse> {
    const endpoint = this.config.endpoint || `https://${environment.azure?.resourceName}.openai.azure.com`;
    const apiVersion = '2024-02-15-preview';

    const headers = {
      'api-key': this.config.apiKey,
      'Content-Type': 'application/json'
    };

    const messages = [];

    if (prompt.system) {
      messages.push({ role: 'system', content: prompt.system });
    }

    const userContent: any[] = [{ type: 'text', text: prompt.user }];

    if (prompt.images && prompt.images.length > 0) {
      for (const image of prompt.images) {
        userContent.push({
          type: 'image_url',
          image_url: {
            url: `data:image/png;base64,${image.toString('base64')}`
          }
        });
      }
    }

    messages.push({ role: 'user', content: userContent });

    const body = {
      messages,
      temperature: prompt.temperature || this.config.temperature,
      max_tokens: prompt.maxTokens || this.config.maxTokens,
      top_p: this.config.topP || 1
    };

    const url = `${endpoint}/openai/deployments/${this.config.model}/chat/completions?api-version=${apiVersion}`;

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      throw new Error(`Azure OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      content: data.choices[0].message.content,
      usage: {
        promptTokens: data.usage.prompt_tokens,
        completionTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens,
        cost: this.calculateCost(data.usage, 'azure')
      },
      model: this.config.model,
      provider: 'azure'
    };
  }

  /**
   * Build the transformation prompt
   */
  private buildTransformationPrompt(context: TransformContext): string {
    return `
Convert this Figma design to Angular components following best practices.

## Input: Figma Design (React + Tailwind)

\`\`\`tsx
${context.reactCode}
\`\`\`

${context.designTokens ? `
## Design Tokens from Figma

\`\`\`json
${JSON.stringify(context.designTokens, null, 2)}
\`\`\`
` : ''}

${context.existingComponents && context.existingComponents.length > 0 ? `
## Existing Components (MUST REUSE WHEN APPLICABLE)

${context.existingComponents.map(c => `
### ${c.name}
- Selector: ${c.selector}
- Description: ${c.description}
- Inputs: ${c.inputs.join(', ') || 'none'}
- Outputs: ${c.outputs.join(', ') || 'none'}
`).join('\n')}
` : ''}

${context.designSystem ? `
## Project Design System

### Color Tokens
${Object.entries(context.designSystem.colors.primary).map(([key, value]) => `- --color-primary-${key}: ${value}`).join('\n')}
${Object.entries(context.designSystem.colors.secondary).map(([key, value]) => `- --color-secondary-${key}: ${value}`).join('\n')}

### Spacing Tokens
${context.designSystem.spacing.scale.map((value, index) => `- --spacing-${index}: ${value * context.designSystem.spacing.base}px`).join('\n')}

### Typography
${Object.entries(context.designSystem.typography.sizes).map(([key, value]) => `- --font-size-${key}: ${value}`).join('\n')}
` : ''}

${context.projectRules ? `
## Project Rules

- Naming Convention: ${context.projectRules.namingConvention}
- Style Format: ${context.projectRules.styleFormat}
- Change Detection: ${context.projectRules.changeDetection}
- Strict Mode: ${context.projectRules.strictMode}
- Accessibility: ${context.projectRules.accessibility}
${context.projectRules.customRules ? context.projectRules.customRules.join('\n') : ''}
` : ''}

## Requirements

1. **Component Reuse**: Check existing components first. If one matches the needs, use it instead of creating new.
2. **Design Tokens**: Never hardcode colors, spacing, or typography. Always use CSS variables from the design system.
3. **Accessibility**: Ensure ${context.projectRules?.accessibility || 'WCAG-AA'} compliance with proper ARIA labels, keyboard navigation, and focus management.
4. **Angular Best Practices**:
   - Use ${context.projectRules?.changeDetection || 'OnPush'} change detection
   - Implement proper lifecycle hooks
   - Use strong typing with TypeScript
   - Follow Angular style guide
5. **Styling**: Convert Tailwind classes to ${context.projectRules?.styleFormat || 'scss'} using BEM methodology
6. **Responsive Design**: Ensure the component is mobile-first and responsive
7. **Performance**: Optimize for performance with lazy loading where appropriate

## Output Format

Return ONLY valid JSON without any markdown formatting or explanation:

{
  "name": "component-name",
  "selector": "app-component-name",
  "typescript": "// Complete TypeScript component code",
  "template": "<!-- Complete HTML template -->",
  "styles": "/* Complete ${context.projectRules?.styleFormat || 'scss'} styles */",
  "module": "// Module code if needed",
  "spec": "// Unit test code",
  "reusedComponents": ["list", "of", "reused", "component", "names"],
  "newComponents": ["list", "of", "new", "sub", "components"],
  "tokensMapped": {
    "figmaColorName": "css-variable-name",
    "figmaSpacing": "spacing-token"
  },
  "reasoning": "Brief explanation of transformation approach and key decisions"
}`;
  }

  /**
   * Get system prompt for the LLM
   */
  private getSystemPrompt(): string {
    return `You are an expert Angular developer specialized in converting Figma designs to production-ready Angular components.

Your expertise includes:
- Angular framework (latest version) with TypeScript
- Component architecture and best practices
- RxJS and reactive programming
- CSS/SCSS and responsive design
- Accessibility standards (WCAG)
- Performance optimization
- Design systems and component libraries

You always:
1. Write clean, maintainable, and well-documented code
2. Follow Angular style guide and conventions
3. Ensure accessibility compliance
4. Optimize for performance
5. Use semantic HTML
6. Implement proper error handling
7. Write testable code

You never:
1. Hardcode values that should be tokens
2. Skip accessibility features
3. Use deprecated APIs
4. Ignore responsive design
5. Write overly complex solutions`;
  }

  /**
   * Parse the generated code from LLM response
   */
  private parseGeneratedCode(response: string): GeneratedComponent {
    try {
      // Remove any markdown code blocks if present
      const cleanResponse = response
        .replace(/```json\n?/g, '')
        .replace(/```\n?/g, '')
        .trim();

      const parsed = JSON.parse(cleanResponse);

      // Validate required fields
      const required = ['name', 'selector', 'typescript', 'template', 'styles'];
      for (const field of required) {
        if (!parsed[field]) {
          throw new Error(`Missing required field: ${field}`);
        }
      }

      // Set defaults for optional fields
      return {
        name: parsed.name,
        selector: parsed.selector,
        typescript: parsed.typescript,
        template: parsed.template,
        styles: parsed.styles,
        module: parsed.module || '',
        spec: parsed.spec || '',
        reusedComponents: parsed.reusedComponents || [],
        newComponents: parsed.newComponents || [],
        tokensMapped: parsed.tokensMapped || {},
        reasoning: parsed.reasoning || ''
      };
    } catch (error) {
      console.error('Failed to parse LLM response:', response);
      throw error;
    }
  }

  /**
   * Calculate cost based on token usage
   */
  private calculateCost(usage: any, provider: string): number {
    const pricing: { [key: string]: { [model: string]: { prompt: number; completion: number } } } = {
      openai: {
        'gpt-4-vision-preview': { prompt: 0.01, completion: 0.03 },
        'gpt-4-turbo-preview': { prompt: 0.01, completion: 0.03 },
        'gpt-4': { prompt: 0.03, completion: 0.06 },
        'gpt-3.5-turbo': { prompt: 0.0005, completion: 0.0015 }
      },
      anthropic: {
        'claude-3-opus': { prompt: 0.015, completion: 0.075 },
        'claude-3-sonnet': { prompt: 0.003, completion: 0.015 },
        'claude-3-haiku': { prompt: 0.00025, completion: 0.00125 }
      },
      azure: {
        'gpt-4': { prompt: 0.03, completion: 0.06 },
        'gpt-35-turbo': { prompt: 0.0005, completion: 0.0015 }
      }
    };

    const model = this.config.model.toLowerCase();
    let rate = { prompt: 0.01, completion: 0.03 }; // Default rates

    // Find matching pricing
    for (const [modelKey, modelPricing] of Object.entries(pricing[provider] || {})) {
      if (model.includes(modelKey)) {
        rate = modelPricing;
        break;
      }
    }

    const promptCost = (usage.promptTokens || usage.prompt_tokens || usage.input_tokens || 0) / 1000 * rate.prompt;
    const completionCost = (usage.completionTokens || usage.completion_tokens || usage.output_tokens || 0) / 1000 * rate.completion;

    return promptCost + completionCost;
  }

  /**
   * Track usage and costs
   */
  private trackUsage(usage: any): void {
    this.totalCost += usage.cost;
    this.requestCount++;

    console.log(`LLM Usage - Requests: ${this.requestCount}, Total Cost: $${this.totalCost.toFixed(4)}`);
  }

  /**
   * Get usage statistics
   */
  getUsageStats(): { requests: number; totalCost: number; averageCost: number } {
    return {
      requests: this.requestCount,
      totalCost: this.totalCost,
      averageCost: this.requestCount > 0 ? this.totalCost / this.requestCount : 0
    };
  }

  /**
   * Validate generated component
   */
  async validateComponent(component: GeneratedComponent): Promise<{ valid: boolean; errors: string[] }> {
    const errors: string[] = [];

    // Check TypeScript syntax
    if (!this.isValidTypeScript(component.typescript)) {
      errors.push('Invalid TypeScript syntax');
    }

    // Check HTML template
    if (!this.isValidTemplate(component.template)) {
      errors.push('Invalid HTML template');
    }

    // Check styles
    if (!this.isValidStyles(component.styles)) {
      errors.push('Invalid styles syntax');
    }

    // Check selector naming
    if (!component.selector.startsWith('app-')) {
      errors.push('Selector should start with "app-"');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  private isValidTypeScript(code: string): boolean {
    // Basic validation - check for required Angular decorators
    return code.includes('@Component') &&
           code.includes('export class') &&
           code.includes('implements OnInit');
  }

  private isValidTemplate(template: string): boolean {
    // Basic HTML validation
    const openTags = (template.match(/<[^/][^>]*>/g) || []).length;
    const closeTags = (template.match(/<\/[^>]*>/g) || []).length;
    return Math.abs(openTags - closeTags) <= 2; // Allow some flexibility for self-closing tags
  }

  private isValidStyles(styles: string): boolean {
    // Basic CSS/SCSS validation
    const openBraces = (styles.match(/{/g) || []).length;
    const closeBraces = (styles.match(/}/g) || []).length;
    return openBraces === closeBraces;
  }
}