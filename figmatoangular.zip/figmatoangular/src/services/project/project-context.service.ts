import { Injectable } from '@angular/core';
import { Observable, from, forkJoin, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import * as fs from 'fs-extra';
import * as path from 'path';
import { glob } from 'glob';
import { ComponentInfo, ProjectRules, DesignSystemConfig, DesignToken } from '../llm/llm.service';

export interface ProjectContext {
  projectPath: string;
  angularVersion: string;
  existingComponents: ComponentInfo[];
  projectRules: ProjectRules;
  designSystem: DesignSystemConfig;
  dependencies: string[];
  isStandalone: boolean;
  hasAngularMaterial: boolean;
}

export interface ComponentMetadata {
  name: string;
  selector: string;
  standalone: boolean;
  imports: string[];
  providers: string[];
  styleUrls: string[];
  templateUrl: string;
  changeDetection?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ProjectContextService {
  private contextCache = new Map<string, ProjectContext>();

  /**
   * Scan an Angular project and build complete context
   */
  async scanProject(projectPath: string): Promise<ProjectContext> {
    // Check cache
    if (this.contextCache.has(projectPath)) {
      return this.contextCache.get(projectPath)!;
    }

    console.log(`Scanning project at ${projectPath}...`);

    // Verify Angular project
    const angularJsonPath = path.join(projectPath, 'angular.json');
    if (!await fs.pathExists(angularJsonPath)) {
      throw new Error(`Not an Angular project: ${projectPath}`);
    }

    // Load project configuration
    const angularJson = await fs.readJson(angularJsonPath);
    const packageJson = await fs.readJson(path.join(projectPath, 'package.json'));
    const tsConfig = await fs.readJson(path.join(projectPath, 'tsconfig.json'));

    // Build context
    const context: ProjectContext = {
      projectPath,
      angularVersion: this.getAngularVersion(packageJson),
      existingComponents: await this.getExistingComponents(projectPath),
      projectRules: await this.getProjectRules(angularJson, tsConfig),
      designSystem: await this.getDesignSystem(projectPath),
      dependencies: Object.keys(packageJson.dependencies || {}),
      isStandalone: this.checkIfStandalone(angularJson),
      hasAngularMaterial: this.hasAngularMaterial(packageJson)
    };

    // Cache result
    this.contextCache.set(projectPath, context);

    console.log(`Found ${context.existingComponents.length} components, ${context.designSystem.tokens.length} design tokens`);

    return context;
  }

  /**
   * Get all existing Angular components in the project
   */
  async getExistingComponents(projectPath?: string): Promise<ComponentInfo[]> {
    const basePath = projectPath || process.cwd();
    const srcPath = path.join(basePath, 'src');

    // Find all component files
    const componentFiles = await this.findFiles(srcPath, '**/*.component.ts');
    const components: ComponentInfo[] = [];

    for (const file of componentFiles) {
      try {
        const content = await fs.readFile(file, 'utf8');
        const metadata = this.parseComponentFile(content, file);

        if (metadata) {
          components.push({
            name: metadata.name,
            selector: metadata.selector,
            description: this.extractDescription(content),
            inputs: this.extractInputs(content),
            outputs: this.extractOutputs(content),
            filePath: file
          });
        }
      } catch (error) {
        console.warn(`Failed to parse component ${file}:`, error);
      }
    }

    return components;
  }

  /**
   * Get project rules from configuration
   */
  async getProjectRules(angularJson?: any, tsConfig?: any): Promise<ProjectRules> {
    // Load configs if not provided
    if (!angularJson) {
      const angularJsonPath = path.join(process.cwd(), 'angular.json');
      angularJson = await fs.readJson(angularJsonPath).catch(() => ({}));
    }

    if (!tsConfig) {
      const tsConfigPath = path.join(process.cwd(), 'tsconfig.json');
      tsConfig = await fs.readJson(tsConfigPath).catch(() => ({}));
    }

    // Extract project settings
    const projectName = Object.keys(angularJson.projects || {})[0];
    const projectConfig = angularJson.projects?.[projectName] || {};

    // Determine style format
    let styleFormat: 'scss' | 'css' | 'less' = 'css';
    const styleExt = projectConfig.schematics?.['@schematics/angular:component']?.style;
    if (styleExt) {
      styleFormat = styleExt as any;
    } else {
      // Check existing files
      const hasScss = await fs.pathExists(path.join(process.cwd(), 'src/styles.scss'));
      const hasLess = await fs.pathExists(path.join(process.cwd(), 'src/styles.less'));
      if (hasScss) styleFormat = 'scss';
      else if (hasLess) styleFormat = 'less';
    }

    // Check for custom rules file
    const customRulesPath = path.join(process.cwd(), '.figma-to-angular/rules.json');
    let customRules: string[] = [];
    if (await fs.pathExists(customRulesPath)) {
      const rulesContent = await fs.readJson(customRulesPath);
      customRules = rulesContent.rules || [];
    }

    return {
      namingConvention: 'kebab-case',
      styleFormat,
      changeDetection: projectConfig.schematics?.['@schematics/angular:component']?.changeDetection || 'Default',
      strictMode: tsConfig.compilerOptions?.strict === true,
      accessibility: 'WCAG-AA',
      customRules
    };
  }

  /**
   * Get design system configuration
   */
  async getDesignSystem(projectPath?: string): Promise<DesignSystemConfig> {
    const basePath = projectPath || process.cwd();
    const tokens: DesignToken[] = [];

    // Look for design token files
    const tokenPaths = [
      path.join(basePath, 'src/styles/_variables.scss'),
      path.join(basePath, 'src/styles/design-tokens.scss'),
      path.join(basePath, 'src/theme.scss'),
      path.join(basePath, 'src/styles.scss')
    ];

    for (const tokenPath of tokenPaths) {
      if (await fs.pathExists(tokenPath)) {
        const content = await fs.readFile(tokenPath, 'utf8');
        tokens.push(...this.extractDesignTokens(content));
      }
    }

    // Extract system configuration
    const spacing = this.extractSpacingSystem(tokens);
    const typography = this.extractTypographySystem(tokens);
    const colors = this.extractColorPalette(tokens);

    return {
      tokens,
      spacing,
      typography,
      colors
    };
  }

  /**
   * Parse component file to extract metadata
   */
  private parseComponentFile(content: string, filePath: string): ComponentMetadata | null {
    // Extract component decorator
    const decoratorMatch = content.match(/@Component\s*\(\s*{([^}]+)}\s*\)/s);
    if (!decoratorMatch) return null;

    const decoratorContent = decoratorMatch[1];

    // Extract selector
    const selectorMatch = decoratorContent.match(/selector\s*:\s*['"`]([^'"`]+)['"`]/);
    if (!selectorMatch) return null;

    // Extract class name
    const classMatch = content.match(/export\s+class\s+(\w+)/);
    if (!classMatch) return null;

    // Check if standalone
    const isStandalone = decoratorContent.includes('standalone: true');

    // Extract imports
    const importsMatch = decoratorContent.match(/imports\s*:\s*\[([^\]]+)\]/);
    const imports = importsMatch ? this.parseArrayContent(importsMatch[1]) : [];

    // Extract providers
    const providersMatch = decoratorContent.match(/providers\s*:\s*\[([^\]]+)\]/);
    const providers = providersMatch ? this.parseArrayContent(providersMatch[1]) : [];

    // Extract style URLs
    const styleUrlsMatch = decoratorContent.match(/styleUrls?\s*:\s*\[([^\]]+)\]/);
    const styleUrls = styleUrlsMatch ? this.parseArrayContent(styleUrlsMatch[1]) : [];

    // Extract template URL
    const templateUrlMatch = decoratorContent.match(/templateUrl\s*:\s*['"`]([^'"`]+)['"`]/);

    // Extract change detection
    const changeDetectionMatch = decoratorContent.match(/changeDetection\s*:\s*ChangeDetectionStrategy\.(\w+)/);

    return {
      name: classMatch[1],
      selector: selectorMatch[1],
      standalone: isStandalone,
      imports,
      providers,
      styleUrls,
      templateUrl: templateUrlMatch?.[1] || '',
      changeDetection: changeDetectionMatch?.[1]
    };
  }

  /**
   * Extract component description from JSDoc
   */
  private extractDescription(content: string): string {
    const jsdocMatch = content.match(/\/\*\*([\s\S]*?)\*\/[\s\S]*?export\s+class/);
    if (jsdocMatch) {
      return jsdocMatch[1]
        .split('\n')
        .map(line => line.replace(/^\s*\*\s?/, ''))
        .filter(line => line.trim())
        .join(' ')
        .trim();
    }
    return '';
  }

  /**
   * Extract @Input properties
   */
  private extractInputs(content: string): string[] {
    const inputs: string[] = [];

    // Match @Input() decorators
    const inputMatches = content.matchAll(/@Input\(\s*['"`]?(\w+)?['"`]?\s*\)\s+(\w+)/g);
    for (const match of inputMatches) {
      inputs.push(match[2] || match[1]);
    }

    // Match inputs array in decorator
    const decoratorMatch = content.match(/inputs\s*:\s*\[([^\]]+)\]/);
    if (decoratorMatch) {
      inputs.push(...this.parseArrayContent(decoratorMatch[1]));
    }

    return [...new Set(inputs)];
  }

  /**
   * Extract @Output properties
   */
  private extractOutputs(content: string): string[] {
    const outputs: string[] = [];

    // Match @Output() decorators
    const outputMatches = content.matchAll(/@Output\(\s*['"`]?(\w+)?['"`]?\s*\)\s+(\w+)/g);
    for (const match of outputMatches) {
      outputs.push(match[2] || match[1]);
    }

    // Match outputs array in decorator
    const decoratorMatch = content.match(/outputs\s*:\s*\[([^\]]+)\]/);
    if (decoratorMatch) {
      outputs.push(...this.parseArrayContent(decoratorMatch[1]));
    }

    return [...new Set(outputs)];
  }

  /**
   * Extract design tokens from CSS/SCSS content
   */
  private extractDesignTokens(content: string): DesignToken[] {
    const tokens: DesignToken[] = [];

    // CSS custom properties
    const cssVarMatches = content.matchAll(/--([^:]+):\s*([^;]+);/g);
    for (const match of cssVarMatches) {
      const name = match[1].trim();
      const value = match[2].trim();
      tokens.push({
        name,
        value,
        category: this.categorizeToken(name),
        cssVariable: `--${name}`
      });
    }

    // SCSS variables
    const scssVarMatches = content.matchAll(/\$([^:]+):\s*([^;]+);/g);
    for (const match of scssVarMatches) {
      const name = match[1].trim();
      const value = match[2].trim();
      tokens.push({
        name,
        value,
        category: this.categorizeToken(name),
        cssVariable: `$${name}`
      });
    }

    return tokens;
  }

  /**
   * Categorize a design token based on its name
   */
  private categorizeToken(name: string): 'color' | 'spacing' | 'typography' | 'shadow' | 'border' | 'other' {
    const lowerName = name.toLowerCase();

    if (lowerName.includes('color') || lowerName.includes('bg') || lowerName.includes('text')) {
      return 'color';
    }
    if (lowerName.includes('space') || lowerName.includes('gap') || lowerName.includes('margin') || lowerName.includes('padding')) {
      return 'spacing';
    }
    if (lowerName.includes('font') || lowerName.includes('text-size') || lowerName.includes('line-height')) {
      return 'typography';
    }
    if (lowerName.includes('shadow') || lowerName.includes('elevation')) {
      return 'shadow';
    }
    if (lowerName.includes('border') || lowerName.includes('radius')) {
      return 'border';
    }

    return 'other';
  }

  /**
   * Extract spacing system from tokens
   */
  private extractSpacingSystem(tokens: DesignToken[]): any {
    const spacingTokens = tokens.filter(t => t.category === 'spacing');

    // Try to find base spacing
    const baseToken = spacingTokens.find(t => t.name.includes('base') || t.name === 'spacing-unit');
    const base = baseToken ? parseInt(baseToken.value) : 4;

    // Extract scale
    const scale: number[] = [];
    for (const token of spacingTokens) {
      const value = parseInt(token.value);
      if (!isNaN(value)) {
        scale.push(value / base);
      }
    }

    return {
      base,
      scale: [...new Set(scale)].sort((a, b) => a - b)
    };
  }

  /**
   * Extract typography system from tokens
   */
  private extractTypographySystem(tokens: DesignToken[]): any {
    const typographyTokens = tokens.filter(t => t.category === 'typography');

    const fonts: { [key: string]: string } = {};
    const sizes: { [key: string]: string } = {};
    const weights: { [key: string]: number } = {};
    const lineHeights: { [key: string]: number } = {};

    for (const token of typographyTokens) {
      const name = token.name;
      const value = token.value;

      if (name.includes('font-family')) {
        const key = name.replace('font-family-', '');
        fonts[key] = value;
      } else if (name.includes('font-size')) {
        const key = name.replace('font-size-', '');
        sizes[key] = value;
      } else if (name.includes('font-weight')) {
        const key = name.replace('font-weight-', '');
        weights[key] = parseInt(value) || 400;
      } else if (name.includes('line-height')) {
        const key = name.replace('line-height-', '');
        lineHeights[key] = parseFloat(value) || 1.5;
      }
    }

    return { fonts, sizes, weights, lineHeights };
  }

  /**
   * Extract color palette from tokens
   */
  private extractColorPalette(tokens: DesignToken[]): any {
    const colorTokens = tokens.filter(t => t.category === 'color');

    const primary: { [key: string]: string } = {};
    const secondary: { [key: string]: string } = {};
    const neutral: { [key: string]: string } = {};
    const semantic: { [key: string]: string } = {};

    for (const token of colorTokens) {
      const name = token.name;
      const value = token.value;

      if (name.includes('primary')) {
        const key = name.replace(/color-primary-?/, '').replace(/-/g, '');
        primary[key || 'main'] = value;
      } else if (name.includes('secondary') || name.includes('accent')) {
        const key = name.replace(/color-(secondary|accent)-?/, '').replace(/-/g, '');
        secondary[key || 'main'] = value;
      } else if (name.includes('gray') || name.includes('grey') || name.includes('neutral')) {
        const key = name.replace(/color-(gray|grey|neutral)-?/, '').replace(/-/g, '');
        neutral[key || 'main'] = value;
      } else if (name.includes('success') || name.includes('error') || name.includes('warning') || name.includes('info')) {
        semantic[name.replace('color-', '')] = value;
      }
    }

    return { primary, secondary, neutral, semantic };
  }

  /**
   * Get Angular version from package.json
   */
  private getAngularVersion(packageJson: any): string {
    const angularCore = packageJson.dependencies?.['@angular/core'] ||
                       packageJson.devDependencies?.['@angular/core'] ||
                       '0.0.0';

    // Clean version string (remove ^, ~, etc.)
    return angularCore.replace(/[^0-9.]/g, '');
  }

  /**
   * Check if project uses standalone components
   */
  private checkIfStandalone(angularJson: any): boolean {
    const projectName = Object.keys(angularJson.projects || {})[0];
    const schematicsConfig = angularJson.projects?.[projectName]?.schematics?.['@schematics/angular:component'];
    return schematicsConfig?.standalone === true;
  }

  /**
   * Check if project has Angular Material
   */
  private hasAngularMaterial(packageJson: any): boolean {
    return !!(packageJson.dependencies?.['@angular/material'] ||
             packageJson.devDependencies?.['@angular/material']);
  }

  /**
   * Find files matching a glob pattern
   */
  private async findFiles(basePath: string, pattern: string): Promise<string[]> {
    // Using glob with promise-based API
    const files = await glob(pattern, { cwd: basePath, absolute: true });
    return files as string[];
  }

  /**
   * Parse array content from decorator
   */
  private parseArrayContent(content: string): string[] {
    return content
      .split(',')
      .map(item => item.trim())
      .map(item => item.replace(/['"`]/g, ''))
      .filter(item => item && !item.startsWith('//'));
  }

  /**
   * Clear context cache
   */
  clearCache(): void {
    this.contextCache.clear();
  }

  /**
   * Get cached context if available
   */
  getCachedContext(projectPath: string): ProjectContext | undefined {
    return this.contextCache.get(projectPath);
  }
}