import { Injectable } from '@angular/core';
import { Observable, from, of, forkJoin } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { GeneratedComponent } from '../llm/llm.service';

export interface ValidationResult {
  passed: boolean;
  score: number;
  issues: ValidationIssue[];
  suggestions: string[];
}

export interface ValidationIssue {
  severity: 'error' | 'warning' | 'info';
  type: string;
  message: string;
  line?: number;
  column?: number;
  file?: string;
  fix?: string;
}

export interface VisualValidationResult {
  passed: boolean;
  similarity: number;
  differences: string[];
  screenshot?: Buffer;
}

export interface AccessibilityValidationResult {
  passed: boolean;
  violations: AccessibilityViolation[];
  level: string;
}

export interface AccessibilityViolation {
  rule: string;
  severity: 'error' | 'warning' | 'info';
  element: string;
  message: string;
  fix?: string;
}

export interface CompilationValidationResult {
  passed: boolean;
  errors: string[];
  warnings: string[];
  output?: string;
}

export interface QualityMetrics {
  codeComplexity: number;
  maintainability: number;
  testCoverage: number;
  performance: number;
  accessibility: number;
  bestPractices: number;
}

@Injectable({
  providedIn: 'root'
})
export class LLMValidationService {

  /**
   * Validate generated component
   */
  validateComponent(component: GeneratedComponent): Observable<ValidationResult> {
    return forkJoin({
      syntax: this.validateSyntax(component),
      structure: this.validateStructure(component),
      styling: this.validateStyling(component),
      accessibility: this.validateAccessibility(component),
      performance: this.validatePerformance(component),
      bestPractices: this.validateBestPractices(component)
    }).pipe(
      map(results => this.combineValidationResults(results))
    );
  }

  /**
   * Validate TypeScript syntax
   */
  private validateSyntax(component: GeneratedComponent): Observable<ValidationResult> {
    const issues: ValidationIssue[] = [];

    // Check for required Angular imports
    if (!component.typescript.includes('@angular/core')) {
      issues.push({
        severity: 'error',
        type: 'missing-import',
        message: 'Missing @angular/core import',
        fix: "import { Component, OnInit } from '@angular/core';"
      });
    }

    // Check for Component decorator
    if (!component.typescript.includes('@Component')) {
      issues.push({
        severity: 'error',
        type: 'missing-decorator',
        message: 'Missing @Component decorator'
      });
    }

    // Check selector format
    if (!component.selector.match(/^[a-z]+(-[a-z]+)*$/)) {
      issues.push({
        severity: 'warning',
        type: 'naming-convention',
        message: 'Selector should be in kebab-case',
        fix: component.selector.toLowerCase().replace(/([A-Z])/g, '-$1').replace(/^-/, '')
      });
    }

    // Check class naming
    const classMatch = component.typescript.match(/export\s+class\s+(\w+)/);
    if (classMatch) {
      const className = classMatch[1];
      if (!className.endsWith('Component')) {
        issues.push({
          severity: 'warning',
          type: 'naming-convention',
          message: 'Component class should end with "Component"',
          fix: className + 'Component'
        });
      }
    }

    // Check for proper lifecycle hook implementation
    if (component.typescript.includes('ngOnInit') && !component.typescript.includes('implements OnInit')) {
      issues.push({
        severity: 'warning',
        type: 'interface-implementation',
        message: 'Component uses ngOnInit but does not implement OnInit interface',
        fix: 'export class ComponentName implements OnInit'
      });
    }

    return of({
      passed: issues.filter(i => i.severity === 'error').length === 0,
      score: Math.max(0, 100 - (issues.filter(i => i.severity === 'error').length * 20) - (issues.filter(i => i.severity === 'warning').length * 5)),
      issues,
      suggestions: this.generateSyntaxSuggestions(component)
    });
  }

  /**
   * Validate component structure
   */
  private validateStructure(component: GeneratedComponent): Observable<ValidationResult> {
    const issues: ValidationIssue[] = [];

    // Check template structure
    if (!component.template || component.template.trim().length === 0) {
      issues.push({
        severity: 'error',
        type: 'empty-template',
        message: 'Component template is empty'
      });
    }

    // Check for balanced tags
    const openTags = (component.template.match(/<[^/][^>]*>/g) || []).length;
    const closeTags = (component.template.match(/<\/[^>]*>/g) || []).length;
    if (Math.abs(openTags - closeTags) > 2) { // Allow some flexibility for self-closing tags
      issues.push({
        severity: 'error',
        type: 'unbalanced-tags',
        message: 'Template has unbalanced HTML tags'
      });
    }

    // Check for Angular directives usage
    const hasStructuralDirectives = component.template.includes('*ngIf') ||
                                   component.template.includes('*ngFor') ||
                                   component.template.includes('*ngSwitch');

    // Check for proper data binding
    const hasInterpolation = component.template.includes('{{') && component.template.includes('}}');
    const hasPropertyBinding = component.template.includes('[') && component.template.includes(']');
    const hasEventBinding = component.template.includes('(') && component.template.includes(')');

    // Check styles structure
    if (component.styles) {
      const openBraces = (component.styles.match(/{/g) || []).length;
      const closeBraces = (component.styles.match(/}/g) || []).length;
      if (openBraces !== closeBraces) {
        issues.push({
          severity: 'error',
          type: 'unbalanced-braces',
          message: 'Styles have unbalanced braces'
        });
      }
    }

    return of({
      passed: issues.filter(i => i.severity === 'error').length === 0,
      score: Math.max(0, 100 - (issues.filter(i => i.severity === 'error').length * 20) - (issues.filter(i => i.severity === 'warning').length * 5)),
      issues,
      suggestions: this.generateStructureSuggestions(component)
    });
  }

  /**
   * Validate styling
   */
  private validateStyling(component: GeneratedComponent): Observable<ValidationResult> {
    const issues: ValidationIssue[] = [];

    // Check for hardcoded values
    const hardcodedColors = component.styles.match(/#[0-9a-fA-F]{3,6}|rgb\([^)]+\)/g);
    if (hardcodedColors && hardcodedColors.length > 0) {
      issues.push({
        severity: 'warning',
        type: 'hardcoded-colors',
        message: `Found ${hardcodedColors.length} hardcoded color values - consider using CSS variables`,
        fix: 'Use CSS custom properties: var(--color-primary)'
      });
    }

    const hardcodedSizes = component.styles.match(/\d+px/g);
    if (hardcodedSizes && hardcodedSizes.length > 5) {
      issues.push({
        severity: 'warning',
        type: 'hardcoded-sizes',
        message: `Many hardcoded pixel values - consider using relative units or variables`,
        fix: 'Use rem, em, or CSS variables for consistency'
      });
    }

    // Check for BEM naming
    const classNames = component.template.match(/class="([^"]+)"/g) || [];
    const nonBemClasses = classNames.filter(cls => {
      const name = cls.replace(/class="|"/g, '');
      return !name.match(/^[a-z]+(-[a-z]+)*(__|--)[a-z]+(-[a-z]+)*$/);
    });

    if (nonBemClasses.length > 0 && classNames.length > 0) {
      const percentage = (nonBemClasses.length / classNames.length) * 100;
      if (percentage > 50) {
        issues.push({
          severity: 'info',
          type: 'naming-convention',
          message: 'Consider using BEM naming convention for CSS classes'
        });
      }
    }

    // Check for responsive design
    const hasMediaQueries = component.styles.includes('@media');
    if (!hasMediaQueries && component.styles.length > 100) {
      issues.push({
        severity: 'warning',
        type: 'responsive-design',
        message: 'No media queries found - consider adding responsive styles'
      });
    }

    // Check for CSS custom properties usage
    const usesCustomProperties = component.styles.includes('var(--');
    if (!usesCustomProperties && component.styles.length > 50) {
      issues.push({
        severity: 'info',
        type: 'theming',
        message: 'Consider using CSS custom properties for theming support'
      });
    }

    return of({
      passed: issues.filter(i => i.severity === 'error').length === 0,
      score: Math.max(0, 100 - (issues.filter(i => i.severity === 'error').length * 20) - (issues.filter(i => i.severity === 'warning').length * 5)),
      issues,
      suggestions: this.generateStylingSuggestions(component)
    });
  }

  /**
   * Validate accessibility
   */
  validateAccessibility(component: GeneratedComponent): Observable<AccessibilityValidationResult> {
    const violations: AccessibilityViolation[] = [];

    // Check for alt text on images
    const images = component.template.match(/<img[^>]*>/g) || [];
    images.forEach(img => {
      if (!img.includes('alt=')) {
        violations.push({
          rule: 'img-alt',
          severity: 'error',
          element: img,
          message: 'Image missing alt attribute',
          fix: 'Add alt="" for decorative images or descriptive text for content images'
        });
      }
    });

    // Check for form labels
    const inputs = component.template.match(/<input[^>]*>/g) || [];
    inputs.forEach(input => {
      const id = input.match(/id="([^"]+)"/);
      if (id) {
        const hasLabel = component.template.includes(`for="${id[1]}"`);
        const hasAriaLabel = input.includes('aria-label') || input.includes('aria-labelledby');
        if (!hasLabel && !hasAriaLabel) {
          violations.push({
            rule: 'label-for-input',
            severity: 'error',
            element: input,
            message: 'Input field missing associated label',
            fix: `Add <label for="${id[1]}">Label Text</label> or aria-label attribute`
          });
        }
      }
    });

    // Check for button text
    const buttons = component.template.match(/<button[^>]*>([^<]*)<\/button>/g) || [];
    buttons.forEach(button => {
      const buttonText = button.match(/>([^<]*)</);
      if (!buttonText || !buttonText[1].trim()) {
        const hasAriaLabel = button.includes('aria-label');
        if (!hasAriaLabel) {
          violations.push({
            rule: 'button-text',
            severity: 'error',
            element: button,
            message: 'Button missing text content or aria-label',
            fix: 'Add button text or aria-label attribute'
          });
        }
      }
    });

    // Check for heading hierarchy
    const headings = component.template.match(/<h[1-6][^>]*>/g) || [];
    let lastLevel = 0;
    headings.forEach(heading => {
      const level = parseInt(heading.match(/<h([1-6])/)?.[1] || '1');
      if (level - lastLevel > 1) {
        violations.push({
          rule: 'heading-hierarchy',
          severity: 'warning',
          element: heading,
          message: `Heading level skipped (h${lastLevel} to h${level})`,
          fix: 'Maintain proper heading hierarchy'
        });
      }
      lastLevel = level;
    });

    // Check for ARIA attributes
    const hasAriaAttributes = component.template.includes('aria-') || component.template.includes('role=');

    // Check for keyboard navigation
    const interactiveElements = component.template.match(/<(button|a|input|select|textarea)[^>]*>/g) || [];
    interactiveElements.forEach(element => {
      if (element.includes('click') && !element.includes('keydown') && !element.includes('keyup') && !element.includes('keypress')) {
        violations.push({
          rule: 'keyboard-navigation',
          severity: 'warning',
          element: element,
          message: 'Interactive element may not be keyboard accessible',
          fix: 'Consider adding keyboard event handlers'
        });
      }
    });

    return of({
      passed: violations.filter(v => v.severity === 'error').length === 0,
      violations,
      level: 'WCAG-AA'
    });
  }

  /**
   * Validate performance
   */
  private validatePerformance(component: GeneratedComponent): Observable<ValidationResult> {
    const issues: ValidationIssue[] = [];

    // Check for OnPush change detection
    if (!component.typescript.includes('ChangeDetectionStrategy.OnPush')) {
      issues.push({
        severity: 'info',
        type: 'change-detection',
        message: 'Consider using OnPush change detection strategy for better performance',
        fix: "changeDetection: ChangeDetectionStrategy.OnPush"
      });
    }

    // Check for trackBy in *ngFor
    const ngForLoops = component.template.match(/\*ngFor="[^"]+"/g) || [];
    ngForLoops.forEach(loop => {
      if (!loop.includes('trackBy')) {
        issues.push({
          severity: 'warning',
          type: 'trackby-missing',
          message: 'ngFor loop missing trackBy function',
          fix: 'Add trackBy function to improve list rendering performance'
        });
      }
    });

    // Check for async pipe usage
    const hasObservables = component.typescript.includes('Observable') || component.typescript.includes('Subject');
    const hasAsyncPipe = component.template.includes('| async');
    if (hasObservables && !hasAsyncPipe) {
      issues.push({
        severity: 'info',
        type: 'async-pipe',
        message: 'Consider using async pipe for automatic subscription management'
      });
    }

    // Check for large bundle indicators
    const componentSize = component.typescript.length + component.template.length + component.styles.length;
    if (componentSize > 50000) {
      issues.push({
        severity: 'warning',
        type: 'component-size',
        message: 'Component is very large - consider splitting into smaller components'
      });
    }

    return of({
      passed: issues.filter(i => i.severity === 'error').length === 0,
      score: Math.max(0, 100 - (issues.filter(i => i.severity === 'error').length * 20) - (issues.filter(i => i.severity === 'warning').length * 5)),
      issues,
      suggestions: this.generatePerformanceSuggestions(component)
    });
  }

  /**
   * Validate best practices
   */
  private validateBestPractices(component: GeneratedComponent): Observable<ValidationResult> {
    const issues: ValidationIssue[] = [];

    // Check for 'any' type usage
    const anyTypeCount = (component.typescript.match(/:\s*any/g) || []).length;
    if (anyTypeCount > 0) {
      issues.push({
        severity: 'warning',
        type: 'type-safety',
        message: `Found ${anyTypeCount} uses of 'any' type - use specific types instead`,
        fix: 'Replace any with specific types or interfaces'
      });
    }

    // Check for console.log statements
    if (component.typescript.includes('console.log')) {
      issues.push({
        severity: 'warning',
        type: 'console-log',
        message: 'Remove console.log statements from production code'
      });
    }

    // Check for proper error handling
    const hasTryCatch = component.typescript.includes('try') && component.typescript.includes('catch');
    const hasErrorHandling = component.typescript.includes('.catch') || component.typescript.includes('catchError');
    if (!hasTryCatch && !hasErrorHandling && component.typescript.includes('subscribe')) {
      issues.push({
        severity: 'warning',
        type: 'error-handling',
        message: 'Add error handling for async operations'
      });
    }

    // Check for unsubscribe pattern
    if (component.typescript.includes('subscribe') && !component.typescript.includes('unsubscribe') && !component.typescript.includes('| async')) {
      issues.push({
        severity: 'warning',
        type: 'memory-leak',
        message: 'Ensure subscriptions are properly unsubscribed',
        fix: 'Implement ngOnDestroy and unsubscribe from all subscriptions'
      });
    }

    // Check for proper input validation
    if (component.typescript.includes('@Input()')) {
      const hasInputValidation = component.typescript.includes('ngOnChanges') ||
                                component.typescript.includes('set ') ||
                                component.typescript.includes('get ');
      if (!hasInputValidation) {
        issues.push({
          severity: 'info',
          type: 'input-validation',
          message: 'Consider adding input validation for @Input properties'
        });
      }
    }

    return of({
      passed: issues.filter(i => i.severity === 'error').length === 0,
      score: Math.max(0, 100 - (issues.filter(i => i.severity === 'error').length * 20) - (issues.filter(i => i.severity === 'warning').length * 5)),
      issues,
      suggestions: this.generateBestPracticesSuggestions(component)
    });
  }

  /**
   * Calculate quality metrics
   */
  calculateQuality(component: GeneratedComponent): Observable<{ score: number; metrics: QualityMetrics }> {
    return forkJoin({
      syntax: this.validateSyntax(component),
      structure: this.validateStructure(component),
      styling: this.validateStyling(component),
      accessibility: this.validateAccessibility(component),
      performance: this.validatePerformance(component),
      bestPractices: this.validateBestPractices(component)
    }).pipe(
      map(results => {
        const metrics: QualityMetrics = {
          codeComplexity: this.calculateComplexity(component),
          maintainability: (results.syntax.score + results.structure.score) / 2,
          testCoverage: 0, // Would need actual test coverage data
          performance: results.performance.score,
          accessibility: results.accessibility.passed ? 100 : 50,
          bestPractices: results.bestPractices.score
        };

        const score = Object.values(metrics).reduce((sum, val) => sum + val, 0) / Object.keys(metrics).length;

        return { score, metrics };
      })
    );
  }

  /**
   * Visual validation against screenshot
   */
  validateVisual(component: GeneratedComponent, screenshot?: Buffer): Observable<VisualValidationResult> {
    // This would need actual visual comparison implementation
    // For now, return mock result
    return of({
      passed: true,
      similarity: 95,
      differences: [],
      screenshot
    });
  }

  /**
   * Compilation validation
   */
  validateCompilation(component: GeneratedComponent): Observable<CompilationValidationResult> {
    // This would need actual TypeScript compilation
    // For now, do basic syntax checks
    const errors: string[] = [];
    const warnings: string[] = [];

    // Check for basic syntax errors
    const braceCount = (component.typescript.match(/{/g) || []).length -
                       (component.typescript.match(/}/g) || []).length;
    if (braceCount !== 0) {
      errors.push('Unbalanced braces in TypeScript code');
    }

    const parenCount = (component.typescript.match(/\(/g) || []).length -
                       (component.typescript.match(/\)/g) || []).length;
    if (parenCount !== 0) {
      errors.push('Unbalanced parentheses in TypeScript code');
    }

    return of({
      passed: errors.length === 0,
      errors,
      warnings
    });
  }

  // Helper methods

  private combineValidationResults(results: any): ValidationResult {
    const allIssues: ValidationIssue[] = [];
    let totalScore = 0;
    let count = 0;

    Object.values(results).forEach((result: any) => {
      if (result.issues) {
        allIssues.push(...result.issues);
      }
      if (result.score !== undefined) {
        totalScore += result.score;
        count++;
      }
    });

    return {
      passed: allIssues.filter(i => i.severity === 'error').length === 0,
      score: count > 0 ? totalScore / count : 0,
      issues: allIssues,
      suggestions: this.generateOverallSuggestions(allIssues)
    };
  }

  private calculateComplexity(component: GeneratedComponent): number {
    // Simple cyclomatic complexity estimation
    const conditionals = (component.typescript.match(/if\s*\(|switch\s*\(|\?\s*:|&&|\|\|/g) || []).length;
    const loops = (component.typescript.match(/for\s*\(|while\s*\(|do\s*{/g) || []).length;
    const functions = (component.typescript.match(/function\s+\w+|=>\s*{|\w+\s*\([^)]*\)\s*{/g) || []).length;

    const complexity = 1 + conditionals + loops + functions;

    // Convert to score (lower complexity = higher score)
    if (complexity <= 5) return 100;
    if (complexity <= 10) return 80;
    if (complexity <= 20) return 60;
    if (complexity <= 30) return 40;
    return 20;
  }

  private generateSyntaxSuggestions(component: GeneratedComponent): string[] {
    const suggestions: string[] = [];

    if (!component.typescript.includes('strict')) {
      suggestions.push('Enable strict TypeScript mode for better type safety');
    }

    if (!component.typescript.includes('readonly')) {
      suggestions.push('Consider using readonly for properties that should not be modified');
    }

    return suggestions;
  }

  private generateStructureSuggestions(component: GeneratedComponent): string[] {
    const suggestions: string[] = [];

    if (component.template.length > 500) {
      suggestions.push('Consider breaking down large templates into smaller components');
    }

    if (!component.template.includes('<ng-content')) {
      suggestions.push('Consider using content projection for more flexible components');
    }

    return suggestions;
  }

  private generateStylingSuggestions(component: GeneratedComponent): string[] {
    const suggestions: string[] = [];

    if (!component.styles.includes(':host')) {
      suggestions.push('Use :host selector for component-level styling');
    }

    if (component.styles.includes('!important')) {
      suggestions.push('Avoid using !important - use more specific selectors instead');
    }

    return suggestions;
  }

  private generatePerformanceSuggestions(component: GeneratedComponent): string[] {
    const suggestions: string[] = [];

    if (component.typescript.includes('setInterval') || component.typescript.includes('setTimeout')) {
      suggestions.push('Clear timers in ngOnDestroy to prevent memory leaks');
    }

    if (component.template.includes('*ngFor') && component.template.includes('*ngIf')) {
      suggestions.push('Avoid using *ngFor and *ngIf on the same element - use ng-container');
    }

    return suggestions;
  }

  private generateBestPracticesSuggestions(component: GeneratedComponent): string[] {
    const suggestions: string[] = [];

    if (!component.typescript.includes('private') && !component.typescript.includes('protected')) {
      suggestions.push('Use proper access modifiers (private, protected, public) for class members');
    }

    if (!component.spec) {
      suggestions.push('Add unit tests for the component');
    }

    return suggestions;
  }

  private generateOverallSuggestions(issues: ValidationIssue[]): string[] {
    const suggestions: string[] = [];
    const errorCount = issues.filter(i => i.severity === 'error').length;
    const warningCount = issues.filter(i => i.severity === 'warning').length;

    if (errorCount > 0) {
      suggestions.push(`Fix ${errorCount} critical issues before deployment`);
    }

    if (warningCount > 5) {
      suggestions.push('Consider addressing warnings to improve code quality');
    }

    if (issues.some(i => i.type === 'accessibility')) {
      suggestions.push('Run full accessibility audit with tools like axe-core');
    }

    return suggestions;
  }
}