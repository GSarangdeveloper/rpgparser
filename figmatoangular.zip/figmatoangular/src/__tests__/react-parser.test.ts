/**
 * React Parser Tests
 */

import { ReactParser } from '../transform/react-parser.service';

describe('ReactParser', () => {
  let parser: ReactParser;

  beforeEach(() => {
    parser = new ReactParser();
  });

  describe('parse', () => {
    it('should parse a simple functional component', () => {
      const code = `
        function Button({ label, onClick }) {
          return (
            <button onClick={onClick}>
              {label}
            </button>
          );
        }
      `;

      const result = parser.parse(code);

      expect(result.componentName).toBe('Button');
      expect(result.props).toContain('label');
      expect(result.props).toContain('onClick');
      expect(result.jsx).toContain('<button');
      expect(result.jsx).toContain('{label}');
    });

    it('should parse arrow function component', () => {
      const code = `
        const Card = ({ title, content }) => {
          return (
            <div className="card">
              <h3>{title}</h3>
              <p>{content}</p>
            </div>
          );
        };
      `;

      const result = parser.parse(code);

      expect(result.componentName).toBe('Card');
      expect(result.props).toContain('title');
      expect(result.props).toContain('content');
      expect(result.jsx).toContain('className="card"');
    });

    it('should extract state variables', () => {
      const code = `
        function Counter() {
          const [count, setCount] = useState(0);
          const [name, setName] = useState('test');

          return <div>{count}</div>;
        }
      `;

      const result = parser.parse(code);

      expect(result.state).toHaveLength(2);
      expect(result.state[0]).toEqual({ name: 'count', initialValue: '0' });
      expect(result.state[1]).toEqual({ name: 'name', initialValue: "'test'" });
    });

    it('should extract event handlers', () => {
      const code = `
        function Form() {
          const handleSubmit = (e) => {
            e.preventDefault();
          };

          const handleChange = (e) => {
            console.log(e.target.value);
          };

          return <form onSubmit={handleSubmit}><input onChange={handleChange} /></form>;
        }
      `;

      const result = parser.parse(code);

      expect(result.events).toContain('handleSubmit');
      expect(result.events).toContain('handleChange');
    });

    it('should extract imports', () => {
      const code = `
        import React, { useState, useEffect } from 'react';
        import { Button } from './Button';
        import styles from './styles.module.css';

        function App() {
          return <div>Test</div>;
        }
      `;

      const result = parser.parse(code);

      expect(result.imports).toHaveLength(3);
      expect(result.imports[0].source).toBe('react');
      expect(result.imports[1].source).toBe('./Button');
      expect(result.imports[2].source).toBe('./styles.module.css');
    });
  });
});
