/**
 * Angular Transformer Tests
 */

import { AngularTransformer } from '../transform/angular-transformer';

describe('AngularTransformer', () => {
  let transformer: AngularTransformer;

  beforeEach(() => {
    transformer = new AngularTransformer();
  });

  describe('transformJsx', () => {
    it('should transform className to class', () => {
      const jsx = '<div className="container">Content</div>';
      const result = transformer.transformJsx(jsx);

      expect(result).toContain('class="container"');
      expect(result).not.toContain('className');
    });

    it('should transform dynamic className to ngClass', () => {
      const jsx = '<div className={styles.card}>Content</div>';
      const result = transformer.transformJsx(jsx);

      expect(result).toContain('[ngClass]="styles.card"');
    });

    it('should transform onClick to (click)', () => {
      const jsx = '<button onClick={handleClick}>Click</button>';
      const result = transformer.transformJsx(jsx);

      expect(result).toContain('(click)="handleClick()"');
      expect(result).not.toContain('onClick');
    });

    it('should transform {variable} to {{variable}}', () => {
      const jsx = '<div>{message}</div>';
      const result = transformer.transformJsx(jsx);

      expect(result).toContain('{{message}}');
    });

    it('should transform value + onChange to [(ngModel)]', () => {
      const jsx = '<input value={name} onChange={handleChange} />';
      const result = transformer.transformJsx(jsx);

      expect(result).toContain('[(ngModel)]="name"');
      expect(result).not.toContain('value=');
      expect(result).not.toContain('onChange=');
    });

    it('should transform conditional rendering with *ngIf', () => {
      const jsx = '{isVisible && <div>Content</div>}';
      const result = transformer.transformJsx(jsx);

      expect(result).toContain('*ngIf="isVisible"');
      expect(result).toContain('<div');
    });

    it('should transform map to *ngFor', () => {
      const jsx = '{items.map(item => <li key={item.id}>{item.name}</li>)}';
      const result = transformer.transformJsx(jsx);

      expect(result).toContain('*ngFor="let item of items"');
      expect(result).toContain('{{item.name}}');
    });

    it('should handle style objects', () => {
      const jsx = '<div style={{ color: "red", fontSize: "16px" }}>Text</div>';
      const result = transformer.transformJsx(jsx);

      expect(result).toContain('[ngStyle]');
    });
  });

  describe('transformProps', () => {
    it('should transform props to @Input decorators', () => {
      const props = ['title', 'count', 'isActive'];
      const result = transformer.transformProps(props);

      expect(result.inputs).toHaveLength(3);
      expect(result.inputs).toContain('title');
      expect(result.inputs).toContain('count');
      expect(result.inputs).toContain('isActive');
    });

    it('should identify event handler props as @Output', () => {
      const props = ['title', 'onClick', 'onSubmit', 'onChange'];
      const result = transformer.transformProps(props);

      expect(result.outputs).toHaveLength(3);
      expect(result.outputs).toContain('onClick');
      expect(result.outputs).toContain('onSubmit');
      expect(result.outputs).toContain('onChange');
    });
  });
});
