/**
 * Authentication Service Tests
 */

import { AuthService } from '../auth/auth.service';
import { TokenStorage } from '../auth/token-storage.service';

// Mock TokenStorage
jest.mock('../auth/token-storage.service');

describe('AuthService', () => {
  let authService: AuthService;
  let mockTokenStorage: jest.Mocked<TokenStorage>;

  beforeEach(() => {
    mockTokenStorage = new TokenStorage() as jest.Mocked<TokenStorage>;
    authService = new AuthService(
      'test-client-id',
      'test-client-secret',
      'http://localhost:3000/callback',
      mockTokenStorage
    );
  });

  describe('getAuthorizationUrl', () => {
    it('should generate authorization URL with correct parameters', () => {
      const url = authService.getAuthorizationUrl();

      expect(url).toContain('https://www.figma.com/oauth');
      expect(url).toContain('client_id=test-client-id');
      expect(url).toContain('redirect_uri=http://localhost:3000/callback');
      expect(url).toContain('scope=file_read');
      expect(url).toContain('state=');
      expect(url).toContain('response_type=code');
    });

    it('should include custom scope if provided', () => {
      const url = authService.getAuthorizationUrl('file_read file_write');

      expect(url).toContain('scope=file_read%20file_write');
    });
  });

  describe('getValidAccessToken', () => {
    it('should return existing token if not expired', async () => {
      const futureDate = Date.now() + 3600000; // 1 hour from now
      mockTokenStorage.getTokens.mockResolvedValue({
        accessToken: 'valid-token',
        refreshToken: 'refresh-token',
        expiresAt: futureDate,
      });

      const token = await authService.getValidAccessToken();

      expect(token).toBe('valid-token');
      expect(mockTokenStorage.getTokens).toHaveBeenCalled();
    });

    it('should return token without expiry check if expiresAt is not set', async () => {
      mockTokenStorage.getTokens.mockResolvedValue({
        accessToken: 'valid-token',
        refreshToken: 'refresh-token',
      });

      const token = await authService.getValidAccessToken();

      expect(token).toBe('valid-token');
    });
  });
});
