/**
 * Tailwind Converter Tests
 */

import { TailwindConverter } from '../transform/tailwind-converter';

describe('TailwindConverter', () => {
  let converter: TailwindConverter;

  beforeEach(() => {
    converter = new TailwindConverter();
  });

  describe('convert', () => {
    it('should convert basic spacing utilities', () => {
      const result = converter.convert('p-4 m-2');

      expect(result.baseStyles).toEqual({
        padding: '1rem',
        margin: '0.5rem',
      });
    });

    it('should convert flexbox utilities', () => {
      const result = converter.convert('flex items-center justify-between');

      expect(result.baseStyles).toMatchObject({
        display: 'flex',
        'align-items': 'center',
        'justify-content': 'space-between',
      });
    });

    it('should convert grid utilities', () => {
      const result = converter.convert('grid grid-cols-3 gap-4');

      expect(result.baseStyles).toMatchObject({
        display: 'grid',
        'grid-template-columns': 'repeat(3, minmax(0, 1fr))',
        gap: '1rem',
      });
    });

    it('should convert typography utilities', () => {
      const result = converter.convert('text-xl font-bold text-center');

      expect(result.baseStyles).toMatchObject({
        'font-size': '1.25rem',
        'font-weight': '700',
        'text-align': 'center',
      });
    });

    it('should convert color utilities', () => {
      const result = converter.convert('text-blue-500 bg-gray-100');

      expect(result.baseStyles).toMatchObject({
        color: '#3b82f6',
        'background-color': '#f3f4f6',
      });
    });

    it('should convert border utilities', () => {
      const result = converter.convert('border border-gray-300 rounded-lg');

      expect(result.baseStyles).toMatchObject({
        'border-width': '1px',
        'border-color': '#d1d5db',
        'border-radius': '0.5rem',
      });
    });

    it('should handle hover modifiers', () => {
      const result = converter.convert('bg-blue-500 hover:bg-blue-600');

      expect(result.baseStyles['background-color']).toBe('#3b82f6');
      expect(result.hoverStyles['background-color']).toBe('#2563eb');
    });

    it('should handle focus modifiers', () => {
      const result = converter.convert('border-gray-300 focus:border-blue-500');

      expect(result.baseStyles['border-color']).toBe('#d1d5db');
      expect(result.focusStyles['border-color']).toBe('#3b82f6');
    });

    it('should handle responsive modifiers', () => {
      const result = converter.convert('text-sm md:text-base lg:text-lg');

      expect(result.baseStyles['font-size']).toBe('0.875rem');
      expect(result.responsiveStyles['md']['font-size']).toBe('1rem');
      expect(result.responsiveStyles['lg']['font-size']).toBe('1.125rem');
    });

    it('should handle width/height utilities', () => {
      const result = converter.convert('w-full h-64');

      expect(result.baseStyles).toMatchObject({
        width: '100%',
        height: '16rem',
      });
    });

    it('should handle shadow utilities', () => {
      const result = converter.convert('shadow-md');

      expect(result.baseStyles['box-shadow']).toBeDefined();
    });

    it('should convert multiple utility classes correctly', () => {
      const result = converter.convert(
        'flex items-center justify-center p-4 bg-white rounded-lg shadow-md hover:shadow-lg'
      );

      expect(result.baseStyles).toMatchObject({
        display: 'flex',
        'align-items': 'center',
        'justify-content': 'center',
        padding: '1rem',
        'background-color': '#ffffff',
        'border-radius': '0.5rem',
      });

      expect(result.hoverStyles).toHaveProperty('box-shadow');
    });
  });
});
