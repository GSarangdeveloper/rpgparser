/**
 * Image Comparator Tests
 */

import { ImageComparator } from '../validation/visual-comparison/image-comparator';
import * as fs from 'fs-extra';
import { PNG } from 'pngjs';

// Mock fs-extra
jest.mock('fs-extra');

describe('ImageComparator', () => {
  let comparator: ImageComparator;

  beforeEach(() => {
    comparator = new ImageComparator();
  });

  describe('compare', () => {
    it('should return 100% similarity for identical images', async () => {
      // Create identical test images
      const img1 = new PNG({ width: 100, height: 100 });
      const img2 = new PNG({ width: 100, height: 100 });

      // Fill with same color
      for (let i = 0; i < img1.data.length; i++) {
        img1.data[i] = 128;
        img2.data[i] = 128;
      }

      (fs.readFile as jest.Mock)
        .mockResolvedValueOnce(PNG.sync.write(img1))
        .mockResolvedValueOnce(PNG.sync.write(img2));

      const result = await comparator.compare('img1.png', 'img2.png', {
        generateDiff: false,
      });

      expect(result.success).toBe(true);
      expect(result.similarity).toBeCloseTo(100, 0);
      expect(result.pixelDifference).toBe(0);
    });

    it('should detect differences between images', async () => {
      // Create different test images
      const img1 = new PNG({ width: 100, height: 100 });
      const img2 = new PNG({ width: 100, height: 100 });

      // Fill with different colors
      img1.data.fill(128);
      img2.data.fill(200);

      (fs.readFile as jest.Mock)
        .mockResolvedValueOnce(PNG.sync.write(img1))
        .mockResolvedValueOnce(PNG.sync.write(img2));

      const result = await comparator.compare('img1.png', 'img2.png', {
        generateDiff: false,
      });

      expect(result.success).toBe(true);
      expect(result.similarity).toBeLessThan(100);
      expect(result.pixelDifference).toBeGreaterThan(0);
    });

    it('should handle dimension mismatch', async () => {
      const img1 = new PNG({ width: 100, height: 100 });
      const img2 = new PNG({ width: 200, height: 200 });

      img1.data.fill(128);
      img2.data.fill(128);

      (fs.readFile as jest.Mock)
        .mockResolvedValueOnce(PNG.sync.write(img1))
        .mockResolvedValueOnce(PNG.sync.write(img2));

      const result = await comparator.compare('img1.png', 'img2.png', {
        generateDiff: false,
      });

      expect(result.success).toBe(true);
      // Should resize and compare
    });
  });

  describe('calculateSSIM', () => {
    it('should return 1.0 for identical images', async () => {
      const img = new PNG({ width: 100, height: 100 });
      img.data.fill(128);

      (fs.readFile as jest.Mock)
        .mockResolvedValueOnce(PNG.sync.write(img))
        .mockResolvedValueOnce(PNG.sync.write(img));

      const ssim = await comparator.calculateSSIM('img1.png', 'img2.png');

      expect(ssim).toBeCloseTo(1.0, 1);
    });

    it('should return 0 for dimension mismatch', async () => {
      const img1 = new PNG({ width: 100, height: 100 });
      const img2 = new PNG({ width: 200, height: 200 });

      (fs.readFile as jest.Mock)
        .mockResolvedValueOnce(PNG.sync.write(img1))
        .mockResolvedValueOnce(PNG.sync.write(img2));

      const ssim = await comparator.calculateSSIM('img1.png', 'img2.png');

      expect(ssim).toBe(0);
    });
  });
});
