/**
 * Compilation Validator Tests
 */

import { CompilationValidator } from '../validation/compilation-validator';
import * as fs from 'fs-extra';

jest.mock('fs-extra');

describe('CompilationValidator', () => {
  let validator: CompilationValidator;

  beforeEach(() => {
    validator = new CompilationValidator();
  });

  describe('validateFile', () => {
    it('should validate correct TypeScript code', async () => {
      const validCode = `
        import { Component } from '@angular/core';

        @Component({
          selector: 'app-test',
          template: '<div>Test</div>',
        })
        export class TestComponent {
          public name: string = 'Test';
        }
      `;

      (fs.readFile as jest.Mock).mockResolvedValue(validCode);
      (fs.pathExists as jest.Mock).mockResolvedValue(true);

      const result = await validator.validateFile('/test/test.component.ts');

      expect(result.success).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should detect syntax errors', async () => {
      const invalidCode = `
        import { Component } from '@angular/core';

        @Component({
          selector: 'app-test',
          template: '<div>Test</div>',
        })
        export class TestComponent {
          public name: string = 'Test'  // Missing semicolon
          public count number = 0;       // Missing colon
        }
      `;

      (fs.readFile as jest.Mock).mockResolvedValue(invalidCode);
      (fs.pathExists as jest.Mock).mockResolvedValue(true);

      const result = await validator.validateFile('/test/test.component.ts');

      expect(result.success).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it('should detect type errors', async () => {
      const typeErrorCode = `
        export class TestComponent {
          public name: string = 123;  // Type error: number assigned to string
          public count: number = 'text';  // Type error: string assigned to number
        }
      `;

      (fs.readFile as jest.Mock).mockResolvedValue(typeErrorCode);
      (fs.pathExists as jest.Mock).mockResolvedValue(true);

      const result = await validator.validateFile('/test/test.component.ts', {
        strict: true,
      });

      expect(result.success).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });
  });

  describe('validateFiles', () => {
    it('should validate multiple files', async () => {
      const validCode = `
        export class TestComponent {
          public name: string = 'Test';
        }
      `;

      (fs.readFile as jest.Mock).mockResolvedValue(validCode);

      const result = await validator.validateFiles([
        '/test/component1.ts',
        '/test/component2.ts',
      ]);

      expect(result.compiledFiles).toBe(2);
    });
  });

  describe('formatResult', () => {
    it('should format successful result', () => {
      const result = {
        success: true,
        errors: [],
        warnings: [],
        diagnostics: [],
        compiledFiles: 1,
      };

      const formatted = validator.formatResult(result);

      expect(formatted).toContain('✓ PASS');
      expect(formatted).toContain('Files compiled: 1');
      expect(formatted).toContain('Errors: 0');
    });

    it('should format failed result with errors', () => {
      const result = {
        success: false,
        errors: [
          {
            file: 'test.ts',
            line: 10,
            column: 5,
            code: 2345,
            message: 'Type error',
            severity: 'error' as const,
          },
        ],
        warnings: [],
        diagnostics: [],
        compiledFiles: 1,
      };

      const formatted = validator.formatResult(result);

      expect(formatted).toContain('✗ FAIL');
      expect(formatted).toContain('Errors: 1');
      expect(formatted).toContain('test.ts:10:5');
      expect(formatted).toContain('Type error');
    });
  });
});
