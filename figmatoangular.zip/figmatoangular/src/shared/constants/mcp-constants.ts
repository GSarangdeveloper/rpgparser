/**
 * MCP (Model Context Protocol) Constants
 * Configuration for Figma's Remote MCP Server
 */

export const MCP_CONFIG = {
  serverUrl: 'https://mcp.figma.com/mcp',
  transport: 'streamable-http',
  protocol: 'jsonrpc-2.0',
  version: '1.0',
} as const;

export const MCP_TOOLS = {
  GET_CODE: {
    name: 'get_code',
    priority: 1,
    required: true,
    description: 'Get React+Tailwind code representation',
  },
  GET_SCREENSHOT: {
    name: 'get_screenshot',
    priority: 2,
    required: true,
    description: 'Get visual screenshot',
  },
  GET_METADATA: {
    name: 'get_metadata',
    priority: 0,
    required: false,
    description: 'Get structural overview (fallback for large designs)',
  },
  GET_VARIABLE_DEFS: {
    name: 'get_variable_defs',
    priority: 3,
    required: false,
    description: 'Extract design tokens',
  },
  GET_CODE_CONNECT_MAP: {
    name: 'get_code_connect_map',
    priority: 4,
    required: false,
    description: 'Map Figma nodes to code components',
  },
} as const;

export const MCP_ERRORS = {
  AUTHENTICATION_FAILED: 'MCP_AUTH_FAILED',
  TOOL_NOT_FOUND: 'MCP_TOOL_NOT_FOUND',
  INVALID_REQUEST: 'MCP_INVALID_REQUEST',
  SERVER_ERROR: 'MCP_SERVER_ERROR',
  TIMEOUT: 'MCP_TIMEOUT',
  TRUNCATED_RESPONSE: 'MCP_TRUNCATED_RESPONSE',
} as const;

export const MCP_TIMEOUTS = {
  DEFAULT: 30000, // 30 seconds
  GET_CODE: 60000, // 60 seconds (can be large)
  GET_SCREENSHOT: 45000, // 45 seconds
  GET_METADATA: 30000, // 30 seconds
} as const;
