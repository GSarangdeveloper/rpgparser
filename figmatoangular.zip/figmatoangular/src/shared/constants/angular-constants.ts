/**
 * Angular-specific constants and conventions
 */

export const ANGULAR_CONFIG = {
  defaultSelector: 'app',
  defaultChangeDetection: 'OnPush',
  defaultStyleEncapsulation: 'Emulated',
} as const;

export const ANGULAR_FILE_EXTENSIONS = {
  COMPONENT: '.component.ts',
  TEMPLATE: '.component.html',
  STYLE: '.component.scss',
  MODULE: '.module.ts',
  SERVICE: '.service.ts',
  SPEC: '.spec.ts',
} as const;

export const ANGULAR_LIFECYCLE_HOOKS = [
  'ngOnInit',
  'ngOnChanges',
  'ngDoCheck',
  'ngAfterContentInit',
  'ngAfterContentChecked',
  'ngAfterViewInit',
  'ngAfterViewChecked',
  'ngOnDestroy',
] as const;

export const ANGULAR_DECORATORS = {
  COMPONENT: '@Component',
  INPUT: '@Input',
  OUTPUT: '@Output',
  VIEW_CHILD: '@ViewChild',
  VIEW_CHILDREN: '@ViewChildren',
  CONTENT_CHILD: '@ContentChild',
  CONTENT_CHILDREN: '@ContentChildren',
  HOST_BINDING: '@HostBinding',
  HOST_LISTENER: '@HostListener',
} as const;

export const ANGULAR_DIRECTIVES = {
  NG_IF: '*ngIf',
  NG_FOR: '*ngFor',
  NG_SWITCH: '*ngSwitch',
  NG_CLASS: '[ngClass]',
  NG_STYLE: '[ngStyle]',
  NG_MODEL: '[(ngModel)]',
} as const;

export const DEFAULT_COMPONENT_PATHS = {
  SHARED: 'src/app/shared/components',
  FEATURES: 'src/app/features',
  CORE: 'src/app/core',
} as const;
