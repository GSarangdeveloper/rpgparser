/**
 * Conversion Result Model
 * Defines the structure of conversion results
 */

export interface GeneratedFile {
  path: string;
  type: 'component' | 'template' | 'style' | 'module' | 'test' | 'asset' | 'documentation';
  content: string;
  size: number;
}

export interface ValidationIssue {
  type: 'error' | 'warning' | 'info';
  category: 'compilation' | 'visual' | 'accessibility' | 'lint';
  message: string;
  file?: string;
  line?: number;
  column?: number;
}

export interface VisualComparisonResult {
  overallSimilarity: number; // 0-100
  figmaScreenshotPath: string;
  generatedScreenshotPath: string;
  diffImagePath: string;
  issues: {
    critical: ValidationIssue[];
    warnings: ValidationIssue[];
  };
  metrics: {
    pixelDifference: number;
    structuralSimilarity: number; // SSIM
    colorDifference: number;
  };
}

export interface ValidationReport {
  success: boolean;
  issues: ValidationIssue[];
  visual?: VisualComparisonResult;
  compilation?: {
    success: boolean;
    errors: string[];
  };
  accessibility?: {
    score: number;
    violations: ValidationIssue[];
  };
  lint?: {
    errors: number;
    warnings: number;
    details: ValidationIssue[];
  };
}

export interface ConversionResult {
  success: boolean;
  componentName: string;
  generatedFiles: GeneratedFile[];
  validationReport: ValidationReport;
  metadata: {
    figmaUrl: string;
    figmaNodeId: string;
    conversionTime: number; // milliseconds
    timestamp: Date;
  };
  designTokens?: {
    colors: Record<string, string>;
    spacing: Record<string, string>;
    typography: Record<string, string>;
  };
  reusedComponents?: string[];
  error?: string;
}
