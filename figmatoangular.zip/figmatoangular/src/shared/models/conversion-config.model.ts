/**
 * Conversion Configuration Model
 * Defines configuration options for the conversion process
 */

export interface ConversionConfig {
  // Input
  figmaUrl: string;
  figmaAccessToken?: string;

  // Output
  outputDir: string;
  componentName?: string;

  // Angular settings
  angular: {
    selector?: string;
    standalone?: boolean;
    changeDetection?: 'Default' | 'OnPush';
    styleEncapsulation?: 'Emulated' | 'None' | 'ShadowDom';
    generateTests?: boolean;
    generateModule?: boolean;
  };

  // Transformation options
  transformation: {
    reuseComponents?: boolean;
    useDesignTokens?: boolean;
    generateDocumentation?: boolean;
    semanticHtml?: boolean;
    accessibility?: boolean;
  };

  // Asset options
  assets: {
    downloadAssets?: boolean;
    optimizeImages?: boolean;
    inlineSvgs?: boolean;
    assetPath?: string;
  };

  // Validation options
  validation: {
    visualComparison?: boolean;
    compileCheck?: boolean;
    lintCheck?: boolean;
    accessibilityCheck?: boolean;
    similarityThreshold?: number; // 0-100
  };

  // Design system
  designSystem?: {
    componentsPath?: string;
    tokensPath?: string;
    codeConnectMappings?: Record<string, string>;
  };
}

export const DEFAULT_CONFIG: Partial<ConversionConfig> = {
  outputDir: './output',
  angular: {
    standalone: true,
    changeDetection: 'OnPush',
    styleEncapsulation: 'Emulated',
    generateTests: false,
    generateModule: false,
  },
  transformation: {
    reuseComponents: true,
    useDesignTokens: true,
    generateDocumentation: true,
    semanticHtml: true,
    accessibility: true,
  },
  assets: {
    downloadAssets: true,
    optimizeImages: true,
    inlineSvgs: true,
    assetPath: './assets',
  },
  validation: {
    visualComparison: true,
    compileCheck: true,
    lintCheck: false,
    accessibilityCheck: true,
    similarityThreshold: 90,
  },
};
