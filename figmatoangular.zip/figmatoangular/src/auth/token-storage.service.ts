/**
 * Token Storage Service
 * Securely stores OAuth tokens on disk
 */

import * as fs from 'fs-extra';
import * as path from 'path';
import * as crypto from 'crypto';
import { logger } from '../shared/utils/logger.service';
import { FigmaTokens } from './auth.service';

export class TokenStorageService {
  private tokenPath: string;
  private encryptionKey: string;

  constructor() {
    const homeDir = process.env.HOME || process.env.USERPROFILE || '.';
    const configDir = path.join(homeDir, '.figma-to-angular');
    this.tokenPath = path.join(configDir, 'tokens.enc');

    // Generate or retrieve encryption key
    this.encryptionKey = this.getOrCreateEncryptionKey(configDir);

    // Ensure config directory exists
    fs.ensureDirSync(configDir);
  }

  /**
   * Save tokens to disk (encrypted)
   */
  async saveTokens(tokens: FigmaTokens): Promise<void> {
    try {
      const data = JSON.stringify({
        ...tokens,
        expiresAt: tokens.expiresAt?.toISOString(),
      });

      const encrypted = this.encrypt(data);
      await fs.writeFile(this.tokenPath, encrypted, 'utf-8');

      logger.debug('Tokens saved successfully');
    } catch (error) {
      logger.error('Failed to save tokens', error);
      throw error;
    }
  }

  /**
   * Load tokens from disk (decrypt)
   */
  async getTokens(): Promise<FigmaTokens | null> {
    try {
      if (!(await fs.pathExists(this.tokenPath))) {
        logger.debug('No tokens file found');
        return null;
      }

      const encrypted = await fs.readFile(this.tokenPath, 'utf-8');
      const decrypted = this.decrypt(encrypted);
      const data = JSON.parse(decrypted);

      return {
        ...data,
        expiresAt: data.expiresAt ? new Date(data.expiresAt) : undefined,
      };
    } catch (error) {
      logger.error('Failed to load tokens', error);
      return null;
    }
  }

  /**
   * Clear tokens
   */
  async clearTokens(): Promise<void> {
    try {
      if (await fs.pathExists(this.tokenPath)) {
        await fs.remove(this.tokenPath);
        logger.debug('Tokens cleared');
      }
    } catch (error) {
      logger.error('Failed to clear tokens', error);
      throw error;
    }
  }

  /**
   * Encrypt data using AES-256-CBC
   */
  private encrypt(text: string): string {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(this.encryptionKey, 'hex'), iv);

    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');

    return iv.toString('hex') + ':' + encrypted;
  }

  /**
   * Decrypt data using AES-256-CBC
   */
  private decrypt(text: string): string {
    const parts = text.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const encryptedText = parts[1];

    const decipher = crypto.createDecipheriv(
      'aes-256-cbc',
      Buffer.from(this.encryptionKey, 'hex'),
      iv
    );

    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted;
  }

  /**
   * Get or create encryption key
   */
  private getOrCreateEncryptionKey(configDir: string): string {
    const keyPath = path.join(configDir, '.key');

    try {
      if (fs.existsSync(keyPath)) {
        return fs.readFileSync(keyPath, 'utf-8').trim();
      }

      // Generate new key
      const key = crypto.randomBytes(32).toString('hex');
      fs.ensureDirSync(configDir);
      fs.writeFileSync(keyPath, key, { mode: 0o600 }); // Restrict permissions

      return key;
    } catch (error) {
      logger.error('Failed to get/create encryption key', error);
      throw error;
    }
  }
}
