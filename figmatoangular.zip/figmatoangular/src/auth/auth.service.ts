/**
 * Authentication Service
 * Handles OAuth 2.0 authentication with Figma
 */

import { AuthorizationCode } from 'simple-oauth2';
import { logger } from '../shared/utils/logger.service';
import { TokenStorageService } from './token-storage.service';

export interface FigmaTokens {
  accessToken: string;
  refreshToken?: string;
  expiresAt?: Date;
}

export class AuthService {
  private oauth2Client: AuthorizationCode;
  private tokenStorage: TokenStorageService;

  constructor() {
    const clientId = process.env.FIGMA_CLIENT_ID;
    const clientSecret = process.env.FIGMA_CLIENT_SECRET;
    // const redirectUri = process.env.FIGMA_REDIRECT_URI || 'http://localhost:3000/callback'; // Unused variable

    if (!clientId || !clientSecret) {
      throw new Error('FIGMA_CLIENT_ID and FIGMA_CLIENT_SECRET must be set in environment');
    }

    this.oauth2Client = new AuthorizationCode({
      client: {
        id: clientId,
        secret: clientSecret,
      },
      auth: {
        tokenHost: 'https://www.figma.com',
        authorizePath: '/oauth',
        tokenPath: '/api/oauth/token',
      },
    });

    this.tokenStorage = new TokenStorageService();
    logger.info('AuthService initialized');
  }

  /**
   * Generate authorization URL for OAuth flow
   */
  getAuthorizationUrl(state?: string): string {
    const authUrl = this.oauth2Client.authorizeURL({
      redirect_uri: process.env.FIGMA_REDIRECT_URI || 'http://localhost:3000/callback',
      scope: 'file_read',
      state: state || this.generateState(),
    });

    logger.debug('Authorization URL generated', authUrl);
    return authUrl;
  }

  /**
   * Exchange authorization code for access token
   */
  async exchangeCodeForToken(code: string): Promise<FigmaTokens> {
    try {
      logger.info('Exchanging authorization code for token');

      const tokenParams = {
        code,
        redirect_uri: process.env.FIGMA_REDIRECT_URI || 'http://localhost:3000/callback',
      };

      const accessToken = await this.oauth2Client.getToken(tokenParams);
      const token = accessToken.token;

      const tokens: FigmaTokens = {
        accessToken: token.access_token as string,
        refreshToken: token.refresh_token as string,
        expiresAt: token.expires_at ? new Date(token.expires_at as number * 1000) : undefined,
      };

      // Store tokens
      await this.tokenStorage.saveTokens(tokens);

      logger.success('Successfully obtained access token');
      return tokens;
    } catch (error) {
      logger.error('Failed to exchange code for token', error);
      throw new Error('Authentication failed: Unable to obtain access token');
    }
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshAccessToken(): Promise<FigmaTokens> {
    try {
      logger.info('Refreshing access token');

      const currentTokens = await this.tokenStorage.getTokens();
      if (!currentTokens?.refreshToken) {
        throw new Error('No refresh token available');
      }

      const tokenObject = this.oauth2Client.createToken({
        access_token: currentTokens.accessToken,
        refresh_token: currentTokens.refreshToken,
      });

      const refreshedToken = await tokenObject.refresh();
      const token = refreshedToken.token;

      const newTokens: FigmaTokens = {
        accessToken: token.access_token as string,
        refreshToken: token.refresh_token as string,
        expiresAt: token.expires_at ? new Date(token.expires_at as number * 1000) : undefined,
      };

      // Store new tokens
      await this.tokenStorage.saveTokens(newTokens);

      logger.success('Successfully refreshed access token');
      return newTokens;
    } catch (error) {
      logger.error('Failed to refresh access token', error);
      throw new Error('Token refresh failed');
    }
  }

  /**
   * Get valid access token (refresh if needed)
   */
  async getValidAccessToken(): Promise<string> {
    const tokens = await this.tokenStorage.getTokens();

    if (!tokens) {
      throw new Error('No tokens available. Please authenticate first.');
    }

    // Check if token is expired or will expire in next 5 minutes
    if (tokens.expiresAt) {
      const expiryBuffer = 5 * 60 * 1000; // 5 minutes
      const now = Date.now();
      const expiresAt = tokens.expiresAt.getTime();

      if (expiresAt - now < expiryBuffer) {
        logger.info('Token expired or expiring soon, refreshing...');
        const refreshedTokens = await this.refreshAccessToken();
        return refreshedTokens.accessToken;
      }
    }

    return tokens.accessToken;
  }

  /**
   * Check if user is authenticated
   */
  async isAuthenticated(): Promise<boolean> {
    const tokens = await this.tokenStorage.getTokens();
    return !!tokens?.accessToken;
  }

  /**
   * Logout (clear tokens)
   */
  async logout(): Promise<void> {
    await this.tokenStorage.clearTokens();
    logger.info('User logged out, tokens cleared');
  }

  /**
   * Generate random state for OAuth
   */
  private generateState(): string {
    return Math.random().toString(36).substring(2, 15);
  }
}
