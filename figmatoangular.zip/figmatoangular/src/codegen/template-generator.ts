/**
 * Template Generator
 * Generates Angular HTML template files
 */

import * as prettier from 'prettier';
import { logger } from '../shared/utils/logger.service';
import { ComponentTransformResult } from '../transform/orchestrator.service';

export class TemplateGenerator {
  /**
   * Generate HTML template file
   */
  generate(result: ComponentTransformResult): string {
    logger.debug(`Generating template for: ${result.componentName}`);

    if (!result.template) {
      logger.warn('No template available, generating empty template');
      return '<!-- Component template -->\n<div class="component-container">\n  <!-- Add content here -->\n</div>';
    }

    // Format template with Prettier (synchronous version)
    try {
      // Note: prettier.format is async, but we're using it synchronously here
      // In production, consider making this method async
      const formatted = prettier.format(result.template, {
        parser: 'html',
        printWidth: 100,
        tabWidth: 2,
        useTabs: false,
        semi: true,
        singleQuote: true,
        bracketSpacing: true,
        arrowParens: 'always',
      }) as any as string;

      return formatted;
    } catch (error) {
      logger.warn('Failed to format with Prettier, returning unformatted', error);
      return result.template;
    }
  }

  /**
   * Generate template with documentation comments
   */
  generateWithComments(result: ComponentTransformResult): string {
    const template = this.generate(result);

    const comments: string[] = [
      '<!--',
      ` Component: ${result.componentName}`,
      ` Generated from Figma design`,
    ];

    if (result.inputs && result.inputs.length > 0) {
      comments.push(` Inputs: ${result.inputs.join(', ')}`);
    }

    if (result.outputs && result.outputs.length > 0) {
      comments.push(` Outputs: ${result.outputs.join(', ')}`);
    }

    if (result.designTokensUsed && result.designTokensUsed.length > 0) {
      comments.push(` Design Tokens Used: ${result.designTokensUsed.length}`);
    }

    comments.push('-->');
    comments.push('');

    return comments.join('\n') + '\n' + template;
  }

  /**
   * Validate template syntax
   */
  validateTemplate(template: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Check for balanced tags
    const openTags = template.match(/<([a-z][a-z0-9]*)[^>]*[^/]>/gi) || [];
    const closeTags = template.match(/<\/([a-z][a-z0-9]*)>/gi) || [];

    if (openTags.length !== closeTags.length) {
      errors.push('Unbalanced HTML tags detected');
    }

    // Check for common Angular syntax errors
    if (template.includes('{{') && !template.includes('}}')) {
      errors.push('Unclosed interpolation detected');
    }

    if (template.includes('[(') && !template.includes(')]')) {
      errors.push('Unclosed two-way binding detected');
    }

    if (template.includes('(') && template.includes(')') && template.match(/\([a-z]+\)="[^"]*"/)) {
      // Check event bindings don't have template expressions
      const eventBindings = template.match(/\([a-z]+\)="{{.*}}"/g);
      if (eventBindings) {
        errors.push('Event bindings should not contain template expressions');
      }
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }
}
