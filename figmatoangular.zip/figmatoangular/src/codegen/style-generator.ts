/**
 * Style Generator
 * Generates Angular SCSS stylesheet files
 */

import { logger } from '../shared/utils/logger.service';
import { ComponentTransformResult } from '../transform/orchestrator.service';

export class StyleGenerator {
  /**
   * Generate SCSS stylesheet
   */
  generate(result: ComponentTransformResult): string {
    logger.debug(`Generating styles for: ${result.componentName}`);

    const lines: string[] = [];

    // Add design tokens import if used
    if (result.designTokensUsed && result.designTokensUsed.length > 0) {
      lines.push('// Design Tokens');
      lines.push('@import "src/styles/tokens";');
      lines.push('');
    }

    // Host styles
    lines.push(':host {');
    lines.push('  display: block;');
    lines.push('}');
    lines.push('');

    // Component class styles
    const className = this.generateClassName(result.componentName);
    lines.push(`.${className} {`);

    if (result.styles && Object.keys(result.styles).length > 0) {
      for (const [prop, value] of Object.entries(result.styles)) {
        lines.push(`  ${prop}: ${value};`);
      }
    } else {
      lines.push('  // Add styles here');
    }

    lines.push('}');

    // Hover styles
    if (result.hoverStyles && Object.keys(result.hoverStyles).length > 0) {
      lines.push('');
      lines.push(`.${className}:hover {`);
      for (const [prop, value] of Object.entries(result.hoverStyles)) {
        lines.push(`  ${prop}: ${value};`);
      }
      lines.push('}');
    }

    // Focus styles
    if (result.focusStyles && Object.keys(result.focusStyles).length > 0) {
      lines.push('');
      lines.push(`.${className}:focus {`);
      for (const [prop, value] of Object.entries(result.focusStyles)) {
        lines.push(`  ${prop}: ${value};`);
      }
      lines.push('}');
    }

    // Responsive styles
    if (result.responsiveStyles && Object.keys(result.responsiveStyles).length > 0) {
      const breakpoints: Record<string, string> = {
        sm: '640px',
        md: '768px',
        lg: '1024px',
        xl: '1280px',
        '2xl': '1536px',
      };

      for (const [breakpoint, styles] of Object.entries(result.responsiveStyles)) {
        if (Object.keys(styles).length > 0) {
          lines.push('');
          lines.push(`@media (min-width: ${breakpoints[breakpoint]}) {`);
          lines.push(`  .${className} {`);
          for (const [prop, value] of Object.entries(styles)) {
            lines.push(`    ${prop}: ${value};`);
          }
          lines.push('  }');
          lines.push('}');
        }
      }
    }

    return lines.join('\n') + '\n';
  }

  /**
   * Generate BEM-style class name
   */
  private generateClassName(componentName: string): string {
    return componentName
      .replace(/Component$/, '')
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .toLowerCase();
  }

  /**
   * Generate styles with comments
   */
  generateWithComments(result: ComponentTransformResult): string {
    const styles = this.generate(result);

    const comments: string[] = [
      '/**',
      ` * ${result.componentName} Styles`,
      ' * Generated from Figma design',
    ];

    if (result.designTokensUsed && result.designTokensUsed.length > 0) {
      comments.push(` * Design Tokens: ${result.designTokensUsed.length} used`);
    }

    if (result.classNames && result.classNames.length > 0) {
      comments.push(` * Original Tailwind Classes: ${result.classNames.join(', ')}`);
    }

    comments.push(' */');
    comments.push('');

    return comments.join('\n') + '\n' + styles;
  }

  /**
   * Generate CSS custom properties from design tokens
   */
  generateTokens(tokens: Record<string, string>): string {
    const lines: string[] = [':root {'];

    for (const [name, value] of Object.entries(tokens)) {
      lines.push(`  --${name}: ${value};`);
    }

    lines.push('}');
    lines.push('');

    return lines.join('\n');
  }
}
