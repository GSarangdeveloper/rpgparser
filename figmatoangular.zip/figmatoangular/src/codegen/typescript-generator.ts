/**
 * TypeScript Component Generator
 * Generates Angular component TypeScript files
 */

import { logger } from '../shared/utils/logger.service';
import { ComponentTransformResult } from '../transform/orchestrator.service';

export interface TypeScriptGeneratorConfig {
  standalone: boolean;
  changeDetection: 'Default' | 'OnPush';
  styleEncapsulation: 'Emulated' | 'None' | 'ShadowDom';
  generateTests: boolean;
}

export class TypeScriptGenerator {
  /**
   * Generate component TypeScript file
   */
  generate(
    result: ComponentTransformResult,
    config: TypeScriptGeneratorConfig
  ): string {
    logger.debug(`Generating TypeScript for: ${result.componentName}`);

    const imports = this.generateImports(result, config);
    const decorator = this.generateDecorator(result, config);
    const classDefinition = this.generateClass(result);

    return `${imports}\n\n${decorator}\nexport class ${result.componentName} ${classDefinition}`;
  }

  /**
   * Generate imports
   */
  private generateImports(
    result: ComponentTransformResult,
    config: TypeScriptGeneratorConfig
  ): string {
    const imports: string[] = [];

    // Core Angular imports
    const coreImports = ['Component'];

    if (result.inputs && result.inputs.length > 0) {
      coreImports.push('Input');
    }

    if (result.outputs && result.outputs.length > 0) {
      coreImports.push('Output', 'EventEmitter');
    }

    if (config.changeDetection === 'OnPush') {
      coreImports.push('ChangeDetectionStrategy');
    }

    if (config.styleEncapsulation !== 'Emulated') {
      coreImports.push('ViewEncapsulation');
    }

    imports.push(`import { ${coreImports.join(', ')} } from '@angular/core';`);

    // FormsModule for ngModel
    if (result.twoWayBindings && result.twoWayBindings.length > 0) {
      imports.push(`import { FormsModule } from '@angular/forms';`);
    }

    // CommonModule for ngIf, ngFor
    if (config.standalone) {
      imports.push(`import { CommonModule } from '@angular/common';`);
    }

    return imports.join('\n');
  }

  /**
   * Generate @Component decorator
   */
  private generateDecorator(
    result: ComponentTransformResult,
    config: TypeScriptGeneratorConfig
  ): string {
    const lines: string[] = ['@Component({'];

    // Selector
    lines.push(`  selector: '${result.selector}',`);

    // Template
    const kebabName = this.toKebabCase(result.componentName);
    lines.push(`  templateUrl: './${kebabName}.component.html',`);

    // Styles
    lines.push(`  styleUrls: ['./${kebabName}.component.scss'],`);

    // Change detection
    if (config.changeDetection === 'OnPush') {
      lines.push(`  changeDetection: ChangeDetectionStrategy.OnPush,`);
    }

    // View encapsulation
    if (config.styleEncapsulation !== 'Emulated') {
      lines.push(`  viewEncapsulation: ViewEncapsulation.${config.styleEncapsulation},`);
    }

    // Standalone
    if (config.standalone) {
      const standaloneImports = ['CommonModule'];
      if (result.twoWayBindings && result.twoWayBindings.length > 0) {
        standaloneImports.push('FormsModule');
      }
      lines.push(`  standalone: true,`);
      lines.push(`  imports: [${standaloneImports.join(', ')}],`);
    }

    lines.push('})');
    return lines.join('\n');
  }

  /**
   * Generate class definition
   */
  private generateClass(result: ComponentTransformResult): string {
    const lines: string[] = ['{'];

    // Inputs
    if (result.inputs && result.inputs.length > 0) {
      for (const input of result.inputs) {
        lines.push(`  @Input() ${input}: any;`);
      }
      lines.push('');
    }

    // Outputs
    if (result.outputs && result.outputs.length > 0) {
      for (const output of result.outputs) {
        lines.push(`  @Output() ${output} = new EventEmitter<any>();`);
      }
      lines.push('');
    }

    // Constructor
    lines.push('  constructor() {}');
    lines.push('');

    // Lifecycle hooks
    lines.push('  ngOnInit(): void {');
    lines.push('    // Component initialization');
    lines.push('  }');

    // Event handler methods for outputs
    if (result.outputs && result.outputs.length > 0) {
      lines.push('');
      for (const output of result.outputs) {
        const methodName = this.generateHandlerMethodName(output);
        lines.push(`  ${methodName}(): void {`);
        lines.push(`    this.${output}.emit();`);
        lines.push('  }');
      }
    }

    lines.push('}');
    return lines.join('\n');
  }

  /**
   * Generate handler method name from event
   */
  private generateHandlerMethodName(eventName: string): string {
    // click → handleClick
    return `handle${eventName.charAt(0).toUpperCase() + eventName.slice(1)}`;
  }

  /**
   * Convert to kebab-case
   */
  private toKebabCase(str: string): string {
    return str
      .replace(/Component$/, '')
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .toLowerCase();
  }

  /**
   * Generate test file
   */
  generateTestFile(
    result: ComponentTransformResult,
    config: TypeScriptGeneratorConfig
  ): string {
    const kebabName = this.toKebabCase(result.componentName);

    return `import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ${result.componentName} } from './${kebabName}.component';

describe('${result.componentName}', () => {
  let component: ${result.componentName};
  let fixture: ComponentFixture<${result.componentName}>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      ${config.standalone ? 'imports' : 'declarations'}: [${result.componentName}]
    }).compileComponents();

    fixture = TestBed.createComponent(${result.componentName});
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Add more tests here
});
`;
  }
}
