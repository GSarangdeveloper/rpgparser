export const environment = {
  production: false,

  // Figma OAuth Configuration
  figma: {
    clientId: 'YOUR_FIGMA_CLIENT_ID',
    clientSecret: 'YOUR_FIGMA_CLIENT_SECRET',
    redirectUri: 'http://localhost:4200/auth/callback',
    scope: 'file_read,file_variables:read',
    authUrl: 'https://www.figma.com/oauth',
    apiUrl: 'https://api.figma.com/v1'
  },

  // MCP Server Configuration
  mcp: {
    serverUrl: 'http://localhost:3000',
    timeout: 30000,
    retryAttempts: 3,
    retryDelay: 1000
  },

  // LLM Configuration
  llm: {
    // Choose provider: 'openai', 'anthropic', or 'azure'
    provider: 'openai',

    // API Configuration
    apiKey: 'YOUR_API_KEY',

    // Model Selection
    model: 'gpt-4-vision-preview', // or 'claude-3-sonnet', 'gpt-4', etc.

    // Generation Parameters
    temperature: 0.3,
    maxTokens: 8000,
    topP: 1,

    // Cost Management
    maxCostPerConversion: 1.00, // Maximum $ per conversion
    enableCaching: true,
    cacheExpiry: 3600000, // 1 hour in milliseconds

    // Retry Configuration
    maxRetries: 3,
    retryDelay: 2000
  },

  // Azure-specific configuration (if using Azure OpenAI)
  azure: {
    resourceName: 'YOUR_AZURE_RESOURCE',
    deploymentName: 'YOUR_DEPLOYMENT_NAME',
    apiVersion: '2024-02-15-preview',
    endpoint: null // Will be constructed from resourceName if not provided
  },

  // Conversion Approach Configuration
  conversion: {
    // Default approach: 'llm', 'rule-based', or 'hybrid'
    defaultApproach: 'llm',

    // Enable parallel processing
    parallelProcessing: true,
    maxConcurrentConversions: 3,

    // Validation Settings
    validation: {
      validateVisual: true,
      validateAccessibility: true,
      validateCompilation: true,
      strictMode: false,
      visualSimilarityThreshold: 0.95,
      accessibilityLevel: 'WCAG-AA'
    },

    // Optimization Settings
    optimization: {
      optimizeImages: true,
      minifyCode: false,
      treeshake: true,
      compressionQuality: 85
    },

    // Output Settings
    output: {
      generateTests: true,
      generateStorybook: false,
      generateDocumentation: true,
      includeSourceMap: true
    }
  },

  // Project Configuration
  project: {
    // Angular Configuration
    angular: {
      version: '17',
      strict: true,
      styleFormat: 'scss',
      changeDetection: 'OnPush',
      namingConvention: 'kebab-case',
      prefix: 'app',
      enableIvy: true,
      enableStandalone: true
    },

    // Design System
    designSystem: {
      enabled: true,
      tokenPrefix: '--ds',
      baseSpacing: 4,
      baseFontSize: 16,
      colorMode: 'light', // 'light', 'dark', or 'auto'
    },

    // Component Library
    componentLibrary: {
      use: 'material', // 'material', 'primeng', 'bootstrap', or 'custom'
      version: '17',
      theme: 'indigo-pink'
    }
  },

  // Asset Management
  assets: {
    downloadPath: './src/assets',
    optimization: {
      images: {
        formats: ['webp', 'original'],
        quality: 85,
        maxWidth: 2048,
        maxHeight: 2048
      },
      svg: {
        optimize: true,
        removeComments: true,
        removeMetadata: true
      }
    }
  },

  // Logging Configuration
  logging: {
    level: 'info', // 'debug', 'info', 'warn', 'error'
    enableFileLogging: true,
    logPath: './logs',
    maxFileSize: 10485760, // 10MB
    maxFiles: 5
  },

  // Feature Flags
  features: {
    enableLLM: true,
    enableRuleBased: true,
    enableHybrid: true,
    enableBatchProcessing: false,
    enableAutoRetry: true,
    enableCostTracking: true,
    enableAnalytics: false,
    enableExperimentalFeatures: false
  },

  // API Rate Limiting
  rateLimit: {
    figma: {
      requestsPerSecond: 10,
      burstLimit: 20
    },
    llm: {
      requestsPerMinute: 60,
      tokensPerMinute: 90000
    }
  },

  // Cache Configuration
  cache: {
    enabled: true,
    strategy: 'memory', // 'memory', 'localStorage', or 'indexedDB'
    maxSize: 52428800, // 50MB
    ttl: 3600000 // 1 hour
  }
};

/**
 * Environment configuration type
 */
export interface Environment {
  production: boolean;
  figma: {
    clientId: string;
    clientSecret: string;
    redirectUri: string;
    scope: string;
    authUrl: string;
    apiUrl: string;
  };
  mcp: {
    serverUrl: string;
    timeout: number;
    retryAttempts: number;
    retryDelay: number;
  };
  llm: {
    provider: 'openai' | 'anthropic' | 'azure';
    apiKey: string;
    model: string;
    temperature: number;
    maxTokens: number;
    topP: number;
    maxCostPerConversion: number;
    enableCaching: boolean;
    cacheExpiry: number;
    maxRetries: number;
    retryDelay: number;
  };
  azure?: {
    resourceName: string;
    deploymentName: string;
    apiVersion: string;
    endpoint: string | null;
  };
  conversion: {
    defaultApproach: 'llm' | 'rule-based' | 'hybrid';
    parallelProcessing: boolean;
    maxConcurrentConversions: number;
    validation: {
      validateVisual: boolean;
      validateAccessibility: boolean;
      validateCompilation: boolean;
      strictMode: boolean;
      visualSimilarityThreshold: number;
      accessibilityLevel: string;
    };
    optimization: {
      optimizeImages: boolean;
      minifyCode: boolean;
      treeshake: boolean;
      compressionQuality: number;
    };
    output: {
      generateTests: boolean;
      generateStorybook: boolean;
      generateDocumentation: boolean;
      includeSourceMap: boolean;
    };
  };
  project: {
    angular: {
      version: string;
      strict: boolean;
      styleFormat: string;
      changeDetection: string;
      namingConvention: string;
      prefix: string;
      enableIvy: boolean;
      enableStandalone: boolean;
    };
    designSystem: {
      enabled: boolean;
      tokenPrefix: string;
      baseSpacing: number;
      baseFontSize: number;
      colorMode: string;
    };
    componentLibrary: {
      use: string;
      version: string;
      theme: string;
    };
  };
  assets: {
    downloadPath: string;
    optimization: {
      images: {
        formats: string[];
        quality: number;
        maxWidth: number;
        maxHeight: number;
      };
      svg: {
        optimize: boolean;
        removeComments: boolean;
        removeMetadata: boolean;
      };
    };
  };
  logging: {
    level: string;
    enableFileLogging: boolean;
    logPath: string;
    maxFileSize: number;
    maxFiles: number;
  };
  features: {
    enableLLM: boolean;
    enableRuleBased: boolean;
    enableHybrid: boolean;
    enableBatchProcessing: boolean;
    enableAutoRetry: boolean;
    enableCostTracking: boolean;
    enableAnalytics: boolean;
    enableExperimentalFeatures: boolean;
  };
  rateLimit: {
    figma: {
      requestsPerSecond: number;
      burstLimit: number;
    };
    llm: {
      requestsPerMinute: number;
      tokensPerMinute: number;
    };
  };
  cache: {
    enabled: boolean;
    strategy: string;
    maxSize: number;
    ttl: number;
  };
}