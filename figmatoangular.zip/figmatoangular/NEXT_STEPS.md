# Next Steps - Detailed Guide

**Current Status:** Phase 1 Complete (Foundation + MCP Integration)
**Next Phase:** Phase 2 - Transformation Engine
**Estimated Time:** 3 weeks

---

## 🎯 Immediate Goals (This Week)

### Day 1-2: React Parser Setup

**Install Dependencies:**
```bash
npm install @babel/parser @babel/traverse @babel/types
npm install --save-dev @types/babel__parser @types/babel__traverse @types/babel__types
```

**Create:** `src/transform/react-parser.service.ts`

**Implementation Checklist:**
- [ ] Import Babel parser
- [ ] Parse JSX string to AST
- [ ] Traverse AST to find components
- [ ] Extract component structure
- [ ] Extract props/state
- [ ] Extract JSX elements
- [ ] Handle nested components
- [ ] Write tests

**Example Code:**
```typescript
import { parse } from '@babel/parser';
import traverse from '@babel/traverse';

export class ReactParser {
  parseComponent(code: string) {
    const ast = parse(code, {
      sourceType: 'module',
      plugins: ['jsx', 'typescript']
    });

    // Traverse and extract
    const component = {
      name: '',
      props: [],
      jsx: null
    };

    traverse(ast, {
      FunctionDeclaration(path) {
        // Extract component
      },
      JSXElement(path) {
        // Extract JSX
      }
    });

    return component;
  }
}
```

---

### Day 3-4: JSX to Angular Transformer

**Create:** `src/transform/angular-transformer.ts`

**Implementation Checklist:**
- [ ] Transform className → class/[ngClass]
- [ ] Transform onClick → (click)
- [ ] Transform style → [ngStyle]
- [ ] Transform conditionals → *ngIf
- [ ] Transform loops → *ngFor
- [ ] Transform {variable} → {{variable}}
- [ ] Handle event handlers
- [ ] Handle two-way binding
- [ ] Write tests

**Transformation Rules:**

| React | Angular |
|-------|---------|
| `className="btn"` | `class="btn"` |
| `className={cls}` | `[ngClass]="cls"` |
| `onClick={fn}` | `(click)="fn()"` |
| `{show && <div>}` | `<div *ngIf="show">` |
| `{items.map(i =>)}` | `<div *ngFor="let i of items">` |
| `{variable}` | `{{variable}}` |
| `<input value={v} onChange={fn}>` | `<input [(ngModel)]="v">` |

**Example:**
```typescript
export class AngularTransformer {
  transformJSX(jsxElement: any): string {
    // Transform JSX node to Angular template
    const tag = jsxElement.openingElement.name.name;
    const attrs = this.transformAttributes(jsxElement.openingElement.attributes);
    const children = this.transformChildren(jsxElement.children);

    return `<${tag} ${attrs}>${children}</${tag}>`;
  }

  transformAttributes(attrs: any[]): string {
    return attrs.map(attr => {
      if (attr.name.name === 'className') {
        return this.transformClassName(attr);
      }
      if (attr.name.name.startsWith('on')) {
        return this.transformEventHandler(attr);
      }
      return this.transformAttribute(attr);
    }).join(' ');
  }
}
```

---

### Day 5: Tailwind to CSS Converter

**Create:** `src/transform/tailwind-converter.ts`

**Implementation Checklist:**
- [ ] Parse Tailwind utility classes
- [ ] Map to CSS properties
- [ ] Handle responsive modifiers (sm:, md:, lg:)
- [ ] Handle state modifiers (hover:, focus:)
- [ ] Handle arbitrary values [prop]
- [ ] Group by selectors
- [ ] Generate SCSS output
- [ ] Write tests

**Example:**
```typescript
export class TailwindConverter {
  private readonly mappings = {
    'flex': { display: 'flex' },
    'flex-col': { 'flex-direction': 'column' },
    'items-center': { 'align-items': 'center' },
    'justify-between': { 'justify-content': 'space-between' },
    'p-4': { padding: '1rem' },
    'text-lg': { 'font-size': '1.125rem' },
    // ... more mappings
  };

  convert(classes: string): string {
    const classList = classes.split(' ');
    const styles: Record<string, string> = {};

    for (const cls of classList) {
      const mapping = this.getMapping(cls);
      Object.assign(styles, mapping);
    }

    return this.toCss(styles);
  }

  private getMapping(cls: string) {
    // Handle responsive: sm:flex → @media (min-width: 640px) { ... }
    // Handle state: hover:bg-blue → &:hover { ... }
    // Handle arbitrary: [prop] → custom value
    return this.mappings[cls] || {};
  }
}
```

---

## 📅 Week 2: Advanced Transformation

### Day 6-7: Component Mapper

**Create:** `src/transform/component-mapper.ts`

**Purpose:** Map Figma components to existing Angular components

**Implementation:**
- [ ] Load existing component registry
- [ ] Compare Figma component to existing
- [ ] Check Code Connect mappings
- [ ] Decide: reuse vs generate
- [ ] Return matched component or null
- [ ] Write tests

**Example:**
```typescript
export class ComponentMapper {
  constructor(
    private registry: ComponentRegistry,
    private codeConnectMappings: Record<string, string>
  ) {}

  findMatch(figmaComponent: any): string | null {
    // 1. Check Code Connect mappings
    if (this.codeConnectMappings[figmaComponent.name]) {
      return this.codeConnectMappings[figmaComponent.name];
    }

    // 2. Check component registry
    const match = this.registry.findByName(figmaComponent.name);
    if (match) return match.path;

    // 3. No match - will generate new component
    return null;
  }
}
```

---

### Day 8-9: Design Token Mapper

**Create:** `src/transform/token-mapper.service.ts`

**Purpose:** Replace hardcoded values with design tokens

**Implementation:**
- [ ] Load existing design tokens
- [ ] Match colors to tokens
- [ ] Match spacing to tokens
- [ ] Match typography to tokens
- [ ] Replace in generated code
- [ ] Create new tokens if needed
- [ ] Write tests

**Example:**
```typescript
export class TokenMapper {
  constructor(private tokens: DesignTokens) {}

  mapColor(colorValue: string): string {
    // Try to find matching token
    const token = this.tokens.colors.find(t => t.value === colorValue);
    if (token) {
      return `var(--${token.name})`;
    }

    // No token found - create new one
    return this.createColorToken(colorValue);
  }

  mapSpacing(value: string): string {
    // Map to spacing scale (4px = --spacing-1, 8px = --spacing-2, etc.)
    const px = parseInt(value);
    const scale = px / 4;
    return `var(--spacing-${scale})`;
  }
}
```

---

### Day 10: Transform Orchestrator

**Create:** `src/transform/orchestrator.service.ts`

**Purpose:** Coordinate all transformation steps

**Implementation:**
```typescript
export class TransformOrchestrator {
  constructor(
    private reactParser: ReactParser,
    private angularTransformer: AngularTransformer,
    private tailwindConverter: TailwindConverter,
    private componentMapper: ComponentMapper,
    private tokenMapper: TokenMapper
  ) {}

  async transform(reactCode: string, config: TransformConfig): Promise<TransformResult> {
    // 1. Parse React code
    const parsed = this.reactParser.parseComponent(reactCode);

    // 2. Check for existing components
    const existingComponent = this.componentMapper.findMatch(parsed);
    if (existingComponent && config.reuseComponents) {
      return { type: 'reuse', componentPath: existingComponent };
    }

    // 3. Transform JSX to Angular template
    const template = this.angularTransformer.transformJSX(parsed.jsx);

    // 4. Convert Tailwind to CSS
    const styles = this.tailwindConverter.convert(parsed.classes);

    // 5. Map to design tokens
    const tokenizedStyles = this.tokenMapper.mapStyles(styles);

    // 6. Generate component structure
    return {
      type: 'generate',
      name: parsed.name,
      template,
      styles: tokenizedStyles,
      inputs: parsed.props,
      outputs: parsed.events
    };
  }
}
```

---

## 📅 Week 3: Code Generation

### Day 11-12: TypeScript Component Generator

**Create:** `src/codegen/typescript-generator.ts`

**Generate `.component.ts` files:**

```typescript
export class TypeScriptGenerator {
  generate(component: ComponentData): string {
    return `
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: '${component.selector}',
  templateUrl: './${component.name}.component.html',
  styleUrls: ['./${component.name}.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true
})
export class ${component.className} {
  ${this.generateInputs(component.inputs)}
  ${this.generateOutputs(component.outputs)}
  ${this.generateMethods(component.methods)}
}
`.trim();
  }
}
```

---

### Day 13: Template & Style Generators

**Create:**
- `src/codegen/template-generator.ts` - Generate .html
- `src/codegen/style-generator.ts` - Generate .scss

**Example:**
```typescript
export class TemplateGenerator {
  generate(template: string): string {
    // Format and prettify
    return prettier.format(template, { parser: 'angular' });
  }
}

export class StyleGenerator {
  generate(styles: any, tokens: any): string {
    return `
@import 'tokens';

.component {
  ${this.generateStyles(styles)}
}

${this.generateModifiers(styles)}
`.trim();
  }
}
```

---

### Day 14-15: Integration & Testing

**Tasks:**
- [ ] Connect all generators
- [ ] Update main converter to use transformation
- [ ] Write comprehensive tests
- [ ] Test with real Figma components
- [ ] Fix bugs
- [ ] Document usage

**Integration:**
```typescript
// In src/index.ts
async convert(config: ConversionConfig): Promise<ConversionResult> {
  // ... existing code ...

  // NEW: Transform React → Angular
  const transformOrchestrator = new TransformOrchestrator(/* ... */);
  const transformed = await transformOrchestrator.transform(
    nodeData.code,
    config.transformation
  );

  // NEW: Generate Angular files
  const tsGen = new TypeScriptGenerator();
  const htmlGen = new TemplateGenerator();
  const scssGen = new StyleGenerator();

  const componentTs = tsGen.generate(transformed);
  const componentHtml = htmlGen.generate(transformed.template);
  const componentScss = scssGen.generate(transformed.styles, nodeData.designTokens);

  // NEW: Write files
  await FileUtils.writeFile(
    path.join(config.outputDir, `${name}.component.ts`),
    componentTs
  );
  // ... more file writes ...

  return result;
}
```

---

## 🧪 Testing Strategy

### Unit Tests (Target: 80% coverage)

**For each module:**
```typescript
// react-parser.service.spec.ts
describe('ReactParser', () => {
  it('should parse simple component', () => {
    const code = `function Button() { return <button>Click</button>; }`;
    const result = parser.parseComponent(code);
    expect(result.name).toBe('Button');
  });
});

// angular-transformer.spec.ts
describe('AngularTransformer', () => {
  it('should transform className to class', () => {
    const jsx = '<div className="container"></div>';
    const result = transformer.transform(jsx);
    expect(result).toBe('<div class="container"></div>');
  });
});

// tailwind-converter.spec.ts
describe('TailwindConverter', () => {
  it('should convert flex utility', () => {
    const result = converter.convert('flex items-center');
    expect(result).toContain('display: flex');
    expect(result).toContain('align-items: center');
  });
});
```

### Integration Tests

```typescript
describe('Full Transformation', () => {
  it('should convert React button to Angular', async () => {
    const reactCode = `
      function PrimaryButton({ label, onClick }) {
        return (
          <button className="flex items-center p-4 bg-blue-500 hover:bg-blue-600" onClick={onClick}>
            {label}
          </button>
        );
      }
    `;

    const result = await orchestrator.transform(reactCode);

    expect(result.template).toContain('(click)="onClick()"');
    expect(result.styles).toContain('display: flex');
    expect(result.inputs).toContain('label');
    expect(result.outputs).toContain('onClick');
  });
});
```

---

## 📚 Resources for Development

### Babel Parser
- **Docs:** https://babeljs.io/docs/en/babel-parser
- **AST Explorer:** https://astexplorer.net/
- **Tutorial:** https://github.com/jamiebuilds/babel-handbook

### Tailwind CSS
- **Docs:** https://tailwindcss.com/docs
- **Config:** https://github.com/tailwindlabs/tailwindcss/blob/master/stubs/defaultConfig.stub.js
- **Parser Example:** https://github.com/ourai/tailwindcss-parser

### Angular
- **Style Guide:** https://angular.io/guide/styleguide
- **Component Syntax:** https://angular.io/guide/component-overview
- **Template Syntax:** https://angular.io/guide/template-syntax

---

## 🎯 Definition of Done (Phase 2)

### Must Have:
- [ ] React code parsed to AST
- [ ] JSX transformed to Angular templates
- [ ] Tailwind converted to CSS
- [ ] Design tokens mapped
- [ ] TypeScript components generated
- [ ] HTML templates generated
- [ ] SCSS stylesheets generated
- [ ] Files written to disk
- [ ] 80% test coverage
- [ ] Documentation updated

### Success Criteria:
- [ ] Can convert simple button component
- [ ] Can convert form with inputs
- [ ] Can convert card layout
- [ ] Generated code compiles without errors
- [ ] Visual output matches Figma screenshot >80%
- [ ] Design tokens used instead of hardcoded values

---

## 🚀 After Phase 2

### Phase 3: Asset Management (Week 4)
- Download images from Figma
- Optimize images
- Process SVGs
- Update paths in code

### Phase 4: Validation (Week 5)
- Screenshot comparison
- Visual diff
- Compilation check
- Accessibility check

### Phase 5: UI (Week 6)
- CLI interface
- Progress bars
- Interactive prompts
- Results display

---

## 💡 Tips for Success

1. **Start Simple** - Test with basic components first
2. **Write Tests Early** - Don't wait until the end
3. **Use AST Explorer** - Visualize JSX structure
4. **Incremental Development** - One feature at a time
5. **Test with Real Data** - Use actual Figma components
6. **Document As You Go** - Update docs immediately
7. **Commit Often** - Small, focused commits

---

## 📞 Need Help?

- Check DEVELOPMENT.md for coding guidelines
- See examples/ for usage patterns
- Read implementation plan for detailed specs
- Review existing code for patterns
- Ask in team chat for blockers

---

**You've got this! The foundation is solid. Now let's build the transformation engine! 🚀**
