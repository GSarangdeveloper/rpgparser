# Quick Start Guide

Get up and running with Figma-to-Angular in 5 minutes!

---

## 🚀 Installation

```bash
# Clone or create project
cd figma-to-angular

# Install dependencies (may take 5-10 minutes first time)
npm install
```

---

## ⚙️ Setup

### 1. Create `.env` file

```bash
cp .env.example .env
```

### 2. Add Figma Credentials

Option A: **OAuth (Recommended)**
```env
FIGMA_CLIENT_ID=your_client_id
FIGMA_CLIENT_SECRET=your_client_secret
FIGMA_REDIRECT_URI=http://localhost:3000/callback
```

Get OAuth credentials:
1. Go to https://www.figma.com/developers/api
2. Create new OAuth app
3. Copy Client ID and Secret

Option B: **Personal Access Token** (Quick Testing)
```env
FIGMA_ACCESS_TOKEN=your_personal_token
```

Get personal token:
1. Go to Figma Settings → Account
2. Scroll to "Personal access tokens"
3. Generate new token

---

## 🎯 Usage

### Method 1: Programmatic (TypeScript)

```typescript
import { FigmaToAngularConverter, DEFAULT_CONFIG } from './src/index';

const converter = new FigmaToAngularConverter();

const result = await converter.convert({
  figmaUrl: 'https://figma.com/file/abc123/MyDesign?node-id=1:2',
  outputDir: './output',
  ...DEFAULT_CONFIG,
});

console.log(result);
```

### Method 2: Run Examples

```bash
# Edit examples/basic-usage.ts with your Figma URL
npm run dev
```

---

## 📝 Your First Conversion

### 1. Get Figma URL

1. Open your Figma file
2. Select a component or frame
3. Right-click → "Copy link"
4. URL should look like:
   ```
   https://figma.com/file/abc123/MyDesign?node-id=1:2
   ```

### 2. Run Conversion

```typescript
import { FigmaToAngularConverter, DEFAULT_CONFIG } from './src/index';

const converter = new FigmaToAngularConverter();

const result = await converter.convert({
  figmaUrl: 'YOUR_FIGMA_URL_HERE',  // Paste your URL
  outputDir: './output/my-component',
  componentName: 'MyComponent',
  ...DEFAULT_CONFIG,
});

if (result.success) {
  console.log('✅ Success!');
  console.log('Generated files:', result.generatedFiles);
} else {
  console.error('❌ Failed:', result.error);
}
```

### 3. Check Output

```bash
ls output/my-component/
# Should contain:
# - my-component.component.ts
# - my-component.component.html
# - my-component.component.scss
```

---

## 🎨 Customize Output

### Standalone Component (Default)

```typescript
await converter.convert({
  figmaUrl: url,
  outputDir: './output',
  angular: {
    standalone: true,
    changeDetection: 'OnPush',
  },
});
```

### Module-based Component

```typescript
await converter.convert({
  figmaUrl: url,
  outputDir: './output',
  angular: {
    standalone: false,
    generateModule: true,
  },
});
```

### With Tests

```typescript
await converter.convert({
  figmaUrl: url,
  outputDir: './output',
  angular: {
    generateTests: true,
  },
});
```

---

## 🔧 Configuration Options

```typescript
interface ConversionConfig {
  // Required
  figmaUrl: string;
  outputDir: string;

  // Optional
  componentName?: string;
  figmaAccessToken?: string;  // If not using OAuth

  angular: {
    selector?: string;           // Default: 'app-{name}'
    standalone?: boolean;        // Default: true
    changeDetection?: string;    // Default: 'OnPush'
    generateTests?: boolean;     // Default: false
    generateModule?: boolean;    // Default: false
  };

  transformation: {
    reuseComponents?: boolean;   // Default: true
    useDesignTokens?: boolean;   // Default: true
    accessibility?: boolean;     // Default: true
  };

  validation: {
    visualComparison?: boolean;  // Default: true
    similarityThreshold?: number; // Default: 90
  };
}
```

---

## 🐛 Troubleshooting

### "Invalid Figma URL"
- Make sure URL includes `node-id` parameter
- Format: `https://figma.com/file/{key}/{name}?node-id={id}`

### "Authentication failed"
- Check `.env` file has correct credentials
- Verify token hasn't expired
- For OAuth: complete browser authentication flow

### "MCP Error"
- Ensure you have Figma Pro/Org/Enterprise account
- Verify you have Dev or Full seat (not Viewer)
- Check internet connection

### "Puppeteer not found"
- Run: `npx puppeteer browsers install chrome`
- Or: `PUPPETEER_SKIP_DOWNLOAD=true npm install`

---

## 📚 Next Steps

1. **Read Full Documentation**: [README.md](README.md)
2. **Development Guide**: [DEVELOPMENT.md](DEVELOPMENT.md)
3. **Check Examples**: [examples/basic-usage.ts](examples/basic-usage.ts)
4. **View Project Status**: [PROJECT_STATUS.md](PROJECT_STATUS.md)

---

## 💡 Tips

### Tip 1: Start Small
Test with a simple component first (e.g., a button) before converting complex layouts.

### Tip 2: Use Design Tokens
Ensure your Figma file uses variables for colors/spacing for best results.

### Tip 3: Review Output
Always review and adjust the generated code. This tool generates a solid starting point.

### Tip 4: Batch Processing
Convert multiple components at once using a loop (see examples).

### Tip 5: Visual Validation
Enable visual comparison to ensure output matches Figma design.

---

## 🎯 Common Use Cases

### Convert Single Button
```typescript
const result = await converter.convert({
  figmaUrl: 'https://figma.com/file/KEY/Design?node-id=button-id',
  componentName: 'PrimaryButton',
  outputDir: './src/app/shared/components/button',
  ...DEFAULT_CONFIG,
});
```

### Convert Form Component
```typescript
const result = await converter.convert({
  figmaUrl: 'https://figma.com/file/KEY/Design?node-id=form-id',
  componentName: 'LoginForm',
  outputDir: './src/app/features/auth/components/login-form',
  angular: { generateTests: true },
  ...DEFAULT_CONFIG,
});
```

### Convert with Design System
```typescript
const result = await converter.convert({
  figmaUrl: 'https://figma.com/file/KEY/Design?node-id=card-id',
  componentName: 'ProductCard',
  outputDir: './src/app/features/products/components/card',
  designSystem: {
    componentsPath: './src/app/shared/components',
    tokensPath: './src/styles/tokens.scss',
  },
  ...DEFAULT_CONFIG,
});
```

---

## 🆘 Need Help?

- **Issues**: Create issue on GitHub
- **Questions**: Check [FAQ in README](README.md)
- **Examples**: See [examples/](examples/) directory
- **Development**: Read [DEVELOPMENT.md](DEVELOPMENT.md)

---

**Ready to convert? Let's go! 🚀**
