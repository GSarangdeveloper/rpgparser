# Development Guide

## Getting Started

### 1. Install Dependencies

```bash
npm install
```

**Note:** First installation may take 5-10 minutes due to Puppeteer downloading Chromium.

### 2. Set Up Environment

```bash
cp .env.example .env
```

Edit `.env` with your Figma OAuth credentials:
- Get credentials from: https://www.figma.com/developers/api
- Register a new OAuth app
- Copy Client ID and Client Secret

### 3. Run Development Server

```bash
npm run dev
```

---

## Project Structure

### Core Modules

#### **Auth Module** (`src/auth/`)
- `auth.service.ts` - OAuth 2.0 authentication flow
- `token-storage.service.ts` - Secure token storage with AES-256 encryption

#### **MCP Module** (`src/mcp/`)
- `mcp-client.service.ts` - JSON-RPC 2.0 client
- `tool-orchestrator.service.ts` - Coordinates tool calls in correct sequence
- `tools/` - Individual MCP tool implementations
  - `get-code.tool.ts` - Fetch React+Tailwind code
  - `get-screenshot.tool.ts` - Fetch visual screenshots
  - `get-metadata.tool.ts` - Fetch XML metadata (fallback)
  - `get-variable-defs.tool.ts` - Fetch design tokens

#### **Figma Module** (`src/figma/`)
- `url-parser.service.ts` - Parse Figma URLs to extract file_key and node_id

#### **Transform Module** (`src/transform/`) - TODO
- React → Angular transformation logic
- JSX → Angular templates
- Tailwind → CSS conversion
- Component matching

#### **Codegen Module** (`src/codegen/`) - TODO
- Angular component generation
- Template generation
- Style generation
- Documentation generation

#### **Validation Module** (`src/validation/`) - TODO
- Visual comparison (screenshot diff)
- Compilation validation
- Accessibility checks
- Linting

---

## Development Workflow

### 1. Create Feature Branch

```bash
git checkout -b feature/my-feature
```

### 2. Write Code

Follow these principles:
- **Type Safety**: Use TypeScript strict mode
- **Logging**: Use `logger` service for all logging
- **Error Handling**: Always catch and log errors
- **Testing**: Write tests for new features

### 3. Run Tests

```bash
npm test
npm run test:coverage
```

### 4. Lint Code

```bash
npm run lint
npm run lint:fix
```

### 5. Format Code

```bash
npm run format
```

### 6. Commit Changes

```bash
git add .
git commit -m "feat: add new feature"
```

Follow [Conventional Commits](https://www.conventionalcommits.org/):
- `feat:` - New feature
- `fix:` - Bug fix
- `docs:` - Documentation
- `test:` - Tests
- `refactor:` - Code refactoring
- `chore:` - Maintenance

---

## Testing Guidelines

### Unit Tests

Create `.spec.ts` files next to source files:

```typescript
// example.service.spec.ts
import { ExampleService } from './example.service';

describe('ExampleService', () => {
  let service: ExampleService;

  beforeEach(() => {
    service = new ExampleService();
  });

  it('should do something', () => {
    expect(service.doSomething()).toBe(true);
  });
});
```

### Integration Tests

Place in `__tests__` directory:

```typescript
// __tests__/conversion.integration.test.ts
describe('Full Conversion Flow', () => {
  it('should convert simple component', async () => {
    // Test implementation
  });
});
```

---

## Code Style

### TypeScript

- Use `interface` for public APIs
- Use `type` for unions/intersections
- Always specify return types for public methods
- Use `readonly` for immutable properties

### Naming Conventions

- **Classes**: PascalCase (`MyService`)
- **Interfaces**: PascalCase (`MyInterface`)
- **Files**: kebab-case (`my-service.ts`)
- **Variables**: camelCase (`myVariable`)
- **Constants**: UPPER_SNAKE_CASE (`MY_CONSTANT`)

### Comments

Use JSDoc for public APIs:

```typescript
/**
 * Parse Figma URL to extract file key and node ID
 * @param url - Figma URL
 * @returns Parsed URL data
 */
parseUrl(url: string): ParsedUrl {
  // Implementation
}
```

---

## Debugging

### Enable Debug Logging

```bash
LOG_LEVEL=debug npm run dev
```

### VS Code Launch Configuration

`.vscode/launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "node",
      "request": "launch",
      "name": "Debug",
      "program": "${workspaceFolder}/src/index.ts",
      "preLaunchTask": "npm: build",
      "outFiles": ["${workspaceFolder}/dist/**/*.js"]
    }
  ]
}
```

---

## Common Issues

### Puppeteer Installation Fails

```bash
# Skip Chromium download
PUPPETEER_SKIP_DOWNLOAD=true npm install

# Install manually
npx puppeteer browsers install chrome
```

### TypeScript Errors

```bash
# Clean build
rm -rf dist/
npm run build
```

### Token Issues

```bash
# Clear cached tokens
rm -rf ~/.figma-to-angular/
```

---

## Next Steps for Development

### Phase 1: Complete MCP Integration ✅
- [x] OAuth authentication
- [x] MCP client
- [x] Tool implementations
- [x] URL parsing

### Phase 2: Transformation Engine (IN PROGRESS)
- [ ] React parser (using Babel)
- [ ] JSX to Angular template transformer
- [ ] Tailwind to CSS converter
- [ ] Component matcher
- [ ] Design token mapper

### Phase 3: Code Generation
- [ ] TypeScript component generator
- [ ] HTML template generator
- [ ] SCSS stylesheet generator
- [ ] Module generator
- [ ] Documentation generator

### Phase 4: Validation
- [ ] Screenshot comparison
- [ ] Visual diff generation
- [ ] Compilation validator
- [ ] Accessibility validator
- [ ] Report generator

### Phase 5: Asset Management
- [ ] Asset downloader
- [ ] Image optimizer
- [ ] SVG processor

### Phase 6: User Interface
- [ ] CLI interface
- [ ] Progress indicators
- [ ] Results viewer

---

## Resources

- [Figma MCP Docs](https://developers.figma.com/docs/figma-mcp-server/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Jest Documentation](https://jestjs.io/docs/getting-started)
- [Angular Style Guide](https://angular.io/guide/styleguide)

---

## Need Help?

- Check existing issues on GitHub
- Read the implementation plan in `IMPLEMENTATION_PLAN.md`
- Ask in team chat/Slack
- Create a new issue with detailed description
