#!/bin/bash

# Prepare Figma-to-Angular for Shipping
# This script cleans up the project and creates a shipping package

echo "================================================"
echo "  Preparing Figma-to-Angular for Shipping"
echo "================================================"
echo ""

# Get version from package.json
VERSION=$(node -p "require('./package.json').version")
PACKAGE_NAME="figmatoangular-v${VERSION}"

echo "📦 Package: ${PACKAGE_NAME}"
echo ""

# Step 1: Clean up
echo "🧹 Step 1: Cleaning up..."
rm -rf node_modules
rm -rf output
rm -rf temp
rm -rf logs
rm -rf coverage
rm -rf .cache
rm -f .env
rm -f .env.local
rm -f *.log
echo "   ✅ Cleaned: node_modules, output, temp, logs, coverage, .env"
echo ""

# Step 2: Verify required files
echo "📋 Step 2: Verifying required files..."
REQUIRED_FILES=(
    "package.json"
    "package-lock.json"
    "tsconfig.json"
    "README.md"
    ".env.example"
    "src"
    "dist"
)

MISSING_FILES=()
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -e "$file" ]; then
        MISSING_FILES+=("$file")
        echo "   ⚠️  Missing: $file"
    else
        echo "   ✅ Found: $file"
    fi
done

if [ ${#MISSING_FILES[@]} -gt 0 ]; then
    echo ""
    echo "⚠️  Warning: Some required files are missing!"
    echo "   Missing: ${MISSING_FILES[*]}"
    echo ""
fi

# Step 3: Check for sensitive data
echo ""
echo "🔒 Step 3: Checking for sensitive data..."
SENSITIVE_FOUND=0

if [ -f ".env" ]; then
    echo "   ⚠️  WARNING: .env file found! This should not be shipped!"
    SENSITIVE_FOUND=1
fi

if [ -d "tokens" ]; then
    echo "   ⚠️  WARNING: tokens/ directory found! This should not be shipped!"
    SENSITIVE_FOUND=1
fi

if [ $SENSITIVE_FOUND -eq 0 ]; then
    echo "   ✅ No sensitive data found"
fi

# Step 4: Create shipping package
echo ""
echo "📦 Step 4: Creating shipping package..."
cd ..

# Create zip file
if command -v zip &> /dev/null; then
    zip -r "${PACKAGE_NAME}.zip" figmatoangular/ \
        -x "*/node_modules/*" \
        -x "*/.git/*" \
        -x "*/.env" \
        -x "*/output/*" \
        -x "*/temp/*" \
        -x "*/logs/*" \
        -x "*/coverage/*" \
        -x "*/.cache/*" \
        -x "*/tokens/*" \
        -q
    
    ZIP_SIZE=$(du -h "${PACKAGE_NAME}.zip" | cut -f1)
    echo "   ✅ Created: ${PACKAGE_NAME}.zip (${ZIP_SIZE})"
else
    echo "   ⚠️  zip command not found, skipping archive creation"
fi

cd figmatoangular

# Step 5: Summary
echo ""
echo "================================================"
echo "  ✅ Shipping Package Ready!"
echo "================================================"
echo ""
echo "📦 Package: ${PACKAGE_NAME}.zip"
echo "📍 Location: ../$(pwd)/../${PACKAGE_NAME}.zip"
echo ""
echo "📋 What's included:"
echo "   ✅ Source code (src/)"
echo "   ✅ Compiled code (dist/)"
echo "   ✅ Configuration files"
echo "   ✅ Documentation"
echo "   ✅ Examples"
echo ""
echo "❌ What's excluded:"
echo "   ❌ node_modules/ (users will run 'npm install')"
echo "   ❌ .env (users will create from .env.example)"
echo "   ❌ output/, temp/, logs/, coverage/"
echo ""
echo "📝 Users will need to:"
echo "   1. Extract the package"
echo "   2. Run: npm install"
echo "   3. Copy .env.example to .env and configure"
echo "   4. Run: npm run build (if needed)"
echo "   5. Run: node dist/cli/cli.js --help"
echo ""
echo "🚀 Ready to ship!"
echo ""

