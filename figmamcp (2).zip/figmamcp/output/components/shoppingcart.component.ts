import { Component } from '@angular/core';

@Component({
  selector: 'app-{component_name.lower()}',
  templateUrl: './{component_name.lower()}.component.html',
  styleUrls: ['./{component_name.lower()}.component.css']
})
export class {component_name}Component {

  constructor() { }

  // Add your component logic here

}