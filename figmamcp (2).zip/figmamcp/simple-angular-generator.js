#!/usr/bin/env node

/**
 * MINIMAL ANGULAR GENERATOR
 *
 * Uses 95% MCP code + 5% minimal processing for maximum accuracy
 * Generates clean Angular components from Figma designs
 *
 * Requirements:
 * - Figma desktop app open
 * - Design file open
 * - Frame/component selected
 */

const { Client } = require("@modelcontextprotocol/sdk/client/index.js");
const { SSEClientTransport } = require("@modelcontextprotocol/sdk/client/sse.js");
const fs = require('fs');
const path = require('path');

async function generateAngularComponent() {
  console.log('🅰️ SIMPLIFIED Angular Component Generator');
  console.log('========================================');
  console.log('');
  console.log('📋 Requirements:');
  console.log('✅ Figma desktop app is open');
  console.log('✅ Design file is open');
  console.log('✅ Frame/component is selected');
  console.log('');
  
  let transport;
  let client;
  
  try {
    console.log('🔌 Connecting to Figma...');
    transport = new SSEClientTransport(new URL("http://127.0.0.1:3845/sse"));
    
    client = new Client(
      {
        name: "angular-generator",
        version: "1.0.0"
      },
      {
        capabilities: {
          tools: {}
        }
      }
    );
    
    await client.connect(transport);
    console.log('✅ Connected to Figma MCP');
    
    console.log('🔄 Getting component code...');
    
    // SIMPLIFIED: Use optimal parameters for Angular
    const result = await client.callTool({
      name: "get_code",
      arguments: {
        clientName: "angular-app",
        clientLanguages: "html, css, typescript",
        clientFrameworks: "angular"
      }
    });
    
    if (result && result.content && result.content[0]) {
      const jsxCode = result.content[0].text;
      console.log('✅ Component code received');
      
      // Create output directory
      const outputDir = "./angular-component";
      if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
      }
      
      console.log('🔄 Converting to Angular format...');
      
      // SIMPLIFIED CONVERSION - minimal processing
      const angularFiles = convertToAngular(jsxCode);
      
      // Save Angular files
      fs.writeFileSync(path.join(outputDir, 'component.html'), angularFiles.template);
      fs.writeFileSync(path.join(outputDir, 'component.css'), angularFiles.styles);
      fs.writeFileSync(path.join(outputDir, 'component.ts'), angularFiles.typescript);
      fs.writeFileSync(path.join(outputDir, 'README.md'), angularFiles.instructions);
      fs.writeFileSync(path.join(outputDir, 'images.txt'), angularFiles.images);
      fs.writeFileSync(path.join(outputDir, 'preview.html'), angularFiles.preview);
      
      console.log('✅ Angular component generated!');
      console.log('');
      console.log('📁 Generated files:');
      console.log('  📄 component.html - Angular template');
      console.log('  🎨 component.css - Component styles');
      console.log('  📝 component.ts - Component class');
      console.log('  🖼️ images.txt - Images to download');
      console.log('  📋 README.md - Setup instructions');
      console.log('  🌐 preview.html - Browser preview');
      
      console.log('');
      console.log('🚀 Next steps:');
      console.log('1. Copy files to your Angular project');
      console.log('2. Download images from images.txt');
      console.log('3. Add Tailwind CSS to your project');
      console.log('4. Follow README.md instructions');
      
      console.log('');
      console.log(`📂 Output folder: ${path.resolve(outputDir)}`);
      
    } else {
      console.log('❌ No component code received');
      console.log('');
      console.log('🔧 Make sure:');
      console.log('• Figma desktop app is open');
      console.log('• Design file is active');
      console.log('• Frame or component is selected');
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.log('');
    console.log('🔧 Troubleshooting:');
    console.log('• Check Figma desktop app is running');
    console.log('• Verify MCP server is connected');
    console.log('• Try selecting a different frame');
  } finally {
    if (transport) {
      try {
        await transport.close();
      } catch (e) {
        // Ignore close errors
      }
    }
  }
}

function convertToAngular(jsxCode) {
  // Extract component name
  const nameMatch = jsxCode.match(/function\s+(\w+)/);
  const componentName = nameMatch ? nameMatch[1] : 'MyComponent';
  
  // Extract images
  const imageMatches = jsxCode.match(/const img\w+ = "([^"]+)";/g) || [];
  const images = [];
  
  imageMatches.forEach((match, index) => {
    const urlMatch = match.match(/const (img\w+) = "([^"]+)";/);
    if (urlMatch) {
      const extension = urlMatch[2].includes('.svg') ? 'svg' : 'png';
      images.push({
        variable: urlMatch[1],
        url: urlMatch[2],
        filename: `image-${index + 1}.${extension}`
      });
    }
  });
  
  // Extract JSX content
  const jsxMatch = jsxCode.match(/return \(([\s\S]*?)\);/);
  if (!jsxMatch) {
    throw new Error('Could not extract component content');
  }
  
  let html = jsxMatch[1].trim();
  
  // MINIMAL conversions - only essentials
  html = html.replace(/className=/g, 'class=');
  
  // Replace image variables with Angular asset paths
  images.forEach(img => {
    const regex = new RegExp(`\\{${img.variable}\\}`, 'g');
    html = html.replace(regex, `"assets/images/${img.filename}"`);
  });
  
  // Fix inline styles for Angular (COMPREHENSIVE FIXES)
  html = html.replace(/style=\{\{([^}]+)\}\}/g, (match, content) => {
    const cleaned = content.replace(/backgroundImage:\s*`url\('([^']+)'\)`/, (m, url) => {
      const img = images.find(i => url.includes(i.variable));
      return img ? `background-image: url('assets/images/${img.filename}')` : m;
    });
    return `style="${cleaned}"`;
  });

  // Fix broken style attributes with $ prefix and malformed quotes
  html = html.replace(/style="\s*backgroundImage:\s*`url\('?\$"([^"']+)"'?\)`[^"]*"/g,
    (match, imagePath) => {
      const img = images.find(i => imagePath.includes(i.variable) || imagePath.includes(i.filename));
      return img ? `style="background-image: url('assets/images/${img.filename}')"` :
                   `style="background-image: url('assets/images/${imagePath}')"`;
    });

  // Fix calc styles with broken quotes
  html = html.replace(/style="\s*top:\s*"calc\([^"]+\)"\s*"/g, 'style="top: 50%"');

  // Fix missing alt attributes
  html = html.replace(/<img alt class=/g, '<img alt="" class=');

  // Create preview HTML with placeholder images
  let previewHtml = html.replace(/assets\/images\//g, 'https://via.placeholder.com/160x160/f3f4f6/9ca3af?text=');

  // Additional fixes for preview
  previewHtml = previewHtml.replace(/style="background-image:\s*url\('https:\/\/via\.placeholder[^']+'\)"/g,
    'style="background-image: url(\'https://via.placeholder.com/160x160/f3f4f6/9ca3af?text=Image\')"');
  
  // Create Angular template
  const template = html;
  
  // Create minimal styles
  const styles = `/* ${componentName} Component Styles */

/* Container */
[data-name*="${componentName}"] {
  width: 100%;
  min-width: 1200px;
  min-height: 900px;
  position: relative;
}

/* Font fixes for complex Tailwind classes */
[class*="font-['Inter:Semi_Bold']"] { font-family: 'Inter', sans-serif; font-weight: 600; }
[class*="font-['Inter:Bold']"] { font-family: 'Inter', sans-serif; font-weight: 700; }
[class*="font-['Inter:Regular']"] { font-family: 'Inter', sans-serif; font-weight: 400; }
[class*="font-['Inter:Light']"] { font-family: 'Inter', sans-serif; font-weight: 300; }
[class*="font-['Newsreader:Regular']"] { font-family: 'Newsreader', serif; font-weight: 400; }
[class*="font-['Newsreader:Medium']"] { font-family: 'Newsreader', serif; font-weight: 500; }`;

  // Create Angular component
  const typescript = `import { Component } from '@angular/core';

@Component({
  selector: 'app-${componentName.toLowerCase()}',
  templateUrl: './${componentName.toLowerCase()}.component.html',
  styleUrls: ['./${componentName.toLowerCase()}.component.css']
})
export class ${componentName}Component {
  
  constructor() { }
  
  // Add your component logic here
  
}`;

  // Create image list
  const imageList = `# Images for ${componentName} Component

${images.map(img => `${img.filename}: ${img.url}`).join('\n')}

# Instructions:
# 1. Download each image using the URL
# 2. Save to: src/assets/images/
# 3. Keep the filenames as shown above`;

  // Create setup instructions
  const instructions = `# ${componentName} Angular Component

## Quick Setup

### 1. Copy Files
\`\`\`bash
# Copy to your Angular project
cp component.html src/app/components/${componentName.toLowerCase()}/${componentName.toLowerCase()}.component.html
cp component.css src/app/components/${componentName.toLowerCase()}/${componentName.toLowerCase()}.component.css
cp component.ts src/app/components/${componentName.toLowerCase()}/${componentName.toLowerCase()}.component.ts
\`\`\`

### 2. Download Images
- Open \`images.txt\`
- Download each image to \`src/assets/images/\`
- Keep the exact filenames shown

### 3. Add Tailwind CSS
\`\`\`bash
# Install Tailwind CSS
ng add @ngneat/tailwind
\`\`\`

### 4. Add Fonts
Add to \`src/index.html\`:
\`\`\`html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Newsreader:wght@400;500&display=swap" rel="stylesheet">
\`\`\`

### 5. Use Component
Add to your module and use:
\`\`\`html
<app-${componentName.toLowerCase()}></app-${componentName.toLowerCase()}>
\`\`\`

## That's it! 🎉

Your Figma design is now a working Angular component.`;

  // Create preview HTML
  const preview = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${componentName} Preview</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Newsreader:wght@400;500&display=swap" rel="stylesheet">
    <style>
        /* Fix complex font classes */
        [class*="font-['Inter:Semi_Bold']"] { font-family: 'Inter', sans-serif !important; font-weight: 600 !important; }
        [class*="font-['Inter:Bold']"] { font-family: 'Inter', sans-serif !important; font-weight: 700 !important; }
        [class*="font-['Inter:Regular']"] { font-family: 'Inter', sans-serif !important; font-weight: 400 !important; }
        [class*="font-['Inter:Light']"] { font-family: 'Inter', sans-serif !important; font-weight: 300 !important; }
        [class*="font-['Newsreader:Regular']"] { font-family: 'Newsreader', serif !important; font-weight: 400 !important; }
        [class*="font-['Newsreader:Medium']"] { font-family: 'Newsreader', serif !important; font-weight: 500 !important; }

        /* Container sizing */
        [data-name*="${componentName}"] {
            width: 100vw;
            height: 100vh;
            min-width: 1200px;
            min-height: 900px;
            position: relative;
            background-color: #ffffff;
        }

        /* Fix letter spacing */
        .adjustLetterSpacing { letter-spacing: -0.02em; }
    </style>
</head>
<body>
    ${previewHtml}
</body>
</html>`;

  return {
    template,
    styles,
    typescript,
    images: imageList,
    instructions,
    preview
  };
}

// Run the generator
generateAngularComponent();
