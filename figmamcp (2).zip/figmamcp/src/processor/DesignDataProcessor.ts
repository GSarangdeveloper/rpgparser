import { FigmaComponent, ComponentStyles, LayoutConstraints, ComponentProps, MCPCodeResponse } from "../types";

export class DesignDataProcessor {
  parseComponentFromMCPResponse(mcpResponse: MCPCodeResponse): FigmaComponent {
    // Parse the generated code to extract component information
    const componentName = this.extractComponentName(mcpResponse.content);
    
    return {
      id: this.generateId(),
      name: componentName,
      type: "COMPONENT",
      styles: this.extractStyles(mcpResponse),
      constraints: this.extractConstraints(mcpResponse),
      props: this.extractProps(mcpResponse.content),
      children: []
    };
  }

  parseComponentTree(mcpResponse: any): FigmaComponent {
    return {
      id: mcpResponse.id || this.generateId(),
      name: this.sanitizeName(mcpResponse.name || "Component"),
      type: mcpResponse.type || "FRAME",
      children: mcpResponse.children?.map((child: any) => this.parseComponentTree(child)) || [],
      constraints: this.extractConstraints(mcpResponse),
      styles: this.extractStyles(mcpResponse),
      props: this.extractProps(mcpResponse)
    };
  }

  extractDesignTokens(variablesResponse: any): any {
    const tokens = {
      colors: [] as any[],
      spacing: [] as any[],
      typography: [] as any[],
      shadows: [] as any[]
    };

    if (variablesResponse.colors) {
      tokens.colors = this.processColorTokens(variablesResponse.colors);
    }
    if (variablesResponse.spacing) {
      tokens.spacing = this.processSpacingTokens(variablesResponse.spacing);
    }
    if (variablesResponse.typography) {
      tokens.typography = this.processTypographyTokens(variablesResponse.typography);
    }
    if (variablesResponse.effects) {
      tokens.shadows = this.processShadowTokens(variablesResponse.effects);
    }

    return tokens;
  }

  private sanitizeName(name: string): string {
    // Convert Figma layer names to valid component names
    return name
      .replace(/[^a-zA-Z0-9]/g, '')
      .replace(/^[0-9]/, match => `Component${match}`)
      .replace(/^[a-z]/, c => c.toUpperCase());
  }

  private extractComponentName(content: string): string {
    // Extract component name from the generated code
    const exportMatch = content.match(/export\s+(?:const|function)\s+(\w+)/);
    const functionMatch = content.match(/function\s+(\w+)/);
    const classMatch = content.match(/class\s+(\w+)/);
    
    return exportMatch?.[1] || functionMatch?.[1] || classMatch?.[1] || "Component";
  }

  private extractConstraints(mcpResponse: any): LayoutConstraints {
    const constraints: LayoutConstraints = {};

    // Extract layout type from the response or generated code
    if (mcpResponse.layout) {
      constraints.layout = mcpResponse.layout;
    }
    
    if (mcpResponse.flexDirection) {
      constraints.flexDirection = mcpResponse.flexDirection;
    }

    if (mcpResponse.justifyContent) {
      constraints.justifyContent = mcpResponse.justifyContent;
    }

    if (mcpResponse.alignItems) {
      constraints.alignItems = mcpResponse.alignItems;
    }

    if (mcpResponse.gap) {
      constraints.gap = mcpResponse.gap;
    }

    return constraints;
  }

  private extractStyles(mcpResponse: any): ComponentStyles {
    const styles: ComponentStyles = {};

    if (mcpResponse.styles) {
      styles.padding = mcpResponse.styles.padding;
      styles.margin = mcpResponse.styles.margin;
      styles.backgroundColor = mcpResponse.styles.backgroundColor;
      styles.color = mcpResponse.styles.color;
      styles.borderRadius = mcpResponse.styles.borderRadius;
      styles.boxShadow = mcpResponse.styles.boxShadow;
    }

    // Extract styles from variables if available
    if (mcpResponse.variables) {
      this.applyVariableStyles(styles, mcpResponse.variables);
    }

    return styles;
  }

  private extractProps(content: string | any): ComponentProps {
    const props: ComponentProps = {};

    if (typeof content === 'string') {
      // Extract props from TypeScript interface or PropTypes
      const interfaceMatch = content.match(/interface\s+\w+Props\s*{([^}]+)}/);
      if (interfaceMatch) {
        const propsContent = interfaceMatch[1];
        const propMatches = propsContent.matchAll(/(\w+)(\?)?:\s*([^;]+);/g);
        
        for (const match of propMatches) {
          props[match[1]] = {
            required: !match[2],
            type: match[3].trim()
          };
        }
      }
    } else if (content.props) {
      return content.props;
    }

    return props;
  }

  private processColorTokens(colors: any[]): any[] {
    return colors.map(color => ({
      figmaId: color.id,
      name: this.tokenizeName(color.name),
      value: this.rgbaToHex(color.value),
      originalValue: color.value
    }));
  }

  private processSpacingTokens(spacing: any[]): any[] {
    return spacing.map(space => ({
      figmaId: space.id,
      name: this.tokenizeName(space.name),
      value: space.value,
      unit: 'px'
    }));
  }

  private processTypographyTokens(typography: any[]): any[] {
    return typography.map(typo => ({
      figmaId: typo.id,
      name: this.tokenizeName(typo.name),
      fontFamily: typo.fontFamily,
      fontSize: typo.fontSize,
      fontWeight: typo.fontWeight,
      lineHeight: typo.lineHeight,
      letterSpacing: typo.letterSpacing
    }));
  }

  private processShadowTokens(effects: any[]): any[] {
    return effects
      .filter(effect => effect.type === 'DROP_SHADOW')
      .map(shadow => ({
        figmaId: shadow.id,
        name: this.tokenizeName(shadow.name || 'shadow'),
        value: `${shadow.offset.x}px ${shadow.offset.y}px ${shadow.radius}px ${this.rgbaToHex(shadow.color)}`
      }));
  }

  private tokenizeName(name: string): string {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
  }

  private rgbaToHex(rgba: { r: number; g: number; b: number; a?: number }): string {
    const toHex = (n: number) => {
      const hex = Math.round(n * 255).toString(16);
      return hex.length === 1 ? '0' + hex : hex;
    };

    const hex = `#${toHex(rgba.r)}${toHex(rgba.g)}${toHex(rgba.b)}`;
    
    if (rgba.a !== undefined && rgba.a < 1) {
      return hex + toHex(rgba.a);
    }
    
    return hex;
  }

  private applyVariableStyles(styles: ComponentStyles, variables: any): void {
    // Apply design tokens from variables to styles
    Object.entries(variables).forEach(([key, value]: [string, any]) => {
      if (key.includes('color') || key.includes('Color')) {
        styles.backgroundColor = value;
      }
      if (key.includes('spacing') || key.includes('padding')) {
        styles.padding = value;
      }
    });
  }

  private generateId(): string {
    return `figma-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}