import { DesignTokens } from "../types";
import { FigmaMCPClient } from "../client/FigmaMCPClient";

export class DesignSystemManager {
  private tokenMapping: Map<string, string> = new Map();
  private designTokens: DesignTokens | null = null;

  constructor(private mcpClient: FigmaMCPClient) {}

  async loadDesignSystem(fileKey: string): Promise<void> {
    try {
      const tokens = await this.mcpClient.getDesignTokens(fileKey);
      this.designTokens = tokens;
      this.buildTokenMapping(tokens);
    } catch (error) {
      console.error("Failed to load design system:", error);
      throw error;
    }
  }

  private buildTokenMapping(tokens: DesignTokens): void {
    // Map Figma variables to CSS custom properties
    tokens.colors.forEach(color => {
      this.tokenMapping.set(color.figmaId, `var(--color-${color.name})`);
    });
    
    tokens.spacing.forEach(space => {
      this.tokenMapping.set(space.figmaId, `var(--spacing-${space.name})`);
    });

    tokens.typography.forEach(typo => {
      this.tokenMapping.set(typo.figmaId, `var(--font-${typo.name})`);
    });

    tokens.shadows.forEach(shadow => {
      this.tokenMapping.set(shadow.figmaId, `var(--shadow-${shadow.name})`);
    });
  }

  resolveToken(figmaValue: any): string {
    if (!figmaValue) return '';

    // Check if it's a variable reference
    if (figmaValue.type === 'VARIABLE_ALIAS' && figmaValue.id) {
      return this.tokenMapping.get(figmaValue.id) || figmaValue.fallback || '';
    }

    // Return the direct value
    return figmaValue.value || figmaValue.toString();
  }

  getTokenValue(tokenName: string): string | undefined {
    for (const [_, value] of this.tokenMapping) {
      if (value.includes(tokenName)) {
        return value;
      }
    }
    return undefined;
  }

  generateCSSVariables(): string {
    if (!this.designTokens) return '';

    const cssLines: string[] = [':root {'];

    // Colors
    this.designTokens.colors.forEach(color => {
      cssLines.push(`  --color-${color.name}: ${color.value};`);
    });

    // Spacing
    this.designTokens.spacing.forEach(space => {
      cssLines.push(`  --spacing-${space.name}: ${space.value}px;`);
    });

    // Typography
    this.designTokens.typography.forEach(typo => {
      cssLines.push(`  --font-${typo.name}-family: ${typo.fontFamily};`);
      cssLines.push(`  --font-${typo.name}-size: ${typo.fontSize}px;`);
      cssLines.push(`  --font-${typo.name}-weight: ${typo.fontWeight};`);
      cssLines.push(`  --font-${typo.name}-line-height: ${typo.lineHeight};`);
    });

    // Shadows
    this.designTokens.shadows.forEach(shadow => {
      cssLines.push(`  --shadow-${shadow.name}: ${shadow.value};`);
    });

    cssLines.push('}');
    
    return cssLines.join('\n');
  }

  getDesignTokens(): DesignTokens | null {
    return this.designTokens;
  }

  hasTokens(): boolean {
    return this.tokenMapping.size > 0;
  }
}