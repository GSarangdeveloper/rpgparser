export interface FigmaComponent {
  id: string;
  name: string;
  type: string;
  figmaUrl?: string;
  children?: FigmaComponent[];
  constraints?: LayoutConstraints;
  styles?: ComponentStyles;
  props?: ComponentProps;
}

export interface LayoutConstraints {
  layout?: 'flex' | 'grid' | 'absolute';
  flexDirection?: 'row' | 'column';
  justifyContent?: string;
  alignItems?: string;
  gap?: number;
}

export interface ComponentStyles {
  padding?: any;
  margin?: any;
  backgroundColor?: any;
  color?: any;
  borderRadius?: any;
  boxShadow?: any;
  typography?: any;
}

export interface ComponentProps {
  [key: string]: any;
}

export interface CodeGenOptions {
  format?: 'react-tsx' | 'react-jsx' | 'html' | 'vue' | 'angular';
  includeStyles?: boolean;
  framework?: 'react' | 'vue' | 'angular' | 'html';
  language?: 'typescript' | 'javascript';
  styling?: 'tailwind' | 'css-modules' | 'styled-components' | 'inline';
}

export interface GeneratedCode {
  filename: string;
  content: string;
  dependencies: string[];
  assets: ProcessedAsset[];
  additionalFiles?: {
    filename: string;
    content: string;
  }[];
}

export interface ProcessedAsset {
  id: string;
  name: string;
  type: 'svg' | 'image';
  content?: string;
  path: string;
  componentName?: string;
}

export interface DesignTokens {
  colors: ColorToken[];
  spacing: SpacingToken[];
  typography: TypographyToken[];
  shadows: ShadowToken[];
}

export interface ColorToken {
  figmaId: string;
  name: string;
  value: string;
}

export interface SpacingToken {
  figmaId: string;
  name: string;
  value: number;
}

export interface TypographyToken {
  figmaId: string;
  name: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: number;
  lineHeight: number;
}

export interface ShadowToken {
  figmaId: string;
  name: string;
  value: string;
}

export interface MCPCodeResponse {
  content: string;
  variables?: any;
  assets?: any[];
}

export interface GenerationOptions {
  framework?: 'react' | 'vue' | 'angular' | 'html';
  language?: 'typescript' | 'javascript';
  styling?: 'tailwind' | 'css-modules' | 'styled-components' | 'inline';
  outputPath?: string;
}

export interface TemplateContext {
  componentName: string;
  props: any[];
  styles: any;
  children: any[];
  imports: any[];
  dependencies: string[];
  assets: ProcessedAsset[];
}