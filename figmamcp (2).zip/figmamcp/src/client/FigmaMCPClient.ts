import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { SSEClientTransport } from "@modelcontextprotocol/sdk/client/sse.js";
import { CodeGenOptions, MCPCodeResponse, DesignTokens } from "../types";

export class FigmaMCPClient {
  private client!: Client;
  private transport!: SSEClientTransport;
  private isConnected: boolean = false;

  constructor(private serverUrl: string = "http://127.0.0.1:3845") {}

  async initialize(): Promise<void> {
    try {
      console.log("Connecting to Figma MCP server at:", this.serverUrl);
      
      // Initialize the MCP client transport with SSE
      this.transport = new SSEClientTransport(new URL(`${this.serverUrl}/sse`));
      
      this.client = new Client(
        {
          name: "figma-code-generator",
          version: "1.0.0"
        },
        {
          capabilities: {
            tools: {}
          }
        }
      );
      
      await this.client.connect(this.transport);
      this.isConnected = true;
      console.log("Successfully connected to Figma MCP server");
    } catch (error) {
      console.error("Failed to connect to Figma MCP server:", error);
      throw error;
    }
  }

  async disconnect(): Promise<void> {
    if (this.isConnected && this.transport) {
      await this.transport.close();
      this.isConnected = false;
    }
  }

  async getAvailableTools(): Promise<any> {
    if (!this.isConnected) {
      throw new Error("Not connected to Figma MCP server");
    }
    
    try {
      const tools = await this.client.listTools();
      console.log("Available tools:", tools);
      return tools;
    } catch (error) {
      console.error("Error listing tools:", error);
      throw error;
    }
  }

  async generateCode(frameUrl: string, options: CodeGenOptions = {}): Promise<MCPCodeResponse> {
    if (!this.isConnected) {
      throw new Error("Not connected to Figma MCP server");
    }

    try {
      console.log("Generating code for:", frameUrl);
      console.log("Options:", options);
      
      // Extract node ID from URL if present
      let nodeId: string | undefined;
      const nodeIdMatch = frameUrl.match(/node-id=([^&]+)/);
      if (nodeIdMatch) {
        nodeId = nodeIdMatch[1].replace('%3A', ':');
      }

      const args = {
        clientName: "figma-mcp-generator",
        clientLanguages: this.getLanguageFromOptions(options),
        clientFrameworks: this.getFrameworkFromOptions(options),
        ...(nodeId && { nodeId: nodeId }),
        // Add format and styling information
        ...(options.format && { format: options.format }),
        ...(options.styling && { styling: options.styling })
      };
      
      console.log("Calling get_code with arguments:", JSON.stringify(args, null, 2));

      const result = await this.client.callTool({
        name: "get_code",
        arguments: args
      });

      console.log("Code generation result:", JSON.stringify(result, null, 2));

      // Check for errors in the response
      if (result.isError || (result.content && (result.content as any)[0]?.text?.includes('error occurred'))) {
        const errorMessage = (result.content as any)?.[0]?.text || 'Unknown error occurred';
        console.error("Code generation error:", errorMessage);
        console.error("Full error response:", JSON.stringify(result, null, 2));
        
        throw new Error(errorMessage);
      }

      // Handle the response structure
      let content = "";
      if (result.content) {
        if (Array.isArray(result.content) && result.content.length > 0) {
          content = result.content[0].text || "";
        } else if (typeof result.content === 'string') {
          content = result.content;
        } else if ((result.content as any).text) {
          content = (result.content as any).text;
        }
      }

      return {
        content: content,
        variables: result.variables || {},
        assets: (result.assets as any[]) || []
      };
    } catch (error) {
      console.error("Error generating code:", error);
      throw error;
    }
  }

  async getDesignTokens(fileKey: string): Promise<DesignTokens> {
    if (!this.isConnected) {
      throw new Error("Not connected to Figma MCP server");
    }

    try {
      console.log("Getting design tokens for file:", fileKey);
      
      const result = await this.client.callTool({
        name: "get_variable_defs",
        arguments: {
          clientName: "figma-mcp-generator",
          clientLanguages: "javascript, typescript",
          clientFrameworks: "react",
          ...(fileKey && { file_key: fileKey })
        }
      });

      console.log("Design tokens result:", result);
      
      // Parse and structure the variables response
      return this.parseDesignTokens(result);
    } catch (error) {
      console.error("Error fetching design tokens:", error);
      throw error;
    }
  }

  async getAssets(frameUrl: string, options: CodeGenOptions = {}): Promise<any[]> {
    if (!this.isConnected) {
      throw new Error("Not connected to Figma MCP server");
    }

    try {
      console.log("Getting assets for:", frameUrl);
      
      // Extract node ID from URL if present
      let nodeId: string | undefined;
      const nodeIdMatch = frameUrl.match(/node-id=([^&]+)/);
      if (nodeIdMatch) {
        nodeId = nodeIdMatch[1].replace('%3A', ':');
      }

      const result = await this.client.callTool({
        name: "get_image",
        arguments: {
          clientName: "figma-mcp-generator",
          clientLanguages: this.getLanguageFromOptions(options),
          clientFrameworks: this.getFrameworkFromOptions(options),
          ...(nodeId && { nodeId: nodeId })
        }
      });

      console.log("Assets result:", result);
      
      return (result.assets as any[]) || [];
    } catch (error) {
      console.error("Error fetching assets:", error);
      throw error;
    }
  }

  async getHighlightedNode(nodeId: string): Promise<any> {
    if (!this.isConnected) {
      throw new Error("Not connected to Figma MCP server");
    }

    try {
      const result = await this.client.callTool({
        name: "highlight",
        arguments: {
          clientName: "figma-mcp-generator",
          clientLanguages: "javascript, typescript",
          clientFrameworks: "react",
          node_id: nodeId
        }
      });

      return result;
    } catch (error) {
      console.error("Error highlighting node:", error);
      throw error;
    }
  }

  private parseDesignTokens(variablesResponse: any): DesignTokens {
    const tokens: DesignTokens = {
      colors: [],
      spacing: [],
      typography: [],
      shadows: []
    };

    // Parse the response based on the actual structure from Figma MCP
    if (variablesResponse.variables) {
      Object.entries(variablesResponse.variables).forEach(([key, value]: [string, any]) => {
        if (value.type === 'COLOR') {
          tokens.colors.push({
            figmaId: key,
            name: value.name,
            value: value.value
          });
        } else if (value.type === 'FLOAT' && value.name.toLowerCase().includes('spacing')) {
          tokens.spacing.push({
            figmaId: key,
            name: value.name,
            value: value.value
          });
        }
      });
    }

    return tokens;
  }

  async getCodeConnectMap(url: string): Promise<any> {
    if (!this.isConnected) {
      throw new Error("Not connected to Figma MCP server");
    }

    try {
      console.log("Getting Code Connect map for:", url);
      
      // Extract node ID from URL if present
      let nodeId: string | undefined;
      const nodeIdMatch = url.match(/node-id=([^&]+)/);
      if (nodeIdMatch) {
        nodeId = nodeIdMatch[1].replace('%3A', ':');
      }

      const result = await this.client.callTool({
        name: "get_code_connect_map",
        arguments: {
          clientName: "figma-mcp-generator",
          clientLanguages: "javascript, typescript",
          clientFrameworks: "react",
          ...(nodeId && { nodeId: nodeId })
        }
      });

      console.log("Code Connect map result:", result);
      
      return result;
    } catch (error) {
      console.error("Error fetching Code Connect map:", error);
      throw error;
    }
  }

  async setCodegenConfig(config: any): Promise<any> {
    if (!this.isConnected) {
      throw new Error("Not connected to Figma MCP server");
    }

    try {
      console.log("Setting codegen config:", config);
      
      const result = await this.client.callTool({
        name: "set_codegen_config",
        arguments: {
          clientName: "figma-mcp-generator",
          clientLanguages: "javascript, typescript",
          clientFrameworks: "react",
          ...config
        }
      });

      console.log("Set codegen config result:", result);
      
      return result;
    } catch (error) {
      console.error("Error setting codegen config:", error);
      throw error;
    }
  }

  private getLanguageFromOptions(options: CodeGenOptions): string {
    // Return as comma-separated string like Figma expects
    if (options.format?.includes('tsx') || options.language === 'typescript') {
      return "javascript, typescript";
    } else if (options.format?.includes('jsx') || options.language === 'javascript') {
      return "javascript";
    } else if (options.format === 'html') {
      return "html, css";
    }
    return "javascript, typescript";
  }

  private getFrameworkFromOptions(options: CodeGenOptions): string {
    // Return lowercase as Figma expects
    if (options.format?.includes('react') || options.framework === 'react') {
      return "react";
    } else if (options.framework === 'vue') {
      return "vue";
    } else if (options.framework === 'angular') {
      return "angular";
    } else if (options.framework === 'html') {
      return "html";
    }

    // If format is specified, use that
    if (options.format === 'html') {
      return "html";
    } else if (options.format?.includes('react')) {
      return "react";
    } else if (options.format === 'vue') {
      return "vue";
    } else if (options.format === 'angular') {
      return "angular";
    }

    return "react";  // Default to react
  }

  isConnectionActive(): boolean {
    return this.isConnected;
  }
}