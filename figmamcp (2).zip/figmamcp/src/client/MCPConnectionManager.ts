import { FigmaMCPClient } from "./FigmaMCPClient";

export class MCPConnectionManager {
  private client: FigmaMCPClient;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private connectionHealthCheckInterval: NodeJS.Timeout | null = null;

  constructor(serverUrl?: string) {
    this.client = new FigmaMCPClient(serverUrl);
  }

  async connectWithRetry(): Promise<FigmaMCPClient> {
    try {
      await this.client.initialize();
      this.reconnectAttempts = 0;
      this.startHealthCheck();
      return this.client;
    } catch (error) {
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        console.log(`Connection failed, retrying in ${this.reconnectDelay}ms... (Attempt ${this.reconnectAttempts + 1}/${this.maxReconnectAttempts})`);
        this.reconnectAttempts++;
        await this.delay(this.reconnectDelay);
        this.reconnectDelay *= 2; // Exponential backoff
        return this.connectWithRetry();
      }
      throw new Error(`Failed to connect after ${this.maxReconnectAttempts} attempts: ${error}`);
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private startHealthCheck(): void {
    // Check connection health every 30 seconds
    this.connectionHealthCheckInterval = setInterval(async () => {
      try {
        if (!this.client.isConnectionActive()) {
          console.log("Connection lost, attempting to reconnect...");
          await this.reconnect();
        }
      } catch (error) {
        console.error("Health check failed:", error);
      }
    }, 30000);
  }

  private async reconnect(): Promise<void> {
    this.reconnectAttempts = 0;
    this.reconnectDelay = 1000;
    await this.connectWithRetry();
  }

  async disconnect(): Promise<void> {
    if (this.connectionHealthCheckInterval) {
      clearInterval(this.connectionHealthCheckInterval);
      this.connectionHealthCheckInterval = null;
    }
    await this.client.disconnect();
  }

  getClient(): FigmaMCPClient {
    return this.client;
  }
}