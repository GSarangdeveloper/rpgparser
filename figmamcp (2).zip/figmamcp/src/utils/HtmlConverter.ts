import { SimpleHtmlConverter } from './SimpleHtmlConverter';

export class HtmlConverter {
  /**
   * Convert JSX/React code to HTML + CSS
   */
  static async convertToHtml(jsxCode: string, componentName: string = 'Component'): Promise<{
    html: string;
    css: string;
    js: string;
    imageFiles?: Array<{ filename: string; url: string }>;
    analysisReport?: string;
  }> {
    // Extract image constants
    const imageMatches = jsxCode.match(/const img\w+ = "([^"]+)";/g) || [];
    const images: { [key: string]: string } = {};

    imageMatches.forEach(match => {
      const [, varName, url] = match.match(/const (img\w+) = "([^"]+)";/) || [];
      if (varName && url) {
        images[varName] = url;
      }
    });

    // Extract the JSX return statement
    const returnMatch = jsxCode.match(/return \(([\s\S]*?)\);/);
    if (!returnMatch) {
      throw new Error('Could not find JSX return statement');
    }

    let jsxContent = returnMatch[1].trim();

    // Convert JSX to HTML
    let html = this.convertJsxToHtml(jsxContent, images);

    // Create JavaScript for interactivity
    const js = this.createJavaScript(images);

    // Use simple converter for clean HTML/CSS
    const { html: simpleHtml, css: simpleCss, imageFiles } = SimpleHtmlConverter.convertToSimpleHtml(jsxCode, componentName);

    return {
      html: simpleHtml,
      css: simpleCss,
      js,
      imageFiles // Return image files to be saved separately
    };
  }

  private static convertJsxToHtml(jsx: string, images: { [key: string]: string }): string {
    let html = jsx;

    // Step 1: Replace image variables in src attributes
    Object.entries(images).forEach(([varName, url]) => {
      const regex = new RegExp(`\\{${varName}\\}`, 'g');
      html = html.replace(regex, `"${url}"`);
    });

    // Step 2: Handle complex style attributes with template literals
    html = html.replace(/style=\{\{([^}]+)\}\}/g, (_match, styleContent) => {
      try {
        // Handle backgroundImage with template literals specifically
        if (styleContent.includes('backgroundImage:')) {
          const bgMatch = styleContent.match(/backgroundImage:\s*`url\('([^']+)'\)`/);
          if (bgMatch) {
            const urlTemplate = bgMatch[1];
            // Replace ${varName} with actual URL
            const finalUrl = urlTemplate.replace(/\$\{([^}]+)\}/, (_: string, varName: string) => {
              return images[varName] || varName;
            });
            return `style="background-image: url('${finalUrl}')"`;
          }
        }

        // Handle other style properties
        const cssProps = styleContent
          .split(',')
          .map((prop: string) => {
            const [key, value] = prop.split(':').map((s: string) => s.trim());
            if (key && value) {
              const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
              let cleanValue = value.replace(/['"]/g, '').replace(/`/g, '');
              return `${cssKey}: ${cleanValue}`;
            }
            return '';
          })
          .filter(Boolean)
          .join('; ');

        return `style="${cssProps}"`;
      } catch (error) {
        console.warn('Failed to parse style attribute:', styleContent);
        return 'style=""';
      }
    });

    // Step 2.5: Handle simple style attributes with template literals (like the broken ones we're seeing)
    html = html.replace(/style=\{\{backgroundImage:\s*`url\('\$\{([^}]+)\}'\)`\}\}/g, (_match, varName) => {
      const imageUrl = images[varName] || varName;
      return `style="background-image: url('${imageUrl}')"`;
    });

    // Step 3: Replace JSX-specific attributes
    html = html.replace(/className=/g, 'class=');
    html = html.replace(/htmlFor=/g, 'for=');

    // Step 4: Remove JSX fragments
    html = html.replace(/<>\s*/g, '').replace(/\s*<\/>/g, '');

    // Step 5: Fix self-closing div tags (convert to proper closing tags)
    html = html.replace(/(<div[^>]*?)\/>/g, '$1></div>');

    // Step 6: Clean up other self-closing tags (keep them self-closing for HTML)
    html = html.replace(/(<img[^>]*?)\/>/g, '$1>');
    html = html.replace(/(<input[^>]*?)\/>/g, '$1>');
    html = html.replace(/(<br[^>]*?)\/>/g, '$1>');

    // Step 7: Fix any remaining template literal expressions
    html = html.replace(/\$\{([^}]+)\}/g, (match, varName) => {
      return images[varName] || match;
    });

    // Step 8: Fix malformed background-image URLs that might have been created
    html = html.replace(/style="background-image:\s*url\('\$"([^"]+)"\'\)"/g, (_match, url) => {
      return `style="background-image: url('${url}')"`;
    });

    // Step 9: Fix any other malformed URLs in style attributes
    html = html.replace(/url\('\$"([^"]+)"\'\)/g, (_match, url) => {
      return `url('${url}')`;
    });

    return html;
  }

  private static extractCssFromClasses(html: string): string {
    const tailwindClasses = new Set<string>();

    // Extract all class attributes
    const classMatches = html.match(/class="([^"]+)"/g) || [];

    classMatches.forEach(match => {
      const classes = match.match(/class="([^"]+)"/)?.[1]?.split(/\s+/) || [];
      classes.forEach(cls => {
        if (cls.trim()) {
          tailwindClasses.add(cls.trim());
        }
      });
    });

    // Convert Tailwind classes to CSS
    let css = '/* Generated CSS from Tailwind classes */\n\n';

    // Add basic resets and container setup
    css += `
* {
  box-sizing: border-box;
}

html, body {
  margin: 0;
  padding: 0;
  font-family: Inter, sans-serif;
  width: 100%;
  height: 100%;
  background-color: #ffffff;
}

[data-name="Shopping cart"] {
  width: 100vw;
  height: 100vh;
  min-height: 900px;
  min-width: 1200px;
  position: relative;
  background-color: #ffffff;
  overflow-x: auto;
  overflow-y: auto;
}

/* Fix transform utilities that might not be working */
.translate-y-\\[-50\\%\\] { transform: translateY(-50%) !important; }
.translate-x-\\[50\\%\\] { transform: translateX(50%) !important; }
.translate-x-\\[-50\\%\\] { transform: translateX(-50%) !important; }
.top-1\\/2 { top: 50% !important; }
.left-1\\/2 { left: 50% !important; }

/* Ensure leading-[0] doesn't break text */
.leading-\\[0\\] { line-height: 1.2 !important; }
`;

    // Generate CSS for each class
    Array.from(tailwindClasses).forEach(className => {
      const cssRule = this.convertTailwindClass(className);
      if (cssRule) {
        css += cssRule + '\n';
      }
    });

    // Add missing CSS for common positioning and transform utilities
    css += `
/* Additional positioning and transform utilities */
.top-1\\/2 { top: 50%; }
.left-1\\/2 { left: 50%; }
.translate-y-\\[-50\\%\\] { transform: translateY(-50%); }
.translate-x-\\[50\\%\\] { transform: translateX(50%); }
.translate-x-\\[-50\\%\\] { transform: translateX(-50%); }

/* Specific positioning values */
.left-\\[184px\\] { left: 184px; }
.left-\\[301px\\] { left: 301px; }
.top-\\[54px\\] { top: 54px; }
.top-\\[82px\\] { top: 82px; }
.top-\\[119px\\] { top: 119px; }
.top-\\[156px\\] { top: 156px; }
.top-\\[190px\\] { top: 190px; }
.top-\\[193px\\] { top: 193px; }
.top-\\[41px\\] { top: 41px; }
.bottom-\\[33px\\] { bottom: 33px; }
.bottom-\\[-1px\\] { bottom: -1px; }
.bottom-\\[-8px\\] { bottom: -8px; }
.left-\\[-0\\.321\\%\\] { left: -0.321%; }
.right-\\[-0\\.321\\%\\] { right: -0.321%; }
.top-\\[-2px\\] { top: -2px; }
.right-\\[523px\\] { right: 523px; }
.right-\\[676\\.5px\\] { right: 676.5px; }
.right-\\[570\\.5px\\] { right: 570.5px; }
.right-\\[439px\\] { right: 439px; }
.right-\\[308px\\] { right: 308px; }
.left-\\[949px\\] { left: 949px; }

/* Specific sizing values */
.h-\\[159px\\] { height: 159px; }
.h-\\[318px\\] { height: 318px; }
.h-\\[149px\\] { height: 149px; }
.w-\\[126px\\] { width: 126px; }
.h-\\[0\\] { height: 0; }

/* Border radius values */
.rounded-\\[20px\\] { border-radius: 20px; }

/* Aspect ratio */
.aspect-\\[160\\/160\\] { aspect-ratio: 160/160; }

/* Leading values */
.leading-\\[0\\] { line-height: 0; }
.leading-\\[1\\.3\\] { line-height: 1.3; }
.leading-\\[1\\.2\\] { line-height: 1.2; }

/* Font sizes */
.text-\\[16px\\] { font-size: 16px; }
.text-\\[20px\\] { font-size: 20px; }
.text-\\[32px\\] { font-size: 32px; }
.text-\\[64px\\] { font-size: 64px; }

/* Letter spacing */
.tracking-\\[-1\\.28px\\] { letter-spacing: -1.28px; }
.tracking-\\[-0\\.32px\\] { letter-spacing: -0.32px; }

/* Colors */
.bg-\\[\\#ffffff\\] { background-color: #ffffff; }
.bg-\\[\\#fafaf5\\] { background-color: #fafaf5; }
.bg-\\[\\#426b1f\\] { background-color: #426b1f; }
.text-\\[\\#000000\\] { color: #000000; }
.text-\\[\\#ffffff\\] { color: #ffffff; }
.text-\\[\\#426b1f\\] { color: #426b1f; }
.border-\\[\\#e6e6e6\\] { border-color: #e6e6e6; }
.border-\\[rgba\\(0\\,0\\,0\\,0\\.06\\)\\] { border-color: rgba(0,0,0,0.06); }

/* Font families - Fixed CSS selectors */
.font-\\[\\'Inter\\:Semi_Bold\\'\\,_sans-serif\\] { font-family: 'Inter', sans-serif !important; font-weight: 600 !important; }
.font-\\[\\'Inter\\:Bold\\'\\,_sans-serif\\] { font-family: 'Inter', sans-serif !important; font-weight: 700 !important; }
.font-\\[\\'Inter\\:Regular\\'\\,_sans-serif\\] { font-family: 'Inter', sans-serif !important; font-weight: 400 !important; }
.font-\\[\\'Inter\\:Light\\'\\,_sans-serif\\] { font-family: 'Inter', sans-serif !important; font-weight: 300 !important; }
.font-\\[\\'Newsreader\\:Regular\\'\\,_sans-serif\\] { font-family: 'Newsreader', serif !important; font-weight: 400 !important; }
.font-\\[\\'Newsreader\\:Medium\\'\\,_sans-serif\\] { font-family: 'Newsreader', serif !important; font-weight: 500 !important; }

/* Simplified font classes that actually work */
[class*="font-['Inter:Semi_Bold']"] { font-family: 'Inter', sans-serif !important; font-weight: 600 !important; }
[class*="font-['Inter:Bold']"] { font-family: 'Inter', sans-serif !important; font-weight: 700 !important; }
[class*="font-['Inter:Regular']"] { font-family: 'Inter', sans-serif !important; font-weight: 400 !important; }
[class*="font-['Inter:Light']"] { font-family: 'Inter', sans-serif !important; font-weight: 300 !important; }
[class*="font-['Newsreader:Regular']"] { font-family: 'Newsreader', serif !important; font-weight: 400 !important; }
[class*="font-['Newsreader:Medium']"] { font-family: 'Newsreader', serif !important; font-weight: 500 !important; }
`;

    return css;
  }

  private static convertTailwindClass(className: string): string {
    // Handle arbitrary value classes like bg-[#ffffff]
    if (className.includes('[') && className.includes(']')) {
      const match = className.match(/^([^[]+)\[([^\]]+)\]$/);
      if (match) {
        const [, prefix, value] = match;
        return this.convertArbitraryClass(prefix, value);
      }
    }

    // Handle standard Tailwind classes
    const conversions: { [key: string]: string } = {
      // Layout
      'relative': '.relative { position: relative; }',
      'absolute': '.absolute { position: absolute; }',
      'block': '.block { display: block; }',
      'flex': '.flex { display: flex; }',
      'hidden': '.hidden { display: none; }',
      'overflow-clip': '.overflow-clip { overflow: hidden; }',

      // Sizing
      'size-full': '.size-full { width: 100%; height: 100%; }',
      'w-full': '.w-full { width: 100%; }',
      'h-full': '.h-full { height: 100%; }',
      'w-32': '.w-32 { width: 8rem; }',
      'h-10': '.h-10 { height: 2.5rem; }',
      'h-12': '.h-12 { height: 3rem; }',
      'h-28': '.h-28 { height: 7rem; }',
      'size-8': '.size-8 { width: 2rem; height: 2rem; }',
      'max-w-none': '.max-w-none { max-width: none; }',

      // Spacing
      'top-0': '.top-0 { top: 0; }',
      'left-0': '.left-0 { left: 0; }',
      'right-0': '.right-0 { right: 0; }',
      'bottom-0': '.bottom-0 { bottom: 0; }',
      'top-6': '.top-6 { top: 1.5rem; }',
      'top-8': '.top-8 { top: 2rem; }',
      'top-14': '.top-14 { top: 3.5rem; }',
      'top-28': '.top-28 { top: 7rem; }',
      'bottom-4': '.bottom-4 { bottom: 1rem; }',
      'bottom-6': '.bottom-6 { bottom: 1.5rem; }',
      'left-4': '.left-4 { left: 1rem; }',
      'left-6': '.left-6 { left: 1.5rem; }',
      'left-24': '.left-24 { left: 6rem; }',
      'right-2': '.right-2 { right: 0.5rem; }',
      'right-4': '.right-4 { right: 1rem; }',
      'right-6': '.right-6 { right: 1.5rem; }',
      'right-24': '.right-24 { right: 6rem; }',

      // Border radius
      'rounded': '.rounded { border-radius: 0.25rem; }',
      'rounded-lg': '.rounded-lg { border-radius: 0.5rem; }',
      'rounded-3xl': '.rounded-3xl { border-radius: 1.5rem; }',

      // Borders
      'border-2': '.border-2 { border-width: 2px; }',
      'border-solid': '.border-solid { border-style: solid; }',

      // Background
      'bg-center': '.bg-center { background-position: center; }',
      'bg-cover': '.bg-cover { background-size: cover; }',
      'bg-no-repeat': '.bg-no-repeat { background-repeat: no-repeat; }',

      // Text
      'text-left': '.text-left { text-align: left; }',
      'text-center': '.text-center { text-align: center; }',
      'text-right': '.text-right { text-align: right; }',
      'text-nowrap': '.text-nowrap { white-space: nowrap; }',
      'font-semibold': '.font-semibold { font-weight: 600; }',
      'font-bold': '.font-bold { font-weight: 700; }',
      'font-light': '.font-light { font-weight: 300; }',
      'font-medium': '.font-medium { font-weight: 500; }',
      'font-normal': '.font-normal { font-weight: 400; }',
      'leading-none': '.leading-none { line-height: 1; }',
      'not-italic': '.not-italic { font-style: normal; }',

      // Flexbox
      'flex-col': '.flex-col { flex-direction: column; }',
      'justify-center': '.justify-center { justify-content: center; }',
      'justify-end': '.justify-end { justify-content: flex-end; }',
      'items-center': '.items-center { align-items: center; }',

      // Positioning
      'inset-0': '.inset-0 { top: 0; right: 0; bottom: 0; left: 0; }',
      'top-1\\/2': '.top-1\\/2 { top: 50%; }',
      'left-1\\/2': '.left-1\\/2 { left: 50%; }',

      // Transform
      'translate-x-\\[50\\%\\]': '.translate-x-\\[50\\%\\] { transform: translateX(50%); }',
      'translate-y-\\[-50\\%\\]': '.translate-y-\\[-50\\%\\] { transform: translateY(-50%); }',
      'translate-x-\\[-50\\%\\]': '.translate-x-\\[-50\\%\\] { transform: translateX(-50%); }',

      // Misc
      'pointer-events-none': '.pointer-events-none { pointer-events: none; }',
      'cursor-pointer': '.cursor-pointer { cursor: pointer; }',
      'whitespace-pre': '.whitespace-pre { white-space: pre; }',
      'adjustLetterSpacing': '.adjustLetterSpacing { letter-spacing: inherit; }'
    };

    return conversions[className] || '';
  }

  private static convertArbitraryClass(prefix: string, value: string): string {
    const cleanValue = value.replace(/['"]/g, '');

    switch (prefix) {
      case 'bg':
        return `.bg-\\[${value}\\] { background-color: ${cleanValue}; }`;
      case 'text':
        if (cleanValue.startsWith('#')) {
          return `.text-\\[${value}\\] { color: ${cleanValue}; }`;
        } else if (cleanValue.endsWith('px')) {
          return `.text-\\[${value}\\] { font-size: ${cleanValue}; }`;
        }
        break;
      case 'border':
        return `.border-\\[${value}\\] { border-color: ${cleanValue}; }`;
      case 'h':
        return `.h-\\[${value}\\] { height: ${cleanValue}; }`;
      case 'w':
        return `.w-\\[${value}\\] { width: ${cleanValue}; }`;
      case 'top':
        return `.top-\\[${value}\\] { top: ${cleanValue}; }`;
      case 'left':
        return `.left-\\[${value}\\] { left: ${cleanValue}; }`;
      case 'right':
        return `.right-\\[${value}\\] { right: ${cleanValue}; }`;
      case 'bottom':
        return `.bottom-\\[${value}\\] { bottom: ${cleanValue}; }`;
      case 'font':
        return `.font-\\[${value}\\] { font-family: ${cleanValue}; }`;
      case 'leading':
        return `.leading-\\[${value}\\] { line-height: ${cleanValue}; }`;
      case 'tracking':
        return `.tracking-\\[${value}\\] { letter-spacing: ${cleanValue}; }`;
      case 'aspect':
        const [w, h] = cleanValue.split('/');
        if (w && h) {
          return `.aspect-\\[${value}\\] { aspect-ratio: ${w}/${h}; }`;
        }
        break;
    }

    return '';
  }

  private static createJavaScript(images: { [key: string]: string }): string {
    let js = '// Generated JavaScript\n\n';
    
    // Add image constants
    if (Object.keys(images).length > 0) {
      js += '// Image assets\n';
      Object.entries(images).forEach(([varName, url]) => {
        js += `const ${varName} = "${url}";\n`;
      });
      js += '\n';
    }

    // Add basic interactivity
    js += `
// Basic interactivity
document.addEventListener('DOMContentLoaded', function() {
  // Add click handlers for buttons
  const buttons = document.querySelectorAll('button, [role="button"]');
  buttons.forEach(button => {
    button.addEventListener('click', function(e) {
      console.log('Button clicked:', e.target);
    });
  });

  // Add hover effects
  const hoverElements = document.querySelectorAll('[class*="hover:"]');
  hoverElements.forEach(element => {
    element.addEventListener('mouseenter', function() {
      this.classList.add('hovered');
    });
    element.addEventListener('mouseleave', function() {
      this.classList.remove('hovered');
    });
  });
});
`;

    return js;
  }

  private static async processImagesForSeparateFolder(html: string, css: string, images: { [key: string]: string }): Promise<{ html: string; css: string; imageFiles: Array<{ filename: string; url: string }> }> {
    const imageFiles: Array<{ filename: string; url: string }> = [];
    let updatedHtml = html;
    let updatedCss = css;

    // Process each image
    Object.entries(images).forEach(([_varName, url], index) => {
      // Create a simple filename from the URL
      const urlParts = url.split('/');
      const originalFilename = urlParts[urlParts.length - 1];
      const extension = originalFilename.includes('.') ? originalFilename.split('.').pop() : 'png';
      const filename = `image-${index + 1}.${extension}`;

      // Store image info for separate saving
      imageFiles.push({ filename, url });

      // Replace URLs in HTML and CSS with relative paths
      const relativePath = `./images/${filename}`;

      // Replace in HTML src attributes
      updatedHtml = updatedHtml.replace(
        new RegExp(`src="${url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"`, 'g'),
        `src="${relativePath}"`
      );

      // Replace in HTML style attributes
      updatedHtml = updatedHtml.replace(
        new RegExp(`url\\('${url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}'\\)`, 'g'),
        `url('${relativePath}')`
      );

      // Replace in CSS
      updatedCss = updatedCss.replace(
        new RegExp(`url\\('${url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}'\\)`, 'g'),
        `url('${relativePath}')`
      );
    });

    return { html: updatedHtml, css: updatedCss, imageFiles };
  }

  private static wrapInHtmlStructure(content: string, componentName: string): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${componentName}</title>
    <link rel="stylesheet" href="${componentName}.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Newsreader:wght@400;500&display=swap" rel="stylesheet">
    <style>
        /* Ensure proper sizing for the component */
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow-x: auto;
        }

        /* Fix for the main container */
        [data-name="Shopping cart"] {
            min-width: 1200px;
            min-height: 900px;
            position: relative;
            background: #ffffff;
        }
    </style>
</head>
<body>
    ${content}
    <script src="${componentName}.js"></script>
</body>
</html>`;
  }
}
