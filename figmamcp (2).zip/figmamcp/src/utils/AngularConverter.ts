export class AngularConverter {
  /**
   * Convert JSX/React code to Angular component
   */
  static convertToAngular(jsxCode: string, componentName: string = 'Component'): { 
    component: string; 
    template: string; 
    styles: string; 
    module?: string 
  } {
    // Extract image constants
    const imageMatches = jsxCode.match(/const img\w+ = "([^"]+)";/g) || [];
    const images: { [key: string]: string } = {};
    
    imageMatches.forEach(match => {
      const [, varName, url] = match.match(/const (img\w+) = "([^"]+)";/) || [];
      if (varName && url) {
        images[varName] = url;
      }
    });

    // Extract the JSX return statement
    const returnMatch = jsxCode.match(/return \(([\s\S]*?)\);/);
    if (!returnMatch) {
      throw new Error('Could not find JSX return statement');
    }

    let jsxContent = returnMatch[1].trim();

    // Convert JSX to Angular template
    const template = this.convertJsxToAngularTemplate(jsxContent, images);
    
    // Generate Angular component
    const component = this.generateAngularComponent(componentName, images);
    
    // Generate styles
    const styles = this.generateAngularStyles(template);

    return { component, template, styles };
  }

  private static convertJsxToAngularTemplate(jsx: string, images: { [key: string]: string }): string {
    let template = jsx;

    // Step 1: Replace image variables in src attributes
    Object.entries(images).forEach(([varName, url]) => {
      const regex = new RegExp(`\\{${varName}\\}`, 'g');
      template = template.replace(regex, `"${url}"`);
    });

    // Step 2: Handle style attributes with template literals
    template = template.replace(/style=\{\{([^}]+)\}\}/g, (_match, styleContent) => {
      try {
        // Handle backgroundImage with template literals specifically
        if (styleContent.includes('backgroundImage:')) {
          const bgMatch = styleContent.match(/backgroundImage:\s*`url\('([^']+)'\)`/);
          if (bgMatch) {
            const urlTemplate = bgMatch[1];
            // Replace ${varName} with actual URL
            const finalUrl = urlTemplate.replace(/\$\{([^}]+)\}/, (_: string, varName: string) => {
              return images[varName] || varName;
            });
            return `[style.background-image]="'url(${finalUrl})')"`;
          }
        }
        
        // Handle other style properties - convert to Angular style binding
        const cssProps = styleContent
          .split(',')
          .map((prop: string) => {
            const [key, value] = prop.split(':').map((s: string) => s.trim());
            if (key && value) {
              const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
              let cleanValue = value.replace(/['"]/g, '').replace(/`/g, '');
              return `[style.${cssKey}]="'${cleanValue}'"`;
            }
            return '';
          })
          .filter(Boolean)
          .join(' ');
        
        return cssProps;
      } catch (error) {
        console.warn('Failed to parse style attribute:', styleContent);
        return '';
      }
    });

    // Step 3: Convert JSX attributes to Angular
    template = template.replace(/className=/g, 'class=');
    template = template.replace(/htmlFor=/g, 'for=');

    // Step 4: Remove JSX fragments
    template = template.replace(/<>\s*/g, '').replace(/\s*<\/>/g, '');

    // Step 5: Fix self-closing div tags
    template = template.replace(/(<div[^>]*?)\/>/g, '$1></div>');
    
    // Step 6: Handle other self-closing tags
    template = template.replace(/(<img[^>]*?)\/>/g, '$1>');
    template = template.replace(/(<input[^>]*?)\/>/g, '$1>');
    template = template.replace(/(<br[^>]*?)\/>/g, '$1>');

    // Step 7: Fix any remaining template literal expressions
    template = template.replace(/\$\{([^}]+)\}/g, (match, varName) => {
      return images[varName] || match;
    });

    // Step 8: Convert event handlers (if any)
    template = template.replace(/onClick=/g, '(click)=');
    template = template.replace(/onChange=/g, '(change)=');
    template = template.replace(/onSubmit=/g, '(submit)=');

    return template;
  }

  private static generateAngularComponent(componentName: string, images: { [key: string]: string }): string {
    const className = this.toPascalCase(componentName);
    const selector = this.toKebabCase(componentName);

    // Generate image properties
    const imageProperties = Object.entries(images)
      .map(([varName, url]) => `  ${varName} = '${url}';`)
      .join('\n');

    return `import { Component } from '@angular/core';

@Component({
  selector: 'app-${selector}',
  templateUrl: './${selector}.component.html',
  styleUrls: ['./${selector}.component.css']
})
export class ${className}Component {
${imageProperties}

  constructor() { }

  // Add your component logic here
  onClick(event: Event) {
    console.log('Button clicked:', event);
  }

  onChange(event: Event) {
    console.log('Input changed:', event);
  }
}`;
  }

  private static generateAngularStyles(template: string): string {
    const tailwindClasses = new Set<string>();
    
    // Extract all class attributes
    const classMatches = template.match(/class="([^"]+)"/g) || [];
    
    classMatches.forEach(match => {
      const classes = match.match(/class="([^"]+)"/)?.[1]?.split(/\s+/) || [];
      classes.forEach(cls => {
        if (cls.trim()) {
          tailwindClasses.add(cls.trim());
        }
      });
    });

    let css = '/* Angular Component Styles */\n\n';
    
    // Add basic resets and container setup
    css += `
:host {
  display: block;
  width: 100%;
  height: 100%;
}

.component-container {
  width: 100vw;
  height: 100vh;
  min-height: 900px;
  min-width: 1200px;
  position: relative;
  background-color: #ffffff;
}

/* Layout utilities */
.relative { position: relative; }
.absolute { position: absolute; }
.block { display: block; }
.flex { display: flex; }
.flex-col { flex-direction: column; }
.justify-center { justify-content: center; }
.justify-end { justify-content: flex-end; }
.items-center { align-items: center; }

/* Sizing */
.size-full { width: 100%; height: 100%; }
.w-32 { width: 8rem; }
.h-10 { height: 2.5rem; }
.h-12 { height: 3rem; }
.h-28 { height: 7rem; }
.size-8 { width: 2rem; height: 2rem; }

/* Spacing */
.top-6 { top: 1.5rem; }
.top-8 { top: 2rem; }
.top-14 { top: 3.5rem; }
.top-28 { top: 7rem; }
.bottom-4 { bottom: 1rem; }
.bottom-6 { bottom: 1.5rem; }
.left-4 { left: 1rem; }
.left-6 { left: 1.5rem; }
.left-24 { left: 6rem; }
.right-2 { right: 0.5rem; }
.right-4 { right: 1rem; }
.right-6 { right: 1.5rem; }
.right-24 { right: 6rem; }
.inset-0 { top: 0; right: 0; bottom: 0; left: 0; }

/* Colors and backgrounds */
.bg-white { background-color: #ffffff; }
.text-black { color: #000000; }
.text-white { color: #ffffff; }

/* Borders and radius */
.border-2 { border-width: 2px; }
.border-solid { border-style: solid; }
.rounded { border-radius: 0.25rem; }
.rounded-lg { border-radius: 0.5rem; }
.rounded-3xl { border-radius: 1.5rem; }

/* Text */
.text-left { text-align: left; }
.text-center { text-align: center; }
.text-right { text-align: right; }
.text-nowrap { white-space: nowrap; }
.font-light { font-weight: 300; }
.font-normal { font-weight: 400; }
.font-medium { font-weight: 500; }
.font-semibold { font-weight: 600; }
.font-bold { font-weight: 700; }

/* Misc */
.overflow-hidden { overflow: hidden; }
.pointer-events-none { pointer-events: none; }
.max-w-none { max-width: none; }
`;

    // Generate CSS for Tailwind arbitrary values
    Array.from(tailwindClasses).forEach(className => {
      if (className.includes('[') && className.includes(']')) {
        const match = className.match(/^([^[]+)\[([^\]]+)\]$/);
        if (match) {
          const [, prefix, value] = match;
          const cssRule = this.convertArbitraryClass(prefix, value);
          if (cssRule) {
            css += cssRule + '\n';
          }
        }
      }
    });

    return css;
  }

  private static convertArbitraryClass(prefix: string, value: string): string {
    const cleanValue = value.replace(/['"]/g, '');
    
    switch (prefix) {
      case 'bg':
        return `.bg-\\[${value}\\] { background-color: ${cleanValue}; }`;
      case 'text':
        if (cleanValue.startsWith('#')) {
          return `.text-\\[${value}\\] { color: ${cleanValue}; }`;
        } else if (cleanValue.endsWith('px')) {
          return `.text-\\[${value}\\] { font-size: ${cleanValue}; }`;
        }
        break;
      case 'h':
        return `.h-\\[${value}\\] { height: ${cleanValue}; }`;
      case 'w':
        return `.w-\\[${value}\\] { width: ${cleanValue}; }`;
      case 'top':
        return `.top-\\[${value}\\] { top: ${cleanValue}; }`;
      case 'left':
        return `.left-\\[${value}\\] { left: ${cleanValue}; }`;
      case 'right':
        return `.right-\\[${value}\\] { right: ${cleanValue}; }`;
      case 'bottom':
        return `.bottom-\\[${value}\\] { bottom: ${cleanValue}; }`;
    }
    
    return '';
  }

  private static toPascalCase(str: string): string {
    return str.replace(/(?:^|[-_])(\w)/g, (_, char) => char.toUpperCase());
  }

  private static toKebabCase(str: string): string {
    return str.replace(/([A-Z])/g, '-$1').toLowerCase().replace(/^-/, '');
  }
}
