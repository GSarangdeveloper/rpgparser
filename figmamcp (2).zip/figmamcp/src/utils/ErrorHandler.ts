export class MCPError extends Error {
  constructor(
    message: string,
    public code: string,
    public details?: any
  ) {
    super(message);
    this.name = 'MCPError';
  }
}

export class GenerationError extends Error {
  constructor(
    message: string,
    public componentName: string,
    public figmaUrl: string,
    public isRetryable: boolean = false,
    public context?: any
  ) {
    super(message);
    this.name = 'GenerationError';
  }
}

export class ErrorHandler {
  private static errorCallbacks: ((error: Error) => void)[] = [];

  static registerErrorCallback(callback: (error: Error) => void): void {
    this.errorCallbacks.push(callback);
  }

  static async handleMCPError(error: any): Promise<void> {
    let mcpError: MCPError;
    
    if (error.code === 'ECONNREFUSED') {
      mcpError = new MCPError(
        'Cannot connect to Figma MCP server. Make sure Figma desktop app is running with Dev Mode enabled.',
        'CONNECTION_REFUSED',
        { originalError: error }
      );
    } else if (error.code === 'ETIMEDOUT') {
      mcpError = new MCPError(
        'Connection to Figma MCP server timed out.',
        'CONNECTION_TIMEOUT',
        { originalError: error }
      );
    } else if (error.message?.includes('CONNECTION_LOST')) {
      mcpError = new MCPError(
        'Lost connection to Figma MCP server.',
        'CONNECTION_LOST',
        { originalError: error }
      );
    } else {
      mcpError = new MCPError(
        error.message || 'Unknown MCP error',
        'UNKNOWN_ERROR',
        { originalError: error }
      );
    }

    this.notifyCallbacks(mcpError);
    throw mcpError;
  }

  static async handleGenerationError(
    error: any,
    componentName: string,
    figmaUrl: string
  ): Promise<void> {
    const generationError = new GenerationError(
      error.message || 'Code generation failed',
      componentName,
      figmaUrl,
      this.isRetryableError(error),
      { originalError: error }
    );

    this.notifyCallbacks(generationError);
    throw generationError;
  }

  private static isRetryableError(error: any): boolean {
    const retryableCodes = ['ETIMEDOUT', 'ECONNRESET', 'CONNECTION_LOST'];
    return retryableCodes.includes(error.code);
  }

  private static notifyCallbacks(error: Error): void {
    this.errorCallbacks.forEach(callback => {
      try {
        callback(error);
      } catch (e) {
        console.error('Error in error callback:', e);
      }
    });
  }
}