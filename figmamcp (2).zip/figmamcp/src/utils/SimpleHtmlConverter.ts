export class SimpleHtmlConverter {
  /**
   * Convert JSX to simple, clean HTML and CSS
   */
  static convertToSimpleHtml(jsxCode: string, componentName: string = 'Component'): { 
    html: string; 
    css: string; 
    imageFiles: Array<{ filename: string; url: string }>; 
  } {
    console.log('🔄 Converting to simple HTML/CSS...');
    
    // Extract image constants
    const imageMatches = jsxCode.match(/const img\w+ = "([^"]+)";/g) || [];
    const imageFiles: Array<{ filename: string; url: string }> = [];
    
    imageMatches.forEach((match, index) => {
      const urlMatch = match.match(/const img\w+ = "([^"]+)";/);
      if (urlMatch && urlMatch[1]) {
        const url = urlMatch[1];
        const extension = url.includes('.svg') ? 'svg' : 'png';
        imageFiles.push({
          filename: `image-${index + 1}.${extension}`,
          url: url
        });
      }
    });

    // Extract JSX return content
    const returnMatch = jsxCode.match(/return \(([\s\S]*?)\);/);
    if (!returnMatch) {
      throw new Error('Could not extract JSX return content');
    }

    let html = returnMatch[1].trim();
    
    // Simple JSX to HTML conversion
    html = html.replace(/className=/g, 'class=');
    html = html.replace(/htmlFor=/g, 'for=');
    html = html.replace(/<>\s*/g, '').replace(/\s*<\/>/g, '');
    
    // Replace image variables with simple relative paths
    imageFiles.forEach((img) => {
      const varPattern = new RegExp(`\\{img\\w+\\}`, 'g');
      html = html.replace(varPattern, `"./images/${img.filename}"`);
    });

    // Fix style attributes
    html = html.replace(/style=\{\{([^}]+)\}\}/g, (_match, styleContent) => {
      const cssProps = styleContent
        .split(',')
        .map((prop: string) => {
          const [key, value] = prop.split(':').map((s: string) => s.trim());
          if (key && value) {
            const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
            const cleanValue = value.replace(/['"]/g, '').replace(/`/g, '');
            return `${cssKey}: ${cleanValue}`;
          }
          return '';
        })
        .filter(Boolean)
        .join('; ');

      return `style="${cssProps}"`;
    });

    // Generate simple CSS
    const css = this.generateSimpleCSS(componentName);
    
    // Wrap in simple HTML structure
    const fullHtml = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${componentName}</title>
    <link rel="stylesheet" href="${componentName}.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Newsreader:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
    ${html}
</body>
</html>`;

    return { html: fullHtml, css, imageFiles };
  }

  private static generateSimpleCSS(componentName: string): string {
    return `/* Simple CSS for ${componentName} */

/* Reset and base styles */
* {
  box-sizing: border-box;
}

html, body {
  margin: 0;
  padding: 0;
  font-family: Inter, sans-serif;
  background-color: #ffffff;
}

/* Main container */
[data-name="Shopping cart"] {
  width: 100vw;
  height: 100vh;
  min-width: 1200px;
  min-height: 900px;
  position: relative;
  background-color: #ffffff;
  overflow: auto;
}

/* Layout utilities */
.relative { position: relative; }
.absolute { position: absolute; }
.block { display: block; }
.flex { display: flex; }
.flex-col { flex-direction: column; }

/* Sizing */
.size-full { width: 100%; height: 100%; }

/* Typography */
.font-semibold { font-weight: 600; }
.font-bold { font-weight: 700; }
.font-normal { font-weight: 400; }
.font-light { font-weight: 300; }
.font-medium { font-weight: 500; }

.text-left { text-align: left; }
.text-center { text-align: center; }
.text-right { text-align: right; }

.text-nowrap { white-space: nowrap; }
.whitespace-pre { white-space: pre; }

/* Colors */
.bg-\\[\\#ffffff\\] { background-color: #ffffff; }
.bg-\\[\\#fafaf5\\] { background-color: #fafaf5; }
.bg-\\[\\#426b1f\\] { background-color: #426b1f; }

.text-\\[\\#000000\\] { color: #000000; }
.text-\\[\\#ffffff\\] { color: #ffffff; }
.text-\\[\\#426b1f\\] { color: #426b1f; }

/* Borders */
.border-2 { border-width: 2px; }
.border-solid { border-style: solid; }
.border-\\[\\#e6e6e6\\] { border-color: #e6e6e6; }

/* Border radius */
.rounded { border-radius: 0.25rem; }
.rounded-lg { border-radius: 0.5rem; }
.rounded-3xl { border-radius: 1.5rem; }

/* Spacing - only common values */
.top-0 { top: 0; }
.left-0 { left: 0; }
.right-0 { right: 0; }
.bottom-0 { bottom: 0; }

.top-6 { top: 1.5rem; }
.left-6 { left: 1.5rem; }
.right-6 { right: 1.5rem; }
.bottom-6 { bottom: 1.5rem; }

.top-24 { top: 6rem; }
.left-24 { left: 6rem; }
.right-24 { right: 6rem; }
.bottom-24 { bottom: 6rem; }

/* Centering */
.top-1\\/2 { top: 50%; }
.left-1\\/2 { left: 50%; }
.translate-y-\\[-50\\%\\] { transform: translateY(-50%); }
.translate-x-\\[-50\\%\\] { transform: translateX(-50%); }

/* Images */
img {
  max-width: 100%;
  height: auto;
}

/* Background images */
[style*="background-image"] {
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

/* Responsive */
@media (max-width: 1200px) {
  [data-name="Shopping cart"] {
    min-width: 100%;
    overflow-x: auto;
  }
}`;
  }
}
