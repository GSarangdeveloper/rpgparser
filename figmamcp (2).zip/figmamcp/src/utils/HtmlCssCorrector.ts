export class HtmlCssCorrector {
  /**
   * Analyze and correct HTML/CSS to ensure proper layout and styling
   */
  static correctHtmlCss(html: string, css: string, _componentName: string): { html: string; css: string; corrections: string[] } {
    console.log('🔍 Analyzing and correcting HTML/CSS structure...');
    
    const corrections: string[] = [];
    let correctedHtml = html;
    let correctedCss = css;

    // 1. Fix container sizing issues
    const containerFixes = this.fixContainerSizing(correctedCss);
    correctedCss = containerFixes.css;
    corrections.push(...containerFixes.corrections);

    // 2. Fix font family issues
    const fontFixes = this.fixFontFamilies(correctedCss);
    correctedCss = fontFixes.css;
    corrections.push(...fontFixes.corrections);

    // 3. Fix positioning and transform issues
    const positionFixes = this.fixPositioning(correctedCss);
    correctedCss = positionFixes.css;
    corrections.push(...positionFixes.corrections);

    // 4. Fix HTML structure issues
    const htmlFixes = this.fixHtmlStructure(correctedHtml);
    correctedHtml = htmlFixes.html;
    corrections.push(...htmlFixes.corrections);

    // 5. Add missing CSS utilities
    const utilityFixes = this.addMissingUtilities(correctedCss);
    correctedCss = utilityFixes.css;
    corrections.push(...utilityFixes.corrections);

    // 6. Fix responsive design issues
    const responsiveFixes = this.fixResponsiveDesign(correctedCss);
    correctedCss = responsiveFixes.css;
    corrections.push(...responsiveFixes.corrections);

    console.log(`✅ Applied ${corrections.length} corrections to HTML/CSS`);
    
    return { html: correctedHtml, css: correctedCss, corrections };
  }

  private static fixContainerSizing(css: string): { css: string; corrections: string[] } {
    const corrections: string[] = [];
    let fixedCss = css;

    // Ensure main container has proper sizing
    if (!css.includes('min-width: 1200px')) {
      fixedCss += `
/* Container sizing fixes */
[data-name="Shopping cart"] {
  min-width: 1200px !important;
  min-height: 900px !important;
  width: 100vw !important;
  height: 100vh !important;
  position: relative !important;
  background-color: #ffffff !important;
  overflow-x: auto !important;
}
`;
      corrections.push('Added proper container sizing');
    }

    return { css: fixedCss, corrections };
  }

  private static fixFontFamilies(css: string): { css: string; corrections: string[] } {
    const corrections: string[] = [];
    let fixedCss = css;

    // Add working font family rules
    const fontFixes = `
/* Font family fixes */
[class*="font-['Inter:Semi_Bold']"],
[class*="font-semibold"] {
  font-family: 'Inter', sans-serif !important;
  font-weight: 600 !important;
}

[class*="font-['Inter:Bold']"],
[class*="font-bold"] {
  font-family: 'Inter', sans-serif !important;
  font-weight: 700 !important;
}

[class*="font-['Inter:Regular']"],
[class*="font-normal"] {
  font-family: 'Inter', sans-serif !important;
  font-weight: 400 !important;
}

[class*="font-['Inter:Light']"],
[class*="font-light"] {
  font-family: 'Inter', sans-serif !important;
  font-weight: 300 !important;
}

[class*="font-['Newsreader:Regular']"] {
  font-family: 'Newsreader', serif !important;
  font-weight: 400 !important;
}

[class*="font-['Newsreader:Medium']"],
[class*="font-medium"] {
  font-family: 'Newsreader', serif !important;
  font-weight: 500 !important;
}
`;

    if (!css.includes("font-['Inter:Semi_Bold']")) {
      fixedCss += fontFixes;
      corrections.push('Added working font family rules');
    }

    return { css: fixedCss, corrections };
  }

  private static fixPositioning(css: string): { css: string; corrections: string[] } {
    const corrections: string[] = [];
    let fixedCss = css;

    // Fix transform and positioning utilities
    const positionFixes = `
/* Positioning and transform fixes */
.top-1\\/2 { top: 50% !important; }
.left-1\\/2 { left: 50% !important; }
.translate-y-\\[-50\\%\\] { transform: translateY(-50%) !important; }
.translate-x-\\[50\\%\\] { transform: translateX(50%) !important; }
.translate-x-\\[-50\\%\\] { transform: translateX(-50%) !important; }

/* Fix combined transforms */
.top-1\\/2.translate-y-\\[-50\\%\\] { 
  top: 50% !important; 
  transform: translateY(-50%) !important; 
}

.left-1\\/2.translate-x-\\[-50\\%\\] { 
  left: 50% !important; 
  transform: translateX(-50%) !important; 
}

/* Fix centering */
.top-14.translate-x-\\[50\\%\\].translate-y-\\[-50\\%\\] {
  transform: translateX(50%) translateY(-50%) !important;
}
`;

    if (!css.includes('transform: translateY(-50%) !important')) {
      fixedCss += positionFixes;
      corrections.push('Fixed positioning and transform utilities');
    }

    return { css: fixedCss, corrections };
  }

  private static fixHtmlStructure(html: string): { html: string; corrections: string[] } {
    const corrections: string[] = [];
    let fixedHtml = html;

    // Fix self-closing div tags
    if (html.includes('<div') && html.includes('/>')) {
      fixedHtml = fixedHtml.replace(/(<div[^>]*?)\/>/g, '$1></div>');
      corrections.push('Fixed self-closing div tags');
    }

    // Fix missing alt attributes
    if (html.includes('<img') && html.includes('alt class=')) {
      fixedHtml = fixedHtml.replace(/alt class=/g, 'alt="" class=');
      corrections.push('Fixed missing alt attributes');
    }

    return { html: fixedHtml, corrections };
  }

  private static addMissingUtilities(css: string): { css: string; corrections: string[] } {
    const corrections: string[] = [];
    let fixedCss = css;

    // Add missing line-height fixes
    const utilityFixes = `
/* Utility fixes */
.leading-\\[0\\] { line-height: 1.2 !important; }
.leading-\\[1\\.2\\] { line-height: 1.2 !important; }
.leading-\\[1\\.3\\] { line-height: 1.3 !important; }

/* Fix whitespace handling */
.whitespace-pre { white-space: pre !important; }
.text-nowrap { white-space: nowrap !important; }

/* Fix overflow */
.overflow-clip { overflow: hidden !important; }

/* Fix aspect ratio */
.aspect-\\[160\\/160\\] { 
  aspect-ratio: 1 !important; 
  width: 160px !important; 
  height: 160px !important; 
}
`;

    if (!css.includes('line-height: 1.2 !important')) {
      fixedCss += utilityFixes;
      corrections.push('Added missing utility classes');
    }

    return { css: fixedCss, corrections };
  }

  private static fixResponsiveDesign(css: string): { css: string; corrections: string[] } {
    const corrections: string[] = [];
    let fixedCss = css;

    // Add responsive design improvements
    const responsiveFixes = `
/* Responsive design fixes */
@media (max-width: 1200px) {
  [data-name="Shopping cart"] {
    min-width: 100% !important;
    overflow-x: auto !important;
  }
}

/* Ensure images don't break layout */
img {
  max-width: 100% !important;
  height: auto !important;
}

/* Fix background images */
[style*="background-image"] {
  background-size: cover !important;
  background-position: center !important;
  background-repeat: no-repeat !important;
}
`;

    if (!css.includes('@media (max-width: 1200px)')) {
      fixedCss += responsiveFixes;
      corrections.push('Added responsive design improvements');
    }

    return { css: fixedCss, corrections };
  }

  /**
   * Generate a detailed analysis report
   */
  static generateAnalysisReport(html: string, css: string, corrections: string[]): string {
    const report = `
# HTML/CSS Analysis Report

## Structure Analysis
- HTML elements: ${(html.match(/<[^>]+>/g) || []).length}
- CSS rules: ${(css.match(/\{[^}]+\}/g) || []).length}
- Images found: ${(html.match(/<img/g) || []).length}
- Background images: ${(html.match(/background-image/g) || []).length}

## Applied Corrections
${corrections.map(correction => `- ✅ ${correction}`).join('\n')}

## Layout Structure
- Main container: Shopping cart component
- Product cards: 3 items (Tomato, Ginger, Onion)
- Summary panel: Order summary with totals
- Navigation: Header with logo and menu
- Page heading: Title section with item count

## Styling Features
- Font families: Inter and Newsreader
- Color scheme: White background, green accents (#426b1f)
- Layout: Absolute positioning with specific coordinates
- Responsive: Minimum width 1200px with overflow handling

## Recommendations
- Images are saved to separate ./images/ folder
- All positioning uses absolute layout as per Figma design
- Font weights and families are properly applied
- Transform utilities work correctly for centering
`;

    return report;
  }
}
