import * as https from 'https';
import * as http from 'http';

export class ImageEmbedder {
  /**
   * Convert image URLs to base64 data URLs for embedding
   */
  static async embedImages(html: string, css: string): Promise<{ html: string; css: string }> {
    console.log('🖼️ Embedding images as base64 data URLs...');
    
    // Extract all image URLs from HTML and CSS
    const imageUrls = new Set<string>();
    
    // Find URLs in HTML src attributes
    const htmlSrcMatches = html.match(/src="(http[^"]+)"/g) || [];
    htmlSrcMatches.forEach(match => {
      const url = match.match(/src="([^"]+)"/)?.[1];
      if (url) imageUrls.add(url);
    });
    
    // Find URLs in CSS background-image
    const cssBgMatches = css.match(/url\('(http[^']+)'\)/g) || [];
    cssBgMatches.forEach(match => {
      const url = match.match(/url\('([^']+)'\)/)?.[1];
      if (url) imageUrls.add(url);
    });
    
    // Find URLs in HTML style attributes
    const htmlStyleMatches = html.match(/style="[^"]*background-image:\s*url\('(http[^']+)'\)[^"]*"/g) || [];
    htmlStyleMatches.forEach(match => {
      const url = match.match(/url\('([^']+)'\)/)?.[1];
      if (url) imageUrls.add(url);
    });
    
    console.log(`Found ${imageUrls.size} unique image URLs to embed`);
    
    // Download and convert each image
    const imageMap = new Map<string, string>();
    
    for (const url of imageUrls) {
      try {
        console.log(`Downloading: ${url}`);
        const dataUrl = await this.downloadImageAsDataUrl(url);
        if (dataUrl) {
          imageMap.set(url, dataUrl);
          console.log(`✅ Embedded: ${url.split('/').pop()}`);
        } else {
          console.log(`❌ Failed to embed: ${url}`);
          // Create a placeholder for failed images
          const isIcon = url.includes('.svg');
          const placeholder = isIcon 
            ? this.createPlaceholderSvg()
            : this.createPlaceholderImage();
          imageMap.set(url, placeholder);
        }
      } catch (error) {
        console.log(`❌ Error embedding ${url}: ${error}`);
        // Create placeholder
        const isIcon = url.includes('.svg');
        const placeholder = isIcon 
          ? this.createPlaceholderSvg()
          : this.createPlaceholderImage();
        imageMap.set(url, placeholder);
      }
    }
    
    // Replace URLs with data URLs
    let updatedHtml = html;
    let updatedCss = css;
    
    for (const [originalUrl, dataUrl] of imageMap) {
      // Replace in HTML src attributes
      updatedHtml = updatedHtml.replace(
        new RegExp(`src="${originalUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"`, 'g'),
        `src="${dataUrl}"`
      );
      
      // Replace in HTML style attributes
      updatedHtml = updatedHtml.replace(
        new RegExp(`url\\('${originalUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}'\\)`, 'g'),
        `url('${dataUrl}')`
      );
      
      // Replace in CSS
      updatedCss = updatedCss.replace(
        new RegExp(`url\\('${originalUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}'\\)`, 'g'),
        `url('${dataUrl}')`
      );
    }
    
    console.log(`✅ Embedded ${imageMap.size} images as data URLs`);
    
    return { html: updatedHtml, css: updatedCss };
  }
  
  private static async downloadImageAsDataUrl(url: string): Promise<string | null> {
    return new Promise((resolve) => {
      try {
        const urlObj = new URL(url);
        const client = urlObj.protocol === 'https:' ? https : http;
        
        const req = client.request({
          hostname: urlObj.hostname,
          port: urlObj.port,
          path: urlObj.pathname,
          method: 'GET',
          timeout: 10000
        }, (res) => {
          if (res.statusCode !== 200) {
            console.log(`HTTP ${res.statusCode} for ${url}`);
            resolve(null);
            return;
          }
          
          const chunks: Buffer[] = [];
          
          res.on('data', (chunk) => {
            chunks.push(chunk);
          });
          
          res.on('end', () => {
            try {
              const buffer = Buffer.concat(chunks);
              const contentType = res.headers['content-type'] || 'image/png';
              const base64 = buffer.toString('base64');
              const dataUrl = `data:${contentType};base64,${base64}`;
              resolve(dataUrl);
            } catch (error) {
              console.log(`Error processing ${url}:`, error);
              resolve(null);
            }
          });
        });
        
        req.on('error', (error) => {
          console.log(`Network error for ${url}:`, error.message);
          resolve(null);
        });
        
        req.on('timeout', () => {
          console.log(`Timeout for ${url}`);
          req.destroy();
          resolve(null);
        });
        
        req.end();
        
      } catch (error) {
        console.log(`URL error for ${url}:`, error);
        resolve(null);
      }
    });
  }
  
  private static createPlaceholderImage(): string {
    // Create a simple placeholder image as base64
    const svg = `<svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
      <rect width="200" height="200" fill="#f0f0f0" stroke="#ccc" stroke-width="2"/>
      <text x="100" y="100" text-anchor="middle" dy=".3em" font-family="Arial" font-size="14" fill="#666">
        Image Not Available
      </text>
    </svg>`;
    
    return `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
  }
  
  private static createPlaceholderSvg(): string {
    // Create a simple placeholder icon as base64
    const svg = `<svg width="24" height="24" xmlns="http://www.w3.org/2000/svg">
      <rect width="24" height="24" fill="#ddd" rx="2"/>
      <text x="12" y="12" text-anchor="middle" dy=".3em" font-family="Arial" font-size="10" fill="#999">?</text>
    </svg>`;
    
    return `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
  }
}
