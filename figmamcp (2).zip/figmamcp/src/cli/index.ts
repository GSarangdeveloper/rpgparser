#!/usr/bin/env node

import { Command } from 'commander';
import chalk from 'chalk';
import ora from 'ora';
import { FigmaCodeGenerator } from '../FigmaCodeGenerator';
import { GenerationOptions } from '../types';
import * as fs from 'fs-extra';
import * as path from 'path';

const program = new Command();

program
  .name('figma-mcp')
  .description('Generate code from Figma designs using MCP')
  .version('1.0.0');

program
  .command('generate')
  .description('Generate code from Figma URL')
  .argument('<url>', 'Figma frame or component URL')
  .option('-o, --output <path>', 'Output directory', './generated')
  .option('-f, --framework <framework>', 'Target framework (react|vue|angular|html)', 'react')
  .option('-s, --styling <styling>', 'Styling approach (tailwind|css-modules|styled-components|inline)', 'tailwind')
  .option('-l, --language <language>', 'Language (typescript|javascript)', 'typescript')
  .option('--no-styles', 'Exclude styles from generation')
  .option('--design-tokens', 'Extract and use design tokens')
  .action(async (url: string, options: any) => {
    // Clean up the URL - remove any trailing whitespace or quotes
    url = url.trim().replace(/^["']|["']$/g, '');
    const spinner = ora('Initializing Figma MCP connection...').start();
    
    try {
      const generationOptions: GenerationOptions = {
        framework: options.framework,
        language: options.language,
        styling: options.styling,
        outputPath: options.output
      };

      const generator = new FigmaCodeGenerator();
      
      spinner.text = 'Connecting to Figma MCP server...';
      await generator.initialize();
      
      spinner.text = 'Generating code from Figma design...';
      const result = await generator.generateFromUrl(url, {
        ...generationOptions,
        includeStyles: options.styles !== false,
        useDesignTokens: options.designTokens
      });
      
      spinner.text = 'Writing generated files...';
      await ensureOutputDirectory(options.output);

      // Write main file
      const outputPath = path.join(options.output, result.filename);
      await fs.writeFile(outputPath, result.content);

      // Write additional files (CSS, JS, etc.)
      const additionalFiles: string[] = [];
      if (result.additionalFiles) {
        for (const additionalFile of result.additionalFiles) {
          const additionalPath = path.join(options.output, additionalFile.filename);
          await fs.writeFile(additionalPath, additionalFile.content);
          additionalFiles.push(additionalFile.filename);
        }
      }

      spinner.succeed(chalk.green(`✓ Generated ${result.filename}${additionalFiles.length > 0 ? ` + ${additionalFiles.length} additional files` : ''}`));

      console.log(chalk.blue('\nGeneration Summary:'));
      console.log(chalk.gray(`  Main file: ${outputPath}`));
      if (additionalFiles.length > 0) {
        console.log(chalk.gray(`  Additional files:`));
        additionalFiles.forEach(file => {
          console.log(chalk.gray(`    - ${path.join(options.output, file)}`));
        });
      }
      console.log(chalk.gray(`  Framework: ${options.framework}`));
      console.log(chalk.gray(`  Language: ${options.language}`));
      console.log(chalk.gray(`  Styling: ${options.styling}`));
      
      if (result.dependencies.length > 0) {
        console.log(chalk.yellow('\nRequired dependencies:'));
        result.dependencies.forEach(dep => {
          console.log(chalk.gray(`  - ${dep}`));
        });
      }
      
      await generator.disconnect();
    } catch (error: any) {
      spinner.fail(chalk.red('Generation failed'));
      console.error(chalk.red('\nError:'), error.message);
      
      if (error.message.includes('ECONNREFUSED')) {
        console.log(chalk.yellow('\nMake sure Figma desktop app is running with Dev Mode enabled.'));
        console.log(chalk.gray('The MCP server should be accessible at http://localhost:3845'));
      }
      
      process.exit(1);
    }
  });

program
  .command('check')
  .description('Check connection to Figma MCP server')
  .action(async () => {
    const spinner = ora('Checking Figma MCP server connection...').start();
    
    try {
      const generator = new FigmaCodeGenerator();
      await generator.initialize();
      
      const tools = await generator.getAvailableTools();
      
      spinner.succeed(chalk.green('✓ Successfully connected to Figma MCP server'));
      
      console.log(chalk.blue('\nAvailable tools:'));
      if (Array.isArray(tools)) {
        tools.forEach((tool: any) => {
          console.log(chalk.gray(`  - ${tool.name}: ${tool.description || 'No description'}`));
        });
      } else if (tools && typeof tools === 'object') {
        // Handle case where tools might be an object
        Object.entries(tools).forEach(([name, tool]: [string, any]) => {
          const desc = typeof tool === 'string' ? tool : tool.description || 'No description';
          console.log(chalk.gray(`  - ${name}: ${desc}`));
        });
      } else {
        console.log(chalk.gray('  No tools information available'));
      }
      
      await generator.disconnect();
    } catch (error: any) {
      spinner.fail(chalk.red('Connection failed'));
      console.error(chalk.red('\nError:'), error.message);
      
      console.log(chalk.yellow('\nTroubleshooting:'));
      console.log(chalk.gray('1. Make sure Figma desktop app is running'));
      console.log(chalk.gray('2. Enable Developer Mode in Figma (Menu → Preferences → Developer Mode)'));
      console.log(chalk.gray('3. Check if MCP server is running at http://localhost:3845'));
      
      process.exit(1);
    }
  });

program
  .command('extract-tokens')
  .description('Extract design tokens from Figma file')
  .argument('<file-key>', 'Figma file key')
  .option('-o, --output <path>', 'Output file path', './design-tokens.json')
  .action(async (fileKey: string, options: any) => {
    const spinner = ora('Extracting design tokens...').start();
    
    try {
      const generator = new FigmaCodeGenerator();
      await generator.initialize();
      
      const tokens = await generator.extractDesignTokens(fileKey);
      
      await fs.writeJson(options.output, tokens, { spaces: 2 });
      
      spinner.succeed(chalk.green(`✓ Design tokens saved to ${options.output}`));
      
      console.log(chalk.blue('\nExtracted tokens:'));
      console.log(chalk.gray(`  Colors: ${tokens.colors.length}`));
      console.log(chalk.gray(`  Spacing: ${tokens.spacing.length}`));
      console.log(chalk.gray(`  Typography: ${tokens.typography.length}`));
      console.log(chalk.gray(`  Shadows: ${tokens.shadows.length}`));
      
      await generator.disconnect();
    } catch (error: any) {
      spinner.fail(chalk.red('Token extraction failed'));
      console.error(chalk.red('\nError:'), error.message);
      process.exit(1);
    }
  });

program
  .command('get-images')
  .description('Extract images and assets from Figma URL')
  .argument('<url>', 'Figma frame or component URL')
  .option('-o, --output <path>', 'Output directory for images', './images')
  .action(async (url: string, options: any) => {
    // Clean up the URL - remove any trailing whitespace or quotes
    url = url.trim().replace(/^["']|["']$/g, '');
    const spinner = ora('Extracting images from Figma...').start();
    
    try {
      const generator = new FigmaCodeGenerator();
      await generator.initialize();
      
      const assets = await generator.getAssets(url, {
        framework: 'react',
        language: 'typescript',
        styling: 'tailwind'
      });
      
      spinner.text = 'Downloading images...';
      
      await ensureOutputDirectory(options.output);
      
      console.log(chalk.blue(`\nFound ${assets.length} assets`));
      
      for (const asset of assets) {
        console.log(chalk.gray(`  - ${asset.name} (${asset.type})`));
        
        if (asset.url) {
          // The asset URLs from Figma MCP are typically localhost URLs
          // You may need to download them or process them further
          console.log(chalk.gray(`    URL: ${asset.url}`));
        }
      }
      
      spinner.succeed(chalk.green('✓ Image extraction complete'));
      
      await generator.disconnect();
    } catch (error: any) {
      spinner.fail(chalk.red('Image extraction failed'));
      console.error(chalk.red('\nError:'), error.message);
      process.exit(1);
    }
  });

program
  .command('code-connect-map')
  .description('Get Code Connect mapping information for a Figma URL')
  .argument('<url>', 'Figma frame or component URL')
  .option('-o, --output <path>', 'Output file path', './code-connect-map.json')
  .action(async (url: string, options: any) => {
    // Clean up the URL
    url = url.trim().replace(/^["']|["']$/g, '');
    const spinner = ora('Getting Code Connect map...').start();
    
    try {
      const generator = new FigmaCodeGenerator();
      await generator.initialize();
      
      const result = await generator.getCodeConnectMap(url);
      
      await fs.writeJson(options.output, result, { spaces: 2 });
      
      spinner.succeed(chalk.green(`✓ Code Connect map saved to ${options.output}`));
      
      console.log(chalk.blue('\nCode Connect Map:'));
      console.log(JSON.stringify(result, null, 2));
      
      await generator.disconnect();
    } catch (error: any) {
      spinner.fail(chalk.red('Failed to get Code Connect map'));
      console.error(chalk.red('\nError:'), error.message);
      process.exit(1);
    }
  });

program
  .command('set-config')
  .description('Set code generation configuration')
  .option('-f, --framework <framework>', 'Default framework', 'react')
  .option('-l, --language <language>', 'Default language', 'typescript')
  .option('-s, --styling <styling>', 'Default styling', 'tailwind')
  .option('--config-file <path>', 'Load config from JSON file')
  .action(async (options: any) => {
    const spinner = ora('Setting codegen configuration...').start();
    
    try {
      const generator = new FigmaCodeGenerator();
      await generator.initialize();
      
      let config: any = {
        framework: options.framework,
        language: options.language,
        styling: options.styling
      };
      
      // If config file is provided, load it
      if (options.configFile) {
        const fileConfig = await fs.readJson(options.configFile);
        config = { ...config, ...fileConfig };
      }
      
      const result = await generator.setCodegenConfig(config);
      
      spinner.succeed(chalk.green('✓ Configuration set successfully'));
      
      console.log(chalk.blue('\nConfiguration:'));
      console.log(JSON.stringify(config, null, 2));
      
      if (result) {
        console.log(chalk.blue('\nServer response:'));
        console.log(JSON.stringify(result, null, 2));
      }
      
      await generator.disconnect();
    } catch (error: any) {
      spinner.fail(chalk.red('Failed to set configuration'));
      console.error(chalk.red('\nError:'), error.message);
      process.exit(1);
    }
  });

async function ensureOutputDirectory(outputPath: string): Promise<void> {
  await fs.ensureDir(outputPath);
}

// Show help if no command provided
if (process.argv.length === 2) {
  program.help();
}

program.parse(process.argv);