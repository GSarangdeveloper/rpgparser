import { MCPConnectionManager } from "./client/MCPConnectionManager";
import { FigmaMCPClient } from "./client/FigmaMCPClient";
import { DesignDataProcessor } from "./processor/DesignDataProcessor";
import { DesignSystemManager } from "./processor/DesignSystemManager";
import { CodeGenerator } from "./generator/CodeGenerator";
import { GeneratedCode, GenerationOptions, DesignTokens } from "./types";

export interface GenerateOptions extends GenerationOptions {
  includeStyles?: boolean;
  useDesignTokens?: boolean;
}

export class FigmaCodeGenerator {
  private connectionManager: MCPConnectionManager;
  private mcpClient: FigmaMCPClient | null = null;
  private dataProcessor: DesignDataProcessor;
  private designSystemManager: DesignSystemManager | null = null;
  private codeGenerator: CodeGenerator;

  constructor() {
    this.connectionManager = new MCPConnectionManager();
    this.dataProcessor = new DesignDataProcessor();
    this.codeGenerator = new CodeGenerator();
  }

  async initialize(): Promise<void> {
    this.mcpClient = await this.connectionManager.connectWithRetry();
    this.designSystemManager = new DesignSystemManager(this.mcpClient);
    this.codeGenerator = new CodeGenerator(this.designSystemManager);
  }

  async generateFromUrl(url: string, options: GenerateOptions): Promise<GeneratedCode> {
    if (!this.mcpClient) {
      throw new Error("Generator not initialized. Call initialize() first.");
    }

    try {
      // Extract file key from URL if needed for design tokens
      if (options.useDesignTokens) {
        const fileKey = this.extractFileKeyFromUrl(url);
        if (fileKey) {
          await this.designSystemManager!.loadDesignSystem(fileKey);
        }
      }

      // Generate code using MCP
      const mcpResponse = await this.mcpClient.generateCode(url, {
        format: this.getFormatFromFramework(options.framework, options.language),
        includeStyles: options.includeStyles !== false,
        framework: options.framework,
        language: options.language,
        styling: options.styling
      });

      // Parse the component data
      const component = this.dataProcessor.parseComponentFromMCPResponse(mcpResponse);

      // Generate the final code
      const generatedCode = await this.codeGenerator.generateComponent(
        component,
        mcpResponse.content,
        options
      );

      // If we have assets, fetch them
      if (mcpResponse.assets && mcpResponse.assets.length > 0) {
        await this.mcpClient.getAssets(url, options);
        // Process assets and add to generated code
        // This would be implemented based on specific needs
      }

      return generatedCode;
    } catch (error) {
      console.error("Error generating code:", error);
      throw error;
    }
  }

  async extractDesignTokens(fileKey: string): Promise<DesignTokens> {
    if (!this.mcpClient) {
      throw new Error("Generator not initialized. Call initialize() first.");
    }

    return await this.mcpClient.getDesignTokens(fileKey);
  }

  async getAvailableTools(): Promise<any[]> {
    if (!this.mcpClient) {
      throw new Error("Generator not initialized. Call initialize() first.");
    }

    return await this.mcpClient.getAvailableTools();
  }

  async getAssets(url: string, options: GenerationOptions = {}): Promise<any[]> {
    if (!this.mcpClient) {
      throw new Error("Generator not initialized. Call initialize() first.");
    }

    return await this.mcpClient.getAssets(url, options);
  }

  async getCodeConnectMap(url: string): Promise<any> {
    if (!this.mcpClient) {
      throw new Error("Generator not initialized. Call initialize() first.");
    }

    return await this.mcpClient.getCodeConnectMap(url);
  }

  async setCodegenConfig(config: any): Promise<any> {
    if (!this.mcpClient) {
      throw new Error("Generator not initialized. Call initialize() first.");
    }

    return await this.mcpClient.setCodegenConfig(config);
  }

  async disconnect(): Promise<void> {
    await this.connectionManager.disconnect();
  }

  private extractFileKeyFromUrl(url: string): string | null {
    // Extract file key from Figma URL
    // Example: https://www.figma.com/file/ABC123/Design-System?node-id=1:2
    const match = url.match(/\/file\/([a-zA-Z0-9]+)\//);
    return match ? match[1] : null;
  }

  private getFormatFromFramework(framework?: string, language?: string): 'react-tsx' | 'react-jsx' | 'html' | 'vue' | 'angular' {
    switch (framework) {
      case 'html':
        return 'html';
      case 'react':
        return language === 'typescript' ? 'react-tsx' : 'react-jsx';
      case 'vue':
        return 'vue';
      case 'angular':
        return 'angular';
      default:
        return 'html';
    }
  }
}