import * as fs from 'fs-extra';
import * as path from 'path';

export interface ToolConfig {
  // Connection settings
  figma: {
    mcpServerUrl: string;
    retryAttempts: number;
    timeout: number;
  };
  
  // Generation settings
  generation: {
    framework: 'react' | 'vue' | 'angular' | 'html';
    language: 'typescript' | 'javascript';
    styling: 'tailwind' | 'css-modules' | 'styled-components' | 'inline';
    outputPath: string;
    assetPath: string;
  };
  
  // Design system
  designSystem: {
    tokenPrefix: string;
    useDesignTokens: boolean;
    tokenFormat: 'css-variables' | 'js-constants';
  };
  
  // Quality settings
  quality: {
    generateTests: boolean;
    generateStories: boolean;
    lintGenerated: boolean;
    formatCode: boolean;
  };
  
  // Git integration
  git: {
    enabled: boolean;
    autoCommit: boolean;
    createPR: boolean;
    branchPrefix: string;
  };
}

export class ConfigManager {
  private config: ToolConfig;
  private configPath: string;

  constructor(configPath?: string) {
    this.configPath = configPath || path.join(process.cwd(), 'figma-mcp.config.json');
    this.config = this.loadDefaultConfig();
  }

  async loadConfig(): Promise<ToolConfig> {
    try {
      if (await fs.pathExists(this.configPath)) {
        const fileConfig = await fs.readJson(this.configPath);
        this.config = { ...this.config, ...fileConfig };
      }
    } catch (error) {
      console.warn('Failed to load config file, using defaults:', error);
    }
    
    return this.config;
  }

  async saveConfig(config: Partial<ToolConfig>): Promise<void> {
    this.config = { ...this.config, ...config };
    await fs.writeJson(this.configPath, this.config, { spaces: 2 });
  }

  async initializeConfig(): Promise<void> {
    if (!(await fs.pathExists(this.configPath))) {
      await this.saveConfig(this.config);
      console.log(`Configuration file created at: ${this.configPath}`);
    }
  }

  getConfig(): ToolConfig {
    return this.config;
  }

  updateConfig(updates: Partial<ToolConfig>): void {
    this.config = this.mergeDeep(this.config, updates);
  }

  private loadDefaultConfig(): ToolConfig {
    return {
      figma: {
        mcpServerUrl: 'http://127.0.0.1:3845',
        retryAttempts: 5,
        timeout: 30000
      },
      generation: {
        framework: 'react',
        language: 'typescript',
        styling: 'tailwind',
        outputPath: './generated',
        assetPath: './generated/assets'
      },
      designSystem: {
        tokenPrefix: '--',
        useDesignTokens: true,
        tokenFormat: 'css-variables'
      },
      quality: {
        generateTests: false,
        generateStories: false,
        lintGenerated: true,
        formatCode: true
      },
      git: {
        enabled: false,
        autoCommit: false,
        createPR: false,
        branchPrefix: 'figma-sync'
      }
    };
  }

  private mergeDeep(target: any, source: any): any {
    const result = { ...target };
    
    for (const key in source) {
      if (source.hasOwnProperty(key)) {
        if (source[key] instanceof Object && key in target) {
          result[key] = this.mergeDeep(target[key], source[key]);
        } else {
          result[key] = source[key];
        }
      }
    }
    
    return result;
  }
}