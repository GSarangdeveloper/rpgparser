import * as Handlebars from 'handlebars';
import { FigmaComponent, GeneratedCode, GenerationOptions, TemplateContext, ProcessedAsset } from '../types';
import { DesignSystemManager } from '../processor/DesignSystemManager';
import { HtmlConverter } from '../utils/HtmlConverter';
import { AngularConverter } from '../utils/AngularConverter';

export interface CodeTemplate {
  framework: 'react' | 'vue' | 'angular' | 'html';
  language: 'typescript' | 'javascript';
  styling: 'tailwind' | 'css-modules' | 'styled-components' | 'inline';
  template: string;
}

export class CodeGenerator {
  private templates: Map<string, CodeTemplate> = new Map();
  private handlebars: typeof Handlebars;

  constructor(private designSystem?: DesignSystemManager) {
    this.handlebars = Handlebars.create();
    this.registerHelpers();
    this.loadDefaultTemplates();
  }

  registerTemplate(key: string, template: CodeTemplate): void {
    this.templates.set(key, template);
  }

  async generateComponent(
    component: FigmaComponent,
    mcpCode: string,
    options: GenerationOptions
  ): Promise<GeneratedCode> {
    const templateKey = `${options.framework}-${options.language}-${options.styling}`;

    // Special handling for HTML format - convert JSX to HTML + CSS
    if (options.framework === 'html') {
      try {
        const result = await HtmlConverter.convertToHtml(mcpCode, component.name);
        const { html, css, js, imageFiles, analysisReport } = result;

        const additionalFiles = [
          {
            filename: `${component.name}.css`,
            content: css
          },
          {
            filename: `${component.name}.js`,
            content: js
          }
        ];

        // Add analysis report
        if (analysisReport) {
          additionalFiles.push({
            filename: `${component.name}-analysis.md`,
            content: analysisReport
          });
        }

        // Add image files info (URLs to download)
        if (imageFiles && imageFiles.length > 0) {
          const imageInfo = imageFiles.map((img: { filename: string; url: string }) => `${img.filename}: ${img.url}`).join('\n');
          additionalFiles.push({
            filename: 'images-to-download.txt',
            content: `# Images to download\n# Save these to ./images/ folder\n\n${imageInfo}`
          });
        }

        return {
          filename: `${component.name}.html`,
          content: html,
          dependencies: [],
          assets: [],
          additionalFiles
        };
      } catch (error) {
        console.warn('Failed to convert to HTML, falling back to original code:', error);
        // Fall back to original code if conversion fails
      }
    }

    // Special handling for Angular format - convert JSX to Angular component
    if (options.framework === 'angular') {
      try {
        const { component: angularComponent, template, styles } = AngularConverter.convertToAngular(mcpCode, component.name);
        const kebabName = component.name.replace(/([A-Z])/g, '-$1').toLowerCase().replace(/^-/, '');

        return {
          filename: `${kebabName}.component.ts`,
          content: angularComponent,
          dependencies: ['@angular/core'],
          assets: [],
          additionalFiles: [
            {
              filename: `${kebabName}.component.html`,
              content: template
            },
            {
              filename: `${kebabName}.component.css`,
              content: styles
            }
          ]
        };
      } catch (error) {
        console.warn('Failed to convert to Angular, falling back to original code:', error);
        // Fall back to original code if conversion fails
      }
    }

    // For now, if we don't have a specific template, use the MCP-generated code
    if (!this.templates.has(templateKey)) {
      return {
        filename: `${component.name}.${this.getFileExtension(options)}`,
        content: mcpCode,
        dependencies: this.extractDependencies(mcpCode, options),
        assets: []
      };
    }

    const template = this.templates.get(templateKey)!;
    const context = await this.buildTemplateContext(component, mcpCode, options);
    const code = this.renderTemplate(template.template, context);

    return {
      filename: `${component.name}.${this.getFileExtension(options)}`,
      content: code,
      dependencies: context.dependencies,
      assets: context.assets
    };
  }

  private async buildTemplateContext(
    component: FigmaComponent,
    mcpCode: string, 
    options: GenerationOptions
  ): Promise<TemplateContext> {
    return {
      componentName: component.name,
      props: this.generateProps(component),
      styles: await this.generateStyles(component, options),
      children: await this.generateChildren(component, options),
      imports: this.generateImports(component, options),
      dependencies: this.extractDependencies(mcpCode, options),
      assets: await this.processAssets(component)
    };
  }

  private renderTemplate(template: string, context: TemplateContext): string {
    const compiledTemplate = this.handlebars.compile(template);
    return compiledTemplate(context);
  }

  private generateProps(component: FigmaComponent): any[] {
    const props: any[] = [];
    
    if (component.props) {
      Object.entries(component.props).forEach(([name, config]) => {
        props.push({
          name,
          type: config.type || 'any',
          optional: !config.required,
          defaultValue: config.defaultValue
        });
      });
    }

    return props;
  }

  private async generateStyles(component: FigmaComponent, options: GenerationOptions): Promise<any> {
    if (options.styling === 'tailwind') {
      return {
        classNames: this.generateTailwindClasses(component).join(' ')
      };
    } else if (options.styling === 'css-modules') {
      return {
        cssModule: this.generateCSSModules(component)
      };
    }
    
    return {
      inline: this.generateInlineStyles(component)
    };
  }

  private generateTailwindClasses(component: FigmaComponent): string[] {
    const classes: string[] = [];
    
    // Layout classes
    if (component.constraints?.layout === 'flex') {
      classes.push('flex');
      if (component.constraints.flexDirection === 'column') {
        classes.push('flex-col');
      }
      if (component.constraints.justifyContent) {
        classes.push(this.mapJustifyContent(component.constraints.justifyContent));
      }
      if (component.constraints.alignItems) {
        classes.push(this.mapAlignItems(component.constraints.alignItems));
      }
    }
    
    // Spacing classes
    if (component.styles?.padding) {
      classes.push(this.generatePaddingClass(component.styles.padding));
    }
    
    // Color classes
    if (component.styles?.backgroundColor) {
      classes.push(this.generateBackgroundClass(component.styles.backgroundColor));
    }
    
    return classes;
  }

  private generateCSSModules(component: FigmaComponent): string {
    const rules: string[] = [];
    
    if (component.constraints?.layout) {
      rules.push(`display: ${component.constraints.layout};`);
    }
    
    if (component.styles) {
      if (component.styles.padding) {
        rules.push(`padding: ${this.resolveStyleValue(component.styles.padding)};`);
      }
      if (component.styles.backgroundColor) {
        rules.push(`background-color: ${this.resolveStyleValue(component.styles.backgroundColor)};`);
      }
    }
    
    return `.${component.name.toLowerCase()} {\n  ${rules.join('\n  ')}\n}`;
  }

  private generateInlineStyles(component: FigmaComponent): any {
    const styles: any = {};
    
    if (component.constraints?.layout) {
      styles.display = component.constraints.layout;
    }
    
    if (component.styles) {
      Object.assign(styles, component.styles);
    }
    
    return styles;
  }

  private async generateChildren(component: FigmaComponent, _options: GenerationOptions): Promise<any[]> {
    if (!component.children || component.children.length === 0) {
      return [];
    }
    
    return component.children.map(child => ({
      component: child.name,
      props: this.generateProps(child)
    }));
  }

  private generateImports(component: FigmaComponent, options: GenerationOptions): any[] {
    const imports: any[] = [];
    
    if (options.framework === 'react') {
      imports.push({ name: 'React', path: 'react' });
    }
    
    // Add child component imports
    if (component.children) {
      component.children.forEach(child => {
        imports.push({ name: child.name, path: `./${child.name}` });
      });
    }
    
    return imports;
  }

  private extractDependencies(code: string, options: GenerationOptions): string[] {
    const dependencies: string[] = [];
    
    if (options.framework === 'react') {
      dependencies.push('react');
      if (options.language === 'typescript') {
        dependencies.push('@types/react');
      }
    }
    
    // Extract imports from the code
    const importMatches = code.matchAll(/import\s+.*?\s+from\s+['"]([^'"]+)['"]/g);
    for (const match of importMatches) {
      const dep = match[1];
      if (!dep.startsWith('.') && !dep.startsWith('/')) {
        dependencies.push(dep);
      }
    }
    
    return [...new Set(dependencies)];
  }

  private async processAssets(_component: FigmaComponent): Promise<ProcessedAsset[]> {
    // This would be implemented with actual asset processing
    return [];
  }

  private getFileExtension(options: GenerationOptions): string {
    const extensions: Record<string, Record<string, string>> = {
      react: {
        typescript: 'tsx',
        javascript: 'jsx'
      },
      vue: {
        typescript: 'vue',
        javascript: 'vue'
      },
      angular: {
        typescript: 'ts',
        javascript: 'js'
      },
      html: {
        typescript: 'html',
        javascript: 'html'
      }
    };
    
    const framework = options.framework || 'react';
    const language = options.language || 'typescript';
    return extensions[framework][language];
  }

  private registerHelpers(): void {
    this.handlebars.registerHelper('kebabCase', (str: string) => {
      return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
    });
    
    this.handlebars.registerHelper('unless', function(this: any, conditional: any, options: any) {
      if (!conditional) {
        return options.fn(this);
      }
      return options.inverse(this);
    });
  }

  private loadDefaultTemplates(): void {
    // React TypeScript Tailwind template
    this.registerTemplate('react-typescript-tailwind', {
      framework: 'react',
      language: 'typescript',
      styling: 'tailwind',
      template: `import React from 'react';

interface {{componentName}}Props {
  {{#each props}}
  {{name}}{{#if optional}}?{{/if}}: {{type}};
  {{/each}}
}

export const {{componentName}}: React.FC<{{componentName}}Props> = ({
  {{#each props}}{{name}}{{#unless @last}}, {{/unless}}{{/each}}
}) => {
  return (
    <div className="{{styles.classNames}}">
      {{#each children}}
      <{{component}} {{#each props}}{{name}}={{value}} {{/each}}/>
      {{/each}}
    </div>
  );
};`
    });
  }

  private mapJustifyContent(value: string): string {
    const mapping: Record<string, string> = {
      'flex-start': 'justify-start',
      'flex-end': 'justify-end',
      'center': 'justify-center',
      'space-between': 'justify-between',
      'space-around': 'justify-around',
      'space-evenly': 'justify-evenly'
    };
    return mapping[value] || 'justify-start';
  }

  private mapAlignItems(value: string): string {
    const mapping: Record<string, string> = {
      'flex-start': 'items-start',
      'flex-end': 'items-end',
      'center': 'items-center',
      'stretch': 'items-stretch',
      'baseline': 'items-baseline'
    };
    return mapping[value] || 'items-start';
  }

  private generatePaddingClass(padding: any): string {
    if (typeof padding === 'number') {
      return `p-${Math.round(padding / 4)}`;
    }
    return 'p-4';
  }

  private generateBackgroundClass(_color: any): string {
    // This would map colors to Tailwind classes
    return 'bg-white';
  }

  private resolveStyleValue(value: any): string {
    if (this.designSystem) {
      return this.designSystem.resolveToken(value);
    }
    return value.toString();
  }
}