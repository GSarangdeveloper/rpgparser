// Example: Using Figma MCP Generator programmatically

const { FigmaCodeGenerator } = require('../dist/FigmaCodeGenerator');

async function generateComponent() {
  const generator = new FigmaCodeGenerator();
  
  try {
    // Initialize connection to Figma MCP server
    console.log('Connecting to Figma MCP server...');
    await generator.initialize();
    
    // Your Figma component URL
    const figmaUrl = 'https://www.figma.com/file/YOUR_FILE_ID/Design-System?node-id=1:2';
    
    // Generation options
    const options = {
      framework: 'react',
      language: 'typescript',
      styling: 'tailwind',
      outputPath: './generated',
      includeStyles: true,
      useDesignTokens: true
    };
    
    // Generate the component
    console.log('Generating component...');
    const result = await generator.generateFromUrl(figmaUrl, options);
    
    console.log('Generated:', result.filename);
    console.log('Dependencies:', result.dependencies);
    
    // Save the file
    const fs = require('fs-extra');
    const path = require('path');
    
    const outputPath = path.join(options.outputPath, result.filename);
    await fs.ensureDir(options.outputPath);
    await fs.writeFile(outputPath, result.content);
    
    console.log('Component saved to:', outputPath);
    
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    // Disconnect from the server
    await generator.disconnect();
  }
}

// Run the example
generateComponent();