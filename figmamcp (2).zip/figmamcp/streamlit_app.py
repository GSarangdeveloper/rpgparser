import streamlit as st
import subprocess
import json
import os
import sys
from pathlib import Path
import platform
import re

# Add the dist directory to Python path so we can import the compiled JS modules
sys.path.append(os.path.join(os.path.dirname(__file__), 'dist'))

st.set_page_config(
    page_title="Figma MCP Code Generator",
    page_icon="🎨",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>
    .stButton > button {
        width: 100%;
        background-color: #5551FF;
        color: white;
    }
    .stButton > button:hover {
        background-color: #4441DD;
    }
    .success-message {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
    }
    .error-message {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        color: #721c24;
    }
</style>
""", unsafe_allow_html=True)

# Helper function to handle Windows paths
def fix_path(path):
    """Convert path to use forward slashes and ensure it's properly formatted"""
    if platform.system() == 'Windows':
        # Convert to Path object and back to string with forward slashes
        return str(Path(path).as_posix())
    return path

# Helper function to run Node commands
def run_node_command(args, cwd=None):
    """Run a Node.js command with proper path handling"""
    if cwd is None:
        cwd = os.path.dirname(os.path.abspath(__file__))
    
    # Ensure we're using the correct node command path
    node_cmd = "node.exe" if platform.system() == 'Windows' else "node"
    
    # Build the command
    cmd = [node_cmd] + args
    
    # Debug output (commented out - uncomment if needed for troubleshooting)
    # st.write(f"Debug - Running command: {' '.join(cmd)}")
    # st.write(f"Debug - Working directory: {cwd}")
    
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=cwd,
            shell=True if platform.system() == 'Windows' else False,
            encoding='utf-8',
            errors='replace'
        )
        return result
    except Exception as e:
        st.error(f"Command execution error: {str(e)}")
        return None

# Simplified MCP Direct Connection (95% MCP code + 5% processing)
def get_mcp_code_simplified():
    """Get JSX code directly using the simplified approach from simple-angular-generator.js"""
    try:
        # Create a simplified Node.js script that uses the working approach
        script_content = '''
const { Client } = require("@modelcontextprotocol/sdk/client/index.js");
const { SSEClientTransport } = require("@modelcontextprotocol/sdk/client/sse.js");

async function generateAngularComponent() {
  let transport;
  let client;

  try {
    transport = new SSEClientTransport(new URL("http://127.0.0.1:3845/sse"));

    client = new Client(
      {
        name: "streamlit-app",
        version: "1.0.0"
      },
      {
        capabilities: {
          tools: {}
        }
      }
    );

    await client.connect(transport);

    // Use optimal parameters for Angular
    const result = await client.callTool({
      name: "get_code",
      arguments: {
        clientName: "streamlit-app",
        clientLanguages: "html, css, typescript",
        clientFrameworks: "angular"
      }
    });

    if (result && result.content && result.content[0]) {
      const jsxCode = result.content[0].text;
      console.log(JSON.stringify({ success: true, code: jsxCode }));
    } else {
      console.log(JSON.stringify({ success: false, error: "No code received" }));
    }

  } catch (error) {
    console.log(JSON.stringify({ success: false, error: error.message }));
  } finally {
    if (transport) {
      try {
        await transport.close();
      } catch (e) {
        // Ignore
      }
    }
  }
}

generateAngularComponent();
'''

        # Write script to temp file in the project directory (where node_modules exists)
        script_path = Path("temp_mcp_script.js")
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(script_content)

        try:
            # Run the script from the project directory
            result = run_node_command([str(script_path)])

            if result and result.returncode == 0:
                # Parse JSON output
                output = result.stdout.strip()
                if output:
                    try:
                        data = json.loads(output)
                        if data.get('success'):
                            return data.get('code')
                        else:
                            st.error(f"MCP Error: {data.get('error')}")
                            return None
                    except json.JSONDecodeError:
                        st.error(f"Invalid JSON response: {output}")
                        return None
            else:
                error_msg = result.stderr if result else 'Unknown error'
                st.error(f"Script execution failed: {error_msg}")
                return None

        finally:
            # Clean up temp file
            try:
                script_path.unlink()
            except:
                pass

    except Exception as e:
        st.error(f"Error getting MCP code: {str(e)}")
        return None

def convert_jsx_to_angular(jsx_code, component_name="MyComponent"):
    """Convert JSX to Angular with minimal processing (5% conversion)"""

    # Extract images
    image_matches = re.findall(r'const (img\w+) = "([^"]+)";', jsx_code)
    images = []

    for i, (var_name, url) in enumerate(image_matches):
        extension = 'svg' if '.svg' in url else 'png'
        images.append({
            'variable': var_name,
            'url': url,
            'filename': f'image-{i + 1}.{extension}'
        })

    # Extract JSX content
    jsx_match = re.search(r'return \(([\s\S]*?)\);', jsx_code)
    if not jsx_match:
        return None

    html = jsx_match.group(1).strip()

    # MINIMAL conversions - only what's absolutely needed
    html = re.sub(r'className=', 'class=', html)

    # Replace image variables
    for img in images:
        html = re.sub(f'\\{{{img["variable"]}\\}}', f'"assets/images/{img["filename"]}"', html)

    # Fix inline styles (comprehensive approach)
    html = re.sub(r'style=\{\{([^}]+)\}\}', lambda m: f'style="{m.group(1)}"', html)

    # Fix broken style attributes with $ prefix and malformed quotes
    html = re.sub(r'style="\s*backgroundImage:\s*`url\(\'?\$"([^"\']+)"\'?\)`[^"]*"',
                  lambda m: f'style="background-image: url(\'assets/images/{os.path.basename(m.group(1))}\');"', html)

    # Fix calc styles with broken quotes
    html = re.sub(r'style="\s*top:\s*"calc\([^"]+\)"\s*"', 'style="top: 50%"', html)

    # Fix missing alt attributes (both patterns)
    html = re.sub(r'<img alt class=', '<img alt="" class=', html)
    html = re.sub(r'<img\s+alt\s+class=', '<img alt="" class=', html)

    # Fix additional broken background image patterns
    html = re.sub(r'style="\s*backgroundImage:\s*`url\(\'([^\']+)\'\)`[^"]*"',
                  lambda m: f'style="background-image: url(\'{m.group(1)}\');"', html)

    # Create Angular files
    angular_html = html

    angular_css = f'''/* {{component_name}} Component Styles */

/* Container */
[data-name*="{{component_name}}"] {{
  width: 100%;
  min-width: 1200px;
  min-height: 900px;
  position: relative;
}}

/* Font fixes for complex Tailwind classes */
[class*="font-['Inter:Semi_Bold']"] {{ font-family: 'Inter', sans-serif; font-weight: 600; }}
[class*="font-['Inter:Bold']"] {{ font-family: 'Inter', sans-serif; font-weight: 700; }}
[class*="font-['Inter:Regular']"] {{ font-family: 'Inter', sans-serif; font-weight: 400; }}
[class*="font-['Inter:Light']"] {{ font-family: 'Inter', sans-serif; font-weight: 300; }}
[class*="font-['Newsreader:Regular']"] {{ font-family: 'Newsreader', serif; font-weight: 400; }}
[class*="font-['Newsreader:Medium']"] {{ font-family: 'Newsreader', serif; font-weight: 500; }}'''

    angular_ts = f'''import {{ Component }} from '@angular/core';

@Component({{
  selector: 'app-{{component_name.lower()}}',
  templateUrl: './{{component_name.lower()}}.component.html',
  styleUrls: ['./{{component_name.lower()}}.component.css']
}})
export class {{component_name}}Component {{

  constructor() {{ }}

  // Add your component logic here

}}'''

    # Create preview HTML with working styles and placeholder images
    preview_html = html.replace('assets/images/', 'https://via.placeholder.com/160x160/f3f4f6/9ca3af?text=')

    preview = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{component_name}} Preview</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Newsreader:wght@400;500&display=swap" rel="stylesheet">
    <style>
        {{angular_css}}

        /* Container sizing */
        [data-name*="{{component_name}}"] {{
            width: 100vw;
            height: 100vh;
            min-width: 1200px;
            min-height: 900px;
            position: relative;
            background-color: #ffffff;
        }}

        /* Fix letter spacing */
        .adjustLetterSpacing {{ letter-spacing: -0.02em; }}
    </style>
</head>
<body>
    {{preview_html}}
</body>
</html>'''

    image_list = '\n'.join([f'{img["filename"]}: {img["url"]}' for img in images])

    return {
        'html': angular_html,
        'css': angular_css,
        'typescript': angular_ts,
        'preview': preview,
        'images': image_list,
        'component_name': component_name
    }

# Title and description
st.title("🎨 Figma MCP Code Generator")
st.markdown("Generate HTML, CSS, TypeScript, React components and extract assets from your Figma designs using the MCP server.")

# Sidebar for configuration
with st.sidebar:
    st.header("⚙️ Configuration")

    # Quick preset selection
    st.subheader("🚀 Quick Presets")
    preset = st.selectbox(
        "Choose output format",
        [
            "Angular Component (Recommended)",
            "HTML + CSS (Browser Ready)",
            "React Component"
        ],
        index=0,
        help="Angular Component: Ready-to-use Angular files with minimal setup"
    )

    # Set defaults based on simplified preset
    if preset == "Angular Component (Recommended)":
        default_framework, default_language, default_styling = "angular", "typescript", "tailwind"
    elif preset == "HTML + CSS (Browser Ready)":
        default_framework, default_language, default_styling = "html", "typescript", "tailwind"
    elif preset == "React Component":
        default_framework, default_language, default_styling = "react", "typescript", "tailwind"
    else:
        default_framework, default_language, default_styling = "angular", "typescript", "tailwind"

    # Simplified configuration - auto-configured based on preset
    framework = default_framework
    language = default_language
    styling = default_styling
    output_dir = "output"
    include_styles = True
    use_design_tokens = False

    # Show current configuration
    st.info(f"📋 **Auto-configured:** {framework.title()} + {language.title()} + {styling.title()}")

    # Optional advanced settings (collapsed)
    with st.expander("🔧 Advanced Settings (Optional)", expanded=False):
        st.markdown("**Default settings work best. Only change if needed.**")

        col1, col2 = st.columns(2)
        with col1:
            framework = st.selectbox(
                "Framework",
                ["angular", "html", "react"],
                index=["angular", "html", "react"].index(default_framework),
                help="Angular recommended for production apps"
            )
            language = st.selectbox(
                "Language",
                ["typescript", "javascript"],
                index=["typescript", "javascript"].index(default_language),
                help="TypeScript recommended"
            )

        with col2:
            styling = st.selectbox(
                "Styling",
                ["tailwind", "css-modules", "inline"],
                index=["tailwind", "css-modules", "inline"].index(default_styling),
                help="Tailwind recommended"
            )
            output_dir = st.text_input("Output Directory", value="output", help="Where to save generated files")

# Main content
col1, col2 = st.columns([2, 1])

with col1:
    # Figma URL input
    figma_url = st.text_input(
        "Figma URL",
        placeholder="https://www.figma.com/file/YOUR_FILE_ID/Design?node-id=1:2",
        help="Paste the URL of your Figma frame or component"
    )

    # Example URLs for testing
    with st.expander("📋 Example URLs (for testing)"):
        st.markdown("""
        **Note:** These are example URL formats. You need to use your own Figma file URLs.

        ```
        https://www.figma.com/design/abc123/MyProject?node-id=1-2
        https://www.figma.com/file/xyz789/Components?node-id=5-10&m=dev
        ```

        **How to get your URL:**
        1. Open your Figma file
        2. Select the frame/component you want to convert
        3. Copy the URL from your browser
        4. Paste it in the field above
        """)
    
    # Action selection
    st.subheader("What would you like to do?")
    col_a, col_b, col_c = st.columns(3)
    
    with col_a:
        generate_code = st.checkbox("🔧 Generate Code", value=True)
    with col_b:
        extract_images = st.checkbox("🖼️ Extract Images", value=False)
    with col_c:
        extract_tokens = st.checkbox("🎨 Extract Tokens", value=False)

    # Preview section
    if figma_url and any([generate_code, extract_images, extract_tokens]):
        st.markdown("---")
        st.subheader("👀 Generation Preview")

        preview_col1, preview_col2 = st.columns(2)

        with preview_col1:
            st.markdown("**📁 Files that will be generated:**")
            files_list = []

            if generate_code:
                if framework == "html":
                    files_list.extend([
                        f"📄 Component.html",
                        f"🎨 Component.css" if styling != "inline" else "🎨 Inline styles",
                        f"⚡ Component.{language[:2]}" if language == "typescript" else "⚡ Component.js"
                    ])
                elif framework == "react":
                    ext = "tsx" if language == "typescript" else "jsx"
                    files_list.append(f"⚛️ Component.{ext}")
                    if styling == "css-modules":
                        files_list.append("🎨 Component.module.css")
                elif framework == "vue":
                    files_list.append("💚 Component.vue")
                elif framework == "angular":
                    files_list.extend([
                        "🅰️ Component.component.ts",
                        "📄 Component.component.html",
                        "🎨 Component.component.css"
                    ])

            if extract_images:
                files_list.append("🖼️ Images and assets")

            if extract_tokens:
                files_list.append("🎨 tokens.json")

            for file in files_list:
                st.markdown(f"- {file}")

        with preview_col2:
            st.markdown("**⚙️ Configuration:**")
            st.markdown(f"- **Framework:** {framework.upper()}")
            st.markdown(f"- **Language:** {language.upper()}")
            st.markdown(f"- **Styling:** {styling.upper()}")
            st.markdown(f"- **Output:** `{output_dir}/`")

            if framework == "html":
                if preset == "Angular HTML + CSS + TypeScript":
                    st.info("💡 Angular HTML format generates clean markup optimized for Angular projects with Tailwind CSS!")
                else:
                    st.info("💡 HTML format generates clean, semantic markup perfect for any website!")
            elif framework == "react":
                st.info("💡 React components are ready to use in your React application!")
            elif framework == "vue":
                st.info("💡 Vue components use the modern Composition API!")
            elif framework == "angular":
                st.info("💡 Angular components follow Angular best practices!")

with col2:
    # Connection status
    st.subheader("🔌 Connection Status")
    if st.button("Check Connection"):
        with st.spinner("Checking Figma MCP server..."):
            cli_path = fix_path("dist/cli/index.js")
            result = run_node_command([cli_path, "check"])
            
            if result and result.returncode == 0:
                st.success("✅ Connected to Figma MCP server!")
                # Parse and display available tools
                if "Available tools:" in result.stdout:
                    st.text(result.stdout.split("Available tools:")[1].strip())
            else:
                st.error("❌ Connection failed!")
                if result:
                    st.text(result.stderr or result.stdout)

# Generate button
if st.button("🚀 Generate", type="primary", disabled=not figma_url):
    if not any([generate_code, extract_images, extract_tokens]):
        st.warning("Please select at least one action to perform.")
    else:
        # Create output directory (using relative path)
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Progress tracking
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        results = {}
        total_tasks = sum([generate_code, extract_images, extract_tokens])
        completed_tasks = 0
        
        # Generate code using simplified approach
        if generate_code:
            framework_name = framework.upper()
            if framework == "html":
                framework_name = "HTML + CSS + TypeScript"
            elif framework == "angular":
                framework_name = "Angular Component"
            elif framework == "react":
                framework_name = "React Component"

            status_text.text(f"Getting code from Figma MCP (95% ready)...")
            with st.spinner(f"Generating {framework_name} using simplified approach..."):

                # Step 1: Get JSX code from MCP (95% of the work)
                jsx_code = get_mcp_code_simplified()

                if jsx_code:
                    # Step 2: Minimal conversion (5% of the work)
                    if framework == "angular":
                        # Extract component name from JSX
                        name_match = re.search(r'function\s+(\w+)', jsx_code)
                        component_name = name_match.group(1) if name_match else "MyComponent"

                        converted = convert_jsx_to_angular(jsx_code, component_name)

                        if converted:
                            # Save files to output directory
                            components_dir = output_path / "components"
                            components_dir.mkdir(exist_ok=True)

                            # Write Angular files
                            (components_dir / f"{component_name.lower()}.component.html").write_text(converted['html'], encoding='utf-8')
                            (components_dir / f"{component_name.lower()}.component.css").write_text(converted['css'], encoding='utf-8')
                            (components_dir / f"{component_name.lower()}.component.ts").write_text(converted['typescript'], encoding='utf-8')
                            (components_dir / "preview.html").write_text(converted['preview'], encoding='utf-8')
                            (components_dir / "images.txt").write_text(converted['images'], encoding='utf-8')

                            results["code"] = {
                                "status": "success",
                                "output": f"✅ Angular component '{component_name}' generated successfully!\n📁 Files: HTML, CSS, TypeScript, Preview, Images list",
                                "framework": framework,
                                "language": language,
                                "styling": styling,
                                "simplified": True,
                                "component_name": component_name
                            }
                        else:
                            results["code"] = {"status": "error", "output": "Failed to convert JSX to Angular"}

                    else:
                        # For HTML/React, use the JSX as-is with minimal processing
                        components_dir = output_path / "components"
                        components_dir.mkdir(exist_ok=True)

                        # Save raw JSX for HTML/React
                        if framework == "html":
                            # Convert JSX to HTML
                            html_content = jsx_code.replace('className=', 'class=')
                            (components_dir / "component.html").write_text(html_content, encoding='utf-8')
                        else:
                            # Save as React component
                            (components_dir / "Component.jsx").write_text(jsx_code, encoding='utf-8')

                        results["code"] = {
                            "status": "success",
                            "output": f"✅ {framework_name} generated successfully using 95% MCP code!",
                            "framework": framework,
                            "language": language,
                            "styling": styling,
                            "simplified": True
                        }
                else:
                    results["code"] = {"status": "error", "output": "Failed to get code from Figma MCP. Make sure Figma is open and frame is selected."}

            completed_tasks += 1
            progress_bar.progress(completed_tasks / total_tasks)
        
        # Extract images
        if extract_images:
            status_text.text("Extracting images...")
            with st.spinner("Extracting images and assets..."):
                cli_path = fix_path("dist/cli/index.js")
                images_dir = fix_path(str(output_path / "images"))
                
                cmd_args = [
                    cli_path, "get-images", f'"{figma_url}"',
                    "--output", images_dir
                ]
                
                result = run_node_command(cmd_args)
                
                if result and result.returncode == 0:
                    results["images"] = {"status": "success", "output": result.stdout}
                else:
                    results["images"] = {"status": "error", "output": result.stderr if result else "Failed to run command"}
            
            completed_tasks += 1
            progress_bar.progress(completed_tasks / total_tasks)
        
        # Extract design tokens
        if extract_tokens:
            status_text.text("Extracting design tokens...")
            # Extract file key from URL
            file_key = figma_url.split("/file/")[1].split("/")[0] if "/file/" in figma_url else figma_url.split("/design/")[1].split("/")[0] if "/design/" in figma_url else None
            
            if file_key:
                with st.spinner("Extracting design tokens..."):
                    cli_path = fix_path("dist/cli/index.js")
                    tokens_file = fix_path(str(output_path / "tokens.json"))
                    
                    cmd_args = [
                        cli_path, "extract-tokens", file_key,
                        "--output", tokens_file
                    ]
                    
                    result = run_node_command(cmd_args)
                    
                    if result and result.returncode == 0:
                        results["tokens"] = {"status": "success", "output": result.stdout}
                    else:
                        results["tokens"] = {"status": "error", "output": result.stderr if result else "Failed to run command"}
            else:
                results["tokens"] = {"status": "error", "output": "Could not extract file key from URL"}
            
            completed_tasks += 1
            progress_bar.progress(completed_tasks / total_tasks)
        
        # Clear progress indicators
        progress_bar.empty()
        status_text.empty()
        
        # Display results
        st.markdown("---")
        st.subheader("📊 Results")
        
        # Code generation results
        if "code" in results:
            framework_display = results["code"].get("framework", "Unknown").upper()
            language_display = results["code"].get("language", "Unknown").upper()
            styling_display = results["code"].get("styling", "Unknown").upper()

            with st.expander(f"🔧 {framework_display} Code Generation", expanded=True):
                if results["code"]["status"] == "success":
                    if results["code"].get("simplified"):
                        st.success(f"✅ {framework_display} generated using simplified approach!")
                        st.info("🎯 **95% MCP Code + 5% Processing** - Minimal conversion for maximum accuracy")

                        if framework == "angular" and results["code"].get("component_name"):
                            component_name = results["code"]["component_name"]
                            st.markdown(f"**📦 Component:** `{component_name}Component`")

                            # Show quick setup for Angular
                            st.markdown("**🚀 Quick Setup:**")
                            st.code(f"""# 1. Copy files to your Angular project
cp {component_name.lower()}.component.html src/app/components/{component_name.lower()}/
cp {component_name.lower()}.component.css src/app/components/{component_name.lower()}/
cp {component_name.lower()}.component.ts src/app/components/{component_name.lower()}/

# 2. Add Tailwind CSS to your Angular project
ng add @ngneat/tailwind

# 3. Use component
<app-{component_name.lower()}></app-{component_name.lower()}>""", language="bash")
                    else:
                        st.success(f"✅ {framework_display} + {language_display} code generated successfully!")

                    st.text(results["code"]["output"])

                    # Display generated files
                    try:
                        components_path = output_path / "components"
                        if components_path.exists():
                            component_files = list(components_path.glob("*"))

                            if component_files:
                                st.subheader(f"📁 Generated Files:")

                                # Show files with download buttons
                                for file in sorted(component_files):
                                    if file.is_file():
                                        col1, col2 = st.columns([3, 1])

                                        with col1:
                                            st.markdown(f"**📄 {file.name}**")

                                        with col2:
                                            try:
                                                with open(file, 'r', encoding='utf-8') as f:
                                                    content = f.read()
                                                st.download_button(
                                                    "📥 Download",
                                                    content,
                                                    file_name=file.name,
                                                    key=f"download_{file.name}"
                                                )
                                            except:
                                                st.text("Binary file")

                                        # Show file content with syntax highlighting
                                        if file.suffix.lower() in ['.html', '.css', '.ts', '.js', '.jsx', '.tsx', '.txt']:
                                            try:
                                                with open(file, 'r', encoding='utf-8') as f:
                                                    content = f.read()

                                                # Limit content length for display
                                                if len(content) > 2000:
                                                    content = content[:2000] + "\n... (truncated)"

                                                # Choose syntax highlighting
                                                if file.suffix.lower() == '.html':
                                                    st.code(content, language="html")
                                                elif file.suffix.lower() == '.css':
                                                    st.code(content, language="css")
                                                elif file.suffix.lower() in ['.ts', '.tsx']:
                                                    st.code(content, language="typescript")
                                                elif file.suffix.lower() in ['.js', '.jsx']:
                                                    st.code(content, language="javascript")
                                                elif file.suffix.lower() == '.txt':
                                                    st.code(content, language="text")
                                                else:
                                                    st.code(content)

                                            except Exception as e:
                                                st.warning(f"Could not display {file.name}: {str(e)}")

                                        st.markdown("---")

                                # Special handling for Angular preview
                                if framework == "angular":
                                    preview_file = components_path / "preview.html"
                                    if preview_file.exists():
                                        st.markdown("**🌐 Preview your component:**")
                                        st.markdown(f"Open `{preview_file}` in your browser to see the styled component!")

                            else:
                                st.warning("No files were generated.")
                    except Exception as e:
                        st.warning(f"Could not display generated files: {str(e)}")
                else:
                    st.error("❌ Code generation failed!")
                    st.text(results["code"]["output"])
        
        # Image extraction results
        if "images" in results:
            with st.expander("🖼️ Image Extraction"):
                if results["images"]["status"] == "success":
                    st.success("✅ Images extracted successfully!")
                    st.text(results["images"]["output"])
                else:
                    st.error("❌ Image extraction failed!")
                    st.text(results["images"]["output"])
        
        # Token extraction results
        if "tokens" in results:
            with st.expander("🎨 Design Tokens"):
                if results["tokens"]["status"] == "success":
                    st.success("✅ Design tokens extracted successfully!")
                    st.text(results["tokens"]["output"])
                    
                    # Try to display the tokens
                    try:
                        tokens_file = output_path / "tokens.json"
                        if tokens_file.exists():
                            with open(tokens_file, 'r', encoding='utf-8') as f:
                                tokens = json.load(f)
                            st.json(tokens)
                    except Exception as e:
                        st.warning(f"Could not display tokens: {str(e)}")
                else:
                    st.error("❌ Token extraction failed!")
                    st.text(results["tokens"]["output"])

# Instructions
with st.expander("📖 How to use"):
    st.markdown("""
    ## 🚀 Quick Start
    1. **Make sure Figma is running** with Dev Mode enabled
    2. **Open your design file** in Figma
    3. **Copy the URL** of the frame or component you want to convert
    4. **Choose a preset** from the sidebar (e.g., "HTML + CSS + TypeScript")
    5. **Paste the URL** in the input field above
    6. **Click Generate** to start the process

    ## 🎯 Output Formats

    ### HTML + CSS + TypeScript/JavaScript
    - Generates clean HTML structure
    - Separate CSS file with styles
    - TypeScript/JavaScript for interactivity
    - Perfect for static websites or integration into existing projects

    ### React Components
    - Modern React functional components
    - TypeScript or JavaScript
    - Tailwind CSS, CSS Modules, or Styled Components
    - Ready to use in React applications

    ### Vue Components
    - Vue 3 composition API components
    - TypeScript or JavaScript support
    - Scoped styles with various CSS approaches

    ### Angular Components
    - Angular components with proper structure
    - TypeScript support
    - Component-scoped styles

    ## 📋 URL Format Examples
    - Frame/Component: `https://www.figma.com/file/ABC123/MyDesign?node-id=2:4`
    - Dev Mode URL: `https://www.figma.com/design/ABC123/MyDesign?node-id=2:4&m=dev`

    ## 📁 Output Structure
    ```
    output/
    ├── components/          # Generated code files
    │   ├── Component.html   # (HTML format)
    │   ├── Component.css    # (CSS styles)
    │   ├── Component.ts     # (TypeScript logic)
    │   └── Component.tsx    # (React/Vue components)
    ├── images/             # Extracted images and assets
    └── tokens.json         # Design tokens (colors, spacing, etc.)
    ```

    ## 💡 Tips
    - Use **HTML + CSS + TypeScript** for maximum compatibility
    - Enable **Design Tokens** to extract reusable design variables
    - Check **Extract Images** to get all visual assets
    - The generated code is production-ready and follows best practices
    """)

# Footer
st.markdown("---")
st.markdown("<center>Built with ❤️ using Figma MCP</center>", unsafe_allow_html=True)