# ShoppingCart Angular Component

## Quick Setup

### 1. Copy Files
```bash
# Copy to your Angular project
cp component.html src/app/components/shoppingcart/shoppingcart.component.html
cp component.css src/app/components/shoppingcart/shoppingcart.component.css
cp component.ts src/app/components/shoppingcart/shoppingcart.component.ts
```

### 2. Download Images
- Open `images.txt`
- Download each image to `src/assets/images/`
- Keep the exact filenames shown

### 3. Add Tailwind CSS
```bash
# Install Tailwind CSS
ng add @ngneat/tailwind
```

### 4. Add Fonts
Add to `src/index.html`:
```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Newsreader:wght@400;500&display=swap" rel="stylesheet">
```

### 5. Use Component
Add to your module and use:
```html
<app-shoppingcart></app-shoppingcart>
```

## That's it! 🎉

Your Figma design is now a working Angular component.