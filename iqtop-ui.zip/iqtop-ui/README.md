# IQTOP - Angular UI

**Intelligent QA Testing Orchestration Platform - Frontend Application**

This is a complete Angular 18+ application for the IQTOP platform, featuring real-time workflow monitoring, project management, test scenario generation, and comprehensive test orchestration capabilities.

## 🎯 Project Status

### ✅ Completed Components

#### Core Infrastructure
- ✅ **Project Structure**: Complete Angular 18+ setup with TypeScript
- ✅ **Configuration**: angular.json, tsconfig.json, package.json
- ✅ **Environment Files**: Development and production configurations
- ✅ **Styling**: Global SCSS with custom theme and utility classes

#### Models & Types
- ✅ **User Models**: User, LoginRequest, LoginResponse, AuthState
- ✅ **Project Models**: Project, CreateProjectRequest, Test Configurations
- ✅ **Workflow Models**: Workflow, WorkflowPhase, TestScenario, WorkflowSummary
- ✅ **Artifact Models**: Artifact types and upload interfaces

#### Core Services
- ✅ **AuthService**: JWT authentication, login/logout, user management
- ✅ **SocketService**: Socket.IO integration for real-time updates
- ✅ **WorkflowService**: Complete CRUD operations for workflows
- ✅ **ProjectService**: Complete CRUD operations for projects
- ✅ **DocumentService**: File upload and document management

#### Guards & Interceptors
- ✅ **AuthGuard**: Route protection
- ✅ **AdminGuard**: Role-based access control
- ✅ **JWT Interceptor**: Automatic token injection
- ✅ **Error Interceptor**: Global error handling

#### State Management (NgRx)
- ✅ **Workflow Store**: Actions, Reducer, Effects, Selectors
- ✅ **Project Store**: Actions, Reducer, Effects, Selectors
- ✅ **Real-time Integration**: Socket.IO updates to store

#### Main Application
- ✅ **App Component**: Full layout with sidebar navigation
- ✅ **App Config**: Complete provider setup with NgRx, interceptors
- ✅ **Routing**: Lazy-loaded modules with guards

#### Features
- ✅ **Authentication Module**: Login component with form validation
- ✅ **Dashboard**: Statistics cards, workflow table, quick actions
- ✅ **Project List**: Grid view with navigation
- ✅ **Workflow Monitor**: Real-time updates via Socket.IO (placeholder)

### 🚧 Components Needing Full Implementation

The following components have placeholder implementations and need to be fully developed:

1. **Project Create Component** - Multi-step wizard for project creation
2. **Project Detail Component** - Detailed project view with workflows
3. **Workflow List Component** - Comprehensive workflow listing
4. **Workflow Monitor Component** - Full 8-phase monitoring UI
5. **Standalone Test Gen Component** - Quick test generation interface
6. **Document Library Component** - Document management with upload

---

## 📦 Installation

### Prerequisites
- Node.js 20+
- npm or yarn
- Angular CLI 18+

### Install Dependencies

```bash
cd iqtop-ui
npm install
```

### Install Angular CLI (if not installed)
```bash
npm install -g @angular/cli@18
```

---

## 🚀 Running the Application

### Development Server
```bash
npm start
# or
ng serve
```

Navigate to `http://localhost:4200/`

The application will automatically reload if you change any source files.

### Build for Production
```bash
npm run build
# or
ng build --configuration production
```

Build artifacts will be stored in the `dist/` directory.

---

## 🏗️ Project Structure

```
iqtop-ui/
├── src/
│   ├── app/
│   │   ├── core/
│   │   │   ├── guards/
│   │   │   │   └── auth.guard.ts
│   │   │   ├── interceptors/
│   │   │   │   ├── jwt.interceptor.ts
│   │   │   │   └── error.interceptor.ts
│   │   │   ├── models/
│   │   │   │   ├── user.model.ts
│   │   │   │   ├── project.model.ts
│   │   │   │   ├── workflow.model.ts
│   │   │   │   ├── artifact.model.ts
│   │   │   │   └── index.ts
│   │   │   └── services/
│   │   │       ├── auth.service.ts
│   │   │       ├── socket.service.ts
│   │   │       ├── workflow.service.ts
│   │   │       ├── project.service.ts
│   │   │       └── document.service.ts
│   │   ├── store/
│   │   │   ├── workflow/
│   │   │   │   ├── workflow.actions.ts
│   │   │   │   ├── workflow.reducer.ts
│   │   │   │   ├── workflow.effects.ts
│   │   │   │   └── workflow.selectors.ts
│   │   │   └── project/
│   │   │       ├── project.actions.ts
│   │   │       ├── project.reducer.ts
│   │   │       ├── project.effects.ts
│   │   │       └── project.selectors.ts
│   │   ├── features/
│   │   │   ├── auth/
│   │   │   │   ├── login/
│   │   │   │   │   └── login.component.ts
│   │   │   │   └── auth.routes.ts
│   │   │   ├── dashboard/
│   │   │   │   ├── dashboard.component.ts
│   │   │   │   └── dashboard.routes.ts
│   │   │   ├── projects/
│   │   │   │   ├── project-list/
│   │   │   │   ├── project-create/
│   │   │   │   ├── project-detail/
│   │   │   │   └── projects.routes.ts
│   │   │   ├── workflows/
│   │   │   │   ├── workflow-list/
│   │   │   │   ├── workflow-monitor/
│   │   │   │   └── workflows.routes.ts
│   │   │   ├── standalone-test-gen/
│   │   │   │   └── standalone-test-gen.component.ts
│   │   │   └── documents/
│   │   │       └── document-library/
│   │   ├── app.component.ts
│   │   ├── app.config.ts
│   │   └── app.routes.ts
│   ├── environments/
│   │   ├── environment.ts
│   │   └── environment.prod.ts
│   ├── styles.scss
│   ├── index.html
│   └── main.ts
├── angular.json
├── package.json
├── tsconfig.json
└── README.md
```

---

## 🔧 Configuration

### Environment Variables

Update `src/environments/environment.ts` for development:

```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000/api/v1',  // Your FastAPI backend
  wsUrl: 'http://localhost:8000',            // WebSocket URL
  appName: 'IQTOP',
  version: '1.0.0'
};
```

Update `src/environments/environment.prod.ts` for production:

```typescript
export const environment = {
  production: true,
  apiUrl: 'https://api.your-domain.com/api/v1',
  wsUrl: 'https://api.your-domain.com',
  appName: 'IQTOP',
  version: '1.0.0'
};
```

---

## 🎨 UI Libraries

The application uses a combination of Angular Material and PrimeNG:

### Angular Material
Used for:
- Layout components (Sidenav, Toolbar)
- Form controls
- Buttons and Icons
- Cards

### PrimeNG
Used for:
- Advanced data tables
- Rich UI components
- Dialogs and overlays
- File upload

Both libraries are themed to match the IQTOP brand colors.

---

## 🔌 Backend Integration

The UI connects to your FastAPI backend through:

### REST API Endpoints
- `POST /api/v1/auth/login` - Authentication
- `GET /api/v1/projects` - List projects
- `POST /api/v1/projects` - Create project
- `GET /api/v1/workflows` - List workflows
- `POST /api/v1/workflows/ui-test` - Start UI workflow
- `POST /api/v1/workflows/{id}/approve` - Approve scenarios

### WebSocket Events
- `workflow_update` - Real-time phase updates
- `phase_complete` - Phase completion notifications
- `workflow_complete` - Final workflow completion

---

## 🔐 Authentication Flow

1. User enters credentials in login form
2. AuthService sends POST to `/api/v1/auth/login`
3. Backend returns JWT token and user object
4. Token stored in localStorage
5. JWT Interceptor adds token to all API requests
6. Socket.IO connects with token for real-time updates

### Demo Credentials
- **Admin**: admin@iqtop.com / admin123
- **Tester**: tester@iqtop.com / admin123

---

## 🔄 State Management

The application uses NgRx for state management:

### Workflow State
```typescript
{
  workflows: WorkflowSummary[],
  currentWorkflow: Workflow | null,
  phases: WorkflowPhase[],
  loading: boolean,
  error: string | null
}
```

### Project State
```typescript
{
  projects: Project[],
  currentProject: Project | null,
  loading: boolean,
  error: string | null
}
```

### Dispatching Actions

```typescript
// Load workflows
this.store.dispatch(WorkflowActions.loadWorkflows({}));

// Start workflow
this.store.dispatch(WorkflowActions.startWorkflow({ request }));

// Approve workflow
this.store.dispatch(WorkflowActions.approveWorkflow({
  workflowId,
  scenarios,
  edited: false
}));
```

### Selecting Data

```typescript
this.workflows$ = this.store.select(selectAllWorkflows);
this.currentWorkflow$ = this.store.select(selectCurrentWorkflow);
this.loading$ = this.store.select(selectWorkflowLoading);
```

---

## 📋 Next Steps: Completing the Application

### Priority 1: Project Creation Wizard

File: `src/app/features/projects/project-create/project-create.component.ts`

**Requirements:**
- Multi-step form using Angular Material Stepper
- Step 1: Basic project information
- Step 2: Test type configuration (UI, API, IBMI, Legacy)
- Step 3: Team member assignment
- Step 4: Document upload

**Key Features:**
- Reactive Forms with validation
- Dynamic test configuration forms
- ngx-dropzone for document upload
- Integration with ProjectService.createProject()

### Priority 2: Workflow Monitor

File: `src/app/features/workflows/workflow-monitor/workflow-monitor.component.ts`

**Requirements:**
- Display 8-phase workflow progress
- Real-time updates via Socket.IO
- Phase status indicators (completed, running, pending, failed)
- Collapsible phase details
- Approval interface for Phase 2
- Display test results and artifacts

**Key Features:**
- Material Stepper or custom phase visualizer
- Socket.IO subscription for real-time updates
- Approval modal with editable scenarios
- Links to reports and GitHub PRs

### Priority 3: Project Detail Page

File: `src/app/features/projects/project-detail/project-detail.component.ts`

**Requirements:**
- Tabbed interface (Overview, Workflows, Configuration, Documents)
- Project statistics and metrics
- List of workflows for this project
- Test type configuration display
- Team member management

**Key Features:**
- Material Tabs
- PrimeNG DataTable for workflows
- Chart.js for metrics visualization
- Quick action buttons to start workflows

### Priority 4: Standalone Test Generation

File: `src/app/features/standalone-test-gen/standalone-test-gen.component.ts`

**Requirements:**
- Simple form for test scenario generation
- Document upload (no project required)
- Test type selection
- Generation parameters (detail level, scenario count)
- Display generated scenarios
- Export options (PDF, Excel, JSON)

### Priority 5: Document Library

File: `src/app/features/documents/document-library/document-library.component.ts`

**Requirements:**
- Tree view of documents by project
- Upload functionality
- Preview modal
- Search and filter
- Delete and download actions

---

## 🧪 Testing

### Unit Tests
```bash
ng test
```

### E2E Tests
```bash
ng e2e
```

---

## 📦 Building for Production

### Optimize Build
```bash
ng build --configuration production --optimization --build-optimizer
```

### Docker Deployment

Create `Dockerfile`:
```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist/iqtop-ui /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Create `nginx.conf`:
```nginx
server {
    listen 80;
    server_name localhost;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://backend:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Build and run:
```bash
docker build -t iqtop-ui .
docker run -p 4200:80 iqtop-ui
```

---

## 🎨 Customization

### Theme Colors

Edit `src/styles.scss`:

```scss
:root {
  --primary-color: #2C3E50;
  --secondary-color: #27AE60;
  --accent-color: #E67E22;
  --success-color: #27AE60;
  --danger-color: #E74C3C;
}
```

### Material Theme

Update Angular Material theme in `src/styles.scss`:

```scss
@import '@angular/material/prebuilt-themes/indigo-pink.css';
// Or create custom theme
```

---

## 📚 Additional Resources

- [Angular Documentation](https://angular.io/docs)
- [Angular Material](https://material.angular.io/)
- [PrimeNG](https://primeng.org/)
- [NgRx](https://ngrx.io/)
- [Socket.IO Client](https://socket.io/docs/v4/client-api/)

---

## 🤝 Contributing

1. Follow Angular style guide
2. Use TypeScript strict mode
3. Write unit tests for new components
4. Follow the existing folder structure
5. Use NgRx for state management
6. Document complex logic with comments

---

## 📄 License

[Your License Here]

---

## 🆘 Support

For issues or questions:
- Check the backend API documentation
- Review NgRx DevTools for state debugging
- Check browser console for errors
- Verify environment configuration

---

## 🎯 Quick Reference

### Common Commands

```bash
# Install dependencies
npm install

# Start dev server
npm start

# Build for production
npm run build

# Run tests
npm test

# Generate component
ng g c features/your-module/your-component --standalone

# Generate service
ng g s core/services/your-service
```

### Important Files

- **Main App**: `src/app/app.component.ts`
- **Routing**: `src/app/app.routes.ts`
- **Config**: `src/app/app.config.ts`
- **Styles**: `src/styles.scss`
- **Environment**: `src/environments/environment.ts`

---

**Built with ❤️ for IQTOP Platform**
