import {
  MatDivider,
  MatDividerModule
} from "./chunk-3GSS2DFE.js";
import "./chunk-3MCUFL57.js";
import "./chunk-WRFOMO2M.js";
import "./chunk-J6IC6NGA.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-XWLXMCJQ.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
