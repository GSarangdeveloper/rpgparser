import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-RVZ75LVY.js";
import "./chunk-LAQEG4JV.js";
import "./chunk-WRFOMO2M.js";
import "./chunk-J6IC6NGA.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-XWLXMCJQ.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
