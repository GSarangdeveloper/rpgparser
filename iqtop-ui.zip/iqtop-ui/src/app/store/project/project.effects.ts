import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { map, catchError, switchMap, tap } from 'rxjs/operators';
import { ProjectService } from '../../core/services/project.service';
import * as ProjectActions from './project.actions';

@Injectable()
export class ProjectEffects {
  loadProjects$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectActions.loadProjects),
      switchMap(() =>
        this.projectService.getProjects().pipe(
          map(projects => ProjectActions.loadProjectsSuccess({ projects })),
          catchError(error => of(ProjectActions.loadProjectsFailure({ error: error.message })))
        )
      )
    )
  );

  loadProject$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectActions.loadProject),
      switchMap(({ projectId }) =>
        this.projectService.getProject(projectId).pipe(
          map(project => ProjectActions.loadProjectSuccess({ project })),
          catchError(error => of(ProjectActions.loadProjectFailure({ error: error.message })))
        )
      )
    )
  );

  createProject$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectActions.createProject),
      switchMap(({ request }) =>
        this.projectService.createProject(request).pipe(
          map(project => ProjectActions.createProjectSuccess({ project })),
          catchError(error => of(ProjectActions.createProjectFailure({ error: error.message })))
        )
      )
    )
  );

  createProjectSuccess$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectActions.createProjectSuccess),
      tap(({ project }) => {
        this.router.navigate(['/projects', project.id]);
      })
    ),
    { dispatch: false }
  );

  constructor(
    private actions$: Actions,
    private projectService: ProjectService,
    private router: Router
  ) {}
}
