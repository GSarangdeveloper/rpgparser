import { createReducer, on } from '@ngrx/store';
import { Project } from '../../core/models';
import * as ProjectActions from './project.actions';

export interface ProjectState {
  projects: Project[];
  currentProject: Project | null;
  loading: boolean;
  error: string | null;
}

export const initialState: ProjectState = {
  projects: [],
  currentProject: null,
  loading: false,
  error: null
};

export const projectReducer = createReducer(
  initialState,
  on(ProjectActions.loadProjects, state => ({ ...state, loading: true, error: null })),
  on(ProjectActions.loadProjectsSuccess, (state, { projects }) => ({ ...state, projects, loading: false })),
  on(ProjectActions.loadProjectsFailure, (state, { error }) => ({ ...state, loading: false, error })),
  on(ProjectActions.loadProject, state => ({ ...state, loading: true, error: null })),
  on(ProjectActions.loadProjectSuccess, (state, { project }) => ({ ...state, currentProject: project, loading: false })),
  on(ProjectActions.loadProjectFailure, (state, { error }) => ({ ...state, loading: false, error })),
  on(ProjectActions.createProject, state => ({ ...state, loading: true, error: null })),
  on(ProjectActions.createProjectSuccess, (state, { project }) => ({
    ...state,
    projects: [...state.projects, project],
    currentProject: project,
    loading: false
  })),
  on(ProjectActions.createProjectFailure, (state, { error }) => ({ ...state, loading: false, error })),
  on(ProjectActions.clearCurrentProject, state => ({ ...state, currentProject: null }))
);
