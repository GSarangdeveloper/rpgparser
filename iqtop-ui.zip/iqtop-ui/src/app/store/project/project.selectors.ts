import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ProjectState } from './project.reducer';

export const selectProjectState = createFeatureSelector<ProjectState>('project');

export const selectAllProjects = createSelector(selectProjectState, (state) => state.projects);
export const selectCurrentProject = createSelector(selectProjectState, (state) => state.currentProject);
export const selectProjectLoading = createSelector(selectProjectState, (state) => state.loading);
export const selectProjectError = createSelector(selectProjectState, (state) => state.error);
