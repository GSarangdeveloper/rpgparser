import { createAction, props } from '@ngrx/store';
import { Project, CreateProjectRequest } from '../../core/models';

export const loadProjects = createAction('[Project] Load Projects');
export const loadProjectsSuccess = createAction('[Project] Load Projects Success', props<{ projects: Project[] }>());
export const loadProjectsFailure = createAction('[Project] Load Projects Failure', props<{ error: string }>());

export const loadProject = createAction('[Project] Load Project', props<{ projectId: string }>());
export const loadProjectSuccess = createAction('[Project] Load Project Success', props<{ project: Project }>());
export const loadProjectFailure = createAction('[Project] Load Project Failure', props<{ error: string }>());

export const createProject = createAction('[Project] Create Project', props<{ request: CreateProjectRequest }>());
export const createProjectSuccess = createAction('[Project] Create Project Success', props<{ project: Project }>());
export const createProjectFailure = createAction('[Project] Create Project Failure', props<{ error: string }>());

export const clearCurrentProject = createAction('[Project] Clear Current Project');
