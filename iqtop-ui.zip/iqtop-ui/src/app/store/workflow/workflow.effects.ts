import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { map, catchError, switchMap, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { WorkflowService } from '../../core/services/workflow.service';
import { SocketService } from '../../core/services/socket.service';
import * as WorkflowActions from './workflow.actions';

@Injectable()
export class WorkflowEffects {
  loadWorkflows$ = createEffect(() =>
    this.actions$.pipe(
      ofType(WorkflowActions.loadWorkflows),
      switchMap(({ projectId }) =>
        this.workflowService.getWorkflows(projectId).pipe(
          map(workflows => WorkflowActions.loadWorkflowsSuccess({ workflows })),
          catchError(error => of(WorkflowActions.loadWorkflowsFailure({ error: error.message })))
        )
      )
    )
  );

  loadWorkflow$ = createEffect(() =>
    this.actions$.pipe(
      ofType(WorkflowActions.loadWorkflow),
      switchMap(({ workflowId }) =>
        this.workflowService.getWorkflow(workflowId).pipe(
          map(workflow => WorkflowActions.loadWorkflowSuccess({ workflow })),
          catchError(error => of(WorkflowActions.loadWorkflowFailure({ error: error.message })))
        )
      )
    )
  );

  loadWorkflowPhases$ = createEffect(() =>
    this.actions$.pipe(
      ofType(WorkflowActions.loadWorkflowPhases),
      switchMap(({ workflowId }) =>
        this.workflowService.getWorkflowPhases(workflowId).pipe(
          map(phases => WorkflowActions.loadWorkflowPhasesSuccess({ phases })),
          catchError(error => of(WorkflowActions.loadWorkflowPhasesFailure({ error: error.message })))
        )
      )
    )
  );

  startWorkflow$ = createEffect(() =>
    this.actions$.pipe(
      ofType(WorkflowActions.startWorkflow),
      switchMap(({ request }) =>
        this.workflowService.startWorkflow(request).pipe(
          map(workflow => WorkflowActions.startWorkflowSuccess({ workflow })),
          catchError(error => of(WorkflowActions.startWorkflowFailure({ error: error.message })))
        )
      )
    )
  );

  startWorkflowSuccess$ = createEffect(() =>
    this.actions$.pipe(
      ofType(WorkflowActions.startWorkflowSuccess),
      tap(({ workflow }) => {
        this.router.navigate(['/workflows', workflow.id]);
      })
    ),
    { dispatch: false }
  );

  approveWorkflow$ = createEffect(() =>
    this.actions$.pipe(
      ofType(WorkflowActions.approveWorkflow),
      switchMap(({ workflowId, scenarios, edited }) =>
        this.workflowService.approveWorkflow({ workflow_id: workflowId, scenarios, edited }).pipe(
          map(() => WorkflowActions.approveWorkflowSuccess()),
          catchError(error => of(WorkflowActions.approveWorkflowFailure({ error: error.message })))
        )
      )
    )
  );

  cancelWorkflow$ = createEffect(() =>
    this.actions$.pipe(
      ofType(WorkflowActions.cancelWorkflow),
      switchMap(({ workflowId }) =>
        this.workflowService.cancelWorkflow(workflowId).pipe(
          map(() => WorkflowActions.cancelWorkflowSuccess()),
          catchError(error => of(WorkflowActions.cancelWorkflowFailure({ error: error.message })))
        )
      )
    )
  );

  constructor(
    private actions$: Actions,
    private workflowService: WorkflowService,
    private socketService: SocketService,
    private router: Router
  ) {}
}
