import { createAction, props } from '@ngrx/store';
import { Workflow, WorkflowPhase, WorkflowSummary, StartWorkflowRequest } from '../../core/models';

// Load Workflows
export const loadWorkflows = createAction('[Workflow] Load Workflows', props<{ projectId?: string }>());
export const loadWorkflowsSuccess = createAction('[Workflow] Load Workflows Success', props<{ workflows: WorkflowSummary[] }>());
export const loadWorkflowsFailure = createAction('[Workflow] Load Workflows Failure', props<{ error: string }>());

// Load Single Workflow
export const loadWorkflow = createAction('[Workflow] Load Workflow', props<{ workflowId: string }>());
export const loadWorkflowSuccess = createAction('[Workflow] Load Workflow Success', props<{ workflow: Workflow }>());
export const loadWorkflowFailure = createAction('[Workflow] Load Workflow Failure', props<{ error: string }>());

// Load Workflow Phases
export const loadWorkflowPhases = createAction('[Workflow] Load Workflow Phases', props<{ workflowId: string }>());
export const loadWorkflowPhasesSuccess = createAction('[Workflow] Load Workflow Phases Success', props<{ phases: WorkflowPhase[] }>());
export const loadWorkflowPhasesFailure = createAction('[Workflow] Load Workflow Phases Failure', props<{ error: string }>());

// Start Workflow
export const startWorkflow = createAction('[Workflow] Start Workflow', props<{ request: StartWorkflowRequest }>());
export const startWorkflowSuccess = createAction('[Workflow] Start Workflow Success', props<{ workflow: Workflow }>());
export const startWorkflowFailure = createAction('[Workflow] Start Workflow Failure', props<{ error: string }>());

// Approve Workflow
export const approveWorkflow = createAction('[Workflow] Approve Workflow', props<{ workflowId: string; scenarios: any[]; edited: boolean }>());
export const approveWorkflowSuccess = createAction('[Workflow] Approve Workflow Success');
export const approveWorkflowFailure = createAction('[Workflow] Approve Workflow Failure', props<{ error: string }>());

// Real-time Updates (from Socket.IO)
export const workflowPhaseUpdate = createAction('[Workflow] Phase Update', props<{ workflow_id: string; phase: number; status: string; output_data?: any }>());
export const workflowCompleted = createAction('[Workflow] Workflow Completed', props<{ workflow_id: string; artifacts: any }>());

// Cancel Workflow
export const cancelWorkflow = createAction('[Workflow] Cancel Workflow', props<{ workflowId: string }>());
export const cancelWorkflowSuccess = createAction('[Workflow] Cancel Workflow Success');
export const cancelWorkflowFailure = createAction('[Workflow] Cancel Workflow Failure', props<{ error: string }>());

// Clear current workflow
export const clearCurrentWorkflow = createAction('[Workflow] Clear Current Workflow');
