import { createFeatureSelector, createSelector } from '@ngrx/store';
import { WorkflowState } from './workflow.reducer';

export const selectWorkflowState = createFeatureSelector<WorkflowState>('workflow');

export const selectAllWorkflows = createSelector(
  selectWorkflowState,
  (state) => state.workflows
);

export const selectCurrentWorkflow = createSelector(
  selectWorkflowState,
  (state) => state.currentWorkflow
);

export const selectWorkflowPhases = createSelector(
  selectWorkflowState,
  (state) => state.phases
);

export const selectWorkflowLoading = createSelector(
  selectWorkflowState,
  (state) => state.loading
);

export const selectWorkflowError = createSelector(
  selectWorkflowState,
  (state) => state.error
);

export const selectCurrentPhase = createSelector(
  selectCurrentWorkflow,
  (workflow) => workflow?.current_phase
);

export const selectWorkflowStatus = createSelector(
  selectCurrentWorkflow,
  (workflow) => workflow?.status
);
