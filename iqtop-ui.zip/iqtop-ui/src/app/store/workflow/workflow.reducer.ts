import { createReducer, on } from '@ngrx/store';
import { Workflow, WorkflowPhase, WorkflowSummary, WorkflowStatus } from '../../core/models';
import * as WorkflowActions from './workflow.actions';

export interface WorkflowState {
  workflows: WorkflowSummary[];
  currentWorkflow: Workflow | null;
  phases: WorkflowPhase[];
  loading: boolean;
  error: string | null;
  phasesLoading: boolean;
  phasesError: string | null;
}

export const initialState: WorkflowState = {
  workflows: [],
  currentWorkflow: null,
  phases: [],
  loading: false,
  error: null,
  phasesLoading: false,
  phasesError: null
};

export const workflowReducer = createReducer(
  initialState,

  // Load Workflows
  on(WorkflowActions.loadWorkflows, state => ({
    ...state,
    loading: true,
    error: null
  })),
  on(WorkflowActions.loadWorkflowsSuccess, (state, { workflows }) => ({
    ...state,
    workflows,
    loading: false
  })),
  on(WorkflowActions.loadWorkflowsFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),

  // Load Single Workflow
  on(WorkflowActions.loadWorkflow, state => ({
    ...state,
    loading: true,
    error: null
  })),
  on(WorkflowActions.loadWorkflowSuccess, (state, { workflow }) => ({
    ...state,
    currentWorkflow: workflow,
    loading: false
  })),
  on(WorkflowActions.loadWorkflowFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),

  // Load Workflow Phases
  on(WorkflowActions.loadWorkflowPhases, state => ({
    ...state,
    phasesLoading: true,
    phasesError: null
  })),
  on(WorkflowActions.loadWorkflowPhasesSuccess, (state, { phases }) => ({
    ...state,
    phases,
    phasesLoading: false
  })),
  on(WorkflowActions.loadWorkflowPhasesFailure, (state, { error }) => ({
    ...state,
    phasesLoading: false,
    phasesError: error
  })),

  // Start Workflow
  on(WorkflowActions.startWorkflow, state => ({
    ...state,
    loading: true,
    error: null
  })),
  on(WorkflowActions.startWorkflowSuccess, (state, { workflow }) => ({
    ...state,
    currentWorkflow: workflow,
    loading: false
  })),
  on(WorkflowActions.startWorkflowFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),

  // Real-time Phase Update
  on(WorkflowActions.workflowPhaseUpdate, (state, { workflow_id, phase, status, output_data }) => {
    if (state.currentWorkflow?.id === workflow_id) {
      return {
        ...state,
        currentWorkflow: {
          ...state.currentWorkflow,
          current_phase: phase,
          status: status as any
        },
        phases: state.phases.map(p =>
          p.phase_number === phase
            ? { ...p, status, output_data: output_data || p.output_data }
            : p
        )
      };
    }
    return state;
  }),

  // Workflow Completed
  on(WorkflowActions.workflowCompleted, (state, { workflow_id }) => {
    if (state.currentWorkflow?.id === workflow_id) {
      const completedStatus: WorkflowStatus = 'completed';
      return {
        ...state,
        currentWorkflow: {
          ...state.currentWorkflow,
          status: completedStatus,
          completed_at: new Date()
        }
      };
    }
    return state;
  }),

  // Clear Current Workflow
  on(WorkflowActions.clearCurrentWorkflow, state => ({
    ...state,
    currentWorkflow: null,
    phases: []
  }))
);
