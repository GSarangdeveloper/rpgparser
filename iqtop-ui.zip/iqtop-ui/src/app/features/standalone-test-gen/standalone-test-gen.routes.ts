import { Routes } from '@angular/router';

export const STANDALONE_TEST_GEN_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./standalone-test-gen.component').then(m => m.StandaloneTestGenComponent)
  }
];
