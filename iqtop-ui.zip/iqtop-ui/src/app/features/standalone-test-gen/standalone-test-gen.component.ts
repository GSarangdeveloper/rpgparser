import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';

interface GeneratedScenario {
  id: string;
  title: string;
  description: string;
  steps: string[];
  expectedResult: string;
  priority: 'high' | 'medium' | 'low';
}

@Component({
  selector: 'app-standalone-test-gen',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatProgressSpinnerModule,
    MatDividerModule
  ],
  template: `
    <div class="standalone-test-gen-page">
      <div class="page-header">
        <div>
          <h1>Standalone Test Generation</h1>
          <p class="subtitle">Generate test scenarios quickly without creating a project</p>
        </div>
      </div>

      <div class="content-grid">
        <!-- Input Section -->
        <mat-card class="input-card">
          <h2>Test Configuration</h2>
          <p class="section-description">Provide details about what you want to test</p>

          <form [formGroup]="testForm">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Test Type</mat-label>
              <mat-select formControlName="testType">
                <mat-option value="ui">UI Testing</mat-option>
                <mat-option value="api">API Testing</mat-option>
                <mat-option value="data">Data Testing</mat-option>
                <mat-option value="integration">Integration Testing</mat-option>
              </mat-select>
              <mat-hint>Select the type of testing you want to perform</mat-hint>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Application/Feature Name</mat-label>
              <input matInput formControlName="featureName" placeholder="e.g., User Login Flow">
              <mat-error *ngIf="testForm.get('featureName')?.hasError('required')">
                Feature name is required
              </mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Description</mat-label>
              <textarea matInput formControlName="description" rows="4"
                placeholder="Describe the functionality you want to test in detail..."></textarea>
              <mat-hint>Provide as much detail as possible for better test scenarios</mat-hint>
              <mat-error *ngIf="testForm.get('description')?.hasError('required')">
                Description is required
              </mat-error>
            </mat-form-field>

            <div class="upload-section">
              <label class="upload-label">Supporting Documents (Optional)</label>
              <div class="upload-area" (click)="fileInput.click()">
                <mat-icon>cloud_upload</mat-icon>
                <p *ngIf="uploadedFiles.length === 0">Click to upload documents</p>
                <p *ngIf="uploadedFiles.length === 0" class="upload-hint">
                  Screenshots, requirements, or design files (PDF, PNG, JPG)
                </p>
                <div *ngIf="uploadedFiles.length > 0" class="uploaded-files">
                  <mat-chip *ngFor="let file of uploadedFiles" class="file-chip">
                    <mat-icon>description</mat-icon>
                    {{ file.name }}
                    <mat-icon (click)="removeFile(file); $event.stopPropagation()">cancel</mat-icon>
                  </mat-chip>
                </div>
              </div>
              <input #fileInput type="file" multiple hidden (change)="onFileSelected($event)"
                accept=".pdf,.png,.jpg,.jpeg,.doc,.docx">
            </div>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Number of Scenarios to Generate</mat-label>
              <mat-select formControlName="scenarioCount">
                <mat-option [value]="5">5 scenarios</mat-option>
                <mat-option [value]="10">10 scenarios</mat-option>
                <mat-option [value]="15">15 scenarios</mat-option>
                <mat-option [value]="20">20 scenarios</mat-option>
              </mat-select>
            </mat-form-field>

            <button mat-raised-button color="primary" class="generate-button full-width"
              (click)="generateScenarios()" [disabled]="testForm.invalid || isGenerating">
              <mat-icon>auto_awesome</mat-icon>
              {{ isGenerating ? 'Generating...' : 'Generate Test Scenarios' }}
            </button>
          </form>
        </mat-card>

        <!-- Results Section -->
        <div class="results-section">
          <mat-card class="results-card" *ngIf="!isGenerating && generatedScenarios.length === 0">
            <div class="empty-state">
              <mat-icon>science</mat-icon>
              <h3>No Scenarios Generated Yet</h3>
              <p>Fill in the form and click "Generate Test Scenarios" to get AI-powered test scenarios</p>
            </div>
          </mat-card>

          <mat-card class="results-card generating-card" *ngIf="isGenerating">
            <div class="generating-state">
              <mat-spinner diameter="50"></mat-spinner>
              <h3>Generating Test Scenarios</h3>
              <p>AI is analyzing your requirements and creating comprehensive test scenarios...</p>
            </div>
          </mat-card>

          <div *ngIf="!isGenerating && generatedScenarios.length > 0">
            <div class="results-header">
              <h2>Generated Test Scenarios ({{ generatedScenarios.length }})</h2>
              <div class="results-actions">
                <button mat-button (click)="exportScenarios('json')">
                  <mat-icon>code</mat-icon>
                  Export JSON
                </button>
                <button mat-button (click)="exportScenarios('csv')">
                  <mat-icon>table_chart</mat-icon>
                  Export CSV
                </button>
                <button mat-button (click)="exportScenarios('pdf')">
                  <mat-icon>picture_as_pdf</mat-icon>
                  Export PDF
                </button>
              </div>
            </div>

            <mat-card *ngFor="let scenario of generatedScenarios" class="scenario-card">
              <div class="scenario-header">
                <div>
                  <h3>{{ scenario.title }}</h3>
                  <mat-chip [class]="'priority-chip priority-' + scenario.priority">
                    {{ scenario.priority }} priority
                  </mat-chip>
                </div>
              </div>

              <p class="scenario-description">{{ scenario.description }}</p>

              <div class="scenario-section">
                <h4>Test Steps</h4>
                <ol class="test-steps">
                  <li *ngFor="let step of scenario.steps">{{ step }}</li>
                </ol>
              </div>

              <div class="scenario-section">
                <h4>Expected Result</h4>
                <p class="expected-result">{{ scenario.expectedResult }}</p>
              </div>
            </mat-card>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .standalone-test-gen-page {
      max-width: 1400px;
      margin: 0 auto;
    }

    .page-header {
      margin-bottom: 2rem;
    }

    .page-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .subtitle {
      color: #6b7280;
      font-size: 1rem;
      margin: 0;
    }

    .content-grid {
      display: grid;
      grid-template-columns: 500px 1fr;
      gap: 2rem;
    }

    @media (max-width: 1200px) {
      .content-grid {
        grid-template-columns: 1fr;
      }
    }

    .input-card {
      padding: 2rem;
      height: fit-content;
      position: sticky;
      top: 2rem;
    }

    .input-card h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .section-description {
      color: #6b7280;
      font-size: 0.875rem;
      margin: 0 0 1.5rem 0;
    }

    .full-width {
      width: 100%;
      margin-bottom: 1rem;
    }

    .upload-section {
      margin-bottom: 1rem;
    }

    .upload-label {
      display: block;
      font-size: 0.875rem;
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .upload-area {
      border: 2px dashed #d1d5db;
      border-radius: 0.5rem;
      padding: 2rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s ease;
      background-color: #f9fafb;
    }

    .upload-area:hover {
      border-color: #2C3E50;
      background-color: #f3f4f6;
    }

    .upload-area mat-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      color: #6b7280;
      margin-bottom: 0.5rem;
    }

    .upload-area p {
      color: #1f2937;
      font-weight: 500;
      margin: 0.5rem 0;
    }

    .upload-hint {
      color: #6b7280 !important;
      font-size: 0.875rem;
      font-weight: 400 !important;
    }

    .uploaded-files {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      justify-content: center;
    }

    .file-chip {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background-color: white;
      border: 1px solid #e5e7eb;
    }

    .file-chip mat-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
      color: #6b7280;
    }

    .file-chip mat-icon:last-child {
      cursor: pointer;
      color: #9ca3af;
    }

    .file-chip mat-icon:last-child:hover {
      color: #e74c3c;
    }

    .generate-button {
      height: 3rem;
      font-size: 1rem;
      font-weight: 500;
      margin-top: 1rem;
    }

    .generate-button mat-icon {
      margin-right: 0.5rem;
    }

    .results-section {
      min-height: 400px;
    }

    .results-card {
      padding: 3rem;
    }

    .empty-state {
      text-align: center;
      color: #6b7280;
    }

    .empty-state mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      margin-bottom: 1rem;
      color: #d1d5db;
    }

    .empty-state h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .empty-state p {
      font-size: 0.875rem;
      max-width: 400px;
      margin: 0 auto;
    }

    .generating-card {
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
    }

    .generating-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }

    .generating-state h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0;
    }

    .generating-state p {
      font-size: 0.875rem;
      color: #6b7280;
      text-align: center;
      max-width: 400px;
    }

    .results-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
    }

    .results-header h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0;
    }

    .results-actions {
      display: flex;
      gap: 0.5rem;
    }

    .results-actions button {
      color: #6b7280;
    }

    .results-actions button mat-icon {
      margin-right: 0.5rem;
      font-size: 18px;
      width: 18px;
      height: 18px;
    }

    .scenario-card {
      padding: 1.5rem;
      margin-bottom: 1rem;
      border-left: 4px solid #2C3E50;
    }

    .scenario-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }

    .scenario-header h3 {
      font-size: 1.125rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .priority-chip {
      padding: 0.25rem 0.75rem;
      border-radius: 0.25rem;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .priority-high {
      background-color: #fee2e2;
      color: #991b1b;
    }

    .priority-medium {
      background-color: #fef3c7;
      color: #92400e;
    }

    .priority-low {
      background-color: #dbeafe;
      color: #1e40af;
    }

    .scenario-description {
      color: #6b7280;
      font-size: 0.875rem;
      margin: 0 0 1rem 0;
    }

    .scenario-section {
      margin-top: 1rem;
      padding-top: 1rem;
      border-top: 1px solid #e5e7eb;
    }

    .scenario-section h4 {
      font-size: 0.875rem;
      font-weight: 600;
      color: #374151;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin: 0 0 0.75rem 0;
    }

    .test-steps {
      margin: 0;
      padding-left: 1.5rem;
    }

    .test-steps li {
      color: #1f2937;
      font-size: 0.875rem;
      line-height: 1.6;
      margin-bottom: 0.5rem;
    }

    .expected-result {
      color: #1f2937;
      font-size: 0.875rem;
      line-height: 1.6;
      margin: 0;
      background-color: #f0fdf4;
      padding: 0.75rem;
      border-radius: 0.375rem;
      border-left: 3px solid #27AE60;
    }
  `]
})
export class StandaloneTestGenComponent {
  testForm: FormGroup;
  uploadedFiles: File[] = [];
  isGenerating = false;
  generatedScenarios: GeneratedScenario[] = [];

  constructor(private fb: FormBuilder) {
    this.testForm = this.fb.group({
      testType: ['ui', Validators.required],
      featureName: ['', Validators.required],
      description: ['', Validators.required],
      scenarioCount: [10, Validators.required]
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      this.uploadedFiles.push(...Array.from(input.files));
    }
  }

  removeFile(file: File): void {
    this.uploadedFiles = this.uploadedFiles.filter(f => f !== file);
  }

  generateScenarios(): void {
    if (this.testForm.invalid) return;

    this.isGenerating = true;
    this.generatedScenarios = [];

    // Simulate AI generation
    setTimeout(() => {
      const count = this.testForm.get('scenarioCount')?.value || 10;
      const featureName = this.testForm.get('featureName')?.value;

      this.generatedScenarios = Array.from({ length: Math.min(count, 5) }, (_, i) => ({
        id: `scenario-${i + 1}`,
        title: `Test Scenario ${i + 1}: ${featureName} - Validation ${i + 1}`,
        description: `Verify that the ${featureName.toLowerCase()} functionality works correctly under ${this.getPriorityText(i)} conditions`,
        steps: [
          'Navigate to the application homepage',
          `Access the ${featureName} feature`,
          'Enter valid test data in all required fields',
          'Submit the form/request',
          'Verify the response/outcome'
        ],
        expectedResult: `The ${featureName.toLowerCase()} should complete successfully with appropriate feedback and all data should be processed correctly`,
        priority: this.getPriority(i)
      }));

      this.isGenerating = false;
    }, 2500);
  }

  getPriority(index: number): 'high' | 'medium' | 'low' {
    if (index < 2) return 'high';
    if (index < 4) return 'medium';
    return 'low';
  }

  getPriorityText(index: number): string {
    if (index < 2) return 'critical';
    if (index < 4) return 'normal';
    return 'edge case';
  }

  exportScenarios(format: 'json' | 'csv' | 'pdf'): void {
    console.log(`Exporting scenarios as ${format.toUpperCase()}...`);
    // Implementation would create and download the file
  }
}
