import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';

interface Tool {
  id: string;
  name: string;
  description: string;
  icon: string;
  route: string;
  category: string;
  status: 'available' | 'coming-soon';
}

@Component({
  selector: 'app-test-tools',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule
  ],
  template: `
    <div class="test-tools-page">
      <div class="page-header">
        <div>
          <h1>Test Tools</h1>
          <p class="subtitle">Explore all available testing and automation tools</p>
        </div>
      </div>

      <div class="category-section" *ngFor="let category of categories">
        <h2 class="category-title">{{ category }}</h2>
        <div class="tools-grid">
          <mat-card *ngFor="let tool of getToolsByCategory(category)" class="tool-card"
            [class.coming-soon]="tool.status === 'coming-soon'"
            [routerLink]="tool.status === 'available' ? tool.route : null">
            <div class="tool-icon-container" [class]="'icon-' + tool.id">
              <mat-icon class="tool-icon">{{ tool.icon }}</mat-icon>
            </div>

            <div class="tool-content">
              <div class="tool-header">
                <h3>{{ tool.name }}</h3>
                <mat-chip *ngIf="tool.status === 'coming-soon'" class="coming-soon-chip">
                  Coming Soon
                </mat-chip>
              </div>

              <p class="tool-description">{{ tool.description }}</p>

              <div class="tool-footer">
                <button mat-raised-button color="primary" *ngIf="tool.status === 'available'"
                  [routerLink]="tool.route" (click)="$event.stopPropagation()">
                  <mat-icon>arrow_forward</mat-icon>
                  Open Tool
                </button>
                <button mat-button disabled *ngIf="tool.status === 'coming-soon'">
                  <mat-icon>schedule</mat-icon>
                  Coming Soon
                </button>
              </div>
            </div>
          </mat-card>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .test-tools-page {
      max-width: 1400px;
      margin: 0 auto;
    }

    .page-header {
      margin-bottom: 3rem;
    }

    .page-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .subtitle {
      color: #6b7280;
      font-size: 1rem;
      margin: 0;
    }

    .category-section {
      margin-bottom: 3rem;
    }

    .category-title {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1.5rem 0;
      padding-bottom: 0.75rem;
      border-bottom: 2px solid #e5e7eb;
    }

    .tools-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 1.5rem;
    }

    @media (max-width: 768px) {
      .tools-grid {
        grid-template-columns: 1fr;
      }
    }

    .tool-card {
      padding: 0;
      cursor: pointer;
      transition: all 0.2s ease;
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }

    .tool-card:not(.coming-soon):hover {
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
      transform: translateY(-4px);
    }

    .tool-card.coming-soon {
      opacity: 0.7;
      cursor: not-allowed;
    }

    .tool-icon-container {
      padding: 2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      height: 150px;
    }

    .tool-icon-container.icon-test-gen {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .tool-icon-container.icon-ui-test {
      background: linear-gradient(135deg, #3498DB 0%, #2980b9 100%);
    }

    .tool-icon-container.icon-api-test {
      background: linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%);
    }

    .tool-icon-container.icon-data-test {
      background: linear-gradient(135deg, #27AE60 0%, #229954 100%);
    }

    .tool-icon-container.icon-ibmi-test {
      background: linear-gradient(135deg, #E67E22 0%, #d35400 100%);
    }

    .tool-icon-container.icon-workflow-builder {
      background: linear-gradient(135deg, #16a085 0%, #138d75 100%);
    }

    .tool-icon-container.icon-report-gen {
      background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    }

    .tool-icon-container.icon-ai-assistant {
      background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
    }

    .tool-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: white;
    }

    .tool-content {
      padding: 1.5rem;
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .tool-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }

    .tool-header h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0;
      flex: 1;
    }

    .coming-soon-chip {
      background-color: #fef3c7;
      color: #92400e;
      font-size: 0.75rem;
      font-weight: 600;
    }

    .tool-description {
      color: #6b7280;
      font-size: 0.875rem;
      line-height: 1.6;
      margin: 0 0 1.5rem 0;
      flex: 1;
    }

    .tool-footer {
      margin-top: auto;
    }

    .tool-footer button {
      width: 100%;
    }

    .tool-footer button mat-icon {
      margin-right: 0.5rem;
    }
  `]
})
export class TestToolsComponent {
  categories = ['Test Generation', 'Test Execution', 'Analysis & Reporting', 'Utilities'];

  tools: Tool[] = [
    {
      id: 'test-gen',
      name: 'Standalone Test Generator',
      description: 'Generate comprehensive test scenarios using AI without creating a full project. Perfect for quick testing needs.',
      icon: 'auto_awesome',
      route: '/test-gen',
      category: 'Test Generation',
      status: 'available'
    },
    {
      id: 'ui-test',
      name: 'UI Test Creator',
      description: 'Create and configure UI testing workflows with Playwright. Supports multiple browsers and visual testing.',
      icon: 'web',
      route: '/projects/create',
      category: 'Test Generation',
      status: 'available'
    },
    {
      id: 'api-test',
      name: 'API Test Creator',
      description: 'Design and execute REST API tests. Validate endpoints, payloads, and response schemas.',
      icon: 'api',
      route: '/projects/create',
      category: 'Test Generation',
      status: 'available'
    },
    {
      id: 'data-test',
      name: 'Data Testing Suite',
      description: 'Validate database integrity, perform data migration testing, and ensure data consistency.',
      icon: 'table_chart',
      route: '/projects/create',
      category: 'Test Generation',
      status: 'available'
    },
    {
      id: 'ibmi-test',
      name: 'IBM i Testing',
      description: 'Specialized tools for testing legacy IBM i systems and mainframe applications.',
      icon: 'storage',
      route: '/projects/create',
      category: 'Test Generation',
      status: 'available'
    },
    {
      id: 'workflow-builder',
      name: 'Workflow Builder',
      description: 'Create custom test workflows with drag-and-drop interface. Combine multiple test types.',
      icon: 'account_tree',
      route: '/workflows',
      category: 'Test Execution',
      status: 'coming-soon'
    },
    {
      id: 'report-gen',
      name: 'Report Generator',
      description: 'Generate comprehensive test reports with visualizations, metrics, and insights.',
      icon: 'assessment',
      route: '/reports',
      category: 'Analysis & Reporting',
      status: 'coming-soon'
    },
    {
      id: 'ai-assistant',
      name: 'AI Testing Assistant',
      description: 'Get AI-powered suggestions for test scenarios, bug analysis, and optimization recommendations.',
      icon: 'psychology',
      route: '/ai-assistant',
      category: 'Utilities',
      status: 'coming-soon'
    }
  ];

  getToolsByCategory(category: string): Tool[] {
    return this.tools.filter(tool => tool.category === category);
  }
}
