import { Routes } from '@angular/router';
import { TestToolsComponent } from './test-tools.component';

export const TEST_TOOLS_ROUTES: Routes = [
  {
    path: '',
    component: TestToolsComponent
  }
];
