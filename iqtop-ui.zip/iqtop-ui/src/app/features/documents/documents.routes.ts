import { Routes } from '@angular/router';

export const DOCUMENTS_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./document-library/document-library.component').then(m => m.DocumentLibraryComponent)
  }
];
