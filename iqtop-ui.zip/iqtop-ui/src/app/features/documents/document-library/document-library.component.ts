import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatChipsModule } from '@angular/material/chips';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTreeModule } from '@angular/material/tree';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule } from '@angular/forms';

interface DocumentNode {
  name: string;
  type: 'folder' | 'file';
  size?: string;
  uploadedBy?: string;
  uploadedDate?: Date;
  children?: DocumentNode[];
  expanded?: boolean;
}

@Component({
  selector: 'app-document-library',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatChipsModule,
    MatInputModule,
    MatFormFieldModule,
    MatTreeModule,
    MatTooltipModule
  ],
  template: `
    <div class="document-library-page">
      <div class="page-header">
        <div class="header-content">
          <div class="title-section">
            <mat-icon class="page-icon">psychology</mat-icon>
            <div>
              <h1>Knowledge Base</h1>
              <p class="subtitle">
                Upload domain documents and context for AI agents • Documents are automatically vectorized for RAG
              </p>
              <div class="info-badges">
                <mat-chip class="info-chip">
                  <mat-icon>auto_awesome</mat-icon>
                  AI-Powered Context
                </mat-chip>
                <mat-chip class="info-chip">
                  <mat-icon>storage</mat-icon>
                  Vector Database
                </mat-chip>
                <mat-chip class="info-chip">
                  <mat-icon>school</mat-icon>
                  Domain Knowledge
                </mat-chip>
              </div>
            </div>
          </div>
        </div>
        <button mat-raised-button color="primary" (click)="fileInput.click()" class="upload-btn">
          <mat-icon>cloud_upload</mat-icon>
          Upload Domain Documents
        </button>
        <input #fileInput type="file" multiple hidden (change)="onFileSelected($event)"
          accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.xls,.xlsx,.txt,.md,.csv">
      </div>

      <div class="content-layout">
        <!-- Folder Tree Navigation -->
        <mat-card class="navigation-card">
          <div class="nav-header">
            <h2>Folders</h2>
            <button mat-icon-button matTooltip="New Folder" (click)="createFolder()">
              <mat-icon>create_new_folder</mat-icon>
            </button>
          </div>

          <mat-form-field appearance="outline" class="search-field">
            <mat-label>Search documents</mat-label>
            <input matInput [(ngModel)]="searchQuery" (ngModelChange)="filterDocuments()"
              placeholder="Search by name...">
            <mat-icon matPrefix>search</mat-icon>
          </mat-form-field>

          <div class="folder-tree">
            <div *ngFor="let node of filteredDocuments" class="tree-node">
              <div class="node-content" [class.selected]="selectedNode === node"
                (click)="selectNode(node)">
                <button mat-icon-button *ngIf="node.type === 'folder'"
                  class="expand-button" (click)="toggleExpand(node); $event.stopPropagation()">
                  <mat-icon>{{ node.expanded ? 'expand_more' : 'chevron_right' }}</mat-icon>
                </button>
                <mat-icon class="node-icon" [class.folder]="node.type === 'folder'">
                  {{ getNodeIcon(node) }}
                </mat-icon>
                <span class="node-name">{{ node.name }}</span>
                <span *ngIf="node.type === 'folder'" class="node-count">
                  ({{ getChildCount(node) }})
                </span>
              </div>
              <div *ngIf="node.expanded && node.children" class="node-children">
                <ng-container *ngTemplateOutlet="treeTemplate; context: { $implicit: node.children }">
                </ng-container>
              </div>
            </div>
          </div>

          <ng-template #treeTemplate let-nodes>
            <div *ngFor="let node of nodes" class="tree-node child-node">
              <div class="node-content" [class.selected]="selectedNode === node"
                (click)="selectNode(node)">
                <button mat-icon-button *ngIf="node.type === 'folder'"
                  class="expand-button" (click)="toggleExpand(node); $event.stopPropagation()">
                  <mat-icon>{{ node.expanded ? 'expand_more' : 'chevron_right' }}</mat-icon>
                </button>
                <mat-icon class="node-icon" [class.folder]="node.type === 'folder'">
                  {{ getNodeIcon(node) }}
                </mat-icon>
                <span class="node-name">{{ node.name }}</span>
                <span *ngIf="node.type === 'folder'" class="node-count">
                  ({{ getChildCount(node) }})
                </span>
              </div>
              <div *ngIf="node.expanded && node.children" class="node-children">
                <ng-container *ngTemplateOutlet="treeTemplate; context: { $implicit: node.children }">
                </ng-container>
              </div>
            </div>
          </ng-template>
        </mat-card>

        <!-- Document Details View -->
        <div class="details-section">
          <mat-card class="details-card" *ngIf="!selectedNode">
            <div class="empty-state">
              <mat-icon>folder_open</mat-icon>
              <h3>No Document Selected</h3>
              <p>Select a document from the left to view details or upload new documents</p>
            </div>
          </mat-card>

          <mat-card class="details-card" *ngIf="selectedNode && selectedNode.type === 'folder'">
            <div class="folder-details">
              <mat-icon class="large-icon">folder</mat-icon>
              <h2>{{ selectedNode.name }}</h2>
              <p class="folder-meta">
                {{ getChildCount(selectedNode) }} items
              </p>

              <div class="folder-actions">
                <button mat-raised-button color="primary" (click)="fileInput.click()">
                  <mat-icon>cloud_upload</mat-icon>
                  Upload to this folder
                </button>
                <button mat-button>
                  <mat-icon>create_new_folder</mat-icon>
                  New Subfolder
                </button>
              </div>

              <div class="folder-contents" *ngIf="selectedNode.children && selectedNode.children.length > 0">
                <h3>Contents</h3>
                <div class="contents-grid">
                  <div *ngFor="let child of selectedNode.children" class="content-item"
                    (click)="selectNode(child)">
                    <mat-icon>{{ getNodeIcon(child) }}</mat-icon>
                    <span>{{ child.name }}</span>
                  </div>
                </div>
              </div>
            </div>
          </mat-card>

          <mat-card class="details-card" *ngIf="selectedNode && selectedNode.type === 'file'">
            <div class="file-details">
              <div class="file-header">
                <div class="file-icon-large">
                  <mat-icon>{{ getNodeIcon(selectedNode) }}</mat-icon>
                </div>
                <div class="file-info">
                  <h2>{{ selectedNode.name }}</h2>
                  <div class="file-meta">
                    <mat-chip class="meta-chip">
                      <mat-icon>storage</mat-icon>
                      {{ selectedNode.size }}
                    </mat-chip>
                    <mat-chip class="meta-chip">
                      <mat-icon>person</mat-icon>
                      {{ selectedNode.uploadedBy }}
                    </mat-chip>
                    <mat-chip class="meta-chip">
                      <mat-icon>schedule</mat-icon>
                      {{ selectedNode.uploadedDate | date: 'MMM d, y' }}
                    </mat-chip>
                  </div>
                </div>
              </div>

              <div class="file-actions">
                <button mat-raised-button color="primary">
                  <mat-icon>download</mat-icon>
                  Download
                </button>
                <button mat-button>
                  <mat-icon>share</mat-icon>
                  Share
                </button>
                <button mat-button color="warn">
                  <mat-icon>delete</mat-icon>
                  Delete
                </button>
              </div>

              <div class="file-preview">
                <h3>Preview</h3>
                <div class="preview-placeholder">
                  <mat-icon>visibility</mat-icon>
                  <p>Preview not available for this file type</p>
                  <button mat-button color="primary">
                    <mat-icon>open_in_new</mat-icon>
                    Open in new tab
                  </button>
                </div>
              </div>
            </div>
          </mat-card>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .document-library-page {
      max-width: 1400px;
      margin: 0 auto;
    }

    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 2.5rem;
      padding: 2rem;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 1rem;
      color: white;
    }

    .header-content {
      flex: 1;
    }

    .title-section {
      display: flex;
      gap: 1.5rem;
      align-items: flex-start;
    }

    .page-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      flex-shrink: 0;
    }

    .page-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: white;
      margin: 0 0 0.75rem 0;
    }

    .subtitle {
      color: rgba(255, 255, 255, 0.95);
      font-size: 1rem;
      margin: 0 0 1rem 0;
      line-height: 1.6;
    }

    .info-badges {
      display: flex;
      gap: 0.75rem;
      flex-wrap: wrap;
    }

    .info-chip {
      background: rgba(255, 255, 255, 0.2);
      color: white;
      border: 1px solid rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(10px);
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem 1rem;
      font-size: 0.875rem;
    }

    .info-chip mat-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
    }

    .upload-btn {
      height: 48px;
      font-size: 1rem;
      font-weight: 500;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .upload-btn mat-icon {
      margin-right: 0.5rem;
    }

    .content-layout {
      display: grid;
      grid-template-columns: 350px 1fr;
      gap: 2rem;
    }

    @media (max-width: 1200px) {
      .content-layout {
        grid-template-columns: 1fr;
      }
    }

    .navigation-card {
      padding: 1.5rem;
      height: fit-content;
      position: sticky;
      top: 2rem;
      max-height: calc(100vh - 4rem);
      display: flex;
      flex-direction: column;
    }

    .nav-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }

    .nav-header h2 {
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0;
    }

    .search-field {
      width: 100%;
      margin-bottom: 1rem;
    }

    .folder-tree {
      flex: 1;
      overflow-y: auto;
    }

    .tree-node {
      margin-bottom: 0.25rem;
    }

    .child-node {
      margin-left: 1.5rem;
    }

    .node-content {
      display: flex;
      align-items: center;
      padding: 0.5rem;
      border-radius: 0.375rem;
      cursor: pointer;
      transition: background-color 0.2s ease;
    }

    .node-content:hover {
      background-color: #f3f4f6;
    }

    .node-content.selected {
      background-color: #e0f2fe;
      color: #0c4a6e;
    }

    .expand-button {
      width: 28px;
      height: 28px;
      line-height: 28px;
      margin-right: 0.25rem;
    }

    .expand-button mat-icon {
      font-size: 20px;
      width: 20px;
      height: 20px;
    }

    .node-icon {
      margin-right: 0.5rem;
      font-size: 20px;
      width: 20px;
      height: 20px;
      color: #6b7280;
    }

    .node-icon.folder {
      color: #f59e0b;
    }

    .node-name {
      flex: 1;
      font-size: 0.875rem;
      font-weight: 500;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .node-count {
      font-size: 0.75rem;
      color: #6b7280;
      margin-left: 0.5rem;
    }

    .node-children {
      margin-top: 0.25rem;
    }

    .details-section {
      min-height: 400px;
    }

    .details-card {
      padding: 2rem;
    }

    .empty-state {
      text-align: center;
      color: #6b7280;
      padding: 3rem 0;
    }

    .empty-state mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      margin-bottom: 1rem;
      color: #d1d5db;
    }

    .empty-state h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .empty-state p {
      font-size: 0.875rem;
    }

    .folder-details {
      text-align: center;
    }

    .large-icon {
      font-size: 96px;
      width: 96px;
      height: 96px;
      color: #f59e0b;
      margin: 0 auto 1rem;
    }

    .folder-details h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .folder-meta {
      color: #6b7280;
      font-size: 0.875rem;
      margin: 0 0 2rem 0;
    }

    .folder-actions {
      display: flex;
      gap: 1rem;
      justify-content: center;
      margin-bottom: 2rem;
    }

    .folder-actions button mat-icon {
      margin-right: 0.5rem;
    }

    .folder-contents {
      text-align: left;
      margin-top: 2rem;
      padding-top: 2rem;
      border-top: 1px solid #e5e7eb;
    }

    .folder-contents h3 {
      font-size: 1rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1rem 0;
    }

    .contents-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 1rem;
    }

    .content-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 1rem;
      border: 1px solid #e5e7eb;
      border-radius: 0.5rem;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .content-item:hover {
      background-color: #f9fafb;
      border-color: #2C3E50;
    }

    .content-item mat-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      color: #6b7280;
      margin-bottom: 0.5rem;
    }

    .content-item span {
      font-size: 0.75rem;
      text-align: center;
      word-break: break-word;
    }

    .file-details {
      text-align: left;
    }

    .file-header {
      display: flex;
      gap: 1.5rem;
      margin-bottom: 2rem;
      padding-bottom: 2rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .file-icon-large {
      flex-shrink: 0;
    }

    .file-icon-large mat-icon {
      font-size: 80px;
      width: 80px;
      height: 80px;
      color: #3b82f6;
    }

    .file-info {
      flex: 1;
    }

    .file-info h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1rem 0;
    }

    .file-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }

    .meta-chip {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background-color: #f3f4f6;
      border: 1px solid #e5e7eb;
    }

    .meta-chip mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }

    .file-actions {
      display: flex;
      gap: 1rem;
      margin-bottom: 2rem;
    }

    .file-actions button mat-icon {
      margin-right: 0.5rem;
    }

    .file-preview {
      margin-top: 2rem;
      padding-top: 2rem;
      border-top: 1px solid #e5e7eb;
    }

    .file-preview h3 {
      font-size: 1rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1rem 0;
    }

    .preview-placeholder {
      background-color: #f9fafb;
      border: 2px dashed #d1d5db;
      border-radius: 0.5rem;
      padding: 3rem;
      text-align: center;
      color: #6b7280;
    }

    .preview-placeholder mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #d1d5db;
      margin-bottom: 1rem;
    }

    .preview-placeholder p {
      margin: 0 0 1rem 0;
    }

    .preview-placeholder button mat-icon {
      margin-right: 0.5rem;
    }
  `]
})
export class DocumentLibraryComponent implements OnInit {
  searchQuery = '';
  selectedNode: DocumentNode | null = null;

  documents: DocumentNode[] = [
    {
      name: 'Domain Knowledge',
      type: 'folder',
      expanded: true,
      children: [
        {
          name: 'Business Process Documentation.pdf',
          type: 'file',
          size: '3.2 MB',
          uploadedBy: 'Sarah Chen (SME)',
          uploadedDate: new Date('2024-01-15')
        },
        {
          name: 'Industry Standards & Compliance.docx',
          type: 'file',
          size: '2.1 MB',
          uploadedBy: 'Michael Torres (Domain Expert)',
          uploadedDate: new Date('2024-01-18')
        },
        {
          name: 'Terminology Glossary.pdf',
          type: 'file',
          size: '1.5 MB',
          uploadedBy: 'Emily Watson (SME)',
          uploadedDate: new Date('2024-01-20')
        }
      ]
    },
    {
      name: 'Technical Context',
      type: 'folder',
      expanded: false,
      children: [
        {
          name: 'API Documentation.pdf',
          type: 'file',
          size: '4.2 MB',
          uploadedBy: 'David Lee',
          uploadedDate: new Date('2024-01-10')
        },
        {
          name: 'System Architecture.pdf',
          type: 'file',
          size: '5.8 MB',
          uploadedBy: 'Alice Johnson',
          uploadedDate: new Date('2024-01-12')
        },
        {
          name: 'Database Schema.pdf',
          type: 'file',
          size: '2.3 MB',
          uploadedBy: 'Bob Smith',
          uploadedDate: new Date('2024-01-14')
        }
      ]
    },
    {
      name: 'Requirements & Specifications',
      type: 'folder',
      expanded: false,
      children: [
        {
          name: 'Product Requirements.pdf',
          type: 'file',
          size: '2.4 MB',
          uploadedBy: 'Alice Johnson',
          uploadedDate: new Date('2024-01-15')
        },
        {
          name: 'Functional Specifications.docx',
          type: 'file',
          size: '3.1 MB',
          uploadedBy: 'Bob Smith',
          uploadedDate: new Date('2024-01-18')
        }
      ]
    },
    {
      name: 'Design Assets',
      type: 'folder',
      expanded: false,
      children: [
        {
          name: 'UI Mockups',
          type: 'folder',
          expanded: false,
          children: [
            {
              name: 'Homepage Design.fig',
              type: 'file',
              size: '5.2 MB',
              uploadedBy: 'Carol White',
              uploadedDate: new Date('2024-01-20')
            },
            {
              name: 'Checkout Flow.png',
              type: 'file',
              size: '1.1 MB',
              uploadedBy: 'Carol White',
              uploadedDate: new Date('2024-01-21')
            }
          ]
        }
      ]
    },
    {
      name: 'Test Artifacts',
      type: 'folder',
      expanded: false,
      children: [
        {
          name: 'Test Reports',
          type: 'folder',
          children: [
            {
              name: 'Sprint 1 Test Report.pdf',
              type: 'file',
              size: '3.5 MB',
              uploadedBy: 'John Doe',
              uploadedDate: new Date('2024-01-22')
            }
          ]
        }
      ]
    }
  ];

  filteredDocuments: DocumentNode[] = [];

  ngOnInit(): void {
    this.filteredDocuments = this.documents;
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      console.log('Files selected:', input.files);
      // Implementation would upload files to the server
    }
  }

  selectNode(node: DocumentNode): void {
    this.selectedNode = node;
  }

  toggleExpand(node: DocumentNode): void {
    node.expanded = !node.expanded;
  }

  getNodeIcon(node: DocumentNode): string {
    if (node.type === 'folder') return 'folder';

    const extension = node.name.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf': return 'picture_as_pdf';
      case 'doc':
      case 'docx': return 'description';
      case 'xls':
      case 'xlsx': return 'table_chart';
      case 'png':
      case 'jpg':
      case 'jpeg': return 'image';
      case 'fig': return 'design_services';
      default: return 'insert_drive_file';
    }
  }

  getChildCount(node: DocumentNode): number {
    return node.children?.length || 0;
  }

  createFolder(): void {
    console.log('Creating new folder...');
    // Implementation would create a new folder
  }

  filterDocuments(): void {
    if (!this.searchQuery.trim()) {
      this.filteredDocuments = this.documents;
      return;
    }

    const query = this.searchQuery.toLowerCase();
    this.filteredDocuments = this.filterNodes(this.documents, query);
  }

  private filterNodes(nodes: DocumentNode[], query: string): DocumentNode[] {
    const filtered: DocumentNode[] = [];

    for (const node of nodes) {
      if (node.name.toLowerCase().includes(query)) {
        filtered.push({ ...node, expanded: true });
      } else if (node.children) {
        const filteredChildren = this.filterNodes(node.children, query);
        if (filteredChildren.length > 0) {
          filtered.push({ ...node, children: filteredChildren, expanded: true });
        }
      }
    }

    return filtered;
  }
}
