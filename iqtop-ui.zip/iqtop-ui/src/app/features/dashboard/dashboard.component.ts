import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TableModule } from 'primeng/table';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { WorkflowSummary } from '../../core/models';
import { selectAllWorkflows, selectWorkflowLoading } from '../../store/workflow/workflow.selectors';
import * as WorkflowActions from '../../store/workflow/workflow.actions';
import * as ProjectActions from '../../store/project/project.actions';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatProgressSpinnerModule,
    TableModule,
    CardModule,
    ButtonModule
  ],
  template: `
    <div class="dashboard">
      <div class="dashboard-header">
        <h1>Dashboard</h1>
        <p class="subtitle">Monitor your testing projects and workflow statistics</p>
      </div>

      <div class="stats-container">
        <mat-card class="stat-card">
          <mat-card-content>
            <div class="stat-content">
              <div class="stat-text">
                <p class="stat-label">Active Projects</p>
                <h3 class="stat-value">12</h3>
              </div>
              <div class="stat-icon primary">
                <mat-icon>folder_open</mat-icon>
              </div>
            </div>
          </mat-card-content>
        </mat-card>

        <mat-card class="stat-card">
          <mat-card-content>
            <div class="stat-content">
              <div class="stat-text">
                <p class="stat-label">Total Workflows</p>
                <h3 class="stat-value">{{ (workflows$ | async)?.length || 48 }}</h3>
              </div>
              <div class="stat-icon success">
                <mat-icon>play_arrow</mat-icon>
              </div>
            </div>
          </mat-card-content>
        </mat-card>

        <mat-card class="stat-card">
          <mat-card-content>
            <div class="stat-content">
              <div class="stat-text">
                <p class="stat-label">Tests Run</p>
                <h3 class="stat-value">1,234</h3>
              </div>
              <div class="stat-icon info">
                <mat-icon>science</mat-icon>
              </div>
            </div>
          </mat-card-content>
        </mat-card>

        <mat-card class="stat-card">
          <mat-card-content>
            <div class="stat-content">
              <div class="stat-text">
                <p class="stat-label">Defects Logged</p>
                <h3 class="stat-value">89</h3>
              </div>
              <div class="stat-icon danger">
                <mat-icon>bug_report</mat-icon>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <div class="cta-section">
        <h2>Ready to Start Testing?</h2>
        <p>Navigate to your projects to create new workflows, manage test types, and assign work to your team.</p>
        <button mat-raised-button color="primary" routerLink="/projects" class="cta-button">
          Go to Projects
          <mat-icon>arrow_forward</mat-icon>
        </button>
      </div>

    </div>
  `,
  styles: [`
    .dashboard {
      max-width: 1280px;
      margin: 0 auto;
    }

    .dashboard-header {
      margin-bottom: 2rem;
    }

    .dashboard-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .dashboard-header .subtitle {
      color: #6b7280;
      font-size: 1rem;
      margin: 0;
    }

    .stats-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .stat-card {
      transition: box-shadow 0.2s ease;
    }

    .stat-card:hover {
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .stat-card mat-card-content {
      padding: 1.5rem;
    }

    .stat-content {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
    }

    .stat-text {
      flex: 1;
    }

    .stat-label {
      font-size: 0.875rem;
      color: #6b7280;
      margin: 0 0 0.25rem 0;
      font-weight: 400;
    }

    .stat-value {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0;
      line-height: 1;
    }

    .stat-icon {
      width: 48px;
      height: 48px;
      border-radius: 0.5rem;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    .stat-icon mat-icon {
      font-size: 24px;
      width: 24px;
      height: 24px;
      color: white;
    }

    .stat-icon.primary {
      background-color: rgba(44, 62, 80, 0.1);
    }

    .stat-icon.primary mat-icon {
      color: #2C3E50;
    }

    .stat-icon.success {
      background-color: rgba(39, 174, 96, 0.1);
    }

    .stat-icon.success mat-icon {
      color: #27AE60;
    }

    .stat-icon.info {
      background-color: rgba(52, 152, 219, 0.1);
    }

    .stat-icon.info mat-icon {
      color: #3498DB;
    }

    .stat-icon.danger {
      background-color: rgba(231, 76, 60, 0.1);
    }

    .stat-icon.danger mat-icon {
      color: #E74C3C;
    }

    .cta-section {
      background: linear-gradient(135deg, rgba(44, 62, 80, 0.1) 0%, rgba(44, 62, 80, 0.05) 100%);
      border: 1px solid #e5e7eb;
      border-radius: 0.5rem;
      padding: 3rem 2rem;
      text-align: center;
      margin-top: 2rem;
    }

    .cta-section h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1rem 0;
    }

    .cta-section p {
      color: #6b7280;
      font-size: 1rem;
      max-width: 42rem;
      margin: 0 auto 1.5rem;
      line-height: 1.6;
    }

    .cta-button {
      height: 3rem;
      padding: 0 2rem;
      font-size: 1rem;
      font-weight: 500;
    }

    .cta-button mat-icon {
      margin-left: 0.5rem;
      font-size: 1rem;
      width: 1rem;
      height: 1rem;
    }
  `]
})
export class DashboardComponent implements OnInit {
  workflows$: Observable<WorkflowSummary[]>;
  loading$: Observable<boolean>;

  constructor(private store: Store) {
    this.workflows$ = this.store.select(selectAllWorkflows);
    this.loading$ = this.store.select(selectWorkflowLoading);
  }

  ngOnInit(): void {
    this.store.dispatch(WorkflowActions.loadWorkflows({}));
    this.store.dispatch(ProjectActions.loadProjects());
  }

  getStatusClass(status: string): string {
    if (status.includes('completed')) return 'completed';
    if (status.includes('failed')) return 'failed';
    if (status.includes('awaiting')) return 'waiting';
    if (status.includes('pending')) return 'pending';
    return 'running';
  }
}
