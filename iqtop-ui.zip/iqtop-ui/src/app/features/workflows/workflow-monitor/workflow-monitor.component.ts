import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subject, takeUntil, interval } from 'rxjs';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule } from '@angular/forms';
import { SocketService } from '../../../core/services/socket.service';
import * as WorkflowActions from '../../../store/workflow/workflow.actions';

interface PhaseInfo {
  phaseNumber: number;
  name: string;
  description: string;
  status: 'completed' | 'running' | 'pending' | 'failed' | 'awaiting_review';
  startTime?: Date;
  endTime?: Date;
  duration?: string;
  logs: string[];
}

interface WorkflowInfo {
  id: string;
  projectName: string;
  testType: string;
  status: string;
  createdBy: string;
  createdAt: Date;
  currentPhase: number;
}

interface TestScenario {
  scenario_id: string;
  title: string;
  description: string;
  steps: string[];
  expected_result: string;
  priority: 'high' | 'medium' | 'low';
  status: 'approved' | 'pending' | 'rejected' | 'edited';
  isEditing?: boolean;
}

@Component({
  selector: 'app-workflow-monitor',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    FormsModule,
    MatCardModule,
    MatProgressBarModule,
    MatIconModule,
    MatButtonModule,
    MatChipsModule,
    MatExpansionModule,
    MatTableModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDialogModule,
    MatTooltipModule
  ],
  template: `
    <div class="workflow-monitor-page">
      <button mat-button routerLink="/projects" class="back-button">
        <mat-icon>arrow_back</mat-icon>
        Back to Projects
      </button>

      <div class="page-header">
        <div>
          <h1>Workflow Monitor</h1>
          <p class="subtitle">Real-time execution tracking with 8-phase orchestration</p>
        </div>
        <mat-chip [class]="'status-chip ' + getStatusClass()">
          {{ workflowInfo.status }}
        </mat-chip>
      </div>

      <!-- Workflow Overview -->
      <mat-card class="overview-card">
        <div class="overview-grid">
          <div class="overview-item">
            <span class="overview-label">Project</span>
            <span class="overview-value">{{ workflowInfo.projectName }}</span>
          </div>
          <div class="overview-item">
            <span class="overview-label">Test Type</span>
            <span class="overview-value">{{ workflowInfo.testType }}</span>
          </div>
          <div class="overview-item">
            <span class="overview-label">Created By</span>
            <span class="overview-value">{{ workflowInfo.createdBy }}</span>
          </div>
          <div class="overview-item">
            <span class="overview-label">Started</span>
            <span class="overview-value">{{ workflowInfo.createdAt | date: 'MMM d, y h:mm a' }}</span>
          </div>
        </div>

        <div class="progress-section">
          <div class="progress-header">
            <span class="progress-label">Overall Progress</span>
            <span class="progress-percentage">{{ getProgressPercentage() }}%</span>
          </div>
          <mat-progress-bar mode="determinate" [value]="getProgressPercentage()"></mat-progress-bar>
        </div>
      </mat-card>

      <!-- Human Approval Interface (Phase 2) -->
      <mat-card *ngIf="isAwaitingApproval()" class="approval-card">
        <div class="approval-header">
          <div class="approval-title-section">
            <mat-icon class="approval-icon">rate_review</mat-icon>
            <div>
              <h2>Test Scenarios Awaiting Your Review</h2>
              <p class="approval-subtitle">
                AI has generated {{ testScenarios.length }} test scenarios. Please review, edit if needed, and approve to continue.
              </p>
            </div>
          </div>
          <div class="approval-stats">
            <div class="stat-item">
              <span class="stat-number">{{ getScenarioCount('approved') }}</span>
              <span class="stat-label">Approved</span>
            </div>
            <div class="stat-item">
              <span class="stat-number">{{ getScenarioCount('pending') }}</span>
              <span class="stat-label">Pending</span>
            </div>
            <div class="stat-item">
              <span class="stat-number">{{ getScenarioCount('rejected') }}</span>
              <span class="stat-label">Rejected</span>
            </div>
          </div>
        </div>

        <div class="scenarios-container">
          <div *ngFor="let scenario of testScenarios; let i = index" class="scenario-review-card"
            [class.approved]="scenario.status === 'approved'"
            [class.rejected]="scenario.status === 'rejected'"
            [class.edited]="scenario.status === 'edited'">

            <div class="scenario-review-header">
              <div class="scenario-number">
                <mat-icon *ngIf="scenario.status === 'approved'" class="status-icon approved">check_circle</mat-icon>
                <mat-icon *ngIf="scenario.status === 'rejected'" class="status-icon rejected">cancel</mat-icon>
                <mat-icon *ngIf="scenario.status === 'edited'" class="status-icon edited">edit</mat-icon>
                <span *ngIf="scenario.status === 'pending'">#{{ i + 1 }}</span>
              </div>

              <div class="scenario-content-header">
                <mat-form-field *ngIf="scenario.isEditing" appearance="outline" class="title-field">
                  <input matInput [(ngModel)]="scenario.title" placeholder="Scenario Title">
                </mat-form-field>
                <h3 *ngIf="!scenario.isEditing">{{ scenario.title }}</h3>

                <div class="scenario-meta">
                  <mat-chip [class]="'priority-chip priority-' + scenario.priority">
                    {{ scenario.priority }}
                  </mat-chip>
                  <span class="scenario-id">{{ scenario.scenario_id }}</span>
                </div>
              </div>

              <div class="scenario-actions">
                <button mat-icon-button (click)="toggleEdit(scenario)"
                  matTooltip="{{ scenario.isEditing ? 'Save' : 'Edit' }}"
                  [color]="scenario.isEditing ? 'primary' : ''">
                  <mat-icon>{{ scenario.isEditing ? 'save' : 'edit' }}</mat-icon>
                </button>
                <button mat-icon-button (click)="approveScenario(scenario)"
                  matTooltip="Approve"
                  [disabled]="scenario.status === 'approved'"
                  color="primary">
                  <mat-icon>check_circle</mat-icon>
                </button>
                <button mat-icon-button (click)="rejectScenario(scenario)"
                  matTooltip="Reject"
                  [disabled]="scenario.status === 'rejected'"
                  color="warn">
                  <mat-icon>cancel</mat-icon>
                </button>
              </div>
            </div>

            <div class="scenario-review-body">
              <div class="review-section">
                <label class="section-label">Description</label>
                <mat-form-field *ngIf="scenario.isEditing" appearance="outline" class="full-width">
                  <textarea matInput [(ngModel)]="scenario.description" rows="2"></textarea>
                </mat-form-field>
                <p *ngIf="!scenario.isEditing" class="scenario-description">{{ scenario.description }}</p>
              </div>

              <div class="review-section">
                <label class="section-label">Test Steps</label>
                <div *ngIf="scenario.isEditing" class="steps-edit">
                  <div *ngFor="let step of scenario.steps; let j = index" class="step-edit-row">
                    <span class="step-number">{{ j + 1 }}</span>
                    <mat-form-field appearance="outline" class="step-field">
                      <input matInput [(ngModel)]="scenario.steps[j]" placeholder="Step {{ j + 1 }}">
                    </mat-form-field>
                    <button mat-icon-button (click)="removeStep(scenario, j)" color="warn" class="remove-step-btn">
                      <mat-icon>delete</mat-icon>
                    </button>
                  </div>
                  <button mat-button (click)="addStep(scenario)" class="add-step-btn">
                    <mat-icon>add</mat-icon>
                    Add Step
                  </button>
                </div>
                <ol *ngIf="!scenario.isEditing" class="test-steps">
                  <li *ngFor="let step of scenario.steps">{{ step }}</li>
                </ol>
              </div>

              <div class="review-section">
                <label class="section-label">Expected Result</label>
                <mat-form-field *ngIf="scenario.isEditing" appearance="outline" class="full-width">
                  <textarea matInput [(ngModel)]="scenario.expected_result" rows="2"></textarea>
                </mat-form-field>
                <div *ngIf="!scenario.isEditing" class="expected-result">{{ scenario.expected_result }}</div>
              </div>

              <div class="review-section" *ngIf="scenario.isEditing">
                <label class="section-label">Priority</label>
                <mat-form-field appearance="outline">
                  <mat-select [(ngModel)]="scenario.priority">
                    <mat-option value="high">High</mat-option>
                    <mat-option value="medium">Medium</mat-option>
                    <mat-option value="low">Low</mat-option>
                  </mat-select>
                </mat-form-field>
              </div>
            </div>
          </div>
        </div>

        <div class="approval-footer">
          <div class="approval-info">
            <mat-icon>info</mat-icon>
            <span>Review all scenarios carefully. You can edit any scenario before approval.</span>
          </div>
          <div class="approval-actions">
            <button mat-button (click)="rejectAllScenarios()" class="reject-all-btn">
              <mat-icon>cancel</mat-icon>
              Reject All & Request Regeneration
            </button>
            <button mat-raised-button color="primary" (click)="submitApproval()"
              [disabled]="!canSubmitApproval()" class="submit-approval-btn">
              <mat-icon>check_circle</mat-icon>
              Approve & Continue Workflow
              <span class="approved-count">({{ getScenarioCount('approved') }}/{{ testScenarios.length }})</span>
            </button>
          </div>
        </div>
      </mat-card>

      <!-- Phase Timeline -->
      <div class="phases-section">
        <h2>Execution Phases</h2>

        <div class="phases-timeline">
          <div *ngFor="let phase of phases; let i = index" class="phase-container">
            <!-- Timeline connector -->
            <div class="timeline-connector" [class.completed]="phase.status === 'completed'">
              <div class="timeline-dot" [class]="phase.status">
                <mat-icon *ngIf="phase.status === 'completed'">check</mat-icon>
                <mat-icon *ngIf="phase.status === 'running'" class="spinning">sync</mat-icon>
                <mat-icon *ngIf="phase.status === 'failed'">close</mat-icon>
                <span *ngIf="phase.status === 'pending'" class="phase-number">{{ phase.phaseNumber }}</span>
              </div>
            </div>

            <!-- Phase Content -->
            <mat-card class="phase-card" [class]="phase.status">
              <div class="phase-header">
                <div class="phase-info">
                  <h3>Phase {{ phase.phaseNumber }}: {{ phase.name }}</h3>
                  <p class="phase-description">{{ phase.description }}</p>
                </div>
                <mat-chip [class]="'phase-status-chip ' + phase.status">
                  {{ phase.status }}
                </mat-chip>
              </div>

              <div *ngIf="phase.status !== 'pending'" class="phase-details">
                <div class="phase-meta">
                  <div class="meta-item" *ngIf="phase.startTime">
                    <mat-icon>schedule</mat-icon>
                    <span>Started: {{ phase.startTime | date: 'h:mm a' }}</span>
                  </div>
                  <div class="meta-item" *ngIf="phase.endTime">
                    <mat-icon>check_circle</mat-icon>
                    <span>Completed: {{ phase.endTime | date: 'h:mm a' }}</span>
                  </div>
                  <div class="meta-item" *ngIf="phase.duration">
                    <mat-icon>timer</mat-icon>
                    <span>Duration: {{ phase.duration }}</span>
                  </div>
                </div>

                <mat-expansion-panel *ngIf="phase.logs.length > 0" class="logs-panel">
                  <mat-expansion-panel-header>
                    <mat-panel-title>
                      <mat-icon>article</mat-icon>
                      Execution Logs ({{ phase.logs.length }})
                    </mat-panel-title>
                  </mat-expansion-panel-header>
                  <div class="logs-content">
                    <div *ngFor="let log of phase.logs" class="log-entry">{{ log }}</div>
                  </div>
                </mat-expansion-panel>
              </div>
            </mat-card>
          </div>
        </div>
      </div>

      <!-- Real-time Updates -->
      <mat-card class="realtime-card" *ngIf="realtimeUpdates.length > 0">
        <h3>
          <mat-icon>notifications_active</mat-icon>
          Real-time Updates
        </h3>
        <div class="updates-list">
          <div *ngFor="let update of realtimeUpdates" class="update-entry">
            <span class="update-time">{{ update.time | date: 'h:mm:ss a' }}</span>
            <span class="update-message">{{ update.message }}</span>
          </div>
        </div>
      </mat-card>
    </div>
  `,
  styles: [`
    .workflow-monitor-page {
      max-width: 1200px;
      margin: 0 auto;
    }

    /* Human Approval Interface Styles */
    .approval-card {
      padding: 0;
      margin-bottom: 2rem;
      border: 2px solid #3498DB;
      box-shadow: 0 4px 12px rgba(52, 152, 219, 0.15);
    }

    .approval-header {
      background: linear-gradient(135deg, #3498DB 0%, #2980b9 100%);
      color: white;
      padding: 2rem;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 2rem;
    }

    .approval-title-section {
      display: flex;
      gap: 1rem;
      flex: 1;
    }

    .approval-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
    }

    .approval-header h2 {
      font-size: 1.75rem;
      font-weight: 600;
      margin: 0 0 0.5rem 0;
    }

    .approval-subtitle {
      font-size: 0.95rem;
      margin: 0;
      opacity: 0.95;
    }

    .approval-stats {
      display: flex;
      gap: 2rem;
      align-items: center;
    }

    .stat-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 0.75rem 1.5rem;
      background: rgba(255, 255, 255, 0.15);
      border-radius: 0.5rem;
      backdrop-filter: blur(10px);
    }

    .stat-number {
      font-size: 2rem;
      font-weight: 700;
      line-height: 1;
      margin-bottom: 0.25rem;
    }

    .stat-label {
      font-size: 0.75rem;
      opacity: 0.9;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .scenarios-container {
      padding: 2rem;
      background: #f9fafb;
      max-height: 600px;
      overflow-y: auto;
    }

    .scenario-review-card {
      background: white;
      border: 2px solid #e5e7eb;
      border-radius: 0.75rem;
      margin-bottom: 1.5rem;
      transition: all 0.3s ease;
      overflow: hidden;
    }

    .scenario-review-card:hover {
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    .scenario-review-card.approved {
      border-color: #27AE60;
      background: linear-gradient(to right, rgba(39, 174, 96, 0.05) 0%, white 20%);
    }

    .scenario-review-card.rejected {
      border-color: #E74C3C;
      background: linear-gradient(to right, rgba(231, 76, 60, 0.05) 0%, white 20%);
      opacity: 0.7;
    }

    .scenario-review-card.edited {
      border-color: #F39C12;
      background: linear-gradient(to right, rgba(243, 156, 18, 0.05) 0%, white 20%);
    }

    .scenario-review-header {
      display: grid;
      grid-template-columns: 60px 1fr auto;
      gap: 1rem;
      padding: 1.5rem;
      align-items: start;
    }

    .scenario-number {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background: #e5e7eb;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.25rem;
      font-weight: 700;
      color: #1f2937;
      flex-shrink: 0;
    }

    .status-icon {
      font-size: 50px !important;
      width: 50px !important;
      height: 50px !important;
    }

    .status-icon.approved {
      color: #27AE60;
    }

    .status-icon.rejected {
      color: #E74C3C;
    }

    .status-icon.edited {
      color: #F39C12;
    }

    .scenario-content-header {
      flex: 1;
      min-width: 0;
    }

    .title-field {
      width: 100%;
      margin: 0;
    }

    .scenario-content-header h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.75rem 0;
    }

    .scenario-meta {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .priority-chip {
      padding: 0.25rem 0.75rem;
      border-radius: 0.25rem;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .priority-chip.priority-high {
      background-color: #fee2e2;
      color: #991b1b;
    }

    .priority-chip.priority-medium {
      background-color: #fef3c7;
      color: #92400e;
    }

    .priority-chip.priority-low {
      background-color: #dbeafe;
      color: #1e40af;
    }

    .scenario-id {
      font-size: 0.75rem;
      color: #6b7280;
      font-family: monospace;
    }

    .scenario-actions {
      display: flex;
      gap: 0.5rem;
    }

    .scenario-review-body {
      padding: 0 1.5rem 1.5rem 1.5rem;
      border-top: 1px solid #e5e7eb;
    }

    .review-section {
      margin-top: 1.5rem;
    }

    .section-label {
      display: block;
      font-size: 0.875rem;
      font-weight: 600;
      color: #374151;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 0.75rem;
    }

    .full-width {
      width: 100%;
    }

    .scenario-description {
      font-size: 0.95rem;
      color: #4b5563;
      line-height: 1.6;
      margin: 0;
    }

    .test-steps {
      margin: 0;
      padding-left: 1.5rem;
      color: #1f2937;
    }

    .test-steps li {
      font-size: 0.95rem;
      line-height: 1.8;
      margin-bottom: 0.5rem;
    }

    .steps-edit {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }

    .step-edit-row {
      display: grid;
      grid-template-columns: 30px 1fr auto;
      gap: 0.75rem;
      align-items: center;
    }

    .step-number {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background: #3498DB;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.875rem;
      font-weight: 600;
      flex-shrink: 0;
    }

    .step-field {
      margin: 0;
    }

    .remove-step-btn {
      flex-shrink: 0;
    }

    .add-step-btn {
      align-self: flex-start;
      margin-left: 45px;
    }

    .expected-result {
      font-size: 0.95rem;
      color: #1f2937;
      line-height: 1.6;
      background: #f0fdf4;
      padding: 1rem;
      border-radius: 0.5rem;
      border-left: 4px solid #27AE60;
    }

    .approval-footer {
      padding: 1.5rem 2rem;
      background: #f9fafb;
      border-top: 2px solid #e5e7eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 2rem;
    }

    .approval-info {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: #6b7280;
      font-size: 0.875rem;
    }

    .approval-info mat-icon {
      color: #3498DB;
    }

    .approval-actions {
      display: flex;
      gap: 1rem;
      align-items: center;
    }

    .reject-all-btn {
      color: #E74C3C;
    }

    .submit-approval-btn {
      height: 48px;
      font-size: 1rem;
      font-weight: 500;
      padding: 0 2rem;
    }

    .submit-approval-btn mat-icon {
      margin-right: 0.5rem;
    }

    .approved-count {
      margin-left: 0.5rem;
      opacity: 0.9;
    }

    @media (max-width: 768px) {
      .approval-header {
        flex-direction: column;
      }

      .approval-stats {
        width: 100%;
        justify-content: space-around;
      }

      .scenario-review-header {
        grid-template-columns: 1fr;
        gap: 1rem;
      }

      .scenario-number {
        margin: 0 auto;
      }

      .scenario-actions {
        justify-content: center;
      }

      .approval-footer {
        flex-direction: column;
        align-items: stretch;
      }

      .approval-actions {
        flex-direction: column;
      }

      .submit-approval-btn {
        width: 100%;
      }
    }

    .back-button {
      margin-bottom: 1.5rem;
      color: #6b7280;
    }

    .back-button mat-icon {
      margin-right: 0.5rem;
    }

    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 2rem;
    }

    .page-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .subtitle {
      color: #6b7280;
      font-size: 1rem;
      margin: 0;
    }

    .status-chip {
      padding: 0.5rem 1rem;
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.875rem;
    }

    .status-chip.running {
      background-color: #dbeafe;
      color: #1e40af;
    }

    .status-chip.completed {
      background-color: #d1fae5;
      color: #065f46;
    }

    .status-chip.failed {
      background-color: #fee2e2;
      color: #991b1b;
    }

    .overview-card {
      padding: 1.5rem;
      margin-bottom: 2rem;
    }

    .overview-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      margin-bottom: 1.5rem;
    }

    .overview-item {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .overview-label {
      font-size: 0.75rem;
      font-weight: 500;
      color: #6b7280;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .overview-value {
      font-size: 1rem;
      font-weight: 600;
      color: #1f2937;
    }

    .progress-section {
      padding-top: 1rem;
      border-top: 1px solid #e5e7eb;
    }

    .progress-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.5rem;
    }

    .progress-label {
      font-size: 0.875rem;
      font-weight: 500;
      color: #6b7280;
    }

    .progress-percentage {
      font-size: 1.25rem;
      font-weight: 700;
      color: #2C3E50;
    }

    .phases-section {
      margin-top: 2rem;
    }

    .phases-section h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1.5rem 0;
    }

    .phases-timeline {
      position: relative;
    }

    .phase-container {
      display: grid;
      grid-template-columns: 60px 1fr;
      gap: 1.5rem;
      margin-bottom: 1.5rem;
    }

    .timeline-connector {
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
    }

    .timeline-connector::after {
      content: '';
      position: absolute;
      top: 50px;
      width: 2px;
      height: calc(100% + 1.5rem);
      background-color: #e5e7eb;
    }

    .timeline-connector.completed::after {
      background-color: #27AE60;
    }

    .phase-container:last-child .timeline-connector::after {
      display: none;
    }

    .timeline-dot {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #e5e7eb;
      color: #6b7280;
      position: relative;
      z-index: 1;
      border: 4px solid white;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .timeline-dot.completed {
      background-color: #27AE60;
      color: white;
    }

    .timeline-dot.running {
      background-color: #3498DB;
      color: white;
    }

    .timeline-dot.failed {
      background-color: #E74C3C;
      color: white;
    }

    .timeline-dot mat-icon {
      font-size: 24px;
      width: 24px;
      height: 24px;
    }

    .spinning {
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    .phase-number {
      font-weight: 700;
      font-size: 1.25rem;
    }

    .phase-card {
      padding: 1.5rem;
      transition: all 0.2s ease;
    }

    .phase-card.running {
      border-left: 4px solid #3498DB;
      background-color: #f0f9ff;
    }

    .phase-card.completed {
      border-left: 4px solid #27AE60;
    }

    .phase-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }

    .phase-info {
      flex: 1;
    }

    .phase-info h3 {
      font-size: 1.125rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .phase-description {
      font-size: 0.875rem;
      color: #6b7280;
      margin: 0;
    }

    .phase-status-chip {
      padding: 0.25rem 0.75rem;
      border-radius: 0.25rem;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .phase-status-chip.completed {
      background-color: #d1fae5;
      color: #065f46;
    }

    .phase-status-chip.running {
      background-color: #dbeafe;
      color: #1e40af;
    }

    .phase-status-chip.pending {
      background-color: #e5e7eb;
      color: #6b7280;
    }

    .phase-status-chip.failed {
      background-color: #fee2e2;
      color: #991b1b;
    }

    .phase-details {
      padding-top: 1rem;
      border-top: 1px solid #e5e7eb;
    }

    .phase-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 1.5rem;
      margin-bottom: 1rem;
    }

    .meta-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.875rem;
      color: #6b7280;
    }

    .meta-item mat-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
    }

    .logs-panel {
      margin-top: 0.5rem;
    }

    ::ng-deep .logs-panel .mat-expansion-panel-header {
      padding: 0.75rem 1rem;
      background-color: #f9fafb;
    }

    ::ng-deep .logs-panel .mat-expansion-panel-header-title {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.875rem;
      font-weight: 500;
    }

    .logs-content {
      padding: 1rem;
      background-color: #1f2937;
      font-family: 'Courier New', monospace;
      font-size: 0.75rem;
      max-height: 300px;
      overflow-y: auto;
    }

    .log-entry {
      color: #d1d5db;
      padding: 0.25rem 0;
      line-height: 1.5;
    }

    .realtime-card {
      padding: 1.5rem;
      margin-top: 2rem;
      background-color: #f9fafb;
    }

    .realtime-card h3 {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 1rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1rem 0;
    }

    .realtime-card h3 mat-icon {
      color: #27AE60;
    }

    .updates-list {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      max-height: 200px;
      overflow-y: auto;
    }

    .update-entry {
      display: flex;
      gap: 1rem;
      padding: 0.5rem;
      background-color: white;
      border-radius: 0.25rem;
      border-left: 3px solid #27AE60;
    }

    .update-time {
      font-size: 0.75rem;
      color: #6b7280;
      min-width: 100px;
    }

    .update-message {
      font-size: 0.875rem;
      color: #1f2937;
    }
  `]
})
export class WorkflowMonitorComponent implements OnInit, OnDestroy {
  workflowId = '';
  private destroy$ = new Subject<void>();

  workflowInfo: WorkflowInfo = {
    id: '',
    projectName: 'E-Commerce Platform',
    testType: 'UI Testing',
    status: 'Phase 3 Executing',
    createdBy: 'John Doe',
    createdAt: new Date(),
    currentPhase: 3
  };

  phases: PhaseInfo[] = [
    {
      phaseNumber: 1,
      name: 'Design Analysis',
      description: 'AI analyzes Figma designs and generates test scenarios',
      status: 'completed',
      startTime: new Date(Date.now() - 3600000),
      endTime: new Date(Date.now() - 3300000),
      duration: '5m 23s',
      logs: [
        '[2024-01-24 10:00:15] Starting design analysis...',
        '[2024-01-24 10:01:42] Fetched Figma design: Homepage v2.3',
        '[2024-01-24 10:02:18] Analyzing components and interactions...',
        '[2024-01-24 10:04:56] Generated 45 test scenarios',
        '[2024-01-24 10:05:38] Phase 1 completed successfully'
      ]
    },
    {
      phaseNumber: 2,
      name: 'Human Approval',
      description: 'Manual review and approval of generated test scenarios',
      status: 'awaiting_review',
      startTime: new Date(Date.now() - 3300000),
      logs: [
        '[2024-01-24 10:05:45] Awaiting human review...',
        '[2024-01-24 10:05:48] Generated 5 test scenarios for review',
        '[2024-01-24 10:05:50] Workflow paused - waiting for tester approval'
      ]
    },
    {
      phaseNumber: 3,
      name: 'Functional Testing',
      description: 'Executing Playwright tests across multiple browsers',
      status: 'pending',
      logs: []
    },
    {
      phaseNumber: 4,
      name: 'Defect Analysis',
      description: 'AI analyzes failures and categorizes defects',
      status: 'pending',
      logs: []
    },
    {
      phaseNumber: 5,
      name: 'Script Generation',
      description: 'Generate reusable test scripts from executed tests',
      status: 'pending',
      logs: []
    },
    {
      phaseNumber: 6,
      name: 'Reporting',
      description: 'Comprehensive test reports with visualizations',
      status: 'pending',
      logs: []
    },
    {
      phaseNumber: 7,
      name: 'Regression Baselining',
      description: 'Establish baseline for future regression testing',
      status: 'pending',
      logs: []
    },
    {
      phaseNumber: 8,
      name: 'GitHub Integration',
      description: 'Commit scripts and reports to repository',
      status: 'pending',
      logs: []
    }
  ];

  realtimeUpdates: { time: Date; message: string }[] = [
    { time: new Date(), message: 'Phase 1 completed: Generated 5 test scenarios' },
    { time: new Date(Date.now() - 30000), message: 'Figma design analysis completed successfully' },
    { time: new Date(Date.now() - 60000), message: 'Rally story fetched: US-12345' }
  ];

  testScenarios: TestScenario[] = [
    {
      scenario_id: 'TC001',
      title: 'User Login with Valid Credentials',
      description: 'Verify that a registered user can successfully log in with valid username and password',
      steps: [
        'Navigate to the login page',
        'Enter valid username in the username field',
        'Enter valid password in the password field',
        'Click on the "Login" button',
        'Verify successful redirect to dashboard'
      ],
      expected_result: 'User is successfully authenticated and redirected to the dashboard page with welcome message displayed',
      priority: 'high',
      status: 'pending',
      isEditing: false
    },
    {
      scenario_id: 'TC002',
      title: 'User Login with Invalid Password',
      description: 'Verify that the system shows an appropriate error message when user enters incorrect password',
      steps: [
        'Navigate to the login page',
        'Enter valid username',
        'Enter an invalid password',
        'Click on the "Login" button',
        'Observe the error message'
      ],
      expected_result: 'System displays "Invalid username or password" error message and user remains on login page',
      priority: 'high',
      status: 'pending',
      isEditing: false
    },
    {
      scenario_id: 'TC003',
      title: 'Product Search Functionality',
      description: 'Verify that users can search for products using the search bar',
      steps: [
        'Navigate to the homepage',
        'Locate the search bar in the header',
        'Enter product name or keyword (e.g., "laptop")',
        'Click search button or press Enter',
        'Verify search results are displayed'
      ],
      expected_result: 'Relevant product results matching the search query are displayed with product images, names, and prices',
      priority: 'medium',
      status: 'pending',
      isEditing: false
    },
    {
      scenario_id: 'TC004',
      title: 'Add Product to Shopping Cart',
      description: 'Verify that users can add products to their shopping cart',
      steps: [
        'Navigate to a product detail page',
        'Select product quantity (if applicable)',
        'Select product options like size, color (if applicable)',
        'Click "Add to Cart" button',
        'Verify cart icon updates with item count',
        'Open cart to verify product is listed'
      ],
      expected_result: 'Product is successfully added to cart with correct details (name, price, quantity, options)',
      priority: 'high',
      status: 'pending',
      isEditing: false
    },
    {
      scenario_id: 'TC005',
      title: 'Checkout Process - Payment Information',
      description: 'Verify that users can complete the checkout process with payment information',
      steps: [
        'Add at least one product to cart',
        'Navigate to cart page',
        'Click "Proceed to Checkout"',
        'Enter shipping address',
        'Select shipping method',
        'Enter payment information (card number, expiry, CVV)',
        'Review order summary',
        'Click "Place Order" button'
      ],
      expected_result: 'Order is successfully placed, confirmation page is shown with order number, and confirmation email is sent',
      priority: 'high',
      status: 'pending',
      isEditing: false
    }
  ];

  constructor(
    private route: ActivatedRoute,
    private store: Store,
    private socketService: SocketService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.workflowId = this.route.snapshot.params['id'] || 'demo-workflow';
    this.workflowInfo.id = this.workflowId;

    this.store.dispatch(WorkflowActions.loadWorkflow({ workflowId: this.workflowId }));
    this.store.dispatch(WorkflowActions.loadWorkflowPhases({ workflowId: this.workflowId }));

    // Listen to real-time updates
    this.socketService.on<any>('workflow_update')
      .pipe(takeUntil(this.destroy$))
      .subscribe(update => {
        if (update.workflow_id === this.workflowId) {
          this.store.dispatch(WorkflowActions.workflowPhaseUpdate(update));
          this.addRealtimeUpdate(update.message);
        }
      });

    // Simulate real-time updates for demo
    interval(5000)
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.simulateRealtimeUpdate();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  getProgressPercentage(): number {
    const completed = this.phases.filter(p => p.status === 'completed').length;
    return Math.round((completed / this.phases.length) * 100);
  }

  getStatusClass(): string {
    if (this.workflowInfo.status.includes('completed')) return 'completed';
    if (this.workflowInfo.status.includes('failed')) return 'failed';
    return 'running';
  }

  addRealtimeUpdate(message: string): void {
    this.realtimeUpdates.unshift({ time: new Date(), message });
    if (this.realtimeUpdates.length > 10) {
      this.realtimeUpdates.pop();
    }
  }

  simulateRealtimeUpdate(): void {
    const messages = [
      'Test execution progress: 32/42 tests completed',
      'Performance metric recorded: Page load time 1.2s',
      'Accessibility check passed for "Product details" page',
      'Cross-browser compatibility verified',
      'API response time: 245ms (within threshold)'
    ];
    const randomMessage = messages[Math.floor(Math.random() * messages.length)];
    this.addRealtimeUpdate(randomMessage);
  }

  // Human-in-the-loop approval methods
  isAwaitingApproval(): boolean {
    return this.phases.some(p => p.phaseNumber === 2 && p.status === 'awaiting_review');
  }

  getScenarioCount(status: string): number {
    return this.testScenarios.filter(s => s.status === status).length;
  }

  toggleEdit(scenario: TestScenario): void {
    if (scenario.isEditing) {
      scenario.isEditing = false;
      if (scenario.status === 'pending') {
        scenario.status = 'edited';
      }
    } else {
      // Close all other editing scenarios
      this.testScenarios.forEach(s => s.isEditing = false);
      scenario.isEditing = true;
    }
  }

  approveScenario(scenario: TestScenario): void {
    scenario.status = 'approved';
    scenario.isEditing = false;
    this.addRealtimeUpdate(`Scenario "${scenario.scenario_id}" approved by ${this.workflowInfo.createdBy}`);
  }

  rejectScenario(scenario: TestScenario): void {
    scenario.status = 'rejected';
    scenario.isEditing = false;
    this.addRealtimeUpdate(`Scenario "${scenario.scenario_id}" rejected - requires revision`);
  }

  addStep(scenario: TestScenario): void {
    scenario.steps.push('');
  }

  removeStep(scenario: TestScenario, index: number): void {
    if (scenario.steps.length > 1) {
      scenario.steps.splice(index, 1);
    }
  }

  canSubmitApproval(): boolean {
    const approvedCount = this.getScenarioCount('approved');
    const rejectedCount = this.getScenarioCount('rejected');
    const total = this.testScenarios.length;

    // At least 50% must be approved to submit
    return approvedCount > 0 && (approvedCount + rejectedCount === total);
  }

  rejectAllScenarios(): void {
    if (confirm('Are you sure you want to reject all scenarios? This will request AI to regenerate them.')) {
      this.testScenarios.forEach(s => {
        s.status = 'rejected';
        s.isEditing = false;
      });
      this.addRealtimeUpdate('All scenarios rejected - Requesting AI regeneration');

      // Simulate workflow regeneration
      setTimeout(() => {
        alert('Scenarios will be regenerated. The workflow will restart from Phase 1.');
      }, 500);
    }
  }

  submitApproval(): void {
    const approvedCount = this.getScenarioCount('approved');
    const rejectedCount = this.getScenarioCount('rejected');

    const message = `You are about to approve ${approvedCount} scenario(s).${
      rejectedCount > 0 ? ` ${rejectedCount} scenario(s) will be excluded.` : ''
    } The workflow will continue to Phase 3 (Functional Testing). Continue?`;

    if (confirm(message)) {
      // Update Phase 2 to completed
      const phase2 = this.phases.find(p => p.phaseNumber === 2);
      if (phase2) {
        phase2.status = 'completed';
        phase2.endTime = new Date();
        phase2.duration = '12m 34s';
        phase2.logs.push(
          `[${new Date().toLocaleTimeString()}] Tester approved ${approvedCount} scenarios`,
          `[${new Date().toLocaleTimeString()}] Phase 2 completed - Workflow resuming`
        );
      }

      // Update Phase 3 to running
      const phase3 = this.phases.find(p => p.phaseNumber === 3);
      if (phase3) {
        phase3.status = 'running';
        phase3.startTime = new Date();
        phase3.logs = [
          `[${new Date().toLocaleTimeString()}] Initializing test environment...`,
          `[${new Date().toLocaleTimeString()}] Loading approved test scenarios`,
          `[${new Date().toLocaleTimeString()}] Starting Playwright execution...`
        ];
      }

      this.workflowInfo.status = 'Phase 3 Executing';
      this.workflowInfo.currentPhase = 3;

      this.addRealtimeUpdate(`Workflow resumed - Starting Phase 3: Functional Testing`);
      this.addRealtimeUpdate(`Executing ${approvedCount} approved test scenarios`);

      // Scroll to phases section
      setTimeout(() => {
        const phasesSection = document.querySelector('.phases-section');
        phasesSection?.scrollIntoView({ behavior: 'smooth' });
      }, 300);

      // Simulate API call to backend
      console.log('Submitting approval to backend...', {
        workflow_id: this.workflowId,
        approved_scenarios: this.testScenarios.filter(s => s.status === 'approved'),
        rejected_scenarios: this.testScenarios.filter(s => s.status === 'rejected')
      });
    }
  }
}
