import { Routes } from '@angular/router';

export const WORKFLOWS_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./workflow-list/workflow-list.component').then(m => m.WorkflowListComponent)
  },
  {
    path: ':id',
    loadComponent: () => import('./workflow-monitor/workflow-monitor.component').then(m => m.WorkflowMonitorComponent)
  }
];
