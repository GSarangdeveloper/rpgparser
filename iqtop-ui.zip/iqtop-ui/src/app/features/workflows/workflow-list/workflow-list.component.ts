import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { WorkflowSummary } from '../../../core/models';
import { selectAllWorkflows } from '../../../store/workflow/workflow.selectors';
import * as WorkflowActions from '../../../store/workflow/workflow.actions';

@Component({
  selector: 'app-workflow-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule
  ],
  template: `
    <div class="workflow-list-page">
      <div class="page-header">
        <div>
          <h1>My Workflows</h1>
          <p class="subtitle">Track and monitor all your workflow executions</p>
        </div>
      </div>

      <div class="filters-section">
        <mat-form-field appearance="outline" class="search-field">
          <mat-label>Search workflows</mat-label>
          <input matInput placeholder="Search by project or workflow name...">
          <mat-icon matPrefix>search</mat-icon>
        </mat-form-field>

        <mat-form-field appearance="outline" class="filter-field">
          <mat-label>Status</mat-label>
          <mat-select>
            <mat-option value="all">All Statuses</mat-option>
            <mat-option value="running">Running</mat-option>
            <mat-option value="completed">Completed</mat-option>
            <mat-option value="failed">Failed</mat-option>
            <mat-option value="pending">Pending</mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline" class="filter-field">
          <mat-label>Test Type</mat-label>
          <mat-select>
            <mat-option value="all">All Types</mat-option>
            <mat-option value="ui">UI Testing</mat-option>
            <mat-option value="api">API Testing</mat-option>
            <mat-option value="data">Data Testing</mat-option>
            <mat-option value="ibmi">IBM i Testing</mat-option>
          </mat-select>
        </mat-form-field>
      </div>

      <mat-tab-group class="workflows-tabs">
        <mat-tab label="All Workflows">
          <div class="workflows-grid">
            <mat-card *ngFor="let workflow of mockWorkflows" class="workflow-card"
              [routerLink]="['/workflows', workflow.id]">
              <div class="workflow-header">
                <div class="workflow-info">
                  <h3>{{ workflow.projectName }}</h3>
                  <p class="workflow-meta">
                    <mat-icon class="meta-icon">{{ getTestTypeIcon(workflow.testType) }}</mat-icon>
                    {{ workflow.testType | uppercase }} Testing
                  </p>
                </div>
                <mat-chip [class]="'status-chip status-' + getStatusClass(workflow.status)">
                  {{ getStatusLabel(workflow.status) }}
                </mat-chip>
              </div>

              <div class="workflow-details">
                <div class="detail-item">
                  <mat-icon>schedule</mat-icon>
                  <span>Started: {{ workflow.created_at | date: 'MMM d, h:mm a' }}</span>
                </div>
                <div class="detail-item">
                  <mat-icon>person</mat-icon>
                  <span>{{ workflow.created_by_name }}</span>
                </div>
              </div>

              <div class="workflow-progress">
                <div class="progress-info">
                  <span class="progress-label">Phase {{ workflow.current_phase }}/8</span>
                  <span class="progress-percentage">{{ getProgressPercentage(workflow.current_phase) }}%</span>
                </div>
                <div class="progress-bar">
                  <div class="progress-fill" [style.width.%]="getProgressPercentage(workflow.current_phase)"></div>
                </div>
              </div>

              <div class="workflow-actions">
                <button mat-button (click)="viewWorkflow(workflow.id); $event.stopPropagation()">
                  <mat-icon>visibility</mat-icon>
                  View Details
                </button>
              </div>
            </mat-card>

            <mat-card *ngIf="mockWorkflows.length === 0" class="empty-card">
              <div class="empty-state">
                <mat-icon>workflow</mat-icon>
                <h3>No Workflows Found</h3>
                <p>Start by creating a project and configuring test workflows</p>
                <button mat-raised-button color="primary" routerLink="/projects">
                  <mat-icon>add</mat-icon>
                  Create Project
                </button>
              </div>
            </mat-card>
          </div>
        </mat-tab>

        <mat-tab label="Running">
          <div class="workflows-grid">
            <mat-card *ngFor="let workflow of getRunningWorkflows()" class="workflow-card"
              [routerLink]="['/workflows', workflow.id]">
              <div class="workflow-header">
                <div class="workflow-info">
                  <h3>{{ workflow.projectName }}</h3>
                  <p class="workflow-meta">
                    <mat-icon class="meta-icon">{{ getTestTypeIcon(workflow.testType) }}</mat-icon>
                    {{ workflow.testType | uppercase }} Testing
                  </p>
                </div>
                <mat-chip class="status-chip status-running">
                  <mat-icon class="spinning">sync</mat-icon>
                  Running
                </mat-chip>
              </div>

              <div class="workflow-details">
                <div class="detail-item">
                  <mat-icon>schedule</mat-icon>
                  <span>Started: {{ workflow.created_at | date: 'MMM d, h:mm a' }}</span>
                </div>
                <div class="detail-item">
                  <mat-icon>person</mat-icon>
                  <span>{{ workflow.created_by_name }}</span>
                </div>
              </div>

              <div class="workflow-progress">
                <div class="progress-info">
                  <span class="progress-label">Phase {{ workflow.current_phase }}/8</span>
                  <span class="progress-percentage">{{ getProgressPercentage(workflow.current_phase) }}%</span>
                </div>
                <div class="progress-bar">
                  <div class="progress-fill" [style.width.%]="getProgressPercentage(workflow.current_phase)"></div>
                </div>
              </div>

              <div class="workflow-actions">
                <button mat-button (click)="viewWorkflow(workflow.id); $event.stopPropagation()">
                  <mat-icon>visibility</mat-icon>
                  Monitor Live
                </button>
              </div>
            </mat-card>
          </div>
        </mat-tab>

        <mat-tab label="Completed">
          <div class="workflows-grid">
            <mat-card *ngFor="let workflow of getCompletedWorkflows()" class="workflow-card"
              [routerLink]="['/workflows', workflow.id]">
              <div class="workflow-header">
                <div class="workflow-info">
                  <h3>{{ workflow.projectName }}</h3>
                  <p class="workflow-meta">
                    <mat-icon class="meta-icon">{{ getTestTypeIcon(workflow.testType) }}</mat-icon>
                    {{ workflow.testType | uppercase }} Testing
                  </p>
                </div>
                <mat-chip class="status-chip status-completed">
                  <mat-icon>check_circle</mat-icon>
                  Completed
                </mat-chip>
              </div>

              <div class="workflow-details">
                <div class="detail-item">
                  <mat-icon>schedule</mat-icon>
                  <span>Completed: {{ workflow.created_at | date: 'MMM d, h:mm a' }}</span>
                </div>
                <div class="detail-item">
                  <mat-icon>person</mat-icon>
                  <span>{{ workflow.created_by_name }}</span>
                </div>
              </div>

              <div class="workflow-progress">
                <div class="progress-info">
                  <span class="progress-label">All Phases Complete</span>
                  <span class="progress-percentage">100%</span>
                </div>
                <div class="progress-bar">
                  <div class="progress-fill completed" style="width: 100%"></div>
                </div>
              </div>

              <div class="workflow-actions">
                <button mat-button (click)="viewWorkflow(workflow.id); $event.stopPropagation()">
                  <mat-icon>visibility</mat-icon>
                  View Report
                </button>
              </div>
            </mat-card>
          </div>
        </mat-tab>
      </mat-tab-group>
    </div>
  `,
  styles: [`
    .workflow-list-page {
      max-width: 1400px;
      margin: 0 auto;
    }

    .page-header {
      margin-bottom: 2rem;
    }

    .page-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .subtitle {
      color: #6b7280;
      font-size: 1rem;
      margin: 0;
    }

    .filters-section {
      display: grid;
      grid-template-columns: 1fr auto auto;
      gap: 1rem;
      margin-bottom: 2rem;
    }

    @media (max-width: 768px) {
      .filters-section {
        grid-template-columns: 1fr;
      }
    }

    .search-field {
      min-width: 300px;
    }

    .filter-field {
      min-width: 200px;
    }

    .workflows-tabs {
      margin-bottom: 2rem;
    }

    .workflows-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
      gap: 1.5rem;
      padding: 1.5rem 0;
    }

    @media (max-width: 768px) {
      .workflows-grid {
        grid-template-columns: 1fr;
      }
    }

    .workflow-card {
      padding: 1.5rem;
      cursor: pointer;
      transition: all 0.2s ease;
      border-left: 4px solid #e5e7eb;
    }

    .workflow-card:hover {
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      transform: translateY(-2px);
    }

    .workflow-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }

    .workflow-info {
      flex: 1;
    }

    .workflow-info h3 {
      font-size: 1.125rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .workflow-meta {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.875rem;
      color: #6b7280;
      margin: 0;
    }

    .meta-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }

    .status-chip {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.25rem 0.75rem;
      border-radius: 0.25rem;
      font-size: 0.75rem;
      font-weight: 600;
    }

    .status-chip mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }

    .status-running {
      background-color: #dbeafe;
      color: #1e40af;
    }

    .status-completed {
      background-color: #d1fae5;
      color: #065f46;
    }

    .status-failed {
      background-color: #fee2e2;
      color: #991b1b;
    }

    .status-pending {
      background-color: #fef3c7;
      color: #92400e;
    }

    .status-waiting {
      background-color: #f3f4f6;
      color: #6b7280;
    }

    .spinning {
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    .workflow-details {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      margin-bottom: 1rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .detail-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.875rem;
      color: #6b7280;
    }

    .detail-item mat-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
    }

    .workflow-progress {
      margin-bottom: 1rem;
    }

    .progress-info {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.5rem;
    }

    .progress-label {
      font-size: 0.875rem;
      color: #6b7280;
    }

    .progress-percentage {
      font-size: 0.875rem;
      font-weight: 600;
      color: #2C3E50;
    }

    .progress-bar {
      height: 8px;
      background-color: #e5e7eb;
      border-radius: 4px;
      overflow: hidden;
    }

    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, #2C3E50 0%, #27AE60 100%);
      transition: width 0.3s ease;
    }

    .progress-fill.completed {
      background: #27AE60;
    }

    .workflow-actions {
      display: flex;
      justify-content: flex-end;
    }

    .workflow-actions button {
      color: #2C3E50;
    }

    .workflow-actions button mat-icon {
      margin-right: 0.5rem;
      font-size: 18px;
      width: 18px;
      height: 18px;
    }

    .empty-card {
      grid-column: 1 / -1;
      padding: 3rem;
    }

    .empty-state {
      text-align: center;
      color: #6b7280;
    }

    .empty-state mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #d1d5db;
      margin-bottom: 1rem;
    }

    .empty-state h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .empty-state p {
      font-size: 0.875rem;
      margin: 0 0 1.5rem 0;
    }

    .empty-state button mat-icon {
      font-size: 20px;
      width: 20px;
      height: 20px;
      margin-right: 0.5rem;
    }
  `]
})
export class WorkflowListComponent implements OnInit {
  workflows$: Observable<WorkflowSummary[]>;

  mockWorkflows = [
    {
      id: 'wf-1',
      projectName: 'E-Commerce Platform',
      testType: 'ui',
      status: 'phase_3_executing',
      current_phase: 3,
      created_by_name: 'John Doe',
      created_at: new Date(Date.now() - 7200000)
    },
    {
      id: 'wf-2',
      projectName: 'Mobile Banking App',
      testType: 'api',
      status: 'phase_5_scripts',
      current_phase: 5,
      created_by_name: 'Jane Smith',
      created_at: new Date(Date.now() - 3600000)
    },
    {
      id: 'wf-3',
      projectName: 'Payment Gateway Integration',
      testType: 'api',
      status: 'completed',
      current_phase: 8,
      created_by_name: 'Bob Wilson',
      created_at: new Date(Date.now() - 86400000)
    },
    {
      id: 'wf-4',
      projectName: 'User Authentication System',
      testType: 'ui',
      status: 'phase_2_awaiting_review',
      current_phase: 2,
      created_by_name: 'Alice Johnson',
      created_at: new Date(Date.now() - 1800000)
    },
    {
      id: 'wf-5',
      projectName: 'Inventory Management',
      testType: 'data',
      status: 'completed',
      current_phase: 8,
      created_by_name: 'Charlie Brown',
      created_at: new Date(Date.now() - 172800000)
    },
    {
      id: 'wf-6',
      projectName: 'Customer Portal Redesign',
      testType: 'ui',
      status: 'phase_6_reporting',
      current_phase: 6,
      created_by_name: 'Diana Prince',
      created_at: new Date(Date.now() - 5400000)
    }
  ];

  constructor(private store: Store) {
    this.workflows$ = this.store.select(selectAllWorkflows);
  }

  ngOnInit(): void {
    this.store.dispatch(WorkflowActions.loadWorkflows({}));
  }

  getRunningWorkflows() {
    return this.mockWorkflows.filter(w =>
      w.status.includes('phase_') && !w.status.includes('completed')
    );
  }

  getCompletedWorkflows() {
    return this.mockWorkflows.filter(w => w.status === 'completed');
  }

  getStatusClass(status: string): string {
    if (status.includes('completed')) return 'completed';
    if (status.includes('failed')) return 'failed';
    if (status.includes('awaiting')) return 'waiting';
    if (status.includes('pending')) return 'pending';
    return 'running';
  }

  getStatusLabel(status: string): string {
    if (status === 'completed') return 'Completed';
    if (status.includes('phase_1')) return 'Phase 1: Design Analysis';
    if (status.includes('phase_2')) return 'Phase 2: Awaiting Review';
    if (status.includes('phase_3')) return 'Phase 3: Executing Tests';
    if (status.includes('phase_4')) return 'Phase 4: Analyzing Defects';
    if (status.includes('phase_5')) return 'Phase 5: Generating Scripts';
    if (status.includes('phase_6')) return 'Phase 6: Creating Reports';
    if (status.includes('phase_7')) return 'Phase 7: Baselining';
    if (status.includes('phase_8')) return 'Phase 8: GitHub Integration';
    return status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }

  getTestTypeIcon(testType: string): string {
    const icons: Record<string, string> = {
      ui: 'web',
      api: 'api',
      data: 'table_chart',
      ibmi: 'storage',
      legacy: 'archive'
    };
    return icons[testType] || 'science';
  }

  getProgressPercentage(currentPhase: number): number {
    return Math.round((currentPhase / 8) * 100);
  }

  viewWorkflow(workflowId: string): void {
    // Navigation handled by routerLink
  }
}
