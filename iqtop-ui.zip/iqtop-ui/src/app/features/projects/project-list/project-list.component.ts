import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { Project } from '../../../core/models';
import { selectAllProjects } from '../../../store/project/project.selectors';
import * as ProjectActions from '../../../store/project/project.actions';

@Component({
  selector: 'app-project-list',
  standalone: true,
  imports: [CommonModule, RouterLink, MatButtonModule, MatCardModule, MatIconModule, MatTableModule],
  template: `
    <div class="projects-page">
      <div class="page-header">
        <div>
          <h1>Projects</h1>
          <p class="subtitle">Manage and organize your testing projects. Click any project to view test types and workflows.</p>
        </div>
        <button mat-raised-button color="primary" routerLink="/projects/create" class="create-button">
          <mat-icon>add</mat-icon>
          Create New Project
        </button>
      </div>

      <mat-card class="table-card">
        <table mat-table [dataSource]="(projects$ | async) || []" class="projects-table">
          <!-- Project Name Column -->
          <ng-container matColumnDef="name">
            <th mat-header-cell *matHeaderCellDef>Project Name</th>
            <td mat-cell *matCellDef="let project" class="project-name-cell">{{ project.name }}</td>
          </ng-container>

          <!-- Description Column -->
          <ng-container matColumnDef="description">
            <th mat-header-cell *matHeaderCellDef>Description</th>
            <td mat-cell *matCellDef="let project" class="description-cell">
              {{ project.description || '-' }}
            </td>
          </ng-container>

          <!-- Created By Column -->
          <ng-container matColumnDef="createdBy">
            <th mat-header-cell *matHeaderCellDef>Created By</th>
            <td mat-cell *matCellDef="let project">{{ project.created_by || '-' }}</td>
          </ng-container>

          <!-- Created Date Column -->
          <ng-container matColumnDef="createdDate">
            <th mat-header-cell *matHeaderCellDef>Created Date</th>
            <td mat-cell *matCellDef="let project">{{ project.created_at | date: 'MMM d, y' }}</td>
          </ng-container>

          <!-- Actions Column -->
          <ng-container matColumnDef="actions">
            <th mat-header-cell *matHeaderCellDef class="actions-header">Actions</th>
            <td mat-cell *matCellDef="let project" class="actions-cell">
              <button mat-icon-button [routerLink]="['/projects', project.id]" matTooltip="View Project">
                <mat-icon>visibility</mat-icon>
              </button>
              <button mat-icon-button matTooltip="Configure">
                <mat-icon>settings</mat-icon>
              </button>
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;" class="project-row"></tr>
        </table>
      </mat-card>
    </div>
  `,
  styles: [`
    .projects-page {
      max-width: 1280px;
      margin: 0 auto;
    }

    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 2rem;
    }

    .page-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .subtitle {
      color: #6b7280;
      font-size: 1rem;
      margin: 0;
    }

    .create-button {
      height: 2.5rem;
      padding: 0 1.5rem;
      font-weight: 500;
    }

    .create-button mat-icon {
      margin-right: 0.5rem;
      font-size: 1.25rem;
      width: 1.25rem;
      height: 1.25rem;
    }

    .table-card {
      border-radius: 0.5rem;
      overflow: hidden;
    }

    .projects-table {
      width: 100%;
    }

    .projects-table th {
      background-color: #f9fafb;
      font-weight: 600;
      color: #374151;
      font-size: 0.875rem;
      padding: 1rem;
    }

    .projects-table td {
      padding: 1rem;
      color: #6b7280;
      font-size: 0.875rem;
    }

    .project-name-cell {
      font-weight: 600;
      color: #1f2937;
    }

    .description-cell {
      max-width: 400px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .actions-header {
      text-align: right;
    }

    .actions-cell {
      text-align: right;
    }

    .actions-cell button {
      color: #6b7280;
    }

    .actions-cell button:hover {
      color: #2C3E50;
      background-color: #f3f4f6;
    }

    .project-row {
      transition: background-color 0.2s ease;
    }

    .project-row:hover {
      background-color: #f9fafb;
    }
  `]
})
export class ProjectListComponent implements OnInit {
  projects$: Observable<Project[]>;
  displayedColumns: string[] = ['name', 'description', 'createdBy', 'createdDate', 'actions'];

  constructor(private store: Store) {
    this.projects$ = this.store.select(selectAllProjects);
  }

  ngOnInit(): void {
    this.store.dispatch(ProjectActions.loadProjects());
  }
}
