import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatExpansionModule } from '@angular/material/expansion';

interface Workflow {
  id: string;
  name: string;
  status: string;
  phase: number;
  assignedTo: string;
  createdDate: Date;
  updatedDate: Date;
}

interface TestType {
  id: string;
  name: string;
  type: 'ui' | 'api' | 'data' | 'ibmi' | 'legacy';
  workflows: Workflow[];
}

interface ProjectDetail {
  projectId: string;
  itProjectId: string;
  name: string;
  description: string;
  deliveryManager: { name: string; email: string };
  projectOwner: { name: string; email: string };
  testTypes: TestType[];
  status: 'Active' | 'Planning' | 'Completed';
}

@Component({
  selector: 'app-project-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, MatCardModule, MatButtonModule, MatIconModule, MatExpansionModule],
  template: `
    <div class="project-detail-page">
      <button mat-button routerLink="/projects" class="back-button">
        <mat-icon>arrow_back</mat-icon>
        Back to Projects
      </button>

      <!-- Project Header -->
      <div class="project-header">
        <div>
          <h1>{{ projectDetail.name }}</h1>
          <p class="project-id">{{ projectDetail.itProjectId }}</p>
        </div>
        <span class="status-badge">{{ projectDetail.status }}</span>
      </div>
      <p class="project-description">{{ projectDetail.description }}</p>

      <!-- Project Stats -->
      <div class="stats-grid">
        <mat-card class="stat-card">
          <p class="stat-label">Total Workflows</p>
          <p class="stat-value">{{ getTotalWorkflows() }}</p>
        </mat-card>
        <mat-card class="stat-card">
          <p class="stat-label">Completed</p>
          <p class="stat-value completed">{{ getCompletedWorkflows() }}</p>
        </mat-card>
        <mat-card class="stat-card team-card" (click)="showTeam = !showTeam">
          <p class="stat-label">Project Team</p>
          <div class="team-preview">
            <div>
              <p class="team-name">{{ projectDetail.deliveryManager.name }}</p>
              <p class="team-role">Delivery Manager</p>
            </div>
            <mat-icon [class.rotated]="showTeam">expand_more</mat-icon>
          </div>
        </mat-card>
      </div>

      <!-- Team Details -->
      <mat-card *ngIf="showTeam" class="team-details">
        <h3>Project Leadership</h3>
        <div class="team-grid">
          <div class="team-member">
            <p class="member-label">Delivery Manager</p>
            <div class="member-info">
              <p class="member-name">{{ projectDetail.deliveryManager.name }}</p>
              <p class="member-email">{{ projectDetail.deliveryManager.email }}</p>
            </div>
          </div>
          <div class="team-member">
            <p class="member-label">Project Owner</p>
            <div class="member-info">
              <p class="member-name">{{ projectDetail.projectOwner.name }}</p>
              <p class="member-email">{{ projectDetail.projectOwner.email }}</p>
            </div>
          </div>
        </div>
      </mat-card>

      <!-- Workflows by Test Type -->
      <div class="workflows-section">
        <h2>Workflows by Test Type</h2>

        <mat-accordion>
          <mat-expansion-panel *ngFor="let testType of projectDetail.testTypes" [expanded]="testType.id === 'tt1'">
            <mat-expansion-panel-header>
              <mat-panel-title>
                <span class="test-type-badge" [class]="'badge-' + testType.type">
                  {{ getTestTypeLabel(testType.type) }}
                </span>
                <div class="test-type-info">
                  <span class="test-type-name">{{ testType.name }}</span>
                  <span class="test-type-meta">
                    {{ testType.workflows.length }} workflows •
                    {{ getCompletedCount(testType.workflows) }} completed
                  </span>
                </div>
              </mat-panel-title>
            </mat-expansion-panel-header>

            <div class="workflows-list">
              <div *ngFor="let workflow of testType.workflows" class="workflow-card">
                <div class="workflow-info">
                  <p class="workflow-name">{{ workflow.name }}</p>
                  <div class="workflow-meta">
                    <span class="status-badge" [class]="'status-' + getStatusClass(workflow.status)">
                      {{ getStatusLabel(workflow.status) }}
                    </span>
                    <span class="phase-text">Phase {{ workflow.phase }}/8</span>
                  </div>
                </div>
                <div class="workflow-actions">
                  <div class="workflow-details">
                    <p class="assigned-to">{{ workflow.assignedTo }}</p>
                    <p class="updated-date">{{ workflow.updatedDate | date: 'MMM d' }}</p>
                  </div>
                  <button mat-icon-button [routerLink]="['/workflows', workflow.id]">
                    <mat-icon>visibility</mat-icon>
                  </button>
                </div>
              </div>
            </div>
          </mat-expansion-panel>
        </mat-accordion>
      </div>
    </div>
  `,
  styles: [`
    .project-detail-page {
      max-width: 1280px;
      margin: 0 auto;
    }

    .back-button {
      margin-bottom: 1.5rem;
      color: #6b7280;
    }

    .back-button mat-icon {
      margin-right: 0.5rem;
    }

    .project-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }

    .project-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0;
    }

    .project-id {
      font-size: 0.875rem;
      color: #6b7280;
      margin: 0.25rem 0 0 0;
    }

    .status-badge {
      padding: 0.5rem 1rem;
      border-radius: 0.375rem;
      border: 1px solid #e5e7eb;
      font-size: 0.875rem;
      font-weight: 500;
      color: #374151;
    }

    .project-description {
      color: #6b7280;
      font-size: 1rem;
      margin: 0 0 2rem 0;
      max-width: 48rem;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .stat-card {
      padding: 1rem;
    }

    .stat-label {
      font-size: 0.875rem;
      color: #6b7280;
      margin: 0 0 0.5rem 0;
    }

    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0;
    }

    .stat-value.completed {
      color: #27AE60;
    }

    .team-card {
      cursor: pointer;
      transition: background-color 0.2s ease;
    }

    .team-card:hover {
      background-color: #f9fafb;
    }

    .team-preview {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 0.5rem;
    }

    .team-name {
      font-weight: 600;
      font-size: 0.875rem;
      color: #1f2937;
      margin: 0;
    }

    .team-role {
      font-size: 0.75rem;
      color: #6b7280;
      margin: 0.25rem 0 0 0;
    }

    .team-preview mat-icon {
      color: #6b7280;
      transition: transform 0.2s ease;
    }

    .team-preview mat-icon.rotated {
      transform: rotate(180deg);
    }

    .team-details {
      padding: 1.5rem;
      background-color: #f9fafb;
      margin-bottom: 1.5rem;
    }

    .team-details h3 {
      font-size: 1rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1rem 0;
    }

    .team-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
    }

    .team-member {
      background-color: white;
      border: 1px solid #e5e7eb;
      border-radius: 0.5rem;
      padding: 1rem;
    }

    .member-label {
      font-size: 0.75rem;
      font-weight: 500;
      color: #6b7280;
      margin: 0 0 0.5rem 0;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .member-info {
      background-color: #f9fafb;
      padding: 0.75rem;
      border-radius: 0.375rem;
      border: 1px solid #e5e7eb;
    }

    .member-name {
      font-weight: 600;
      font-size: 0.875rem;
      color: #1f2937;
      margin: 0;
    }

    .member-email {
      font-size: 0.75rem;
      color: #6b7280;
      margin: 0.25rem 0 0 0;
    }

    .workflows-section {
      margin-top: 2rem;
    }

    .workflows-section h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1rem 0;
    }

    ::ng-deep .mat-expansion-panel {
      margin-bottom: 1rem;
      border-radius: 0.5rem;
      overflow: hidden;
    }

    ::ng-deep .mat-expansion-panel-header {
      padding: 1rem;
    }

    ::ng-deep .mat-expansion-panel-header:hover {
      background-color: #f9fafb !important;
    }

    .test-type-badge {
      padding: 0.25rem 0.75rem;
      border-radius: 0.375rem;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
      margin-right: 0.75rem;
    }

    .badge-ui {
      background-color: #dbeafe;
      color: #1e40af;
    }

    .badge-api {
      background-color: #e9d5ff;
      color: #6b21a8;
    }

    .badge-data {
      background-color: #d1fae5;
      color: #065f46;
    }

    .badge-ibmi {
      background-color: #fed7aa;
      color: #92400e;
    }

    .badge-legacy {
      background-color: #e5e7eb;
      color: #374151;
    }

    .test-type-info {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
    }

    .test-type-name {
      font-weight: 600;
      color: #1f2937;
    }

    .test-type-meta {
      font-size: 0.75rem;
      color: #6b7280;
    }

    .workflows-list {
      padding: 1rem;
      background-color: #f9fafb;
    }

    .workflow-card {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.75rem;
      background-color: white;
      border: 1px solid #e5e7eb;
      border-radius: 0.5rem;
      margin-bottom: 0.5rem;
      transition: all 0.2s ease;
    }

    .workflow-card:hover {
      background-color: #f9fafb;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    .workflow-card:last-child {
      margin-bottom: 0;
    }

    .workflow-info {
      flex: 1;
      min-width: 0;
    }

    .workflow-name {
      font-weight: 500;
      font-size: 0.875rem;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .workflow-meta {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .workflow-meta .status-badge {
      padding: 0.125rem 0.5rem;
      border-radius: 0.25rem;
      font-size: 0.75rem;
      font-weight: 500;
    }

    .status-completed {
      background-color: #d1fae5;
      color: #065f46;
    }

    .status-running {
      background-color: #dbeafe;
      color: #1e40af;
    }

    .status-waiting {
      background-color: #fef3c7;
      color: #92400e;
    }

    .status-pending {
      background-color: #e5e7eb;
      color: #374151;
    }

    .status-failed {
      background-color: #fee2e2;
      color: #991b1b;
    }

    .phase-text {
      font-size: 0.75rem;
      color: #6b7280;
    }

    .workflow-actions {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .workflow-details {
      text-align: right;
    }

    .assigned-to {
      font-size: 0.75rem;
      color: #6b7280;
      margin: 0;
    }

    .updated-date {
      font-size: 0.75rem;
      color: #6b7280;
      margin: 0.25rem 0 0 0;
    }

    .workflow-actions button {
      color: #6b7280;
      opacity: 0;
      transition: opacity 0.2s ease;
    }

    .workflow-card:hover .workflow-actions button {
      opacity: 1;
    }

    .workflow-actions button:hover {
      color: #2C3E50;
      background-color: #f3f4f6;
    }
  `]
})
export class ProjectDetailComponent implements OnInit {
  showTeam = false;
  projectDetail: ProjectDetail = {
    projectId: '1',
    itProjectId: 'ITPRJ#2024-001',
    name: 'E-Commerce Platform',
    description: 'Online shopping platform with advanced payment integration and inventory management',
    deliveryManager: { name: 'Alice Johnson', email: 'alice.johnson@company.com' },
    projectOwner: { name: 'Bob Smith', email: 'bob.smith@company.com' },
    testTypes: [
      {
        id: 'tt1',
        name: 'UI Testing - Web',
        type: 'ui',
        workflows: [
          {
            id: 'w1',
            name: 'Homepage & Navigation Flow',
            status: 'phase_3_executing',
            phase: 3,
            assignedTo: 'John Doe',
            createdDate: new Date('2024-01-15'),
            updatedDate: new Date('2024-01-24'),
          },
          {
            id: 'w2',
            name: 'Checkout Process Validation',
            status: 'phase_2_awaiting_review',
            phase: 2,
            assignedTo: 'Jane Smith',
            createdDate: new Date('2024-01-18'),
            updatedDate: new Date('2024-01-23'),
          },
          {
            id: 'w3',
            name: 'Payment Integration Tests',
            status: 'completed',
            phase: 8,
            assignedTo: 'Mike Brown',
            createdDate: new Date('2024-01-10'),
            updatedDate: new Date('2024-01-22'),
          },
        ],
      },
      {
        id: 'tt2',
        name: 'API Testing - Payment Gateway',
        type: 'api',
        workflows: [
          {
            id: 'w6',
            name: 'Payment Processing API',
            status: 'phase_3_executing',
            phase: 3,
            assignedTo: 'Emma Wilson',
            createdDate: new Date('2024-01-16'),
            updatedDate: new Date('2024-01-24'),
          },
        ],
      },
    ],
    status: 'Active',
  };

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    // In real app, load project detail based on route param
    const projectId = this.route.snapshot.paramMap.get('id');
    console.log('Loading project:', projectId);
  }

  getTotalWorkflows(): number {
    return this.projectDetail.testTypes.reduce((acc, tt) => acc + tt.workflows.length, 0);
  }

  getCompletedWorkflows(): number {
    return this.projectDetail.testTypes.reduce(
      (acc, tt) => acc + tt.workflows.filter(w => w.status === 'completed').length,
      0
    );
  }

  getCompletedCount(workflows: Workflow[]): number {
    return workflows.filter(w => w.status === 'completed').length;
  }

  getTestTypeLabel(type: string): string {
    const labels: Record<string, string> = {
      ui: 'UI',
      api: 'API',
      data: 'Data',
      ibmi: 'IBM i',
      legacy: 'Legacy',
    };
    return labels[type] || type.toUpperCase();
  }

  getStatusClass(status: string): string {
    if (status.includes('completed')) return 'completed';
    if (status.includes('failed')) return 'failed';
    if (status.includes('awaiting')) return 'waiting';
    if (status.includes('pending')) return 'pending';
    return 'running';
  }

  getStatusLabel(status: string): string {
    return status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }
}
