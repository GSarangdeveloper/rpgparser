import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatStepperModule } from '@angular/material/stepper';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { Store } from '@ngrx/store';
import * as ProjectActions from '../../../store/project/project.actions';

interface TestTypeConfig {
  type: string;
  enabled: boolean;
  name: string;
}

@Component({
  selector: 'app-project-create',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterLink,
    MatCardModule,
    MatStepperModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule
  ],
  template: `
    <div class="create-project-page">
      <button mat-button routerLink="/projects" class="back-button">
        <mat-icon>arrow_back</mat-icon>
        Back to Projects
      </button>

      <div class="page-header">
        <h1>Create New Project</h1>
        <p class="subtitle">Set up a new testing project with configurations</p>
      </div>

      <mat-card class="stepper-card">
        <mat-stepper [linear]="true" #stepper>

          <!-- Step 1: Basic Information -->
          <mat-step [stepControl]="basicInfoForm">
            <form [formGroup]="basicInfoForm">
              <ng-template matStepLabel>Basic Information</ng-template>

              <div class="step-content">
                <h2>Project Details and Metadata</h2>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Project Name</mat-label>
                  <input matInput formControlName="name" placeholder="E-Commerce Platform">
                  <mat-error *ngIf="basicInfoForm.get('name')?.hasError('required')">
                    Project name is required
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Description</mat-label>
                  <textarea matInput formControlName="description" rows="3"
                    placeholder="Brief description of your project..."></textarea>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>GitHub Repository URL</mat-label>
                  <input matInput formControlName="githubRepo" placeholder="https://github.com/org/repo">
                </mat-form-field>

                <div class="form-row">
                  <mat-form-field appearance="outline" class="half-width">
                    <mat-label>Rally Project ID</mat-label>
                    <input matInput formControlName="rallyId" placeholder="RALLY-123">
                  </mat-form-field>

                  <mat-form-field appearance="outline" class="half-width">
                    <mat-label>Jira Project Key</mat-label>
                    <input matInput formControlName="jiraKey" placeholder="PROJ">
                  </mat-form-field>
                </div>

                <div class="step-actions">
                  <button mat-button routerLink="/projects">Cancel</button>
                  <button mat-raised-button color="primary" matStepperNext>
                    Next
                    <mat-icon>arrow_forward</mat-icon>
                  </button>
                </div>
              </div>
            </form>
          </mat-step>

          <!-- Step 2: Test Type Configuration -->
          <mat-step>
            <ng-template matStepLabel>Test Type Configuration</ng-template>

            <div class="step-content">
              <h2>Select and Configure Test Types</h2>

              <div class="test-types-list">
                <mat-checkbox [(ngModel)]="testTypes.ui.enabled" [ngModelOptions]="{standalone: true}" class="test-checkbox">
                  <div class="test-type-item">
                    <div class="test-type-info">
                      <h3>UI Testing</h3>
                      <p>Web and mobile interface testing with Playwright</p>
                    </div>
                  </div>
                </mat-checkbox>

                <mat-checkbox [(ngModel)]="testTypes.api.enabled" [ngModelOptions]="{standalone: true}" class="test-checkbox">
                  <div class="test-type-item">
                    <div class="test-type-info">
                      <h3>API Testing</h3>
                      <p>REST API endpoint validation and integration tests</p>
                    </div>
                  </div>
                </mat-checkbox>

                <mat-checkbox [(ngModel)]="testTypes.ibmi.enabled" [ngModelOptions]="{standalone: true}" class="test-checkbox">
                  <div class="test-type-item">
                    <div class="test-type-info">
                      <h3>IBM i Testing</h3>
                      <p>Legacy IBM i system and mainframe testing</p>
                    </div>
                  </div>
                </mat-checkbox>

                <mat-checkbox [(ngModel)]="testTypes.data.enabled" [ngModelOptions]="{standalone: true}" class="test-checkbox">
                  <div class="test-type-item">
                    <div class="test-type-info">
                      <h3>Data Testing</h3>
                      <p>Database validation and data integrity tests</p>
                    </div>
                  </div>
                </mat-checkbox>
              </div>

              <div class="step-actions">
                <button mat-button matStepperPrevious>
                  <mat-icon>arrow_back</mat-icon>
                  Back
                </button>
                <button mat-raised-button color="primary" matStepperNext
                  [disabled]="!hasSelectedTestTypes()">
                  Next
                  <mat-icon>arrow_forward</mat-icon>
                </button>
              </div>
            </div>
          </mat-step>

          <!-- Step 3: Team Members -->
          <mat-step [stepControl]="teamForm">
            <form [formGroup]="teamForm">
              <ng-template matStepLabel>Team Members</ng-template>

              <div class="step-content">
                <h2>Add Collaborators to the Project</h2>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Delivery Manager Name</mat-label>
                  <input matInput formControlName="deliveryManagerName">
                  <mat-error>Required</mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Delivery Manager Email</mat-label>
                  <input matInput type="email" formControlName="deliveryManagerEmail">
                  <mat-error *ngIf="teamForm.get('deliveryManagerEmail')?.hasError('email')">
                    Invalid email format
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Project Owner Name</mat-label>
                  <input matInput formControlName="projectOwnerName">
                  <mat-error>Required</mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Project Owner Email</mat-label>
                  <input matInput type="email" formControlName="projectOwnerEmail">
                  <mat-error *ngIf="teamForm.get('projectOwnerEmail')?.hasError('email')">
                    Invalid email format
                  </mat-error>
                </mat-form-field>

                <div class="step-actions">
                  <button mat-button matStepperPrevious>
                    <mat-icon>arrow_back</mat-icon>
                    Back
                  </button>
                  <button mat-raised-button color="primary" matStepperNext>
                    Next
                    <mat-icon>arrow_forward</mat-icon>
                  </button>
                </div>
              </div>
            </form>
          </mat-step>

          <!-- Step 4: Documents -->
          <mat-step>
            <ng-template matStepLabel>Documents</ng-template>

            <div class="step-content">
              <h2>Upload Context Documents</h2>
              <p class="step-description">
                Upload domain documents, specifications, or any context that will help AI agents understand your project better.
              </p>

              <div class="upload-zone" (click)="documentInput.click()">
                <mat-icon class="upload-icon">cloud_upload</mat-icon>
                <p class="upload-text">Drag and drop files here or click to browse</p>
                <p class="upload-hint">Supported formats: PDF, DOCX, TXT, JSON, YAML, MD</p>
              </div>
              <input #documentInput type="file" multiple hidden (change)="onDocumentsSelected($event)"
                accept=".pdf,.doc,.docx,.txt,.json,.yaml,.yml,.md">

              <div *ngIf="uploadedDocuments.length > 0" class="uploaded-files">
                <h3>Uploaded Files ({{ uploadedDocuments.length }})</h3>
                <div class="file-list">
                  <div *ngFor="let file of uploadedDocuments" class="file-item">
                    <mat-icon>description</mat-icon>
                    <span class="file-name">{{ file.name }}</span>
                    <span class="file-size">{{ formatFileSize(file.size) }}</span>
                    <button mat-icon-button (click)="removeDocument(file)">
                      <mat-icon>close</mat-icon>
                    </button>
                  </div>
                </div>
              </div>

              <div class="step-actions">
                <button mat-button matStepperPrevious>
                  <mat-icon>arrow_back</mat-icon>
                  Back
                </button>
                <button mat-raised-button color="primary" (click)="createProject()"
                  [disabled]="isSubmitting">
                  <mat-icon>check</mat-icon>
                  {{ isSubmitting ? 'Creating...' : 'Create Project' }}
                </button>
              </div>
            </div>
          </mat-step>

        </mat-stepper>
      </mat-card>
    </div>
  `,
  styles: [`
    .create-project-page {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
    }

    .back-button {
      margin-bottom: 1rem;
      color: #6b7280;
    }

    .back-button mat-icon {
      margin-right: 0.5rem;
    }

    .page-header {
      margin-bottom: 2rem;
    }

    .page-header h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0 0 0.5rem 0;
    }

    .subtitle {
      color: #6b7280;
      font-size: 1rem;
      margin: 0;
    }

    .stepper-card {
      padding: 2rem;
    }

    .step-content {
      padding: 1.5rem 0;
    }

    .step-content h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1.5rem 0;
    }

    .step-description {
      color: #6b7280;
      font-size: 0.875rem;
      margin-bottom: 1.5rem;
    }

    .full-width {
      width: 100%;
      margin-bottom: 1rem;
    }

    .form-row {
      display: flex;
      gap: 1rem;
      margin-bottom: 1rem;
    }

    .half-width {
      flex: 1;
    }

    .test-types-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
      margin-bottom: 2rem;
    }

    .test-checkbox {
      width: 100%;
      padding: 1rem;
      border: 2px solid #e5e7eb;
      border-radius: 0.5rem;
      transition: all 0.2s ease;
    }

    .test-checkbox:hover {
      border-color: #2C3E50;
      background: #f9fafb;
    }

    ::ng-deep .test-checkbox.mat-mdc-checkbox-checked {
      border-color: #2C3E50;
      background: #f0f9ff;
    }

    .test-type-item {
      margin-left: 0.5rem;
    }

    .test-type-info h3 {
      font-size: 1rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.25rem 0;
    }

    .test-type-info p {
      font-size: 0.875rem;
      color: #6b7280;
      margin: 0;
    }

    .upload-zone {
      border: 2px dashed #d1d5db;
      border-radius: 0.5rem;
      padding: 3rem 2rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s ease;
      margin-bottom: 1.5rem;
    }

    .upload-zone:hover {
      border-color: #2C3E50;
      background: #f9fafb;
    }

    .upload-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      color: #9ca3af;
      margin: 0 auto 1rem;
    }

    .upload-text {
      font-size: 1rem;
      color: #6b7280;
      margin: 0 0 0.5rem 0;
    }

    .upload-hint {
      font-size: 0.875rem;
      color: #9ca3af;
      margin: 0;
    }

    .uploaded-files h3 {
      font-size: 1rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 1rem 0;
    }

    .file-list {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .file-item {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.75rem;
      border: 1px solid #e5e7eb;
      border-radius: 0.375rem;
      background: #f9fafb;
    }

    .file-item mat-icon {
      color: #3b82f6;
    }

    .file-name {
      flex: 1;
      font-size: 0.875rem;
      color: #1f2937;
    }

    .file-size {
      font-size: 0.75rem;
      color: #6b7280;
    }

    .step-actions {
      display: flex;
      justify-content: space-between;
      margin-top: 2rem;
      padding-top: 1rem;
      border-top: 1px solid #e5e7eb;
    }

    .step-actions button mat-icon {
      font-size: 1.25rem;
      width: 1.25rem;
      height: 1.25rem;
    }
  `]
})
export class ProjectCreateComponent {
  basicInfoForm: FormGroup;
  teamForm: FormGroup;
  isSubmitting = false;
  uploadedDocuments: File[] = [];

  // Use direct properties instead of Record to avoid index signature issues
  testTypes = {
    ui: { type: 'ui', enabled: false, name: 'UI Testing' },
    api: { type: 'api', enabled: false, name: 'API Testing' },
    ibmi: { type: 'ibmi', enabled: false, name: 'IBM i Testing' },
    data: { type: 'data', enabled: false, name: 'Data Testing' }
  };

  constructor(
    private fb: FormBuilder,
    private store: Store,
    private router: Router
  ) {
    this.basicInfoForm = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      githubRepo: [''],
      rallyId: [''],
      jiraKey: ['']
    });

    this.teamForm = this.fb.group({
      deliveryManagerName: ['', Validators.required],
      deliveryManagerEmail: ['', [Validators.required, Validators.email]],
      projectOwnerName: ['', Validators.required],
      projectOwnerEmail: ['', [Validators.required, Validators.email]]
    });
  }

  hasSelectedTestTypes(): boolean {
    return Object.values(this.testTypes).some(tt => tt.enabled);
  }

  onDocumentsSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      const newFiles = Array.from(input.files);
      const existingNames = this.uploadedDocuments.map(f => f.name);
      const uniqueFiles = newFiles.filter(f => !existingNames.includes(f.name));
      this.uploadedDocuments.push(...uniqueFiles);
      input.value = '';
    }
  }

  removeDocument(file: File): void {
    const index = this.uploadedDocuments.indexOf(file);
    if (index > -1) {
      this.uploadedDocuments.splice(index, 1);
    }
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  }

  createProject(): void {
    if (this.basicInfoForm.invalid || this.teamForm.invalid || !this.hasSelectedTestTypes()) {
      return;
    }

    this.isSubmitting = true;

    // Build the request matching CreateProjectRequest interface
    const request = {
      name: this.basicInfoForm.value.name,
      description: this.basicInfoForm.value.description,
      github_repo_url: this.basicInfoForm.value.githubRepo,
      rally_project_id: this.basicInfoForm.value.rallyId,
      jira_project_key: this.basicInfoForm.value.jiraKey,
      test_types: Object.values(this.testTypes)
        .filter(tt => tt.enabled)
        .map(tt => ({
          test_type: tt.type as any,
          enabled: true,
          configuration: {}
        }))
    };

    this.store.dispatch(ProjectActions.createProject({ request }));

    console.log('Creating project:', request);
    console.log('Documents to upload:', this.uploadedDocuments);

    setTimeout(() => {
      this.router.navigate(['/projects']);
    }, 1000);
  }
}
