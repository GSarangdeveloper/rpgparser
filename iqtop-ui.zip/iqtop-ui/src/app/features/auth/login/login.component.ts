import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatProgressSpinnerModule
  ],
  template: `
    <div class="login-container">
      <mat-card class="login-card">
        <mat-card-header>
          <div class="logo-container">
            <div class="logo">IQ</div>
          </div>
          <mat-card-title>
            <h1>Welcome to IQTOP</h1>
            <p>Intelligent QA Testing Orchestration Platform</p>
          </mat-card-title>
        </mat-card-header>

        <mat-card-content>
          <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Email</mat-label>
              <input matInput type="email" formControlName="email" placeholder="admin&#64;iqtop.com">
              <mat-error *ngIf="loginForm.get('email')?.hasError('required')">
                Email is required
              </mat-error>
              <mat-error *ngIf="loginForm.get('email')?.hasError('email')">
                Please enter a valid email
              </mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Password</mat-label>
              <input matInput type="password" formControlName="password" placeholder="Enter your password">
              <mat-error *ngIf="loginForm.get('password')?.hasError('required')">
                Password is required
              </mat-error>
            </mat-form-field>

            <div class="error-message" *ngIf="errorMessage">
              {{ errorMessage }}
            </div>

            <button mat-raised-button color="primary" type="submit" class="full-width login-button"
                    [disabled]="loginForm.invalid || loading">
              <span *ngIf="!loading">Sign In</span>
              <mat-spinner *ngIf="loading" diameter="20"></mat-spinner>
            </button>
          </form>

          <div class="demo-credentials">
            <p class="credentials-title">Demo Credentials:</p>
            <p>Admin: admin&#64;iqtop.com / admin123</p>
            <p>Tester: tester&#64;iqtop.com / admin123</p>
          </div>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .login-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 1rem;
    }

    .login-card {
      width: 100%;
      max-width: 28rem;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    mat-card-header {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      padding-bottom: 0;
    }

    .logo-container {
      display: flex;
      justify-content: center;
      margin-bottom: 1rem;
    }

    .logo {
      width: 4rem;
      height: 4rem;
      border-radius: 0.5rem;
      background-color: #2C3E50;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 700;
      font-size: 1.5rem;
    }

    mat-card-title h1 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      text-align: center;
      margin: 0 0 0.5rem 0;
    }

    mat-card-title p {
      text-align: center;
      color: #6b7280;
      font-size: 0.875rem;
      margin: 0;
    }

    mat-card-content {
      padding-top: 1.5rem;
    }

    .full-width {
      width: 100%;
      margin-bottom: 1rem;
    }

    .error-message {
      color: #dc2626;
      padding: 0.75rem;
      background-color: #fee2e2;
      border-radius: 0.375rem;
      margin-bottom: 1rem;
      text-align: center;
      font-size: 0.875rem;
    }

    .login-button {
      height: 3rem;
      font-size: 1rem;
      font-weight: 500;
      margin-top: 0.5rem;
    }

    .demo-credentials {
      text-align: center;
      font-size: 0.875rem;
      color: #6b7280;
      margin-top: 1.5rem;
      padding: 0;
    }

    .credentials-title {
      font-weight: 500;
      margin-bottom: 0.25rem;
    }

    .demo-credentials p {
      margin: 0.25rem 0;
    }
  `]
})
export class LoginComponent {
  loginForm: FormGroup;
  loading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      this.loading = true;
      this.errorMessage = '';

      this.authService.login(this.loginForm.value).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/dashboard']);
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage = error.error?.detail || 'Login failed. Please check your credentials.';
        }
      });
    }
  }
}
