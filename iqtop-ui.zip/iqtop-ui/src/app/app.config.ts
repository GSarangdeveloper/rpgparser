import { ApplicationConfig, provideZoneChangeDetection, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors, withInterceptorsFromDi, HTTP_INTERCEPTORS } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { provideStoreDevtools } from '@ngrx/store-devtools';

import { routes } from './app.routes';
import { jwtInterceptor } from './core/interceptors/jwt.interceptor';
import { errorInterceptor } from './core/interceptors/error.interceptor';
import { MockBackendInterceptor } from './core/interceptors/mock-backend.interceptor';
import { workflowReducer } from './store/workflow/workflow.reducer';
import { projectReducer } from './store/project/project.reducer';
import { WorkflowEffects } from './store/workflow/workflow.effects';
import { ProjectEffects } from './store/project/project.effects';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(
      withInterceptorsFromDi(),
      withInterceptors([jwtInterceptor, errorInterceptor])
    ),
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MockBackendInterceptor,
      multi: true
    },
    provideAnimations(),
    provideStore({
      workflow: workflowReducer,
      project: projectReducer
    }),
    provideEffects([WorkflowEffects, ProjectEffects]),
    provideStoreDevtools({ maxAge: 25 })
  ]
};
