import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';

@Injectable()
export class MockBackendInterceptor implements HttpInterceptor {
  
  // Mock users database
  private users = [
    {
      id: '1',
      email: 'admin@iqtop.com',
      password: 'admin123',
      name: 'Admin User',
      role: 'admin'
    },
    {
      id: '2',
      email: 'tester@iqtop.com',
      password: 'admin123',
      name: 'Tester User',
      role: 'tester'
    }
  ];

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const { url, method, body } = request;

    // Only intercept API calls to localhost:8000
    if (!url.includes('localhost:8000')) {
      return next.handle(request);
    }

    // Handle login request
    if (url.endsWith('/auth/login') && method === 'POST') {
      return this.handleLogin(body);
    }

    // Handle register request
    if (url.endsWith('/auth/register') && method === 'POST') {
      return this.handleRegister(body);
    }

    // Handle projects list
    if (url.includes('/projects') && method === 'GET') {
      return this.handleGetProjects();
    }

    // Handle workflows list
    if (url.includes('/workflows') && method === 'GET') {
      return this.handleGetWorkflows();
    }

    // Pass through any other requests
    return next.handle(request);
  }

  private handleLogin(body: any): Observable<HttpEvent<any>> {
    const { email, password } = body;
    const user = this.users.find(u => u.email === email && u.password === password);

    if (user) {
      const response = {
        access_token: 'mock-jwt-token-' + user.id,
        token_type: 'bearer',
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role
        }
      };
      return of(new HttpResponse({ status: 200, body: response })).pipe(delay(500));
    } else {
      return throwError(() => ({
        status: 401,
        error: { detail: 'Invalid email or password' }
      })).pipe(delay(500));
    }
  }

  private handleRegister(body: any): Observable<HttpEvent<any>> {
    const { email, password, name } = body;
    
    // Check if user already exists
    if (this.users.find(u => u.email === email)) {
      return throwError(() => ({
        status: 400,
        error: { detail: 'User with this email already exists' }
      })).pipe(delay(500));
    }

    // Create new user
    const newUser = {
      id: (this.users.length + 1).toString(),
      email,
      password,
      name,
      role: 'tester'
    };
    this.users.push(newUser);

    const response = {
      access_token: 'mock-jwt-token-' + newUser.id,
      token_type: 'bearer',
      user: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        role: newUser.role
      }
    };
    return of(new HttpResponse({ status: 200, body: response })).pipe(delay(500));
  }

  private handleGetProjects(): Observable<HttpEvent<any>> {
    const projects = [
      {
        id: '1',
        name: 'E-Commerce Platform',
        description: 'Testing suite for e-commerce application',
        created_at: new Date('2024-01-15'),
        updated_at: new Date('2024-01-20'),
        created_by: 'Admin User',
        workflow_count: 5,
        status: 'active'
      },
      {
        id: '2',
        name: 'Mobile Banking App',
        description: 'Security and functional testing',
        created_at: new Date('2024-01-10'),
        updated_at: new Date('2024-01-18'),
        created_by: 'Tester User',
        workflow_count: 3,
        status: 'active'
      }
    ];
    return of(new HttpResponse({ status: 200, body: projects })).pipe(delay(300));
  }

  private handleGetWorkflows(): Observable<HttpEvent<any>> {
    const workflows = [
      {
        workflow_id: '1',
        project_id: '1',
        project_name: 'E-Commerce Platform',
        test_type: 'ui',
        status: 'phase_3_executing',
        current_phase: 3,
        created_by: 'admin@iqtop.com',
        created_by_name: 'Admin User',
        created_at: new Date(),
        started_at: new Date()
      }
    ];
    return of(new HttpResponse({ status: 200, body: workflows })).pipe(delay(300));
  }
}

