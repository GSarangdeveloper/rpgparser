import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import {
  Workflow,
  WorkflowPhase,
  WorkflowSummary,
  StartWorkflowRequest,
  ApproveWorkflowRequest,
  TestScenario,
  TestExecution
} from '../models';

@Injectable({
  providedIn: 'root'
})
export class WorkflowService {
  private apiUrl = `${environment.apiUrl}/workflows`;

  constructor(private http: HttpClient) {}

  getWorkflows(projectId?: string): Observable<WorkflowSummary[]> {
    const url = projectId ? `${this.apiUrl}?project_id=${projectId}` : this.apiUrl;
    return this.http.get<WorkflowSummary[]>(url);
  }

  getWorkflow(workflowId: string): Observable<Workflow> {
    return this.http.get<Workflow>(`${this.apiUrl}/${workflowId}`);
  }

  getWorkflowPhases(workflowId: string): Observable<WorkflowPhase[]> {
    return this.http.get<WorkflowPhase[]>(`${this.apiUrl}/${workflowId}/phases`);
  }

  getWorkflowScenarios(workflowId: string): Observable<TestScenario> {
    return this.http.get<TestScenario>(`${this.apiUrl}/${workflowId}/scenarios`);
  }

  getWorkflowExecutions(workflowId: string): Observable<TestExecution[]> {
    return this.http.get<TestExecution[]>(`${this.apiUrl}/${workflowId}/executions`);
  }

  startWorkflow(request: StartWorkflowRequest): Observable<Workflow> {
    const endpoint = `${this.apiUrl}/${request.test_type}-test`;
    return this.http.post<Workflow>(endpoint, request);
  }

  approveWorkflow(request: ApproveWorkflowRequest): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(
      `${this.apiUrl}/${request.workflow_id}/approve`,
      { scenarios: request.scenarios, edited: request.edited }
    );
  }

  cancelWorkflow(workflowId: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(
      `${this.apiUrl}/${workflowId}/cancel`,
      {}
    );
  }

  getWorkflowArtifacts(workflowId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${workflowId}/artifacts`);
  }
}
