import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Artifact, UploadDocumentResponse } from '../models';

@Injectable({
  providedIn: 'root'
})
export class DocumentService {
  private apiUrl = `${environment.apiUrl}/documents`;

  constructor(private http: HttpClient) {}

  uploadDocument(file: File, projectId?: string, workflowId?: string): Observable<UploadDocumentResponse> {
    const formData = new FormData();
    formData.append('file', file);
    if (projectId) {
      formData.append('project_id', projectId);
    }
    if (workflowId) {
      formData.append('workflow_id', workflowId);
    }

    return this.http.post<UploadDocumentResponse>(this.apiUrl, formData);
  }

  getDocuments(projectId?: string): Observable<Artifact[]> {
    const url = projectId ? `${this.apiUrl}?project_id=${projectId}` : this.apiUrl;
    return this.http.get<Artifact[]>(url);
  }

  deleteDocument(documentId: string): Observable<{ success: boolean }> {
    return this.http.delete<{ success: boolean }>(`${this.apiUrl}/${documentId}`);
  }

  downloadDocument(documentId: string): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/${documentId}/download`, {
      responseType: 'blob'
    });
  }
}
