export interface Project {
  id: string;
  name: string;
  description?: string;
  github_repo_url?: string;
  rally_project_id?: string;
  jira_project_key?: string;
  created_by: string;
  created_at: Date;
  updated_at: Date;
  is_archived: boolean;
  test_types?: ProjectTestType[];
}

export interface ProjectTestType {
  test_type: TestType;
  enabled: boolean;
  configuration: any;
}

export type TestType = 'ui' | 'api' | 'legacy' | 'standalone';

export interface CreateProjectRequest {
  name: string;
  description?: string;
  github_repo_url?: string;
  rally_project_id?: string;
  jira_project_key?: string;
  test_types: ProjectTestType[];
  team_members?: string[];
}

export interface UITestConfiguration {
  test_environment: string;
  browsers: ('chromium' | 'firefox' | 'webkit')[];
  figma_token?: string;
  timeout_ms: number;
  video_mode: 'on-failure' | 'always' | 'never';
  screenshot_mode: 'on-failure' | 'always' | 'never';
  auto_defect_logging: {
    rally: boolean;
    jira: boolean;
  };
  severity_threshold: 'low' | 'medium' | 'high' | 'critical';
}

export interface APITestConfiguration {
  base_url: string;
  authentication_type: 'none' | 'basic' | 'bearer' | 'oauth2';
  timeout_ms: number;
}

export interface IBMITestConfiguration {
  host: string;
  port: number;
  username: string;
  library: string;
}
