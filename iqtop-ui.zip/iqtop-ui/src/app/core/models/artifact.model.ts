export type ArtifactType = 'script' | 'report' | 'screenshot' | 'video' | 'trace' | 'document';

export interface Artifact {
  id: string;
  workflow_id: string;
  artifact_type: ArtifactType;
  file_name: string;
  storage_url: string;
  file_size_bytes?: number;
  mime_type?: string;
  checksum?: string;
  created_at: Date;
}

export interface UploadDocumentRequest {
  project_id?: string;
  workflow_id?: string;
  file: File;
  artifact_type: ArtifactType;
}

export interface UploadDocumentResponse {
  artifact_id: string;
  storage_url: string;
  file_name: string;
}
