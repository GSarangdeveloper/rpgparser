export type WorkflowStatus =
  | 'pending'
  | 'phase_1_generating'
  | 'phase_2_awaiting_review'
  | 'phase_3_executing'
  | 'phase_4_defects'
  | 'phase_5_scripts'
  | 'phase_6_reporting'
  | 'phase_7_regression'
  | 'phase_8_committing'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface Workflow {
  id: string;
  project_id: string;
  test_type: 'ui' | 'api' | 'legacy' | 'standalone';
  status: WorkflowStatus;
  current_phase: number;
  input_data: any;
  created_by: string;
  started_at?: Date;
  completed_at?: Date;
  duration_ms?: number;
  created_at: Date;
  updated_at: Date;
}

export interface WorkflowPhase {
  id: string;
  workflow_id: string;
  phase_number: number;
  phase_name: string;
  agent_name?: string;
  status: string;
  input_data?: any;
  output_data?: any;
  error_message?: string;
  error_stack_trace?: string;
  started_at?: Date;
  completed_at?: Date;
  duration_ms?: number;
  created_at: Date;
}

export interface TestScenario {
  id: string;
  workflow_id: string;
  scenario_json: any;
  approved: boolean;
  approved_by?: string;
  approved_at?: Date;
  edited: boolean;
  created_at: Date;
}

export interface TestExecution {
  id: string;
  workflow_id: string;
  scenario_id?: string;
  test_name: string;
  status: 'passed' | 'failed' | 'skipped' | 'flaky';
  execution_time_ms?: number;
  browser?: string;
  error_message?: string;
  stack_trace?: string;
  screenshot_url?: string;
  video_url?: string;
  trace_url?: string;
  executed_at: Date;
}

export interface StartWorkflowRequest {
  project_id: string;
  test_type: 'ui' | 'api' | 'legacy' | 'standalone';
  input_data: any;
}

export interface UIWorkflowInput {
  figma_url: string;
  rally_story_id: string;
  additional_documents?: string[];
}

export interface ApproveWorkflowRequest {
  workflow_id: string;
  scenarios: any[];
  edited: boolean;
}

export interface WorkflowSummary {
  workflow_id: string;
  project_id: string;
  project_name: string;
  test_type: string;
  status: WorkflowStatus;
  current_phase: number;
  created_by: string;
  created_by_name: string;
  created_at: Date;
  started_at?: Date;
  completed_at?: Date;
  duration_ms?: number;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  defects_logged: number;
  github_pr_url?: string;
}
