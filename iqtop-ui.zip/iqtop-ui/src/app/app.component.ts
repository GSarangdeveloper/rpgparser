import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive, Router } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { Subject, takeUntil } from 'rxjs';
import { AuthService } from './core/services/auth.service';
import { SocketService } from './core/services/socket.service';
import { User } from './core/models';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule
  ],
  template: `
    <div class="app-container" *ngIf="isAuthenticated">
      <mat-sidenav-container class="sidenav-container">
        <mat-sidenav mode="side" opened class="sidenav">
          <div class="sidebar-header">
            <div class="logo-badge">IQ</div>
            <span class="logo-text">IQTOP</span>
          </div>

          <div class="nav-section">
            <div class="nav-label">Navigation</div>
            <mat-nav-list>
              <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
                <mat-icon>home</mat-icon>
                <span>Dashboard</span>
              </a>

              <a mat-list-item routerLink="/projects" routerLinkActive="active">
                <mat-icon>folder_open</mat-icon>
                <span>Projects</span>
              </a>

              <a mat-list-item routerLink="/documents" routerLinkActive="active">
                <mat-icon>psychology</mat-icon>
                <span>Knowledge Base</span>
              </a>
            </mat-nav-list>
          </div>

          <div class="nav-section">
            <div class="nav-label">Tools</div>
            <mat-nav-list>
              <a mat-list-item routerLink="/test-tools" routerLinkActive="active">
                <mat-icon>construction</mat-icon>
                <span>Test Tools</span>
              </a>
            </mat-nav-list>
          </div>

          <div class="nav-section">
            <div class="nav-label">My Workflows</div>
            <mat-nav-list>
              <a mat-list-item routerLink="/workflows" routerLinkActive="active">
                <mat-icon>sync</mat-icon>
                <span>All Workflows</span>
              </a>
            </mat-nav-list>
          </div>
        </mat-sidenav>

        <mat-sidenav-content>
          <mat-toolbar class="top-toolbar">
            <span class="spacer"></span>

            <button mat-icon-button class="toolbar-button">
              <mat-icon>notifications_none</mat-icon>
            </button>

            <button mat-icon-button class="toolbar-button">
              <mat-icon>dark_mode</mat-icon>
            </button>

            <button mat-icon-button [matMenuTriggerFor]="userMenu" class="toolbar-button">
              <mat-icon>account_circle</mat-icon>
            </button>
            <mat-menu #userMenu="matMenu">
              <div class="user-menu-header">
                <div class="user-info">
                  <div class="user-name">{{ currentUser?.full_name || 'User' }}</div>
                  <div class="user-email">{{ currentUser?.email }}</div>
                </div>
              </div>
              <mat-divider></mat-divider>
              <button mat-menu-item>
                <mat-icon>person</mat-icon>
                <span>Profile</span>
              </button>
              <button mat-menu-item>
                <mat-icon>settings</mat-icon>
                <span>Settings</span>
              </button>
              <mat-divider></mat-divider>
              <button mat-menu-item (click)="logout()">
                <mat-icon>logout</mat-icon>
                <span>Logout</span>
              </button>
            </mat-menu>
          </mat-toolbar>

          <div class="content">
            <router-outlet></router-outlet>
          </div>
        </mat-sidenav-content>
      </mat-sidenav-container>
    </div>

    <div class="auth-container" *ngIf="!isAuthenticated">
      <router-outlet></router-outlet>
    </div>
  `,
  styles: [`
    .app-container {
      height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .sidenav-container {
      flex: 1;
    }

    .sidenav {
      width: 250px;
      background-color: #2C3E50;
      color: white;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
    }

    .sidebar-header {
      padding: 1.5rem;
      display: flex;
      align-items: center;
      gap: 0.75rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .logo-badge {
      width: 2.5rem;
      height: 2.5rem;
      background-color: white;
      color: #2C3E50;
      border-radius: 0.5rem;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 1rem;
    }

    .logo-text {
      font-size: 1.25rem;
      font-weight: 700;
      color: white;
    }

    .nav-section {
      padding: 1.5rem 0;
    }

    .nav-label {
      padding: 0 1.5rem;
      font-size: 0.75rem;
      font-weight: 600;
      color: rgba(255, 255, 255, 0.5);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 0.5rem;
    }

    mat-nav-list {
      padding: 0;
    }

    mat-nav-list a {
      color: rgba(255, 255, 255, 0.7);
      transition: all 0.2s ease;
      margin: 0.25rem 0.75rem;
      border-radius: 0.5rem;
      height: 2.5rem;
    }

    mat-nav-list a:hover {
      background-color: rgba(255, 255, 255, 0.1);
      color: white;
    }

    mat-nav-list a.active {
      background-color: rgba(255, 255, 255, 0.15);
      color: white;
    }

    mat-nav-list a mat-icon {
      margin-right: 0.75rem;
      color: rgba(255, 255, 255, 0.7);
      font-size: 1.25rem;
      width: 1.25rem;
      height: 1.25rem;
    }

    mat-nav-list a.active mat-icon {
      color: #27AE60;
    }

    mat-nav-list a span {
      font-size: 0.875rem;
      font-weight: 500;
    }

    .top-toolbar {
      background-color: white;
      color: #1f2937;
      border-bottom: 1px solid #e5e7eb;
      height: 64px;
      padding: 0 1.5rem;
    }

    .toolbar-button {
      color: #6b7280;
      margin-left: 0.5rem;
    }

    .toolbar-button:hover {
      background-color: #f3f4f6;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .user-menu-header {
      padding: 1rem;
      background-color: #f9fafb;
    }

    .user-info {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
    }

    .user-name {
      font-weight: 600;
      color: #1f2937;
      font-size: 0.875rem;
    }

    .user-email {
      font-size: 0.75rem;
      color: #6b7280;
    }

    .content {
      padding: 2rem;
      background-color: #f9fafb;
      min-height: calc(100vh - 64px);
    }

    .auth-container {
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
  `]
})
export class AppComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  currentUser: User | null = null;
  isAuthenticated = false;
  pageTitle = 'Dashboard';

  constructor(
    private authService: AuthService,
    private socketService: SocketService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.authService.currentUser$
      .pipe(takeUntil(this.destroy$))
      .subscribe(user => {
        this.currentUser = user;
        this.isAuthenticated = this.authService.isAuthenticated();

        if (this.isAuthenticated) {
          this.socketService.connect();
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.socketService.disconnect();
  }

  logout(): void {
    this.authService.logout();
    this.socketService.disconnect();
    this.router.navigate(['/auth/login']);
  }
}
