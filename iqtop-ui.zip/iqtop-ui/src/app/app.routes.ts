import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'auth',
    loadChildren: () => import('./features/auth/auth.routes').then(m => m.AUTH_ROUTES)
  },
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadChildren: () => import('./features/dashboard/dashboard.routes').then(m => m.DASHBOARD_ROUTES)
  },
  {
    path: 'projects',
    canActivate: [authGuard],
    loadChildren: () => import('./features/projects/projects.routes').then(m => m.PROJECTS_ROUTES)
  },
  {
    path: 'workflows',
    canActivate: [authGuard],
    loadChildren: () => import('./features/workflows/workflows.routes').then(m => m.WORKFLOWS_ROUTES)
  },
  {
    path: 'test-gen',
    canActivate: [authGuard],
    loadChildren: () => import('./features/standalone-test-gen/standalone-test-gen.routes').then(m => m.STANDALONE_TEST_GEN_ROUTES)
  },
  {
    path: 'test-tools',
    canActivate: [authGuard],
    loadChildren: () => import('./features/test-tools/test-tools.routes').then(m => m.TEST_TOOLS_ROUTES)
  },
  {
    path: 'documents',
    canActivate: [authGuard],
    loadChildren: () => import('./features/documents/documents.routes').then(m => m.DOCUMENTS_ROUTES)
  },
  {
    path: '**',
    redirectTo: '/dashboard'
  }
];
