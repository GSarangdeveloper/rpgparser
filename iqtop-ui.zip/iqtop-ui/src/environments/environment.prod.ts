export const environment = {
  production: true,
  apiUrl: 'https://api.iqtop.com/api/v1',
  wsUrl: 'https://api.iqtop.com',
  appName: 'IQTOP',
  version: '1.0.0'
};
