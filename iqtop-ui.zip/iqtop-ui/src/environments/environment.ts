export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000/api/v1',
  wsUrl: 'http://localhost:8000',
  appName: 'IQTOP',
  version: '1.0.0'
};
