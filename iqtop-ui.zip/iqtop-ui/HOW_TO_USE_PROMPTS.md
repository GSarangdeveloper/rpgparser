# 🚀 How to Use These Prompts in Lovable and Replit

## 📋 What You Have

I've created **two comprehensive prompts** that will generate the exact same IQTOP UI:

1. **LOVABLE_PROMPT.md** - Optimized for Lovable (formerly GPT Engineer)
2. **REPLIT_PROMPT.md** - Optimized for Replit Agent

Both prompts contain:
- ✅ Complete Angular 18+ specifications
- ✅ All TypeScript models and interfaces
- ✅ Detailed component descriptions with HTML templates
- ✅ Service implementations with methods
- ✅ NgRx store architecture
- ✅ Styling and theme specifications
- ✅ Backend API integration details
- ✅ Socket.IO real-time configuration

---

## 🎨 Option 1: Using Lovable

### What is Lovable?
Lovable (formerly GPT Engineer) is an AI-powered development tool that generates complete applications from prompts.

Website: https://lovable.dev

### Steps to Generate Your UI in Lovable:

1. **Sign Up / Log In**
   - Go to https://lovable.dev
   - Create an account or log in

2. **Create New Project**
   - Click "New Project"
   - Choose "Start from scratch"

3. **Copy and Paste the Prompt**
   - Open `LOVABLE_PROMPT.md`
   - Copy the **ENTIRE** contents (it's detailed for a reason!)
   - Paste into Lovable's chat interface

4. **Let Lovable Generate**
   - Lovable will start generating your application
   - It may take 5-10 minutes to generate all files
   - It will create the complete file structure

5. **Review and Iterate**
   - Check the generated code
   - If something isn't right, ask Lovable to fix it:
     * "The login button styling is incorrect, please fix"
     * "Add more padding to the dashboard cards"
     * "The workflow monitor needs better spacing"

6. **Deploy**
   - Lovable can deploy directly to Vercel/Netlify
   - Or download the code and deploy manually

### 💡 Tips for Lovable:
- The prompt is very detailed - don't modify it unless you want changes
- Lovable works best with React/Next.js, but supports Angular
- If Lovable suggests using React instead, tell it: "Please use Angular 18+ as specified"
- You can ask for modifications after generation

---

## 💻 Option 2: Using Replit

### What is Replit?
Replit is an online IDE with AI-powered code generation through Replit Agent.

Website: https://replit.com

### Steps to Generate Your UI in Replit:

1. **Sign Up / Log In**
   - Go to https://replit.com
   - Create an account or log in

2. **Create New Repl**
   - Click "Create Repl"
   - Choose "Angular" as the template
   - Name it "iqtop-ui"

3. **Open Replit Agent**
   - Look for the AI/Agent icon (⚡ or robot icon)
   - Or press `Ctrl+K` (Windows) or `Cmd+K` (Mac)

4. **Copy and Paste the Prompt**
   - Open `REPLIT_PROMPT.md`
   - Copy the **ENTIRE** contents
   - Paste into Replit Agent's chat

5. **Let Replit Agent Generate**
   - Agent will start generating files
   - It will create the folder structure
   - It will install dependencies
   - It may take 10-15 minutes

6. **Run the Application**
   - Replit will automatically detect it's an Angular app
   - Click "Run" button
   - The app will start on a Replit preview URL

7. **Iterate if Needed**
   - If something isn't working, ask Agent:
     * "The dashboard component isn't loading, please fix"
     * "Update the colors to match the theme"
     * "Fix the TypeScript errors in workflow.service.ts"

### 💡 Tips for Replit:
- Replit Agent is very good with full-stack applications
- The preview will be live as you make changes
- You can share the Replit with your team
- Export the code anytime by downloading the Repl

---

## 🔄 Option 3: Hybrid Approach (Recommended)

For best results, you can use **both tools together**:

### Workflow:
1. **Start with Lovable** (faster generation)
   - Lovable generates the initial codebase quickly
   - Download the generated code

2. **Import to Replit** (better development experience)
   - Upload the Lovable code to Replit
   - Use Replit Agent to fix issues and add features
   - Develop and test in Replit's IDE

3. **Refine with Either**
   - Use whichever tool you prefer for refinements
   - Both can modify existing code

---

## 🎯 What to Expect After Generation

### You Should Get:

```
iqtop-ui/
├── src/
│   ├── app/
│   │   ├── core/              ✅ 5 services, guards, interceptors
│   │   ├── store/             ✅ NgRx stores
│   │   ├── features/          ✅ 6 feature modules
│   │   ├── app.component.ts   ✅ Main layout
│   │   └── app.routes.ts      ✅ Routing
│   ├── environments/          ✅ Environment configs
│   ├── styles.scss            ✅ Global styles
│   └── index.html             ✅ Main HTML
├── angular.json               ✅ Angular config
├── package.json               ✅ Dependencies
└── tsconfig.json              ✅ TypeScript config
```

### Application Features:
- ✅ Login page (working)
- ✅ Dashboard (with stats and table)
- ✅ Main layout (sidebar + toolbar)
- ✅ Project list
- ✅ Project create wizard
- ✅ Workflow monitor
- ✅ Real-time Socket.IO integration
- ✅ NgRx state management

---

## 🐛 Common Issues and Fixes

### Issue 1: "Module not found" errors
**Fix:**
```bash
npm install
# or if specific package missing:
npm install @angular/material primeng socket.io-client @ngrx/store
```

### Issue 2: TypeScript errors
**Ask the AI:**
"There are TypeScript errors in [filename]. Please fix the type definitions."

### Issue 3: Components not showing
**Ask the AI:**
"The [component name] isn't rendering. Please check the routing and fix."

### Issue 4: Backend connection errors
**Update environment.ts:**
```typescript
export const environment = {
  apiUrl: 'YOUR_BACKEND_URL/api/v1',
  wsUrl: 'YOUR_BACKEND_URL'
};
```

### Issue 5: Styling issues
**Ask the AI:**
"The styling doesn't match the mockup. Please update the CSS to match the design specifications in the original prompt."

---

## 📝 Customization After Generation

Once generated, you can ask either tool to modify:

### Change Colors:
```
"Update the primary color to #1976D2 (blue) instead of #2C3E50"
```

### Add Features:
```
"Add a search bar to the project list component"
```

### Fix Bugs:
```
"The workflow approval dialog isn't working. Please fix the modal trigger."
```

### Improve UX:
```
"Add loading skeletons to the dashboard while data loads"
```

---

## 🔗 Backend Integration

After generation, connect to your FastAPI backend:

1. **Update Environment:**
   ```typescript
   // src/environments/environment.ts
   export const environment = {
     apiUrl: 'http://localhost:8000/api/v1',
     wsUrl: 'http://localhost:8000'
   };
   ```

2. **Start Backend:**
   ```bash
   # Your FastAPI backend should be running on port 8000
   ```

3. **Test Connection:**
   - Try logging in with demo credentials
   - Check browser console for API calls
   - Verify Socket.IO connection

---

## 🎓 Learning Resources

If you want to understand the generated code:

- **Angular Docs**: https://angular.io/docs
- **Angular Material**: https://material.angular.io/
- **PrimeNG**: https://primeng.org/
- **NgRx**: https://ngrx.io/
- **Socket.IO**: https://socket.io/docs/v4/

---

## ✅ Checklist Before Starting

- [ ] Decide which tool to use (Lovable or Replit)
- [ ] Have the prompt file ready (LOVABLE_PROMPT.md or REPLIT_PROMPT.md)
- [ ] Know your backend API URL
- [ ] Have demo credentials ready (admin@iqtop.com / admin123)
- [ ] Understand you might need to iterate with the AI

---

## 🆘 If Generation Fails

### Option A: Try the Other Tool
If Lovable doesn't work well, try Replit (or vice versa)

### Option B: Use the Manual Code
You already have the complete Angular code in the `iqtop-ui/` folder:
```bash
cd iqtop-ui
npm install
npm start
```

### Option C: Ask for Help
Both Lovable and Replit have support:
- Lovable: Discord community
- Replit: Community forums and support

---

## 🎉 Expected Timeline

### Lovable:
- Generation: 5-10 minutes
- Testing: 5-10 minutes
- Minor fixes: 10-20 minutes
- **Total: ~30-40 minutes to working app**

### Replit:
- Generation: 10-15 minutes
- Testing: 5-10 minutes
- Minor fixes: 10-20 minutes
- **Total: ~35-45 minutes to working app**

### Manual (Existing Code):
- Install: 2-5 minutes
- Run: 1 minute
- **Total: ~5 minutes to working app**

---

## 💡 Pro Tips

1. **Be Patient**: AI code generation takes time
2. **Read the Generated Code**: Understand what was created
3. **Test Thoroughly**: Check all features work
4. **Iterate Gradually**: Make one change at a time
5. **Save Your Work**: Download/commit regularly
6. **Keep Backend Running**: Frontend needs API to be fully functional

---

## 🚀 Quick Start Command

### For Lovable:
1. Copy `LOVABLE_PROMPT.md` contents
2. Paste into Lovable chat
3. Wait for generation
4. Deploy or download

### For Replit:
1. Create Angular Repl
2. Copy `REPLIT_PROMPT.md` contents
3. Paste into Replit Agent
4. Wait for generation
5. Click Run

**That's it! You should have a working IQTOP UI in under an hour!** 🎉

---

## 📞 Need Help?

If you're stuck:
1. Check the error messages carefully
2. Ask the AI tool to fix specific issues
3. Refer to the existing code in `iqtop-ui/` folder
4. Check Angular/Material/PrimeNG documentation

**Remember: The prompts are comprehensive and detailed. Trust the process!** ✨
