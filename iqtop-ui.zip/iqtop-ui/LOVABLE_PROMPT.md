# LOVABLE PROMPT - IQTOP Platform UI

Copy and paste this entire prompt into Lovable:

---

Create a complete Angular 18+ web application called "IQTOP - Intelligent QA Testing Orchestration Platform" with the following specifications:

## TECH STACK
- Angular 18+ with standalone components
- TypeScript with strict mode
- Angular Material for UI components
- PrimeNG for advanced data tables and components
- NgRx for state management (Store, Effects, Selectors)
- Socket.IO client for real-time updates
- RxJS for reactive programming
- SCSS for styling

## PROJECT STRUCTURE
```
src/app/
├── core/
│   ├── models/
│   │   ├── user.model.ts (User, LoginRequest, LoginResponse, UserRole)
│   │   ├── project.model.ts (Project, CreateProjectRequest, TestType, UITestConfiguration, APITestConfiguration, IBMITestConfiguration)
│   │   ├── workflow.model.ts (Workflow, WorkflowPhase, TestScenario, WorkflowStatus, StartWorkflowRequest, ApproveWorkflowRequest)
│   │   └── artifact.model.ts (Artifact, ArtifactType, UploadDocumentRequest)
│   ├── services/
│   │   ├── auth.service.ts
│   │   ├── socket.service.ts
│   │   ├── workflow.service.ts
│   │   ├── project.service.ts
│   │   └── document.service.ts
│   ├── guards/
│   │   └── auth.guard.ts
│   └── interceptors/
│       ├── jwt.interceptor.ts
│       └── error.interceptor.ts
├── store/
│   ├── workflow/ (actions, reducer, effects, selectors)
│   └── project/ (actions, reducer, effects, selectors)
└── features/
    ├── auth/login/
    ├── dashboard/
    ├── projects/ (list, create, detail)
    ├── workflows/ (list, monitor)
    ├── standalone-test-gen/
    └── documents/
```

## MODELS & TYPES

### User Models
```typescript
type UserRole = 'admin' | 'tester' | 'viewer';
interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  is_active: boolean;
  created_at: Date;
}
```

### Project Models
```typescript
type TestType = 'ui' | 'api' | 'legacy' | 'standalone';
interface Project {
  id: string;
  name: string;
  description?: string;
  github_repo_url?: string;
  rally_project_id?: string;
  jira_project_key?: string;
  created_by: string;
  created_at: Date;
  test_types?: ProjectTestType[];
}
```

### Workflow Models
```typescript
type WorkflowStatus = 'pending' | 'phase_1_generating' | 'phase_2_awaiting_review' | 'phase_3_executing' | 'phase_4_defects' | 'phase_5_scripts' | 'phase_6_reporting' | 'phase_7_regression' | 'phase_8_committing' | 'completed' | 'failed' | 'cancelled';

interface Workflow {
  id: string;
  project_id: string;
  test_type: TestType;
  status: WorkflowStatus;
  current_phase: number;
  created_at: Date;
  started_at?: Date;
  completed_at?: Date;
}
```

## BACKEND API CONFIGURATION
- Base API URL: http://localhost:8000/api/v1
- WebSocket URL: http://localhost:8000
- Authentication: JWT Bearer token
- All HTTP requests need Authorization header

### API Endpoints
```
POST   /auth/login
GET    /projects
POST   /projects
GET    /projects/{id}
GET    /workflows
POST   /workflows/ui-test
POST   /workflows/api-test
GET    /workflows/{id}
GET    /workflows/{id}/phases
POST   /workflows/{id}/approve
POST   /documents (multipart/form-data)
```

### WebSocket Events (Socket.IO)
```javascript
// Client subscribes to:
socket.on('workflow_update', (data) => {
  // data: { workflow_id, phase, status, output_data }
});
socket.on('phase_complete', (data) => {});
socket.on('workflow_complete', (data) => {});
```

## CORE SERVICES

### AuthService
- login(credentials) → Observable<LoginResponse>
- logout() → void
- getToken() → string | null
- getUser() → User | null
- isAuthenticated() → boolean
- Store token and user in localStorage

### SocketService
- connect() → void (connects with JWT token)
- disconnect() → void
- on<T>(event: string) → Observable<T>
- emit(event, data) → void

### WorkflowService
- getWorkflows(projectId?) → Observable<WorkflowSummary[]>
- getWorkflow(id) → Observable<Workflow>
- getWorkflowPhases(id) → Observable<WorkflowPhase[]>
- startWorkflow(request) → Observable<Workflow>
- approveWorkflow(request) → Observable<{success: boolean}>

### ProjectService
- getProjects() → Observable<Project[]>
- getProject(id) → Observable<Project>
- createProject(request) → Observable<Project>

## NGRX STORE

### Workflow State
```typescript
interface WorkflowState {
  workflows: WorkflowSummary[];
  currentWorkflow: Workflow | null;
  phases: WorkflowPhase[];
  loading: boolean;
  error: string | null;
}
```

Actions: loadWorkflows, loadWorkflow, startWorkflow, approveWorkflow, workflowPhaseUpdate
Effects: Handle API calls and Socket.IO updates
Selectors: selectAllWorkflows, selectCurrentWorkflow, selectWorkflowPhases

### Project State
Similar structure for projects

## GUARDS & INTERCEPTORS

### AuthGuard
- Checks if user is authenticated
- Redirects to /auth/login if not
- Protects all routes except /auth/*

### JWT Interceptor
- Adds Authorization: Bearer <token> to all HTTP requests
- Get token from AuthService

### Error Interceptor
- Catches 401 errors → logout and redirect to login
- Handle other HTTP errors gracefully

## UI COMPONENTS

### App Component (Main Layout)
```
┌─────────────────────────────────────────┐
│ [Logo] IQTOP      [Notifications] [👤▼]│ ← Mat-Toolbar (primary color)
├──────┬──────────────────────────────────┤
│      │                                  │
│ Nav  │         Content Area            │
│      │                                  │
│ ☰    │    <router-outlet>              │
│ 🏠   │                                  │
│ 📊   │                                  │
│ 🧪   │                                  │
│ ⚡   │                                  │
│ 📚   │                                  │
│      │                                  │
└──────┴──────────────────────────────────┘
```

Sidebar (MatSidenav - 250px width):
- Dark background (#2C3E50)
- White text
- Navigation items:
  * Dashboard (home icon)
  * Projects (folder icon)
  * Workflows (account_tree icon)
  * Quick Test Gen (bolt icon)
  * Documents (description icon)

### Login Component
Full-screen centered card with:
- Logo and tagline
- Email input (with validation)
- Password input
- Login button (Material raised button, primary color)
- Loading spinner during login
- Error message display
- Demo credentials text at bottom
- Gradient background: linear-gradient(135deg, #667eea 0%, #764ba2 100%)

### Dashboard Component
Grid layout with:

**Stats Cards (4 cards in grid):**
1. Active Projects (count + icon)
2. Total Workflows (count + icon)
3. Tests Run (count + icon)
4. Defects Logged (count + icon)

**Workflow Table:**
- PrimeNG p-table with pagination
- Columns: Project Name, Type, Status, Phase, Created Date, Actions
- Status badges with colors:
  * pending: yellow
  * running: blue
  * completed: green
  * failed: red
  * awaiting: orange
- Action button: View (eye icon) → navigate to workflow detail

**Quick Actions:**
- "Create New Project" button (primary)
- "Quick Test Generation" button (accent)

### Project List Component
Grid of project cards:
- Each card shows: name, description, created date
- Click card → navigate to /projects/{id}
- "Create New Project" button at top

### Project Create Component (Multi-step form)
Material Stepper with 4 steps:

**Step 1: Basic Information**
- Project Name (required)
- Description (textarea)
- GitHub Repository URL
- Rally Project ID
- Jira Project Key

**Step 2: Test Type Configuration**
Checkboxes for test types:
- ☑️ UI Testing (Playwright)
  * When checked, show config panel:
    - Test Environment URL
    - Browser selection: Chromium, Firefox, WebKit (checkboxes)
    - Figma Token (optional)
    - Video mode: dropdown (on-failure, always, never)
    - Screenshot mode: dropdown
    - Auto-create defects: Rally checkbox, Jira checkbox

- ☑️ API Testing
  * When checked, show config panel:
    - Base URL
    - Authentication type: dropdown (none, basic, bearer, oauth2)
    - Timeout (ms)

- ☑️ IBMI Testing
  * When checked, show config panel:
    - Host
    - Port
    - Username
    - Library

- ☐ Legacy Modernization

**Step 3: Team Members**
- Add team members (autocomplete search)
- Display added members with remove button

**Step 4: Upload Context Documents**
- Drag-and-drop file upload zone (use ngx-dropzone)
- Show uploaded files with size and remove button
- Supported formats: PDF, DOCX, TXT, JSON, YAML

Final step: "Create Project" button (dispatches to NgRx store)

### Project Detail Component
Tabs:
1. Overview (project info, stats)
2. Workflows (list of workflows for this project)
3. Configuration (view test type configs)
4. Documents (list uploaded documents)

### Workflow Monitor Component
**Visual 8-Phase Progress:**

```
Phase 1: Design Analysis          ✅ Completed (60s)
├─ Fetched Figma design
├─ Fetched Rally story
└─ Generated 15 scenarios via GPT-4

Phase 2: Human Approval            🟡 Waiting
└─ [Review & Approve Scenarios] button

Phase 3: Functional Testing        ⏸️ Pending
Phase 4: Defect Analysis           ⏸️ Pending
Phase 5: Script Generation         ⏸️ Pending
Phase 6: Reporting                 ⏸️ Pending
Phase 7: Regression Baselining     ⏸️ Pending
Phase 8: GitHub Integration        ⏸️ Pending
```

Each phase shows:
- Phase icon with status color (✅ green, 🔄 blue, ⏸️ gray, ❌ red)
- Phase name
- Agent name (if available)
- Duration (if completed)
- Expandable details (output data)

**Approval Dialog (when Phase 2 waiting):**
- Modal showing generated test scenarios
- Each scenario in expandable panel:
  * Scenario title
  * Test steps (numbered list)
  * Expected result
  * Priority
  * [Edit] button
- Checkbox to select/deselect scenarios
- [Approve & Run] button (dispatches approveWorkflow action)

**Real-time Updates:**
Subscribe to Socket.IO 'workflow_update' event
Update phases in real-time as workflow progresses

### Standalone Test Generation Component
Simple form:
- Test Type radio buttons (UI, API, Legacy)
- Feature Description (textarea)
- Upload documents (drag-drop)
- Generation options:
  * Include happy paths (checkbox)
  * Include edge cases (checkbox)
  * Include negative scenarios (checkbox)
  * Detail level: radio buttons (Brief, Detailed)
  * Scenario count: number input (1-50)
- [Generate Scenarios] button
- Results section:
  * Display generated scenarios in cards
  * Export buttons: PDF, Excel, JSON, Copy

### Document Library Component
Two-panel layout:
**Left panel (30%):**
- Tree view of documents (PrimeNG p-tree)
- Organized by project folders
- Global/Shared folder

**Right panel (70%):**
- Document preview area
- Selected document info
- Actions: Download, Delete
- Upload button at top

## STYLING & THEME

### Colors
```scss
:root {
  --primary-color: #2C3E50;
  --secondary-color: #27AE60;
  --accent-color: #E67E22;
  --success-color: #27AE60;
  --warning-color: #F39C12;
  --danger-color: #E74C3C;
  --info-color: #3498DB;
}
```

### Global Styles
- Font: 'Inter', sans-serif
- Background: #f5f7fa
- Card shadows: subtle (0 2px 4px rgba(0,0,0,0.1))
- Border radius: 8px for cards
- Button padding: 0.75rem 1.5rem

### Status Badges
```scss
.status-pending { background: #FFF3CD; color: #856404; }
.status-running { background: #D1ECF1; color: #0C5460; }
.status-completed { background: #D4EDDA; color: #155724; }
.status-failed { background: #F8D7DA; color: #721C24; }
```

## ROUTING
```typescript
/ → redirect to /dashboard
/auth/login → LoginComponent (no guard)
/dashboard → DashboardComponent (authGuard)
/projects → ProjectListComponent (authGuard, lazy loaded)
/projects/create → ProjectCreateComponent (authGuard)
/projects/:id → ProjectDetailComponent (authGuard)
/workflows → WorkflowListComponent (authGuard, lazy loaded)
/workflows/:id → WorkflowMonitorComponent (authGuard)
/test-gen → StandaloneTestGenComponent (authGuard, lazy loaded)
/documents → DocumentLibraryComponent (authGuard, lazy loaded)
```

## ENVIRONMENT CONFIGURATION
```typescript
// environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000/api/v1',
  wsUrl: 'http://localhost:8000',
  appName: 'IQTOP',
  version: '1.0.0'
};
```

## PACKAGE DEPENDENCIES
```json
{
  "@angular/animations": "^18.0.0",
  "@angular/common": "^18.0.0",
  "@angular/core": "^18.0.0",
  "@angular/forms": "^18.0.0",
  "@angular/material": "^18.0.0",
  "@angular/platform-browser": "^18.0.0",
  "@angular/router": "^18.0.0",
  "@ngrx/effects": "^18.0.0",
  "@ngrx/store": "^18.0.0",
  "@ngrx/store-devtools": "^18.0.0",
  "primeng": "^17.18.0",
  "primeicons": "^7.0.0",
  "socket.io-client": "^4.7.0",
  "ngx-dropzone": "^3.1.0",
  "rxjs": "~7.8.0",
  "tslib": "^2.3.0",
  "zone.js": "~0.14.0"
}
```

## SPECIAL REQUIREMENTS

1. **TypeScript Strict Mode**: Enable strict type checking
2. **Standalone Components**: Use Angular standalone components (no NgModules)
3. **Path Aliases**: Configure @core, @shared, @features, @store, @environments
4. **Lazy Loading**: All feature modules should be lazy loaded
5. **Responsive Design**: Mobile-friendly layout (collapse sidebar on mobile)
6. **Error Handling**: Show user-friendly error messages
7. **Loading States**: Show spinners during API calls
8. **Form Validation**: All forms must have validation and error messages

## DEMO DATA
- Default login credentials: admin@iqtop.com / admin123
- On successful login, store JWT token and navigate to dashboard

## NOTES
- Focus on creating a professional, enterprise-grade UI
- Ensure all components are type-safe with TypeScript
- Use Material Design principles
- Implement proper error handling and loading states
- Add inline comments for complex logic
- Follow Angular style guide and best practices

Generate a complete, production-ready application with all these specifications.
