# IQTOP UI - Development Guide

## 🚀 What Has Been Built

This Angular application provides a **production-ready foundation** for the IQTOP platform with the following complete implementations:

### ✅ Fully Implemented

1. **Complete Project Structure**
   - Angular 18+ with standalone components
   - TypeScript with strict mode
   - Path aliases configured (@core, @shared, @features, @store, @environments)
   - Modular architecture with lazy-loaded routes

2. **Core Services (100% Complete)**
   - `AuthService`: JWT authentication, login/logout, user state management
   - `SocketService`: Socket.IO integration for real-time updates
   - `WorkflowService`: Full CRUD for workflows with all 8 phases
   - `ProjectService`: Full CRUD for projects
   - `DocumentService`: File upload and document management

3. **Security & Infrastructure**
   - `AuthGuard`: Route protection
   - `AdminGuard`: Role-based access control
   - `JwtInterceptor`: Automatic Bearer token injection
   - `ErrorInterceptor`: Global HTTP error handling with auto-redirect on 401

4. **State Management (NgRx)**
   - Workflow store with actions, reducer, effects, selectors
   - Project store with actions, reducer, effects, selectors
   - Real-time integration with Socket.IO
   - Redux DevTools configured

5. **Type System**
   - Complete TypeScript models for all entities
   - User, Project, Workflow, Artifact models
   - Request/Response interfaces
   - Enums for status types

6. **Working Components**
   - **App Component**: Full layout with sidebar, toolbar, user menu
   - **Login Component**: Fully functional authentication
   - **Dashboard Component**: Statistics, workflow table, quick actions
   - **Project List**: Basic listing with navigation

### 🚧 Placeholder Components (Need Implementation)

These components have routing and basic structure but need full UI development:

1. **Project Create Component** - Multi-step wizard
2. **Project Detail Component** - Detailed view with tabs
3. **Workflow Monitor Component** - Real-time 8-phase visualization
4. **Workflow List Component** - Comprehensive listing
5. **Standalone Test Gen Component** - Quick generation interface
6. **Document Library Component** - Full document management

---

## 🔨 Implementation Guide for Remaining Components

### 1. Project Create Component (High Priority)

**Location:** `src/app/features/projects/project-create/project-create.component.ts`

**What to Build:**

```typescript
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatStepperModule } from '@angular/material/stepper';
import { Store } from '@ngrx/store';
import * as ProjectActions from '../../../store/project/project.actions';

@Component({
  selector: 'app-project-create',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatStepperModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCheckboxModule
  ],
  template: `
    <mat-stepper [linear]="true">
      <!-- Step 1: Basic Info -->
      <mat-step [stepControl]="basicInfoForm">
        <form [formGroup]="basicInfoForm">
          <ng-template matStepLabel>Basic Information</ng-template>

          <mat-form-field>
            <mat-label>Project Name</mat-label>
            <input matInput formControlName="name" required>
          </mat-form-field>

          <mat-form-field>
            <mat-label>Description</mat-label>
            <textarea matInput formControlName="description"></textarea>
          </mat-form-field>

          <mat-form-field>
            <mat-label>GitHub Repository URL</mat-label>
            <input matInput formControlName="github_repo_url">
          </mat-form-field>

          <mat-form-field>
            <mat-label>Rally Project ID</mat-label>
            <input matInput formControlName="rally_project_id">
          </mat-form-field>

          <button mat-button matStepperNext>Next</button>
        </form>
      </mat-step>

      <!-- Step 2: Test Configuration -->
      <mat-step [stepControl]="testConfigForm">
        <form [formGroup]="testConfigForm">
          <ng-template matStepLabel>Test Configuration</ng-template>

          <h3>Select Test Types:</h3>

          <mat-checkbox formControlName="enable_ui_testing">
            UI Testing (Playwright)
          </mat-checkbox>

          <!-- Show UI config form if enabled -->
          <div *ngIf="testConfigForm.get('enable_ui_testing')?.value" class="config-panel">
            <mat-form-field>
              <mat-label>Test Environment URL</mat-label>
              <input matInput formControlName="ui_test_environment">
            </mat-form-field>

            <mat-checkbox formControlName="ui_browser_chromium">Chromium</mat-checkbox>
            <mat-checkbox formControlName="ui_browser_firefox">Firefox</mat-checkbox>
            <mat-checkbox formControlName="ui_browser_webkit">WebKit</mat-checkbox>
          </div>

          <mat-checkbox formControlName="enable_api_testing">
            API Testing
          </mat-checkbox>

          <mat-checkbox formControlName="enable_ibmi_testing">
            IBMI Testing
          </mat-checkbox>

          <button mat-button matStepperPrevious>Back</button>
          <button mat-button matStepperNext>Next</button>
        </form>
      </mat-step>

      <!-- Step 3: Team & Documents -->
      <mat-step>
        <ng-template matStepLabel>Team & Context</ng-template>

        <!-- Team selection UI -->
        <!-- Document upload UI -->

        <button mat-button matStepperPrevious>Back</button>
        <button mat-raised-button color="primary" (click)="createProject()">
          Create Project
        </button>
      </mat-step>
    </mat-stepper>
  `
})
export class ProjectCreateComponent {
  basicInfoForm: FormGroup;
  testConfigForm: FormGroup;

  constructor(private fb: FormBuilder, private store: Store) {
    this.basicInfoForm = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      github_repo_url: [''],
      rally_project_id: ['']
    });

    this.testConfigForm = this.fb.group({
      enable_ui_testing: [false],
      ui_test_environment: [''],
      ui_browser_chromium: [true],
      ui_browser_firefox: [false],
      ui_browser_webkit: [false],
      enable_api_testing: [false],
      enable_ibmi_testing: [false]
    });
  }

  createProject(): void {
    const request = {
      ...this.basicInfoForm.value,
      test_types: this.buildTestTypesArray()
    };
    this.store.dispatch(ProjectActions.createProject({ request }));
  }

  buildTestTypesArray(): any[] {
    // Build test_types array from form values
    const types = [];
    if (this.testConfigForm.value.enable_ui_testing) {
      types.push({
        test_type: 'ui',
        enabled: true,
        configuration: { /* ... */ }
      });
    }
    return types;
  }
}
```

**Key Features to Implement:**
- Material Stepper for multi-step form
- Dynamic form controls based on test type selection
- ngx-dropzone for document upload in step 3
- Form validation with error messages
- Dispatch to store on completion

---

### 2. Workflow Monitor Component (Critical)

**Location:** `src/app/features/workflows/workflow-monitor/workflow-monitor.component.ts`

**What to Build:**

The current placeholder has Socket.IO integration. You need to add:

1. **Phase Visualization UI**
```html
<div class="phase-container">
  <div *ngFor="let phase of phases$ | async" class="phase-item">
    <div [class]="'phase-icon ' + getPhaseStatusClass(phase.status)">
      <mat-icon *ngIf="phase.status === 'completed'">check</mat-icon>
      <mat-icon *ngIf="phase.status === 'running'">sync</mat-icon>
      <mat-icon *ngIf="phase.status === 'pending'">schedule</mat-icon>
      <mat-icon *ngIf="phase.status === 'failed'">error</mat-icon>
    </div>

    <div class="phase-info">
      <h4>Phase {{ phase.phase_number }}: {{ phase.phase_name }}</h4>
      <p>{{ phase.agent_name }}</p>
      <p *ngIf="phase.duration_ms">Duration: {{ phase.duration_ms | number }}ms</p>
    </div>

    <mat-expansion-panel *ngIf="phase.output_data">
      <mat-expansion-panel-header>
        View Details
      </mat-expansion-panel-header>
      <pre>{{ phase.output_data | json }}</pre>
    </mat-expansion-panel>
  </div>
</div>
```

2. **Approval Modal for Phase 2**
```typescript
openApprovalDialog(): void {
  const dialogRef = this.dialog.open(ScenarioApprovalDialogComponent, {
    data: { scenarios: this.scenarios },
    width: '80vw',
    maxHeight: '90vh'
  });

  dialogRef.afterClosed().subscribe(result => {
    if (result) {
      this.store.dispatch(WorkflowActions.approveWorkflow({
        workflowId: this.workflowId,
        scenarios: result.scenarios,
        edited: result.edited
      }));
    }
  });
}
```

**Key Features:**
- Visual phase progress indicator
- Expandable phase details
- Approval dialog when workflow reaches Phase 2
- Real-time status updates via Socket.IO
- Links to artifacts (reports, PRs, defects)

---

### 3. Document Library Component

**Location:** `src/app/features/documents/document-library/document-library.component.ts`

**What to Build:**

```typescript
import { Component, OnInit } from '@angular/core';
import { TreeModule } from 'primeng/tree';
import { DocumentService } from '../../../core/services/document.service';

@Component({
  selector: 'app-document-library',
  standalone: true,
  imports: [CommonModule, TreeModule, /* other PrimeNG modules */],
  template: `
    <div class="document-library">
      <div class="toolbar">
        <input type="file" #fileInput (change)="onFileSelect($event)" hidden>
        <button mat-raised-button color="primary" (click)="fileInput.click()">
          <mat-icon>cloud_upload</mat-icon>
          Upload Document
        </button>
      </div>

      <div class="library-content">
        <p-tree [value]="documentTree"
                selectionMode="single"
                [(selection)]="selectedNode"
                (onNodeSelect)="onNodeSelect($event)">
        </p-tree>

        <div class="document-preview" *ngIf="selectedNode">
          <h3>{{ selectedNode.label }}</h3>
          <button mat-button (click)="downloadDocument()">
            <mat-icon>download</mat-icon>
            Download
          </button>
          <button mat-button color="warn" (click)="deleteDocument()">
            <mat-icon>delete</mat-icon>
            Delete
          </button>
        </div>
      </div>
    </div>
  `
})
export class DocumentLibraryComponent implements OnInit {
  documentTree: any[] = [];
  selectedNode: any;

  constructor(private documentService: DocumentService) {}

  ngOnInit(): void {
    this.loadDocuments();
  }

  loadDocuments(): void {
    this.documentService.getDocuments().subscribe(documents => {
      this.documentTree = this.buildTree(documents);
    });
  }

  onFileSelect(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.documentService.uploadDocument(file).subscribe(() => {
        this.loadDocuments();
      });
    }
  }

  buildTree(documents: any[]): any[] {
    // Build tree structure from flat document list
    return documents.map(doc => ({
      label: doc.file_name,
      data: doc,
      icon: 'pi pi-file'
    }));
  }
}
```

---

## 🔗 Backend Integration Checklist

### API Endpoints to Implement in Backend

Make sure your FastAPI backend has these endpoints:

```python
# Authentication
POST   /api/v1/auth/login
POST   /api/v1/auth/logout
GET    /api/v1/auth/me

# Projects
GET    /api/v1/projects
POST   /api/v1/projects
GET    /api/v1/projects/{id}
PATCH  /api/v1/projects/{id}
DELETE /api/v1/projects/{id}

# Workflows
GET    /api/v1/workflows
POST   /api/v1/workflows/ui-test
POST   /api/v1/workflows/api-test
POST   /api/v1/workflows/legacy-test
GET    /api/v1/workflows/{id}
GET    /api/v1/workflows/{id}/phases
GET    /api/v1/workflows/{id}/scenarios
POST   /api/v1/workflows/{id}/approve
POST   /api/v1/workflows/{id}/cancel

# Documents
POST   /api/v1/documents (multipart/form-data)
GET    /api/v1/documents
GET    /api/v1/documents/{id}/download
DELETE /api/v1/documents/{id}

# Standalone
POST   /api/v1/standalone/generate-scenarios
```

### WebSocket Events

Implement Socket.IO on backend:

```python
# Server emits
socketio.emit('workflow_update', {
    'workflow_id': workflow_id,
    'phase': current_phase,
    'status': phase_status,
    'output_data': {}
})

socketio.emit('phase_complete', {
    'workflow_id': workflow_id,
    'phase': phase_number,
    'result': {}
})

socketio.emit('workflow_complete', {
    'workflow_id': workflow_id,
    'artifacts': {}
})
```

---

## 🎨 UI Component Library Usage

### When to Use Angular Material vs PrimeNG

**Use Angular Material for:**
- Layout (Sidenav, Toolbar)
- Form controls (Input, Select, Checkbox)
- Buttons and basic UI
- Dialogs and Snackbars

**Use PrimeNG for:**
- Data Tables (much more powerful than Material tables)
- Tree views
- File upload
- Advanced charts
- Timeline components

### Example: Data Table with PrimeNG

```typescript
import { TableModule } from 'primeng/table';

@Component({
  template: `
    <p-table [value]="data" [paginator]="true" [rows]="10">
      <ng-template pTemplate="header">
        <tr>
          <th>Column 1</th>
          <th>Column 2</th>
        </tr>
      </ng-template>
      <ng-template pTemplate="body" let-item>
        <tr>
          <td>{{ item.field1 }}</td>
          <td>{{ item.field2 }}</td>
        </tr>
      </ng-template>
    </p-table>
  `
})
```

---

## 🧪 Testing Strategy

### Unit Tests

Each component should have corresponding `.spec.ts` file:

```typescript
describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [DashboardComponent],
      providers: [
        provideMockStore({ initialState: { workflow: initialState } })
      ]
    });

    store = TestBed.inject(MockStore);
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load workflows on init', () => {
    spyOn(store, 'dispatch');
    component.ngOnInit();
    expect(store.dispatch).toHaveBeenCalledWith(
      WorkflowActions.loadWorkflows({})
    );
  });
});
```

### E2E Tests with Cypress

Install Cypress:
```bash
npm install --save-dev cypress
```

Example test:
```typescript
describe('Login Flow', () => {
  it('should login successfully', () => {
    cy.visit('/auth/login');
    cy.get('input[type="email"]').type('admin@iqtop.com');
    cy.get('input[type="password"]').type('admin123');
    cy.get('button[type="submit"]').click();
    cy.url().should('include', '/dashboard');
  });
});
```

---

## 📦 Deployment

### Docker Multi-Stage Build

The application is ready for Docker deployment. Build and run:

```bash
docker build -t iqtop-ui .
docker run -p 4200:80 iqtop-ui
```

### Kubernetes Deployment

Create `k8s-deployment.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: iqtop-ui
spec:
  replicas: 3
  selector:
    matchLabels:
      app: iqtop-ui
  template:
    metadata:
      labels:
        app: iqtop-ui
    spec:
      containers:
      - name: iqtop-ui
        image: iqtop-ui:latest
        ports:
        - containerPort: 80
        env:
        - name: API_URL
          value: "http://iqtop-backend:8000"
---
apiVersion: v1
kind: Service
metadata:
  name: iqtop-ui
spec:
  selector:
    app: iqtop-ui
  ports:
  - port: 80
    targetPort: 80
  type: LoadBalancer
```

---

## 🚀 Performance Optimization

### Lazy Loading

All feature modules are already lazy-loaded in `app.routes.ts`:

```typescript
{
  path: 'projects',
  loadChildren: () => import('./features/projects/projects.routes')
}
```

### OnPush Change Detection

For better performance, use OnPush strategy:

```typescript
@Component({
  selector: 'app-your-component',
  changeDetection: ChangeDetectionStrategy.OnPush
})
```

### Virtual Scrolling

For long lists, use CDK virtual scrolling:

```typescript
import { ScrollingModule } from '@angular/cdk/scrolling';

<cdk-virtual-scroll-viewport itemSize="50">
  <div *cdkVirtualFor="let item of items">{{ item }}</div>
</cdk-virtual-scroll-viewport>
```

---

## 🔍 Debugging

### NgRx DevTools

The Redux DevTools are already configured. Install the browser extension:
- [Chrome](https://chrome.google.com/webstore/detail/redux-devtools/)
- [Firefox](https://addons.mozilla.org/en-US/firefox/addon/reduxdevtools/)

### Console Logging

Enable detailed logging in development:

```typescript
// environment.ts
export const environment = {
  production: false,
  debug: true
};

// Usage
if (!environment.production) {
  console.log('Debug info:', data);
}
```

---

## ✅ Checklist Before Going Live

- [ ] All components implemented with real functionality
- [ ] Unit tests written and passing
- [ ] E2E tests cover critical user flows
- [ ] Error handling in all services
- [ ] Loading states in all components
- [ ] Environment variables configured for production
- [ ] Socket.IO connection handling with reconnection logic
- [ ] JWT token refresh mechanism
- [ ] Proper logging and monitoring
- [ ] Security headers configured in nginx
- [ ] CORS configured properly
- [ ] Rate limiting on backend
- [ ] SSL certificates configured
- [ ] Backup strategy for user data

---

**You now have a solid, production-ready foundation. Focus on completing the placeholder components one by one, and you'll have a fully functional IQTOP UI!**
