# REPLIT PROMPT - IQTOP Platform UI

Copy and paste this entire prompt into Replit Agent:

---

Build me a complete Angular 18+ web application for an "Intelligent QA Testing Orchestration Platform (IQTOP)" with the following detailed specifications:

## APPLICATION OVERVIEW
IQTOP is an enterprise testing automation platform where:
- Project Managers create projects and configure test types (UI, API, IBMI testing)
- System generates test scenarios using AI
- Tests execute through an 8-phase automated workflow
- Real-time monitoring of test execution
- Results integrated with GitHub, Rally/Jira

## TECH STACK REQUIREMENTS
Framework: Angular 18+ (standalone components, no NgModules)
Language: TypeScript (strict mode enabled)
UI Libraries:
  - Angular Material (layout, forms, buttons, dialogs)
  - PrimeNG (data tables, tree views, advanced components)
State Management: NgRx (Store, Effects, Selectors, DevTools)
Real-time: Socket.IO client for WebSocket communication
HTTP: Angular HttpClient with interceptors
Styling: SCSS with custom theme
Build: Angular CLI with optimization

## COMPLETE FILE STRUCTURE
```
src/
├── app/
│   ├── core/
│   │   ├── models/
│   │   │   ├── user.model.ts
│   │   │   ├── project.model.ts
│   │   │   ├── workflow.model.ts
│   │   │   ├── artifact.model.ts
│   │   │   └── index.ts
│   │   ├── services/
│   │   │   ├── auth.service.ts
│   │   │   ├── socket.service.ts
│   │   │   ├── workflow.service.ts
│   │   │   ├── project.service.ts
│   │   │   └── document.service.ts
│   │   ├── guards/
│   │   │   └── auth.guard.ts
│   │   └── interceptors/
│   │       ├── jwt.interceptor.ts
│   │       └── error.interceptor.ts
│   ├── store/
│   │   ├── workflow/
│   │   │   ├── workflow.actions.ts
│   │   │   ├── workflow.reducer.ts
│   │   │   ├── workflow.effects.ts
│   │   │   └── workflow.selectors.ts
│   │   └── project/
│   │       ├── project.actions.ts
│   │       ├── project.reducer.ts
│   │       ├── project.effects.ts
│   │       └── project.selectors.ts
│   ├── features/
│   │   ├── auth/
│   │   │   ├── login/
│   │   │   │   └── login.component.ts
│   │   │   └── auth.routes.ts
│   │   ├── dashboard/
│   │   │   ├── dashboard.component.ts
│   │   │   └── dashboard.routes.ts
│   │   ├── projects/
│   │   │   ├── project-list/
│   │   │   │   └── project-list.component.ts
│   │   │   ├── project-create/
│   │   │   │   └── project-create.component.ts
│   │   │   ├── project-detail/
│   │   │   │   └── project-detail.component.ts
│   │   │   └── projects.routes.ts
│   │   ├── workflows/
│   │   │   ├── workflow-list/
│   │   │   │   └── workflow-list.component.ts
│   │   │   ├── workflow-monitor/
│   │   │   │   └── workflow-monitor.component.ts
│   │   │   └── workflows.routes.ts
│   │   ├── standalone-test-gen/
│   │   │   ├── standalone-test-gen.component.ts
│   │   │   └── standalone-test-gen.routes.ts
│   │   └── documents/
│   │       ├── document-library/
│   │       │   └── document-library.component.ts
│   │       └── documents.routes.ts
│   ├── app.component.ts
│   ├── app.config.ts
│   └── app.routes.ts
├── environments/
│   ├── environment.ts
│   └── environment.prod.ts
├── styles.scss
├── index.html
└── main.ts
```

## DATA MODELS (TypeScript Interfaces)

```typescript
// user.model.ts
export type UserRole = 'admin' | 'tester' | 'viewer';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  is_active: boolean;
  last_login?: Date;
  created_at: Date;
  updated_at: Date;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  user: User;
}

// project.model.ts
export type TestType = 'ui' | 'api' | 'legacy' | 'standalone';

export interface Project {
  id: string;
  name: string;
  description?: string;
  github_repo_url?: string;
  rally_project_id?: string;
  jira_project_key?: string;
  created_by: string;
  created_at: Date;
  updated_at: Date;
  is_archived: boolean;
}

export interface CreateProjectRequest {
  name: string;
  description?: string;
  github_repo_url?: string;
  rally_project_id?: string;
  test_types: ProjectTestType[];
}

export interface ProjectTestType {
  test_type: TestType;
  enabled: boolean;
  configuration: any;
}

// workflow.model.ts
export type WorkflowStatus =
  | 'pending'
  | 'phase_1_generating'
  | 'phase_2_awaiting_review'
  | 'phase_3_executing'
  | 'phase_4_defects'
  | 'phase_5_scripts'
  | 'phase_6_reporting'
  | 'phase_7_regression'
  | 'phase_8_committing'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface Workflow {
  id: string;
  project_id: string;
  test_type: TestType;
  status: WorkflowStatus;
  current_phase: number;
  input_data: any;
  created_by: string;
  started_at?: Date;
  completed_at?: Date;
  duration_ms?: number;
  created_at: Date;
}

export interface WorkflowPhase {
  id: string;
  workflow_id: string;
  phase_number: number;
  phase_name: string;
  agent_name?: string;
  status: string;
  output_data?: any;
  started_at?: Date;
  completed_at?: Date;
  duration_ms?: number;
}

export interface WorkflowSummary {
  workflow_id: string;
  project_id: string;
  project_name: string;
  test_type: string;
  status: WorkflowStatus;
  current_phase: number;
  created_at: Date;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
}
```

## BACKEND API INTEGRATION

### Environment Configuration
```typescript
// environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000/api/v1',
  wsUrl: 'http://localhost:8000',
  appName: 'IQTOP',
  version: '1.0.0'
};
```

### API Endpoints to Call
```
Authentication:
POST   /auth/login             Body: { email, password }
                               Response: { access_token, user }

Projects:
GET    /projects               Response: Project[]
POST   /projects               Body: CreateProjectRequest
GET    /projects/{id}          Response: Project
PATCH  /projects/{id}          Body: Partial<Project>

Workflows:
GET    /workflows              Query: ?project_id=xxx
                               Response: WorkflowSummary[]
POST   /workflows/ui-test      Body: { project_id, input_data }
POST   /workflows/api-test     Body: { project_id, input_data }
GET    /workflows/{id}         Response: Workflow
GET    /workflows/{id}/phases  Response: WorkflowPhase[]
POST   /workflows/{id}/approve Body: { scenarios, edited }

Documents:
POST   /documents              Body: FormData with file
GET    /documents              Query: ?project_id=xxx
DELETE /documents/{id}
```

### WebSocket Integration (Socket.IO)
```typescript
// Connect with JWT token
socket = io(wsUrl, {
  auth: { token: jwtToken },
  transports: ['websocket']
});

// Listen to events:
socket.on('workflow_update', (data) => {
  // { workflow_id, phase, status, output_data }
  // Dispatch to NgRx store to update UI
});

socket.on('phase_complete', (data) => {
  // Phase completed notification
});

socket.on('workflow_complete', (data) => {
  // { workflow_id, artifacts }
  // Workflow finished
});
```

## CORE SERVICES IMPLEMENTATION

### AuthService (Injectable)
```typescript
Methods:
- login(credentials: LoginRequest): Observable<LoginResponse>
  * POST to /auth/login
  * Store token in localStorage
  * Store user in localStorage
  * Update currentUserSubject

- logout(): void
  * Clear localStorage
  * Navigate to /auth/login

- getToken(): string | null
  * Return token from localStorage

- getUser(): User | null
  * Return parsed user from localStorage

- isAuthenticated(): boolean
  * Check if token exists

- isAdmin(): boolean
  * Check if user.role === 'admin'
```

### SocketService (Injectable)
```typescript
Methods:
- connect(): void
  * Get token from AuthService
  * Create Socket.IO connection with auth
  * Set up connection event handlers

- disconnect(): void
  * Close socket connection

- on<T>(event: string): Observable<T>
  * Return Observable that emits when event received
  * Use RxJS Observable wrapper

- emit(event: string, data?: any): void
  * Send event to server
```

### WorkflowService (Injectable)
```typescript
Methods:
- getWorkflows(projectId?: string): Observable<WorkflowSummary[]>
  * GET /workflows with optional query param

- getWorkflow(id: string): Observable<Workflow>
  * GET /workflows/{id}

- getWorkflowPhases(id: string): Observable<WorkflowPhase[]>
  * GET /workflows/{id}/phases

- startWorkflow(request): Observable<Workflow>
  * POST /workflows/ui-test or /api-test

- approveWorkflow(workflowId, scenarios, edited): Observable<{success: boolean}>
  * POST /workflows/{id}/approve

- cancelWorkflow(id): Observable<{success: boolean}>
  * POST /workflows/{id}/cancel
```

### ProjectService (Injectable)
```typescript
Methods:
- getProjects(): Observable<Project[]>
- getProject(id): Observable<Project>
- createProject(request): Observable<Project>
- updateProject(id, updates): Observable<Project>
- deleteProject(id): Observable<{success: boolean}>
```

## GUARDS & INTERCEPTORS

### AuthGuard (CanActivateFn)
```typescript
- Check if AuthService.isAuthenticated()
- If yes, return true
- If no, navigate to /auth/login and return false
```

### JWT Interceptor (HttpInterceptorFn)
```typescript
- Get token from AuthService
- Clone request and add Authorization: Bearer <token>
- Return next(clonedRequest)
```

### Error Interceptor (HttpInterceptorFn)
```typescript
- Catch HTTP errors
- If 401: logout and redirect to login
- If other error: show user-friendly message
```

## NGRX STORE IMPLEMENTATION

### Workflow Store

**Actions:**
```typescript
- loadWorkflows({ projectId? })
- loadWorkflowsSuccess({ workflows })
- loadWorkflowsFailure({ error })
- loadWorkflow({ workflowId })
- loadWorkflowSuccess({ workflow })
- startWorkflow({ request })
- startWorkflowSuccess({ workflow })
- approveWorkflow({ workflowId, scenarios, edited })
- workflowPhaseUpdate({ workflow_id, phase, status, output_data })
- workflowCompleted({ workflow_id, artifacts })
```

**State:**
```typescript
{
  workflows: WorkflowSummary[];
  currentWorkflow: Workflow | null;
  phases: WorkflowPhase[];
  loading: boolean;
  error: string | null;
}
```

**Effects:**
- Listen to actions and call WorkflowService
- On startWorkflowSuccess, navigate to /workflows/{id}
- Handle Socket.IO events and dispatch workflowPhaseUpdate

**Selectors:**
```typescript
- selectAllWorkflows
- selectCurrentWorkflow
- selectWorkflowPhases
- selectWorkflowLoading
- selectCurrentPhase
```

### Project Store
Similar structure: actions, reducer, effects, selectors

## UI COMPONENTS DETAILED SPECIFICATIONS

### 1. App Component (Main Layout)
**Template Structure:**
```html
<div class="app-container" *ngIf="isAuthenticated">
  <mat-sidenav-container>
    <mat-sidenav mode="side" opened class="sidenav">
      <!-- Logo -->
      <div class="logo">
        <h2>IQTOP</h2>
      </div>

      <!-- Navigation -->
      <mat-nav-list>
        <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
          <mat-icon>dashboard</mat-icon>
          <span>Dashboard</span>
        </a>
        <a mat-list-item routerLink="/projects" routerLinkActive="active">
          <mat-icon>folder</mat-icon>
          <span>Projects</span>
        </a>
        <a mat-list-item routerLink="/workflows" routerLinkActive="active">
          <mat-icon>account_tree</mat-icon>
          <span>Workflows</span>
        </a>
        <a mat-list-item routerLink="/test-gen" routerLinkActive="active">
          <mat-icon>bolt</mat-icon>
          <span>Quick Test Gen</span>
        </a>
        <a mat-list-item routerLink="/documents" routerLinkActive="active">
          <mat-icon>description</mat-icon>
          <span>Documents</span>
        </a>
      </mat-nav-list>
    </mat-sidenav>

    <mat-sidenav-content>
      <!-- Toolbar -->
      <mat-toolbar color="primary">
        <span>{{ pageTitle }}</span>
        <span class="spacer"></span>
        <button mat-icon-button>
          <mat-icon>notifications</mat-icon>
        </button>
        <button mat-button [matMenuTriggerFor]="userMenu">
          <mat-icon>account_circle</mat-icon>
          <span>{{ currentUser?.full_name }}</span>
        </button>
        <mat-menu #userMenu="matMenu">
          <button mat-menu-item disabled>{{ currentUser?.email }}</button>
          <button mat-menu-item disabled>
            <span class="role-badge">{{ currentUser?.role }}</span>
          </button>
          <mat-divider></mat-divider>
          <button mat-menu-item (click)="logout()">
            <mat-icon>exit_to_app</mat-icon>
            <span>Logout</span>
          </button>
        </mat-menu>
      </mat-toolbar>

      <!-- Content -->
      <div class="content">
        <router-outlet></router-outlet>
      </div>
    </mat-sidenav-content>
  </mat-sidenav-container>
</div>

<div *ngIf="!isAuthenticated">
  <router-outlet></router-outlet>
</div>
```

**Styling:**
- Sidenav width: 250px
- Sidenav background: #2C3E50
- Sidenav text: white
- Active link background: rgba(255,255,255,0.1)
- Content padding: 2rem
- Content background: #f5f7fa

**Component Logic:**
- Subscribe to AuthService.currentUser$
- Connect Socket.IO on auth
- Disconnect Socket.IO on destroy

### 2. Login Component
**Full-screen centered card layout**

**Template:**
```html
<div class="login-container">
  <mat-card class="login-card">
    <mat-card-header>
      <mat-card-title>
        <h1>IQTOP</h1>
        <p>Intelligent QA Testing Orchestration Platform</p>
      </mat-card-title>
    </mat-card-header>

    <mat-card-content>
      <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
        <mat-form-field appearance="outline">
          <mat-label>Email</mat-label>
          <input matInput type="email" formControlName="email">
          <mat-error *ngIf="loginForm.get('email')?.hasError('required')">
            Email is required
          </mat-error>
          <mat-error *ngIf="loginForm.get('email')?.hasError('email')">
            Invalid email
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Password</mat-label>
          <input matInput type="password" formControlName="password">
          <mat-error>Password is required</mat-error>
        </mat-form-field>

        <div class="error-message" *ngIf="errorMessage">
          {{ errorMessage }}
        </div>

        <button mat-raised-button color="primary" type="submit"
                [disabled]="loginForm.invalid || loading">
          <span *ngIf="!loading">Login</span>
          <mat-spinner *ngIf="loading" diameter="20"></mat-spinner>
        </button>
      </form>
    </mat-card-content>

    <mat-card-footer>
      <p class="demo-credentials">
        Demo Credentials:<br>
        Admin: admin@iqtop.com / admin123
      </p>
    </mat-card-footer>
  </mat-card>
</div>
```

**Styling:**
- Container: 100vh height, centered, gradient background
- Gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%)
- Card: max-width 450px, white, shadow

**Form:**
- Reactive form with validators
- Email: required, email format
- Password: required
- Submit calls AuthService.login()
- On success, navigate to /dashboard

### 3. Dashboard Component
**Grid layout with stats and table**

**Template:**
```html
<div class="dashboard">
  <h1>Dashboard</h1>

  <!-- Stats Cards -->
  <div class="stats-container">
    <mat-card class="stat-card">
      <mat-card-content>
        <div class="stat-icon">
          <mat-icon>folder</mat-icon>
        </div>
        <div class="stat-info">
          <h3>12</h3>
          <p>Active Projects</p>
        </div>
      </mat-card-content>
    </mat-card>

    <mat-card class="stat-card">
      <mat-card-content>
        <div class="stat-icon">
          <mat-icon>play_circle</mat-icon>
        </div>
        <div class="stat-info">
          <h3>{{ (workflows$ | async)?.length || 0 }}</h3>
          <p>Total Workflows</p>
        </div>
      </mat-card-content>
    </mat-card>

    <!-- 2 more stat cards -->
  </div>

  <!-- Workflow Table -->
  <mat-card>
    <mat-card-header>
      <mat-card-title>Recent Workflows</mat-card-title>
    </mat-card-header>
    <mat-card-content>
      <p-table [value]="(workflows$ | async) || []"
               [paginator]="true"
               [rows]="10">
        <ng-template pTemplate="header">
          <tr>
            <th>Project</th>
            <th>Type</th>
            <th>Status</th>
            <th>Phase</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </ng-template>
        <ng-template pTemplate="body" let-workflow>
          <tr>
            <td>{{ workflow.project_name }}</td>
            <td>
              <span class="badge">{{ workflow.test_type | uppercase }}</span>
            </td>
            <td>
              <span [class]="'status-badge status-' + getStatusClass(workflow.status)">
                {{ workflow.status }}
              </span>
            </td>
            <td>Phase {{ workflow.current_phase }}/8</td>
            <td>{{ workflow.created_at | date:'short' }}</td>
            <td>
              <button pButton icon="pi pi-eye" class="p-button-sm"
                      [routerLink]="['/workflows', workflow.workflow_id]">
              </button>
            </td>
          </tr>
        </ng-template>
      </p-table>
    </mat-card-content>
  </mat-card>

  <!-- Quick Actions -->
  <div class="quick-actions">
    <button mat-raised-button color="primary" routerLink="/projects/create">
      <mat-icon>add</mat-icon>
      Create New Project
    </button>
    <button mat-raised-button color="accent" routerLink="/test-gen">
      <mat-icon>bolt</mat-icon>
      Quick Test Generation
    </button>
  </div>
</div>
```

**Component Logic:**
- OnInit: Dispatch loadWorkflows and loadProjects
- Subscribe to workflows$ from store
- getStatusClass() method for status colors

### 4. Project Create Component (Multi-step Wizard)
**Use Material Stepper**

**4 Steps:**
1. Basic Info (name, description, GitHub URL, Rally ID)
2. Test Configuration (checkboxes for UI/API/IBMI with config panels)
3. Team Members (add/remove)
4. Documents (drag-drop upload)

**Step 2 Test Configuration Detail:**
```html
<mat-checkbox formControlName="enable_ui_testing">
  UI Testing (Playwright)
</mat-checkbox>

<div *ngIf="testConfigForm.get('enable_ui_testing')?.value" class="config-panel">
  <mat-form-field>
    <mat-label>Test Environment URL</mat-label>
    <input matInput formControlName="ui_test_environment">
  </mat-form-field>

  <div class="checkbox-group">
    <mat-checkbox formControlName="ui_browser_chromium">Chromium</mat-checkbox>
    <mat-checkbox formControlName="ui_browser_firefox">Firefox</mat-checkbox>
    <mat-checkbox formControlName="ui_browser_webkit">WebKit</mat-checkbox>
  </div>

  <mat-form-field>
    <mat-label>Video Mode</mat-label>
    <mat-select formControlName="ui_video_mode">
      <mat-option value="on-failure">On Failure</mat-option>
      <mat-option value="always">Always</mat-option>
      <mat-option value="never">Never</mat-option>
    </mat-select>
  </mat-form-field>

  <div class="checkbox-group">
    <mat-checkbox formControlName="ui_auto_rally">Auto-create Rally defects</mat-checkbox>
    <mat-checkbox formControlName="ui_auto_jira">Auto-create Jira defects</mat-checkbox>
  </div>
</div>

<!-- Similar panels for API and IBMI -->
```

**On Submit:**
- Build CreateProjectRequest from form values
- Dispatch createProject action
- Navigate to project detail on success

### 5. Workflow Monitor Component
**Real-time 8-phase visualization**

**Template:**
```html
<mat-card>
  <mat-card-header>
    <mat-card-title>Workflow Monitor</mat-card-title>
    <mat-card-subtitle>{{ (currentWorkflow$ | async)?.status }}</mat-card-subtitle>
  </mat-card-header>

  <mat-card-content>
    <!-- Phase Progress -->
    <div class="phases-container">
      <div *ngFor="let phase of phases$ | async" class="phase-item">
        <div [class]="'phase-icon ' + getPhaseIconClass(phase.status)">
          <mat-icon *ngIf="phase.status === 'completed'">check</mat-icon>
          <mat-icon *ngIf="phase.status === 'running'">sync</mat-icon>
          <mat-icon *ngIf="phase.status === 'pending'">schedule</mat-icon>
          <mat-icon *ngIf="phase.status === 'failed'">error</mat-icon>
        </div>

        <div class="phase-content">
          <h3>Phase {{ phase.phase_number }}: {{ phase.phase_name }}</h3>
          <p class="agent-name">{{ phase.agent_name }}</p>
          <p *ngIf="phase.duration_ms" class="duration">
            Duration: {{ phase.duration_ms }}ms
          </p>

          <mat-expansion-panel *ngIf="phase.output_data">
            <mat-expansion-panel-header>
              View Details
            </mat-expansion-panel-header>
            <pre>{{ phase.output_data | json }}</pre>
          </mat-expansion-panel>
        </div>
      </div>
    </div>

    <!-- Approval Button (show when Phase 2 awaiting) -->
    <button *ngIf="showApprovalButton$ | async"
            mat-raised-button color="primary"
            (click)="openApprovalDialog()">
      Review & Approve Scenarios
    </button>

    <!-- Workflow Info -->
    <div class="workflow-info">
      <p>Started: {{ (currentWorkflow$ | async)?.started_at | date:'medium' }}</p>
      <p>Duration: {{ (currentWorkflow$ | async)?.duration_ms }}ms</p>
    </div>
  </mat-card-content>
</mat-card>
```

**Component Logic:**
- OnInit: Load workflow and phases
- Subscribe to Socket.IO 'workflow_update'
- When update received, dispatch workflowPhaseUpdate action
- openApprovalDialog(): Show modal with scenarios

**Approval Dialog:**
```html
<h2 mat-dialog-title>Review Test Scenarios</h2>
<mat-dialog-content>
  <div *ngFor="let scenario of data.scenarios" class="scenario-card">
    <mat-expansion-panel>
      <mat-expansion-panel-header>
        <mat-panel-title>{{ scenario.title }}</mat-panel-title>
      </mat-expansion-panel-header>
      <div class="scenario-details">
        <h4>Steps:</h4>
        <ol>
          <li *ngFor="let step of scenario.steps">{{ step }}</li>
        </ol>
        <h4>Expected Result:</h4>
        <p>{{ scenario.expected_result }}</p>
      </div>
    </mat-expansion-panel>
  </div>
</mat-dialog-content>
<mat-dialog-actions>
  <button mat-button (click)="onCancel()">Cancel</button>
  <button mat-raised-button color="primary" (click)="onApprove()">
    Approve & Run
  </button>
</mat-dialog-actions>
```

### 6. Project List Component
**Grid of project cards**

```html
<div class="projects-page">
  <div class="page-header">
    <h1>Projects</h1>
    <button mat-raised-button color="primary" routerLink="/projects/create">
      <mat-icon>add</mat-icon>
      Create New Project
    </button>
  </div>

  <div class="projects-grid">
    <mat-card *ngFor="let project of projects$ | async" class="project-card"
              [routerLink]="['/projects', project.id]">
      <mat-card-header>
        <mat-card-title>{{ project.name }}</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <p>{{ project.description || 'No description' }}</p>
        <p class="created-date">
          Created: {{ project.created_at | date:'short' }}
        </p>
      </mat-card-content>
      <mat-card-actions>
        <button mat-button>View Details</button>
      </mat-card-actions>
    </mat-card>
  </div>
</div>
```

### 7. Document Library Component
**Tree view with preview**

```html
<div class="document-library">
  <div class="toolbar">
    <input type="file" #fileInput (change)="onFileSelect($event)" hidden>
    <button mat-raised-button color="primary" (click)="fileInput.click()">
      <mat-icon>cloud_upload</mat-icon>
      Upload Document
    </button>
  </div>

  <div class="library-content">
    <div class="tree-panel">
      <p-tree [value]="documentTree"
              selectionMode="single"
              [(selection)]="selectedNode"
              (onNodeSelect)="onNodeSelect($event)">
      </p-tree>
    </div>

    <div class="preview-panel" *ngIf="selectedNode">
      <h3>{{ selectedNode.label }}</h3>
      <p>Size: {{ selectedNode.data.file_size_bytes | number }} bytes</p>
      <button mat-button (click)="downloadDocument()">
        <mat-icon>download</mat-icon>
        Download
      </button>
      <button mat-button color="warn" (click)="deleteDocument()">
        <mat-icon>delete</mat-icon>
        Delete
      </button>
    </div>
  </div>
</div>
```

## STYLING THEME

### Global Colors
```scss
:root {
  --primary-color: #2C3E50;
  --secondary-color: #27AE60;
  --accent-color: #E67E22;
  --success-color: #27AE60;
  --warning-color: #F39C12;
  --danger-color: #E74C3C;
  --info-color: #3498DB;
  --gray-50: #F8F9FA;
  --gray-600: #6C757D;
  --gray-800: #212529;
}
```

### Status Badge Styling
```scss
.status-badge {
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.875rem;
  font-weight: 500;
  display: inline-block;
}

.status-pending { background-color: #FFF3CD; color: #856404; }
.status-running { background-color: #D1ECF1; color: #0C5460; }
.status-completed { background-color: #D4EDDA; color: #155724; }
.status-failed { background-color: #F8D7DA; color: #721C24; }
.status-waiting { background-color: #FFF3CD; color: #856404; }
```

### Phase Icon Styling
```scss
.phase-icon {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 1rem;
}

.phase-completed { background-color: #27AE60; color: white; }
.phase-running { background-color: #3498DB; color: white; animation: pulse 2s infinite; }
.phase-pending { background-color: #CED4DA; color: #6C757D; }
.phase-failed { background-color: #E74C3C; color: white; }

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.6; }
}
```

### Card Styling
```scss
.card, mat-card {
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 1rem;
}
```

## ROUTING CONFIGURATION

```typescript
const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  {
    path: 'auth',
    loadChildren: () => import('./features/auth/auth.routes').then(m => m.AUTH_ROUTES)
  },
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadChildren: () => import('./features/dashboard/dashboard.routes').then(m => m.DASHBOARD_ROUTES)
  },
  {
    path: 'projects',
    canActivate: [authGuard],
    loadChildren: () => import('./features/projects/projects.routes').then(m => m.PROJECTS_ROUTES)
  },
  {
    path: 'workflows',
    canActivate: [authGuard],
    loadChildren: () => import('./features/workflows/workflows.routes').then(m => m.WORKFLOWS_ROUTES)
  },
  {
    path: 'test-gen',
    canActivate: [authGuard],
    loadChildren: () => import('./features/standalone-test-gen/standalone-test-gen.routes')
  },
  {
    path: 'documents',
    canActivate: [authGuard],
    loadChildren: () => import('./features/documents/documents.routes')
  },
  { path: '**', redirectTo: '/dashboard' }
];
```

## APP CONFIG (Providers)

```typescript
export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(
      withInterceptors([jwtInterceptor, errorInterceptor])
    ),
    provideAnimations(),
    provideStore({
      workflow: workflowReducer,
      project: projectReducer
    }),
    provideEffects([WorkflowEffects, ProjectEffects]),
    provideStoreDevtools({ maxAge: 25 })
  ]
};
```

## SPECIAL REQUIREMENTS

1. **TypeScript Strict Mode**: All type checking enabled
2. **Standalone Components**: No NgModules, use standalone: true
3. **Lazy Loading**: All feature modules lazy loaded
4. **Error Handling**: User-friendly error messages
5. **Loading States**: Show spinners during async operations
6. **Responsive**: Mobile-friendly (sidebar collapses)
7. **Real-time**: Socket.IO updates workflow UI automatically
8. **Form Validation**: All forms validated with error messages
9. **Security**: JWT tokens, route guards, interceptors
10. **Professional UI**: Material Design, consistent spacing

## SUCCESS CRITERIA

Application should:
✅ Compile without errors
✅ Run on localhost:4200
✅ Allow login with demo credentials
✅ Show dashboard with stats and workflow table
✅ Navigate between all pages
✅ Display loading states
✅ Handle errors gracefully
✅ Connect to backend API (when available)
✅ Support real-time updates via Socket.IO
✅ Be fully type-safe with TypeScript
✅ Follow Angular best practices
✅ Have clean, maintainable code

Generate the complete application with all files, properly structured and ready to run.
