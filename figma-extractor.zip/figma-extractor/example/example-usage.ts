import { FigmaExtractor } from '../src/index.js';

// Example 1: Basic extraction
async function basicExtraction() {
  const extractor = new FigmaExtractor({
    accessToken: 'your-figma-token',
    fileKey: 'your-file-key',
    outputDir: './output/basic',
  });

  const data = await extractor.extract();

  console.log('Extracted:', {
    pages: data.structure.pages.length,
    components: data.components.detected.length,
    colors: data.styles.colors.length,
  });
}

// Example 2: Full extraction with all features
async function fullExtraction() {
  const extractor = new FigmaExtractor({
    accessToken: process.env.FIGMA_ACCESS_TOKEN!,
    fileKey: process.env.FIGMA_FILE_KEY!,
    outputDir: './output/full',
    enableVisualDocs: true,
    enableComponentSearch: true,
    enableTokens: true,
    enableAssets: true,
    compareWithImplementation: 'http://localhost:4200',
    verbose: true,
  });

  const data = await extractor.extract();

  // Search for specific components
  const buttons = data.components.detected.filter(c => c.type === 'BUTTON');
  console.log(`Found ${buttons.length} buttons`);

  // Get color palette
  const primaryColors = data.tokens.colors.filter(c => c.category === 'primary');
  console.log('Primary colors:', primaryColors);
}

// Example 3: Component search
async function searchComponents() {
  const { ComponentInventory } = await import('../src/extractors/component-inventory.js');

  const inventory = new ComponentInventory('./output/inventory');

  // Assuming inventory was already built
  const searchResults = inventory.search('button primary', {
    limit: 5,
    type: 'BUTTON'
  });

  searchResults.forEach(result => {
    console.log(`Found: ${result.component.name} (${result.score} confidence)`);
  });
}

// Example 4: Working with extracted data
async function processExtractedData() {
  const fs = await import('fs/promises');

  // Load previously extracted data
  const dataPath = './output/raw/complete-extraction.json';
  const data = JSON.parse(await fs.readFile(dataPath, 'utf-8'));

  // Generate Angular component mapping
  const componentMappings = data.components.detected.map((comp: any) => {
    const bestMatch = comp.libraryMatches[0];

    return {
      figmaComponent: comp.name,
      figmaType: comp.type,
      angularComponent: bestMatch?.component || 'custom',
      library: bestMatch?.library || 'custom',
      importPath: bestMatch?.importPath || '',
      needsCustomImplementation: !bestMatch,
      properties: comp.properties,
    };
  });

  // Save mappings for code generation
  await fs.writeFile(
    './output/angular-mappings.json',
    JSON.stringify(componentMappings, null, 2)
  );
}

// Example 5: Design token usage
async function useDesignTokens() {
  const fs = await import('fs/promises');

  // Load tokens
  const tokensPath = './output/tokens/tokens.json';
  const tokens = JSON.parse(await fs.readFile(tokensPath, 'utf-8'));

  // Generate Angular theme
  let angularTheme = `
// Auto-generated Angular Material theme
@use '@angular/material' as mat;

// Color tokens
`;

  tokens.colors.forEach((color: any) => {
    if (color.category === 'primary') {
      angularTheme += `$primary-color: ${color.value};\n`;
    }
  });

  angularTheme += `
// Typography tokens
$typography-config: mat.define-typography-config(
`;

  tokens.typography.forEach((typo: any) => {
    angularTheme += `  $${typo.name}: mat.define-typography-level(
    $font-size: ${typo.fontSize},
    $font-weight: ${typo.fontWeight},
    $line-height: ${typo.lineHeight},
  ),\n`;
  });

  angularTheme += `);\n`;

  await fs.writeFile('./output/angular-theme.scss', angularTheme);
}

// Example 6: Visual comparison workflow
async function visualComparison() {
  const extractor = new FigmaExtractor({
    accessToken: process.env.FIGMA_ACCESS_TOKEN!,
    fileKey: process.env.FIGMA_FILE_KEY!,
    outputDir: './output/visual-comparison',
    enableVisualDocs: true,
    compareWithImplementation: 'http://localhost:4200',
  });

  const data = await extractor.extract();

  // Check visual comparison results
  const comparisons = (data as any).visualDocs?.comparisons || [];

  comparisons.forEach((comp: any) => {
    if (comp.similarity < 0.9) {
      console.warn(`Visual mismatch detected: ${comp.designPath}`);
      console.warn(`Similarity: ${(comp.similarity * 100).toFixed(1)}%`);
      console.warn(`Differences: ${comp.differences} pixels`);
    }
  });
}

// Example 7: Custom component detection rules
async function customComponentDetection() {
  const { ComponentDetector } = await import('../src/extractors/component-detector.js');
  const { FigmaApiClient } = await import('../src/api/figma-client.js');

  const client = new FigmaApiClient(
    process.env.FIGMA_ACCESS_TOKEN!,
    process.env.FIGMA_FILE_KEY!
  );

  const fileData = await client.getFile();

  // Create detector with custom rules
  const detector = new ComponentDetector();

  // Add custom detection logic here if needed

  const components = detector.detect(fileData.document);

  // Filter for enterprise-specific components
  const enterpriseComponents = components.filter(c =>
    c.libraryMatches.some(m => m.library.includes('@enterprise'))
  );

  console.log(`Found ${enterpriseComponents.length} enterprise components`);
}

// Example 8: Batch processing multiple files
async function batchProcessing() {
  const fileKeys = [
    'file-key-1',
    'file-key-2',
    'file-key-3',
  ];

  const results = [];

  for (const fileKey of fileKeys) {
    const extractor = new FigmaExtractor({
      accessToken: process.env.FIGMA_ACCESS_TOKEN!,
      fileKey,
      outputDir: `./output/batch/${fileKey}`,
    });

    try {
      const data = await extractor.extract();
      results.push({
        fileKey,
        success: true,
        components: data.components.detected.length,
      });
    } catch (error) {
      results.push({
        fileKey,
        success: false,
        error: (error as Error).message,
      });
    }
  }

  console.log('Batch processing results:', results);
}

// Run examples
if (import.meta.url === `file://${process.argv[1]}`) {
  const example = process.argv[2] || 'basic';

  console.log(`Running example: ${example}`);

  const examples: Record<string, () => Promise<void>> = {
    basic: basicExtraction,
    full: fullExtraction,
    search: searchComponents,
    process: processExtractedData,
    tokens: useDesignTokens,
    visual: visualComparison,
    custom: customComponentDetection,
    batch: batchProcessing,
  };

  const fn = examples[example];
  if (fn) {
    fn().catch(console.error);
  } else {
    console.log('Available examples:', Object.keys(examples).join(', '));
  }
}