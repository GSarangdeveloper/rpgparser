# Third-Party Libraries Used in Figma Extractor

## ❌ NOT Using These Libraries

This tool **does NOT use** the following Figma-specific libraries:
- ❌ `figma-api` - NOT used
- ❌ `figma-transformer` - NOT used
- ❌ `figma-flatten` - NOT used

Instead, this tool implements **custom, direct API integration** using `axios` to communicate with Figma's REST API.

## ✅ Custom Implementation

### Figma API Client (Custom Built)
- **Location**: `src/api/figma-client.ts`
- **Implementation**: Custom TypeScript class using axios
- **Why Custom**:
  - Full control over API calls
  - Type-safe with custom TypeScript interfaces
  - No dependency on third-party Figma wrappers
  - Direct REST API calls to `https://api.figma.com/v1`

## Image Generation & Processing Libraries

### 1. **Sharp** (^0.33.0)
- **Purpose**: High-performance image processing
- **Used For**:
  - Resizing and optimizing images
  - Converting image formats (PNG, JPG, WebP)
  - Generating thumbnails
  - Image metadata extraction
  - Creating image variants at different scales
- **Location**: `src/extractors/visual-documenter.ts`, `src/extractors/asset-extractor.ts`
- **License**: Apache-2.0
- **Why**: Native C++ bindings make it extremely fast for image operations

### 2. **Jimp** (^0.22.10)
- **Purpose**: JavaScript image manipulation
- **Used For**:
  - Image comparison operations
  - Pixel-level image manipulation
  - Creating annotated screenshots
- **Location**: `src/extractors/visual-documenter.ts`
- **License**: MIT
- **Why**: Pure JavaScript implementation, good for pixel manipulation

### 3. **Pixelmatch** (^5.3.0)
- **Purpose**: Pixel-level image comparison
- **Used For**:
  - Visual regression testing
  - Comparing Figma designs with live implementation
  - Calculating similarity scores between images
  - Generating diff images showing differences
- **Location**: `src/extractors/visual-documenter.ts`
- **License**: ISC
- **Why**: Fast and accurate pixel-by-pixel comparison algorithm

### 4. **Puppeteer** (^21.0.0)
- **Purpose**: Headless browser automation
- **Used For**:
  - Capturing screenshots of live web implementations
  - Visual comparison between Figma and implementation
  - Generating PDF documentation
  - Automated visual testing
- **Location**: `src/extractors/visual-documenter.ts`
- **License**: Apache-2.0
- **Why**: Official Google tool for browser automation, reliable for screenshots

## How Image Generation Works

### From Figma API:
1. **Figma REST API** - The tool uses Figma's official API endpoint:
   ```
   GET /images/{file_key}?ids={node_ids}&format={png|jpg|svg}&scale={1|2|3|4}
   ```
   - Returns URLs to rendered images of Figma nodes
   - Supports multiple formats and scales
   - No third-party rendering needed - Figma generates the images

2. **Image Download** - Uses `axios` to download images from Figma's CDN

3. **Post-Processing** - Uses Sharp to:
   - Optimize file sizes
   - Generate multiple resolutions
   - Create thumbnails
   - Convert formats

### Visual Documentation Process:
```
Figma Design
    ↓
Figma API (generates images)
    ↓
Download via axios
    ↓
Process with Sharp (resize, optimize)
    ↓
Optional: Compare with Puppeteer screenshots
    ↓
Optional: Annotate with Jimp
    ↓
Save to output directory
```

## Other Key Libraries

### 5. **SVGO** (^3.0.0)
- **Purpose**: SVG optimization
- **Used For**:
  - Optimizing SVG icons
  - Cleaning up SVG code
  - Reducing file sizes
- **Location**: `src/extractors/asset-extractor.ts`

### 6. **Axios** (^1.6.0) ⭐ Core Library
- **Purpose**: HTTP client for Figma API
- **Used For**:
  - **Direct REST API calls to Figma** (no wrapper library)
  - Making requests to `https://api.figma.com/v1`
  - Downloading images from URLs
  - Handling API authentication with X-Figma-Token header
- **Why Not Use figma-api library**:
  - Custom implementation provides better type safety
  - More control over request/response handling
  - Lighter weight - only includes what we need

### 7. **Style Dictionary** (^3.8.0)
- **Purpose**: Design token transformation
- **Used For**:
  - Converting design tokens to multiple formats
  - Generating CSS, SCSS, TypeScript token files
- **Location**: `src/extractors/token-extractor.ts`

### 8. **Fuse.js** (^7.0.0)
- **Purpose**: Fuzzy search
- **Used For**:
  - Searching component inventory
  - Finding components by name or properties
- **Location**: `src/extractors/component-inventory.ts`

## CLI & Utility Libraries

### 9. **Commander** (^11.0.0)
- **Purpose**: CLI framework
- **Used For**: Building command-line interface

### 10. **Inquirer** (^9.0.0)
- **Purpose**: Interactive CLI prompts
- **Used For**: Asking user for input (tokens, file keys)

### 11. **Ora** (^7.0.0)
- **Purpose**: Terminal spinners
- **Used For**: Showing progress during extraction

### 12. **Chalk** (^5.3.0)
- **Purpose**: Terminal colors
- **Used For**: Colorful CLI output

### 13. **Winston** (^3.11.0)
- **Purpose**: Logging
- **Used For**: Application logging

### 14. **Dotenv** (^16.0.0)
- **Purpose**: Environment variables
- **Used For**: Loading .env configuration

## Summary

**Yes, this tool uses several third-party libraries for image generation:**

1. **Primary Image Source**: Figma API (official, not third-party)
   - Figma's servers render the designs to images
   - No external rendering service needed

2. **Image Processing**: Sharp, Jimp
   - Process and optimize downloaded images
   - Create variants and thumbnails

3. **Visual Comparison**: Puppeteer, Pixelmatch
   - Compare designs with live implementations
   - Generate diff images

4. **Vector Optimization**: SVGO
   - Optimize SVG exports

**All libraries are open-source and well-maintained**, with permissive licenses (MIT, Apache-2.0, ISC).

## License Compliance

All dependencies use permissive open-source licenses:
- MIT License: Most libraries
- Apache-2.0: Sharp, Puppeteer
- ISC: Pixelmatch

No proprietary or restrictive licenses are used.

---

## 🔍 Detailed Comparison: Custom vs Third-Party Figma Libraries

### Why This Tool Doesn't Use `figma-api`, `figma-transformer`, or `figma-flatten`

| Aspect | This Tool (Custom) | figma-api/figma-transformer/figma-flatten |
|--------|-------------------|-------------------------------------------|
| **API Access** | Direct axios calls to Figma REST API | Wrapper around Figma API |
| **Type Safety** | Custom TypeScript interfaces | May have outdated types |
| **Bundle Size** | Smaller (only axios) | Larger (additional abstraction layers) |
| **Maintenance** | Full control over updates | Depends on third-party maintenance |
| **Customization** | Easy to modify API calls | Limited by library API |
| **Dependencies** | Minimal (just axios) | Additional dependencies |

### Custom Implementation Benefits

1. **Direct Control**:
   - Custom `FigmaApiClient` class in `src/api/figma-client.ts`
   - Direct REST API calls without abstraction overhead
   - Easy to add new Figma API endpoints as they're released

2. **Type Safety**:
   - Custom TypeScript interfaces in `types/figma.types.ts`
   - Strongly typed responses
   - Better IDE autocomplete and error checking

3. **Performance**:
   - No unnecessary abstraction layers
   - Minimal dependencies
   - Faster execution

4. **Flexibility**:
   - Custom hierarchy traversal in `StructuralExtractor`
   - Custom flattening logic in component detection
   - Tailored specifically for Angular development needs

### What This Tool Implements Internally

Instead of using third-party libraries, this tool has custom implementations for:

1. **API Access** (replaces `figma-api`):
   - `src/api/figma-client.ts` - Custom Figma API client
   - Methods: `getFile()`, `getImages()`, `getFileNodes()`, etc.

2. **Hierarchy Transformation** (replaces `figma-transformer`):
   - `src/extractors/structural-extractor.ts` - Custom hierarchy normalization
   - Builds node maps, traverses tree structure
   - Extracts pages, frames, and component hierarchy

3. **Structure Simplification** (replaces `figma-flatten`):
   - `src/extractors/component-detector.ts` - Flattens and analyzes components
   - Custom logic for detecting UI component patterns
   - Optimized for Angular Material and PrimeNG mapping

### Code Example: Custom API Client

```typescript
// src/api/figma-client.ts
export class FigmaApiClient {
  private client: AxiosInstance;

  constructor(accessToken: string, fileKey: string) {
    this.client = axios.create({
      baseURL: 'https://api.figma.com/v1',
      headers: { 'X-Figma-Token': accessToken }
    });
  }

  async getFile(): Promise<FigmaFile> {
    const response = await this.client.get(`/files/${this.fileKey}`);
    return response.data;
  }

  async getImages(nodeIds: string[], format: string, scale: number) {
    const response = await this.client.get(`/images/${this.fileKey}`, {
      params: { ids: nodeIds.join(','), format, scale }
    });
    return response.data.images;
  }
}
```

This approach gives us:
- ✅ Full control over API interactions
- ✅ Type-safe responses
- ✅ Easy to extend with new endpoints
- ✅ No dependency on third-party library updates
- ✅ Smaller bundle size

