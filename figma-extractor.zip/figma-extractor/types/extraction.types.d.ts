import { Paint, Effect } from './figma.types.js';
export interface ExtractedData {
    structure: StructuralData;
    styles: StyleData;
    assets: AssetData;
    components: ComponentData;
    layout: LayoutData;
    metadata: MetaData;
    interactions: InteractionData;
    tokens: DesignTokens;
}
export interface StructuralData {
    pages: PageData[];
    frames: FrameData[];
    hierarchy: HierarchyNode;
}
export interface PageData {
    id: string;
    name: string;
    frames: string[];
    order: number;
}
export interface FrameData {
    id: string;
    name: string;
    type: 'DESKTOP' | 'TABLET' | 'MOBILE' | 'CUSTOM';
    dimensions: {
        width: number;
        height: number;
    };
    background: Paint[];
    children: string[];
}
export interface HierarchyNode {
    id: string;
    name: string;
    type: string;
    children: HierarchyNode[];
    depth: number;
    path: string;
}
export interface StyleData {
    colors: ColorStyle[];
    typography: TypographyStyle[];
    effects: EffectStyle[];
    spacing: SpacingStyle[];
}
export interface ColorStyle {
    id: string;
    name: string;
    value: string;
    rgb: {
        r: number;
        g: number;
        b: number;
    };
    opacity: number;
    usage: string[];
    semantic?: 'primary' | 'secondary' | 'error' | 'warning' | 'success' | 'info';
}
export interface TypographyStyle {
    id: string;
    name: string;
    fontFamily: string;
    fontSize: number;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    textAlign: string;
    usage: string[];
}
export interface EffectStyle {
    id: string;
    name: string;
    type: string;
    properties: Effect;
    usage: string[];
}
export interface SpacingStyle {
    name: string;
    value: number;
    usage: string[];
}
export interface AssetData {
    images: ImageAsset[];
    icons: IconAsset[];
    fonts: FontAsset[];
}
export interface ImageAsset {
    id: string;
    name: string;
    url: string;
    dimensions: {
        width: number;
        height: number;
    };
    format: string;
    exportSettings: ExportVariant[];
}
export interface IconAsset {
    id: string;
    name: string;
    svgContent: string;
    size: {
        width: number;
        height: number;
    };
    category: string;
}
export interface FontAsset {
    family: string;
    weights: number[];
    styles: string[];
    source: string;
}
export interface ExportVariant {
    suffix: string;
    resolution: number;
    format: string;
    url: string;
}
export interface ComponentData {
    detected: DetectedComponent[];
    library: ComponentLibraryMapping[];
    patterns: ComponentPattern[];
    inventory: ComponentInventory;
}
export interface DetectedComponent {
    id: string;
    type: ComponentType;
    subType?: string;
    confidence: number;
    name: string;
    properties: ComponentProperties;
    location: ComponentLocation;
    states: ComponentState[];
    variants: ComponentVariant[];
    libraryMatches: LibraryMatch[];
}
export type ComponentType = 'BUTTON' | 'INPUT' | 'SELECT' | 'CHECKBOX' | 'RADIO' | 'TOGGLE' | 'SLIDER' | 'DATEPICKER' | 'TIMEPICKER' | 'TABLE' | 'LIST' | 'CARD' | 'ACCORDION' | 'TABS' | 'NAVIGATION' | 'SIDEBAR' | 'BREADCRUMB' | 'PAGINATION' | 'MODAL' | 'TOOLTIP' | 'ALERT' | 'BADGE' | 'CHIP' | 'PROGRESS' | 'SPINNER' | 'AVATAR' | 'MENU' | 'FORM';
export interface ComponentProperties {
    label?: string;
    placeholder?: string;
    value?: any;
    disabled?: boolean;
    required?: boolean;
    size?: 'small' | 'medium' | 'large';
    variant?: string;
    color?: string;
    icon?: string;
    customProps?: Record<string, any>;
}
export interface ComponentLocation {
    pageId: string;
    pageName: string;
    frameId: string;
    frameName: string;
    nodePath: string;
    coordinates: {
        x: number;
        y: number;
    };
}
export interface ComponentState {
    name: string;
    properties: Partial<ComponentProperties>;
    styles: any;
}
export interface ComponentVariant {
    name: string;
    properties: Record<string, any>;
}
export interface LibraryMatch {
    library: string;
    component: string;
    confidence: number;
    importPath: string;
    version?: string;
}
export interface ComponentLibraryMapping {
    detectedId: string;
    libraryName: string;
    componentName: string;
    importStatement: string;
    propertyMapping: Record<string, string>;
}
export interface ComponentPattern {
    name: string;
    type: string;
    components: string[];
    description: string;
}
export interface ComponentInventory {
    total: number;
    byType: Record<ComponentType, number>;
    byLibrary: Record<string, number>;
    unmapped: string[];
    statistics: ComponentStatistics;
}
export interface ComponentStatistics {
    totalDetected: number;
    uniqueTypes: number;
    libraryMatchRate: number;
    averageConfidence: number;
    mostUsed: {
        type: ComponentType;
        count: number;
    };
    complexComponents: number;
}
export interface LayoutData {
    grids: GridSystem[];
    breakpoints: Breakpoint[];
    constraints: LayoutConstraints[];
    autoLayout: AutoLayoutData[];
}
export interface GridSystem {
    type: 'ROWS' | 'COLUMNS' | 'GRID';
    count: number;
    gutter: number;
    margin: number;
    alignment: string;
}
export interface Breakpoint {
    name: string;
    width: number;
    scale: number;
}
export interface LayoutConstraints {
    nodeId: string;
    horizontal: string;
    vertical: string;
    aspectRatio?: number;
}
export interface AutoLayoutData {
    nodeId: string;
    direction: 'HORIZONTAL' | 'VERTICAL';
    spacing: number;
    padding: {
        top: number;
        right: number;
        bottom: number;
        left: number;
    };
    primaryAxisAlign: string;
    counterAxisAlign: string;
}
export interface MetaData {
    fileName: string;
    fileKey: string;
    lastModified: string;
    version: string;
    pages: number;
    nodes: number;
    components: number;
    extractedAt: string;
    extractionDuration: number;
}
export interface InteractionData {
    prototypes: PrototypeInteraction[];
    animations: AnimationData[];
    flows: UserFlow[];
}
export interface PrototypeInteraction {
    nodeId: string;
    trigger: string;
    action: string;
    destination?: string;
    animation?: AnimationData;
    delay?: number;
}
export interface AnimationData {
    type: string;
    duration: number;
    easing: string;
    direction?: string;
}
export interface UserFlow {
    name: string;
    steps: FlowStep[];
    startNodeId: string;
    endNodeId?: string;
}
export interface FlowStep {
    from: string;
    to: string;
    interaction: PrototypeInteraction;
}
export interface DesignTokens {
    colors: ColorToken[];
    typography: TypographyToken[];
    spacing: SpacingToken[];
    sizing: SizingToken[];
    elevation: ElevationToken[];
    motion: MotionToken[];
    breakpoints: BreakpointToken[];
}
export interface ColorToken {
    name: string;
    value: string;
    category: string;
    cssVariable: string;
}
export interface TypographyToken {
    name: string;
    fontFamily: string;
    fontSize: string;
    fontWeight: number;
    lineHeight: string;
    letterSpacing: string;
    cssClass: string;
}
export interface SpacingToken {
    name: string;
    value: string;
    pixels: number;
    cssVariable: string;
}
export interface SizingToken {
    name: string;
    value: string;
    category: string;
    cssVariable: string;
}
export interface ElevationToken {
    name: string;
    level: number;
    boxShadow: string;
    cssVariable: string;
}
export interface MotionToken {
    name: string;
    duration: string;
    easing: string;
    cssVariable: string;
}
export interface BreakpointToken {
    name: string;
    minWidth?: string;
    maxWidth?: string;
    cssVariable: string;
}
//# sourceMappingURL=extraction.types.d.ts.map