export {};
//# sourceMappingURL=figma.types.js.map