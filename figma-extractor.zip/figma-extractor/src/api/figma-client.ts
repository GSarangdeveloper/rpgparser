import axios, { AxiosInstance } from 'axios';
import { FigmaFile, FigmaNode } from '../../types/figma.types.js';

export class FigmaApiClient {
  protected client: AxiosInstance;
  protected fileKey: string;

  constructor(accessToken: string, fileKey: string) {
    this.fileKey = fileKey;
    this.client = axios.create({
      baseURL: 'https://api.figma.com/v1',
      headers: {
        'X-Figma-Token': accessToken,
      },
    });
  }

  async getFile(): Promise<FigmaFile> {
    const response = await this.client.get(`/files/${this.fileKey}`);
    return response.data;
  }

  async getFileNodes(nodeIds: string[]): Promise<any> {
    const ids = nodeIds.join(',');
    const response = await this.client.get(`/files/${this.fileKey}/nodes`, {
      params: { ids },
    });
    return response.data;
  }

  async getImages(nodeIds: string[], format: string = 'png', scale: number = 2): Promise<Record<string, string>> {
    const ids = nodeIds.join(',');
    const response = await this.client.get(`/images/${this.fileKey}`, {
      params: { ids, format, scale },
    });
    return response.data.images;
  }

  async getImageFills(): Promise<Record<string, string>> {
    const response = await this.client.get(`/files/${this.fileKey}/images`);
    return response.data.meta.images;
  }

  async getFileStyles(): Promise<any> {
    const response = await this.client.get(`/files/${this.fileKey}/styles`);
    return response.data;
  }

  async getFileComponents(): Promise<any> {
    const response = await this.client.get(`/files/${this.fileKey}/components`);
    return response.data;
  }

  async getFileVersions(): Promise<any> {
    const response = await this.client.get(`/files/${this.fileKey}/versions`);
    return response.data;
  }

  async getComments(): Promise<any> {
    const response = await this.client.get(`/files/${this.fileKey}/comments`);
    return response.data;
  }

  async getTeamProjects(teamId: string): Promise<any> {
    const response = await this.client.get(`/teams/${teamId}/projects`);
    return response.data;
  }

  async getProjectFiles(projectId: string): Promise<any> {
    const response = await this.client.get(`/projects/${projectId}/files`);
    return response.data;
  }

  async downloadImage(url: string): Promise<Buffer> {
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    return Buffer.from(response.data);
  }
}