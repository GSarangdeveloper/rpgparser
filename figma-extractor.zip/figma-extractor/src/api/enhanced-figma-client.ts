import axios, { AxiosInstance } from 'axios';
import { FigmaApiClient } from './figma-client.js';
import { FigmaFile, FigmaNode } from '../../types/figma.types.js';

// Extend parent class to access protected properties
declare module './figma-client.js' {
  interface FigmaApiClient {
    fileKey: string;
    accessToken: string;
  }
}

interface EnhancedFileData extends FigmaFile {
  enhanced: {
    processedAt: string;
    extractionVersion: string;
    nodeCount: number;
    componentCount: number;
    pageCount: number;
    hasPrototypes: boolean;
    hasComments: boolean;
    metadata: {
      lastModified: string;
      version: string;
      role: string;
      editorType: string;
    };
  };
}

interface NodeWithMetadata extends FigmaNode {
  metadata?: {
    depth: number;
    path: string[];
    parentType?: string;
    siblings: number;
    index: number;
    isComponent: boolean;
    isInstance: boolean;
    hasConstraints: boolean;
    hasEffects: boolean;
    hasExportSettings: boolean;
  };
}

export class EnhancedFigmaApiClient extends FigmaApiClient {
  private axiosInstance: AxiosInstance;
  private versionHistory: Map<string, any> = new Map();
  private nodeCache: Map<string, NodeWithMetadata> = new Map();
  private componentsCache: Map<string, any> = new Map();
  private stylesCache: Map<string, any> = new Map();

  constructor(accessToken: string, fileKey: string) {
    super(accessToken, fileKey);

    this.axiosInstance = axios.create({
      baseURL: 'https://api.figma.com/v1',
      headers: {
        'X-Figma-Token': accessToken
      },
      timeout: 30000
    });
  }

  /**
   * Get enhanced file data with additional metadata and processing
   */
  async getEnhancedFile(): Promise<EnhancedFileData> {
    const baseFile = await this.getFile();

    // Fetch additional data in parallel
    const [components, styles, version, comments] = await Promise.all([
      this.getFileComponents(),
      this.getFileStyles(),
      this.getFileVersion(),
      this.getFileComments()
    ]);

    // Process and enhance the file data
    const enhancedFile: EnhancedFileData = {
      ...baseFile,
      enhanced: {
        processedAt: new Date().toISOString(),
        extractionVersion: '2.0.0',
        nodeCount: this.countNodes(baseFile.document),
        componentCount: components.meta?.components?.length || 0,
        pageCount: baseFile.document.children?.length || 0,
        hasPrototypes: this.hasPrototypes(baseFile),
        hasComments: comments.length > 0,
        metadata: {
          lastModified: baseFile.lastModified || '',
          version: version.version || '',
          role: baseFile.role || '',
          editorType: baseFile.editorType || ''
        }
      }
    };

    // Cache components and styles
    this.cacheComponents(components);
    this.cacheStyles(styles);

    // Enhance nodes with metadata
    this.enhanceNodesRecursively(enhancedFile.document, [], 0);

    return enhancedFile;
  }

  /**
   * Get file components
   */
  async getFileComponents(): Promise<any> {
    try {
      const response = await this.axiosInstance.get(`/files/${this.fileKey}/components`);
      return response.data;
    } catch (error) {
      console.error('Error fetching components:', error);
      return { meta: { components: [] } };
    }
  }

  /**
   * Get file styles
   */
  async getFileStyles(): Promise<any> {
    try {
      const response = await this.axiosInstance.get(`/files/${this.fileKey}/styles`);
      return response.data;
    } catch (error) {
      console.error('Error fetching styles:', error);
      return { meta: { styles: [] } };
    }
  }

  /**
   * Get file version information
   */
  async getFileVersion(): Promise<any> {
    try {
      const response = await this.axiosInstance.get(`/files/${this.fileKey}/versions`);
      const versions = response.data.versions || [];
      if (versions.length > 0) {
        this.versionHistory.set(this.fileKey, versions);
        return versions[0]; // Return latest version
      }
      return { version: 'unknown' };
    } catch (error) {
      console.error('Error fetching versions:', error);
      return { version: 'unknown' };
    }
  }

  /**
   * Get file comments
   */
  async getFileComments(): Promise<any[]> {
    try {
      const response = await this.axiosInstance.get(`/files/${this.fileKey}/comments`);
      return response.data.comments || [];
    } catch (error) {
      console.error('Error fetching comments:', error);
      return [];
    }
  }

  /**
   * Get specific nodes with enhanced data
   */
  async getNodes(nodeIds: string[]): Promise<NodeWithMetadata[]> {
    try {
      const response = await this.axiosInstance.get(`/files/${this.fileKey}/nodes`, {
        params: {
          ids: nodeIds.join(',')
        }
      });

      const nodes = response.data.nodes || {};
      const enhancedNodes: NodeWithMetadata[] = [];

      for (const [nodeId, nodeData] of Object.entries(nodes)) {
        const enhancedNode = this.enhanceNode(nodeData as FigmaNode, [], 0);
        enhancedNodes.push(enhancedNode);
        this.nodeCache.set(nodeId, enhancedNode);
      }

      return enhancedNodes;
    } catch (error) {
      console.error('Error fetching nodes:', error);
      return [];
    }
  }

  /**
   * Get images from the file
   */
  async getImages(nodeIds: string[], format: 'jpg' | 'png' | 'svg' | 'pdf' = 'png', scale: number = 2): Promise<Map<string, string>> {
    try {
      const response = await this.axiosInstance.get(`/images/${this.fileKey}`, {
        params: {
          ids: nodeIds.join(','),
          format,
          scale
        }
      });

      const imageMap = new Map<string, string>();
      const images = response.data.images || {};

      for (const [nodeId, imageUrl] of Object.entries(images)) {
        imageMap.set(nodeId, imageUrl as string);
      }

      return imageMap;
    } catch (error) {
      console.error('Error fetching images:', error);
      return new Map();
    }
  }

  /**
   * Get component sets (variants)
   */
  async getComponentSets(): Promise<any[]> {
    try {
      const response = await this.axiosInstance.get(`/files/${this.fileKey}/component_sets`);
      return response.data.component_sets || [];
    } catch (error) {
      console.error('Error fetching component sets:', error);
      return [];
    }
  }

  /**
   * Count all nodes in the document
   */
  private countNodes(node: FigmaNode): number {
    let count = 1;
    if (node.children) {
      for (const child of node.children) {
        count += this.countNodes(child);
      }
    }
    return count;
  }

  /**
   * Check if file has prototypes
   */
  private hasPrototypes(file: FigmaFile): boolean {
    const checkNode = (node: FigmaNode): boolean => {
      if (node.transitionNodeID || node.transitionDuration) {
        return true;
      }
      if (node.children) {
        for (const child of node.children) {
          if (checkNode(child)) return true;
        }
      }
      return false;
    };

    return checkNode(file.document);
  }

  /**
   * Enhance nodes recursively with metadata
   */
  private enhanceNodesRecursively(node: NodeWithMetadata, path: string[], depth: number): void {
    // Add metadata to current node
    node.metadata = {
      depth,
      path: [...path, node.name],
      parentType: path.length > 0 ? undefined : 'root',
      siblings: node.parent?.children?.length || 0,
      index: node.parent?.children?.indexOf(node as any) || 0,
      isComponent: node.type === 'COMPONENT',
      isInstance: node.type === 'INSTANCE',
      hasConstraints: !!node.constraints,
      hasEffects: Array.isArray(node.effects) && node.effects.length > 0,
      hasExportSettings: Array.isArray(node.exportSettings) && node.exportSettings.length > 0
    };

    // Cache the enhanced node
    this.nodeCache.set(node.id, node);

    // Process children
    if (node.children) {
      node.children.forEach((child, index) => {
        const childNode = child as NodeWithMetadata;
        childNode.parent = node;
        this.enhanceNodesRecursively(childNode, [...path, node.name], depth + 1);
      });
    }
  }

  /**
   * Enhance a single node with metadata
   */
  private enhanceNode(node: FigmaNode, path: string[], depth: number): NodeWithMetadata {
    const enhanced = node as NodeWithMetadata;
    enhanced.metadata = {
      depth,
      path,
      siblings: 0,
      index: 0,
      isComponent: node.type === 'COMPONENT',
      isInstance: node.type === 'INSTANCE',
      hasConstraints: !!node.constraints,
      hasEffects: Array.isArray(node.effects) && node.effects.length > 0,
      hasExportSettings: Array.isArray(node.exportSettings) && node.exportSettings.length > 0
    };
    return enhanced;
  }

  /**
   * Cache components for quick lookup
   */
  private cacheComponents(components: any): void {
    if (components.meta?.components) {
      for (const component of components.meta.components) {
        this.componentsCache.set(component.key, component);
      }
    }
  }

  /**
   * Cache styles for quick lookup
   */
  private cacheStyles(styles: any): void {
    if (styles.meta?.styles) {
      for (const style of styles.meta.styles) {
        this.stylesCache.set(style.key, style);
      }
    }
  }

  /**
   * Get component by key from cache
   */
  getComponentByKey(key: string): any {
    return this.componentsCache.get(key);
  }

  /**
   * Get style by key from cache
   */
  getStyleByKey(key: string): any {
    return this.stylesCache.get(key);
  }

  /**
   * Get node by ID from cache
   */
  getNodeById(id: string): NodeWithMetadata | undefined {
    return this.nodeCache.get(id);
  }

  /**
   * Get all cached components
   */
  getAllComponents(): Map<string, any> {
    return this.componentsCache;
  }

  /**
   * Get all cached styles
   */
  getAllStyles(): Map<string, any> {
    return this.stylesCache;
  }

  /**
   * Clear all caches
   */
  clearCaches(): void {
    this.nodeCache.clear();
    this.componentsCache.clear();
    this.stylesCache.clear();
    this.versionHistory.clear();
  }
}