#!/usr/bin/env node

import { Command } from 'commander';
import inquirer from 'inquirer';
import chalk from 'chalk';
import * as dotenv from 'dotenv';
import { FigmaExtractor, ExtractionOptions } from './index.js';
import * as fs from 'fs/promises';
import * as path from 'path';

// Load environment variables
dotenv.config();

const program = new Command();

program
  .name('figma-extract')
  .description('Extract complete design data from Figma files for Angular development')
  .version('1.0.0');

program
  .command('extract')
  .description('Extract data from a Figma file')
  .option('-t, --token <token>', 'Figma access token (or use FIGMA_ACCESS_TOKEN env var)')
  .option('-f, --file <key>', 'Figma file key (or use FIGMA_FILE_KEY env var)')
  .option('-o, --output <dir>', 'Output directory', './output')
  .option('--no-assets', 'Skip asset extraction')
  .option('--no-tokens', 'Skip design token extraction')
  .option('--no-search', 'Skip component search index generation')
  .option('--visual-docs', 'Generate visual documentation (screenshots)')
  .option('--compare <url>', 'Compare with implementation URL')
  .option('-v, --verbose', 'Verbose output')
  .action(async (options) => {
    try {
      // Get or prompt for required values
      const config = await getConfiguration(options);

      // Create extractor
      const extractor = new FigmaExtractor(config);

      // Run extraction
      await extractor.extract();

      console.log(chalk.green('\n✨ Extraction completed successfully!'));
      console.log(chalk.gray(`Check the ${config.outputDir} directory for results.`));
    } catch (error) {
      console.error(chalk.red('Error:'), error);
      process.exit(1);
    }
  });

program
  .command('search <query>')
  .description('Search in previously extracted component inventory')
  .option('-i, --inventory <path>', 'Path to inventory file', './output/inventory/component-inventory.json')
  .option('-t, --type <type>', 'Filter by component type')
  .option('-l, --limit <number>', 'Limit results', '10')
  .action(async (query, options) => {
    try {
      const inventoryPath = path.resolve(options.inventory);
      const inventoryData = JSON.parse(await fs.readFile(inventoryPath, 'utf-8'));

      console.log(chalk.cyan(`\nSearching for: "${query}"\n`));

      // Simple search implementation
      const results = inventoryData.catalog.filter((item: any) => {
        const matchesQuery = item.searchableText.toLowerCase().includes(query.toLowerCase()) ||
                            item.name.toLowerCase().includes(query.toLowerCase());
        const matchesType = !options.type || item.type === options.type;
        return matchesQuery && matchesType;
      }).slice(0, parseInt(options.limit));

      if (results.length === 0) {
        console.log(chalk.yellow('No components found matching your query.'));
      } else {
        console.log(chalk.green(`Found ${results.length} components:\n`));

        results.forEach((component: any) => {
          console.log(chalk.bold(`📦 ${component.name}`));
          console.log(`   Type: ${component.type}`);
          if (component.libraryMappings.length > 0) {
            const mapping = component.libraryMappings[0];
            console.log(`   Library: ${mapping.library}`);
            console.log(`   Component: ${mapping.component}`);
            console.log(`   Import: ${mapping.importPath}`);
          } else {
            console.log(chalk.yellow(`   No library mapping found`));
          }
          console.log(`   Confidence: ${(component.confidence * 100).toFixed(1)}%`);
          console.log(`   Instances: ${component.instances}`);
          console.log();
        });
      }
    } catch (error) {
      console.error(chalk.red('Error:'), error);
      process.exit(1);
    }
  });

program
  .command('init')
  .description('Initialize a new Figma extraction project')
  .action(async () => {
    console.log(chalk.cyan('\n🚀 Initializing Figma Extractor\n'));

    const answers = await inquirer.prompt([
      {
        type: 'input',
        name: 'projectName',
        message: 'Project name:',
        default: 'figma-extraction',
      },
      {
        type: 'input',
        name: 'outputDir',
        message: 'Output directory:',
        default: './output',
      },
      {
        type: 'confirm',
        name: 'createEnv',
        message: 'Create .env file for configuration?',
        default: true,
      },
    ]);

    // Create project structure
    const dirs = [
      answers.outputDir,
      path.join(answers.outputDir, 'assets'),
      path.join(answers.outputDir, 'tokens'),
      path.join(answers.outputDir, 'inventory'),
      path.join(answers.outputDir, 'visual-docs'),
    ];

    for (const dir of dirs) {
      await fs.mkdir(dir, { recursive: true });
    }

    // Create config file
    const config = {
      name: answers.projectName,
      outputDir: answers.outputDir,
      extraction: {
        enableAssets: true,
        enableTokens: true,
        enableComponentSearch: true,
        enableVisualDocs: false,
      },
    };

    await fs.writeFile('figma-extractor.config.json', JSON.stringify(config, null, 2));

    // Create .env file if requested
    if (answers.createEnv) {
      const envContent = `# Figma API Configuration
FIGMA_ACCESS_TOKEN=your-token-here
FIGMA_FILE_KEY=your-file-key-here

# Output Configuration
OUTPUT_DIR=${answers.outputDir}
`;

      await fs.writeFile('.env', envContent);
      console.log(chalk.green('✅ Created .env file (remember to add your Figma credentials)'));
    }

    console.log(chalk.green('✅ Project initialized successfully!'));
    console.log(chalk.gray('\nNext steps:'));
    console.log(chalk.gray('1. Add your Figma access token to .env'));
    console.log(chalk.gray('2. Add your Figma file key to .env'));
    console.log(chalk.gray('3. Run: figma-extract extract'));
  });

program
  .command('analyze <output-dir>')
  .description('Analyze previously extracted data')
  .action(async (outputDir) => {
    try {
      const metadataPath = path.join(outputDir, 'raw', 'metadata.json');
      const componentsPath = path.join(outputDir, 'raw', 'components.json');
      const stylesPath = path.join(outputDir, 'raw', 'styles.json');

      const metadata = JSON.parse(await fs.readFile(metadataPath, 'utf-8'));
      const components = JSON.parse(await fs.readFile(componentsPath, 'utf-8'));
      const styles = JSON.parse(await fs.readFile(stylesPath, 'utf-8'));

      console.log(chalk.cyan('\n📊 Extraction Analysis\n'));

      console.log(chalk.bold('File Information:'));
      console.log(`  Name: ${metadata.fileName}`);
      console.log(`  Last Modified: ${metadata.lastModified}`);
      console.log(`  Extraction Date: ${metadata.extractedAt}`);
      console.log();

      console.log(chalk.bold('Statistics:'));
      console.log(`  Pages: ${metadata.pages}`);
      console.log(`  Total Nodes: ${Object.values(metadata.nodes).reduce((a: any, b: any) => a + b, 0)}`);
      console.log(`  Components: ${components.detected.length}`);
      console.log(`  Colors: ${styles.colors.length}`);
      console.log(`  Typography Styles: ${styles.typography.length}`);
      console.log();

      console.log(chalk.bold('Component Breakdown:'));
      const typeCount: Record<string, number> = {};
      components.detected.forEach((comp: any) => {
        typeCount[comp.type] = (typeCount[comp.type] || 0) + 1;
      });

      Object.entries(typeCount)
        .sort((a, b) => b[1] - a[1])
        .forEach(([type, count]) => {
          console.log(`  ${type}: ${count}`);
        });

      console.log();
      console.log(chalk.bold('Library Mappings:'));
      const libraryCount: Record<string, number> = {};
      components.detected.forEach((comp: any) => {
        if (comp.libraryMatches.length > 0) {
          const lib = comp.libraryMatches[0].library;
          libraryCount[lib] = (libraryCount[lib] || 0) + 1;
        }
      });

      if (Object.keys(libraryCount).length === 0) {
        console.log(chalk.yellow('  No library mappings found'));
      } else {
        Object.entries(libraryCount).forEach(([lib, count]) => {
          console.log(`  ${lib}: ${count}`);
        });
      }

    } catch (error) {
      console.error(chalk.red('Error analyzing extraction:'), error);
      process.exit(1);
    }
  });

async function getConfiguration(options: any): Promise<ExtractionOptions> {
  let accessToken = options.token || process.env.FIGMA_ACCESS_TOKEN;
  let fileKey = options.file || process.env.FIGMA_FILE_KEY;

  // Prompt for missing values
  if (!accessToken) {
    const answer = await inquirer.prompt({
      type: 'password',
      name: 'token',
      message: 'Enter your Figma access token:',
      validate: (input) => input.length > 0 || 'Token is required',
    });
    accessToken = answer.token;
  }

  if (!fileKey) {
    const answer = await inquirer.prompt({
      type: 'input',
      name: 'fileKey',
      message: 'Enter the Figma file key:',
      validate: (input) => input.length > 0 || 'File key is required',
    });
    fileKey = answer.fileKey;
  }

  return {
    accessToken,
    fileKey,
    outputDir: options.output,
    enableAssets: options.assets !== false,
    enableTokens: options.tokens !== false,
    enableComponentSearch: options.search !== false,
    enableVisualDocs: options.visualDocs || false,
    compareWithImplementation: options.compare,
    verbose: options.verbose || false,
  };
}

program.parse();