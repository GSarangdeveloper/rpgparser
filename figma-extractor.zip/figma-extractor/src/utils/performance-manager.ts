import NodeCache from 'node-cache';
import PQueue from 'p-queue';
import * as fs from 'fs/promises';
import * as path from 'path';
import Handlebars from 'handlebars';
import { DetectedComponent, DesignTokens } from '../../types/extraction.types.js';

interface QueueOptions {
  cache?: boolean;
  ttl?: number;
  priority?: number;
}

interface CacheStats {
  hits: number;
  misses: number;
  keys: number;
  hitRate: number;
}

interface QueueStats {
  size: number;
  pending: number;
  completed: number;
  failed: number;
}

interface PerformanceStats {
  cache: CacheStats;
  queue: QueueStats;
  executionTime: Map<string, number>;
  memoryUsage: NodeJS.MemoryUsage;
}

/**
 * Performance Manager for optimizing extraction operations
 */
export class PerformanceManager {
  private cache: NodeCache;
  private queue: PQueue;
  private stats: {
    cacheHits: number;
    cacheMisses: number;
    queueCompleted: number;
    queueFailed: number;
  };
  private executionTimes: Map<string, number[]>;

  constructor() {
    // Initialize cache with default TTL of 5 minutes
    this.cache = new NodeCache({
      stdTTL: 300,
      checkperiod: 60,
      useClones: false,
      deleteOnExpire: true,
      maxKeys: 1000
    });

    // Initialize queue with concurrency limit
    this.queue = new PQueue({
      concurrency: 5,
      interval: 1000,
      intervalCap: 10,
      timeout: 30000
    });

    this.stats = {
      cacheHits: 0,
      cacheMisses: 0,
      queueCompleted: 0,
      queueFailed: 0
    };

    this.executionTimes = new Map();

    // Set up cache event listeners
    this.setupCacheListeners();
  }

  /**
   * Add task to queue with optional caching
   */
  async addToQueue<T>(
    key: string,
    task: () => Promise<T>,
    options: QueueOptions = {}
  ): Promise<T> {
    // Check cache first if enabled
    if (options.cache) {
      const cached = this.getFromCache<T>(key);
      if (cached !== null) {
        this.stats.cacheHits++;
        return cached;
      }
      this.stats.cacheMisses++;
    }

    // Execute task through queue
    const startTime = Date.now();

    try {
      const result = await this.queue.add(
        async () => {
          const taskResult = await task();

          // Cache result if caching is enabled
          if (options.cache) {
            this.setCache(key, taskResult, options.ttl);
          }

          return taskResult;
        },
        { priority: options.priority || 0 }
      );

      // Track execution time
      const executionTime = Date.now() - startTime;
      this.trackExecutionTime(key, executionTime);

      this.stats.queueCompleted++;
      return result as T;
    } catch (error) {
      this.stats.queueFailed++;
      throw error;
    }
  }

  /**
   * Get value from cache
   */
  getFromCache<T>(key: string): T | null {
    const value = this.cache.get<T>(key);
    return value !== undefined ? value : null;
  }

  /**
   * Set value in cache
   */
  setCache<T>(key: string, value: T, ttl?: number): boolean {
    return ttl ? this.cache.set(key, value, ttl) : this.cache.set(key, value);
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.cache.flushAll();
  }

  /**
   * Clear specific cache keys by pattern
   */
  clearCacheByPattern(pattern: string): number {
    const keys = this.cache.keys();
    const regex = new RegExp(pattern);
    let cleared = 0;

    for (const key of keys) {
      if (regex.test(key)) {
        this.cache.del(key);
        cleared++;
      }
    }

    return cleared;
  }

  /**
   * Get queue status
   */
  getQueueStatus(): { size: number; pending: number; isPaused: boolean } {
    return {
      size: this.queue.size,
      pending: this.queue.pending,
      isPaused: this.queue.isPaused
    };
  }

  /**
   * Pause queue processing
   */
  pauseQueue(): void {
    this.queue.pause();
  }

  /**
   * Resume queue processing
   */
  resumeQueue(): void {
    this.queue.start();
  }

  /**
   * Clear queue
   */
  clearQueue(): void {
    this.queue.clear();
  }

  /**
   * Get performance statistics
   */
  getStats(): PerformanceStats {
    const cacheKeys = this.cache.keys();

    return {
      cache: {
        hits: this.stats.cacheHits,
        misses: this.stats.cacheMisses,
        keys: cacheKeys.length,
        hitRate: this.calculateHitRate()
      },
      queue: {
        size: this.queue.size,
        pending: this.queue.pending,
        completed: this.stats.queueCompleted,
        failed: this.stats.queueFailed
      },
      executionTime: this.getAverageExecutionTimes(),
      memoryUsage: process.memoryUsage()
    };
  }

  /**
   * Batch process items with concurrency control
   */
  async batchProcess<T, R>(
    items: T[],
    processor: (item: T) => Promise<R>,
    batchSize: number = 10
  ): Promise<R[]> {
    const results: R[] = [];
    const batches: T[][] = [];

    // Split items into batches
    for (let i = 0; i < items.length; i += batchSize) {
      batches.push(items.slice(i, i + batchSize));
    }

    // Process batches sequentially
    for (const batch of batches) {
      const batchResults = await Promise.all(
        batch.map(item =>
          this.addToQueue(
            `batch-${Date.now()}-${Math.random()}`,
            () => processor(item)
          )
        )
      );
      results.push(...batchResults);
    }

    return results;
  }

  /**
   * Track execution time for a key
   */
  private trackExecutionTime(key: string, time: number): void {
    const baseKey = key.split('-')[0]; // Group by base key
    if (!this.executionTimes.has(baseKey)) {
      this.executionTimes.set(baseKey, []);
    }
    this.executionTimes.get(baseKey)!.push(time);

    // Keep only last 100 times
    const times = this.executionTimes.get(baseKey)!;
    if (times.length > 100) {
      times.shift();
    }
  }

  /**
   * Get average execution times
   */
  private getAverageExecutionTimes(): Map<string, number> {
    const averages = new Map<string, number>();

    for (const [key, times] of this.executionTimes) {
      if (times.length > 0) {
        const sum = times.reduce((a, b) => a + b, 0);
        averages.set(key, sum / times.length);
      }
    }

    return averages;
  }

  /**
   * Calculate cache hit rate
   */
  private calculateHitRate(): number {
    const total = this.stats.cacheHits + this.stats.cacheMisses;
    return total > 0 ? this.stats.cacheHits / total : 0;
  }

  /**
   * Set up cache event listeners
   */
  private setupCacheListeners(): void {
    this.cache.on('expired', (key, value) => {
      console.log(`Cache expired: ${key}`);
    });

    this.cache.on('flush', () => {
      console.log('Cache flushed');
    });
  }

  /**
   * Optimize memory usage
   */
  async optimizeMemory(): Promise<void> {
    // Clear old cache entries
    const keys = this.cache.keys();
    const now = Date.now();

    for (const key of keys) {
      const ttl = this.cache.getTtl(key);
      if (ttl && ttl < now) {
        this.cache.del(key);
      }
    }

    // Force garbage collection if available
    if (global.gc) {
      global.gc();
    }
  }

  /**
   * Save stats to file
   */
  async saveStats(outputPath: string): Promise<void> {
    const stats = this.getStats();
    const statsJson = JSON.stringify(stats, (key, value) => {
      if (value instanceof Map) {
        return Object.fromEntries(value);
      }
      return value;
    }, 2);

    await fs.writeFile(outputPath, statsJson);
  }
}

/**
 * Template Manager for generating various output formats
 */
export class TemplateManager {
  private templates: Map<string, HandlebarsTemplateDelegate>;

  constructor() {
    this.templates = new Map();
    this.registerHelpers();
    this.loadDefaultTemplates();
  }

  /**
   * Register Handlebars helpers
   */
  private registerHelpers(): void {
    // Format number helper
    Handlebars.registerHelper('formatNumber', (num: number) => {
      return new Intl.NumberFormat().format(num);
    });

    // Percentage helper
    Handlebars.registerHelper('percentage', (value: number, decimals: number = 1) => {
      return `${(value * 100).toFixed(decimals)}%`;
    });

    // JSON stringify helper
    Handlebars.registerHelper('json', (context: any) => {
      return JSON.stringify(context, null, 2);
    });

    // Conditional helper
    Handlebars.registerHelper('ifCond', function(v1: any, operator: string, v2: any, options: any) {
      switch (operator) {
        case '==': return (v1 == v2) ? options.fn(this) : options.inverse(this);
        case '===': return (v1 === v2) ? options.fn(this) : options.inverse(this);
        case '!=': return (v1 != v2) ? options.fn(this) : options.inverse(this);
        case '!==': return (v1 !== v2) ? options.fn(this) : options.inverse(this);
        case '<': return (v1 < v2) ? options.fn(this) : options.inverse(this);
        case '<=': return (v1 <= v2) ? options.fn(this) : options.inverse(this);
        case '>': return (v1 > v2) ? options.fn(this) : options.inverse(this);
        case '>=': return (v1 >= v2) ? options.fn(this) : options.inverse(this);
        case '&&': return (v1 && v2) ? options.fn(this) : options.inverse(this);
        case '||': return (v1 || v2) ? options.fn(this) : options.inverse(this);
        default: return options.inverse(this);
      }
    });

    // Array join helper
    Handlebars.registerHelper('join', (array: any[], separator: string = ', ') => {
      return array.join(separator);
    });
  }

  /**
   * Load default templates
   */
  private loadDefaultTemplates(): void {
    // Angular component template
    this.templates.set('angular-component', Handlebars.compile(`
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: '{{selector}}',
  templateUrl: './{{fileName}}.html',
  styleUrls: ['./{{fileName}}.scss']
})
export class {{className}}Component {
  {{#each properties}}
  @Input() {{this.name}}: {{this.type}} = {{this.defaultValue}};
  {{/each}}

  {{#each events}}
  @Output() {{this.name}} = new EventEmitter<{{this.type}}>();
  {{/each}}

  {{#each methods}}
  {{this.name}}({{#each this.params}}{{this.name}}: {{this.type}}{{#unless @last}}, {{/unless}}{{/each}}): {{this.returnType}} {
    // Implementation based on Figma design
    {{#if this.implementation}}
    {{this.implementation}}
    {{else}}
    // TODO: Implement based on design requirements
    {{/if}}
  }
  {{/each}}
}
    `));

    // Component inventory HTML template
    this.templates.set('inventory-html', Handlebars.compile(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Component Inventory</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; padding: 20px; }
    .component-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
    .component-card { border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; }
    .component-type { font-size: 12px; color: #666; text-transform: uppercase; }
    .component-name { font-size: 18px; font-weight: 600; margin: 8px 0; }
    .confidence { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; }
    .confidence.high { background: #4caf50; color: white; }
    .confidence.medium { background: #ff9800; color: white; }
    .confidence.low { background: #f44336; color: white; }
    .properties { margin-top: 12px; font-size: 14px; }
    .property { padding: 4px 0; }
  </style>
</head>
<body>
  <h1>Component Inventory</h1>
  <p>Total components detected: {{components.length}}</p>

  <div class="component-grid">
    {{#each components}}
    <div class="component-card">
      <div class="component-type">{{this.type}}</div>
      <div class="component-name">{{this.name}}</div>
      <span class="confidence {{#if (gte this.confidence 0.8)}}high{{else if (gte this.confidence 0.6)}}medium{{else}}low{{/if}}">
        {{percentage this.confidence}}
      </span>

      <div class="properties">
        {{#each this.properties}}
        <div class="property">
          <strong>{{@key}}:</strong> {{this}}
        </div>
        {{/each}}
      </div>

      {{#if this.libraryMappings}}
      <div class="library-mappings">
        <strong>Library Matches:</strong>
        {{#each this.libraryMappings}}
        <span>{{this.library}} ({{percentage this.confidence}})</span>
        {{/each}}
      </div>
      {{/if}}
    </div>
    {{/each}}
  </div>
</body>
</html>
    `));

    // SCSS tokens template
    const scssTemplate = [
      '// Design Tokens - Generated from Figma',
      '// Generated on: {{generatedAt}}',
      '',
      '// Colors',
      '{{#each colors}}',
      '${{this.name}}: {{this.value}};',
      '{{/each}}',
      '',
      '// Typography',
      '{{#each typography}}',
      '$font-{{this.name}}: {{this.value}};',
      '{{/each}}',
      '',
      '// Spacing',
      '{{#each spacing}}',
      '$spacing-{{this.name}}: {{this.value}};',
      '{{/each}}',
      '',
      '// Shadows',
      '{{#each shadows}}',
      '$shadow-{{this.name}}: {{this.value}};',
      '{{/each}}',
      '',
      '// Breakpoints',
      '{{#each breakpoints}}',
      '$breakpoint-{{this.name}}: {{this.value}};',
      '{{/each}}',
      '',
      '// Component-specific tokens',
      '{{#each components}}',
      '// {{this.name}}',
      '{{#each this.tokens}}',
      '${{../name}}-{{this.name}}: {{this.value}};',
      '{{/each}}',
      '{{/each}}'
    ].join('\n');

    this.templates.set('tokens-scss', Handlebars.compile(scssTemplate));
  }

  /**
   * Generate Angular component code
   */
  generateAngularComponent(component: DetectedComponent): string {
    const template = this.templates.get('angular-component');
    if (!template) throw new Error('Angular component template not found');

    const context = {
      selector: this.toKebabCase(component.name),
      fileName: this.toKebabCase(component.name),
      className: this.toPascalCase(component.name),
      properties: this.extractComponentProperties(component),
      events: this.extractComponentEvents(component),
      methods: this.extractComponentMethods(component)
    };

    return template(context);
  }

  /**
   * Generate inventory HTML
   */
  generateInventoryHTML(components: DetectedComponent[]): string {
    const template = this.templates.get('inventory-html');
    if (!template) throw new Error('Inventory HTML template not found');

    // Register gte helper for this template
    Handlebars.registerHelper('gte', (a: number, b: number) => a >= b);

    return template({ components });
  }

  /**
   * Generate SCSS tokens
   */
  generateTokensSCSS(tokens: DesignTokens): string {
    const template = this.templates.get('tokens-scss');
    if (!template) throw new Error('Tokens SCSS template not found');

    const context = {
      generatedAt: new Date().toISOString(),
      colors: this.formatColorTokens(tokens.colors),
      typography: this.formatTypographyTokens(tokens.typography),
      spacing: this.formatSpacingTokens(tokens.spacing),
      shadows: this.formatShadowTokens(tokens.shadows),
      breakpoints: this.formatBreakpointTokens(tokens.breakpoints),
      components: [] // Component-specific tokens
    };

    return template(context);
  }

  /**
   * Add custom template
   */
  addTemplate(name: string, templateString: string): void {
    this.templates.set(name, Handlebars.compile(templateString));
  }

  /**
   * Generate from custom template
   */
  generate(templateName: string, context: any): string {
    const template = this.templates.get(templateName);
    if (!template) throw new Error(`Template ${templateName} not found`);
    return template(context);
  }

  // Helper methods for formatting

  private toKebabCase(str: string): string {
    return str
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .replace(/[\s_]+/g, '-')
      .toLowerCase();
  }

  private toPascalCase(str: string): string {
    return str
      .replace(/[-_\s]+(.)?/g, (_, c) => c ? c.toUpperCase() : '')
      .replace(/^(.)/, c => c.toUpperCase());
  }

  private extractComponentProperties(component: DetectedComponent): any[] {
    const properties: any[] = [];

    if (component.properties) {
      for (const [key, value] of Object.entries(component.properties)) {
        properties.push({
          name: this.toCamelCase(key),
          type: this.inferType(value),
          defaultValue: this.formatDefaultValue(value)
        });
      }
    }

    return properties;
  }

  private extractComponentEvents(component: DetectedComponent): any[] {
    // Extract events based on component type
    const events: any[] = [];

    switch (component.type) {
      case 'BUTTON':
        events.push({ name: 'click', type: 'void' });
        break;
      case 'INPUT':
        events.push({ name: 'change', type: 'string' });
        events.push({ name: 'blur', type: 'void' });
        break;
      case 'SELECT':
        events.push({ name: 'selectionChange', type: 'any' });
        break;
    }

    return events;
  }

  private extractComponentMethods(component: DetectedComponent): any[] {
    // Extract methods based on component type
    const methods: any[] = [];

    switch (component.type) {
      case 'TABLE':
        methods.push({
          name: 'sort',
          params: [{ name: 'column', type: 'string' }],
          returnType: 'void'
        });
        break;
      case 'FORM':
        methods.push({
          name: 'submit',
          params: [],
          returnType: 'void'
        });
        methods.push({
          name: 'reset',
          params: [],
          returnType: 'void'
        });
        break;
    }

    return methods;
  }

  private toCamelCase(str: string): string {
    return str
      .replace(/[-_\s]+(.)?/g, (_, c) => c ? c.toUpperCase() : '')
      .replace(/^(.)/, c => c.toLowerCase());
  }

  private inferType(value: any): string {
    if (typeof value === 'string') return 'string';
    if (typeof value === 'number') return 'number';
    if (typeof value === 'boolean') return 'boolean';
    if (Array.isArray(value)) return 'any[]';
    if (value === null || value === undefined) return 'any';
    return 'any';
  }

  private formatDefaultValue(value: any): string {
    if (typeof value === 'string') return `'${value}'`;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (Array.isArray(value)) return '[]';
    if (value === null) return 'null';
    if (value === undefined) return 'undefined';
    return '{}';
  }

  private formatColorTokens(colors: any[]): any[] {
    return colors.map(color => ({
      name: `color-${this.toKebabCase(color.name || 'unknown')}`,
      value: color.hex || color.value || '#000000'
    }));
  }

  private formatTypographyTokens(typography: any[]): any[] {
    return typography.map(typo => ({
      name: this.toKebabCase(typo.name || 'text'),
      value: typo.fontFamily || 'sans-serif'
    }));
  }

  private formatSpacingTokens(spacing: any[]): any[] {
    return spacing.map((space, index) => ({
      name: String(index),
      value: `${space}px`
    }));
  }

  private formatShadowTokens(shadows: any[]): any[] {
    return shadows.map(shadow => ({
      name: this.toKebabCase(shadow.name || 'default'),
      value: shadow.value || 'none'
    }));
  }

  private formatBreakpointTokens(breakpoints: any[]): any[] {
    return breakpoints.map(breakpoint => ({
      name: this.toKebabCase(breakpoint.name || 'medium'),
      value: `${breakpoint.value}px`
    }));
  }
}