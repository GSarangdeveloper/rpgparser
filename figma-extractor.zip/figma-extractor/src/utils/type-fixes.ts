// Type fixes and extensions for missing properties

import { FigmaNode, TextNode, RGB, RGBA } from '../../types/figma.types.js';

// Extend FigmaNode with additional properties
export interface ExtendedFigmaNode extends FigmaNode {
  parent?: FigmaNode;
  transitionNodeID?: string;
  transitionDuration?: number;
  componentId?: string;
  fillStyleId?: string;
  strokeStyleId?: string;
  textStyleId?: string;
  effectStyleId?: string;
  rotation?: number;
  description?: string;
  interactions?: any[];
  characters?: string;
}

// Extend TextNode with additional properties
export interface ExtendedTextNode extends TextNode {
  fontName?: { family: string; style: string };
  fontSize?: number;
  lineHeight?: any;
  letterSpacing?: any;
  textAlignHorizontal?: string;
  textAlignVertical?: string;
}

// Extended RGB with alpha
export interface RGBColor extends RGB {
  a?: number;
}

// Extended DetectedComponent with additional fields
export interface ExtendedDetectedComponent {
  mlFeatures?: any;
  patternMatches?: any[];
  enhancedDetection?: boolean;
  mlDetected?: boolean;
  clusterIndex?: number;
  patternDetected?: boolean;
  patternName?: string;
  detectionMethods?: string[];
}

// Color type that may have alpha
export type Color = RGB | RGBA | RGBColor;