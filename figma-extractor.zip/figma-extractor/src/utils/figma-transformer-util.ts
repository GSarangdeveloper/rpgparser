import { FigmaNode, TextNode, Color, Effect, Paint } from '../../types/figma.types.js';
import FigmaTransformer from 'figma-transformer';

interface TransformOptions {
  expandInstances?: boolean;
  resolveStyles?: boolean;
  optimizeProperties?: boolean;
  flattenGroups?: boolean;
  processVariants?: boolean;
  extractComponents?: boolean;
  normalizeColors?: boolean;
  includePrivateNodes?: boolean;
}

interface TransformedNode extends FigmaNode {
  transformed?: {
    originalType: string;
    isExpanded: boolean;
    isResolved: boolean;
    computedStyles?: any;
    variants?: any[];
    componentInfo?: any;
    normalizedColors?: any;
  };
}

/**
 * Utility for transforming and normalizing Figma data
 */
export class FigmaTransformerUtil {
  private transformer: typeof FigmaTransformer;
  private styleCache: Map<string, any> = new Map();
  private componentCache: Map<string, any> = new Map();

  constructor() {
    this.transformer = FigmaTransformer;
  }

  /**
   * Transform node tree with advanced options
   */
  static transformNodeTree(node: FigmaNode, options: TransformOptions = {}): TransformedNode {
    const instance = new FigmaTransformerUtil();
    return instance.transform(node, options);
  }

  /**
   * Main transformation method
   */
  transform(node: FigmaNode, options: TransformOptions = {}): TransformedNode {
    const transformed = this.deepClone(node) as TransformedNode;

    // Initialize transformation metadata
    transformed.transformed = {
      originalType: node.type,
      isExpanded: false,
      isResolved: false
    };

    // Apply transformations based on options
    if (options.expandInstances) {
      this.expandInstances(transformed);
    }

    if (options.resolveStyles) {
      this.resolveStyles(transformed);
    }

    if (options.optimizeProperties) {
      this.optimizeProperties(transformed);
    }

    if (options.flattenGroups) {
      this.flattenGroups(transformed);
    }

    if (options.processVariants) {
      this.processVariants(transformed);
    }

    if (options.extractComponents) {
      this.extractComponents(transformed);
    }

    if (options.normalizeColors) {
      this.normalizeColors(transformed);
    }

    // Process children recursively
    if (transformed.children) {
      transformed.children = transformed.children
        .filter(child => options.includePrivateNodes || !child.name.startsWith('_'))
        .map(child => this.transform(child, options));
    }

    return transformed;
  }

  /**
   * Expand component instances to their full structure
   */
  private expandInstances(node: TransformedNode): void {
    if (node.type === 'INSTANCE') {
      // Mark as expanded
      if (node.transformed) {
        node.transformed.isExpanded = true;
      }

      // If we have component data, expand it
      if (node.componentId) {
        const component = this.componentCache.get(node.componentId);
        if (component) {
          // Merge component properties with instance overrides
          this.mergeComponentData(node, component);
        }
      }
    }
  }

  /**
   * Resolve style references to actual values
   */
  private resolveStyles(node: TransformedNode): void {
    if (!node.transformed) return;

    node.transformed.isResolved = true;
    node.transformed.computedStyles = {};

    // Resolve fill styles
    if (node.fillStyleId && this.styleCache.has(node.fillStyleId)) {
      const style = this.styleCache.get(node.fillStyleId);
      node.transformed.computedStyles.fill = style;

      // Apply style to node if no local fills
      if (!node.fills || node.fills.length === 0) {
        node.fills = style.paints || [];
      }
    }

    // Resolve stroke styles
    if (node.strokeStyleId && this.styleCache.has(node.strokeStyleId)) {
      const style = this.styleCache.get(node.strokeStyleId);
      node.transformed.computedStyles.stroke = style;

      if (!node.strokes || node.strokes.length === 0) {
        node.strokes = style.paints || [];
      }
    }

    // Resolve text styles
    if (node.textStyleId && this.styleCache.has(node.textStyleId)) {
      const style = this.styleCache.get(node.textStyleId);
      node.transformed.computedStyles.text = style;

      // Apply text style properties
      if (node.type === 'TEXT') {
        this.applyTextStyle(node as TextNode, style);
      }
    }

    // Resolve effect styles
    if (node.effectStyleId && this.styleCache.has(node.effectStyleId)) {
      const style = this.styleCache.get(node.effectStyleId);
      node.transformed.computedStyles.effect = style;

      if (!node.effects || node.effects.length === 0) {
        node.effects = style.effects || [];
      }
    }
  }

  /**
   * Optimize properties for better performance
   */
  private optimizeProperties(node: TransformedNode): void {
    // Remove default/redundant properties
    if (node.visible === true) delete node.visible;
    if (node.locked === false) delete node.locked;
    if (node.opacity === 1) delete node.opacity;
    if (node.rotation === 0) delete node.rotation;

    // Optimize fills
    if (node.fills) {
      node.fills = this.optimizePaints(node.fills);
    }

    // Optimize strokes
    if (node.strokes) {
      node.strokes = this.optimizePaints(node.strokes);
    }

    // Optimize effects
    if (node.effects) {
      node.effects = this.optimizeEffects(node.effects);
    }

    // Round numeric values
    if (node.absoluteBoundingBox) {
      node.absoluteBoundingBox.x = Math.round(node.absoluteBoundingBox.x * 100) / 100;
      node.absoluteBoundingBox.y = Math.round(node.absoluteBoundingBox.y * 100) / 100;
      node.absoluteBoundingBox.width = Math.round(node.absoluteBoundingBox.width * 100) / 100;
      node.absoluteBoundingBox.height = Math.round(node.absoluteBoundingBox.height * 100) / 100;
    }
  }

  /**
   * Flatten group hierarchies
   */
  private flattenGroups(node: TransformedNode): void {
    if (node.type === 'GROUP' && node.children && node.children.length === 1) {
      // If group has only one child, promote the child
      const child = node.children[0];
      Object.assign(node, child);
    }
  }

  /**
   * Process component variants
   */
  private processVariants(node: TransformedNode): void {
    if (node.type === 'COMPONENT_SET' && node.children) {
      if (!node.transformed) return;

      node.transformed.variants = node.children.map(child => ({
        name: child.name,
        properties: this.extractVariantProperties(child)
      }));
    }
  }

  /**
   * Extract component information
   */
  private extractComponents(node: TransformedNode): void {
    if (node.type === 'COMPONENT' || node.type === 'INSTANCE') {
      if (!node.transformed) return;

      node.transformed.componentInfo = {
        id: node.id,
        name: node.name,
        description: node.description || '',
        isVariant: node.parent?.type === 'COMPONENT_SET',
        properties: this.extractComponentProperties(node)
      };

      // Cache component for future reference
      if (node.type === 'COMPONENT') {
        this.componentCache.set(node.id, node);
      }
    }
  }

  /**
   * Normalize colors to consistent format
   */
  private normalizeColors(node: TransformedNode): void {
    if (!node.transformed) return;

    node.transformed.normalizedColors = {
      fills: [],
      strokes: []
    };

    // Normalize fill colors
    if (node.fills) {
      node.transformed.normalizedColors.fills = node.fills.map(fill =>
        this.normalizePaint(fill)
      );
    }

    // Normalize stroke colors
    if (node.strokes) {
      node.transformed.normalizedColors.strokes = node.strokes.map(stroke =>
        this.normalizePaint(stroke)
      );
    }
  }

  /**
   * Helper: Deep clone an object
   */
  private deepClone<T>(obj: T): T {
    if (obj === null || typeof obj !== 'object') return obj;
    if (obj instanceof Date) return new Date(obj.getTime()) as any;
    if (obj instanceof Array) return obj.map(item => this.deepClone(item)) as any;

    const cloned = {} as T;
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        cloned[key] = this.deepClone(obj[key]);
      }
    }
    return cloned;
  }

  /**
   * Helper: Merge component data with instance
   */
  private mergeComponentData(instance: TransformedNode, component: any): void {
    // Preserve instance overrides
    const overrides = {
      fills: instance.fills,
      strokes: instance.strokes,
      effects: instance.effects,
      text: instance.type === 'TEXT' ? (instance as any).characters : undefined
    };

    // Copy component structure
    if (component.children && !instance.children) {
      instance.children = this.deepClone(component.children);
    }

    // Apply overrides back
    if (overrides.fills) instance.fills = overrides.fills;
    if (overrides.strokes) instance.strokes = overrides.strokes;
    if (overrides.effects) instance.effects = overrides.effects;
  }

  /**
   * Helper: Apply text style to node
   */
  private applyTextStyle(node: TextNode, style: any): void {
    if (style.fontFamily) node.fontName = { family: style.fontFamily, style: style.fontStyle || 'Regular' };
    if (style.fontSize) node.fontSize = style.fontSize;
    if (style.lineHeight) node.lineHeight = style.lineHeight;
    if (style.letterSpacing) node.letterSpacing = style.letterSpacing;
    if (style.textAlignHorizontal) node.textAlignHorizontal = style.textAlignHorizontal;
    if (style.textAlignVertical) node.textAlignVertical = style.textAlignVertical;
  }

  /**
   * Helper: Optimize paints array
   */
  private optimizePaints(paints: Paint[]): Paint[] {
    return paints.filter(paint => {
      // Remove invisible paints
      if (paint.visible === false) return false;
      if (paint.opacity === 0) return false;
      return true;
    }).map(paint => {
      // Remove default values
      const optimized = { ...paint };
      if (optimized.visible === true) delete optimized.visible;
      if (optimized.opacity === 1) delete optimized.opacity;
      return optimized;
    });
  }

  /**
   * Helper: Optimize effects array
   */
  private optimizeEffects(effects: Effect[]): Effect[] {
    return effects.filter(effect => {
      // Remove invisible effects
      if (effect.visible === false) return false;
      return true;
    }).map(effect => {
      // Remove default values
      const optimized = { ...effect };
      if (optimized.visible === true) delete optimized.visible;
      return optimized;
    });
  }

  /**
   * Helper: Extract variant properties
   */
  private extractVariantProperties(node: FigmaNode): any {
    const properties: any = {};

    // Parse variant properties from name
    if (node.name.includes('=')) {
      const parts = node.name.split(',').map(p => p.trim());
      for (const part of parts) {
        const [key, value] = part.split('=').map(p => p.trim());
        if (key && value) {
          properties[key] = value;
        }
      }
    }

    return properties;
  }

  /**
   * Helper: Extract component properties
   */
  private extractComponentProperties(node: FigmaNode): any {
    const properties: any = {
      width: node.absoluteBoundingBox?.width,
      height: node.absoluteBoundingBox?.height,
      hasAutoLayout: node.layoutMode !== undefined,
      hasConstraints: node.constraints !== undefined,
      exportSettings: node.exportSettings || []
    };

    if (node.layoutMode) {
      properties.layout = {
        mode: node.layoutMode,
        primaryAxisAlignItems: node.primaryAxisAlignItems,
        counterAxisAlignItems: node.counterAxisAlignItems,
        paddingLeft: node.paddingLeft,
        paddingRight: node.paddingRight,
        paddingTop: node.paddingTop,
        paddingBottom: node.paddingBottom,
        itemSpacing: node.itemSpacing
      };
    }

    return properties;
  }

  /**
   * Helper: Normalize paint to consistent format
   */
  private normalizePaint(paint: Paint): any {
    const normalized: any = {
      type: paint.type,
      visible: paint.visible !== false,
      opacity: paint.opacity || 1
    };

    if (paint.type === 'SOLID' && paint.color) {
      normalized.color = {
        hex: this.colorToHex(paint.color),
        rgb: `rgb(${Math.round(paint.color.r * 255)}, ${Math.round(paint.color.g * 255)}, ${Math.round(paint.color.b * 255)})`,
        rgba: `rgba(${Math.round(paint.color.r * 255)}, ${Math.round(paint.color.g * 255)}, ${Math.round(paint.color.b * 255)}, ${paint.color.a || 1})`,
        hsl: this.rgbToHsl(paint.color)
      };
    }

    if (paint.type === 'GRADIENT_LINEAR' && paint.gradientStops) {
      normalized.gradient = {
        type: 'linear',
        stops: paint.gradientStops.map(stop => ({
          position: stop.position,
          color: this.colorToHex(stop.color)
        }))
      };
    }

    return normalized;
  }

  /**
   * Helper: Convert color to hex
   */
  private colorToHex(color: Color): string {
    const r = Math.round(color.r * 255).toString(16).padStart(2, '0');
    const g = Math.round(color.g * 255).toString(16).padStart(2, '0');
    const b = Math.round(color.b * 255).toString(16).padStart(2, '0');
    return `#${r}${g}${b}`;
  }

  /**
   * Helper: Convert RGB to HSL
   */
  private rgbToHsl(color: Color): string {
    const r = color.r;
    const g = color.g;
    const b = color.b;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

      switch (max) {
        case r:
          h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
          break;
        case g:
          h = ((b - r) / d + 2) / 6;
          break;
        case b:
          h = ((r - g) / d + 4) / 6;
          break;
      }
    }

    return `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
  }

  /**
   * Set style cache for resolution
   */
  setStyleCache(styles: Map<string, any>): void {
    this.styleCache = styles;
  }

  /**
   * Set component cache for expansion
   */
  setComponentCache(components: Map<string, any>): void {
    this.componentCache = components;
  }

  /**
   * Clear all caches
   */
  clearCaches(): void {
    this.styleCache.clear();
    this.componentCache.clear();
  }
}