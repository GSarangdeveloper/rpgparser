import { FigmaNode, Paint, Effect, TextNode, TypeStyle } from '../../types/figma.types.js';
import { StyleData, ColorStyle, TypographyStyle, EffectStyle, SpacingStyle } from '../../types/extraction.types.js';
import Color from 'color';

export class StyleExtractor {
  private colors: Map<string, ColorStyle> = new Map();
  private typography: Map<string, TypographyStyle> = new Map();
  private effects: Map<string, EffectStyle> = new Map();
  private spacing: Map<number, SpacingStyle> = new Map();

  extract(node: FigmaNode): StyleData {
    this.extractNodeStyles(node);

    return {
      colors: Array.from(this.colors.values()),
      typography: Array.from(this.typography.values()),
      effects: Array.from(this.effects.values()),
      spacing: Array.from(this.spacing.values()),
    };
  }

  private extractNodeStyles(node: FigmaNode) {
    // Extract fills (colors)
    if (node.fills && Array.isArray(node.fills)) {
      node.fills.forEach(fill => this.extractPaintStyle(fill, node.id));
    }

    // Extract strokes
    if (node.strokes && Array.isArray(node.strokes)) {
      node.strokes.forEach(stroke => this.extractPaintStyle(stroke, node.id));
    }

    // Extract effects
    if (node.effects && Array.isArray(node.effects)) {
      node.effects.forEach(effect => this.extractEffectStyle(effect, node.id));
    }

    // Extract text styles
    if (node.type === 'TEXT') {
      this.extractTextStyle(node as TextNode);
    }

    // Extract spacing
    this.extractSpacing(node);

    // Recursively process children
    if (node.children) {
      node.children.forEach(child => this.extractNodeStyles(child));
    }
  }

  private extractPaintStyle(paint: Paint, nodeId: string) {
    if (!paint.visible) return;

    if (paint.type === 'SOLID' && paint.color) {
      const colorKey = this.getColorKey(paint.color);

      if (!this.colors.has(colorKey)) {
        const color = Color.rgb(
          paint.color.r * 255,
          paint.color.g * 255,
          paint.color.b * 255
        );

        const colorStyle: ColorStyle = {
          id: `color-${this.colors.size}`,
          name: this.generateColorName(paint.color),
          value: color.hex(),
          rgb: {
            r: Math.round(paint.color.r * 255),
            g: Math.round(paint.color.g * 255),
            b: Math.round(paint.color.b * 255),
          },
          opacity: paint.opacity || 1,
          usage: [nodeId],
          semantic: this.detectSemanticColor(color.hex()),
        };

        this.colors.set(colorKey, colorStyle);
      } else {
        const existingColor = this.colors.get(colorKey);
        if (existingColor && !existingColor.usage.includes(nodeId)) {
          existingColor.usage.push(nodeId);
        }
      }
    } else if (paint.type.startsWith('GRADIENT')) {
      // Handle gradients
      if (paint.gradientStops) {
        paint.gradientStops.forEach(stop => {
          const colorKey = this.getColorKey(stop.color);
          if (!this.colors.has(colorKey)) {
            const color = Color.rgb(
              stop.color.r * 255,
              stop.color.g * 255,
              stop.color.b * 255
            );

            this.colors.set(colorKey, {
              id: `gradient-color-${this.colors.size}`,
              name: this.generateColorName(stop.color),
              value: color.hex(),
              rgb: {
                r: Math.round(stop.color.r * 255),
                g: Math.round(stop.color.g * 255),
                b: Math.round(stop.color.b * 255),
              },
              opacity: stop.color.a,
              usage: [nodeId],
            });
          }
        });
      }
    }
  }

  private extractTextStyle(textNode: TextNode) {
    const style = textNode.style;
    if (!style) return;

    const styleKey = this.getTypographyKey(style);

    if (!this.typography.has(styleKey)) {
      const typographyStyle: TypographyStyle = {
        id: `text-${this.typography.size}`,
        name: this.generateTypographyName(style),
        fontFamily: style.fontFamily,
        fontSize: style.fontSize,
        fontWeight: style.fontWeight,
        lineHeight: style.lineHeightPx || style.fontSize * 1.2,
        letterSpacing: style.letterSpacing,
        textAlign: style.textAlignHorizontal,
        usage: [textNode.id],
      };

      this.typography.set(styleKey, typographyStyle);
    } else {
      const existingStyle = this.typography.get(styleKey);
      if (existingStyle && !existingStyle.usage.includes(textNode.id)) {
        existingStyle.usage.push(textNode.id);
      }
    }
  }

  private extractEffectStyle(effect: Effect, nodeId: string) {
    if (!effect.visible) return;

    const effectKey = this.getEffectKey(effect);

    if (!this.effects.has(effectKey)) {
      const effectStyle: EffectStyle = {
        id: `effect-${this.effects.size}`,
        name: this.generateEffectName(effect),
        type: effect.type,
        properties: effect,
        usage: [nodeId],
      };

      this.effects.set(effectKey, effectStyle);
    } else {
      const existingEffect = this.effects.get(effectKey);
      if (existingEffect && !existingEffect.usage.includes(nodeId)) {
        existingEffect.usage.push(nodeId);
      }
    }
  }

  private extractSpacing(node: FigmaNode) {
    // Extract padding
    if (node.paddingTop) this.addSpacing(node.paddingTop, node.id);
    if (node.paddingRight) this.addSpacing(node.paddingRight, node.id);
    if (node.paddingBottom) this.addSpacing(node.paddingBottom, node.id);
    if (node.paddingLeft) this.addSpacing(node.paddingLeft, node.id);

    // Extract item spacing
    if (node.itemSpacing) this.addSpacing(node.itemSpacing, node.id);
  }

  private addSpacing(value: number, nodeId: string) {
    const roundedValue = Math.round(value);

    if (!this.spacing.has(roundedValue)) {
      this.spacing.set(roundedValue, {
        name: `spacing-${roundedValue}`,
        value: roundedValue,
        usage: [nodeId],
      });
    } else {
      const existingSpacing = this.spacing.get(roundedValue);
      if (existingSpacing && !existingSpacing.usage.includes(nodeId)) {
        existingSpacing.usage.push(nodeId);
      }
    }
  }

  private getColorKey(color: any): string {
    return `${Math.round(color.r * 255)}-${Math.round(color.g * 255)}-${Math.round(color.b * 255)}-${color.a || 1}`;
  }

  private getTypographyKey(style: TypeStyle): string {
    return `${style.fontFamily}-${style.fontSize}-${style.fontWeight}-${style.lineHeightPx}`;
  }

  private getEffectKey(effect: Effect): string {
    return `${effect.type}-${effect.radius || 0}-${effect.offset?.x || 0}-${effect.offset?.y || 0}`;
  }

  private generateColorName(color: any): string {
    const hex = Color.rgb(
      color.r * 255,
      color.g * 255,
      color.b * 255
    ).hex();

    // Try to generate a descriptive name
    const hsl = Color(hex).hsl();
    const hue = hsl.hue();
    const saturation = hsl.saturationl();
    const lightness = hsl.lightness();

    let name = '';

    // Determine base color
    if (saturation < 10) {
      if (lightness < 20) name = 'black';
      else if (lightness > 80) name = 'white';
      else name = 'gray';
    } else {
      if (hue < 15 || hue >= 345) name = 'red';
      else if (hue < 45) name = 'orange';
      else if (hue < 75) name = 'yellow';
      else if (hue < 150) name = 'green';
      else if (hue < 210) name = 'cyan';
      else if (hue < 270) name = 'blue';
      else if (hue < 330) name = 'purple';
    }

    // Add lightness modifier
    if (lightness < 30) name = `dark-${name}`;
    else if (lightness > 70) name = `light-${name}`;

    return name;
  }

  private generateTypographyName(style: TypeStyle): string {
    const sizeCategory = this.getFontSizeCategory(style.fontSize);
    const weightCategory = this.getFontWeightCategory(style.fontWeight);
    return `${sizeCategory}-${weightCategory}`;
  }

  private generateEffectName(effect: Effect): string {
    return effect.type.toLowerCase().replace(/_/g, '-');
  }

  private getFontSizeCategory(size: number): string {
    if (size <= 12) return 'xs';
    if (size <= 14) return 'sm';
    if (size <= 16) return 'base';
    if (size <= 18) return 'lg';
    if (size <= 24) return 'xl';
    if (size <= 30) return '2xl';
    if (size <= 36) return '3xl';
    if (size <= 48) return '4xl';
    return '5xl';
  }

  private getFontWeightCategory(weight: number): string {
    if (weight <= 300) return 'light';
    if (weight <= 400) return 'regular';
    if (weight <= 500) return 'medium';
    if (weight <= 600) return 'semibold';
    if (weight <= 700) return 'bold';
    return 'black';
  }

  private detectSemanticColor(hex: string): ColorStyle['semantic'] {
    const color = Color(hex);
    const hue = color.hsl().hue();
    const saturation = color.hsl().saturationl();
    const lightness = color.hsl().lightness();

    // Primary: blues
    if (hue >= 200 && hue <= 240 && saturation > 40 && lightness > 30 && lightness < 70) {
      return 'primary';
    }

    // Error: reds
    if ((hue >= 350 || hue <= 10) && saturation > 40 && lightness > 30 && lightness < 70) {
      return 'error';
    }

    // Warning: oranges/yellows
    if (hue >= 30 && hue <= 60 && saturation > 40 && lightness > 40 && lightness < 70) {
      return 'warning';
    }

    // Success: greens
    if (hue >= 100 && hue <= 150 && saturation > 30 && lightness > 30 && lightness < 70) {
      return 'success';
    }

    // Info: cyans
    if (hue >= 180 && hue <= 200 && saturation > 30 && lightness > 40 && lightness < 70) {
      return 'info';
    }

    return undefined;
  }

  getColorPalette(): Record<string, string[]> {
    const palette: Record<string, string[]> = {};

    this.colors.forEach(color => {
      const baseName = color.name.split('-')[0];
      if (!palette[baseName]) {
        palette[baseName] = [];
      }
      palette[baseName].push(color.value);
    });

    return palette;
  }

  getTypographyScale(): TypographyStyle[] {
    return Array.from(this.typography.values())
      .sort((a, b) => a.fontSize - b.fontSize);
  }

  getSpacingScale(): number[] {
    return Array.from(this.spacing.keys()).sort((a, b) => a - b);
  }
}