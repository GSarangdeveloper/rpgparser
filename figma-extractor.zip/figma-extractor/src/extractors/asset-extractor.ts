import { FigmaNode } from '../../types/figma.types.js';
import { AssetData, ImageAsset, IconAsset, FontAsset, ExportVariant } from '../../types/extraction.types.js';
import { FigmaApiClient } from '../api/figma-client.js';
import sharp from 'sharp';
import { optimize } from 'svgo';
import * as fs from 'fs/promises';
import * as path from 'path';

export class AssetExtractor {
  private client: FigmaApiClient;
  private outputDir: string;
  private images: Map<string, ImageAsset> = new Map();
  private icons: Map<string, IconAsset> = new Map();
  private fonts: Set<FontAsset> = new Set();

  constructor(client: FigmaApiClient, outputDir: string = './output/assets') {
    this.client = client;
    this.outputDir = outputDir;
  }

  async extract(node: FigmaNode): Promise<AssetData> {
    await this.ensureOutputDirs();
    await this.extractNodeAssets(node);

    return {
      images: Array.from(this.images.values()),
      icons: Array.from(this.icons.values()),
      fonts: Array.from(this.fonts),
    };
  }

  private async ensureOutputDirs() {
    await fs.mkdir(path.join(this.outputDir, 'images'), { recursive: true });
    await fs.mkdir(path.join(this.outputDir, 'icons'), { recursive: true });
    await fs.mkdir(path.join(this.outputDir, 'fonts'), { recursive: true });
  }

  private async extractNodeAssets(node: FigmaNode) {
    // Extract images from fills
    if (node.fills) {
      for (const fill of node.fills) {
        if (fill.type === 'IMAGE' && fill.imageRef) {
          await this.extractImage(node, fill.imageRef);
        }
      }
    }

    // Extract vector graphics as icons
    if (this.isIconCandidate(node)) {
      await this.extractIcon(node);
    }

    // Extract fonts from text nodes
    if (node.type === 'TEXT') {
      this.extractFonts(node);
    }

    // Extract export settings
    if (node.exportSettings && node.exportSettings.length > 0) {
      await this.extractExports(node);
    }

    // Process children
    if (node.children) {
      for (const child of node.children) {
        await this.extractNodeAssets(child);
      }
    }
  }

  private async extractImage(node: FigmaNode, imageRef: string) {
    if (this.images.has(imageRef)) return;

    try {
      const imageUrls = await this.client.getImages([node.id]);
      const imageUrl = imageUrls[node.id];

      if (!imageUrl) return;

      const imageBuffer = await this.client.downloadImage(imageUrl);
      const metadata = await sharp(imageBuffer).metadata();

      const imageAsset: ImageAsset = {
        id: node.id,
        name: this.sanitizeFileName(node.name),
        url: imageUrl,
        dimensions: {
          width: metadata.width || 0,
          height: metadata.height || 0,
        },
        format: metadata.format || 'unknown',
        exportSettings: await this.generateImageVariants(node, imageBuffer),
      };

      this.images.set(imageRef, imageAsset);

      // Save original image
      const imagePath = path.join(this.outputDir, 'images', `${imageAsset.name}.${metadata.format}`);
      await fs.writeFile(imagePath, imageBuffer);

      // Generate and save variants
      for (const variant of imageAsset.exportSettings) {
        await this.saveImageVariant(imageBuffer, variant, imageAsset.name);
      }
    } catch (error) {
      console.error(`Failed to extract image from node ${node.id}:`, error);
    }
  }

  private async generateImageVariants(node: FigmaNode, buffer: Buffer): Promise<ExportVariant[]> {
    const variants: ExportVariant[] = [];
    const scales = [1, 2, 3]; // 1x, 2x, 3x for different screen densities

    for (const scale of scales) {
      variants.push({
        suffix: `@${scale}x`,
        resolution: scale,
        format: 'png',
        url: '', // Will be filled with local path
      });
    }

    return variants;
  }

  private async saveImageVariant(buffer: Buffer, variant: ExportVariant, baseName: string) {
    const filename = `${baseName}${variant.suffix}.${variant.format}`;
    const filepath = path.join(this.outputDir, 'images', filename);

    if (variant.resolution > 1) {
      const metadata = await sharp(buffer).metadata();
      const newWidth = Math.round((metadata.width || 0) * variant.resolution);
      const newHeight = Math.round((metadata.height || 0) * variant.resolution);

      await sharp(buffer)
        .resize(newWidth, newHeight)
        .toFile(filepath);
    } else {
      await fs.writeFile(filepath, buffer);
    }

    variant.url = filepath;
  }

  private isIconCandidate(node: FigmaNode): boolean {
    // Check if node is likely an icon
    if (!node.absoluteBoundingBox) return false;

    const { width, height } = node.absoluteBoundingBox;

    // Icons are typically small and square-ish
    const isSmall = width <= 100 && height <= 100;
    const isSquareish = Math.abs(width - height) / Math.max(width, height) < 0.2;

    // Check name patterns
    const iconPatterns = /icon|logo|symbol|glyph|arrow|chevron|check|close|menu/i;
    const hasIconName = iconPatterns.test(node.name);

    // Check node type
    const isVector = node.type === 'VECTOR' || node.type === 'BOOLEAN_OPERATION' ||
                     (node.type === 'FRAME' && node.children?.every(child =>
                       child.type === 'VECTOR' || child.type === 'BOOLEAN_OPERATION'
                     )) || false;

    return (isSmall && isSquareish && (hasIconName || isVector));
  }

  private async extractIcon(node: FigmaNode) {
    if (this.icons.has(node.id)) return;

    try {
      // Export as SVG for icons
      const svgUrls = await this.client.getImages([node.id], 'svg');
      const svgUrl = svgUrls[node.id];

      if (!svgUrl) return;

      const svgBuffer = await this.client.downloadImage(svgUrl);
      const svgContent = svgBuffer.toString('utf-8');

      // Optimize SVG
      const optimizedSvg = optimize(svgContent, {
        plugins: [
          'preset-default',
          'removeXMLNS',
        ],
      });

      const iconAsset: IconAsset = {
        id: node.id,
        name: this.sanitizeFileName(node.name),
        svgContent: optimizedSvg.data,
        size: {
          width: node.absoluteBoundingBox?.width || 24,
          height: node.absoluteBoundingBox?.height || 24,
        },
        category: this.categorizeIcon(node.name),
      };

      this.icons.set(node.id, iconAsset);

      // Save SVG file
      const iconPath = path.join(this.outputDir, 'icons', `${iconAsset.name}.svg`);
      await fs.writeFile(iconPath, optimizedSvg.data);
    } catch (error) {
      console.error(`Failed to extract icon from node ${node.id}:`, error);
    }
  }

  private categorizeIcon(name: string): string {
    const categories: Record<string, RegExp> = {
      navigation: /arrow|chevron|menu|hamburger|close|back|forward/i,
      action: /add|delete|edit|save|share|download|upload|search/i,
      status: /check|error|warning|info|success|fail/i,
      social: /facebook|twitter|instagram|linkedin|youtube|github/i,
      communication: /mail|email|phone|chat|message|notification/i,
      media: /play|pause|stop|volume|mute|camera|video/i,
      file: /file|folder|document|pdf|image|zip/i,
    };

    for (const [category, pattern] of Object.entries(categories)) {
      if (pattern.test(name)) {
        return category;
      }
    }

    return 'general';
  }

  private extractFonts(node: FigmaNode) {
    if (node.type !== 'TEXT') return;

    const textNode = node as any; // Cast to include text-specific properties
    if (!textNode.style) return;

    const fontFamily = textNode.style.fontFamily;
    const fontWeight = textNode.style.fontWeight;

    // Find existing font or create new
    let fontAsset: FontAsset | undefined;
    for (const font of this.fonts) {
      if (font.family === fontFamily) {
        fontAsset = font;
        break;
      }
    }

    if (!fontAsset) {
      fontAsset = {
        family: fontFamily,
        weights: [],
        styles: [],
        source: 'google-fonts', // Default assumption
      };
      this.fonts.add(fontAsset);
    }

    // Add weight if not already present
    if (!fontAsset.weights.includes(fontWeight)) {
      fontAsset.weights.push(fontWeight);
      fontAsset.weights.sort((a, b) => a - b);
    }

    // Add style
    const fontStyle = textNode.style.italic ? 'italic' : 'normal';
    if (!fontAsset.styles.includes(fontStyle)) {
      fontAsset.styles.push(fontStyle);
    }
  }

  private async extractExports(node: FigmaNode) {
    if (!node.exportSettings) return;

    for (const exportSetting of node.exportSettings) {
      const scale = exportSetting.constraint.value;
      const format = exportSetting.format.toLowerCase();

      try {
        const imageUrls = await this.client.getImages([node.id], format, scale);
        const imageUrl = imageUrls[node.id];

        if (imageUrl) {
          const buffer = await this.client.downloadImage(imageUrl);
          const filename = `${this.sanitizeFileName(node.name)}${exportSetting.suffix}.${format}`;
          const filepath = path.join(this.outputDir, 'images', filename);
          await fs.writeFile(filepath, buffer);
        }
      } catch (error) {
        console.error(`Failed to export ${node.id} with settings ${JSON.stringify(exportSetting)}:`, error);
      }
    }
  }

  private sanitizeFileName(name: string): string {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9-_]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  }

  async generateIconSprite() {
    const icons = Array.from(this.icons.values());
    if (icons.length === 0) return;

    let spriteContent = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">';

    for (const icon of icons) {
      const symbolContent = icon.svgContent
        .replace(/<svg[^>]*>/, `<symbol id="${icon.name}" viewBox="0 0 ${icon.size.width} ${icon.size.height}">`)
        .replace(/<\/svg>/, '</symbol>');
      spriteContent += symbolContent;
    }

    spriteContent += '</svg>';

    const spritePath = path.join(this.outputDir, 'icons', 'sprite.svg');
    await fs.writeFile(spritePath, spriteContent);

    return spritePath;
  }

  async generateAssetManifest() {
    const manifest = {
      images: Array.from(this.images.values()).map(img => ({
        id: img.id,
        name: img.name,
        path: `images/${img.name}.${img.format}`,
        dimensions: img.dimensions,
        variants: img.exportSettings,
      })),
      icons: Array.from(this.icons.values()).map(icon => ({
        id: icon.id,
        name: icon.name,
        path: `icons/${icon.name}.svg`,
        category: icon.category,
        size: icon.size,
      })),
      fonts: Array.from(this.fonts).map(font => ({
        family: font.family,
        weights: font.weights,
        styles: font.styles,
        source: font.source,
      })),
      statistics: {
        totalImages: this.images.size,
        totalIcons: this.icons.size,
        totalFonts: this.fonts.size,
        iconCategories: this.getIconCategories(),
      },
    };

    const manifestPath = path.join(this.outputDir, 'manifest.json');
    await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2));

    return manifest;
  }

  private getIconCategories(): Record<string, number> {
    const categories: Record<string, number> = {};

    for (const icon of this.icons.values()) {
      categories[icon.category] = (categories[icon.category] || 0) + 1;
    }

    return categories;
  }
}