import { StyleData, ColorStyle, TypographyStyle, EffectStyle, SpacingStyle } from '../../types/extraction.types.js';
import {
  DesignTokens,
  ColorToken,
  TypographyToken,
  SpacingToken,
  SizingToken,
  ElevationToken,
  MotionToken,
  BreakpointToken
} from '../../types/extraction.types.js';
import StyleDictionary from 'style-dictionary';
import * as fs from 'fs/promises';
import * as path from 'path';

export class TokenExtractor {
  private outputDir: string;

  constructor(outputDir: string = './output/tokens') {
    this.outputDir = outputDir;
  }

  async extract(styleData: StyleData, additionalData?: any): Promise<DesignTokens> {
    await this.ensureOutputDir();

    const tokens: DesignTokens = {
      colors: this.extractColorTokens(styleData.colors),
      typography: this.extractTypographyTokens(styleData.typography),
      spacing: this.extractSpacingTokens(styleData.spacing),
      sizing: this.extractSizingTokens(additionalData),
      elevation: this.extractElevationTokens(styleData.effects),
      motion: this.extractMotionTokens(additionalData),
      breakpoints: this.extractBreakpointTokens(additionalData),
    };

    // Export tokens in various formats
    await this.exportTokens(tokens);

    return tokens;
  }

  private extractColorTokens(colors: ColorStyle[]): ColorToken[] {
    const colorTokens: ColorToken[] = [];
    const colorGroups = this.groupColors(colors);

    for (const [category, groupColors] of Object.entries(colorGroups)) {
      groupColors.forEach((color, index) => {
        const shade = this.getColorShade(color, groupColors);
        const tokenName = `color-${category}${shade ? `-${shade}` : ''}`;

        colorTokens.push({
          name: tokenName,
          value: color.value,
          category,
          cssVariable: `--${tokenName}`,
        });
      });
    }

    // Add semantic color tokens
    const semanticTokens = this.createSemanticColorTokens(colors);
    colorTokens.push(...semanticTokens);

    return colorTokens;
  }

  private groupColors(colors: ColorStyle[]): Record<string, ColorStyle[]> {
    const groups: Record<string, ColorStyle[]> = {};

    for (const color of colors) {
      // Group by base color name
      const baseName = color.name.split('-')[0];

      if (!groups[baseName]) {
        groups[baseName] = [];
      }
      groups[baseName].push(color);
    }

    // Sort each group by lightness
    for (const group of Object.values(groups)) {
      group.sort((a, b) => {
        const getLightness = (c: ColorStyle) => {
          const r = c.rgb.r / 255;
          const g = c.rgb.g / 255;
          const b = c.rgb.b / 255;
          return (Math.max(r, g, b) + Math.min(r, g, b)) / 2;
        };
        return getLightness(a) - getLightness(b);
      });
    }

    return groups;
  }

  private getColorShade(color: ColorStyle, group: ColorStyle[]): string {
    const index = group.indexOf(color);
    const shades = ['50', '100', '200', '300', '400', '500', '600', '700', '800', '900'];

    if (group.length <= shades.length) {
      const interval = Math.floor(shades.length / group.length);
      return shades[index * interval];
    }

    return (index * 100).toString();
  }

  private createSemanticColorTokens(colors: ColorStyle[]): ColorToken[] {
    const semanticTokens: ColorToken[] = [];
    const semanticMap = {
      primary: null as ColorStyle | null,
      secondary: null as ColorStyle | null,
      error: null as ColorStyle | null,
      warning: null as ColorStyle | null,
      success: null as ColorStyle | null,
      info: null as ColorStyle | null,
    };

    // Find semantic colors
    for (const color of colors) {
      if (color.semantic && !semanticMap[color.semantic]) {
        semanticMap[color.semantic] = color;
      }
    }

    // Create tokens for semantic colors
    for (const [semantic, color] of Object.entries(semanticMap)) {
      if (color) {
        semanticTokens.push({
          name: `color-${semantic}`,
          value: color.value,
          category: 'semantic',
          cssVariable: `--color-${semantic}`,
        });

        // Add variations
        semanticTokens.push(
          {
            name: `color-${semantic}-light`,
            value: this.lightenColor(color.value, 0.2),
            category: 'semantic',
            cssVariable: `--color-${semantic}-light`,
          },
          {
            name: `color-${semantic}-dark`,
            value: this.darkenColor(color.value, 0.2),
            category: 'semantic',
            cssVariable: `--color-${semantic}-dark`,
          }
        );
      }
    }

    return semanticTokens;
  }

  private extractTypographyTokens(typography: TypographyStyle[]): TypographyToken[] {
    const tokens: TypographyToken[] = [];
    const sorted = [...typography].sort((a, b) => a.fontSize - b.fontSize);

    const scales = ['xs', 'sm', 'base', 'lg', 'xl', '2xl', '3xl', '4xl', '5xl'];

    sorted.forEach((style, index) => {
      const scale = scales[Math.min(index, scales.length - 1)];
      const weightName = this.getFontWeightName(style.fontWeight);

      tokens.push({
        name: `text-${scale}`,
        fontFamily: style.fontFamily,
        fontSize: `${style.fontSize}px`,
        fontWeight: style.fontWeight,
        lineHeight: `${style.lineHeight}px`,
        letterSpacing: `${style.letterSpacing}px`,
        cssClass: `text-${scale}`,
      });

      // Add weight variant if not regular
      if (weightName !== 'regular') {
        tokens.push({
          name: `text-${scale}-${weightName}`,
          fontFamily: style.fontFamily,
          fontSize: `${style.fontSize}px`,
          fontWeight: style.fontWeight,
          lineHeight: `${style.lineHeight}px`,
          letterSpacing: `${style.letterSpacing}px`,
          cssClass: `text-${scale}-${weightName}`,
        });
      }
    });

    return tokens;
  }

  private getFontWeightName(weight: number): string {
    const weightMap: Record<number, string> = {
      100: 'thin',
      200: 'extralight',
      300: 'light',
      400: 'regular',
      500: 'medium',
      600: 'semibold',
      700: 'bold',
      800: 'extrabold',
      900: 'black',
    };

    return weightMap[weight] || 'regular';
  }

  private extractSpacingTokens(spacing: SpacingStyle[]): SpacingToken[] {
    const tokens: SpacingToken[] = [];
    const sorted = [...spacing].sort((a, b) => a.value - b.value);

    // Create base spacing scale
    const baseUnit = 8;
    const scales = [0, 0.5, 1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10, 12, 14, 16, 20, 24, 32, 40, 48, 56, 64];

    scales.forEach(scale => {
      const value = scale * baseUnit;
      const nearestSpacing = sorted.find(s => Math.abs(s.value - value) < 2);

      tokens.push({
        name: `spacing-${scale}`,
        value: `${value}px`,
        pixels: value,
        cssVariable: `--spacing-${scale}`,
      });
    });

    return tokens;
  }

  private extractSizingTokens(additionalData: any): SizingToken[] {
    const tokens: SizingToken[] = [];

    // Common sizing tokens
    const sizes = {
      'xs': '20rem',
      'sm': '24rem',
      'md': '28rem',
      'lg': '32rem',
      'xl': '36rem',
      '2xl': '42rem',
      '3xl': '48rem',
      '4xl': '56rem',
      '5xl': '64rem',
      '6xl': '72rem',
      'full': '100%',
    };

    for (const [name, value] of Object.entries(sizes)) {
      tokens.push({
        name: `size-${name}`,
        value,
        category: 'container',
        cssVariable: `--size-${name}`,
      });
    }

    // Component-specific sizes
    const componentSizes = {
      'button-sm': '2rem',
      'button-md': '2.5rem',
      'button-lg': '3rem',
      'input-sm': '2rem',
      'input-md': '2.5rem',
      'input-lg': '3rem',
      'icon-sm': '1rem',
      'icon-md': '1.5rem',
      'icon-lg': '2rem',
    };

    for (const [name, value] of Object.entries(componentSizes)) {
      tokens.push({
        name,
        value,
        category: 'component',
        cssVariable: `--${name}`,
      });
    }

    return tokens;
  }

  private extractElevationTokens(effects: EffectStyle[]): ElevationToken[] {
    const tokens: ElevationToken[] = [];
    const shadows = effects.filter(e => e.type === 'DROP_SHADOW' || e.type === 'INNER_SHADOW');

    // Material Design elevation levels
    const elevationLevels = [0, 1, 2, 3, 4, 6, 8, 12, 16, 24];

    elevationLevels.forEach(level => {
      const shadow = this.generateElevationShadow(level);
      tokens.push({
        name: `elevation-${level}`,
        level,
        boxShadow: shadow,
        cssVariable: `--elevation-${level}`,
      });
    });

    return tokens;
  }

  private generateElevationShadow(level: number): string {
    if (level === 0) return 'none';

    const umbraOpacity = 0.2;
    const penumbraOpacity = 0.14;
    const ambientOpacity = 0.12;

    const umbraY = level;
    const penumbraY = level * 0.5;
    const umbraBlur = level * 2;
    const penumbraBlur = level;
    const ambientBlur = level * 2;

    return `
      0px ${umbraY}px ${umbraBlur}px rgba(0,0,0,${umbraOpacity}),
      0px ${penumbraY}px ${penumbraBlur}px rgba(0,0,0,${penumbraOpacity}),
      0px ${level}px ${ambientBlur}px rgba(0,0,0,${ambientOpacity})
    `.trim().replace(/\s+/g, ' ');
  }

  private extractMotionTokens(additionalData: any): MotionToken[] {
    const tokens: MotionToken[] = [];

    // Standard duration tokens
    const durations = {
      'instant': '0ms',
      'fast': '150ms',
      'normal': '300ms',
      'slow': '450ms',
      'slower': '600ms',
    };

    // Standard easing tokens
    const easings = {
      'linear': 'linear',
      'ease-in': 'cubic-bezier(0.4, 0, 1, 1)',
      'ease-out': 'cubic-bezier(0, 0, 0.2, 1)',
      'ease-in-out': 'cubic-bezier(0.4, 0, 0.2, 1)',
      'bounce': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
    };

    // Create motion tokens for each combination
    for (const [durationName, duration] of Object.entries(durations)) {
      for (const [easingName, easing] of Object.entries(easings)) {
        tokens.push({
          name: `motion-${durationName}-${easingName}`,
          duration,
          easing,
          cssVariable: `--motion-${durationName}-${easingName}`,
        });
      }
    }

    return tokens;
  }

  private extractBreakpointTokens(additionalData: any): BreakpointToken[] {
    const tokens: BreakpointToken[] = [];

    const breakpoints = [
      { name: 'xs', minWidth: '0', maxWidth: '575px' },
      { name: 'sm', minWidth: '576px', maxWidth: '767px' },
      { name: 'md', minWidth: '768px', maxWidth: '991px' },
      { name: 'lg', minWidth: '992px', maxWidth: '1199px' },
      { name: 'xl', minWidth: '1200px', maxWidth: '1399px' },
      { name: 'xxl', minWidth: '1400px' },
    ];

    for (const bp of breakpoints) {
      tokens.push({
        name: `breakpoint-${bp.name}`,
        minWidth: bp.minWidth,
        maxWidth: bp.maxWidth,
        cssVariable: `--breakpoint-${bp.name}`,
      });
    }

    return tokens;
  }

  private lightenColor(hex: string, amount: number): string {
    const rgb = this.hexToRgb(hex);
    if (!rgb) return hex;

    const lighten = (value: number) => Math.min(255, value + (255 - value) * amount);

    const newRgb = {
      r: Math.round(lighten(rgb.r)),
      g: Math.round(lighten(rgb.g)),
      b: Math.round(lighten(rgb.b)),
    };

    return this.rgbToHex(newRgb);
  }

  private darkenColor(hex: string, amount: number): string {
    const rgb = this.hexToRgb(hex);
    if (!rgb) return hex;

    const darken = (value: number) => Math.max(0, value * (1 - amount));

    const newRgb = {
      r: Math.round(darken(rgb.r)),
      g: Math.round(darken(rgb.g)),
      b: Math.round(darken(rgb.b)),
    };

    return this.rgbToHex(newRgb);
  }

  private hexToRgb(hex: string): { r: number; g: number; b: number } | null {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16),
    } : null;
  }

  private rgbToHex(rgb: { r: number; g: number; b: number }): string {
    const toHex = (n: number) => n.toString(16).padStart(2, '0');
    return `#${toHex(rgb.r)}${toHex(rgb.g)}${toHex(rgb.b)}`;
  }

  private async ensureOutputDir() {
    await fs.mkdir(this.outputDir, { recursive: true });
  }

  private async exportTokens(tokens: DesignTokens) {
    // Export as JSON
    await this.exportAsJson(tokens);

    // Export as CSS variables
    await this.exportAsCss(tokens);

    // Export as SCSS variables
    await this.exportAsScss(tokens);

    // Export as JavaScript/TypeScript
    await this.exportAsTypeScript(tokens);

    // Export using Style Dictionary
    await this.exportWithStyleDictionary(tokens);
  }

  private async exportAsJson(tokens: DesignTokens) {
    const jsonPath = path.join(this.outputDir, 'tokens.json');
    await fs.writeFile(jsonPath, JSON.stringify(tokens, null, 2));
  }

  private async exportAsCss(tokens: DesignTokens) {
    let css = ':root {\n';

    // Colors
    tokens.colors.forEach(token => {
      css += `  ${token.cssVariable}: ${token.value};\n`;
    });

    // Typography
    tokens.typography.forEach(token => {
      css += `  --font-${token.name}: ${token.fontSize};\n`;
      css += `  --font-weight-${token.name}: ${token.fontWeight};\n`;
      css += `  --line-height-${token.name}: ${token.lineHeight};\n`;
    });

    // Spacing
    tokens.spacing.forEach(token => {
      css += `  ${token.cssVariable}: ${token.value};\n`;
    });

    // Sizing
    tokens.sizing.forEach(token => {
      css += `  ${token.cssVariable}: ${token.value};\n`;
    });

    // Elevation
    tokens.elevation.forEach(token => {
      css += `  ${token.cssVariable}: ${token.boxShadow};\n`;
    });

    css += '}\n';

    const cssPath = path.join(this.outputDir, 'tokens.css');
    await fs.writeFile(cssPath, css);
  }

  private async exportAsScss(tokens: DesignTokens) {
    let scss = '// Design Tokens\n\n';

    // Colors
    scss += '// Colors\n';
    tokens.colors.forEach(token => {
      scss += `$${token.name}: ${token.value};\n`;
    });

    scss += '\n// Typography\n';
    tokens.typography.forEach(token => {
      scss += `$font-size-${token.name}: ${token.fontSize};\n`;
      scss += `$font-weight-${token.name}: ${token.fontWeight};\n`;
      scss += `$line-height-${token.name}: ${token.lineHeight};\n`;
    });

    scss += '\n// Spacing\n';
    tokens.spacing.forEach(token => {
      scss += `$${token.name}: ${token.value};\n`;
    });

    scss += '\n// Elevation\n';
    tokens.elevation.forEach(token => {
      scss += `$${token.name}: ${token.boxShadow};\n`;
    });

    const scssPath = path.join(this.outputDir, 'tokens.scss');
    await fs.writeFile(scssPath, scss);
  }

  private async exportAsTypeScript(tokens: DesignTokens) {
    let ts = '// Auto-generated design tokens\n\n';

    ts += 'export const tokens = {\n';

    ts += '  colors: {\n';
    tokens.colors.forEach(token => {
      ts += `    '${token.name}': '${token.value}',\n`;
    });
    ts += '  },\n';

    ts += '  typography: {\n';
    tokens.typography.forEach(token => {
      ts += `    '${token.name}': {\n`;
      ts += `      fontSize: '${token.fontSize}',\n`;
      ts += `      fontWeight: ${token.fontWeight},\n`;
      ts += `      lineHeight: '${token.lineHeight}',\n`;
      ts += `    },\n`;
    });
    ts += '  },\n';

    ts += '  spacing: {\n';
    tokens.spacing.forEach(token => {
      ts += `    '${token.name}': '${token.value}',\n`;
    });
    ts += '  },\n';

    ts += '};\n';

    const tsPath = path.join(this.outputDir, 'tokens.ts');
    await fs.writeFile(tsPath, ts);
  }

  private async exportWithStyleDictionary(tokens: DesignTokens) {
    const config = {
      source: [`${this.outputDir}/tokens.json`],
      platforms: {
        scss: {
          transformGroup: 'scss',
          buildPath: `${this.outputDir}/style-dictionary/`,
          files: [{
            destination: 'variables.scss',
            format: 'scss/variables',
          }],
        },
        css: {
          transformGroup: 'css',
          buildPath: `${this.outputDir}/style-dictionary/`,
          files: [{
            destination: 'variables.css',
            format: 'css/variables',
          }],
        },
      },
    };

    const configPath = path.join(this.outputDir, 'style-dictionary.config.json');
    await fs.writeFile(configPath, JSON.stringify(config, null, 2));

    // Note: Style Dictionary would be run as a separate build step
  }
}