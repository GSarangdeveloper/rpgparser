import { FigmaNode, TextNode } from '../../types/figma.types.js';
import {
  DetectedComponent,
  ComponentType,
  ComponentProperties,
  ComponentLocation,
  ComponentState,
  ComponentVariant,
  LibraryMatch
} from '../../types/extraction.types.js';

interface DetectionRule {
  type: ComponentType;
  patterns: ComponentPattern[];
  confidence: number;
}

interface ComponentPattern {
  nodeTypes?: string[];
  namePatterns?: RegExp[];
  childPatterns?: ComponentPattern[];
  properties?: Partial<ComponentProperties>;
  dimensions?: { minWidth?: number; maxWidth?: number; minHeight?: number; maxHeight?: number };
  childCount?: { min?: number; max?: number };
}

export class ComponentDetector {
  private detectedComponents: DetectedComponent[] = [];
  private detectionRules: DetectionRule[] = this.initializeDetectionRules();
  private libraryMappings = this.initializeLibraryMappings();

  detect(node: FigmaNode, location: Partial<ComponentLocation> = {}): DetectedComponent[] {
    this.detectNode(node, location);
    return this.detectedComponents;
  }

  private detectNode(node: FigmaNode, location: Partial<ComponentLocation>) {
    // Check if node matches any component pattern
    const detection = this.detectComponentType(node);

    if (detection) {
      const component: DetectedComponent = {
        id: `comp-${this.detectedComponents.length + 1}`,
        type: detection.type,
        subType: detection.subType,
        confidence: detection.confidence,
        name: node.name,
        properties: this.extractProperties(node, detection.type),
        location: {
          pageId: location.pageId || '',
          pageName: location.pageName || '',
          frameId: location.frameId || '',
          frameName: location.frameName || '',
          nodePath: location.nodePath || node.id,
          coordinates: {
            x: node.absoluteBoundingBox?.x || 0,
            y: node.absoluteBoundingBox?.y || 0,
          },
        },
        states: this.detectStates(node),
        variants: this.detectVariants(node),
        libraryMatches: this.findLibraryMatches(detection.type, node),
      };

      this.detectedComponents.push(component);
    }

    // Continue detection on children
    if (node.children) {
      node.children.forEach(child => {
        const childLocation: Partial<ComponentLocation> = {
          ...location,
          nodePath: `${location.nodePath || ''}/${child.name}`,
        };
        this.detectNode(child, childLocation);
      });
    }
  }

  private detectComponentType(node: FigmaNode): { type: ComponentType; subType?: string; confidence: number } | null {
    let bestMatch: { type: ComponentType; subType?: string; confidence: number } | null = null;
    let highestConfidence = 0;

    for (const rule of this.detectionRules) {
      const confidence = this.calculateConfidence(node, rule);
      if (confidence > highestConfidence && confidence > 0.5) {
        highestConfidence = confidence;
        bestMatch = {
          type: rule.type,
          subType: this.detectSubType(node, rule.type),
          confidence,
        };
      }
    }

    return bestMatch;
  }

  private calculateConfidence(node: FigmaNode, rule: DetectionRule): number {
    let totalScore = 0;
    let checks = 0;

    for (const pattern of rule.patterns) {
      // Check node type
      if (pattern.nodeTypes) {
        checks++;
        if (pattern.nodeTypes.includes(node.type)) {
          totalScore += 1;
        }
      }

      // Check name patterns
      if (pattern.namePatterns) {
        checks++;
        if (pattern.namePatterns.some(regex => regex.test(node.name.toLowerCase()))) {
          totalScore += 1;
        }
      }

      // Check dimensions
      if (pattern.dimensions && node.absoluteBoundingBox) {
        checks++;
        const { width, height } = node.absoluteBoundingBox;
        const dims = pattern.dimensions;
        if (
          (!dims.minWidth || width >= dims.minWidth) &&
          (!dims.maxWidth || width <= dims.maxWidth) &&
          (!dims.minHeight || height >= dims.minHeight) &&
          (!dims.maxHeight || height <= dims.maxHeight)
        ) {
          totalScore += 1;
        }
      }

      // Check child count
      if (pattern.childCount) {
        checks++;
        const childCount = node.children?.length || 0;
        if (
          (!pattern.childCount.min || childCount >= pattern.childCount.min) &&
          (!pattern.childCount.max || childCount <= pattern.childCount.max)
        ) {
          totalScore += 1;
        }
      }

      // Check for specific child patterns
      if (pattern.childPatterns && node.children) {
        checks++;
        const hasRequiredChildren = pattern.childPatterns.every(childPattern =>
          node.children!.some(child => this.matchesPattern(child, childPattern))
        );
        if (hasRequiredChildren) {
          totalScore += 1;
        }
      }
    }

    return checks > 0 ? (totalScore / checks) * rule.confidence : 0;
  }

  private matchesPattern(node: FigmaNode, pattern: ComponentPattern): boolean {
    if (pattern.nodeTypes && !pattern.nodeTypes.includes(node.type)) {
      return false;
    }

    if (pattern.namePatterns) {
      if (!pattern.namePatterns.some(regex => regex.test(node.name.toLowerCase()))) {
        return false;
      }
    }

    return true;
  }

  private detectSubType(node: FigmaNode, type: ComponentType): string | undefined {
    switch (type) {
      case 'BUTTON':
        if (node.name.toLowerCase().includes('primary')) return 'primary';
        if (node.name.toLowerCase().includes('secondary')) return 'secondary';
        if (node.name.toLowerCase().includes('icon')) return 'icon';
        if (node.fills?.[0]?.type === 'SOLID') return 'filled';
        return 'outlined';

      case 'INPUT':
        if (node.name.toLowerCase().includes('email')) return 'email';
        if (node.name.toLowerCase().includes('password')) return 'password';
        if (node.name.toLowerCase().includes('search')) return 'search';
        if (node.name.toLowerCase().includes('number')) return 'number';
        if (node.name.toLowerCase().includes('tel')) return 'tel';
        return 'text';

      case 'TABLE':
        const hasHeader = node.children?.[0]?.name.toLowerCase().includes('header');
        const hasPagination = node.children?.some(child =>
          child.name.toLowerCase().includes('pagination')
        );
        if (hasHeader && hasPagination) return 'data-table';
        if (hasHeader) return 'simple-table';
        return 'basic';

      default:
        return undefined;
    }
  }

  private extractProperties(node: FigmaNode, type: ComponentType): ComponentProperties {
    const props: ComponentProperties = {};

    // Extract common properties
    props.disabled = node.opacity !== undefined && node.opacity < 0.5;

    // Extract text content
    const textNodes = this.findTextNodes(node);
    if (textNodes.length > 0) {
      const primaryText = textNodes[0] as TextNode;
      props.label = primaryText.characters;
    }

    // Extract type-specific properties
    switch (type) {
      case 'BUTTON':
        props.size = this.detectSize(node);
        props.variant = this.detectButtonVariant(node);
        break;

      case 'INPUT':
        const placeholderText = textNodes.find(text => {
          const textNode = text as TextNode;
          return textNode.characters.toLowerCase().includes('placeholder') ||
            (textNode.opacity !== undefined && textNode.opacity < 0.5);
        });
        if (placeholderText) {
          props.placeholder = (placeholderText as TextNode).characters;
        }
        props.required = node.name.toLowerCase().includes('required');
        break;

      case 'CHECKBOX':
      case 'RADIO':
      case 'TOGGLE':
        const isChecked = node.children?.some(child =>
          child.name.toLowerCase().includes('checked') ||
          child.name.toLowerCase().includes('selected') ||
          child.visible === true && child.name.toLowerCase().includes('check')
        );
        props.value = isChecked;
        break;

      case 'SELECT':
        const options = node.children?.filter(child =>
          child.name.toLowerCase().includes('option')
        );
        if (options) {
          props.customProps = {
            options: options.map(opt => {
              const textNode = this.findTextNodes(opt)[0] as TextNode;
              return textNode?.characters || opt.name;
            })
          };
        }
        break;
    }

    return props;
  }

  private detectSize(node: FigmaNode): 'small' | 'medium' | 'large' {
    if (!node.absoluteBoundingBox) return 'medium';

    const { height } = node.absoluteBoundingBox;

    if (height < 32) return 'small';
    if (height > 48) return 'large';
    return 'medium';
  }

  private detectButtonVariant(node: FigmaNode): string {
    if (!node.fills || node.fills.length === 0) return 'text';

    const hasFill = node.fills.some(fill => fill.type === 'SOLID' && fill.visible);
    const hasStroke = node.strokes && node.strokes.length > 0;

    if (hasFill && hasStroke) return 'contained-outlined';
    if (hasFill) return 'contained';
    if (hasStroke) return 'outlined';

    return 'text';
  }

  private detectStates(node: FigmaNode): ComponentState[] {
    const states: ComponentState[] = [];

    // Look for component variants or states
    if (node.type === 'COMPONENT_SET') {
      node.children?.forEach(variant => {
        const stateName = this.extractStateName(variant.name);
        if (stateName) {
          states.push({
            name: stateName,
            properties: this.extractProperties(variant, 'BUTTON'), // Use detected type
            styles: {
              fills: variant.fills,
              strokes: variant.strokes,
              effects: variant.effects,
            },
          });
        }
      });
    }

    // If no explicit states, create default state
    if (states.length === 0) {
      states.push({
        name: 'default',
        properties: {},
        styles: {
          fills: node.fills,
          strokes: node.strokes,
          effects: node.effects,
        },
      });
    }

    return states;
  }

  private extractStateName(name: string): string {
    const statePatterns = ['default', 'hover', 'active', 'focus', 'disabled', 'selected', 'pressed'];
    const lowerName = name.toLowerCase();

    for (const pattern of statePatterns) {
      if (lowerName.includes(pattern)) {
        return pattern;
      }
    }

    return 'default';
  }

  private detectVariants(node: FigmaNode): ComponentVariant[] {
    const variants: ComponentVariant[] = [];

    if (node.componentPropertyDefinitions) {
      Object.entries(node.componentPropertyDefinitions).forEach(([key, def]) => {
        if (def.type === 'VARIANT' && def.variantOptions) {
          def.variantOptions.forEach(option => {
            variants.push({
              name: option,
              properties: { [key]: option },
            });
          });
        }
      });
    }

    return variants;
  }

  private findTextNodes(node: FigmaNode): FigmaNode[] {
    const textNodes: FigmaNode[] = [];

    if (node.type === 'TEXT') {
      textNodes.push(node);
    }

    if (node.children) {
      node.children.forEach(child => {
        textNodes.push(...this.findTextNodes(child));
      });
    }

    return textNodes;
  }

  private findLibraryMatches(type: ComponentType, node: FigmaNode): LibraryMatch[] {
    const matches: LibraryMatch[] = [];
    const mappings = this.libraryMappings[type] || [];

    for (const mapping of mappings) {
      const confidence = this.calculateLibraryMatchConfidence(node, mapping);
      if (confidence > 0.5) {
        matches.push({
          library: mapping.library,
          component: mapping.component,
          confidence,
          importPath: mapping.importPath,
          version: mapping.version,
        });
      }
    }

    // Sort by confidence
    return matches.sort((a, b) => b.confidence - a.confidence);
  }

  private calculateLibraryMatchConfidence(node: FigmaNode, mapping: any): number {
    let score = 0;
    let checks = 0;

    // Check name similarity
    if (mapping.namePattern) {
      checks++;
      if (mapping.namePattern.test(node.name.toLowerCase())) {
        score += 1;
      }
    }

    // Check structural similarity
    if (mapping.structure) {
      checks++;
      if (this.matchesStructure(node, mapping.structure)) {
        score += 1;
      }
    }

    // Check property compatibility
    if (mapping.properties) {
      checks++;
      const nodeProps = this.extractProperties(node, mapping.type);
      const propMatch = this.compareProperties(nodeProps, mapping.properties);
      score += propMatch;
    }

    return checks > 0 ? score / checks : 0;
  }

  private matchesStructure(node: FigmaNode, structure: any): boolean {
    // Simplified structure matching
    if (structure.childCount) {
      const childCount = node.children?.length || 0;
      if (childCount < structure.childCount.min || childCount > structure.childCount.max) {
        return false;
      }
    }
    return true;
  }

  private compareProperties(props1: any, props2: any): number {
    const keys1 = Object.keys(props1);
    const keys2 = Object.keys(props2);
    const allKeys = new Set([...keys1, ...keys2]);

    let matches = 0;
    for (const key of allKeys) {
      if (props1[key] === props2[key]) {
        matches++;
      }
    }

    return allKeys.size > 0 ? matches / allKeys.size : 0;
  }

  private initializeDetectionRules(): DetectionRule[] {
    return [
      {
        type: 'BUTTON',
        confidence: 0.9,
        patterns: [
          {
            namePatterns: [/button/i, /btn/i, /cta/i],
            dimensions: { minWidth: 60, maxWidth: 300, minHeight: 24, maxHeight: 80 },
            childPatterns: [{ nodeTypes: ['TEXT'] }],
          },
          {
            nodeTypes: ['FRAME', 'RECTANGLE'],
            dimensions: { minWidth: 40, maxWidth: 300, minHeight: 28, maxHeight: 60 },
            childCount: { min: 1, max: 3 },
          },
        ],
      },
      {
        type: 'INPUT',
        confidence: 0.85,
        patterns: [
          {
            namePatterns: [/input/i, /field/i, /textbox/i, /entry/i],
            dimensions: { minWidth: 100, minHeight: 30, maxHeight: 60 },
          },
          {
            nodeTypes: ['FRAME'],
            dimensions: { minWidth: 120, minHeight: 32, maxHeight: 56 },
            childPatterns: [{ nodeTypes: ['TEXT'] }],
          },
        ],
      },
      {
        type: 'CHECKBOX',
        confidence: 0.9,
        patterns: [
          {
            namePatterns: [/checkbox/i, /check/i],
            dimensions: { minWidth: 14, maxWidth: 30, minHeight: 14, maxHeight: 30 },
          },
          {
            nodeTypes: ['FRAME', 'RECTANGLE'],
            dimensions: { minWidth: 16, maxWidth: 24, minHeight: 16, maxHeight: 24 },
          },
        ],
      },
      {
        type: 'RADIO',
        confidence: 0.9,
        patterns: [
          {
            namePatterns: [/radio/i, /option/i],
            dimensions: { minWidth: 14, maxWidth: 30, minHeight: 14, maxHeight: 30 },
          },
          {
            nodeTypes: ['ELLIPSE'],
            dimensions: { minWidth: 16, maxWidth: 24, minHeight: 16, maxHeight: 24 },
          },
        ],
      },
      {
        type: 'TOGGLE',
        confidence: 0.85,
        patterns: [
          {
            namePatterns: [/toggle/i, /switch/i],
            dimensions: { minWidth: 40, maxWidth: 80, minHeight: 20, maxHeight: 40 },
          },
        ],
      },
      {
        type: 'SELECT',
        confidence: 0.8,
        patterns: [
          {
            namePatterns: [/select/i, /dropdown/i, /combo/i],
            childPatterns: [
              { namePatterns: [/arrow/i, /chevron/i, /caret/i] }
            ],
          },
        ],
      },
      {
        type: 'TABLE',
        confidence: 0.85,
        patterns: [
          {
            namePatterns: [/table/i, /grid/i, /data/i],
            childCount: { min: 2 },
          },
        ],
      },
      {
        type: 'CARD',
        confidence: 0.8,
        patterns: [
          {
            namePatterns: [/card/i],
            dimensions: { minWidth: 200, minHeight: 100 },
          },
          {
            nodeTypes: ['FRAME'],
            dimensions: { minWidth: 240, minHeight: 120 },
            childCount: { min: 2 },
          },
        ],
      },
      {
        type: 'MODAL',
        confidence: 0.85,
        patterns: [
          {
            namePatterns: [/modal/i, /dialog/i, /popup/i, /overlay/i],
            dimensions: { minWidth: 300, minHeight: 200 },
          },
        ],
      },
      {
        type: 'NAVIGATION',
        confidence: 0.8,
        patterns: [
          {
            namePatterns: [/nav/i, /menu/i, /header/i],
            dimensions: { minHeight: 40 },
          },
        ],
      },
    ];
  }

  private initializeLibraryMappings(): Record<ComponentType, any[]> {
    return {
      'BUTTON': [
        {
          library: '@angular/material',
          component: 'MatButton',
          importPath: '@angular/material/button',
          namePattern: /button|btn/i,
          structure: { childCount: { min: 1, max: 3 } },
        },
        {
          library: 'primeng',
          component: 'p-button',
          importPath: 'primeng/button',
          namePattern: /button|btn/i,
        },
      ],
      'INPUT': [
        {
          library: '@angular/material',
          component: 'MatInput',
          importPath: '@angular/material/input',
          namePattern: /input|field/i,
        },
        {
          library: 'primeng',
          component: 'p-inputText',
          importPath: 'primeng/inputtext',
          namePattern: /input|field/i,
        },
      ],
      'CHECKBOX': [
        {
          library: '@angular/material',
          component: 'MatCheckbox',
          importPath: '@angular/material/checkbox',
          namePattern: /check/i,
        },
      ],
      'RADIO': [
        {
          library: '@angular/material',
          component: 'MatRadioButton',
          importPath: '@angular/material/radio',
          namePattern: /radio/i,
        },
      ],
      'SELECT': [
        {
          library: '@angular/material',
          component: 'MatSelect',
          importPath: '@angular/material/select',
          namePattern: /select|dropdown/i,
        },
      ],
      'TABLE': [
        {
          library: '@angular/material',
          component: 'MatTable',
          importPath: '@angular/material/table',
          namePattern: /table|grid/i,
        },
      ],
      'CARD': [
        {
          library: '@angular/material',
          component: 'MatCard',
          importPath: '@angular/material/card',
          namePattern: /card/i,
        },
      ],
      'TOGGLE': [],
      'SLIDER': [],
      'DATEPICKER': [],
      'TIMEPICKER': [],
      'LIST': [],
      'ACCORDION': [],
      'TABS': [],
      'SIDEBAR': [],
      'BREADCRUMB': [],
      'PAGINATION': [],
      'MODAL': [],
      'TOOLTIP': [],
      'ALERT': [],
      'BADGE': [],
      'CHIP': [],
      'PROGRESS': [],
      'SPINNER': [],
      'AVATAR': [],
      'MENU': [],
      'FORM': [],
      'NAVIGATION': [],
    };
  }

  getStatistics() {
    const stats = {
      totalDetected: this.detectedComponents.length,
      byType: {} as Record<ComponentType, number>,
      averageConfidence: 0,
      libraryMatchRate: 0,
    };

    this.detectedComponents.forEach(comp => {
      stats.byType[comp.type] = (stats.byType[comp.type] || 0) + 1;
      stats.averageConfidence += comp.confidence;
      if (comp.libraryMatches.length > 0) {
        stats.libraryMatchRate++;
      }
    });

    if (this.detectedComponents.length > 0) {
      stats.averageConfidence /= this.detectedComponents.length;
      stats.libraryMatchRate = stats.libraryMatchRate / this.detectedComponents.length;
    }

    return stats;
  }
}