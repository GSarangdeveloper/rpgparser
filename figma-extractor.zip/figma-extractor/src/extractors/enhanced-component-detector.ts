import { FigmaNode } from '../../types/figma.types.js';
import { DetectedComponent, ComponentType } from '../../types/extraction.types.js';
import { ComponentDetector } from './component-detector.js';
import * as kmeans from 'ml-kmeans';
import { Engine, Rule } from 'json-rules-engine';

interface PatternRule {
  name: string;
  type: ComponentType;
  conditions: any;
  priority: number;
  confidence: number;
}

interface MLFeatures {
  width: number;
  height: number;
  aspectRatio: number;
  childCount: number;
  hasText: boolean;
  hasFills: boolean;
  hasStrokes: boolean;
  hasEffects: boolean;
  hasCornerRadius: boolean;
  depth: number;
  textLength: number;
  colorCount: number;
  hasIcon: boolean;
  isClickable: boolean;
  hasHoverState: boolean;
}

export class EnhancedComponentDetector extends ComponentDetector {
  private rulesEngine: Engine;
  private mlModel: any;
  private patternRules: PatternRule[];
  private detectionConfidence: Map<string, number> = new Map();
  private componentClusters: Map<number, ComponentType[]> = new Map();

  constructor() {
    super();
    this.rulesEngine = new Engine();
    this.patternRules = this.initializePatternRules();
    this.initializeRulesEngine();
    this.initializeMLClusters();
  }

  /**
   * Enhanced detection with ML and pattern matching
   */
  async detectEnhanced(node: FigmaNode): Promise<DetectedComponent[]> {
    const components: DetectedComponent[] = [];

    // Run base detection first
    const baseComponents = this.detect(node);

    // Enhance each detected component
    for (const component of baseComponents) {
      const enhancedComponent = await this.enhanceComponentDetection(component, node);
      components.push(enhancedComponent);
    }

    // Detect additional patterns using ML
    const mlDetected = await this.detectWithML(node);
    components.push(...mlDetected);

    // Run pattern-based detection
    const patternDetected = await this.detectWithPatterns(node);
    components.push(...patternDetected);

    // Remove duplicates and merge similar detections
    return this.mergeDuplicateDetections(components);
  }

  /**
   * Enhance component detection with additional analysis
   */
  private async enhanceComponentDetection(
    component: DetectedComponent,
    node: FigmaNode
  ): Promise<DetectedComponent> {
    // Extract ML features
    const features = this.extractMLFeatures(node);

    // Run rules engine for validation
    const rulesResult = await this.rulesEngine.run({ node, features });

    // Calculate enhanced confidence
    const mlConfidence = this.calculateMLConfidence(features, component.type);
    const patternConfidence = await this.calculatePatternConfidence(node, component.type);

    // Combine confidences
    const enhancedConfidence = this.combineConfidences([
      component.confidence,
      mlConfidence,
      patternConfidence
    ]);

    return {
      ...component,
      confidence: enhancedConfidence,
      mlFeatures: features,
      patternMatches: rulesResult.results,
      enhancedDetection: true
    };
  }

  /**
   * Detect components using ML clustering
   */
  private async detectWithML(node: FigmaNode): Promise<DetectedComponent[]> {
    const components: DetectedComponent[] = [];
    const nodes = this.flattenNodes(node);

    // Extract features for all nodes
    const featureVectors = nodes.map(n => this.extractFeatureVector(n));

    if (featureVectors.length < 3) return components;

    // Perform k-means clustering
    const k = Math.min(10, Math.floor(featureVectors.length / 3));
    const result = kmeans(featureVectors, k);

    // Analyze clusters
    result.clusters.forEach((clusterIndex, nodeIndex) => {
      const nodeToAnalyze = nodes[nodeIndex];
      const predictedTypes = this.componentClusters.get(clusterIndex) || [];

      for (const type of predictedTypes) {
        const confidence = this.calculateClusterConfidence(
          featureVectors[nodeIndex],
          result.centroids[clusterIndex]
        );

        if (confidence > 0.7) {
          components.push({
            id: `ml-${components.length}`,
            type,
            confidence,
            name: nodeToAnalyze.name,
            properties: this.extractProperties(nodeToAnalyze, type),
            location: {
              pageId: '',
              frameId: nodeToAnalyze.id,
              nodeId: nodeToAnalyze.id
            },
            mlDetected: true,
            clusterIndex
          } as DetectedComponent);
        }
      }
    });

    return components;
  }

  /**
   * Detect components using pattern rules
   */
  private async detectWithPatterns(node: FigmaNode): Promise<DetectedComponent[]> {
    const components: DetectedComponent[] = [];
    const nodes = this.flattenNodes(node);

    for (const n of nodes) {
      const features = this.extractMLFeatures(n);

      for (const rule of this.patternRules) {
        const facts = { node: n, features };

        // Create a temporary engine with just this rule
        const tempEngine = new Engine();
        tempEngine.addRule(new Rule(rule.conditions));

        try {
          const result = await tempEngine.run(facts);

          if (result.results.length > 0) {
            components.push({
              id: `pattern-${components.length}`,
              type: rule.type,
              confidence: rule.confidence,
              name: n.name,
              properties: this.extractProperties(n, rule.type),
              location: {
                pageId: '',
                frameId: n.id,
                nodeId: n.id
              },
              patternDetected: true,
              patternName: rule.name
            } as DetectedComponent);
          }
        } catch (error) {
          // Rule didn't match, continue
        }
      }
    }

    return components;
  }

  /**
   * Extract ML features from a node
   */
  private extractMLFeatures(node: FigmaNode): MLFeatures {
    const hasText = node.type === 'TEXT' || this.containsTextChild(node);
    const textLength = node.type === 'TEXT' ? (node.characters?.length || 0) : 0;

    return {
      width: node.absoluteBoundingBox?.width || 0,
      height: node.absoluteBoundingBox?.height || 0,
      aspectRatio: (node.absoluteBoundingBox?.width || 1) / (node.absoluteBoundingBox?.height || 1),
      childCount: node.children?.length || 0,
      hasText,
      hasFills: Array.isArray(node.fills) && node.fills.length > 0,
      hasStrokes: Array.isArray(node.strokes) && node.strokes.length > 0,
      hasEffects: Array.isArray(node.effects) && node.effects.length > 0,
      hasCornerRadius: node.cornerRadius > 0 || node.rectangleCornerRadii?.some(r => r > 0),
      depth: this.getNodeDepth(node),
      textLength,
      colorCount: this.countUniqueColors(node),
      hasIcon: this.detectIcon(node),
      isClickable: this.detectClickable(node),
      hasHoverState: this.detectHoverState(node)
    };
  }

  /**
   * Extract feature vector for clustering
   */
  private extractFeatureVector(node: FigmaNode): number[] {
    const features = this.extractMLFeatures(node);
    return [
      features.width,
      features.height,
      features.aspectRatio,
      features.childCount,
      features.hasText ? 1 : 0,
      features.hasFills ? 1 : 0,
      features.hasStrokes ? 1 : 0,
      features.hasEffects ? 1 : 0,
      features.hasCornerRadius ? 1 : 0,
      features.depth,
      features.textLength,
      features.colorCount,
      features.hasIcon ? 1 : 0,
      features.isClickable ? 1 : 0,
      features.hasHoverState ? 1 : 0
    ];
  }

  /**
   * Initialize pattern rules for the rules engine
   */
  private initializePatternRules(): PatternRule[] {
    return [
      // Button patterns
      {
        name: 'primary-button',
        type: 'BUTTON',
        conditions: {
          conditions: {
            all: [
              { fact: 'features', path: '.hasText', operator: 'equal', value: true },
              { fact: 'features', path: '.hasCornerRadius', operator: 'equal', value: true },
              { fact: 'features', path: '.height', operator: 'greaterThan', value: 30 },
              { fact: 'features', path: '.height', operator: 'lessThan', value: 60 },
              { fact: 'features', path: '.aspectRatio', operator: 'greaterThan', value: 2 }
            ]
          }
        },
        priority: 10,
        confidence: 0.85
      },

      // Input field patterns
      {
        name: 'text-input',
        type: 'INPUT',
        conditions: {
          conditions: {
            all: [
              { fact: 'features', path: '.height', operator: 'greaterThan', value: 35 },
              { fact: 'features', path: '.height', operator: 'lessThan', value: 60 },
              { fact: 'features', path: '.aspectRatio', operator: 'greaterThan', value: 3 },
              { fact: 'node', path: '.type', operator: 'in', value: ['FRAME', 'RECTANGLE'] }
            ]
          }
        },
        priority: 9,
        confidence: 0.80
      },

      // Card patterns
      {
        name: 'content-card',
        type: 'CARD',
        conditions: {
          conditions: {
            all: [
              { fact: 'features', path: '.hasEffects', operator: 'equal', value: true },
              { fact: 'features', path: '.childCount', operator: 'greaterThan', value: 2 },
              { fact: 'features', path: '.aspectRatio', operator: 'lessThan', value: 2 },
              { fact: 'features', path: '.hasCornerRadius', operator: 'equal', value: true }
            ]
          }
        },
        priority: 8,
        confidence: 0.75
      },

      // Table patterns
      {
        name: 'data-table',
        type: 'TABLE',
        conditions: {
          conditions: {
            all: [
              { fact: 'features', path: '.childCount', operator: 'greaterThan', value: 4 },
              { fact: 'node', path: '.layoutMode', operator: 'equal', value: 'VERTICAL' },
              { fact: 'features', path: '.aspectRatio', operator: 'greaterThan', value: 1.5 }
            ]
          }
        },
        priority: 7,
        confidence: 0.78
      },

      // Modal patterns
      {
        name: 'modal-dialog',
        type: 'MODAL',
        conditions: {
          conditions: {
            all: [
              { fact: 'features', path: '.hasEffects', operator: 'equal', value: true },
              { fact: 'features', path: '.width', operator: 'greaterThan', value: 400 },
              { fact: 'features', path: '.hasCornerRadius', operator: 'equal', value: true },
              { fact: 'node', path: '.opacity', operator: 'lessThan', value: 1 }
            ]
          }
        },
        priority: 6,
        confidence: 0.82
      }
    ];
  }

  /**
   * Initialize rules engine with pattern rules
   */
  private initializeRulesEngine(): void {
    for (const rule of this.patternRules) {
      this.rulesEngine.addRule(new Rule(rule.conditions));
    }
  }

  /**
   * Initialize ML component clusters
   */
  private initializeMLClusters(): void {
    // Pre-defined clusters based on common patterns
    this.componentClusters.set(0, ['BUTTON', 'CHIP']);
    this.componentClusters.set(1, ['INPUT', 'TEXTAREA']);
    this.componentClusters.set(2, ['CARD', 'CONTAINER']);
    this.componentClusters.set(3, ['TABLE', 'LIST']);
    this.componentClusters.set(4, ['NAVIGATION', 'SIDEBAR']);
    this.componentClusters.set(5, ['MODAL', 'DIALOG']);
    this.componentClusters.set(6, ['CHECKBOX', 'RADIO']);
    this.componentClusters.set(7, ['SELECT', 'DROPDOWN']);
    this.componentClusters.set(8, ['TABS', 'STEPPER']);
    this.componentClusters.set(9, ['HEADER', 'FOOTER']);
  }

  /**
   * Calculate ML-based confidence
   */
  private calculateMLConfidence(features: MLFeatures, type: ComponentType): number {
    // Simple heuristic-based confidence calculation
    let confidence = 0.5;

    // Adjust confidence based on feature matching
    switch (type) {
      case 'BUTTON':
        if (features.hasText && features.hasCornerRadius && features.height < 60) {
          confidence += 0.3;
        }
        if (features.isClickable) confidence += 0.1;
        if (features.hasHoverState) confidence += 0.1;
        break;

      case 'INPUT':
        if (features.height > 35 && features.height < 60 && features.aspectRatio > 3) {
          confidence += 0.3;
        }
        if (features.hasText) confidence += 0.2;
        break;

      case 'TABLE':
        if (features.childCount > 4 && features.aspectRatio > 1.5) {
          confidence += 0.4;
        }
        break;

      case 'CARD':
        if (features.hasEffects && features.hasCornerRadius && features.childCount > 2) {
          confidence += 0.35;
        }
        break;
    }

    return Math.min(confidence, 1.0);
  }

  /**
   * Calculate pattern-based confidence
   */
  private async calculatePatternConfidence(node: FigmaNode, type: ComponentType): Promise<number> {
    const features = this.extractMLFeatures(node);
    const facts = { node, features };

    let maxConfidence = 0;

    for (const rule of this.patternRules.filter(r => r.type === type)) {
      try {
        const tempEngine = new Engine();
        tempEngine.addRule(new Rule(rule.conditions));
        const result = await tempEngine.run(facts);

        if (result.results.length > 0) {
          maxConfidence = Math.max(maxConfidence, rule.confidence);
        }
      } catch {
        // Rule didn't match
      }
    }

    return maxConfidence;
  }

  /**
   * Calculate cluster confidence
   */
  private calculateClusterConfidence(features: number[], centroid: number[]): number {
    // Calculate Euclidean distance
    let distance = 0;
    for (let i = 0; i < features.length; i++) {
      distance += Math.pow(features[i] - centroid[i], 2);
    }
    distance = Math.sqrt(distance);

    // Convert distance to confidence (inverse relationship)
    const maxDistance = 1000; // Normalize based on expected max distance
    return Math.max(0, 1 - (distance / maxDistance));
  }

  /**
   * Combine multiple confidence scores
   */
  private combineConfidences(confidences: number[]): number {
    // Weighted average with emphasis on higher scores
    const weights = confidences.map(c => c * c); // Square to emphasize higher scores
    const weightSum = weights.reduce((a, b) => a + b, 0);

    if (weightSum === 0) return 0;

    const weightedSum = confidences.reduce((sum, conf, i) => sum + conf * weights[i], 0);
    return Math.min(weightedSum / weightSum, 1.0);
  }

  /**
   * Merge duplicate detections
   */
  private mergeDuplicateDetections(components: DetectedComponent[]): DetectedComponent[] {
    const merged: DetectedComponent[] = [];
    const processed = new Set<string>();

    for (const component of components) {
      const nodeId = component.location.nodeId;

      if (!processed.has(nodeId)) {
        // Find all detections for the same node
        const duplicates = components.filter(c => c.location.nodeId === nodeId);

        if (duplicates.length === 1) {
          merged.push(component);
        } else {
          // Merge duplicates, keeping the highest confidence
          const best = duplicates.reduce((prev, curr) =>
            curr.confidence > prev.confidence ? curr : prev
          );

          // Combine detection methods
          const enhancedBest = {
            ...best,
            detectionMethods: duplicates.map(d => {
              if (d.mlDetected) return 'ml';
              if (d.patternDetected) return 'pattern';
              if (d.enhancedDetection) return 'enhanced';
              return 'base';
            })
          };

          merged.push(enhancedBest);
        }

        processed.add(nodeId);
      }
    }

    return merged;
  }

  /**
   * Helper: Flatten all nodes in the tree
   */
  private flattenNodes(node: FigmaNode): FigmaNode[] {
    const nodes: FigmaNode[] = [node];

    if (node.children) {
      for (const child of node.children) {
        nodes.push(...this.flattenNodes(child));
      }
    }

    return nodes;
  }

  /**
   * Helper: Check if node contains text children
   */
  private containsTextChild(node: FigmaNode): boolean {
    if (node.type === 'TEXT') return true;
    if (node.children) {
      return node.children.some(child => this.containsTextChild(child));
    }
    return false;
  }

  /**
   * Helper: Get node depth in tree
   */
  private getNodeDepth(node: FigmaNode): number {
    let depth = 0;
    let current = node;

    while (current.parent) {
      depth++;
      current = current.parent as FigmaNode;
    }

    return depth;
  }

  /**
   * Helper: Count unique colors in node
   */
  private countUniqueColors(node: FigmaNode): number {
    const colors = new Set<string>();

    if (node.fills && Array.isArray(node.fills)) {
      node.fills.forEach(fill => {
        if (fill.type === 'SOLID' && fill.color) {
          colors.add(`${fill.color.r}-${fill.color.g}-${fill.color.b}`);
        }
      });
    }

    if (node.strokes && Array.isArray(node.strokes)) {
      node.strokes.forEach(stroke => {
        if (stroke.type === 'SOLID' && stroke.color) {
          colors.add(`${stroke.color.r}-${stroke.color.g}-${stroke.color.b}`);
        }
      });
    }

    return colors.size;
  }

  /**
   * Helper: Detect if node is likely an icon
   */
  private detectIcon(node: FigmaNode): boolean {
    if (node.name.toLowerCase().includes('icon')) return true;
    if (node.type === 'VECTOR') return true;

    const ratio = (node.absoluteBoundingBox?.width || 0) / (node.absoluteBoundingBox?.height || 0);
    const size = node.absoluteBoundingBox?.width || 0;

    // Square-ish, small size
    return ratio > 0.8 && ratio < 1.2 && size < 50;
  }

  /**
   * Helper: Detect if node is clickable
   */
  private detectClickable(node: FigmaNode): boolean {
    // Check for interaction triggers
    if (node.interactions && node.interactions.length > 0) return true;

    // Check name patterns
    const clickablePatterns = ['button', 'btn', 'link', 'click', 'tap'];
    return clickablePatterns.some(pattern =>
      node.name.toLowerCase().includes(pattern)
    );
  }

  /**
   * Helper: Detect if node has hover state
   */
  private detectHoverState(node: FigmaNode): boolean {
    // Check for hover in name
    if (node.name.toLowerCase().includes('hover')) return true;

    // Check for hover interactions
    if (node.interactions) {
      return node.interactions.some(i =>
        i.trigger?.type === 'ON_HOVER'
      );
    }

    return false;
  }

  /**
   * Get detection statistics
   */
  getEnhancedStatistics(): any {
    const baseStats = this.getStatistics();

    return {
      ...baseStats,
      mlDetections: Array.from(this.detectionConfidence.entries()).filter(([_, conf]) => conf > 0.7).length,
      patternMatches: this.patternRules.length,
      averageMLConfidence: this.calculateAverageConfidence(),
      clusterCount: this.componentClusters.size
    };
  }

  /**
   * Calculate average ML confidence
   */
  private calculateAverageConfidence(): number {
    const confidences = Array.from(this.detectionConfidence.values());
    if (confidences.length === 0) return 0;

    const sum = confidences.reduce((a, b) => a + b, 0);
    return sum / confidences.length;
  }
}