import { FigmaFile, FigmaNode } from '../../types/figma.types.js';
import { StructuralData, PageData, FrameData, HierarchyNode } from '../../types/extraction.types.js';

export class StructuralExtractor {
  private fileData: FigmaFile;
  private nodeMap: Map<string, FigmaNode> = new Map();

  constructor(fileData: FigmaFile) {
    this.fileData = fileData;
    this.buildNodeMap(this.fileData.document);
  }

  private buildNodeMap(node: FigmaNode) {
    this.nodeMap.set(node.id, node);
    if (node.children) {
      node.children.forEach(child => this.buildNodeMap(child));
    }
  }

  extract(): StructuralData {
    const pages = this.extractPages();
    const frames = this.extractFrames();
    const hierarchy = this.buildHierarchy(this.fileData.document, 0, '');

    return {
      pages,
      frames,
      hierarchy,
    };
  }

  private extractPages(): PageData[] {
    const pages: PageData[] = [];

    if (this.fileData.document.children) {
      this.fileData.document.children.forEach((page, index) => {
        if (page.type === 'CANVAS') {
          const frameIds = page.children?.map(child => child.id) || [];
          pages.push({
            id: page.id,
            name: page.name,
            frames: frameIds,
            order: index,
          });
        }
      });
    }

    return pages;
  }

  private extractFrames(): FrameData[] {
    const frames: FrameData[] = [];

    this.traverseNodes(this.fileData.document, (node) => {
      if (node.type === 'FRAME') {
        const dimensions = node.absoluteBoundingBox || { width: 0, height: 0 };
        const frameType = this.detectFrameType(dimensions.width);

        frames.push({
          id: node.id,
          name: node.name,
          type: frameType,
          dimensions: {
            width: dimensions.width,
            height: dimensions.height,
          },
          background: node.fills || [],
          children: node.children?.map(child => child.id) || [],
        });
      }
    });

    return frames;
  }

  private detectFrameType(width: number): 'DESKTOP' | 'TABLET' | 'MOBILE' | 'CUSTOM' {
    if (width >= 1200) return 'DESKTOP';
    if (width >= 768 && width < 1200) return 'TABLET';
    if (width < 768) return 'MOBILE';
    return 'CUSTOM';
  }

  private buildHierarchy(node: FigmaNode, depth: number, path: string): HierarchyNode {
    const nodePath = path ? `${path}/${node.name}` : node.name;

    return {
      id: node.id,
      name: node.name,
      type: node.type,
      depth,
      path: nodePath,
      children: node.children?.map(child =>
        this.buildHierarchy(child, depth + 1, nodePath)
      ) || [],
    };
  }

  private traverseNodes(node: FigmaNode, callback: (node: FigmaNode) => void) {
    callback(node);
    if (node.children) {
      node.children.forEach(child => this.traverseNodes(child, callback));
    }
  }

  getNodeById(id: string): FigmaNode | undefined {
    return this.nodeMap.get(id);
  }

  getNodePath(nodeId: string): string[] {
    const path: string[] = [];
    let current = this.nodeMap.get(nodeId);

    while (current) {
      path.unshift(current.name);
      current = this.findParent(current.id);
    }

    return path;
  }

  private findParent(nodeId: string): FigmaNode | undefined {
    for (const [id, node] of this.nodeMap.entries()) {
      if (node.children?.some(child => child.id === nodeId)) {
        return node;
      }
    }
    return undefined;
  }

  getNodesByType(type: string): FigmaNode[] {
    const nodes: FigmaNode[] = [];

    for (const node of this.nodeMap.values()) {
      if (node.type === type) {
        nodes.push(node);
      }
    }

    return nodes;
  }

  getComponents(): FigmaNode[] {
    return this.getNodesByType('COMPONENT');
  }

  getInstances(): FigmaNode[] {
    return this.getNodesByType('INSTANCE');
  }

  getTextNodes(): FigmaNode[] {
    return this.getNodesByType('TEXT');
  }

  getNodeStatistics(): Record<string, number> {
    const stats: Record<string, number> = {};

    for (const node of this.nodeMap.values()) {
      stats[node.type] = (stats[node.type] || 0) + 1;
    }

    return stats;
  }

  getMaxDepth(): number {
    let maxDepth = 0;

    const calculateDepth = (node: FigmaNode, depth: number) => {
      maxDepth = Math.max(maxDepth, depth);
      if (node.children) {
        node.children.forEach(child => calculateDepth(child, depth + 1));
      }
    };

    calculateDepth(this.fileData.document, 0);
    return maxDepth;
  }
}