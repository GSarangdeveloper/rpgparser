import { FigmaNode } from '../../types/figma.types.js';
import { FigmaApiClient } from '../api/figma-client.js';
import puppeteer, { Browser, Page } from 'puppeteer';
import sharp from 'sharp';
import * as fs from 'fs/promises';
import * as path from 'path';
import Jimp from 'jimp';
import pixelmatch from 'pixelmatch';

interface ScreenshotOptions {
  format: 'png' | 'jpg' | 'pdf';
  scale: number;
  outputDir: string;
  withAnnotations: boolean;
  compareWithImplementation?: string;
}

interface VisualDocumentation {
  fullPages: ScreenshotCapture[];
  components: ComponentScreenshot[];
  annotated: AnnotatedScreenshot[];
  flows: UserFlowCapture[];
  comparisons: VisualComparison[];
}

interface ScreenshotCapture {
  nodeId: string;
  nodeName: string;
  viewport: string;
  resolution: string;
  path: string;
  dimensions: { width: number; height: number };
}

interface ComponentScreenshot {
  componentId: string;
  componentName: string;
  componentType: string;
  states: StateScreenshot[];
  variants: VariantScreenshot[];
}

interface StateScreenshot {
  state: string;
  path: string;
  thumbnail: string;
}

interface VariantScreenshot {
  variant: string;
  path: string;
}

interface AnnotatedScreenshot {
  originalId: string;
  type: 'spacing' | 'grid' | 'components' | 'measurements';
  path: string;
}

interface UserFlowCapture {
  flowName: string;
  steps: FlowStep[];
  pdfPath?: string;
}

interface FlowStep {
  stepNumber: number;
  frameId: string;
  frameName: string;
  description: string;
  screenshotPath: string;
}

interface VisualComparison {
  designPath: string;
  implementationPath: string;
  diffPath: string;
  similarity: number;
  differences: number;
}

export class VisualDocumenter {
  private client: FigmaApiClient;
  private outputDir: string;
  private browser: Browser | null = null;

  constructor(client: FigmaApiClient, outputDir: string = './output/visual-docs') {
    this.client = client;
    this.outputDir = outputDir;
  }

  async document(node: FigmaNode, options: Partial<ScreenshotOptions> = {}): Promise<VisualDocumentation> {
    await this.ensureOutputDirs();

    const defaultOptions: ScreenshotOptions = {
      format: 'png',
      scale: 2,
      outputDir: this.outputDir,
      withAnnotations: true,
      ...options,
    };

    const documentation: VisualDocumentation = {
      fullPages: await this.captureFullPages(node, defaultOptions),
      components: await this.captureComponents(node, defaultOptions),
      annotated: await this.createAnnotatedScreenshots(node, defaultOptions),
      flows: await this.captureUserFlows(node, defaultOptions),
      comparisons: [],
    };

    if (options.compareWithImplementation) {
      documentation.comparisons = await this.performVisualComparison(
        documentation.fullPages,
        options.compareWithImplementation
      );
    }

    await this.generateVisualIndex(documentation);

    return documentation;
  }

  private async ensureOutputDirs() {
    const dirs = [
      'full-designs/desktop',
      'full-designs/tablet',
      'full-designs/mobile',
      'components',
      'annotated/spacing',
      'annotated/grid',
      'annotated/components',
      'flows',
      'comparisons',
      'thumbnails',
    ];

    for (const dir of dirs) {
      await fs.mkdir(path.join(this.outputDir, dir), { recursive: true });
    }
  }

  private async captureFullPages(node: FigmaNode, options: ScreenshotOptions): Promise<ScreenshotCapture[]> {
    const captures: ScreenshotCapture[] = [];
    const frames = this.findFrames(node);

    for (const frame of frames) {
      const viewport = this.detectViewport(frame);

      for (const scale of [1, 2, 3]) {
        try {
          const imageUrl = await this.getNodeImage(frame.id, options.format, scale);
          if (!imageUrl) continue;

          const imageBuffer = await this.client.downloadImage(imageUrl);
          const filename = `${this.sanitizeName(frame.name)}-${viewport}-${scale}x.${options.format}`;
          const filepath = path.join(this.outputDir, 'full-designs', viewport, filename);

          await fs.writeFile(filepath, imageBuffer);

          // Generate metadata
          const metadata = await sharp(imageBuffer).metadata();
          captures.push({
            nodeId: frame.id,
            nodeName: frame.name,
            viewport,
            resolution: `${scale}x`,
            path: filepath,
            dimensions: {
              width: metadata.width || 0,
              height: metadata.height || 0,
            },
          });

          // Create thumbnail
          await this.createThumbnail(imageBuffer, frame.name);
        } catch (error) {
          console.error(`Failed to capture frame ${frame.id}:`, error);
        }
      }
    }

    return captures;
  }

  private async captureComponents(node: FigmaNode, options: ScreenshotOptions): Promise<ComponentScreenshot[]> {
    const componentScreenshots: ComponentScreenshot[] = [];
    const components = this.findComponents(node);

    for (const component of components) {
      const screenshot: ComponentScreenshot = {
        componentId: component.id,
        componentName: component.name,
        componentType: this.detectComponentType(component),
        states: [],
        variants: [],
      };

      // Capture component states
      if (component.type === 'COMPONENT_SET') {
        for (const variant of component.children || []) {
          const state = this.extractState(variant.name);
          const imageUrl = await this.getNodeImage(variant.id, options.format, options.scale);

          if (imageUrl) {
            const imageBuffer = await this.client.downloadImage(imageUrl);
            const statePath = path.join(
              this.outputDir,
              'components',
              this.sanitizeName(component.name),
              `${state}.${options.format}`
            );

            await fs.mkdir(path.dirname(statePath), { recursive: true });
            await fs.writeFile(statePath, imageBuffer);

            const thumbnailPath = await this.createThumbnail(imageBuffer, `${component.name}-${state}`);

            screenshot.states.push({
              state,
              path: statePath,
              thumbnail: thumbnailPath,
            });
          }
        }
      } else {
        // Capture single component
        const imageUrl = await this.getNodeImage(component.id, options.format, options.scale);

        if (imageUrl) {
          const imageBuffer = await this.client.downloadImage(imageUrl);
          const componentPath = path.join(
            this.outputDir,
            'components',
            `${this.sanitizeName(component.name)}.${options.format}`
          );

          await fs.writeFile(componentPath, imageBuffer);

          const thumbnailPath = await this.createThumbnail(imageBuffer, component.name);

          screenshot.states.push({
            state: 'default',
            path: componentPath,
            thumbnail: thumbnailPath,
          });
        }
      }

      componentScreenshots.push(screenshot);
    }

    return componentScreenshots;
  }

  private async createAnnotatedScreenshots(
    node: FigmaNode,
    options: ScreenshotOptions
  ): Promise<AnnotatedScreenshot[]> {
    const annotated: AnnotatedScreenshot[] = [];

    // Create spacing annotations
    const spacingAnnotations = await this.annotateSpacing(node, options);
    annotated.push(...spacingAnnotations);

    // Create grid annotations
    const gridAnnotations = await this.annotateGrid(node, options);
    annotated.push(...gridAnnotations);

    // Create component boundary annotations
    const componentAnnotations = await this.annotateComponents(node, options);
    annotated.push(...componentAnnotations);

    return annotated;
  }

  private async annotateSpacing(node: FigmaNode, options: ScreenshotOptions): Promise<AnnotatedScreenshot[]> {
    const annotations: AnnotatedScreenshot[] = [];
    const frames = this.findFrames(node);

    for (const frame of frames) {
      if (!frame.absoluteBoundingBox) continue;

      // Get base image
      const imageUrl = await this.getNodeImage(frame.id, 'png', options.scale);
      if (!imageUrl) continue;

      const imageBuffer = await this.client.downloadImage(imageUrl);

      // Create annotation overlay using Sharp
      const { width, height } = await sharp(imageBuffer).metadata();
      if (!width || !height) continue;

      // Create SVG overlay with spacing indicators
      const svgOverlay = this.createSpacingSvg(frame, width, height);

      const annotatedBuffer = await sharp(imageBuffer)
        .composite([
          {
            input: Buffer.from(svgOverlay),
            top: 0,
            left: 0,
          },
        ])
        .toBuffer();

      const filename = `spacing-${this.sanitizeName(frame.name)}.png`;
      const filepath = path.join(this.outputDir, 'annotated', 'spacing', filename);
      await fs.writeFile(filepath, annotatedBuffer);

      annotations.push({
        originalId: frame.id,
        type: 'spacing',
        path: filepath,
      });
    }

    return annotations;
  }

  private async annotateGrid(node: FigmaNode, options: ScreenshotOptions): Promise<AnnotatedScreenshot[]> {
    const annotations: AnnotatedScreenshot[] = [];
    const frames = this.findFrames(node);

    for (const frame of frames) {
      if (!frame.absoluteBoundingBox) continue;

      const imageUrl = await this.getNodeImage(frame.id, 'png', options.scale);
      if (!imageUrl) continue;

      const imageBuffer = await this.client.downloadImage(imageUrl);
      const { width, height } = await sharp(imageBuffer).metadata();
      if (!width || !height) continue;

      // Create grid overlay
      const gridSvg = this.createGridSvg(width, height);

      const annotatedBuffer = await sharp(imageBuffer)
        .composite([
          {
            input: Buffer.from(gridSvg),
            top: 0,
            left: 0,
            blend: 'over',
          },
        ])
        .toBuffer();

      const filename = `grid-${this.sanitizeName(frame.name)}.png`;
      const filepath = path.join(this.outputDir, 'annotated', 'grid', filename);
      await fs.writeFile(filepath, annotatedBuffer);

      annotations.push({
        originalId: frame.id,
        type: 'grid',
        path: filepath,
      });
    }

    return annotations;
  }

  private async annotateComponents(node: FigmaNode, options: ScreenshotOptions): Promise<AnnotatedScreenshot[]> {
    const annotations: AnnotatedScreenshot[] = [];
    const frames = this.findFrames(node);

    for (const frame of frames) {
      const imageUrl = await this.getNodeImage(frame.id, 'png', options.scale);
      if (!imageUrl) continue;

      const imageBuffer = await this.client.downloadImage(imageUrl);
      const { width, height } = await sharp(imageBuffer).metadata();
      if (!width || !height) continue;

      // Create component boundary overlay
      const componentSvg = this.createComponentBoundarySvg(frame, width, height, options.scale);

      const annotatedBuffer = await sharp(imageBuffer)
        .composite([
          {
            input: Buffer.from(componentSvg),
            top: 0,
            left: 0,
          },
        ])
        .toBuffer();

      const filename = `components-${this.sanitizeName(frame.name)}.png`;
      const filepath = path.join(this.outputDir, 'annotated', 'components', filename);
      await fs.writeFile(filepath, annotatedBuffer);

      annotations.push({
        originalId: frame.id,
        type: 'components',
        path: filepath,
      });
    }

    return annotations;
  }

  private async captureUserFlows(node: FigmaNode, options: ScreenshotOptions): Promise<UserFlowCapture[]> {
    const flows: UserFlowCapture[] = [];

    // Find prototype flows
    const prototypeFlows = this.findPrototypeFlows(node);

    for (const flow of prototypeFlows) {
      const flowCapture: UserFlowCapture = {
        flowName: flow.name,
        steps: [],
      };

      for (let i = 0; i < flow.frames.length; i++) {
        const frame = flow.frames[i];
        const imageUrl = await this.getNodeImage(frame.id, options.format, options.scale);

        if (imageUrl) {
          const imageBuffer = await this.client.downloadImage(imageUrl);
          const stepPath = path.join(
            this.outputDir,
            'flows',
            this.sanitizeName(flow.name),
            `step-${i + 1}.${options.format}`
          );

          await fs.mkdir(path.dirname(stepPath), { recursive: true });
          await fs.writeFile(stepPath, imageBuffer);

          flowCapture.steps.push({
            stepNumber: i + 1,
            frameId: frame.id,
            frameName: frame.name,
            description: flow.descriptions?.[i] || `Step ${i + 1}`,
            screenshotPath: stepPath,
          });
        }
      }

      flows.push(flowCapture);
    }

    return flows;
  }

  private async performVisualComparison(
    designScreenshots: ScreenshotCapture[],
    implementationPath: string
  ): Promise<VisualComparison[]> {
    const comparisons: VisualComparison[] = [];

    // Initialize browser for implementation screenshots
    this.browser = await puppeteer.launch({ headless: true });
    const page = await this.browser.newPage();

    for (const designShot of designScreenshots) {
      try {
        // Navigate to implementation
        await page.goto(implementationPath, { waitUntil: 'networkidle2' });

        // Set viewport to match design
        await page.setViewport({
          width: designShot.dimensions.width,
          height: designShot.dimensions.height,
        });

        // Capture implementation screenshot
        const implementationBuffer = await page.screenshot({ type: 'png' });
        const implPath = path.join(
          this.outputDir,
          'comparisons',
          `impl-${path.basename(designShot.path)}`
        );
        await fs.writeFile(implPath, implementationBuffer);

        // Perform pixel comparison
        const designBuffer = await fs.readFile(designShot.path);
        const comparison = await this.compareImages(designBuffer, implementationBuffer);

        const diffPath = path.join(
          this.outputDir,
          'comparisons',
          `diff-${path.basename(designShot.path)}`
        );
        await fs.writeFile(diffPath, comparison.diffBuffer);

        comparisons.push({
          designPath: designShot.path,
          implementationPath: implPath,
          diffPath,
          similarity: comparison.similarity,
          differences: comparison.differences,
        });
      } catch (error) {
        console.error(`Failed to compare ${designShot.nodeName}:`, error);
      }
    }

    await this.browser.close();

    return comparisons;
  }

  private async compareImages(buffer1: Buffer, buffer2: Buffer): Promise<any> {
    const img1 = await Jimp.read(buffer1);
    const img2 = await Jimp.read(buffer2);

    // Ensure same dimensions
    const width = Math.min(img1.bitmap.width, img2.bitmap.width);
    const height = Math.min(img1.bitmap.height, img2.bitmap.height);

    img1.resize(width, height);
    img2.resize(width, height);

    const diff = new Jimp(width, height);
    const numDiffPixels = pixelmatch(
      img1.bitmap.data,
      img2.bitmap.data,
      diff.bitmap.data,
      width,
      height,
      { threshold: 0.1 }
    );

    const totalPixels = width * height;
    const similarity = 1 - (numDiffPixels / totalPixels);

    return {
      diffBuffer: await diff.getBufferAsync(Jimp.MIME_PNG),
      similarity,
      differences: numDiffPixels,
    };
  }

  private async createThumbnail(imageBuffer: Buffer, name: string): Promise<string> {
    const thumbnailPath = path.join(this.outputDir, 'thumbnails', `thumb-${this.sanitizeName(name)}.jpg`);

    await sharp(imageBuffer)
      .resize(200, 150, { fit: 'cover' })
      .jpeg({ quality: 80 })
      .toFile(thumbnailPath);

    return thumbnailPath;
  }

  private async generateVisualIndex(documentation: VisualDocumentation) {
    const htmlContent = this.generateHtmlIndex(documentation);
    const indexPath = path.join(this.outputDir, 'index.html');
    await fs.writeFile(indexPath, htmlContent);

    // Generate JSON index for programmatic access
    const jsonIndex = {
      generatedAt: new Date().toISOString(),
      statistics: {
        fullPages: documentation.fullPages.length,
        components: documentation.components.length,
        annotatedScreenshots: documentation.annotated.length,
        userFlows: documentation.flows.length,
        visualComparisons: documentation.comparisons.length,
      },
      documentation,
    };

    const jsonPath = path.join(this.outputDir, 'visual-index.json');
    await fs.writeFile(jsonPath, JSON.stringify(jsonIndex, null, 2));
  }

  private generateHtmlIndex(documentation: VisualDocumentation): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <title>Visual Documentation</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .section { margin-bottom: 40px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px; }
    .card { border: 1px solid #ddd; padding: 10px; border-radius: 8px; }
    .card img { width: 100%; height: auto; }
    .card h3 { margin: 10px 0 5px 0; font-size: 14px; }
    .stats { background: #f5f5f5; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
  </style>
</head>
<body>
  <h1>Figma Design Visual Documentation</h1>

  <div class="stats">
    <h2>Statistics</h2>
    <p>Full Pages: ${documentation.fullPages.length}</p>
    <p>Components: ${documentation.components.length}</p>
    <p>Annotated Screenshots: ${documentation.annotated.length}</p>
    <p>User Flows: ${documentation.flows.length}</p>
  </div>

  <div class="section">
    <h2>Full Page Designs</h2>
    <div class="grid">
      ${documentation.fullPages.map(page => `
        <div class="card">
          <img src="${path.relative(this.outputDir, page.path)}" alt="${page.nodeName}">
          <h3>${page.nodeName}</h3>
          <p>${page.viewport} - ${page.resolution}</p>
        </div>
      `).join('')}
    </div>
  </div>

  <div class="section">
    <h2>Components</h2>
    <div class="grid">
      ${documentation.components.map(comp => `
        <div class="card">
          ${comp.states[0] ? `<img src="${path.relative(this.outputDir, comp.states[0].thumbnail)}" alt="${comp.componentName}">` : ''}
          <h3>${comp.componentName}</h3>
          <p>Type: ${comp.componentType}</p>
          <p>States: ${comp.states.length}</p>
        </div>
      `).join('')}
    </div>
  </div>

  <div class="section">
    <h2>Annotated Screenshots</h2>
    <div class="grid">
      ${documentation.annotated.map(ann => `
        <div class="card">
          <img src="${path.relative(this.outputDir, ann.path)}" alt="Annotated ${ann.type}">
          <h3>Type: ${ann.type}</h3>
        </div>
      `).join('')}
    </div>
  </div>
</body>
</html>
    `;
  }

  private async getNodeImage(nodeId: string, format: string, scale: number): Promise<string | null> {
    try {
      const images = await this.client.getImages([nodeId], format, scale);
      return images[nodeId] || null;
    } catch (error) {
      console.error(`Failed to get image for node ${nodeId}:`, error);
      return null;
    }
  }

  private findFrames(node: FigmaNode): FigmaNode[] {
    const frames: FigmaNode[] = [];

    if (node.type === 'FRAME') {
      frames.push(node);
    }

    if (node.children) {
      for (const child of node.children) {
        frames.push(...this.findFrames(child));
      }
    }

    return frames;
  }

  private findComponents(node: FigmaNode): FigmaNode[] {
    const components: FigmaNode[] = [];

    if (node.type === 'COMPONENT' || node.type === 'COMPONENT_SET') {
      components.push(node);
    }

    if (node.children) {
      for (const child of node.children) {
        components.push(...this.findComponents(child));
      }
    }

    return components;
  }

  private detectViewport(frame: FigmaNode): string {
    if (!frame.absoluteBoundingBox) return 'custom';

    const width = frame.absoluteBoundingBox.width;

    if (width >= 1200) return 'desktop';
    if (width >= 768) return 'tablet';
    if (width < 768) return 'mobile';

    return 'custom';
  }

  private detectComponentType(component: FigmaNode): string {
    const name = component.name.toLowerCase();

    if (name.includes('button')) return 'button';
    if (name.includes('input')) return 'input';
    if (name.includes('card')) return 'card';
    if (name.includes('modal')) return 'modal';
    if (name.includes('nav')) return 'navigation';

    return 'component';
  }

  private extractState(variantName: string): string {
    const states = ['default', 'hover', 'active', 'focus', 'disabled'];

    for (const state of states) {
      if (variantName.toLowerCase().includes(state)) {
        return state;
      }
    }

    return 'default';
  }

  private findPrototypeFlows(node: FigmaNode): any[] {
    // Simplified prototype flow detection
    // In real implementation, would parse prototype interactions
    return [];
  }

  private createSpacingSvg(frame: FigmaNode, width: number, height: number): string {
    // Create SVG with spacing indicators
    return `
      <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="spacing" patternUnits="userSpaceOnUse" width="8" height="8">
            <rect width="1" height="8" fill="rgba(255,0,255,0.3)"/>
            <rect width="8" height="1" fill="rgba(255,0,255,0.3)"/>
          </pattern>
        </defs>
        <rect width="${width}" height="${height}" fill="url(#spacing)" opacity="0.3"/>
      </svg>
    `;
  }

  private createGridSvg(width: number, height: number): string {
    const gridSize = 8;
    return `
      <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="${gridSize}" height="${gridSize}" patternUnits="userSpaceOnUse">
            <path d="M ${gridSize} 0 L 0 0 0 ${gridSize}" fill="none" stroke="rgba(0,150,255,0.3)" stroke-width="1"/>
          </pattern>
        </defs>
        <rect width="${width}" height="${height}" fill="url(#grid)"/>
      </svg>
    `;
  }

  private createComponentBoundarySvg(frame: FigmaNode, width: number, height: number, scale: number): string {
    let boundaries = '';

    const addBoundary = (node: FigmaNode, color: string) => {
      if (node.absoluteBoundingBox && frame.absoluteBoundingBox) {
        const x = (node.absoluteBoundingBox.x - frame.absoluteBoundingBox.x) * scale;
        const y = (node.absoluteBoundingBox.y - frame.absoluteBoundingBox.y) * scale;
        const w = node.absoluteBoundingBox.width * scale;
        const h = node.absoluteBoundingBox.height * scale;

        boundaries += `
          <rect x="${x}" y="${y}" width="${w}" height="${h}"
                fill="none" stroke="${color}" stroke-width="2" stroke-dasharray="5,5"/>
          <text x="${x + 5}" y="${y - 5}" fill="${color}" font-size="12">${node.name}</text>
        `;
      }

      if (node.children) {
        node.children.forEach(child => addBoundary(child, color));
      }
    };

    frame.children?.forEach(child => {
      const color = child.type === 'COMPONENT' ? 'red' : 'blue';
      addBoundary(child, color);
    });

    return `
      <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
        ${boundaries}
      </svg>
    `;
  }

  private sanitizeName(name: string): string {
    return name.toLowerCase().replace(/[^a-z0-9-_]/g, '-').replace(/-+/g, '-');
  }
}