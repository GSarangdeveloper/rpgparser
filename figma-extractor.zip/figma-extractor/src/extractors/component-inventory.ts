import Fuse from 'fuse.js';
import { DetectedComponent, ComponentType, LibraryMatch } from '../../types/extraction.types.js';
import * as fs from 'fs/promises';
import * as path from 'path';

interface ComponentSearchResult {
  component: DetectedComponent;
  score: number;
  matches: SearchMatch[];
}

interface SearchMatch {
  field: string;
  value: string;
  matchType: 'exact' | 'fuzzy' | 'pattern';
}

interface ComponentCatalogEntry {
  id: string;
  name: string;
  type: ComponentType;
  subType?: string;
  libraryMappings: LibraryMapping[];
  properties: Record<string, any>;
  tags: string[];
  searchableText: string;
  instances: number;
  confidence: number;
}

interface LibraryMapping {
  library: string;
  component: string;
  importPath: string;
  confidence: number;
  propertyMapping: Record<string, string>;
  exampleCode?: string;
}

interface ComponentInventoryOutput {
  catalog: ComponentCatalogEntry[];
  byType: Record<ComponentType, ComponentCatalogEntry[]>;
  byLibrary: Record<string, ComponentCatalogEntry[]>;
  searchIndex: any;
  statistics: InventoryStatistics;
  gapAnalysis: GapAnalysisReport;
}

interface InventoryStatistics {
  totalComponents: number;
  uniqueTypes: number;
  libraryMatchRate: number;
  averageConfidence: number;
  mostUsedComponents: Array<{ name: string; count: number }>;
  complexityDistribution: Record<string, number>;
}

interface GapAnalysisReport {
  unmappedComponents: Array<{
    component: ComponentCatalogEntry;
    suggestedAlternatives: LibraryMapping[];
    implementationEffort: 'low' | 'medium' | 'high';
  }>;
  missingLibraryComponents: string[];
  customComponentsNeeded: number;
}

export class ComponentInventory {
  private components: DetectedComponent[] = [];
  private catalog: Map<string, ComponentCatalogEntry> = new Map();
  private searchIndex: Fuse<ComponentCatalogEntry> | null = null;
  private libraryRegistry: Map<string, LibraryMapping[]> = new Map();
  private outputDir: string;

  constructor(outputDir: string = './output/inventory') {
    this.outputDir = outputDir;
    this.initializeLibraryRegistry();
  }

  async build(components: DetectedComponent[]): Promise<ComponentInventoryOutput> {
    this.components = components;
    await this.ensureOutputDir();

    // Build catalog
    this.buildCatalog();

    // Create search index
    this.createSearchIndex();

    // Generate outputs
    const inventory = this.generateInventory();

    // Export various formats
    await this.exportInventory(inventory);

    return inventory;
  }

  private buildCatalog() {
    // Group similar components
    const componentGroups = this.groupSimilarComponents();

    for (const group of componentGroups) {
      const catalogEntry = this.createCatalogEntry(group);
      this.catalog.set(catalogEntry.id, catalogEntry);
    }
  }

  private groupSimilarComponents(): DetectedComponent[][] {
    const groups: DetectedComponent[][] = [];
    const processed = new Set<string>();

    for (const component of this.components) {
      if (processed.has(component.id)) continue;

      const similarComponents = this.findSimilarComponents(component);
      if (similarComponents.length > 0) {
        groups.push(similarComponents);
        similarComponents.forEach(c => processed.add(c.id));
      }
    }

    return groups;
  }

  private findSimilarComponents(target: DetectedComponent): DetectedComponent[] {
    const similar = [target];

    for (const component of this.components) {
      if (component.id === target.id) continue;

      const similarity = this.calculateSimilarity(target, component);
      if (similarity > 0.8) {
        similar.push(component);
      }
    }

    return similar;
  }

  private calculateSimilarity(comp1: DetectedComponent, comp2: DetectedComponent): number {
    let score = 0;
    let factors = 0;

    // Type match
    if (comp1.type === comp2.type) {
      score += 1;
      factors += 1;
    }

    // SubType match
    if (comp1.subType === comp2.subType) {
      score += 0.5;
      factors += 0.5;
    }

    // Name similarity
    const nameSimilarity = this.stringSimilarity(comp1.name, comp2.name);
    score += nameSimilarity * 0.3;
    factors += 0.3;

    // Property similarity
    const propSimilarity = this.propertySimilarity(comp1.properties, comp2.properties);
    score += propSimilarity * 0.2;
    factors += 0.2;

    return factors > 0 ? score / factors : 0;
  }

  private stringSimilarity(str1: string, str2: string): number {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;

    if (longer.length === 0) return 1.0;

    const editDistance = this.levenshteinDistance(longer, shorter);
    return (longer.length - editDistance) / longer.length;
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix: number[][] = [];

    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }

    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }

    return matrix[str2.length][str1.length];
  }

  private propertySimilarity(props1: any, props2: any): number {
    const keys1 = Object.keys(props1 || {});
    const keys2 = Object.keys(props2 || {});
    const allKeys = new Set([...keys1, ...keys2]);

    if (allKeys.size === 0) return 1;

    let matches = 0;
    for (const key of allKeys) {
      if (props1?.[key] === props2?.[key]) {
        matches++;
      }
    }

    return matches / allKeys.size;
  }

  private createCatalogEntry(components: DetectedComponent[]): ComponentCatalogEntry {
    const primary = components[0];
    const mergedLibraryMappings = this.mergeLibraryMappings(components);

    return {
      id: `catalog-${this.catalog.size + 1}`,
      name: this.generateCatalogName(primary),
      type: primary.type,
      subType: primary.subType,
      libraryMappings: mergedLibraryMappings,
      properties: this.mergeProperties(components),
      tags: this.generateTags(primary),
      searchableText: this.generateSearchableText(primary),
      instances: components.length,
      confidence: components.reduce((sum, c) => sum + c.confidence, 0) / components.length,
    };
  }

  private generateCatalogName(component: DetectedComponent): string {
    const parts: string[] = [];

    // Add library prefix if matched
    if (component.libraryMatches.length > 0) {
      const bestMatch = component.libraryMatches[0];
      if (bestMatch.library === '@angular/material') {
        parts.push('mat');
      } else if (bestMatch.library === 'primeng') {
        parts.push('p');
      }
    }

    // Add type
    parts.push(component.type.toLowerCase());

    // Add subtype
    if (component.subType) {
      parts.push(component.subType);
    }

    return parts.join('-');
  }

  private mergeLibraryMappings(components: DetectedComponent[]): LibraryMapping[] {
    const mappingMap = new Map<string, LibraryMapping>();

    for (const component of components) {
      for (const match of component.libraryMatches) {
        const key = `${match.library}-${match.component}`;

        if (!mappingMap.has(key)) {
          mappingMap.set(key, {
            library: match.library,
            component: match.component,
            importPath: match.importPath,
            confidence: match.confidence,
            propertyMapping: this.generatePropertyMapping(component, match),
            exampleCode: this.generateExampleCode(component, match),
          });
        } else {
          const existing = mappingMap.get(key)!;
          existing.confidence = Math.max(existing.confidence, match.confidence);
        }
      }
    }

    return Array.from(mappingMap.values()).sort((a, b) => b.confidence - a.confidence);
  }

  private generatePropertyMapping(component: DetectedComponent, match: LibraryMatch): Record<string, string> {
    const mapping: Record<string, string> = {};

    // Map common properties
    if (component.properties.label) {
      mapping['label'] = 'label';
    }
    if (component.properties.placeholder) {
      mapping['placeholder'] = 'placeholder';
    }
    if (component.properties.value) {
      mapping['value'] = 'ngModel';
    }
    if (component.properties.disabled) {
      mapping['disabled'] = 'disabled';
    }

    // Library-specific mappings
    if (match.library === '@angular/material') {
      if (component.properties.required) {
        mapping['required'] = 'required';
      }
      if (component.properties.color) {
        mapping['color'] = 'color';
      }
    }

    return mapping;
  }

  private generateExampleCode(component: DetectedComponent, match: LibraryMatch): string {
    if (match.library === '@angular/material') {
      switch (component.type) {
        case 'BUTTON':
          return `<button mat-raised-button color="primary">${component.properties.label || 'Button'}</button>`;
        case 'INPUT':
          return `<mat-form-field>
  <mat-label>${component.properties.label || 'Input'}</mat-label>
  <input matInput placeholder="${component.properties.placeholder || ''}" />
</mat-form-field>`;
        case 'CHECKBOX':
          return `<mat-checkbox>${component.properties.label || 'Checkbox'}</mat-checkbox>`;
        default:
          return '';
      }
    }
    return '';
  }

  private mergeProperties(components: DetectedComponent[]): Record<string, any> {
    const merged: Record<string, any> = {};

    for (const component of components) {
      Object.assign(merged, component.properties);
    }

    return merged;
  }

  private generateTags(component: DetectedComponent): string[] {
    const tags: string[] = [];

    // Add type tags
    tags.push(component.type.toLowerCase());
    if (component.subType) {
      tags.push(component.subType);
    }

    // Add property tags
    if (component.properties.required) tags.push('required');
    if (component.properties.disabled) tags.push('disabled');
    if (component.properties.size) tags.push(component.properties.size);

    // Add state tags
    component.states.forEach(state => tags.push(state.name));

    // Add library tags
    component.libraryMatches.forEach(match => {
      tags.push(match.library.replace('@', '').replace('/', '-'));
    });

    return [...new Set(tags)];
  }

  private generateSearchableText(component: DetectedComponent): string {
    const parts = [
      component.name,
      component.type,
      component.subType || '',
      component.properties.label || '',
      component.properties.placeholder || '',
      ...component.states.map(s => s.name),
      ...component.libraryMatches.map(m => m.component),
    ];

    return parts.filter(Boolean).join(' ').toLowerCase();
  }

  private createSearchIndex() {
    const catalogEntries = Array.from(this.catalog.values());

    this.searchIndex = new Fuse(catalogEntries, {
      keys: [
        { name: 'name', weight: 0.3 },
        { name: 'type', weight: 0.25 },
        { name: 'subType', weight: 0.15 },
        { name: 'tags', weight: 0.15 },
        { name: 'searchableText', weight: 0.15 },
      ],
      threshold: 0.4,
      includeScore: true,
      includeMatches: true,
    });
  }

  search(query: string, options: { limit?: number; type?: ComponentType } = {}): ComponentSearchResult[] {
    if (!this.searchIndex) return [];

    let results = this.searchIndex.search(query);

    // Filter by type if specified
    if (options.type) {
      results = results.filter(r => r.item.type === options.type);
    }

    // Limit results
    if (options.limit) {
      results = results.slice(0, options.limit);
    }

    return results.map(result => ({
      component: this.components.find(c => c.name === result.item.name)!,
      score: result.score || 0,
      matches: (result.matches || []).map(m => ({
        field: m.key || '',
        value: m.value || '',
        matchType: 'fuzzy' as const,
      })),
    }));
  }

  searchInLibrary(libraryName: string, componentType?: ComponentType): ComponentCatalogEntry[] {
    return Array.from(this.catalog.values()).filter(entry => {
      const hasLibrary = entry.libraryMappings.some(m => m.library === libraryName);
      const matchesType = !componentType || entry.type === componentType;
      return hasLibrary && matchesType;
    });
  }

  private generateInventory(): ComponentInventoryOutput {
    const catalogArray = Array.from(this.catalog.values());

    return {
      catalog: catalogArray,
      byType: this.groupByType(catalogArray),
      byLibrary: this.groupByLibrary(catalogArray),
      searchIndex: this.searchIndex,
      statistics: this.generateStatistics(catalogArray),
      gapAnalysis: this.performGapAnalysis(catalogArray),
    };
  }

  private groupByType(entries: ComponentCatalogEntry[]): Record<ComponentType, ComponentCatalogEntry[]> {
    const grouped: Partial<Record<ComponentType, ComponentCatalogEntry[]>> = {};

    for (const entry of entries) {
      if (!grouped[entry.type]) {
        grouped[entry.type] = [];
      }
      grouped[entry.type]!.push(entry);
    }

    return grouped as Record<ComponentType, ComponentCatalogEntry[]>;
  }

  private groupByLibrary(entries: ComponentCatalogEntry[]): Record<string, ComponentCatalogEntry[]> {
    const grouped: Record<string, ComponentCatalogEntry[]> = {};

    for (const entry of entries) {
      for (const mapping of entry.libraryMappings) {
        if (!grouped[mapping.library]) {
          grouped[mapping.library] = [];
        }
        grouped[mapping.library].push(entry);
      }
    }

    // Add unmapped components
    const unmapped = entries.filter(e => e.libraryMappings.length === 0);
    if (unmapped.length > 0) {
      grouped['unmapped'] = unmapped;
    }

    return grouped;
  }

  private generateStatistics(entries: ComponentCatalogEntry[]): InventoryStatistics {
    const componentCounts = new Map<string, number>();
    let totalConfidence = 0;
    let mappedComponents = 0;

    for (const entry of entries) {
      componentCounts.set(entry.name, (componentCounts.get(entry.name) || 0) + entry.instances);
      totalConfidence += entry.confidence;
      if (entry.libraryMappings.length > 0) {
        mappedComponents++;
      }
    }

    const mostUsed = Array.from(componentCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([name, count]) => ({ name, count }));

    return {
      totalComponents: this.components.length,
      uniqueTypes: new Set(entries.map(e => e.type)).size,
      libraryMatchRate: entries.length > 0 ? mappedComponents / entries.length : 0,
      averageConfidence: entries.length > 0 ? totalConfidence / entries.length : 0,
      mostUsedComponents: mostUsed,
      complexityDistribution: this.getComplexityDistribution(entries),
    };
  }

  private getComplexityDistribution(entries: ComponentCatalogEntry[]): Record<string, number> {
    const distribution = {
      simple: 0,
      moderate: 0,
      complex: 0,
    };

    for (const entry of entries) {
      const propCount = Object.keys(entry.properties).length;
      if (propCount <= 3) {
        distribution.simple++;
      } else if (propCount <= 6) {
        distribution.moderate++;
      } else {
        distribution.complex++;
      }
    }

    return distribution;
  }

  private performGapAnalysis(entries: ComponentCatalogEntry[]): GapAnalysisReport {
    const unmappedComponents = entries
      .filter(e => e.libraryMappings.length === 0)
      .map(component => ({
        component,
        suggestedAlternatives: this.suggestAlternatives(component),
        implementationEffort: this.estimateImplementationEffort(component),
      }));

    return {
      unmappedComponents,
      missingLibraryComponents: this.identifyMissingLibraryComponents(entries),
      customComponentsNeeded: unmappedComponents.filter(c => c.suggestedAlternatives.length === 0).length,
    };
  }

  private suggestAlternatives(component: ComponentCatalogEntry): LibraryMapping[] {
    const suggestions: LibraryMapping[] = [];
    const registry = this.libraryRegistry.get(component.type) || [];

    for (const mapping of registry) {
      const similarity = this.calculateMappingSimilarity(component, mapping);
      if (similarity > 0.5) {
        suggestions.push({
          ...mapping,
          confidence: similarity,
        });
      }
    }

    return suggestions.sort((a, b) => b.confidence - a.confidence).slice(0, 3);
  }

  private calculateMappingSimilarity(component: ComponentCatalogEntry, mapping: LibraryMapping): number {
    // Simplified similarity calculation
    return 0.6; // Would implement proper similarity logic
  }

  private estimateImplementationEffort(component: ComponentCatalogEntry): 'low' | 'medium' | 'high' {
    const propCount = Object.keys(component.properties).length;
    const hasComplexLogic = component.tags.includes('form') || component.tags.includes('table');

    if (propCount <= 3 && !hasComplexLogic) return 'low';
    if (propCount <= 6) return 'medium';
    return 'high';
  }

  private identifyMissingLibraryComponents(entries: ComponentCatalogEntry[]): string[] {
    const missing: string[] = [];

    // Check for common patterns not found in library
    const commonPatterns = ['date-range-picker', 'multi-select', 'file-upload', 'rich-text-editor'];

    for (const pattern of commonPatterns) {
      const found = entries.some(e =>
        e.name.toLowerCase().includes(pattern) ||
        e.searchableText.includes(pattern)
      );

      if (!found) {
        missing.push(pattern);
      }
    }

    return missing;
  }

  private async ensureOutputDir() {
    await fs.mkdir(this.outputDir, { recursive: true });
  }

  private async exportInventory(inventory: ComponentInventoryOutput) {
    // Export as JSON
    await this.exportAsJson(inventory);

    // Export as CSV
    await this.exportAsCsv(inventory);

    // Export as YAML
    await this.exportAsYaml(inventory);

    // Export as HTML catalog
    await this.exportAsHtml(inventory);

    // Export flat list
    await this.exportFlatList(inventory);
  }

  private async exportAsJson(inventory: ComponentInventoryOutput) {
    const jsonPath = path.join(this.outputDir, 'component-inventory.json');
    await fs.writeFile(jsonPath, JSON.stringify(inventory, null, 2));
  }

  private async exportAsCsv(inventory: ComponentInventoryOutput) {
    const csvContent = this.generateCsvContent(inventory.catalog);
    const csvPath = path.join(this.outputDir, 'component-inventory.csv');
    await fs.writeFile(csvPath, csvContent);
  }

  private generateCsvContent(entries: ComponentCatalogEntry[]): string {
    const headers = ['ID', 'Name', 'Type', 'SubType', 'Library', 'Component', 'Import Path', 'Instances', 'Confidence'];
    const rows = [headers.join(',')];

    for (const entry of entries) {
      if (entry.libraryMappings.length > 0) {
        for (const mapping of entry.libraryMappings) {
          rows.push([
            entry.id,
            entry.name,
            entry.type,
            entry.subType || '',
            mapping.library,
            mapping.component,
            mapping.importPath,
            entry.instances.toString(),
            entry.confidence.toFixed(2),
          ].join(','));
        }
      } else {
        rows.push([
          entry.id,
          entry.name,
          entry.type,
          entry.subType || '',
          'unmapped',
          '',
          '',
          entry.instances.toString(),
          entry.confidence.toFixed(2),
        ].join(','));
      }
    }

    return rows.join('\n');
  }

  private async exportAsYaml(inventory: ComponentInventoryOutput) {
    const yamlContent = this.generateYamlContent(inventory);
    const yamlPath = path.join(this.outputDir, 'component-inventory.yaml');
    await fs.writeFile(yamlPath, yamlContent);
  }

  private generateYamlContent(inventory: ComponentInventoryOutput): string {
    // Simple YAML generation (would use a proper YAML library in production)
    let yaml = 'component_inventory:\n';
    yaml += `  total_components: ${inventory.statistics.totalComponents}\n`;
    yaml += `  unique_types: ${inventory.statistics.uniqueTypes}\n`;
    yaml += `  library_match_rate: ${inventory.statistics.libraryMatchRate.toFixed(2)}\n`;
    yaml += '  components:\n';

    for (const entry of inventory.catalog) {
      yaml += `    - id: ${entry.id}\n`;
      yaml += `      name: ${entry.name}\n`;
      yaml += `      type: ${entry.type}\n`;
      if (entry.subType) {
        yaml += `      subType: ${entry.subType}\n`;
      }
      yaml += `      instances: ${entry.instances}\n`;
      yaml += `      confidence: ${entry.confidence.toFixed(2)}\n`;
    }

    return yaml;
  }

  private async exportAsHtml(inventory: ComponentInventoryOutput) {
    const htmlContent = this.generateHtmlCatalog(inventory);
    const htmlPath = path.join(this.outputDir, 'component-catalog.html');
    await fs.writeFile(htmlPath, htmlContent);
  }

  private generateHtmlCatalog(inventory: ComponentInventoryOutput): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <title>Component Inventory Catalog</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .stats { background: #f5f5f5; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
    th { background: #e0e0e0; }
    .confidence { font-weight: bold; }
    .high { color: green; }
    .medium { color: orange; }
    .low { color: red; }
    .unmapped { background: #fff3cd; }
    .search-box { padding: 10px; font-size: 16px; width: 300px; margin-bottom: 20px; }
  </style>
</head>
<body>
  <h1>Component Inventory Catalog</h1>

  <div class="stats">
    <h2>Statistics</h2>
    <p>Total Components Detected: <strong>${inventory.statistics.totalComponents}</strong></p>
    <p>Unique Component Types: <strong>${inventory.statistics.uniqueTypes}</strong></p>
    <p>Library Match Rate: <strong>${(inventory.statistics.libraryMatchRate * 100).toFixed(1)}%</strong></p>
    <p>Average Confidence: <strong>${(inventory.statistics.averageConfidence * 100).toFixed(1)}%</strong></p>
  </div>

  <h2>Component Catalog</h2>
  <input type="text" class="search-box" placeholder="Search components..." id="searchBox" />

  <table id="componentTable">
    <thead>
      <tr>
        <th>Name</th>
        <th>Type</th>
        <th>SubType</th>
        <th>Library</th>
        <th>Component</th>
        <th>Instances</th>
        <th>Confidence</th>
      </tr>
    </thead>
    <tbody>
      ${inventory.catalog.map(entry => {
        const mapping = entry.libraryMappings[0];
        const confidenceClass = entry.confidence > 0.8 ? 'high' : entry.confidence > 0.6 ? 'medium' : 'low';
        const rowClass = mapping ? '' : 'unmapped';

        return `
          <tr class="${rowClass}">
            <td>${entry.name}</td>
            <td>${entry.type}</td>
            <td>${entry.subType || '-'}</td>
            <td>${mapping?.library || 'unmapped'}</td>
            <td>${mapping?.component || '-'}</td>
            <td>${entry.instances}</td>
            <td class="confidence ${confidenceClass}">${(entry.confidence * 100).toFixed(1)}%</td>
          </tr>
        `;
      }).join('')}
    </tbody>
  </table>

  <script>
    document.getElementById('searchBox').addEventListener('input', function(e) {
      const searchTerm = e.target.value.toLowerCase();
      const rows = document.querySelectorAll('#componentTable tbody tr');

      rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
      });
    });
  </script>
</body>
</html>
    `;
  }

  private async exportFlatList(inventory: ComponentInventoryOutput) {
    const flatList = inventory.catalog.map(entry => {
      const mapping = entry.libraryMappings[0];
      return `${mapping?.library || 'custom'}:${entry.name} (${entry.instances} instances)`;
    }).join('\n');

    const flatPath = path.join(this.outputDir, 'component-list.txt');
    await fs.writeFile(flatPath, `DETECTED COMPONENTS:\n${flatList}`);
  }

  private initializeLibraryRegistry() {
    // Initialize with common Angular libraries
    this.libraryRegistry.set('BUTTON', [
      {
        library: '@angular/material',
        component: 'MatButton',
        importPath: '@angular/material/button',
        confidence: 0,
        propertyMapping: {},
      },
      {
        library: 'primeng',
        component: 'p-button',
        importPath: 'primeng/button',
        confidence: 0,
        propertyMapping: {},
      },
    ]);

    // Add more component mappings...
  }
}