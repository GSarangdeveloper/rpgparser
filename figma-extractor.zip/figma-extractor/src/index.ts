import { FigmaApiClient } from './api/figma-client.js';
import { EnhancedFigmaApiClient } from './api/enhanced-figma-client.js';
import { StructuralExtractor } from './extractors/structural-extractor.js';
import { StyleExtractor } from './extractors/style-extractor.js';
import { ComponentDetector } from './extractors/component-detector.js';
import { EnhancedComponentDetector } from './extractors/enhanced-component-detector.js';
import { AssetExtractor } from './extractors/asset-extractor.js';
import { VisualDocumenter } from './extractors/visual-documenter.js';
import { ComponentInventory } from './extractors/component-inventory.js';
import { TokenExtractor } from './extractors/token-extractor.js';
import { PerformanceManager, TemplateManager } from './utils/performance-manager.js';
import { FigmaTransformerUtil } from './utils/figma-transformer-util.js';
import { ExtractedData } from '../types/extraction.types.js';
import * as fs from 'fs/promises';
import * as path from 'path';
import chalk from 'chalk';
import ora from 'ora';

export interface ExtractionOptions {
  accessToken: string;
  fileKey: string;
  outputDir?: string;
  enableVisualDocs?: boolean;
  enableComponentSearch?: boolean;
  enableTokens?: boolean;
  enableAssets?: boolean;
  compareWithImplementation?: string;
  verbose?: boolean;
  useEnhanced?: boolean; // Use enhanced extraction with ML and design-lint patterns
}

export class FigmaExtractor {
  private client: FigmaApiClient | EnhancedFigmaApiClient;
  private options: ExtractionOptions;
  private outputDir: string;
  private useEnhanced: boolean;
  private performanceManager: PerformanceManager;
  private templateManager: TemplateManager;

  constructor(options: ExtractionOptions) {
    this.options = options;
    this.outputDir = options.outputDir || './output';
    this.useEnhanced = options.useEnhanced !== false; // Use enhanced by default

    // Use enhanced client by default for better extraction
    this.client = this.useEnhanced
      ? new EnhancedFigmaApiClient(options.accessToken, options.fileKey)
      : new FigmaApiClient(options.accessToken, options.fileKey);

    // Initialize performance and template managers
    this.performanceManager = new PerformanceManager();
    this.templateManager = new TemplateManager();
  }

  async extract(): Promise<ExtractedData> {
    console.log(chalk.cyan.bold('\n🎨 Figma Design Extractor\n'));

    const startTime = Date.now();
    let spinner: any = null;

    try {
      // Initialize output directory
      await this.initializeOutputDirectory();

      // Step 1: Fetch Figma file with caching
      spinner = ora('Fetching Figma file...').start();
      const fileData = await this.performanceManager.addToQueue(
        `file-${this.options.fileKey}`,
        async () => {
          return this.useEnhanced && this.client instanceof EnhancedFigmaApiClient
            ? await this.client.getEnhancedFile()
            : await this.client.getFile();
        },
        { cache: true, ttl: 300 } // Cache for 5 minutes
      );
      spinner.succeed('Figma file fetched successfully');

      // Transform data if enhanced mode
      let transformedData = fileData;
      if (this.useEnhanced) {
        spinner = ora('Transforming Figma data...').start();
        transformedData = FigmaTransformerUtil.transformNodeTree(fileData.document, {
          expandInstances: true,
          resolveStyles: true,
          optimizeProperties: true
        });
        spinner.succeed('Data transformation complete');
      }

      // Step 2: Extract structural data
      spinner = ora('Extracting structural data...').start();
      const structuralExtractor = new StructuralExtractor(fileData);
      const structure = structuralExtractor.extract();
      spinner.succeed(`Extracted ${structure.pages.length} pages, ${structure.frames.length} frames`);

      // Step 3: Extract styles
      spinner = ora('Extracting styles and visual properties...').start();
      const styleExtractor = new StyleExtractor();
      const styles = styleExtractor.extract(fileData.document);
      spinner.succeed(`Extracted ${styles.colors.length} colors, ${styles.typography.length} typography styles`);

      // Step 4: Detect components
      spinner = ora('Detecting UI components...').start();
      let detectedComponents;
      let stats;

      if (this.useEnhanced) {
        const enhancedDetector = new EnhancedComponentDetector();
        detectedComponents = await enhancedDetector.detectEnhanced(fileData.document);
        stats = enhancedDetector.getEnhancedStatistics();
        spinner.succeed(`Enhanced detection: ${detectedComponents.length} components with ${(stats.averageConfidence * 100).toFixed(1)}% average confidence`);
      } else {
        const componentDetector = new ComponentDetector();
        detectedComponents = componentDetector.detect(fileData.document);
        stats = componentDetector.getStatistics();
        spinner.succeed(`Detected ${detectedComponents.length} components with ${(stats.averageConfidence * 100).toFixed(1)}% average confidence`);
      }

      // Step 5: Extract assets (if enabled)
      let assets: any = { images: [], icons: [], fonts: [] };
      if (this.options.enableAssets !== false) {
        spinner = ora('Extracting assets...').start();
        const assetExtractor = new AssetExtractor(this.client, path.join(this.outputDir, 'assets'));
        assets = await assetExtractor.extract(fileData.document);
        await assetExtractor.generateAssetManifest();
        spinner.succeed(`Extracted ${assets.images.length} images, ${assets.icons.length} icons, ${assets.fonts.length} fonts`);
      }

      // Step 6: Generate visual documentation (if enabled)
      let visualDocs: any = null;
      if (this.options.enableVisualDocs) {
        spinner = ora('Generating visual documentation...').start();
        const visualDocumenter = new VisualDocumenter(this.client, path.join(this.outputDir, 'visual-docs'));
        visualDocs = await visualDocumenter.document(fileData.document, {
          compareWithImplementation: this.options.compareWithImplementation,
        });
        spinner.succeed('Visual documentation generated');
      }

      // Step 7: Build component inventory (if enabled)
      let componentInventory: any = null;
      if (this.options.enableComponentSearch !== false) {
        spinner = ora('Building searchable component inventory...').start();
        const inventory = new ComponentInventory(path.join(this.outputDir, 'inventory'));
        componentInventory = await inventory.build(detectedComponents);
        spinner.succeed(`Built searchable inventory with ${componentInventory.statistics.libraryMatchRate * 100}% library match rate`);
      }

      // Step 8: Extract design tokens (if enabled)
      let tokens: any = null;
      if (this.options.enableTokens !== false) {
        spinner = ora('Extracting design tokens...').start();
        const tokenExtractor = new TokenExtractor(path.join(this.outputDir, 'tokens'));
        tokens = await tokenExtractor.extract(styles);
        spinner.succeed(`Extracted ${tokens.colors.length} color tokens, ${tokens.typography.length} typography tokens`);
      }

      // Step 9: Compile metadata
      const metadata = {
        fileName: fileData.name,
        fileKey: this.options.fileKey,
        lastModified: fileData.lastModified,
        version: fileData.version,
        pages: structure.pages.length,
        nodes: structuralExtractor.getNodeStatistics(),
        components: detectedComponents.length,
        extractedAt: new Date().toISOString(),
        extractionDuration: Date.now() - startTime,
      };

      // Step 10: Create final output
      const extractedData: ExtractedData = {
        structure,
        styles,
        assets,
        components: {
          detected: detectedComponents,
          library: componentInventory?.catalog || [],
          patterns: [],
          inventory: componentInventory || {
            total: detectedComponents.length,
            byType: stats.byType,
            byLibrary: {},
            unmapped: [],
            statistics: {
              totalDetected: detectedComponents.length,
              uniqueTypes: Object.keys(stats.byType).length,
              libraryMatchRate: stats.libraryMatchRate,
              averageConfidence: stats.averageConfidence,
              mostUsed: { type: 'BUTTON', count: 0 },
              complexComponents: 0,
            },
          },
        },
        layout: {
          grids: [],
          breakpoints: [],
          constraints: [],
          autoLayout: [],
        },
        metadata,
        interactions: {
          prototypes: [],
          animations: [],
          flows: [],
        },
        tokens: tokens || {
          colors: [],
          typography: [],
          spacing: [],
          sizing: [],
          elevation: [],
          motion: [],
          breakpoints: [],
        },
      };

      // Save complete extracted data
      await this.saveExtractedData(extractedData);

      // Generate templates if enhanced mode
      if (this.useEnhanced) {
        await this.generateTemplates(extractedData);
      }

      // Generate summary report
      await this.generateSummaryReport(extractedData);

      // Show performance statistics
      if (this.options.verbose) {
        const stats = this.performanceManager.getStats();
        console.log(chalk.gray('\nPerformance Statistics:'));
        console.log(chalk.gray(`  Cache hits: ${stats.cache.hits}`));
        console.log(chalk.gray(`  Cache hit rate: ${(stats.cache.hitRate * 100).toFixed(1)}%`));
        console.log(chalk.gray(`  Queue completed: ${stats.queue.completed}`));
      }

      const duration = ((Date.now() - startTime) / 1000).toFixed(2);
      console.log(chalk.green.bold(`\n✅ Extraction completed successfully in ${duration}s`));
      console.log(chalk.gray(`Output saved to: ${this.outputDir}`));

      return extractedData;
    } catch (error) {
      if (spinner) spinner.fail('Extraction failed');
      console.error(chalk.red('Error during extraction:'), error);
      throw error;
    }
  }

  private async initializeOutputDirectory() {
    await fs.mkdir(this.outputDir, { recursive: true });

    const subdirs = [
      'raw',
      'assets',
      'visual-docs',
      'inventory',
      'tokens',
      'reports',
    ];

    for (const subdir of subdirs) {
      await fs.mkdir(path.join(this.outputDir, subdir), { recursive: true });
    }
  }

  private async saveExtractedData(data: ExtractedData) {
    // Save complete data as JSON
    const jsonPath = path.join(this.outputDir, 'raw', 'complete-extraction.json');
    await fs.writeFile(jsonPath, JSON.stringify(data, null, 2));

    // Save individual sections
    const sections = [
      { name: 'structure', data: data.structure },
      { name: 'styles', data: data.styles },
      { name: 'components', data: data.components },
      { name: 'assets', data: data.assets },
      { name: 'layout', data: data.layout },
      { name: 'tokens', data: data.tokens },
      { name: 'metadata', data: data.metadata },
    ];

    for (const section of sections) {
      const sectionPath = path.join(this.outputDir, 'raw', `${section.name}.json`);
      await fs.writeFile(sectionPath, JSON.stringify(section.data, null, 2));
    }
  }

  private async generateTemplates(data: ExtractedData) {
    const templatesDir = path.join(this.outputDir, 'templates');
    await fs.mkdir(templatesDir, { recursive: true });

    // Generate Angular components for detected components
    const angularDir = path.join(templatesDir, 'angular');
    await fs.mkdir(angularDir, { recursive: true });

    for (const component of data.components.detected.slice(0, 10)) { // Limit to first 10
      const angularCode = this.templateManager.generateAngularComponent(component);
      const fileName = `${component.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}.component.ts`;
      await fs.writeFile(path.join(angularDir, fileName), angularCode);
    }

    // Generate inventory HTML
    const inventoryHtml = this.templateManager.generateInventoryHTML(data.components.detected);
    await fs.writeFile(path.join(templatesDir, 'inventory.html'), inventoryHtml);

    // Generate SCSS tokens
    const tokensSCSS = this.templateManager.generateTokensSCSS(data.tokens);
    await fs.writeFile(path.join(templatesDir, 'tokens.scss'), tokensSCSS);

    console.log(chalk.gray(`  Generated templates in ${templatesDir}`));
  }

  private async generateSummaryReport(data: ExtractedData) {
    const report = `
# Figma Extraction Report

Generated: ${new Date().toISOString()}
File: ${data.metadata.fileName}

## Summary

- **Pages**: ${data.structure.pages.length}
- **Frames**: ${data.structure.frames.length}
- **Components Detected**: ${data.components.detected.length}
- **Colors**: ${data.styles.colors.length}
- **Typography Styles**: ${data.styles.typography.length}
- **Images**: ${data.assets.images.length}
- **Icons**: ${data.assets.icons.length}

## Component Statistics

- **Average Confidence**: ${(data.components.inventory.statistics.averageConfidence * 100).toFixed(1)}%
- **Library Match Rate**: ${(data.components.inventory.statistics.libraryMatchRate * 100).toFixed(1)}%
- **Unique Types**: ${data.components.inventory.statistics.uniqueTypes}

## Component Types Detected

${Object.entries(data.components.inventory.byType)
  .map(([type, count]) => `- ${type}: ${count}`)
  .join('\n')}

## Design Tokens

- **Color Tokens**: ${data.tokens.colors.length}
- **Typography Tokens**: ${data.tokens.typography.length}
- **Spacing Tokens**: ${data.tokens.spacing.length}
- **Elevation Tokens**: ${data.tokens.elevation.length}

## Output Files

- \`raw/\`: Complete extracted data in JSON format
- \`assets/\`: Extracted images, icons, and fonts
- \`inventory/\`: Searchable component catalog
- \`tokens/\`: Design tokens in various formats
- \`visual-docs/\`: Visual documentation and screenshots
`;

    const reportPath = path.join(this.outputDir, 'reports', 'extraction-summary.md');
    await fs.writeFile(reportPath, report);

    // Also generate HTML report
    const htmlReport = this.generateHtmlReport(data);
    const htmlPath = path.join(this.outputDir, 'reports', 'extraction-summary.html');
    await fs.writeFile(htmlPath, htmlReport);
  }

  private generateHtmlReport(data: ExtractedData): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <title>Figma Extraction Report</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
      background: #f5f5f5;
    }
    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      border-radius: 10px;
      margin-bottom: 30px;
    }
    .header h1 {
      margin: 0;
      font-size: 2.5em;
    }
    .header p {
      margin: 10px 0 0 0;
      opacity: 0.9;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    .card {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .card h3 {
      margin-top: 0;
      color: #667eea;
    }
    .stat {
      font-size: 2em;
      font-weight: bold;
      color: #333;
    }
    .label {
      color: #666;
      font-size: 0.9em;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .progress {
      height: 20px;
      background: #e0e0e0;
      border-radius: 10px;
      overflow: hidden;
      margin: 10px 0;
    }
    .progress-bar {
      height: 100%;
      background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
      border-radius: 10px;
      transition: width 0.3s;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }
    th, td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #e0e0e0;
    }
    th {
      background: #f5f5f5;
      font-weight: 600;
    }
    .section {
      background: white;
      padding: 25px;
      border-radius: 8px;
      margin-bottom: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .section h2 {
      margin-top: 0;
      color: #333;
      border-bottom: 2px solid #667eea;
      padding-bottom: 10px;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>🎨 Figma Extraction Report</h1>
    <p>${data.metadata.fileName} - Extracted on ${new Date().toLocaleDateString()}</p>
  </div>

  <div class="grid">
    <div class="card">
      <div class="label">Pages</div>
      <div class="stat">${data.structure.pages.length}</div>
    </div>
    <div class="card">
      <div class="label">Frames</div>
      <div class="stat">${data.structure.frames.length}</div>
    </div>
    <div class="card">
      <div class="label">Components</div>
      <div class="stat">${data.components.detected.length}</div>
    </div>
    <div class="card">
      <div class="label">Colors</div>
      <div class="stat">${data.styles.colors.length}</div>
    </div>
    <div class="card">
      <div class="label">Typography</div>
      <div class="stat">${data.styles.typography.length}</div>
    </div>
    <div class="card">
      <div class="label">Assets</div>
      <div class="stat">${data.assets.images.length + data.assets.icons.length}</div>
    </div>
  </div>

  <div class="section">
    <h2>Component Analysis</h2>
    <div class="grid">
      <div class="card">
        <h3>Detection Confidence</h3>
        <div class="progress">
          <div class="progress-bar" style="width: ${data.components.inventory.statistics.averageConfidence * 100}%"></div>
        </div>
        <p>${(data.components.inventory.statistics.averageConfidence * 100).toFixed(1)}% Average</p>
      </div>
      <div class="card">
        <h3>Library Match Rate</h3>
        <div class="progress">
          <div class="progress-bar" style="width: ${data.components.inventory.statistics.libraryMatchRate * 100}%"></div>
        </div>
        <p>${(data.components.inventory.statistics.libraryMatchRate * 100).toFixed(1)}% Matched</p>
      </div>
    </div>

    <h3>Component Types</h3>
    <table>
      <thead>
        <tr>
          <th>Type</th>
          <th>Count</th>
          <th>Percentage</th>
        </tr>
      </thead>
      <tbody>
        ${Object.entries(data.components.inventory.byType)
          .map(([type, count]) => `
            <tr>
              <td>${type}</td>
              <td>${count}</td>
              <td>${((count as any / data.components.detected.length) * 100).toFixed(1)}%</td>
            </tr>
          `).join('')}
      </tbody>
    </table>
  </div>

  <div class="section">
    <h2>Design System Tokens</h2>
    <div class="grid">
      <div class="card">
        <h3>Color Palette</h3>
        <div style="display: flex; flex-wrap: wrap; gap: 5px; margin-top: 10px;">
          ${data.tokens.colors.slice(0, 12).map(color => `
            <div style="width: 30px; height: 30px; background: ${color.value}; border-radius: 4px; border: 1px solid #ddd;" title="${color.name}"></div>
          `).join('')}
        </div>
        <p style="margin-top: 10px; color: #666; font-size: 0.9em;">${data.tokens.colors.length} total colors</p>
      </div>
      <div class="card">
        <h3>Typography Scale</h3>
        <p>${data.tokens.typography.length} text styles</p>
        <p style="color: #666; font-size: 0.9em;">
          ${data.tokens.typography.map(t => t.name).slice(0, 5).join(', ')}...
        </p>
      </div>
      <div class="card">
        <h3>Spacing System</h3>
        <p>${data.tokens.spacing.length} spacing values</p>
        <p style="color: #666; font-size: 0.9em;">
          Base unit: 8px
        </p>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>Extraction Metadata</h2>
    <table>
      <tr>
        <td><strong>File Key</strong></td>
        <td>${data.metadata.fileKey}</td>
      </tr>
      <tr>
        <td><strong>Last Modified</strong></td>
        <td>${data.metadata.lastModified}</td>
      </tr>
      <tr>
        <td><strong>Version</strong></td>
        <td>${data.metadata.version}</td>
      </tr>
      <tr>
        <td><strong>Extraction Duration</strong></td>
        <td>${(data.metadata.extractionDuration / 1000).toFixed(2)} seconds</td>
      </tr>
    </table>
  </div>
</body>
</html>
    `;
  }
}

export * from '../types/figma.types.js';
export * from '../types/extraction.types.js';