# Figma Design Extractor

A comprehensive tool for extracting complete design data from Figma files, specifically tailored for Angular application development. This tool provides 100% extraction of visual design information, component detection, design tokens, and searchable component inventory.

## 🚀 What This Tool Does

**Input:** Figma file URL or file key
**Output:** Complete design system extraction including components, assets, tokens, and visual documentation

This tool takes your Figma design file and extracts:
- ✅ **Complete component list** with classification (buttons, forms, tables, cards, etc.)
- ✅ **Design tokens** (colors, typography, spacing, shadows)
- ✅ **Visual assets** (images, icons, fonts)
- ✅ **Component mappings** to Angular Material, PrimeNG, and custom libraries
- ✅ **Visual documentation** with screenshots and annotations
- ✅ **Searchable inventory** of all detected components

## Features

### 🎨 Complete Design Extraction
- **Structural Data**: Pages, frames, component hierarchy
- **Visual Properties**: Colors, typography, effects, spacing
- **Component Detection**: AI-powered detection of UI components with library mapping
- **Asset Extraction**: Images, icons, fonts with optimization
- **Design Tokens**: Automatic token generation for design systems
- **Visual Documentation**: Screenshots, annotations, and visual comparisons

### 🔍 Searchable Component Inventory
- Detect and classify UI components (buttons, inputs, tables, etc.)
- Map to Angular Material, PrimeNG, and custom libraries
- Export in multiple formats (JSON, CSV, HTML)
- Search and filter capabilities

### 📸 Visual Documentation
- Full page screenshots at multiple resolutions
- Component-level captures with states
- Annotated screenshots (spacing, grids, boundaries)
- Visual regression testing

### 🎯 Design Tokens
- Color palettes with semantic mapping
- Typography scales
- Spacing systems
- Elevation/shadow definitions
- Motion tokens
- Breakpoints

## Installation

```bash
# Clone and install locally
git clone https://github.com/your-org/figma-extractor
cd figma-extractor
npm install
npm run build
```

## 🎯 Quick Start - How to Run

### 1. Get Figma Access Token

1. Go to [Figma Account Settings](https://www.figma.com/settings)
2. Generate a personal access token
3. Copy the token

### 2. Get Figma File Key

The file key is in your Figma file URL:
`https://www.figma.com/file/[FILE_KEY]/[FILE_NAME]`

### 3. Initialize Project

```bash
npx figma-extract init
```

### 4. Configure Environment

Edit `.env` file:
```env
FIGMA_ACCESS_TOKEN=your-token-here
FIGMA_FILE_KEY=your-file-key-here
```

### 5. Run Extraction

```bash
# Using npm scripts
npm run extract

# Or using tsx directly
npm run dev

# Or build and run
npm run build
node dist/cli.js extract
```

## 📋 Complete Usage Guide

### CLI Commands

```bash
# Basic extraction (extracts everything including component list)
npm run extract

# Or using the built tool
node dist/cli.js extract

# Full extraction with visual documentation
node dist/cli.js extract --visual-docs --compare http://localhost:4200

# Search components after extraction
node dist/cli.js search "button primary" --type BUTTON

# Analyze extracted data
node dist/cli.js analyze ./output
```

### 📦 What Gets Extracted (Outputs)

The tool provides multiple outputs in the `output/` directory:

### Programmatic Usage

```typescript
import { FigmaExtractor } from 'figma-extractor';

const extractor = new FigmaExtractor({
  accessToken: 'your-token',
  fileKey: 'your-file-key',
  outputDir: './output',
  enableVisualDocs: true,
  enableComponentSearch: true,
  enableTokens: true,
  enableAssets: true,
});

const data = await extractor.extract();

// Access extracted data
console.log(`Detected ${data.components.detected.length} components`);
console.log(`Extracted ${data.tokens.colors.length} color tokens`);
```

## 📂 Output Structure - What You Get

```
output/
├── raw/                    # Complete extracted data
│   ├── complete-extraction.json    # ALL Figma data
│   ├── structure.json              # Page & frame hierarchy
│   ├── styles.json                 # All styles from Figma
│   ├── components.json             # 🎯 COMPONENT LIST - All detected components
│   └── tokens.json                 # Design tokens
├── assets/                 # Extracted assets
│   ├── images/            # All images from designs
│   ├── icons/             # SVG icons extracted
│   └── fonts/             # Font files if available
├── visual-docs/           # Visual documentation
│   ├── full-designs/      # Complete page screenshots
│   ├── components/        # Individual component screenshots
│   ├── annotated/         # Screenshots with annotations
│   └── flows/             # User flow visualizations
├── inventory/             # 🎯 SEARCHABLE COMPONENT INVENTORY
│   ├── component-inventory.json    # JSON format component list
│   ├── component-inventory.csv     # CSV format for Excel/Sheets
│   └── component-catalog.html      # Visual HTML catalog
├── tokens/               # Design tokens for development
│   ├── tokens.json       # Raw token data
│   ├── tokens.css        # CSS variables
│   ├── tokens.scss       # SCSS variables
│   └── tokens.ts         # TypeScript constants
└── reports/             # Summary reports
    ├── extraction-summary.md       # Markdown report
    └── extraction-summary.html     # HTML report with visuals
```

### 🎯 Key Outputs Explained

1. **components.json** - Contains the complete list of detected UI components with:
   - Component type (button, input, table, card, etc.)
   - Component properties and styles
   - Location in the Figma file
   - Confidence scores for detection

2. **component-inventory.json** - Enhanced searchable component database with:
   - Library mappings (Angular Material, PrimeNG, etc.)
   - Usage statistics
   - Component variants and states
   - Search metadata

3. **component-catalog.html** - Visual catalog you can open in a browser to:
   - See all components visually
   - Filter by type
   - View component properties
   - Export component data

## 📊 Component Detection - Yes, It Extracts Component Lists!

The tool automatically detects and classifies ALL UI components in your Figma file:

### Form Components
- Text Input, Textarea, Select/Dropdown
- Checkbox, Radio Button, Toggle/Switch
- Slider, Date Picker, Time Picker
- File Upload

### Data Display
- Table, List, Card
- Accordion, Tree View

### Navigation
- Navigation Bar, Sidebar
- Tabs, Breadcrumb
- Pagination, Stepper

### Feedback
- Modal, Tooltip, Alert
- Badge, Chip
- Progress, Spinner

## Library Mapping

Automatically maps detected components to:
- **Angular Material** (`@angular/material`)
- **PrimeNG** (`primeng`)
- **Custom Enterprise Libraries**
- **Third-party libraries**

## Design Tokens

Generated tokens include:

### Colors
- Semantic colors (primary, secondary, error, warning, success)
- Color palettes with shades
- CSS variables and SCSS variables

### Typography
- Font families and weights
- Type scale (xs to 5xl)
- Line heights and letter spacing

### Spacing
- Base unit system (8px grid)
- Spacing scale (0-64)

### Elevation
- Material Design elevation levels
- Box shadow definitions

## Advanced Features

### Visual Comparison

Compare Figma designs with live implementation:

```bash
figma-extract extract --visual-docs --compare http://localhost:4200
```

### Component Search

Search extracted components:

```typescript
const inventory = new ComponentInventory('./output/inventory');
const results = inventory.search('button primary', {
  limit: 5,
  type: 'BUTTON'
});
```

### Custom Detection Rules

Add custom component detection:

```typescript
const detector = new ComponentDetector();
// Add custom rules
const components = detector.detect(figmaNode);
```

## API Reference

### FigmaExtractor

```typescript
class FigmaExtractor {
  constructor(options: ExtractionOptions)
  extract(): Promise<ExtractedData>
}
```

### ExtractionOptions

```typescript
interface ExtractionOptions {
  accessToken: string;
  fileKey: string;
  outputDir?: string;
  enableVisualDocs?: boolean;
  enableComponentSearch?: boolean;
  enableTokens?: boolean;
  enableAssets?: boolean;
  compareWithImplementation?: string;
  verbose?: boolean;
}
```

## 🔄 Complete Workflow Example

```bash
# Step 1: Setup
cd figma-extractor
npm install

# Step 2: Configure
echo "FIGMA_ACCESS_TOKEN=your-token" > .env
echo "FIGMA_FILE_KEY=your-file-key" >> .env

# Step 3: Run extraction
npm run extract

# Step 4: View results
# Open output/component-catalog.html in browser to see all components
# Check output/raw/components.json for component list
# Check output/inventory/component-inventory.json for searchable database
```

## Examples

See the `example/` directory for detailed usage examples:

- Basic extraction
- Full extraction with all features
- Component search
- Design token usage
- Visual comparison workflow
- Batch processing

## Integration with Angular

### Using Extracted Components

```typescript
// Load component mappings
import mappings from './output/inventory/component-inventory.json';

// Generate Angular components
mappings.catalog.forEach(component => {
  if (component.libraryMappings.length > 0) {
    const mapping = component.libraryMappings[0];
    // Use mapping.importPath and mapping.component
  }
});
```

### Using Design Tokens

```scss
// Import generated tokens
@import './output/tokens/tokens.scss';

// Use in your styles
.primary-button {
  background-color: $color-primary;
  padding: $spacing-2;
  font-size: $font-size-text-base;
}
```

## Performance

- Handles large Figma files efficiently
- Parallel processing for assets
- Optimized image generation
- Caching for repeated operations

## Limitations

- Requires Figma API access (Professional plan or above)
- Rate limits apply (see Figma API documentation)
- Large files may take several minutes to process
- Some advanced Figma features may not be fully supported

## Contributing

Contributions are welcome! Please read our contributing guidelines.

## License

MIT

## Support

For issues and questions:
- GitHub Issues: [Report an issue](https://github.com/your-org/figma-extractor/issues)
- Documentation: [Full documentation](https://docs.your-org.com/figma-extractor)

## Acknowledgments

Built with:
- Figma API
- Sharp (image processing)
- SVGO (SVG optimization)
- Style Dictionary (design tokens)
- Puppeteer (visual documentation)
- Fuse.js (fuzzy search)