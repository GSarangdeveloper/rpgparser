"""
Batch processing script for multiple Excel files
"""

import os
import glob
from excel_processor import ExcelProcessor
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def process_batch(input_folder, output_folder, rules_dir='rules'):
    """
    Process all Excel files in a folder
    
    Args:
        input_folder: Path to folder containing Excel files
        output_folder: Path to folder for output files
        rules_dir: Path to rules directory
    """
    
    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)
    
    # Create processor
    processor = ExcelProcessor()
    processor.load_all_rules(rules_dir)
    
    # Find all Excel files
    excel_files = glob.glob(os.path.join(input_folder, '*.xlsx')) + \
                  glob.glob(os.path.join(input_folder, '*.xls'))
    
    logger.info(f"Found {len(excel_files)} Excel files to process")
    
    # Process each file
    for input_file in excel_files:
        try:
            filename = os.path.basename(input_file)
            output_file = os.path.join(output_folder, f"processed_{filename}")
            
            logger.info(f"Processing: {filename}")
            results = processor.process_excel_file(input_file)
            processor.save_results(results, output_file)
            
            # Log summary
            summary = processor.get_processing_summary(results)
            logger.info(f"Completed: {filename} - {summary['sheets_processed']} sheets processed")
            
        except Exception as e:
            logger.error(f"Error processing {filename}: {str(e)}")
            continue
    
    logger.info("Batch processing completed!")

if __name__ == "__main__":
    # Example usage
    process_batch(
        input_folder="input_files",
        output_folder="output_files",
        rules_dir="rules"
    )