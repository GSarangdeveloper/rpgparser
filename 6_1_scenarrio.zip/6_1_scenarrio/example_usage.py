"""
Example of how to use the Excel processor directly in Python
"""

from excel_processor import ExcelProcessor
import pandas as pd

# Create processor instance
processor = ExcelProcessor()

# Load rules from JSON files
processor.load_all_rules('rules')

# Or load rules programmatically
from rule_engine import RuleEngine
from data_enricher import DataEnricher
from base_scenario import BaseScenario

# Example: Load scenario rules for a specific sheet
scenario_rules = {
    "sheet_name_in_excel": "Member Cost Share",
    "columns_to_extract": ["PlanID", "Copay Category", "Pharmacy Network"],
    "default_scenario": "UNMAPPED",
    "default_rule_id": "NO_MATCH",
    "rules": [
        {
            "RuleID": "RULE001",
            "Priority": 1,
            "IsEnabled": True,
            "ScenarioIdentification": "Test Scenario",
            "conditions": {
                "Copay Category": "Drug Specific",
                "Pharmacy Network": "_NONBLANK_"
            }
        }
    ]
}

processor.rule_engine.load_rules_from_dict("Member Cost Share", scenario_rules)

# Process a single Excel file
input_file = "path/to/your/input.xlsx"
output_file = "path/to/your/output.xlsx"

# Process the file
results = processor.process_excel_file(input_file)

# Save results
processor.save_results(results, output_file)

# Or work with the results directly
for sheet_name, df in results.items():
    print(f"\nSheet: {sheet_name}")
    print(f"Rows: {len(df)}")
    if 'Scenario Identification' in df.columns:
        print(f"Unique scenarios: {df['Scenario Identification'].unique()}")

# Get processing summary
summary = processor.get_processing_summary(results)
print(f"\nTotal sheets processed: {summary['sheets_processed']}")

# Access individual DataFrames
member_cost_share_df = results.get('Member Cost Share')
if member_cost_share_df is not None:
    # Work with the processed data
    print(member_cost_share_df.head())