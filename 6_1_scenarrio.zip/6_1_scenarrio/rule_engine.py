import pandas as pd
import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class Rule:
    """Represents a single business rule"""
    rule_id: str
    priority: int
    is_enabled: bool
    scenario_identification: str
    conditions: Dict[str, str]
    
    def matches(self, row: pd.Series) -> bool:
        """Check if a row matches this rule's conditions"""
        if not self.is_enabled:
            return False
            
        for column, expected_value in self.conditions.items():
            if column not in row.index:
                logger.warning(f"Column '{column}' not found in data for rule {self.rule_id}")
                return False
                
            actual_value = row[column]
            
            # Handle special keywords
            if expected_value == "_BLANK_":
                if pd.notna(actual_value) and str(actual_value).strip() != "":
                    return False
            elif expected_value == "_NONBLANK_":
                if pd.isna(actual_value) or str(actual_value).strip() == "":
                    return False
            else:
                # Direct value comparison
                if str(actual_value) != str(expected_value):
                    return False
                    
        return True

class RuleEngine:
    """Main rule engine for processing Excel data"""
    
    def __init__(self):
        self.rules_cache: Dict[str, List[Rule]] = {}
        
    def load_rules(self, rules_file_path: str) -> None:
        """Load rules from JSON file"""
        try:
            with open(rules_file_path, 'r') as f:
                rules_data = json.load(f)
                
            sheet_name = rules_data.get('sheet_name_in_excel', 'Unknown')
            rules = []
            
            for rule_data in rules_data.get('rules', []):
                rule = Rule(
                    rule_id=rule_data['RuleID'],
                    priority=rule_data['Priority'],
                    is_enabled=rule_data['IsEnabled'],
                    scenario_identification=rule_data['ScenarioIdentification'],
                    conditions=rule_data['conditions']
                )
                rules.append(rule)
                
            # Sort rules by priority (ascending)
            rules.sort(key=lambda r: r.priority)
            self.rules_cache[sheet_name] = rules
            
            logger.info(f"Loaded {len(rules)} rules for sheet '{sheet_name}'")
            
        except Exception as e:
            logger.error(f"Error loading rules from {rules_file_path}: {str(e)}")
            raise
            
    def load_rules_from_dict(self, sheet_name: str, rules_data: Dict) -> None:
        """Load rules from dictionary (for Streamlit UI)"""
        rules = []
        
        for rule_data in rules_data.get('rules', []):
            rule = Rule(
                rule_id=rule_data['RuleID'],
                priority=rule_data['Priority'],
                is_enabled=rule_data['IsEnabled'],
                scenario_identification=rule_data['ScenarioIdentification'],
                conditions=rule_data['conditions']
            )
            rules.append(rule)
            
        # Sort rules by priority (ascending)
        rules.sort(key=lambda r: r.priority)
        self.rules_cache[sheet_name] = rules
        
    def process_sheet(self, df: pd.DataFrame, sheet_name: str, 
                     default_scenario: str = "UNMAPPED_SCENARIO",
                     default_rule_id: str = "NO_MATCH") -> pd.DataFrame:
        """Process a DataFrame and add Scenario Identification and MatchedRuleID columns"""
        
        if sheet_name not in self.rules_cache:
            logger.warning(f"No rules found for sheet '{sheet_name}'")
            df['Scenario Identification'] = default_scenario
            df['MatchedRuleID'] = default_rule_id
            return df
            
        rules = self.rules_cache[sheet_name]
        scenario_identifications = []
        matched_rule_ids = []
        
        for index, row in df.iterrows():
            matched = False
            
            for rule in rules:
                if rule.matches(row):
                    scenario_identifications.append(rule.scenario_identification)
                    matched_rule_ids.append(rule.rule_id)
                    matched = True
                    break
                    
            if not matched:
                scenario_identifications.append(default_scenario)
                matched_rule_ids.append(default_rule_id)
                
        df['Scenario Identification'] = scenario_identifications
        df['MatchedRuleID'] = matched_rule_ids
        
        return df
        
    def get_rules_summary(self, sheet_name: str) -> Dict[str, Any]:
        """Get summary of rules for a sheet"""
        if sheet_name not in self.rules_cache:
            return {"sheet_name": sheet_name, "rule_count": 0, "rules": []}
            
        rules = self.rules_cache[sheet_name]
        return {
            "sheet_name": sheet_name,
            "rule_count": len(rules),
            "enabled_count": sum(1 for r in rules if r.is_enabled),
            "rules": [
                {
                    "rule_id": r.rule_id,
                    "priority": r.priority,
                    "is_enabled": r.is_enabled,
                    "scenario": r.scenario_identification,
                    "conditions_count": len(r.conditions)
                }
                for r in rules
            ]
        }