import pandas as pd
import json
from typing import Dict, List, Any
import logging

logger = logging.getLogger(__name__)

class BaseScenario:
    """Handles Step 3: Base scenario expansion"""
    
    def __init__(self):
        self.expansion_rules = {}
        
    def load_expansion_rules(self, rules_file_path: str) -> None:
        """Load expansion rules from JSON file"""
        try:
            with open(rules_file_path, 'r') as f:
                self.expansion_rules = json.load(f)
            logger.info(f"Loaded expansion rules for {len(self.expansion_rules)} sheets")
        except Exception as e:
            logger.error(f"Error loading expansion rules: {str(e)}")
            raise
            
    def load_expansion_rules_from_dict(self, rules: Dict) -> None:
        """Load expansion rules from dictionary (for Streamlit UI)"""
        self.expansion_rules = rules
        
    def expand_scenarios(self, enriched_df: pd.DataFrame, sheet_name: str) -> pd.DataFrame:
        """Expand scenarios based on Scenario Identification tag"""
        
        if sheet_name not in self.expansion_rules:
            logger.warning(f"No expansion rules found for sheet '{sheet_name}'")
            # Add default columns
            enriched_df['Base Scenario'] = 'NO_EXPANSION_RULE'
            enriched_df['Expected Status'] = ''
            return enriched_df
            
        sheet_expansion_rules = self.expansion_rules[sheet_name]
        new_rows_list = []
        
        for idx, row in enriched_df.iterrows():
            scenario_tag = row.get('Scenario Identification', '')
            
            if scenario_tag in sheet_expansion_rules:
                expansion_rule = sheet_expansion_rules[scenario_tag]
                base_scenarios = expansion_rule.get('base_scenarios', [])
                expected_status = expansion_rule.get('expected_status', 'P')
                
                # Create a row for each base scenario
                for base_scenario in base_scenarios:
                    new_row = row.copy()
                    new_row['Base Scenario'] = base_scenario
                    new_row['Expected Status'] = expected_status
                    new_rows_list.append(new_row)
            else:
                # No expansion rule found - add original row with defaults
                new_row = row.copy()
                new_row['Base Scenario'] = 'NO_EXPANSION_RULE'
                new_row['Expected Status'] = ''
                new_rows_list.append(new_row)
                
        # Create new DataFrame from expanded rows
        if new_rows_list:
            final_df = pd.DataFrame(new_rows_list)
            return final_df
        else:
            # Return original with default columns
            enriched_df['Base Scenario'] = 'NO_EXPANSION_RULE'
            enriched_df['Expected Status'] = ''
            return enriched_df
            
    def get_expansion_summary(self, sheet_name: str) -> Dict[str, Any]:
        """Get summary of expansion rules for a sheet"""
        if sheet_name not in self.expansion_rules:
            return {"sheet_name": sheet_name, "rule_count": 0, "scenarios": []}
            
        sheet_rules = self.expansion_rules[sheet_name]
        return {
            "sheet_name": sheet_name,
            "rule_count": len(sheet_rules),
            "scenarios": [
                {
                    "scenario_identification": scenario,
                    "base_scenarios": rule.get('base_scenarios', []),
                    "expected_status": rule.get('expected_status', '')
                }
                for scenario, rule in sheet_rules.items()
            ]
        }