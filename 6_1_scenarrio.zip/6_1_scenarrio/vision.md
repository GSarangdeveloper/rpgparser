High-Level Development Prompt: Step 1 - Scenario Identification Generation

Objective:
Develop Step 1 of an application to process multi-sheet Excel files, automatically generating a "Scenario Identification" and "MatchedRuleID" for each relevant row based on externally managed, dynamic business rules defined in JSON.

Input Data:

Input will be Excel files (.xlsx), each potentially containing approximately 29 distinct "functional area" sheets plus a "Plan Detail" sheet. The "Plan Detail" sheet may provide common configuration data or values that can be referenced during rule evaluation for other sheets.
Each functional area sheet has a variable number of rows (e.g., ~1000 rows) and its own unique set of columns.
Core Functionality of Step 1:

For each designated functional area sheet within an uploaded Excel file:
Load the sheet's data. The specific columns relevant for rule processing and to be carried forward will be defined in the external rule configuration for that sheet (columns_to_extract).
Access and apply the set of predefined business rules (from an external JSON file) specific to that sheet type.
For each data row, determine the appropriate "Scenario Identification" string and the corresponding "MatchedRuleID" based on the first matching rule (by priority).
Add these two new columns (Scenario Identification, MatchedRuleID) to the dataset for that sheet.
Rule Management System:

External JSON Rule Definition: Business rules will be stored as JSON files, external to the application's deployment package, to allow updates without redeploying the application.
Rule File Structure: A dedicated JSON rule file (e.g., MemberCostShare_Rules.json) will exist for each functional area sheet type.
Storage: These JSON rule files will be stored in a central, external location (e.g., S3, Azure Blob Storage, a shared network drive) accessible by the application.
JSON Content: Each rule JSON file will contain:
Metadata like sheet_name_in_excel (for reference).
A columns_to_extract array listing the column names from the data sheet that are essential for rule evaluation and/or should be part of the processed output.
Default scenario/rule ID for the sheet if no rules match.
An array of rules, where each rule object specifies RuleID, Priority, IsEnabled, ScenarioIdentification, and a conditions object (key-value pairs of data column name and expected value/keyword like _BLANK_, _NONBLANK_).
Rule Loading: The application will load and parse these external JSON rule files at startup or periodically, caching them for efficient use.
Output of Step 1 (to become Input for Step 2):

For each processed sheet from an input Excel file, the output will be an in-memory Pandas DataFrame.
This DataFrame will contain:
All original columns and data from the input sheet (or at least those specified in columns_to_extract plus any others deemed necessary).
The two newly generated columns: Scenario Identification and MatchedRuleID.
This collection of processed DataFrames will be passed directly to Step 2 within the same microservice.
Technical Context & Non-Functional Requirements:

Microservice Architecture: Step 1 is a component within a larger microservice.
Event-Driven: Processing of an input Excel file will be initiated by a message from a Kafka topic.
Modularity & Maintainability: The solution for Step 1 should be modular and maintainable.
Rule Updatability: Changes to the external JSON rule files should be picked up by the application without requiring a code deployment.
Business Rules in JSON Format: MemberCostShare_Rules.json Example

This JSON file defines the rules and necessary configuration for the "Member Cost Share" sheet.

JSON

{
  "sheet_name_in_excel": "Member Cost Share",
  "columns_to_extract": [
    "PlanID",
    "Copay Category",
    "Pharmacy Network",
    "Drug List",
    "Delivery System",
    "Copay Tier",
    "Copay Step",
    "Copay Max Days Supply",
    "Copay Amount - Flat Dollar",
    "Copay Amount - Percent",
    "Copay Minimum",
    "Copay Maximum",
    "Copay Calculation"
  ],
  "default_scenario": "MCS_UNMAPPED_SCENARIO",
  "default_rule_id": "MCS_NO_MATCH",
  "rules": [
    {
      "RuleID": "MCS001",
      "Priority": 1,
      "IsEnabled": true,
      "ScenarioIdentification": "DC_Flat Copay, Extended Cycle",
      "conditions": {
        "Copay Category": "Drug Specific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS002",
      "Priority": 2,
      "IsEnabled": true,
      "ScenarioIdentification": "DC_Flat Coinsurance, Extended Cycle",
      "conditions": {
        "Copay Category": "Drug Specific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS003",
      "Priority": 3,
      "IsEnabled": true,
      "ScenarioIdentification": "DC_Coinsurance with Min, Extended Cycle",
      "conditions": {
        "Copay Category": "Drug Specific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "Higher Of"
      }
    },
    {
      "RuleID": "MCS004",
      "Priority": 4,
      "IsEnabled": true,
      "ScenarioIdentification": "DC_Greater of or Extended Cycle",
      "conditions": {
        "Copay Category": "Drug Specific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "Greater Of"
      }
    },
    {
      "RuleID": "MCS005",
      "Priority": 5,
      "IsEnabled": true,
      "ScenarioIdentification": "DC_Lower cost extended Cycle",
      "conditions": {
        "Copay Category": "Drug Specific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "Lower Of"
      }
    },
    {
      "RuleID": "MCS006",
      "Priority": 6,
      "IsEnabled": true,
      "ScenarioIdentification": "DC_Coninsurance with Min Max, Extended Cycle",
      "conditions": {
        "Copay Category": "Drug Specific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS007",
      "Priority": 7,
      "IsEnabled": true,
      "ScenarioIdentification": "PS_Flat Copay",
      "conditions": {
        "Copay Category": "Government_PharmacySpecific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_NONBLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "Higher Of"
      }
    },
    {
      "RuleID": "MCS008",
      "Priority": 8,
      "IsEnabled": true,
      "ScenarioIdentification": "PS_Flat Coinsurance",
      "conditions": {
        "Copay Category": "Government_PharmacySpecific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_NONBLANK_", 
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS009",
      "Priority": 9,
      "IsEnabled": true,
      "ScenarioIdentification": "PS_Coinsurance then Copay",
      "conditions": {
        "Copay Category": "Government_PharmacySpecific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS010",
      "Priority": 10,
      "IsEnabled": true,
      "ScenarioIdentification": "PS_Coinsurance with Max",
      "conditions": {
        "Copay Category": "Government_PharmacySpecific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS011",
      "Priority": 11,
      "IsEnabled": true,
      "ScenarioIdentification": "PS_Coninsurance with Min",
      "conditions": {
        "Copay Category": "Government_PharmacySpecific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS012",
      "Priority": 12,
      "IsEnabled": true,
      "ScenarioIdentification": "PS_Coninsurance with Min Max",
      "conditions": {
        "Copay Category": "Government_PharmacySpecific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS013",
      "Priority": 13,
      "IsEnabled": true,
      "ScenarioIdentification": "PS_Flat Copay",
      "conditions": {
        "Copay Category": "Government_PharmacySpecific",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_BLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_", 
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS014",
      "Priority": 14,
      "IsEnabled": true,
      "ScenarioIdentification": "PP_Flat Coinsurance",
      "conditions": {
        "Copay Category": "Plan",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_NONBLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS015",
      "Priority": 15,
      "IsEnabled": true,
      "ScenarioIdentification": "PP_Coinsurance with Min Max",
      "conditions": {
        "Copay Category": "Plan",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_NONBLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS016",
      "Priority": 16,
      "IsEnabled": true,
      "ScenarioIdentification": "PP_Greater Of",
      "conditions": {
        "Copay Category": "Plan",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_NONBLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS017",
      "Priority": 17,
      "IsEnabled": true,
      "ScenarioIdentification": "PP_Coinsurance with Max",
      "conditions": {
        "Copay Category": "Plan",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_NONBLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "Higher Of"
      }
    },
    {
      "RuleID": "MCS018",
      "Priority": 18,
      "IsEnabled": true,
      "ScenarioIdentification": "PP_Lower Of",
      "conditions": {
        "Copay Category": "Plan",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_NONBLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "Lower Of"
      }
    },
    {
      "RuleID": "MCS019",
      "Priority": 19,
      "IsEnabled": true,
      "ScenarioIdentification": "PP_Coninsurance with Min Max",
      "conditions": {
        "Copay Category": "Plan",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_NONBLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS020",
      "Priority": 20,
      "IsEnabled": true,
      "ScenarioIdentification": "PP_Copay then Coinsurance",
      "conditions": {
        "Copay Category": "Plan",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_NONBLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "_BLANK_"
      }
    },
    {
      "RuleID": "MCS021",
      "Priority": 21,
      "IsEnabled": true,
      "ScenarioIdentification": "PP_Coinsurance then Copay",
      "conditions": {
        "Copay Category": "Plan",
        "Delivery System": "_NONBLANK_",
        "Pharmacy Network": "_NONBLANK_",
        "Drug List": "_NONBLANK_",
        "Copay Amount - Flat Dollar": "_NONBLANK_",
        "Copay Amount - Percent": "_NONBLANK_",
        "Copay Minimum": "_BLANK_",
        "Copay Maximum": "_BLANK_",
        "Copay Calculation": "% then Copay"
      }
    }
  ]
}
Important Notes on the JSON Rules:

Column Names in conditions: These keys (e.g., "Copay Category", "Copay Amount - Flat Dollar") MUST EXACTLY match the column names present in your input data sheet (and as listed in columns_to_extract). I have used the mapped names like "Copay Amount - Flat Dollar" instead of "Flat Dollar".
Conflicting Conditions: As with the Excel example, rules MCS001, MCS002, MCS006 have identical conditions. Similarly for several "Government_PharmacySpecific" and "Plan" rules where Copay Calculation is _BLANK_. You must resolve these conflicts by either making their conditions distinct or ensuring the Priority correctly reflects which rule should fire. The system will apply the first matching rule based on ascending Priority.
Keywords: The keywords _NONBLANK_ and _BLANK_ are used as string values. Your Python rule engine will need to interpret these specifically.
Extensibility: This JSON structure can be extended later. For example, the conditions values could become objects themselves to support more operators like "greater_than", "in_list", etc., e.g., "Copay Minimum": {"operator": "greater_than", "value": 0}. For now, it uses simple key-value matching.



Recap: Output of Step 1 (Input to Step 2)

For each processed functional area sheet from the input Excel, Step 1 produces an in-memory Pandas DataFrame. This DataFrame contains:

All original columns and data from that sheet.
A new column: Scenario Identification (e.g., "PP_CoinsuranceWithMinMax").
A new column: MatchedRuleID (e.g., "MCS015").
The "Plan Detail" sheet is also available as a separate Pandas DataFrame.

Development Plan for Step 2: Data Enrichment
Goal: Update specific columns in the functional area DataFrames if their current values are blank or match certain placeholders (like "9999"), using corresponding values from the "Plan Detail" sheet. The logic for which "Plan Detail" column to use can be conditional.

1. Rule Definition & Storage (External JSON Configuration)

We'll define enrichment rules in an external JSON file (e.g., enrichment_rules.json). This file will be loaded by the microservice at startup or periodically.

Structure of enrichment_rules.json:
An array of rule objects. Each object defines an enrichment task for a specific column in a specific sheet (or could apply to multiple sheets if source_sheet_name is a list or uses wildcards, though your example is specific).

JSON

[
  {
    "rule_id": "ENRICH_MCS_COPAY_MAX_DAYS", // Unique ID for this enrichment rule
    "source_sheet_name": "Member Cost Share",
    "target_column_to_update": "Copay Max Days Supply",
    "join_details": { // How to link source sheet to reference sheet
      "source_column": "PlanID",
      "reference_sheet_name": "Plan Detail", // This is constant as per your requirement
      "reference_column": "PlanID"
    },
    "update_condition": { // When to update the target_column_to_update
      "type": "is_blank_or_specific_values", // Other types: "is_blank", "is_specific_values"
      "values_to_match": ["", " ", "9999", "nulll", null, "™"] // List of values that trigger update
                                                          // Note: "nulll" and "™" from your example. Convert null string to actual None/NaN in parsing.
    },
    "lookup_logic": { // How to find the new value in the 'Plan Detail' sheet
      "conditional_rules": [ // Evaluated in order; first match wins
        {
          "condition_on_source_field": "Delivery System", // Field in the source_sheet_name row
          "operator": "contains_ignore_case", // Other ops: "equals_ignore_case", "startswith_ignore_case"
          "value_to_check": "mail",
          "use_plan_detail_field": "Mail Max Days Supply" // Column in 'Plan Detail'
        },
        {
          "condition_on_source_field": "Delivery System",
          "operator": "contains_ignore_case",
          "value_to_check": "paper",
          "use_plan_detail_field": "All Paper Max Days Supply",
          "fallback_plan_detail_field": "Retail Max Day Supply" // Optional: if primary lookup is blank in Plan Detail
        }
        // Add more conditional rules as needed
      ],
      "default_plan_detail_field": "Retail Max Day Supply" // Mandatory: fallback if no conditional rules match
                                                          // or if their lookups (including fallbacks) are blank.
    }
  }
  // ... other enrichment rules for other columns or other sheets
]
2. Application Logic (Python - within your microservice)

Create a module, say data_enricher.py.

load_enrichment_rules(filepath): Function to load and parse enrichment_rules.json.
enrich_sheet_data(data_df, plan_detail_df, sheet_enrichment_rules):
Input:
data_df: DataFrame for the functional area sheet (output of Step 1).
plan_detail_df: DataFrame for the "Plan Detail" sheet.
sheet_enrichment_rules: List of parsed enrichment rule objects applicable to the current data_df.
Process:
For each rule in sheet_enrichment_rules: a. Identify rows needing update: * Select rows in data_df where rule['target_column_to_update'] is blank or matches any value in rule['update_condition']['values_to_match']. Handle null, empty strings, and specific placeholders correctly. Pandas isin() combined with isna() can be useful. b. If no rows need updating for this rule, continue to the next rule. c. Prepare for lookup: For the rows identified, you'll need to find corresponding values in plan_detail_df. It's efficient to perform a left merge of the relevant subset of data_df (or all of it, if easier) with plan_detail_df using the join_details. python # Example merge (conceptual, might do this once if multiple rules use Plan Detail) # merged_df = pd.merge( # data_df_subset_to_update, # plan_detail_df, # left_on=rule['join_details']['source_column'], # right_on=rule['join_details']['reference_column'], # how='left', # suffixes=('', '_plan_detail') # To avoid column name clashes # ) d. Apply lookup logic for each row to update: * Iterate through merged_df (or the identified rows in data_df by index, performing lookups into plan_detail_df based on the join key for each row). * For each row, evaluate rule['lookup_logic']['conditional_rules'] in order. * If a conditional rule matches (based on condition_on_source_field, operator, value_to_check): * The value comes from plan_detail_df[conditional_rule['use_plan_detail_field']]. * If that's blank and fallback_plan_detail_field exists, use that from plan_detail_df. * If no conditional rule yields a non-blank value, use plan_detail_df[rule['lookup_logic']['default_plan_detail_field']]. * If the final chosen lookup value from plan_detail_df is not blank/null, update data_df.loc[row_index, rule['target_column_to_update']] with this new value.
Output: The modified data_df.
Development Plan for Step 3: Base Scenario Expansion
Goal: Based on the Scenario Identification tag (from Step 1, carried through Step 2), expand each row into one or more "base scenario" rows, adding Base Scenario and Expected Status columns.

1. Rule Definition & Storage (External JSON Configuration)

Define expansion rules in an external JSON file (e.g., expansion_rules.json), loaded at startup.

Structure of expansion_rules.json:
A dictionary where keys are sheet names. Each value is a dictionary where keys are Scenario Identification tags.

JSON

{
  "Member Cost Share": {
    "DC_Flat Copay, Extended Cycle": {
      "base_scenarios": ["Verify_Copay"],
      "expected_status": "P"
    },
    "DC_Flat Coinsurance, Extended Cycle": {
      "base_scenarios": ["Verify_Coinsurance"],
      "expected_status": "P"
    },
    "DC_Coinsurance with Min, Extended Cycle": {
      "base_scenarios": ["Verify_Coinsurance", "Verify_Min Copay"],
      "expected_status": "P"
    },
    "DC_Coinsurance with Min Max, Extended Cycle": {
      "base_scenarios": ["Verify_Coinsurance", "Verify_Min Copay", "Verify_Max Copay"],
      "expected_status": "P"
    }
    // ... all other 21 rules for Member Cost Share from your example
  }
  // ... rules for other sheets
}
2. Application Logic (Python - within your microservice)

Create a module, say scenario_expander.py.

load_expansion_rules(filepath): Function to load and parse expansion_rules.json.
expand_scenarios(enriched_df, sheet_expansion_rules_map):
Input:
enriched_df: DataFrame for the functional area sheet (output of Step 2).
sheet_expansion_rules_map: The parsed expansion rule map for the current sheet (e.g., the value for "Member Cost Share" from the loaded JSON).
Process:
Initialize an empty list new_rows_list.
Iterate through each index, row in enriched_df.iterrows(): a. Get the scenario_tag = row['Scenario Identification']. b. Look up expansion_rule = sheet_expansion_rules_map.get(scenario_tag). c. If expansion_rule is found: * For each base_name in expansion_rule['base_scenarios']: * Create a copy of the current row (as a dictionary or Pandas Series). * Add Base Scenario = base_name to the copy. * Add Expected Status = expansion_rule['expected_status'] to the copy. * Append the modified copy to new_rows_list. d. Else (no expansion rule for this scenario tag): * Option 1 (Default behavior): Add the original row as is, perhaps with default/blank "Base Scenario" and "Expected Status", or log a warning. * Option 2 (Strict): Skip the row or raise an error if all scenarios are expected to have expansion rules. * For now, let's assume if no rule is found, we can add the original row with blank/default values for the new columns or a special "NO_EXPANSION_RULE" Base Scenario.
If new_rows_list is not empty, create a new DataFrame: final_df = pd.DataFrame(new_rows_list).
Else, return the original enriched_df (perhaps with the new columns added with default values).
Output: The new final_df with expanded rows and the two new columns.
Overall Microservice Flow Update:

Python

# --- At Microservice Startup ---
# scenario_rules_cache = load_step1_rules()
# enrichment_rules_cache = load_step2_enrichment_rules('enrichment_rules.json')
# expansion_rules_cache = load_step3_expansion_rules('expansion_rules.json')

# --- For Each Kafka Message ---
# ... load input_excel_data, extract plan_detail_df ...

# --- STEP 1 (as before) ---
# processed_sheets_step1 = run_step1(all_sheets_data_step0, scenario_rules_cache)

# --- STEP 2 ---
processed_sheets_step2 = {}
for sheet_name, df_step1 in processed_sheets_step1.items():
    rules_for_sheet_enrich = enrichment_rules_cache.get(sheet_name, []) # Get list of enrichment rules for this sheet
    df_step2_output = data_enricher.enrich_sheet_data(df_step1, plan_detail_df, rules_for_sheet_enrich)
    processed_sheets_step2[sheet_name] = df_step2_output

# --- STEP 3 ---
final_output_sheets = {}
for sheet_name, df_step2 in processed_sheets_step2.items():
    rules_for_sheet_expand = expansion_rules_cache.get(sheet_name, {}) # Get expansion map for this sheet
    df_step3_output = scenario_expander.expand_scenarios(df_step2, rules_for_sheet_expand)
    final_output_sheets[sheet_name] = df_step3_output

# Now, final_output_sheets contains the DataFrames after all three steps.
# This data can be outputted as needed (e.g., written to a database, new Excel files, Parquet, etc.).
This plan ensures that the logic for both Step 2 and Step 3 is driven by external JSON configurations, meeting your requirements for scalability and low-code updates (by modifying the JSON files). The Python code will focus on robustly parsing these configurations and applying the defined logic.

