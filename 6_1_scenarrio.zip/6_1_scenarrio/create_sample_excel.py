"""
Create a sample Excel file for testing with specific header and data row positions
"""

import pandas as pd
import openpyxl
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows

def create_formatted_excel():
    # Create a new workbook
    wb = Workbook()
    
    # Remove default sheet
    wb.remove(wb.active)
    
    # Create Member Cost Share sheet
    ws_mcs = wb.create_sheet("Member Cost Share")
    
    # Add some header rows before the actual column headers
    ws_mcs['A1'] = "Member Cost Share Report"
    ws_mcs['A2'] = "Generated Date: 2024-01-01"
    # Row 3 (index 2) will have column headers
    # Row 4 will be empty
    # Row 5 (index 4) will start the data
    
    # Create sample Member Cost Share data
    member_cost_share_data = {
        'PlanID': ['PLAN001', 'PLAN001', 'PLAN002', 'PLAN002', 'PLAN003'],
        'Copay Category': ['Drug Specific', 'Drug Specific', 'Government_PharmacySpecific', 'Plan', 'Plan'],
        'Pharmacy Network': ['Network A', 'Network B', 'Network A', 'Network C', ''],
        'Drug List': ['List 1', 'List 2', 'List 1', 'List 3', 'List 1'],
        'Delivery System': ['Mail', 'Paper', 'Retail', 'Mail', 'Retail'],
        'Copay Tier': ['Tier 1', 'Tier 2', 'Tier 1', 'Tier 3', 'Tier 2'],
        'Copay Step': ['Step 1', 'Step 1', 'Step 2', 'Step 1', 'Step 2'],
        'Copay Max Days Supply': ['', '9999', '30', '', '90'],
        'Copay Amount - Flat Dollar': ['', '', '10', '25', '15'],
        'Copay Amount - Percent': ['20', '25', '', '30', '20'],
        'Copay Minimum': ['', '', '5', '', '10'],
        'Copay Maximum': ['', '', '50', '100', '75'],
        'Copay Calculation': ['', 'Higher Of', '', 'Lower Of', '']
    }
    
    df_mcs = pd.DataFrame(member_cost_share_data)
    
    # Write headers at row 3
    for c_idx, column in enumerate(df_mcs.columns, 1):
        ws_mcs.cell(row=3, column=c_idx, value=column)
    
    # Write data starting at row 5
    for r_idx, row in enumerate(dataframe_to_rows(df_mcs, index=False, header=False), 5):
        for c_idx, value in enumerate(row, 1):
            ws_mcs.cell(row=r_idx, column=c_idx, value=value)
    
    # Create Plan Detail sheet
    ws_pd = wb.create_sheet("Plan Detail")
    
    # Add header rows
    ws_pd['A1'] = "Plan Detail Information"
    ws_pd['A2'] = "Version: 1.0"
    ws_pd['A3'] = "Last Updated: 2024-01-01"
    # Row 4 (index 3) will have column headers
    # Row 5 will be empty
    # Row 6 (index 5) will start the data
    
    # Create sample Plan Detail data
    plan_detail_data = {
        'PlanID': ['PLAN001', 'PLAN002', 'PLAN003'],
        'Plan Name': ['Basic Plan', 'Standard Plan', 'Premium Plan'],
        'Mail Max Days Supply': ['90', '90', '90'],
        'All Paper Max Days Supply': ['30', '45', '60'],
        'Retail Max Day Supply': ['30', '30', '30'],
        'Plan Type': ['HMO', 'PPO', 'EPO']
    }
    
    df_pd = pd.DataFrame(plan_detail_data)
    
    # Write headers at row 4
    for c_idx, column in enumerate(df_pd.columns, 1):
        ws_pd.cell(row=4, column=c_idx, value=column)
    
    # Write data starting at row 6
    for r_idx, row in enumerate(dataframe_to_rows(df_pd, index=False, header=False), 6):
        for c_idx, value in enumerate(row, 1):
            ws_pd.cell(row=r_idx, column=c_idx, value=value)
    
    # Create Additional Info sheet (standard format)
    ws_ai = wb.create_sheet("Additional Info")
    
    additional_sheet_data = {
        'PlanID': ['PLAN001', 'PLAN002', 'PLAN003'],
        'Coverage Type': ['Medical', 'Medical', 'Medical'],
        'Deductible': [1000, 500, 250],
        'Out of Pocket Max': [5000, 3000, 2000]
    }
    
    df_ai = pd.DataFrame(additional_sheet_data)
    
    # Standard format - headers at row 1, data at row 2
    for r in dataframe_to_rows(df_ai, index=False, header=True):
        ws_ai.append(r)
    
    # Save the workbook
    wb.save('sample_input_formatted.xlsx')
    
    print("Sample Excel file 'sample_input_formatted.xlsx' created successfully!")
    print("\nSheets included:")
    print("1. Member Cost Share - Headers at row 3, data starts at row 5")
    print("2. Plan Detail - Headers at row 4, data starts at row 6")
    print("3. Additional Info - Standard format (headers at row 1)")
    print("\nThis file matches the exact format expected by the system.")

if __name__ == "__main__":
    create_formatted_excel()