# Rule Management System

A Python-based application for processing multi-sheet Excel files with dynamic business rules management through a Streamlit interface.

## Features

- **Step 1: Scenario Identification** - Automatically tag rows with scenario identifications based on business rules
- **Step 2: Data Enrichment** - Enrich data using Plan Detail sheet based on conditional lookup rules
- **Step 3: Scenario Expansion** - Expand scenarios into base scenarios with expected status
- **Streamlit UI** - User-friendly interface for managing all rules
- **JSON-based Rule Storage** - External rule management without code deployment
- **Flexible Sheet Layout** - Support for Excel sheets with headers and data at custom row positions

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

## Running the Application

Start the Streamlit app:
```bash
streamlit run streamlit_app.py
```

## Application Structure

- `rule_engine.py` - Core rule engine for scenario identification (Step 1)
- `data_enricher.py` - Data enrichment logic (Step 2)
- `base_scenario.py` - Base scenario expansion logic (Step 3)
- `excel_processor.py` - Main processor orchestrating all steps
- `streamlit_app.py` - Web interface for rule management
- `rules/` - Directory containing JSON rule files

## Using the Application

### 1. Dashboard
View system overview and load example rules

### 2. Scenario Rules
- Define rules for scenario identification
- Set conditions using special keywords:
  - `_BLANK_` - Matches empty/null values
  - `_NONBLANK_` - Matches non-empty values
- Manage rule priorities (lower number = higher priority)

### 3. Enrichment Rules
- Configure data enrichment from Plan Detail sheet
- Set conditional lookup logic
- Define fallback fields

### 4. Expansion Rules
- Map scenario identifications to base scenarios
- Set expected status for each scenario

### 5. Process Excel
- Upload Excel file for processing
- Download processed results with added columns:
  - Scenario Identification
  - MatchedRuleID
  - Base Scenario
  - Expected Status

### 6. Test Rules
- Create test data
- Validate rules before processing actual files

## Rule File Structure

### Sheet Configuration (JSON)
```json
{
  "Member Cost Share": {
    "header_row": 2,
    "data_start_row": 4,
    "description": "Headers at row 3, data starts at row 5"
  },
  "Plan Detail": {
    "header_row": 3,
    "data_start_row": 5,
    "description": "Headers at row 4, data starts at row 6"
  }
}
```

### Scenario Rules (JSON)
```json
{
  "sheet_name_in_excel": "Sheet Name",
  "sheet_config": {
    "header_row": 2,
    "data_start_row": 4
  },
  "columns_to_extract": ["Column1", "Column2"],
  "default_scenario": "UNMAPPED_SCENARIO",
  "default_rule_id": "NO_MATCH",
  "rules": [
    {
      "RuleID": "RULE001",
      "Priority": 1,
      "IsEnabled": true,
      "ScenarioIdentification": "Scenario Name",
      "conditions": {
        "Column1": "Value",
        "Column2": "_NONBLANK_"
      }
    }
  ]
}
```

### Enrichment Rules (JSON)
```json
[
  {
    "rule_id": "ENRICH001",
    "source_sheet_name": "Sheet Name",
    "target_column_to_update": "Column Name",
    "join_details": {
      "source_column": "PlanID",
      "reference_sheet_name": "Plan Detail",
      "reference_column": "PlanID"
    },
    "update_condition": {
      "type": "is_blank_or_specific_values",
      "values_to_match": ["", "9999", "null"]
    },
    "lookup_logic": {
      "conditional_rules": [...],
      "default_plan_detail_field": "Default Column"
    }
  }
]
```

### Expansion Rules (JSON)
```json
{
  "Sheet Name": {
    "Scenario Identification": {
      "base_scenarios": ["Base1", "Base2"],
      "expected_status": "P"
    }
  }
}
```

## How to Process Excel Files

### Method 1: Web Interface (Recommended)
1. Start the Streamlit app: `streamlit run streamlit_app.py`
2. Navigate to "Process Excel" page
3. Upload your Excel file
4. Click "Process File"
5. Download the processed results

### Method 2: Command Line
```bash
# Process a single file
python process_excel_cli.py input.xlsx output.xlsx

# With custom rules directory
python process_excel_cli.py input.xlsx output.xlsx --rules-dir custom_rules

# With summary output
python process_excel_cli.py input.xlsx output.xlsx --summary
```

### Method 3: Batch Processing
```python
# Process all Excel files in a folder
python batch_process.py
```

### Method 4: Python Script
```python
from excel_processor import ExcelProcessor

processor = ExcelProcessor()
processor.load_all_rules('rules')
results = processor.process_excel_file('input.xlsx')
processor.save_results(results, 'output.xlsx')
```

## Creating Test Data

Generate a sample Excel file:
```bash
python create_sample_excel.py
```

This creates `sample_input.xlsx` with:
- Member Cost Share sheet (main data)
- Plan Detail sheet (for enrichment)
- Additional Info sheet (extra data)

## Example Workflow

1. Create sample data: `python create_sample_excel.py`
2. Start Streamlit: `streamlit run streamlit_app.py`
3. Load example rules from Dashboard
4. Go to "Process Excel" page
5. Upload `sample_input.xlsx`
6. Process and download results

## Notes

- Rules are evaluated by priority (ascending)
- First matching rule wins
- External JSON files allow rule updates without code changes
- All original data is preserved in the output