#!/usr/bin/env python3
"""
Command-line interface for processing Excel files
Usage: python process_excel_cli.py input.xlsx output.xlsx
"""

import sys
import os
import argparse
from excel_processor import ExcelProcessor
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    parser = argparse.ArgumentParser(description='Process Excel file with business rules')
    parser.add_argument('input_file', help='Path to input Excel file')
    parser.add_argument('output_file', help='Path for output Excel file')
    parser.add_argument('--rules-dir', default='rules', help='Directory containing rule files (default: rules)')
    parser.add_argument('--summary', action='store_true', help='Print processing summary')
    
    args = parser.parse_args()
    
    # Validate input file exists
    if not os.path.exists(args.input_file):
        logger.error(f"Input file not found: {args.input_file}")
        sys.exit(1)
    
    # Create processor
    processor = ExcelProcessor()
    
    try:
        # Load rules
        logger.info(f"Loading rules from directory: {args.rules_dir}")
        processor.load_all_rules(args.rules_dir)
        
        # Process the file
        logger.info(f"Processing file: {args.input_file}")
        results = processor.process_excel_file(args.input_file)
        
        # Save results
        logger.info(f"Saving results to: {args.output_file}")
        processor.save_results(results, args.output_file)
        
        # Print summary if requested
        if args.summary:
            summary = processor.get_processing_summary(results)
            print("\nProcessing Summary:")
            print(f"Sheets processed: {summary['sheets_processed']}")
            for sheet in summary['sheet_details']:
                print(f"\n{sheet['sheet_name']}:")
                print(f"  - Original rows: {sheet['original_rows']}")
                print(f"  - Final rows: {sheet['final_rows']}")
                print(f"  - Scenarios found: {sheet['scenarios_found']}")
                print(f"  - Rules matched: {sheet['rules_matched']}")
        
        logger.info("Processing completed successfully!")
        
    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()