import pandas as pd
import json
from typing import Dict, List, Any, Optional
import logging

logger = logging.getLogger(__name__)

class DataEnricher:
    """Handles Step 2: Data enrichment using Plan Detail sheet"""
    
    def __init__(self):
        self.enrichment_rules = []
        
    def load_enrichment_rules(self, rules_file_path: str) -> None:
        """Load enrichment rules from JSON file"""
        try:
            with open(rules_file_path, 'r') as f:
                self.enrichment_rules = json.load(f)
            logger.info(f"Loaded {len(self.enrichment_rules)} enrichment rules")
        except Exception as e:
            logger.error(f"Error loading enrichment rules: {str(e)}")
            raise
            
    def load_enrichment_rules_from_list(self, rules: List[Dict]) -> None:
        """Load enrichment rules from list (for Streamlit UI)"""
        self.enrichment_rules = rules
        
    def enrich_sheet_data(self, data_df: pd.DataFrame, plan_detail_df: pd.DataFrame, 
                         sheet_name: str) -> pd.DataFrame:
        """Enrich sheet data using Plan Detail sheet based on rules"""
        
        # Filter rules for this sheet
        sheet_rules = [r for r in self.enrichment_rules 
                      if r.get('source_sheet_name') == sheet_name]
        
        if not sheet_rules:
            logger.info(f"No enrichment rules found for sheet '{sheet_name}'")
            return data_df
            
        # Create a copy to avoid modifying original
        enriched_df = data_df.copy()
        
        for rule in sheet_rules:
            try:
                self._apply_enrichment_rule(enriched_df, plan_detail_df, rule)
            except Exception as e:
                logger.error(f"Error applying enrichment rule {rule.get('rule_id')}: {str(e)}")
                
        return enriched_df
        
    def _apply_enrichment_rule(self, data_df: pd.DataFrame, plan_detail_df: pd.DataFrame, 
                              rule: Dict) -> None:
        """Apply a single enrichment rule"""
        
        target_column = rule['target_column_to_update']
        join_details = rule['join_details']
        update_condition = rule['update_condition']
        lookup_logic = rule['lookup_logic']
        
        # Check if target column exists
        if target_column not in data_df.columns:
            logger.warning(f"Target column '{target_column}' not found in data")
            return
            
        # Identify rows needing update
        values_to_match = update_condition.get('values_to_match', ['', ' ', '9999', 'null', None])
        
        # Create mask for rows to update
        mask = pd.Series(False, index=data_df.index)
        for value in values_to_match:
            if value is None or value == 'null':
                mask |= data_df[target_column].isna()
            else:
                mask |= (data_df[target_column] == value)
                
        rows_to_update = data_df[mask]
        
        if rows_to_update.empty:
            logger.info(f"No rows need updating for rule {rule.get('rule_id')}")
            return
            
        # Perform the enrichment
        for idx, row in rows_to_update.iterrows():
            # Find matching Plan Detail row
            plan_id = row[join_details['source_column']]
            plan_detail_row = plan_detail_df[
                plan_detail_df[join_details['reference_column']] == plan_id
            ]
            
            if plan_detail_row.empty:
                continue
                
            plan_detail_row = plan_detail_row.iloc[0]
            
            # Apply lookup logic
            new_value = self._get_lookup_value(row, plan_detail_row, lookup_logic)
            
            if pd.notna(new_value) and str(new_value).strip() != '':
                data_df.at[idx, target_column] = new_value
                
    def _get_lookup_value(self, source_row: pd.Series, plan_detail_row: pd.Series, 
                         lookup_logic: Dict) -> Any:
        """Get the lookup value based on conditional rules"""
        
        # Try conditional rules first
        for rule in lookup_logic.get('conditional_rules', []):
            condition_field = rule['condition_on_source_field']
            operator = rule['operator']
            value_to_check = rule['value_to_check']
            
            if condition_field not in source_row.index:
                continue
                
            source_value = str(source_row[condition_field]).lower()
            check_value = value_to_check.lower()
            
            # Check condition
            condition_met = False
            if operator == 'contains_ignore_case':
                condition_met = check_value in source_value
            elif operator == 'equals_ignore_case':
                condition_met = source_value == check_value
            elif operator == 'startswith_ignore_case':
                condition_met = source_value.startswith(check_value)
                
            if condition_met:
                # Get value from Plan Detail
                plan_detail_field = rule['use_plan_detail_field']
                if plan_detail_field in plan_detail_row.index:
                    value = plan_detail_row[plan_detail_field]
                    if pd.notna(value) and str(value).strip() != '':
                        return value
                        
                # Try fallback field if primary is blank
                fallback_field = rule.get('fallback_plan_detail_field')
                if fallback_field and fallback_field in plan_detail_row.index:
                    value = plan_detail_row[fallback_field]
                    if pd.notna(value) and str(value).strip() != '':
                        return value
                        
        # Use default field if no conditional rules matched
        default_field = lookup_logic.get('default_plan_detail_field')
        if default_field and default_field in plan_detail_row.index:
            return plan_detail_row[default_field]
            
        return None