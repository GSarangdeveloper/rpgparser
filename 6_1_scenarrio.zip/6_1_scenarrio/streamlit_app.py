import streamlit as st
import pandas as pd
import json
import os
from datetime import datetime
from rule_engine import RuleEngine
from data_enricher import DataEnricher
from base_scenario import BaseScenario
from excel_processor import ExcelProcessor
import io

# Page configuration
st.set_page_config(
    page_title="Rule Management System",
    page_icon="📋",
    layout="wide"
)

# Initialize session state
if 'scenario_rules' not in st.session_state:
    st.session_state.scenario_rules = {}
if 'enrichment_rules' not in st.session_state:
    st.session_state.enrichment_rules = []
if 'expansion_rules' not in st.session_state:
    st.session_state.expansion_rules = {}

def save_rules_to_file(rules_type, rules_data, filename):
    """Save rules to JSON file"""
    os.makedirs('rules', exist_ok=True)
    with open(f'rules/{filename}', 'w') as f:
        json.dump(rules_data, f, indent=2)
    st.success(f"{rules_type} rules saved successfully!")

def load_rules_from_file(filename):
    """Load rules from JSON file"""
    filepath = f'rules/{filename}'
    if os.path.exists(filepath):
        with open(filepath, 'r') as f:
            return json.load(f)
    return None

# Main app
st.title("📋 Rule Management System")
st.markdown("Manage business rules for Excel processing")

# Sidebar for navigation
page = st.sidebar.selectbox(
    "Navigation",
    ["Dashboard", "Scenario Rules", "Enrichment Rules", "Expansion Rules", "Process Excel", "Test Rules"]
)

if page == "Dashboard":
    st.header("System Overview")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Scenario Rule Sets", len(st.session_state.scenario_rules))
    with col2:
        st.metric("Enrichment Rules", len(st.session_state.enrichment_rules))
    with col3:
        st.metric("Expansion Rule Sets", len(st.session_state.expansion_rules))
    
    st.subheader("Quick Actions")
    
    if st.button("Load Example Rules"):
        # Load the example from vision.md
        example_rules = {
            "sheet_name_in_excel": "Member Cost Share",
            "columns_to_extract": [
                "PlanID", "Copay Category", "Pharmacy Network", "Drug List",
                "Delivery System", "Copay Tier", "Copay Step", "Copay Max Days Supply",
                "Copay Amount - Flat Dollar", "Copay Amount - Percent",
                "Copay Minimum", "Copay Maximum", "Copay Calculation"
            ],
            "default_scenario": "MCS_UNMAPPED_SCENARIO",
            "default_rule_id": "MCS_NO_MATCH",
            "rules": [
                {
                    "RuleID": "MCS001",
                    "Priority": 1,
                    "IsEnabled": True,
                    "ScenarioIdentification": "DC_Flat Copay, Extended Cycle",
                    "conditions": {
                        "Copay Category": "Drug Specific",
                        "Delivery System": "_NONBLANK_",
                        "Pharmacy Network": "_NONBLANK_",
                        "Drug List": "_NONBLANK_",
                        "Copay Amount - Flat Dollar": "_BLANK_",
                        "Copay Amount - Percent": "_NONBLANK_",
                        "Copay Minimum": "_BLANK_",
                        "Copay Maximum": "_BLANK_",
                        "Copay Calculation": "_BLANK_"
                    }
                }
            ]
        }
        st.session_state.scenario_rules["Member Cost Share"] = example_rules
        st.success("Example rules loaded!")

elif page == "Scenario Rules":
    st.header("Scenario Identification Rules")
    st.markdown("Define rules for Step 1: Scenario Identification")
    
    # Sheet selection
    sheet_names = list(st.session_state.scenario_rules.keys())
    sheet_names.append("+ Add New Sheet")
    
    selected_sheet = st.selectbox("Select Sheet", sheet_names)
    
    if selected_sheet == "+ Add New Sheet":
        new_sheet_name = st.text_input("Sheet Name")
        if st.button("Create Sheet") and new_sheet_name:
            st.session_state.scenario_rules[new_sheet_name] = {
                "sheet_name_in_excel": new_sheet_name,
                "columns_to_extract": [],
                "default_scenario": "UNMAPPED_SCENARIO",
                "default_rule_id": "NO_MATCH",
                "rules": []
            }
            st.experimental_rerun()
    
    elif selected_sheet:
        sheet_data = st.session_state.scenario_rules[selected_sheet]
        
        # Edit sheet configuration
        st.subheader("Sheet Configuration")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            sheet_data["default_scenario"] = st.text_input(
                "Default Scenario", 
                value=sheet_data.get("default_scenario", "UNMAPPED_SCENARIO")
            )
        with col2:
            sheet_data["default_rule_id"] = st.text_input(
                "Default Rule ID", 
                value=sheet_data.get("default_rule_id", "NO_MATCH")
            )
        with col3:
            st.write("") # Empty column for spacing
            
        # Sheet layout configuration
        st.subheader("Sheet Layout Configuration")
        st.info("Specify where headers and data are located in the Excel sheet (0-indexed)")
        
        if "sheet_config" not in sheet_data:
            sheet_data["sheet_config"] = {}
            
        col1, col2, col3 = st.columns(3)
        with col1:
            header_row = st.number_input(
                "Header Row (0-indexed)", 
                min_value=0, 
                value=sheet_data["sheet_config"].get("header_row", 0),
                help="Row 3 = index 2"
            )
            sheet_data["sheet_config"]["header_row"] = header_row
        with col2:
            data_start_row = st.number_input(
                "Data Start Row (0-indexed)", 
                min_value=0, 
                value=sheet_data["sheet_config"].get("data_start_row", header_row + 1),
                help="Row 5 = index 4"
            )
            sheet_data["sheet_config"]["data_start_row"] = data_start_row
        with col3:
            st.write(f"Headers at row {header_row + 1}")
            st.write(f"Data starts at row {data_start_row + 1}")
        
        # Columns to extract
        st.subheader("Columns to Extract")
        columns_text = st.text_area(
            "Enter column names (one per line)",
            value="\n".join(sheet_data.get("columns_to_extract", [])),
            height=150
        )
        sheet_data["columns_to_extract"] = [col.strip() for col in columns_text.split("\n") if col.strip()]
        
        # Rules management
        st.subheader("Rules")
        
        # Add new rule
        with st.expander("Add New Rule"):
            new_rule = {}
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                new_rule["RuleID"] = st.text_input("Rule ID", key="new_rule_id")
            with col2:
                new_rule["Priority"] = st.number_input("Priority", min_value=1, value=1, key="new_priority")
            with col3:
                new_rule["IsEnabled"] = st.checkbox("Is Enabled", value=True, key="new_enabled")
            with col4:
                new_rule["ScenarioIdentification"] = st.text_input("Scenario", key="new_scenario")
            
            st.write("Conditions")
            num_conditions = st.number_input("Number of conditions", min_value=1, value=1, key="num_conditions")
            
            new_rule["conditions"] = {}
            for i in range(num_conditions):
                col1, col2 = st.columns(2)
                with col1:
                    field = st.text_input(f"Field {i+1}", key=f"field_{i}")
                with col2:
                    value = st.text_input(f"Value {i+1}", key=f"value_{i}")
                if field:
                    new_rule["conditions"][field] = value
            
            if st.button("Add Rule"):
                if new_rule["RuleID"] and new_rule["ScenarioIdentification"]:
                    sheet_data["rules"].append(new_rule)
                    st.success("Rule added!")
                    st.experimental_rerun()
        
        # Display existing rules
        if sheet_data.get("rules"):
            st.write("Existing Rules:")
            rules_df = pd.DataFrame(sheet_data["rules"])
            st.dataframe(rules_df)
            
            # Delete rule
            rule_to_delete = st.selectbox(
                "Select rule to delete", 
                ["None"] + [r["RuleID"] for r in sheet_data["rules"]]
            )
            if rule_to_delete != "None" and st.button("Delete Rule"):
                sheet_data["rules"] = [r for r in sheet_data["rules"] if r["RuleID"] != rule_to_delete]
                st.success("Rule deleted!")
                st.experimental_rerun()
        
        # Save rules
        if st.button("Save Scenario Rules"):
            save_rules_to_file("Scenario", sheet_data, f"{selected_sheet}_rules.json")

elif page == "Enrichment Rules":
    st.header("Data Enrichment Rules")
    st.markdown("Define rules for Step 2: Data Enrichment")
    
    # Add new enrichment rule
    with st.expander("Add New Enrichment Rule"):
        new_rule = {}
        
        col1, col2 = st.columns(2)
        with col1:
            new_rule["rule_id"] = st.text_input("Rule ID")
            new_rule["source_sheet_name"] = st.text_input("Source Sheet Name")
        with col2:
            new_rule["target_column_to_update"] = st.text_input("Target Column to Update")
        
        st.subheader("Join Details")
        col1, col2, col3 = st.columns(3)
        with col1:
            source_col = st.text_input("Source Column")
        with col2:
            reference_sheet = st.text_input("Reference Sheet", value="Plan Detail")
        with col3:
            reference_col = st.text_input("Reference Column")
        
        new_rule["join_details"] = {
            "source_column": source_col,
            "reference_sheet_name": reference_sheet,
            "reference_column": reference_col
        }
        
        st.subheader("Update Condition")
        values_to_match = st.text_area(
            "Values to match (one per line)",
            value="\n9999\nnull"
        ).split("\n")
        
        new_rule["update_condition"] = {
            "type": "is_blank_or_specific_values",
            "values_to_match": [v.strip() for v in values_to_match if v.strip()]
        }
        
        st.subheader("Lookup Logic")
        num_conditional_rules = st.number_input("Number of conditional rules", min_value=0, value=1)
        
        conditional_rules = []
        for i in range(num_conditional_rules):
            st.write(f"Conditional Rule {i+1}")
            col1, col2, col3 = st.columns(3)
            with col1:
                condition_field = st.text_input(f"Condition Field {i+1}", key=f"cond_field_{i}")
                operator = st.selectbox(
                    f"Operator {i+1}", 
                    ["contains_ignore_case", "equals_ignore_case", "startswith_ignore_case"],
                    key=f"operator_{i}"
                )
            with col2:
                value_to_check = st.text_input(f"Value to Check {i+1}", key=f"check_value_{i}")
            with col3:
                use_field = st.text_input(f"Use Plan Detail Field {i+1}", key=f"use_field_{i}")
                fallback_field = st.text_input(f"Fallback Field {i+1}", key=f"fallback_{i}")
            
            if condition_field and use_field:
                rule_dict = {
                    "condition_on_source_field": condition_field,
                    "operator": operator,
                    "value_to_check": value_to_check,
                    "use_plan_detail_field": use_field
                }
                if fallback_field:
                    rule_dict["fallback_plan_detail_field"] = fallback_field
                conditional_rules.append(rule_dict)
        
        default_field = st.text_input("Default Plan Detail Field")
        
        new_rule["lookup_logic"] = {
            "conditional_rules": conditional_rules,
            "default_plan_detail_field": default_field
        }
        
        if st.button("Add Enrichment Rule"):
            if new_rule["rule_id"] and new_rule["source_sheet_name"]:
                st.session_state.enrichment_rules.append(new_rule)
                st.success("Enrichment rule added!")
                st.experimental_rerun()
    
    # Display existing rules
    if st.session_state.enrichment_rules:
        st.subheader("Existing Enrichment Rules")
        for i, rule in enumerate(st.session_state.enrichment_rules):
            with st.expander(f"Rule: {rule['rule_id']}"):
                st.json(rule)
                if st.button(f"Delete Rule {i}", key=f"del_enrich_{i}"):
                    st.session_state.enrichment_rules.pop(i)
                    st.experimental_rerun()
    
    # Save rules
    if st.button("Save Enrichment Rules"):
        save_rules_to_file("Enrichment", st.session_state.enrichment_rules, "enrichment_rules.json")

elif page == "Expansion Rules":
    st.header("Base Scenario Expansion Rules")
    st.markdown("Define rules for Step 3: Base Scenario Expansion")
    
    # Sheet selection
    sheet_names = list(st.session_state.expansion_rules.keys())
    sheet_names.append("+ Add New Sheet")
    
    selected_sheet = st.selectbox("Select Sheet", sheet_names)
    
    if selected_sheet == "+ Add New Sheet":
        new_sheet_name = st.text_input("Sheet Name")
        if st.button("Create Sheet") and new_sheet_name:
            st.session_state.expansion_rules[new_sheet_name] = {}
            st.experimental_rerun()
    
    elif selected_sheet:
        sheet_rules = st.session_state.expansion_rules[selected_sheet]
        
        # Add new expansion rule
        with st.expander("Add New Expansion Rule"):
            scenario_id = st.text_input("Scenario Identification")
            base_scenarios = st.text_area(
                "Base Scenarios (one per line)",
                value="Verify_Copay"
            ).split("\n")
            expected_status = st.text_input("Expected Status", value="P")
            
            if st.button("Add Expansion Rule"):
                if scenario_id:
                    sheet_rules[scenario_id] = {
                        "base_scenarios": [s.strip() for s in base_scenarios if s.strip()],
                        "expected_status": expected_status
                    }
                    st.success("Expansion rule added!")
                    st.experimental_rerun()
        
        # Display existing rules
        if sheet_rules:
            st.subheader("Existing Expansion Rules")
            for scenario, rule in sheet_rules.items():
                with st.expander(f"Scenario: {scenario}"):
                    st.write(f"Base Scenarios: {', '.join(rule['base_scenarios'])}")
                    st.write(f"Expected Status: {rule['expected_status']}")
                    if st.button(f"Delete {scenario}", key=f"del_exp_{scenario}"):
                        del sheet_rules[scenario]
                        st.experimental_rerun()
        
        # Save rules
        if st.button("Save Expansion Rules"):
            save_rules_to_file("Expansion", st.session_state.expansion_rules, "expansion_rules.json")

elif page == "Process Excel":
    st.header("Process Excel File")
    
    # File upload
    uploaded_file = st.file_uploader("Choose an Excel file", type=['xlsx', 'xls'])
    
    if uploaded_file:
        # Process button
        if st.button("Process File"):
            with st.spinner("Processing..."):
                try:
                    # Create processor
                    processor = ExcelProcessor()
                    
                    # Load rules from session state
                    for sheet_name, rules in st.session_state.scenario_rules.items():
                        processor.rule_engine.load_rules_from_dict(sheet_name, rules)
                        
                        # Also load sheet configuration if present
                        if 'sheet_config' in rules:
                            processor.sheet_config[sheet_name] = rules['sheet_config']
                    
                    processor.data_enricher.load_enrichment_rules_from_list(
                        st.session_state.enrichment_rules
                    )
                    
                    processor.base_scenario.load_expansion_rules_from_dict(
                        st.session_state.expansion_rules
                    )
                    
                    # Process file
                    results = processor.process_excel_file(uploaded_file)
                    
                    # Display summary
                    st.success("Processing complete!")
                    summary = processor.get_processing_summary(results)
                    
                    st.subheader("Processing Summary")
                    st.json(summary)
                    
                    # Download processed file
                    output = io.BytesIO()
                    with pd.ExcelWriter(output, engine='openpyxl') as writer:
                        for sheet_name, df in results.items():
                            df.to_excel(writer, sheet_name=sheet_name, index=False)
                    
                    output.seek(0)
                    st.download_button(
                        label="Download Processed File",
                        data=output,
                        file_name=f"processed_{uploaded_file.name}",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
                    
                except Exception as e:
                    st.error(f"Error processing file: {str(e)}")

elif page == "Test Rules":
    st.header("Test Rules")
    st.markdown("Test your rules with sample data")
    
    # Create test data
    st.subheader("Create Test Data")
    
    num_rows = st.number_input("Number of rows", min_value=1, value=5)
    num_cols = st.number_input("Number of columns", min_value=1, value=5)
    
    # Create column names
    col_names = []
    cols = st.columns(num_cols)
    for i, col in enumerate(cols):
        col_name = col.text_input(f"Column {i+1}", value=f"Column_{i+1}")
        col_names.append(col_name)
    
    # Create data
    data = {}
    for col_name in col_names:
        col_data = []
        for i in range(num_rows):
            value = st.text_input(f"{col_name} - Row {i+1}", key=f"{col_name}_{i}")
            col_data.append(value)
        data[col_name] = col_data
    
    test_df = pd.DataFrame(data)
    st.dataframe(test_df)
    
    # Test with rules
    sheet_to_test = st.selectbox(
        "Select sheet rules to test", 
        list(st.session_state.scenario_rules.keys())
    )
    
    if sheet_to_test and st.button("Test Rules"):
        engine = RuleEngine()
        engine.load_rules_from_dict(sheet_to_test, st.session_state.scenario_rules[sheet_to_test])
        
        result_df = engine.process_sheet(test_df, sheet_to_test)
        
        st.subheader("Results")
        st.dataframe(result_df)

# Footer
st.sidebar.markdown("---")
st.sidebar.markdown("Rule Management System v1.0")
st.sidebar.markdown("Built with Streamlit")