import pandas as pd
import json
import os
from typing import Dict, List, Any, Optional
from rule_engine import RuleEngine
from data_enricher import DataEnricher
from base_scenario import BaseScenario
import logging

logger = logging.getLogger(__name__)

class ExcelProcessor:
    """Main processor that orchestrates all three steps"""
    
    def __init__(self):
        self.rule_engine = RuleEngine()
        self.data_enricher = DataEnricher()
        self.base_scenario = BaseScenario()
        self.rules_config = {}
        
        # Sheet configuration for header and data row positions
        self.sheet_config = {
            'Member Cost Share': {
                'header_row': 2,  # Row 3 (0-indexed)
                'data_start_row': 4  # Row 5 (0-indexed)
            },
            'Plan Detail': {
                'header_row': 3,  # Row 4 (0-indexed)
                'data_start_row': 5  # Row 6 (0-indexed)
            }
        }
        
    def load_all_rules(self, rules_directory: str) -> None:
        """Load all rules from a directory"""
        # Load sheet configuration
        sheet_config_path = os.path.join(rules_directory, 'sheet_config.json')
        if os.path.exists(sheet_config_path):
            self.load_sheet_config(sheet_config_path)
            
        # Load scenario identification rules
        scenario_rules_path = os.path.join(rules_directory, 'scenario_rules')
        if os.path.exists(scenario_rules_path):
            for file in os.listdir(scenario_rules_path):
                if file.endswith('.json'):
                    filepath = os.path.join(scenario_rules_path, file)
                    self.rule_engine.load_rules(filepath)
                    
                    # Also extract sheet config from scenario rules if present
                    try:
                        with open(filepath, 'r') as f:
                            rules_data = json.load(f)
                            sheet_name = rules_data.get('sheet_name_in_excel')
                            if sheet_name and 'sheet_config' in rules_data:
                                self.sheet_config[sheet_name] = rules_data['sheet_config']
                    except:
                        pass
                    
        # Load enrichment rules
        enrichment_rules_path = os.path.join(rules_directory, 'enrichment_rules.json')
        if os.path.exists(enrichment_rules_path):
            self.data_enricher.load_enrichment_rules(enrichment_rules_path)
            
        # Load expansion rules
        expansion_rules_path = os.path.join(rules_directory, 'expansion_rules.json')
        if os.path.exists(expansion_rules_path):
            self.base_scenario.load_expansion_rules(expansion_rules_path)
            
    def load_sheet_config(self, config_file_path: str) -> None:
        """Load sheet configuration from JSON file"""
        try:
            with open(config_file_path, 'r') as f:
                self.sheet_config = json.load(f)
            logger.info(f"Loaded sheet configuration from {config_file_path}")
        except Exception as e:
            logger.warning(f"Could not load sheet config: {str(e)}. Using defaults.")
    
    def read_sheet_with_config(self, excel_file, sheet_name: str) -> pd.DataFrame:
        """Read a sheet with specific header and data row configuration"""
        config = self.sheet_config.get(sheet_name, {})
        
        if config:
            # Read with specific header row
            header_row = config.get('header_row', 0)
            data_start_row = config.get('data_start_row', header_row + 1)
            
            # Read the Excel file with header at specified row
            df = pd.read_excel(
                excel_file, 
                sheet_name=sheet_name,
                header=header_row,
                skiprows=range(header_row + 1, data_start_row)
            )
            
            logger.info(f"Read sheet '{sheet_name}' with header at row {header_row + 1}, data starting at row {data_start_row + 1}")
        else:
            # Default read for sheets without specific configuration
            df = pd.read_excel(excel_file, sheet_name=sheet_name)
            logger.info(f"Read sheet '{sheet_name}' with default configuration")
            
        return df
    
    def process_excel_file(self, excel_file_path: str) -> Dict[str, pd.DataFrame]:
        """Process an Excel file through all three steps"""
        
        # Read Excel file
        excel_data = pd.ExcelFile(excel_file_path)
        sheet_names = excel_data.sheet_names
        
        # Load all sheets
        all_sheets = {}
        plan_detail_df = None
        
        for sheet_name in sheet_names:
            df = self.read_sheet_with_config(excel_data, sheet_name)
            all_sheets[sheet_name] = df
            
            if sheet_name == 'Plan Detail':
                plan_detail_df = df
                
        # Process each sheet through all three steps
        final_output = {}
        
        for sheet_name, df in all_sheets.items():
            if sheet_name == 'Plan Detail':
                # Don't process Plan Detail sheet
                final_output[sheet_name] = df
                continue
                
            logger.info(f"Processing sheet: {sheet_name}")
            
            # Step 1: Scenario Identification
            step1_df = self.rule_engine.process_sheet(df, sheet_name)
            
            # Step 2: Data Enrichment
            if plan_detail_df is not None:
                step2_df = self.data_enricher.enrich_sheet_data(
                    step1_df, plan_detail_df, sheet_name
                )
            else:
                step2_df = step1_df
                
            # Step 3: Base Scenario Expansion
            step3_df = self.base_scenario.expand_scenarios(step2_df, sheet_name)
            
            final_output[sheet_name] = step3_df
            
        return final_output
        
    def save_results(self, results: Dict[str, pd.DataFrame], output_path: str) -> None:
        """Save processed results to Excel file"""
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            for sheet_name, df in results.items():
                df.to_excel(writer, sheet_name=sheet_name, index=False)
                
        logger.info(f"Results saved to {output_path}")
        
    def get_processing_summary(self, results: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """Get summary of processing results"""
        summary = {
            "sheets_processed": len(results),
            "sheet_details": []
        }
        
        for sheet_name, df in results.items():
            detail = {
                "sheet_name": sheet_name,
                "original_rows": len(df[df['Base Scenario'] != 'NO_EXPANSION_RULE']) if 'Base Scenario' in df.columns else len(df),
                "final_rows": len(df),
                "scenarios_found": df['Scenario Identification'].nunique() if 'Scenario Identification' in df.columns else 0,
                "rules_matched": df['MatchedRuleID'].nunique() if 'MatchedRuleID' in df.columns else 0
            }
            summary["sheet_details"].append(detail)
            
        return summary