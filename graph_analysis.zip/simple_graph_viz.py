import json
import os

def create_mermaid_graph():
    """Create Mermaid diagram for rule graph visualization"""
    
    mermaid_code = """graph TD
    %% Functional Area
    FA[Member Cost Share<br/>Functional Area]
    style FA fill:#4CAF50,stroke:#333,stroke-width:2px,color:#fff
    
    %% Scenario Rules
    SR1[MCS001<br/>Priority: 1]
    SR2[MCS002<br/>Priority: 2]
    SR3[MCS003<br/>Priority: 3]
    style SR1 fill:#2196F3,stroke:#333,stroke-width:2px,color:#fff
    style SR2 fill:#2196F3,stroke:#333,stroke-width:2px,color:#fff
    style SR3 fill:#2196F3,stroke:#333,stroke-width:2px,color:#fff
    
    %% Scenario Identifications
    SI1[DC_Flat Copay<br/>Extended Cycle]
    SI2[DC_Flat Coinsurance<br/>Extended Cycle]
    SI3[DC_Coinsurance with Min<br/>Extended Cycle]
    style SI1 fill:#FF9800,stroke:#333,stroke-width:2px,color:#fff
    style SI2 fill:#FF9800,stroke:#333,stroke-width:2px,color:#fff
    style SI3 fill:#FF9800,stroke:#333,stroke-width:2px,color:#fff
    
    %% Base Scenarios
    BS1[Verify_Copay]
    BS2[Verify_Coinsurance]
    BS3[Verify_Min Copay]
    BS4[Verify_Max Copay]
    style BS1 fill:#9C27B0,stroke:#333,stroke-width:2px,color:#fff
    style BS2 fill:#9C27B0,stroke:#333,stroke-width:2px,color:#fff
    style BS3 fill:#9C27B0,stroke:#333,stroke-width:2px,color:#fff
    style BS4 fill:#9C27B0,stroke:#333,stroke-width:2px,color:#fff
    
    %% Enrichment Rule
    ER1[ENRICH_MCS_COPAY_MAX_DAYS<br/>Enrichment Rule]
    style ER1 fill:#795548,stroke:#333,stroke-width:2px,color:#fff
    
    %% Data Fields (subset for clarity)
    DF1[Copay Category]
    DF2[Copay Amount - Percent]
    DF3[Copay Max Days Supply]
    style DF1 fill:#607D8B,stroke:#333,stroke-width:2px,color:#fff
    style DF2 fill:#607D8B,stroke:#333,stroke-width:2px,color:#fff
    style DF3 fill:#607D8B,stroke:#333,stroke-width:2px,color:#fff
    
    %% Relationships
    SR1 -->|APPLIES_TO| FA
    SR2 -->|APPLIES_TO| FA
    SR3 -->|APPLIES_TO| FA
    
    SR1 -->|PRODUCES| SI1
    SR2 -->|PRODUCES| SI2
    SR3 -->|PRODUCES| SI3
    
    SI1 -->|EXPANDS_TO| BS1
    SI2 -->|EXPANDS_TO| BS2
    SI3 -->|EXPANDS_TO| BS2
    SI3 -->|EXPANDS_TO| BS3
    
    SR1 -->|DEPENDS_ON| DF1
    SR1 -->|DEPENDS_ON| DF2
    SR2 -->|DEPENDS_ON| DF1
    SR2 -->|DEPENDS_ON| DF2
    SR3 -->|DEPENDS_ON| DF1
    SR3 -->|DEPENDS_ON| DF2
    
    ER1 -->|ENRICHES_SHEET| FA
    ER1 -->|UPDATES_FIELD| DF3
    
    FA -->|HAS_FIELD| DF1
    FA -->|HAS_FIELD| DF2
    FA -->|HAS_FIELD| DF3
    """
    
    # Save Mermaid diagram
    with open('rule_graph_mermaid.md', 'w') as f:
        f.write("# Rule Graph Visualization\n\n")
        f.write("```mermaid\n")
        f.write(mermaid_code)
        f.write("\n```\n\n")
        f.write("## Legend\n")
        f.write("- **Green**: Functional Areas\n")
        f.write("- **Blue**: Scenario Rules\n")
        f.write("- **Orange**: Scenario Identifications\n")
        f.write("- **Purple**: Base Scenarios\n")
        f.write("- **Gray**: Data Fields\n")
        f.write("- **Brown**: Enrichment Rules\n")
    
    print("Mermaid diagram saved to rule_graph_mermaid.md")

def create_ascii_visualization():
    """Create ASCII art visualization of the rule graph"""
    
    ascii_art = """
    ┌─────────────────────────────────────────────────────────────────────┐
    │                      RULE GRAPH STRUCTURE                            │
    └─────────────────────────────────────────────────────────────────────┘
    
    Level 0: FUNCTIONAL AREA
    ═══════════════════════════════════════════════════════════════════════
                            [Member Cost Share]
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
    
    Level 1: RULES (Scenario & Enrichment)
    ═══════════════════════════════════════════════════════════════════════
              [MCS001]         [MCS002]         [MCS003]      [ENRICH_MCS]
           (Priority: 1)    (Priority: 2)    (Priority: 3)   (Enrichment)
                 │               │               │                │
                 │               │               │                │
    
    Level 2: SCENARIO IDENTIFICATIONS
    ═══════════════════════════════════════════════════════════════════════
        [DC_Flat Copay,    [DC_Flat         [DC_Coinsurance
         Extended Cycle]    Coinsurance,      with Min,
                           Extended Cycle]    Extended Cycle]
                │               │                    │
                │               │                    ├────────┐
                │               │                    │        │
    
    Level 3: BASE SCENARIOS
    ═══════════════════════════════════════════════════════════════════════
         [Verify_Copay]  [Verify_Coinsurance]  [Verify_Min Copay]
    
    
    Level 4: DATA FIELDS (Sample)
    ═══════════════════════════════════════════════════════════════════════
    Connected to Rules & Functional Area:
    • Copay Category
    • Copay Amount - Percent  
    • Copay Max Days Supply (Updated by Enrichment Rule)
    • Delivery System
    • Drug List
    • ... and more
    
    RELATIONSHIPS:
    ─────────────
    → APPLIES_TO: Rules apply to Functional Areas
    → PRODUCES: Scenario Rules produce Scenario Identifications
    → EXPANDS_TO: Scenario Identifications expand to Base Scenarios
    → DEPENDS_ON: Rules depend on Data Fields
    → ENRICHES_SHEET: Enrichment Rules enrich Functional Areas
    → UPDATES_FIELD: Enrichment Rules update specific fields
    """
    
    with open('rule_graph_ascii.txt', 'w') as f:
        f.write(ascii_art)
    
    print("ASCII visualization saved to rule_graph_ascii.txt")
    print(ascii_art)

def analyze_graph_structure():
    """Analyze and report on the graph structure"""
    
    # Load rules to analyze
    scenario_rules = []
    expansion_rules = {}
    enrichment_rules = []
    
    # Load scenario rules
    rules_dir = "rules/scenario_rules"
    for filename in os.listdir(rules_dir):
        if filename.endswith("_Rules.json"):
            filepath = os.path.join(rules_dir, filename)
            with open(filepath, 'r') as f:
                data = json.load(f)
                for rule in data["rules"]:
                    if rule["IsEnabled"]:
                        scenario_rules.append(rule)
    
    # Load expansion rules
    with open("rules/expansion_rules.json", 'r') as f:
        expansion_rules = json.load(f)
    
    # Load enrichment rules
    with open("rules/enrichment_rules.json", 'r') as f:
        enrichment_rules = json.load(f)
    
    # Generate analysis
    analysis = f"""
    GRAPH STRUCTURE ANALYSIS
    ========================
    
    1. SCENARIO RULES: {len(scenario_rules)} active rules
       - Rule IDs: {', '.join([r['RuleID'] for r in scenario_rules])}
       - Priority Range: {min([r['Priority'] for r in scenario_rules])} - {max([r['Priority'] for r in scenario_rules])}
    
    2. SCENARIO IDENTIFICATIONS: {len(expansion_rules.get('Member Cost Share', {}))} scenarios
       - Single Base Scenario: {sum(1 for s in expansion_rules.get('Member Cost Share', {}).values() if len(s['base_scenarios']) == 1)}
       - Multiple Base Scenarios: {sum(1 for s in expansion_rules.get('Member Cost Share', {}).values() if len(s['base_scenarios']) > 1)}
       - Max Base Scenarios: {max([len(s['base_scenarios']) for s in expansion_rules.get('Member Cost Share', {}).values()])}
    
    3. BASE SCENARIOS: {len(set([bs for s in expansion_rules.get('Member Cost Share', {}).values() for bs in s['base_scenarios']]))} unique
       - All Base Scenarios: {', '.join(sorted(set([bs for s in expansion_rules.get('Member Cost Share', {}).values() for bs in s['base_scenarios']])))}
    
    4. ENRICHMENT RULES: {len(enrichment_rules)} rules
       - Target Columns: {', '.join([r['target_column_to_update'] for r in enrichment_rules])}
    
    5. GRAPH COMPLEXITY METRICS:
       - Total Nodes: ~40-50 (including all data fields)
       - Total Edges: ~100+ (including all dependencies)
       - Graph Depth: 5 levels (FA → Rules → Scenarios → Base → Fields)
       - Branching Factor: Varies (1-3 typically)
    """
    
    with open('graph_analysis.txt', 'w') as f:
        f.write(analysis)
    
    print("Graph analysis saved to graph_analysis.txt")
    print(analysis)

if __name__ == "__main__":
    print("Creating graph visualizations...")
    create_mermaid_graph()
    create_ascii_visualization()
    analyze_graph_structure()
    print("\nAll visualizations created successfully!")