import json
import os
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import matplotlib.patches as mpatches

class RuleGraphVisualizer:
    """Create visual representation of rules without Neo4j"""
    
    def __init__(self):
        self.G = nx.DiGraph()
        self.node_colors = {
            'FunctionalArea': '#4CAF50',
            'ScenarioRule': '#2196F3',
            'ScenarioIdentification': '#FF9800',
            'BaseScenario': '#9C27B0',
            'DataField': '#607D8B',
            'EnrichmentRule': '#795548'
        }
        
    def load_rules(self):
        """Load rules from JSON files and build graph"""
        
        # Load scenario rules
        rules_dir = "rules/scenario_rules"
        for filename in os.listdir(rules_dir):
            if filename.endswith("_Rules.json"):
                filepath = os.path.join(rules_dir, filename)
                with open(filepath, 'r') as f:
                    data = json.load(f)
                    
                sheet_name = data["sheet_name_in_excel"]
                
                # Add functional area node
                self.G.add_node(f"FA_{sheet_name}", 
                              type='FunctionalArea',
                              label=sheet_name,
                              sheet_config=data["sheet_config"])
                
                # Add data field nodes
                for column in data["columns_to_extract"]:
                    field_id = f"DF_{column}"
                    self.G.add_node(field_id,
                                  type='DataField',
                                  label=column)
                    self.G.add_edge(f"FA_{sheet_name}", field_id, 
                                  relationship='HAS_FIELD')
                
                # Add scenario rules
                for rule in data["rules"]:
                    if rule["IsEnabled"]:
                        rule_id = f"SR_{rule['RuleID']}"
                        scenario_id = f"SI_{rule['ScenarioIdentification']}"
                        
                        self.G.add_node(rule_id,
                                      type='ScenarioRule',
                                      label=rule['RuleID'],
                                      priority=rule['Priority'],
                                      scenario=rule['ScenarioIdentification'])
                        
                        self.G.add_node(scenario_id,
                                      type='ScenarioIdentification',
                                      label=rule['ScenarioIdentification'])
                        
                        # Add relationships
                        self.G.add_edge(rule_id, f"FA_{sheet_name}", 
                                      relationship='APPLIES_TO')
                        self.G.add_edge(rule_id, scenario_id, 
                                      relationship='PRODUCES')
                        
                        # Add dependencies
                        for field, condition in rule["conditions"].items():
                            field_id = f"DF_{field}"
                            self.G.add_edge(rule_id, field_id,
                                          relationship='DEPENDS_ON',
                                          condition=condition)
        
        # Load expansion rules
        with open("rules/expansion_rules.json", 'r') as f:
            expansion_data = json.load(f)
            
        for sheet_name, scenarios in expansion_data.items():
            for scenario_name, config in scenarios.items():
                scenario_id = f"SI_{scenario_name}"
                
                for base_scenario in config["base_scenarios"]:
                    base_id = f"BS_{base_scenario}"
                    self.G.add_node(base_id,
                                  type='BaseScenario',
                                  label=base_scenario,
                                  expected_status=config["expected_status"])
                    self.G.add_edge(scenario_id, base_id,
                                  relationship='EXPANDS_TO')
        
        # Load enrichment rules
        with open("rules/enrichment_rules.json", 'r') as f:
            enrichment_data = json.load(f)
            
        for rule in enrichment_data:
            rule_id = f"ER_{rule['rule_id']}"
            self.G.add_node(rule_id,
                          type='EnrichmentRule',
                          label=rule['rule_id'],
                          target_column=rule['target_column_to_update'])
            
            # Add relationships
            self.G.add_edge(rule_id, f"FA_{rule['source_sheet_name']}", 
                          relationship='ENRICHES_SHEET')
            self.G.add_edge(rule_id, f"DF_{rule['target_column_to_update']}", 
                          relationship='UPDATES_FIELD')
    
    def create_hierarchical_layout(self):
        """Create a hierarchical layout for the graph"""
        # Separate nodes by type
        layers = {
            0: [],  # Functional Areas
            1: [],  # Scenario Rules and Enrichment Rules
            2: [],  # Scenario Identifications
            3: [],  # Base Scenarios
            4: []   # Data Fields
        }
        
        for node, data in self.G.nodes(data=True):
            node_type = data.get('type', '')
            if node_type == 'FunctionalArea':
                layers[0].append(node)
            elif node_type in ['ScenarioRule', 'EnrichmentRule']:
                layers[1].append(node)
            elif node_type == 'ScenarioIdentification':
                layers[2].append(node)
            elif node_type == 'BaseScenario':
                layers[3].append(node)
            elif node_type == 'DataField':
                layers[4].append(node)
        
        # Calculate positions
        pos = {}
        y_offset = 0
        for layer_idx, nodes in layers.items():
            if nodes:
                x_spacing = 2.0
                x_offset = -(len(nodes) - 1) * x_spacing / 2
                for i, node in enumerate(nodes):
                    pos[node] = (x_offset + i * x_spacing, -layer_idx * 3)
        
        return pos
    
    def visualize_full_graph(self, output_file='rule_graph_full.png'):
        """Create full graph visualization"""
        plt.figure(figsize=(20, 15))
        
        # Get layout
        pos = self.create_hierarchical_layout()
        
        # Draw nodes by type
        for node_type, color in self.node_colors.items():
            nodes = [n for n, d in self.G.nodes(data=True) if d.get('type') == node_type]
            if nodes:
                nx.draw_networkx_nodes(self.G, pos, 
                                     nodelist=nodes,
                                     node_color=color,
                                     node_size=1000,
                                     alpha=0.8)
        
        # Draw edges
        nx.draw_networkx_edges(self.G, pos, 
                             edge_color='gray',
                             arrows=True,
                             arrowsize=20,
                             alpha=0.5)
        
        # Add labels
        labels = {n: d.get('label', n)[:20] + '...' if len(d.get('label', n)) > 20 else d.get('label', n) 
                  for n, d in self.G.nodes(data=True)}
        nx.draw_networkx_labels(self.G, pos, labels, font_size=8)
        
        # Add legend
        legend_elements = [mpatches.Patch(color=color, label=node_type) 
                          for node_type, color in self.node_colors.items()]
        plt.legend(handles=legend_elements, loc='upper right')
        
        plt.title("Rule Graph Visualization - Full View", fontsize=16, fontweight='bold')
        plt.axis('off')
        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"Full graph visualization saved to {output_file}")
    
    def visualize_rule_path(self, rule_id, output_file='rule_path.png'):
        """Visualize path for a specific rule"""
        plt.figure(figsize=(15, 10))
        
        # Find all connected nodes for the rule
        rule_node = f"SR_{rule_id}"
        if rule_node not in self.G:
            print(f"Rule {rule_id} not found")
            return
        
        # Get subgraph
        connected_nodes = set([rule_node])
        
        # Get all neighbors (both directions)
        for neighbor in nx.all_neighbors(self.G, rule_node):
            connected_nodes.add(neighbor)
            # For scenario identifications, also get base scenarios
            if neighbor.startswith('SI_'):
                for base_scenario in self.G.neighbors(neighbor):
                    if base_scenario.startswith('BS_'):
                        connected_nodes.add(base_scenario)
        
        subgraph = self.G.subgraph(connected_nodes)
        
        # Layout
        pos = nx.spring_layout(subgraph, k=3, iterations=50)
        
        # Draw nodes by type
        for node_type, color in self.node_colors.items():
            nodes = [n for n, d in subgraph.nodes(data=True) if d.get('type') == node_type]
            if nodes:
                nx.draw_networkx_nodes(subgraph, pos, 
                                     nodelist=nodes,
                                     node_color=color,
                                     node_size=2000,
                                     alpha=0.8)
        
        # Highlight the main rule
        nx.draw_networkx_nodes(subgraph, pos, 
                             nodelist=[rule_node],
                             node_color='red',
                             node_size=2500,
                             alpha=1.0)
        
        # Draw edges with labels
        nx.draw_networkx_edges(subgraph, pos, 
                             edge_color='gray',
                             arrows=True,
                             arrowsize=20,
                             alpha=0.6,
                             width=2)
        
        # Add edge labels
        edge_labels = nx.get_edge_attributes(subgraph, 'relationship')
        nx.draw_networkx_edge_labels(subgraph, pos, edge_labels, font_size=8)
        
        # Add node labels
        labels = {n: d.get('label', n) for n, d in subgraph.nodes(data=True)}
        nx.draw_networkx_labels(subgraph, pos, labels, font_size=10)
        
        plt.title(f"Rule Path Visualization: {rule_id}", fontsize=16, fontweight='bold')
        plt.axis('off')
        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"Rule path visualization saved to {output_file}")
    
    def generate_graph_statistics(self):
        """Generate statistics about the graph"""
        stats = {
            'Total Nodes': self.G.number_of_nodes(),
            'Total Edges': self.G.number_of_edges(),
            'Node Types': {}
        }
        
        # Count nodes by type
        for node, data in self.G.nodes(data=True):
            node_type = data.get('type', 'Unknown')
            stats['Node Types'][node_type] = stats['Node Types'].get(node_type, 0) + 1
        
        # Find most connected nodes
        degree_centrality = nx.degree_centrality(self.G)
        top_nodes = sorted(degree_centrality.items(), key=lambda x: x[1], reverse=True)[:5]
        
        print("\n=== Graph Statistics ===")
        print(f"Total Nodes: {stats['Total Nodes']}")
        print(f"Total Edges: {stats['Total Edges']}")
        print("\nNodes by Type:")
        for node_type, count in stats['Node Types'].items():
            print(f"  {node_type}: {count}")
        
        print("\nMost Connected Nodes:")
        for node, centrality in top_nodes:
            node_data = self.G.nodes[node]
            print(f"  {node_data.get('label', node)} ({node_data.get('type', 'Unknown')}): {centrality:.3f}")

if __name__ == "__main__":
    visualizer = RuleGraphVisualizer()
    
    print("Loading rules...")
    visualizer.load_rules()
    
    print("Creating visualizations...")
    visualizer.visualize_full_graph()
    visualizer.visualize_rule_path('MCS001', 'rule_path_MCS001.png')
    visualizer.visualize_rule_path('MCS002', 'rule_path_MCS002.png')
    visualizer.visualize_rule_path('MCS003', 'rule_path_MCS003.png')
    
    visualizer.generate_graph_statistics()