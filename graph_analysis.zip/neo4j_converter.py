import json
import os
from typing import Dict, List, Any
from neo4j import GraphDatabase
import networkx as nx
import matplotlib.pyplot as plt
from pyvis.network import Network

class RulesToNeo4jConverter:
    """Convert scenario and expansion rules to Neo4j graph database"""
    
    def __init__(self, uri: str = "bolt://localhost:7687", user: str = "neo4j", password: str = "password"):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        
    def close(self):
        self.driver.close()
        
    def clear_database(self):
        """Clear existing data"""
        with self.driver.session() as session:
            session.run("MATCH (n) DETACH DELETE n")
            
    def create_constraints(self):
        """Create uniqueness constraints"""
        with self.driver.session() as session:
            constraints = [
                "CREATE CONSTRAINT IF NOT EXISTS FOR (fa:FunctionalArea) REQUIRE fa.name IS UNIQUE",
                "CREATE CONSTRAINT IF NOT EXISTS FOR (sr:ScenarioRule) REQUIRE sr.ruleId IS UNIQUE",
                "CREATE CONSTRAINT IF NOT EXISTS FOR (si:ScenarioIdentification) REQUIRE si.name IS UNIQUE",
                "CREATE CONSTRAINT IF NOT EXISTS FOR (bs:BaseScenario) REQUIRE bs.name IS UNIQUE",
                "CREATE CONSTRAINT IF NOT EXISTS FOR (er:EnrichmentRule) REQUIRE er.ruleId IS UNIQUE",
                "CREATE CONSTRAINT IF NOT EXISTS FOR (df:DataField) REQUIRE df.name IS UNIQUE"
            ]
            for constraint in constraints:
                session.run(constraint)
                
    def import_scenario_rules(self, rules_dir: str = "rules/scenario_rules"):
        """Import scenario rules from JSON files"""
        for filename in os.listdir(rules_dir):
            if filename.endswith("_Rules.json"):
                filepath = os.path.join(rules_dir, filename)
                with open(filepath, 'r') as f:
                    data = json.load(f)
                    
                sheet_name = data["sheet_name_in_excel"]
                
                # Create FunctionalArea node
                with self.driver.session() as session:
                    session.run("""
                        MERGE (fa:FunctionalArea {name: $sheet_name})
                        SET fa.headerRow = $header_row,
                            fa.dataStartRow = $data_start_row,
                            fa.description = $description
                    """, sheet_name=sheet_name,
                         header_row=data["sheet_config"]["header_row"],
                         data_start_row=data["sheet_config"]["data_start_row"],
                         description=data["sheet_config"]["description"])
                    
                    # Create DataField nodes for columns
                    for column in data["columns_to_extract"]:
                        session.run("""
                            MERGE (df:DataField {name: $column})
                            MERGE (fa:FunctionalArea {name: $sheet_name})
                            MERGE (fa)-[:HAS_FIELD]->(df)
                        """, column=column, sheet_name=sheet_name)
                    
                    # Create ScenarioRule nodes
                    for rule in data["rules"]:
                        if rule["IsEnabled"]:
                            session.run("""
                                MERGE (sr:ScenarioRule {ruleId: $rule_id})
                                SET sr.priority = $priority,
                                    sr.scenarioIdentification = $scenario,
                                    sr.conditions = $conditions
                                MERGE (fa:FunctionalArea {name: $sheet_name})
                                MERGE (sr)-[:APPLIES_TO]->(fa)
                                MERGE (si:ScenarioIdentification {name: $scenario})
                                MERGE (sr)-[:PRODUCES]->(si)
                            """, rule_id=rule["RuleID"],
                                 priority=rule["Priority"],
                                 scenario=rule["ScenarioIdentification"],
                                 conditions=json.dumps(rule["conditions"]),
                                 sheet_name=sheet_name)
                            
                            # Create relationships to DataFields based on conditions
                            for field, condition in rule["conditions"].items():
                                session.run("""
                                    MERGE (sr:ScenarioRule {ruleId: $rule_id})
                                    MERGE (df:DataField {name: $field})
                                    MERGE (sr)-[:DEPENDS_ON {condition: $condition}]->(df)
                                """, rule_id=rule["RuleID"],
                                     field=field,
                                     condition=condition)
                                     
    def import_expansion_rules(self, filepath: str = "rules/expansion_rules.json"):
        """Import expansion rules"""
        with open(filepath, 'r') as f:
            data = json.load(f)
            
        with self.driver.session() as session:
            for sheet_name, scenarios in data.items():
                for scenario_name, config in scenarios.items():
                    # Link ScenarioIdentification to BaseScenarios
                    for base_scenario in config["base_scenarios"]:
                        session.run("""
                            MERGE (si:ScenarioIdentification {name: $scenario_name})
                            MERGE (bs:BaseScenario {name: $base_scenario})
                            SET bs.expectedStatus = $status
                            MERGE (si)-[:EXPANDS_TO]->(bs)
                        """, scenario_name=scenario_name,
                             base_scenario=base_scenario,
                             status=config["expected_status"])
                             
    def import_enrichment_rules(self, filepath: str = "rules/enrichment_rules.json"):
        """Import enrichment rules"""
        with open(filepath, 'r') as f:
            data = json.load(f)
            
        with self.driver.session() as session:
            for rule in data:
                session.run("""
                    MERGE (er:EnrichmentRule {ruleId: $rule_id})
                    SET er.sourceSheet = $source_sheet,
                        er.targetColumn = $target_column,
                        er.lookupLogic = $lookup_logic
                    MERGE (fa:FunctionalArea {name: $source_sheet})
                    MERGE (er)-[:ENRICHES_SHEET]->(fa)
                    MERGE (df:DataField {name: $target_column})
                    MERGE (er)-[:UPDATES_FIELD]->(df)
                """, rule_id=rule["rule_id"],
                     source_sheet=rule["source_sheet_name"],
                     target_column=rule["target_column_to_update"],
                     lookup_logic=json.dumps(rule["lookup_logic"]))
                     
    def visualize_graph(self, output_file: str = "rule_graph.html"):
        """Create interactive visualization using pyvis"""
        net = Network(height="800px", width="100%", directed=True)
        net.barnes_hut(gravity=-80000, central_gravity=0.3, spring_length=150)
        
        with self.driver.session() as session:
            # Get all nodes and relationships
            result = session.run("""
                MATCH (n)
                OPTIONAL MATCH (n)-[r]->(m)
                RETURN n, r, m
            """)
            
            nodes_added = set()
            
            for record in result:
                node = record["n"]
                rel = record["r"]
                target = record["m"]
                
                # Add source node
                if node.id not in nodes_added:
                    node_props = dict(node)
                    node_label = list(node.labels)[0]
                    
                    if node_label == "FunctionalArea":
                        net.add_node(node.id, label=node_props.get("name", ""), 
                                   color="#4CAF50", size=30, title=f"Functional Area: {node_props.get('name', '')}")
                    elif node_label == "ScenarioRule":
                        net.add_node(node.id, label=node_props.get("ruleId", ""), 
                                   color="#2196F3", size=20, title=f"Rule: {node_props.get('ruleId', '')}\nPriority: {node_props.get('priority', '')}")
                    elif node_label == "ScenarioIdentification":
                        net.add_node(node.id, label=node_props.get("name", "")[:20] + "...", 
                                   color="#FF9800", size=15, title=f"Scenario: {node_props.get('name', '')}")
                    elif node_label == "BaseScenario":
                        net.add_node(node.id, label=node_props.get("name", ""), 
                                   color="#9C27B0", size=15, title=f"Base Scenario: {node_props.get('name', '')}")
                    elif node_label == "DataField":
                        net.add_node(node.id, label=node_props.get("name", ""), 
                                   color="#607D8B", size=10, title=f"Field: {node_props.get('name', '')}")
                    elif node_label == "EnrichmentRule":
                        net.add_node(node.id, label=node_props.get("ruleId", ""), 
                                   color="#795548", size=20, title=f"Enrichment: {node_props.get('ruleId', '')}")
                    
                    nodes_added.add(node.id)
                
                # Add target node and relationship
                if target and rel:
                    if target.id not in nodes_added:
                        target_props = dict(target)
                        target_label = list(target.labels)[0]
                        
                        if target_label == "DataField":
                            net.add_node(target.id, label=target_props.get("name", ""), 
                                       color="#607D8B", size=10, title=f"Field: {target_props.get('name', '')}")
                        elif target_label == "BaseScenario":
                            net.add_node(target.id, label=target_props.get("name", ""), 
                                       color="#9C27B0", size=15, title=f"Base Scenario: {target_props.get('name', '')}")
                        # Add other node types as needed
                        nodes_added.add(target.id)
                    
                    # Add edge
                    rel_type = type(rel).__name__
                    net.add_edge(node.id, target.id, label=rel_type, color="#999999")
        
        # Save visualization
        net.show(output_file)
        print(f"Graph visualization saved to {output_file}")
        
    def generate_cypher_queries(self, output_file: str = "neo4j_queries.cypher"):
        """Generate useful Cypher queries for analysis"""
        queries = """
// ========================================
// Neo4j Cypher Queries for Rule Analysis
// ========================================

// 1. Find all rules for a specific functional area
MATCH (sr:ScenarioRule)-[:APPLIES_TO]->(fa:FunctionalArea {name: 'Member Cost Share'})
RETURN sr.ruleId, sr.priority, sr.scenarioIdentification
ORDER BY sr.priority;

// 2. Trace the complete path from rule to base scenarios
MATCH path = (sr:ScenarioRule)-[:PRODUCES]->(si:ScenarioIdentification)-[:EXPANDS_TO]->(bs:BaseScenario)
WHERE sr.ruleId = 'MCS001'
RETURN path;

// 3. Find all fields that a rule depends on
MATCH (sr:ScenarioRule {ruleId: 'MCS001'})-[dep:DEPENDS_ON]->(df:DataField)
RETURN df.name, dep.condition;

// 4. Find overlapping rules (rules with similar conditions)
MATCH (sr1:ScenarioRule)-[:DEPENDS_ON]->(df:DataField)<-[:DEPENDS_ON]-(sr2:ScenarioRule)
WHERE sr1.ruleId < sr2.ruleId
WITH sr1, sr2, COUNT(df) as sharedFields
WHERE sharedFields > 3
RETURN sr1.ruleId, sr2.ruleId, sharedFields
ORDER BY sharedFields DESC;

// 5. Find scenario identifications that expand to multiple base scenarios
MATCH (si:ScenarioIdentification)-[:EXPANDS_TO]->(bs:BaseScenario)
WITH si, COUNT(bs) as baseCount, COLLECT(bs.name) as baseScenarios
WHERE baseCount > 1
RETURN si.name, baseCount, baseScenarios
ORDER BY baseCount DESC;

// 6. Impact analysis: What scenarios are affected by a specific field?
MATCH (df:DataField {name: 'Copay Amount - Percent'})<-[:DEPENDS_ON]-(sr:ScenarioRule)-[:PRODUCES]->(si:ScenarioIdentification)
RETURN DISTINCT si.name;

// 7. Find enrichment rules and their targets
MATCH (er:EnrichmentRule)-[:UPDATES_FIELD]->(df:DataField)
RETURN er.ruleId, er.sourceSheet, df.name as targetField;

// 8. Visualize the rule hierarchy for a functional area
MATCH path = (fa:FunctionalArea {name: 'Member Cost Share'})<-[:APPLIES_TO]-(sr:ScenarioRule)-[:PRODUCES]->(si:ScenarioIdentification)-[:EXPANDS_TO]->(bs:BaseScenario)
RETURN path;

// 9. Find unused scenario identifications (no expansion rules)
MATCH (si:ScenarioIdentification)
WHERE NOT (si)-[:EXPANDS_TO]->()
RETURN si.name;

// 10. Rule coverage analysis
MATCH (fa:FunctionalArea)
OPTIONAL MATCH (fa)<-[:APPLIES_TO]-(sr:ScenarioRule)
WITH fa, COUNT(sr) as ruleCount
RETURN fa.name, ruleCount
ORDER BY ruleCount DESC;
"""
        
        with open(output_file, 'w') as f:
            f.write(queries)
        print(f"Cypher queries saved to {output_file}")

if __name__ == "__main__":
    # Initialize converter
    converter = RulesToNeo4jConverter()
    
    try:
        # Setup database
        print("Clearing existing data...")
        converter.clear_database()
        
        print("Creating constraints...")
        converter.create_constraints()
        
        # Import data
        print("Importing scenario rules...")
        converter.import_scenario_rules()
        
        print("Importing expansion rules...")
        converter.import_expansion_rules()
        
        print("Importing enrichment rules...")
        converter.import_enrichment_rules()
        
        # Generate outputs
        print("Creating visualization...")
        converter.visualize_graph()
        
        print("Generating Cypher queries...")
        converter.generate_cypher_queries()
        
        print("\nConversion complete! Check rule_graph.html for visualization.")
        
    finally:
        converter.close()