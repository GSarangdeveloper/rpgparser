# Rule Graph Visualization

```mermaid
graph TD
    %% Functional Area
    FA[Member Cost Share<br/>Functional Area]
    style FA fill:#4CAF50,stroke:#333,stroke-width:2px,color:#fff
    
    %% Scenario Rules
    SR1[MCS001<br/>Priority: 1]
    SR2[MCS002<br/>Priority: 2]
    SR3[MCS003<br/>Priority: 3]
    style SR1 fill:#2196F3,stroke:#333,stroke-width:2px,color:#fff
    style SR2 fill:#2196F3,stroke:#333,stroke-width:2px,color:#fff
    style SR3 fill:#2196F3,stroke:#333,stroke-width:2px,color:#fff
    
    %% Scenario Identifications
    SI1[DC_Flat Copay<br/>Extended Cycle]
    SI2[DC_Flat Coinsurance<br/>Extended Cycle]
    SI3[DC_Coinsurance with Min<br/>Extended Cycle]
    style SI1 fill:#FF9800,stroke:#333,stroke-width:2px,color:#fff
    style SI2 fill:#FF9800,stroke:#333,stroke-width:2px,color:#fff
    style SI3 fill:#FF9800,stroke:#333,stroke-width:2px,color:#fff
    
    %% Base Scenarios
    BS1[Verify_Copay]
    BS2[Verify_Coinsurance]
    BS3[Verify_Min Copay]
    BS4[Verify_Max Copay]
    style BS1 fill:#9C27B0,stroke:#333,stroke-width:2px,color:#fff
    style BS2 fill:#9C27B0,stroke:#333,stroke-width:2px,color:#fff
    style BS3 fill:#9C27B0,stroke:#333,stroke-width:2px,color:#fff
    style BS4 fill:#9C27B0,stroke:#333,stroke-width:2px,color:#fff
    
    %% Enrichment Rule
    ER1[ENRICH_MCS_COPAY_MAX_DAYS<br/>Enrichment Rule]
    style ER1 fill:#795548,stroke:#333,stroke-width:2px,color:#fff
    
    %% Data Fields (subset for clarity)
    DF1[Copay Category]
    DF2[Copay Amount - Percent]
    DF3[Copay Max Days Supply]
    style DF1 fill:#607D8B,stroke:#333,stroke-width:2px,color:#fff
    style DF2 fill:#607D8B,stroke:#333,stroke-width:2px,color:#fff
    style DF3 fill:#607D8B,stroke:#333,stroke-width:2px,color:#fff
    
    %% Relationships
    SR1 -->|APPLIES_TO| FA
    SR2 -->|APPLIES_TO| FA
    SR3 -->|APPLIES_TO| FA
    
    SR1 -->|PRODUCES| SI1
    SR2 -->|PRODUCES| SI2
    SR3 -->|PRODUCES| SI3
    
    SI1 -->|EXPANDS_TO| BS1
    SI2 -->|EXPANDS_TO| BS2
    SI3 -->|EXPANDS_TO| BS2
    SI3 -->|EXPANDS_TO| BS3
    
    SR1 -->|DEPENDS_ON| DF1
    SR1 -->|DEPENDS_ON| DF2
    SR2 -->|DEPENDS_ON| DF1
    SR2 -->|DEPENDS_ON| DF2
    SR3 -->|DEPENDS_ON| DF1
    SR3 -->|DEPENDS_ON| DF2
    
    ER1 -->|ENRICHES_SHEET| FA
    ER1 -->|UPDATES_FIELD| DF3
    
    FA -->|HAS_FIELD| DF1
    FA -->|HAS_FIELD| DF2
    FA -->|HAS_FIELD| DF3
    
```

## Legend
- **Green**: Functional Areas
- **Blue**: Scenario Rules
- **Orange**: Scenario Identifications
- **Purple**: Base Scenarios
- **Gray**: Data Fields
- **Brown**: Enrichment Rules
