#!/usr/bin/env python3
"""
Figma Component Extractor - MCP Server
Hosted MCP server that exposes Figma extraction as tools for any MCP client
"""

import asyncio
import logging
from typing import Any
from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions, Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
)
import os
from dotenv import load_dotenv

# Import our extraction logic
from figma_extractor.core.extractor import ComponentExtractor
from figma_extractor.core.enterprise_formatter import EnterpriseAPIFormatter
from figma_extractor.config import Config

# Load environment
load_dotenv()
config = Config.from_env()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("figma-mcp-server")

# Create MCP server
server = Server("figma-component-extractor")


@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """
    List available MCP tools.
    These tools will appear in Claude Desktop and other MCP clients.
    """
    return [
        Tool(
            name="extract_figma_components",
            description="""
                Extract UI components from a Figma design file.

                This tool automatically:
                1. Analyzes Figma file via API (finds components in file structure)
                2. Exports screens/frames as images
                3. Analyzes images with AI vision (Gemini)
                4. Merges both results for comprehensive extraction
                5. Returns a complete list of all UI components

                Supports 38+ component types including:
                - Buttons, inputs, selects, checkboxes, radios
                - Navigation (navbar, sidebar, tabs, breadcrumbs)
                - Content (cards, tables, lists, accordions)
                - Feedback (modals, alerts, toasts, badges)
                - And many more...

                Returns JSON with extraction method, component list, and metadata.
            """,
            inputSchema={
                "type": "object",
                "properties": {
                    "figma_url": {
                        "type": "string",
                        "description": "The Figma file URL (https://www.figma.com/file/...) or file key"
                    },
                    "pat_token": {
                        "type": "string",
                        "description": "Figma Personal Access Token (optional if set in environment)"
                    },
                    "max_frames": {
                        "type": "integer",
                        "description": "Maximum number of frames to export and analyze (default: 5)",
                        "default": 5
                    },
                    "use_vision": {
                        "type": "boolean",
                        "description": "Whether to use AI vision analysis for better accuracy (default: true)",
                        "default": True
                    }
                },
                "required": ["figma_url"]
            },
        ),
        Tool(
            name="extract_figma_for_enterprise",
            description="""
                Extract components from Figma and format for enterprise code generation APIs.

                This tool does everything extract_figma_components does, but formats the output
                specifically for enterprise APIs that generate Angular/React/Vue components.

                Returns a structured payload with:
                - Component requirements with framework/version
                - Features for each component (sorting, pagination, etc.)
                - Subcomponents for complex components
                - Ready to send to code generation APIs
            """,
            inputSchema={
                "type": "object",
                "properties": {
                    "figma_url": {
                        "type": "string",
                        "description": "The Figma file URL or file key"
                    },
                    "pat_token": {
                        "type": "string",
                        "description": "Figma Personal Access Token (optional if set in environment)"
                    },
                    "framework": {
                        "type": "string",
                        "description": "Target framework (angular, react, vue)",
                        "default": "angular"
                    },
                    "version": {
                        "type": "string",
                        "description": "Framework version (e.g., 17 for Angular)",
                        "default": "17"
                    }
                },
                "required": ["figma_url"]
            },
        ),
        Tool(
            name="list_supported_components",
            description="""
                Get a list of all supported component types that can be detected.

                Returns 38+ component types that the extractor can identify, including:
                - Action components (button, fab, icon-button)
                - Form components (text-input, select, checkbox, etc.)
                - Navigation components (navbar, sidebar, tabs, etc.)
                - Content components (card, table, list, etc.)
                - Feedback components (modal, alert, toast, etc.)
                - Media components (avatar, image, video, etc.)

                Useful for understanding what the extractor can detect.
            """,
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            },
        ),
    ]


@server.call_tool()
async def handle_call_tool(name: str, arguments: dict | None) -> list[TextContent | ImageContent | EmbeddedResource]:
    """
    Handle tool execution.
    """
    try:
        if name == "extract_figma_components":
            return await extract_figma_components(arguments or {})
        elif name == "extract_figma_for_enterprise":
            return await extract_figma_for_enterprise(arguments or {})
        elif name == "list_supported_components":
            return await list_supported_components()
        else:
            raise ValueError(f"Unknown tool: {name}")
    except Exception as e:
        logger.error(f"Tool execution error: {e}", exc_info=True)
        return [TextContent(
            type="text",
            text=f"Error: {str(e)}"
        )]


async def extract_figma_components(args: dict) -> list[TextContent]:
    """Extract components from Figma with dual-method approach."""
    figma_url = args.get("figma_url")
    pat_token = args.get("pat_token") or config.figma_pat_token
    max_frames = args.get("max_frames", 5)
    use_vision = args.get("use_vision", True)

    if not figma_url:
        return [TextContent(
            type="text",
            text="Error: figma_url is required"
        )]

    if not pat_token:
        return [TextContent(
            type="text",
            text="Error: pat_token is required (provide in arguments or set FIGMA_PAT_TOKEN environment variable)"
        )]

    logger.info(f"Extracting components from: {figma_url}")

    # Create extractor
    gemini_key = config.gemini_api_key if use_vision else None
    extractor = ComponentExtractor(
        figma_token=pat_token,
        gemini_key=gemini_key,
        confidence_threshold=config.confidence_threshold
    )

    # Extract with automatic dual-method if vision enabled
    if use_vision and gemini_key:
        result = extractor.extract_with_auto_vision(figma_url, max_frames)
    else:
        result = extractor.extract_simple(figma_url)

    # Format response
    import json
    response_text = json.dumps(result, indent=2)

    return [TextContent(
        type="text",
        text=response_text
    )]


async def extract_figma_for_enterprise(args: dict) -> list[TextContent]:
    """Extract components and format for enterprise API."""
    figma_url = args.get("figma_url")
    pat_token = args.get("pat_token") or config.figma_pat_token
    framework = args.get("framework", "angular")
    version = args.get("version", "17")

    if not figma_url:
        return [TextContent(
            type="text",
            text="Error: figma_url is required"
        )]

    if not pat_token:
        return [TextContent(
            type="text",
            text="Error: pat_token is required"
        )]

    logger.info(f"Extracting components for enterprise API: {figma_url}")

    # Extract components (simple method for now)
    extractor = ComponentExtractor(
        figma_token=pat_token,
        confidence_threshold=config.confidence_threshold
    )

    result = extractor.extract_simple(figma_url)

    if result.get("status") != "success":
        return [TextContent(
            type="text",
            text=f"Error: {result.get('error', 'Extraction failed')}"
        )]

    # Format for enterprise
    formatter = EnterpriseAPIFormatter(framework=framework, version=version)
    enterprise_format = formatter.format_for_enterprise_api(
        components=result.get("components", [])
    )

    import json
    response_text = json.dumps(enterprise_format, indent=2)

    return [TextContent(
        type="text",
        text=response_text
    )]


async def list_supported_components() -> list[TextContent]:
    """List all supported component types."""
    from figma_extractor.core.component_patterns import get_all_component_types

    component_types = get_all_component_types()

    import json
    response = {
        "supported_components": component_types,
        "count": len(component_types),
        "categories": {
            "action": ["button", "fab", "icon-button"],
            "form": ["text-input", "select", "checkbox", "radio", "switch", "slider", "date-picker", "time-picker", "file-upload", "form"],
            "navigation": ["navbar", "sidebar", "tabs", "breadcrumb", "pagination", "menu", "stepper"],
            "content": ["card", "list", "table", "accordion", "carousel", "timeline", "tree-view"],
            "feedback": ["alert", "modal", "tooltip", "toast", "badge", "progress-bar", "spinner", "skeleton"],
            "media": ["avatar", "image", "video", "audio", "icon"],
            "data-viz": ["chart", "gauge", "map"]
        }
    }

    response_text = json.dumps(response, indent=2)

    return [TextContent(
        type="text",
        text=response_text
    )]


async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="figma-component-extractor",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
