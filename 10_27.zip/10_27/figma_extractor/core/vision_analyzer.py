"""AI Vision analysis for component detection"""

import logging
import json
import re
from typing import Dict, List, Optional, Any
import base64
import requests

logger = logging.getLogger(__name__)


# Comprehensive Gemini Vision prompt for component detection
GEMINI_VISION_PROMPT = """You are an expert UI/UX component identifier. Analyze this interface design screenshot and identify ALL UI components present.

CRITICAL INSTRUCTIONS:
1. Identify ONLY actual UI components, not layout containers
2. Look for both obvious and subtle components
3. Consider component states (hover, active, disabled)
4. Identify nested components within larger components

COMPONENT CATEGORIES TO IDENTIFY:

ACTION COMPONENTS:
- button (any clickable button including primary, secondary, text, icon buttons)
- fab (floating action button)
- icon-button (standalone clickable icons)

FORM COMPONENTS:
- text-input (text fields, input boxes, form fields)
- select (dropdowns, select boxes)
- checkbox (checkboxes, tick boxes)
- radio (radio buttons, option selectors)
- switch (toggle switches, on/off toggles)
- slider (range sliders, value selectors)
- date-picker (date selectors, calendar inputs)
- time-picker (time selectors)
- file-upload (file upload areas, drag-drop zones)
- form (complete form containers)

NAVIGATION COMPONENTS:
- navbar (top navigation bars, headers)
- sidebar (side navigation, drawers)
- tabs (tab bars, tab navigation)
- breadcrumb (breadcrumb navigation)
- pagination (page navigation, page numbers)
- menu (menu items, dropdown menus)
- stepper (step indicators, progress steps)

CONTENT DISPLAY:
- card (content cards, tiles, panels)
- list (lists, list items)
- table (data tables, grids)
- accordion (collapsible sections, expandables)
- carousel (image sliders, content sliders)
- timeline (timeline displays)
- tree-view (hierarchical views)

FEEDBACK COMPONENTS:
- alert (alert messages, warnings)
- modal (modals, dialogs, popups)
- tooltip (tooltips, hover hints)
- toast (toast notifications, snackbars)
- badge (badges, chips, tags, labels)
- progress-bar (progress indicators, loading bars)
- spinner (loading spinners, circular progress)
- skeleton (skeleton loaders, placeholders)

MEDIA COMPONENTS:
- avatar (user avatars, profile pictures)
- image (images, photos, illustrations)
- video (video players, media players)
- audio (audio players)
- icon (standalone icons, not buttons)

DATA VISUALIZATION:
- chart (charts, graphs, data visualizations)
- gauge (gauges, meters, indicators)
- map (maps, location displays)

ANALYSIS APPROACH:
1. Scan the entire image systematically from top to bottom
2. Identify primary components first (navbar, cards, buttons)
3. Look for form elements within sections
4. Check for feedback components (modals, alerts)
5. Identify any data display components (tables, lists)

OUTPUT FORMAT:
Return ONLY a JSON object with this exact structure:
{
  "components": ["component1", "component2", "component3"],
  "confidence_notes": {
    "high": ["components you're certain about"],
    "medium": ["components you're reasonably sure about"],
    "low": ["components you're uncertain about"]
  }
}

Use ONLY the component names listed above. Do not create new component names.
If you see a component that doesn't match exactly, use the closest matching type.

Analyze the image now and return the JSON response:"""


class GeminiVisionAnalyzer:
    """Analyzer using Google Gemini Vision API"""

    def __init__(self, api_key: str):
        """
        Initialize Gemini Vision analyzer.

        Args:
            api_key: Google Gemini API key
        """
        self.api_key = api_key
        self.api_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

    def analyze_image_url(self, image_url: str) -> Dict[str, Any]:
        """
        Analyze image from URL using Gemini Vision.

        Args:
            image_url: URL of image to analyze

        Returns:
            Analysis results dict
        """
        try:
            # Download image
            response = requests.get(image_url, timeout=30)
            response.raise_for_status()
            image_data = response.content

            # Convert to base64
            image_base64 = base64.b64encode(image_data).decode('utf-8')

            return self.analyze_image_base64(image_base64)

        except Exception as e:
            logger.error(f"Error analyzing image from URL: {e}")
            return {
                "success": False,
                "error": str(e),
                "components": []
            }

    def analyze_image_base64(self, image_base64: str, mime_type: str = "image/png") -> Dict[str, Any]:
        """
        Analyze base64 encoded image using Gemini Vision.

        Args:
            image_base64: Base64 encoded image
            mime_type: Image MIME type

        Returns:
            Analysis results dict
        """
        try:
            # Prepare request
            request_data = {
                "contents": [{
                    "parts": [
                        {
                            "text": GEMINI_VISION_PROMPT
                        },
                        {
                            "inline_data": {
                                "mime_type": mime_type,
                                "data": image_base64
                            }
                        }
                    ]
                }],
                "generationConfig": {
                    "temperature": 0.2,
                    "topK": 32,
                    "topP": 1,
                    "maxOutputTokens": 2048
                }
            }

            # Make API call
            url = f"{self.api_url}?key={self.api_key}"
            response = requests.post(url, json=request_data, timeout=60)
            response.raise_for_status()

            result = response.json()

            # Extract text from response
            if "candidates" in result and len(result["candidates"]) > 0:
                candidate = result["candidates"][0]
                if "content" in candidate and "parts" in candidate["content"]:
                    text = candidate["content"]["parts"][0].get("text", "")
                    return self._parse_response(text)

            return {
                "success": False,
                "error": "No response from Gemini",
                "components": []
            }

        except Exception as e:
            logger.error(f"Error analyzing image with Gemini: {e}")
            return {
                "success": False,
                "error": str(e),
                "components": []
            }

    def _parse_response(self, text: str) -> Dict[str, Any]:
        """
        Parse JSON response from Gemini.

        Args:
            text: Response text

        Returns:
            Parsed results dict
        """
        try:
            # Try to find JSON in the response
            json_match = re.search(r'\{[\s\S]*\}', text)
            if json_match:
                json_str = json_match.group(0)
                data = json.loads(json_str)

                components = data.get("components", [])
                confidence_notes = data.get("confidence_notes", {})

                # Calculate confidence for each component
                component_confidences = {}
                for comp in components:
                    if comp in confidence_notes.get("high", []):
                        component_confidences[comp] = 0.9
                    elif comp in confidence_notes.get("medium", []):
                        component_confidences[comp] = 0.75
                    elif comp in confidence_notes.get("low", []):
                        component_confidences[comp] = 0.6
                    else:
                        component_confidences[comp] = 0.7  # Default

                return {
                    "success": True,
                    "method": "gemini_vision",
                    "components": components,
                    "confidence_scores": component_confidences,
                    "confidence_notes": confidence_notes
                }

            # Fallback: try to extract component names from text
            return self._fallback_parse(text)

        except json.JSONDecodeError as e:
            logger.error(f"Error parsing JSON response: {e}")
            return self._fallback_parse(text)

    def _fallback_parse(self, text: str) -> Dict[str, Any]:
        """
        Fallback parsing when JSON extraction fails.

        Args:
            text: Response text

        Returns:
            Parsed results dict
        """
        # Try to find component names in text
        from .component_patterns import get_all_component_types

        found_components = []
        component_types = get_all_component_types()

        for comp_type in component_types:
            if comp_type in text.lower():
                found_components.append(comp_type)

        return {
            "success": len(found_components) > 0,
            "method": "gemini_vision_fallback",
            "components": found_components,
            "confidence_scores": {comp: 0.5 for comp in found_components},
            "note": "Fallback parsing used"
        }


class VisionAnalyzerFactory:
    """Factory for creating vision analyzers"""

    @staticmethod
    def create_analyzer(api_key: str, analyzer_type: str = "gemini"):
        """
        Create vision analyzer instance.

        Args:
            api_key: API key for the service
            analyzer_type: Type of analyzer (gemini, openai)

        Returns:
            Analyzer instance
        """
        if analyzer_type == "gemini":
            return GeminiVisionAnalyzer(api_key)
        else:
            raise ValueError(f"Unsupported analyzer type: {analyzer_type}")


def analyze_figma_screenshot(image_url: str, api_key: str, analyzer_type: str = "gemini") -> Dict[str, Any]:
    """
    Convenience function to analyze Figma screenshot.

    Args:
        image_url: URL of Figma screenshot
        api_key: API key for vision service
        analyzer_type: Type of analyzer to use

    Returns:
        Analysis results dict
    """
    analyzer = VisionAnalyzerFactory.create_analyzer(api_key, analyzer_type)
    return analyzer.analyze_image_url(image_url)


def analyze_multiple_images(image_urls: List[str], api_key: str, analyzer_type: str = "gemini") -> Dict[str, Any]:
    """
    Analyze multiple Figma images and aggregate results.

    Args:
        image_urls: List of image URLs to analyze
        api_key: API key for vision service
        analyzer_type: Type of analyzer to use

    Returns:
        Aggregated analysis results
    """
    analyzer = VisionAnalyzerFactory.create_analyzer(api_key, analyzer_type)

    all_components = set()
    confidence_scores = {}
    analysis_results = []

    logger.info(f"Analyzing {len(image_urls)} images...")

    for i, image_url in enumerate(image_urls, 1):
        logger.info(f"Analyzing image {i}/{len(image_urls)}")

        result = analyzer.analyze_image_url(image_url)

        if result.get("success"):
            components = result.get("components", [])
            scores = result.get("confidence_scores", {})

            # Add to aggregate
            all_components.update(components)

            # Update confidence scores (keep highest)
            for comp, score in scores.items():
                if comp not in confidence_scores or score > confidence_scores[comp]:
                    confidence_scores[comp] = score

            analysis_results.append({
                "image_index": i,
                "components": components,
                "success": True
            })
        else:
            logger.warning(f"Failed to analyze image {i}: {result.get('error')}")
            analysis_results.append({
                "image_index": i,
                "success": False,
                "error": result.get("error")
            })

    return {
        "success": len(all_components) > 0,
        "method": "gemini_vision_multiple",
        "components": list(all_components),
        "confidence_scores": confidence_scores,
        "images_analyzed": len(image_urls),
        "successful_analyses": sum(1 for r in analysis_results if r.get("success")),
        "analysis_results": analysis_results
    }
