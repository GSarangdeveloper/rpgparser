"""Core extraction modules"""
