"""Component detection patterns and rules"""

import re
from typing import List, Dict, Any, Optional


# Complete component mapping with detection patterns
COMPONENT_PATTERNS = {
    # Action Components
    "button": {
        "patterns": [
            r"^(btn|button)",
            r"button$",
            r"(primary|secondary|tertiary)[\s_-]?(btn|button)",
            r"cta[\s_-]?button",
            r"action[\s_-]?button"
        ],
        "exclude": [r"button[\s_-]?group"],
        "priority": 10,
        "visual_cues": ["rounded rectangle", "centered text", "elevation"],
        "min_confidence": 0.7
    },

    "fab": {
        "patterns": [
            r"^fab",
            r"floating[\s_-]?action",
            r"^float"
        ],
        "exclude": [],
        "priority": 9,
        "visual_cues": ["circular", "elevated", "corner position"],
        "min_confidence": 0.8
    },

    "icon-button": {
        "patterns": [
            r"icon[\s_-]?button",
            r"^icon[\s_-]?btn"
        ],
        "exclude": [],
        "priority": 8,
        "visual_cues": ["small", "circular or square", "icon only"],
        "min_confidence": 0.75
    },

    # Form Components
    "text-input": {
        "patterns": [
            r"^(input|textfield|text[\s_-]?field)",
            r"^(form[\s_-]?)?(field|input)",
            r"(email|password|search)[\s_-]?(field|input)"
        ],
        "exclude": [r"input[\s_-]?group", r"checkbox", r"radio"],
        "priority": 9,
        "visual_cues": ["rectangle outline", "placeholder text", "label"],
        "min_confidence": 0.75
    },

    "select": {
        "patterns": [
            r"^(select|dropdown|picker)",
            r"drop[\s_-]?down",
            r"combo[\s_-]?box"
        ],
        "exclude": [r"date[\s_-]?picker", r"time[\s_-]?picker"],
        "priority": 8,
        "visual_cues": ["dropdown arrow", "rectangular", "options"],
        "min_confidence": 0.7
    },

    "checkbox": {
        "patterns": [
            r"^checkbox",
            r"^check[\s_-]?box",
            r"check$"
        ],
        "exclude": [],
        "priority": 9,
        "visual_cues": ["square", "checkmark", "label beside"],
        "min_confidence": 0.85
    },

    "radio": {
        "patterns": [
            r"^radio",
            r"radio[\s_-]?button"
        ],
        "exclude": [],
        "priority": 9,
        "visual_cues": ["circular", "dot center", "grouped"],
        "min_confidence": 0.85
    },

    "switch": {
        "patterns": [
            r"^switch",
            r"^toggle"
        ],
        "exclude": [],
        "priority": 8,
        "visual_cues": ["pill shape", "thumb indicator"],
        "min_confidence": 0.8
    },

    "slider": {
        "patterns": [
            r"^slider",
            r"^range"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["horizontal line", "thumb control"],
        "min_confidence": 0.75
    },

    "date-picker": {
        "patterns": [
            r"date[\s_-]?picker",
            r"^calendar",
            r"date[\s_-]?input"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["calendar icon", "date format"],
        "min_confidence": 0.7
    },

    "time-picker": {
        "patterns": [
            r"time[\s_-]?picker",
            r"time[\s_-]?input"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["clock icon", "time format"],
        "min_confidence": 0.7
    },

    "file-upload": {
        "patterns": [
            r"file[\s_-]?upload",
            r"upload[\s_-]?button",
            r"file[\s_-]?input",
            r"drop[\s_-]?zone"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["dashed border", "upload icon"],
        "min_confidence": 0.7
    },

    "form": {
        "patterns": [
            r"^form$",
            r"^form[\s_-]?container"
        ],
        "exclude": [r"form[\s_-]?field", r"form[\s_-]?input"],
        "priority": 5,
        "visual_cues": ["multiple inputs", "submit button"],
        "min_confidence": 0.65
    },

    # Navigation Components
    "navbar": {
        "patterns": [
            r"^nav(bar)?$",
            r"navigation",
            r"^header$",
            r"top[\s_-]?bar"
        ],
        "exclude": [r"nav[\s_-]?item", r"nav[\s_-]?link"],
        "priority": 6,
        "visual_cues": ["top position", "horizontal", "logo"],
        "min_confidence": 0.75
    },

    "sidebar": {
        "patterns": [
            r"^sidebar",
            r"^drawer",
            r"side[\s_-]?nav"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["vertical", "left/right position"],
        "min_confidence": 0.75
    },

    "tabs": {
        "patterns": [
            r"^tabs?$",
            r"tab[\s_-]?bar"
        ],
        "exclude": [r"tab[\s_-]?panel", r"table"],
        "priority": 7,
        "visual_cues": ["horizontal items", "underline"],
        "min_confidence": 0.8
    },

    "breadcrumb": {
        "patterns": [
            r"^breadcrumb",
            r"bread[\s_-]?crumbs"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["separator symbols", "hierarchical"],
        "min_confidence": 0.75
    },

    "pagination": {
        "patterns": [
            r"^pagination",
            r"^pager"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["number sequence", "prev/next"],
        "min_confidence": 0.8
    },

    "menu": {
        "patterns": [
            r"^menu$",
            r"^dropdown[\s_-]?menu"
        ],
        "exclude": [r"menu[\s_-]?item"],
        "priority": 6,
        "visual_cues": ["vertical list", "menu items"],
        "min_confidence": 0.7
    },

    "stepper": {
        "patterns": [
            r"^stepper",
            r"^steps",
            r"step[\s_-]?indicator"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["numbered steps", "progress line"],
        "min_confidence": 0.75
    },

    # Content Display
    "card": {
        "patterns": [
            r"^card",
            r"card$",
            r"(product|user|info)[\s_-]?card",
            r"^(panel|tile)$"
        ],
        "exclude": [r"card[\s_-]?header", r"card[\s_-]?footer"],
        "priority": 7,
        "visual_cues": ["rectangular", "elevation", "contained"],
        "min_confidence": 0.7
    },

    "list": {
        "patterns": [
            r"^list$",
            r"^list[\s_-]?view"
        ],
        "exclude": [r"list[\s_-]?item"],
        "priority": 6,
        "visual_cues": ["vertical items", "repeated structure"],
        "min_confidence": 0.65
    },

    "table": {
        "patterns": [
            r"^table$",
            r"data[\s_-]?table",
            r"data[\s_-]?grid",
            r"^grid$"
        ],
        "exclude": [r"table[\s_-]?row", r"table[\s_-]?cell", r"grid[\s_-]?item"],
        "priority": 5,
        "visual_cues": ["rows and columns", "headers", "borders"],
        "min_confidence": 0.8
    },

    "accordion": {
        "patterns": [
            r"^accordion",
            r"expand[\s_-]?panel",
            r"collapse"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["expandable sections", "chevron icons"],
        "min_confidence": 0.75
    },

    "carousel": {
        "patterns": [
            r"^carousel",
            r"^slider$",
            r"image[\s_-]?slider"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["sliding images", "navigation dots"],
        "min_confidence": 0.75
    },

    "timeline": {
        "patterns": [
            r"^timeline"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["chronological line", "events"],
        "min_confidence": 0.7
    },

    "tree-view": {
        "patterns": [
            r"tree[\s_-]?view",
            r"^tree$"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["hierarchical", "expandable nodes"],
        "min_confidence": 0.7
    },

    # Feedback Components
    "alert": {
        "patterns": [
            r"^alert",
            r"notification",
            r"message[\s_-]?box"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["colored background", "icon", "message"],
        "min_confidence": 0.75
    },

    "modal": {
        "patterns": [
            r"^modal$",
            r"^dialog",
            r"^popup"
        ],
        "exclude": [r"modal[\s_-]?header", r"modal[\s_-]?footer"],
        "priority": 4,
        "visual_cues": ["overlay", "centered", "backdrop"],
        "min_confidence": 0.8
    },

    "tooltip": {
        "patterns": [
            r"^tooltip",
            r"^hint"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["small popup", "arrow pointer"],
        "min_confidence": 0.65
    },

    "toast": {
        "patterns": [
            r"^toast",
            r"^snackbar"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["bottom position", "temporary"],
        "min_confidence": 0.7
    },

    "badge": {
        "patterns": [
            r"^badge",
            r"^chip",
            r"^tag$",
            r"^label$"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["small", "rounded", "text/number"],
        "min_confidence": 0.7
    },

    "progress-bar": {
        "patterns": [
            r"progress[\s_-]?bar",
            r"^progress$",
            r"loading[\s_-]?bar"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["horizontal bar", "fill indicator"],
        "min_confidence": 0.8
    },

    "spinner": {
        "patterns": [
            r"^spinner",
            r"^loader",
            r"loading[\s_-]?spinner"
        ],
        "exclude": [],
        "priority": 7,
        "visual_cues": ["circular", "rotating"],
        "min_confidence": 0.75
    },

    "skeleton": {
        "patterns": [
            r"skeleton",
            r"placeholder",
            r"shimmer"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["gray bars", "loading placeholder"],
        "min_confidence": 0.7
    },

    # Media Components
    "avatar": {
        "patterns": [
            r"^avatar",
            r"profile[\s_-]?(pic|picture|image)"
        ],
        "exclude": [],
        "priority": 8,
        "visual_cues": ["circular/square", "user representation"],
        "min_confidence": 0.8
    },

    "image": {
        "patterns": [
            r"^image$",
            r"^img$",
            r"^photo$",
            r"^picture$"
        ],
        "exclude": [r"avatar", r"icon"],
        "priority": 5,
        "visual_cues": ["rectangular", "visual content"],
        "min_confidence": 0.7
    },

    "video": {
        "patterns": [
            r"^video",
            r"video[\s_-]?player"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["play button", "controls"],
        "min_confidence": 0.75
    },

    "audio": {
        "patterns": [
            r"^audio",
            r"audio[\s_-]?player"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["play/pause", "waveform"],
        "min_confidence": 0.75
    },

    "icon": {
        "patterns": [
            r"^icon$"
        ],
        "exclude": [r"icon[\s_-]?button"],
        "priority": 5,
        "visual_cues": ["small graphic", "symbolic"],
        "min_confidence": 0.6
    },

    # Data Visualization
    "chart": {
        "patterns": [
            r"^chart",
            r"^graph"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["data visualization", "axes"],
        "min_confidence": 0.75
    },

    "gauge": {
        "patterns": [
            r"^gauge",
            r"^meter"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["circular/arc", "needle/pointer"],
        "min_confidence": 0.75
    },

    "map": {
        "patterns": [
            r"^map$",
            r"location[\s_-]?map"
        ],
        "exclude": [],
        "priority": 6,
        "visual_cues": ["geographic", "markers"],
        "min_confidence": 0.75
    }
}


# Pattern recognition rules for related components
COMPONENT_PATTERN_RULES = {
    "table": {
        "related": ["pagination", "checkbox", "button"],
        "confidence_boost": 0.1
    },
    "form": {
        "related": ["text-input", "button", "checkbox", "radio", "select"],
        "confidence_boost": 0.15
    },
    "navbar": {
        "related": ["menu", "avatar", "button"],
        "confidence_boost": 0.1
    },
    "card": {
        "related": ["image", "button", "badge", "avatar"],
        "confidence_boost": 0.05
    }
}


def detect_component_type(name: str) -> Optional[Dict[str, Any]]:
    """
    Detect component type from name using pattern matching.

    Args:
        name: Component name to analyze

    Returns:
        Dict with type, confidence, and priority or None if no match
    """
    if not name:
        return None

    name_lower = name.lower()
    matches = []

    for comp_type, patterns_info in COMPONENT_PATTERNS.items():
        # Check include patterns
        for pattern in patterns_info["patterns"]:
            if re.search(pattern, name_lower, re.IGNORECASE):
                # Check exclude patterns
                excluded = False
                for exclude_pattern in patterns_info.get("exclude", []):
                    if re.search(exclude_pattern, name_lower, re.IGNORECASE):
                        excluded = True
                        break

                if not excluded:
                    matches.append({
                        "type": comp_type,
                        "priority": patterns_info["priority"],
                        "confidence": 0.9,  # High confidence for API matches
                        "min_confidence": patterns_info["min_confidence"]
                    })
                    break

    if not matches:
        return None

    # Return highest priority match
    matches.sort(key=lambda x: x["priority"], reverse=True)
    return matches[0]


def get_all_component_types() -> List[str]:
    """Get list of all supported component types"""
    return list(COMPONENT_PATTERNS.keys())


def normalize_component_name(name: str) -> str:
    """
    Normalize component name to standard format.

    Args:
        name: Component name to normalize

    Returns:
        Normalized component name
    """
    # Convert to lowercase
    normalized = name.lower()

    # Remove special characters except hyphens
    normalized = re.sub(r'[^a-z0-9\-]', '', normalized)

    # Remove common suffixes
    normalized = re.sub(r'(component|comp|widget|element)$', '', normalized)

    # Replace multiple hyphens with single
    normalized = re.sub(r'-+', '-', normalized)

    # Strip leading/trailing hyphens
    normalized = normalized.strip('-')

    return normalized
