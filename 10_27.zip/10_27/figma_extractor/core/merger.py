"""Component merger and validation logic"""

import logging
from typing import Dict, List, Any, Set
from collections import defaultdict

from .component_patterns import normalize_component_name, COMPONENT_PATTERN_RULES

logger = logging.getLogger(__name__)


class ComponentMerger:
    """Merges and validates components from multiple sources"""

    def __init__(self, confidence_threshold: float = 0.65):
        """
        Initialize merger.

        Args:
            confidence_threshold: Minimum confidence to include component
        """
        self.confidence_threshold = confidence_threshold

    def merge(self, api_results: Dict, vision_results: Dict) -> Dict[str, Any]:
        """
        Merge results from API and Vision analysis.

        Args:
            api_results: Results from Figma API extraction
            vision_results: Results from Vision analysis

        Returns:
            Merged results dict
        """
        component_map = {}

        # Process API results (higher base confidence)
        if api_results.get("success"):
            api_components = api_results.get("components", [])
            for comp in api_components:
                normalized = normalize_component_name(comp)
                if normalized not in component_map:
                    component_map[normalized] = {
                        "name": comp,
                        "normalized": normalized,
                        "sources": ["api"],
                        "api_confidence": 0.9,
                        "vision_confidence": 0.0,
                        "instances": 1
                    }

        # Process Vision results
        if vision_results.get("success"):
            vision_components = vision_results.get("components", [])
            confidence_scores = vision_results.get("confidence_scores", {})

            for comp in vision_components:
                normalized = normalize_component_name(comp)
                vision_conf = confidence_scores.get(comp, 0.7)

                if normalized in component_map:
                    # Component found by both methods - HIGH confidence
                    component_map[normalized]["sources"].append("vision")
                    component_map[normalized]["vision_confidence"] = vision_conf
                    component_map[normalized]["instances"] += 1
                else:
                    # Component only found by vision
                    component_map[normalized] = {
                        "name": comp,
                        "normalized": normalized,
                        "sources": ["vision"],
                        "api_confidence": 0.0,
                        "vision_confidence": vision_conf,
                        "instances": 1
                    }

        # Calculate final confidence scores
        final_components = []
        for comp_data in component_map.values():
            final_confidence = self._calculate_confidence(comp_data)
            comp_data["final_confidence"] = final_confidence

            if final_confidence >= self.confidence_threshold:
                final_components.append(comp_data)

        # Apply context-aware adjustments
        final_components = self._apply_context_adjustments(final_components)

        # Sort by confidence
        final_components.sort(key=lambda x: x["final_confidence"], reverse=True)

        return {
            "success": True,
            "components": [comp["name"] for comp in final_components],
            "detailed_components": final_components,
            "metadata": {
                "total_detected": len(component_map),
                "passed_threshold": len(final_components),
                "threshold": self.confidence_threshold,
                "api_found": len([c for c in component_map.values() if "api" in c["sources"]]),
                "vision_found": len([c for c in component_map.values() if "vision" in c["sources"]]),
                "both_found": len([c for c in component_map.values() if len(c["sources"]) > 1])
            }
        }

    def _calculate_confidence(self, comp_data: Dict) -> float:
        """
        Calculate final confidence score.

        Args:
            comp_data: Component data dict

        Returns:
            Final confidence score (0-1)
        """
        sources = comp_data["sources"]
        api_conf = comp_data["api_confidence"]
        vision_conf = comp_data["vision_confidence"]

        if len(sources) > 1:
            # Both methods detected - very high confidence
            return 0.95
        elif "api" in sources:
            # Only API detected - use API confidence
            return api_conf
        else:
            # Only vision detected - use vision confidence
            return vision_conf

    def _apply_context_adjustments(self, components: List[Dict]) -> List[Dict]:
        """
        Apply context-aware confidence adjustments.

        Args:
            components: List of component dicts

        Returns:
            Adjusted component list
        """
        component_names = {comp["name"] for comp in components}

        for comp in components:
            comp_name = comp["name"]

            # Check if this component has related components
            if comp_name in COMPONENT_PATTERN_RULES:
                rules = COMPONENT_PATTERN_RULES[comp_name]
                related = rules.get("related", [])
                boost = rules.get("confidence_boost", 0)

                # Check how many related components are present
                found_related = len([r for r in related if r in component_names])

                if found_related > 0:
                    # Boost confidence based on related components found
                    adjustment = boost * (found_related / len(related))
                    comp["final_confidence"] = min(
                        comp["final_confidence"] + adjustment,
                        1.0
                    )
                    comp["context_boost"] = adjustment

        return components

    def deduplicate(self, components: List[str]) -> List[str]:
        """
        Remove duplicates from component list.

        Args:
            components: List of component names

        Returns:
            Deduplicated list
        """
        seen = set()
        deduplicated = []

        for comp in components:
            normalized = normalize_component_name(comp)
            if normalized not in seen:
                seen.add(normalized)
                deduplicated.append(comp)

        return deduplicated


class ComponentValidator:
    """Validates extracted components"""

    def validate(self, components: List[str], expected: List[str] = None) -> Dict[str, Any]:
        """
        Validate extracted components.

        Args:
            components: Detected components
            expected: Expected components (if known)

        Returns:
            Validation results
        """
        metrics = {
            "total_detected": len(components),
            "unique_types": len(set(components))
        }

        # If we have expected components, calculate accuracy metrics
        if expected:
            detected_set = set(components)
            expected_set = set(expected)

            true_positives = len(detected_set & expected_set)
            false_positives = len(detected_set - expected_set)
            false_negatives = len(expected_set - detected_set)

            precision = true_positives / len(detected_set) if detected_set else 0
            recall = true_positives / len(expected_set) if expected_set else 0
            f1_score = (2 * precision * recall / (precision + recall)
                       if (precision + recall) > 0 else 0)

            metrics.update({
                "precision": precision,
                "recall": recall,
                "f1_score": f1_score,
                "accuracy": true_positives / max(len(expected_set), len(detected_set)),
                "missing_components": list(expected_set - detected_set),
                "extra_components": list(detected_set - expected_set),
                "passes_threshold": f1_score >= 0.85
            })

        return metrics

    def find_missing_common_components(self, components: List[str]) -> List[str]:
        """
        Identify common components that might be missing.

        Args:
            components: Detected components

        Returns:
            List of potentially missing components
        """
        component_set = set(components)
        potentially_missing = []

        # Common patterns
        if "form" in component_set:
            expected_form_components = ["text-input", "button", "select"]
            missing = [c for c in expected_form_components if c not in component_set]
            potentially_missing.extend(missing)

        if "table" in component_set:
            if "pagination" not in component_set:
                potentially_missing.append("pagination")

        if "navbar" in component_set:
            if "menu" not in component_set and "button" not in component_set:
                potentially_missing.append("menu")

        return potentially_missing


def merge_component_results(api_results: Dict, vision_results: Dict,
                            confidence_threshold: float = 0.65) -> Dict[str, Any]:
    """
    Convenience function to merge component extraction results.

    Args:
        api_results: Figma API extraction results
        vision_results: Vision analysis results
        confidence_threshold: Minimum confidence threshold

    Returns:
        Merged results dict
    """
    merger = ComponentMerger(confidence_threshold)
    return merger.merge(api_results, vision_results)
