"""Main component extraction orchestrator"""

import logging
import time
from typing import Dict, Any, Optional

from .figma_client import FigmaClient
from .vision_analyzer import GeminiVisionAnalyzer, analyze_multiple_images
from .merger import ComponentMerger

logger = logging.getLogger(__name__)


class ComponentExtractor:
    """Main orchestrator for component extraction"""

    def __init__(self, figma_token: str, gemini_key: Optional[str] = None,
                 confidence_threshold: float = 0.65):
        """
        Initialize extractor.

        Args:
            figma_token: Figma PAT token
            gemini_key: Gemini API key (optional)
            confidence_threshold: Minimum confidence threshold
        """
        self.figma_client = FigmaClient(figma_token)
        self.vision_analyzer = GeminiVisionAnalyzer(gemini_key) if gemini_key else None
        self.merger = ComponentMerger(confidence_threshold)
        self.confidence_threshold = confidence_threshold

    def extract(self, figma_url: str, use_vision: bool = True,
                screenshot_url: Optional[str] = None) -> Dict[str, Any]:
        """
        Extract components from Figma design.

        Args:
            figma_url: Figma file URL or key
            use_vision: Whether to use vision analysis
            screenshot_url: Optional screenshot URL for vision analysis

        Returns:
            Extraction results dict
        """
        start_time = time.time()
        results = {
            "status": "processing",
            "methods_used": [],
            "components": [],
            "metadata": {}
        }

        try:
            # Step 1: Extract from Figma API
            logger.info("Starting Figma API extraction...")
            api_results = self.figma_client.extract_components(figma_url)

            if not api_results.get("success"):
                return {
                    "status": "error",
                    "error": api_results.get("error", "Figma API extraction failed"),
                    "components": []
                }

            results["methods_used"].append("figma_api")
            results["api_results"] = api_results

            # Step 2: Vision analysis (if enabled and available)
            vision_results = None
            if use_vision and self.vision_analyzer and screenshot_url:
                logger.info("Starting vision analysis...")
                vision_results = self.vision_analyzer.analyze_image_url(screenshot_url)

                if vision_results.get("success"):
                    results["methods_used"].append("gemini_vision")
                    results["vision_results"] = vision_results
                else:
                    logger.warning(f"Vision analysis failed: {vision_results.get('error')}")

            # Step 3: Merge results
            if vision_results and vision_results.get("success"):
                logger.info("Merging API and Vision results...")
                merged = self.merger.merge(api_results, vision_results)
            else:
                # Use API results only
                logger.info("Using API results only...")
                merged = {
                    "success": True,
                    "components": api_results.get("components", []),
                    "metadata": {
                        "source": "api_only"
                    }
                }

            # Prepare final response
            processing_time = int((time.time() - start_time) * 1000)

            return {
                "status": "success",
                "extraction_method": "both" if len(results["methods_used"]) > 1 else results["methods_used"][0],
                "components": merged.get("components", []),
                "count": len(merged.get("components", [])),
                "metadata": {
                    "processing_time_ms": processing_time,
                    "methods_used": results["methods_used"],
                    "confidence_threshold": self.confidence_threshold,
                    **merged.get("metadata", {})
                }
            }

        except Exception as e:
            logger.error(f"Extraction error: {e}", exc_info=True)
            return {
                "status": "error",
                "error": str(e),
                "components": []
            }

    def extract_with_auto_vision(self, figma_url: str, max_frames: int = 5) -> Dict[str, Any]:
        """
        Extract components with automatic image export and vision analysis.
        This is the fully automatic dual-method approach.

        Args:
            figma_url: Figma file URL or key
            max_frames: Maximum number of frames to export and analyze

        Returns:
            Extraction results dict
        """
        start_time = time.time()

        try:
            # Step 1: Extract file key
            file_key = self.figma_client.extract_file_key(figma_url)
            if not file_key:
                return {
                    "status": "error",
                    "error": "Invalid Figma URL or file key",
                    "components": []
                }

            logger.info(f"Extracting components from file: {file_key}")

            # Step 2: Extract from Figma API (components)
            logger.info("Method 1: Figma API extraction...")
            api_results = self.figma_client.extract_components(figma_url)

            if not api_results.get("success"):
                return {
                    "status": "error",
                    "error": api_results.get("error", "Figma API extraction failed"),
                    "components": []
                }

            # Step 3: Automatic image export
            logger.info("Exporting frames for vision analysis...")
            frames = self.figma_client.export_frames_for_analysis(file_key, max_frames)

            vision_results = None
            if frames and self.vision_analyzer:
                # Step 4: Analyze multiple images with AI Vision
                logger.info(f"Method 2: AI Vision analysis of {len(frames)} frames...")
                image_urls = [frame["image_url"] for frame in frames]

                vision_results = analyze_multiple_images(
                    image_urls,
                    self.vision_analyzer.api_key
                )

                if vision_results.get("success"):
                    logger.info(f"Vision analysis found {len(vision_results.get('components', []))} components")
                else:
                    logger.warning("Vision analysis failed or found no components")
            else:
                if not frames:
                    logger.warning("No exportable frames found - using API results only")
                if not self.vision_analyzer:
                    logger.warning("Vision analyzer not configured - using API results only")

            # Step 5: Merge results
            if vision_results and vision_results.get("success"):
                logger.info("Merging API and Vision results...")
                merged = self.merger.merge(api_results, vision_results)
                extraction_method = "both"
            else:
                logger.info("Using API results only...")
                merged = {
                    "success": True,
                    "components": api_results.get("components", []),
                    "metadata": {
                        "source": "api_only"
                    }
                }
                extraction_method = "figma_api"

            # Prepare final response
            processing_time = int((time.time() - start_time) * 1000)

            return {
                "status": "success",
                "extraction_method": extraction_method,
                "components": merged.get("components", []),
                "count": len(merged.get("components", [])),
                "metadata": {
                    "processing_time_ms": processing_time,
                    "frames_exported": len(frames) if frames else 0,
                    "frames_analyzed": vision_results.get("successful_analyses", 0) if vision_results else 0,
                    "confidence_threshold": self.confidence_threshold,
                    **merged.get("metadata", {})
                }
            }

        except Exception as e:
            logger.error(f"Extraction error: {e}", exc_info=True)
            return {
                "status": "error",
                "error": str(e),
                "components": []
            }

    def extract_simple(self, figma_url: str) -> Dict[str, Any]:
        """
        Simple extraction using API only (no vision).

        Args:
            figma_url: Figma file URL or key

        Returns:
            Simple extraction results
        """
        start_time = time.time()

        try:
            api_results = self.figma_client.extract_components(figma_url)

            if not api_results.get("success"):
                return {
                    "status": "error",
                    "error": api_results.get("error", "Extraction failed"),
                    "components": []
                }

            processing_time = int((time.time() - start_time) * 1000)

            return {
                "status": "success",
                "components": api_results.get("components", []),
                "count": len(api_results.get("components", [])),
                "processing_time_ms": processing_time
            }

        except Exception as e:
            logger.error(f"Simple extraction error: {e}", exc_info=True)
            return {
                "status": "error",
                "error": str(e),
                "components": []
            }
