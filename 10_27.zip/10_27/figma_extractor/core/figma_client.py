"""Figma API client for extracting components"""

import requests
import logging
from typing import Dict, List, Optional, Any
from urllib.parse import urlparse

from .component_patterns import detect_component_type, normalize_component_name

logger = logging.getLogger(__name__)


class FigmaClient:
    """Client for interacting with Figma API"""

    def __init__(self, pat_token: str):
        """
        Initialize Figma client.

        Args:
            pat_token: Figma Personal Access Token
        """
        self.pat_token = pat_token
        self.base_url = "https://api.figma.com/v1"
        self.headers = {
            "X-Figma-Token": pat_token
        }

    def extract_file_key(self, figma_url: str) -> Optional[str]:
        """
        Extract file key from Figma URL.

        Args:
            figma_url: Figma file URL or file key

        Returns:
            File key string or None
        """
        # If it's already a file key (no slashes)
        if '/' not in figma_url:
            return figma_url

        # Parse URL
        try:
            parsed = urlparse(figma_url)
            path_parts = parsed.path.split('/')

            # URL format: /file/{file_key}/...
            if 'file' in path_parts:
                file_index = path_parts.index('file')
                if file_index + 1 < len(path_parts):
                    return path_parts[file_index + 1]

            return None
        except Exception as e:
            logger.error(f"Error parsing Figma URL: {e}")
            return None

    def get_file(self, file_key: str) -> Optional[Dict]:
        """
        Get Figma file data.

        Args:
            file_key: Figma file key

        Returns:
            File data dict or None
        """
        url = f"{self.base_url}/files/{file_key}"

        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching Figma file: {e}")
            return None

    def find_exportable_frames(self, node: Dict, frames: Optional[List] = None, max_frames: int = 10) -> List[Dict]:
        """
        Find frames/screens suitable for image export and AI analysis.

        Args:
            node: Figma node to search
            frames: List to accumulate frames
            max_frames: Maximum number of frames to export

        Returns:
            List of frame info dicts
        """
        if frames is None:
            frames = []

        # Stop if we have enough frames
        if len(frames) >= max_frames:
            return frames

        node_type = node.get("type")
        node_name = node.get("name", "")
        node_id = node.get("id", "")

        # Prioritize these node types for export
        exportable_types = ["FRAME", "COMPONENT_SET", "CANVAS"]

        if node_type in exportable_types:
            # Skip if it looks like a small component or icon
            # (We want full screens/pages)
            if node_type == "FRAME":
                # Check if it looks like a full screen
                # (usually named things like "Home", "Dashboard", "Screen 1", etc.)
                is_screen = any(keyword in node_name.lower() for keyword in [
                    "screen", "page", "view", "dashboard", "home", "app",
                    "mobile", "desktop", "tablet", "layout"
                ])

                if is_screen or node_type == "CANVAS":
                    frames.append({
                        "id": node_id,
                        "name": node_name,
                        "type": node_type
                    })
                    logger.info(f"Found exportable frame: {node_name} ({node_type})")

            elif node_type == "COMPONENT_SET":
                # Export component library pages
                frames.append({
                    "id": node_id,
                    "name": node_name,
                    "type": node_type
                })
                logger.info(f"Found exportable component set: {node_name}")

        # Recursively check children
        children = node.get("children", [])
        for child in children:
            if len(frames) >= max_frames:
                break
            self.find_exportable_frames(child, frames, max_frames)

        return frames

    def export_images(self, file_key: str, node_ids: List[str], scale: int = 2) -> Optional[Dict[str, str]]:
        """
        Export Figma frames as images.

        Args:
            file_key: Figma file key
            node_ids: List of node IDs to export
            scale: Image scale (1, 2, or 4)

        Returns:
            Dict mapping node_id to image URL, or None on error
        """
        if not node_ids:
            return {}

        # Build query string with node IDs
        ids_param = ",".join(node_ids)
        url = f"{self.base_url}/images/{file_key}"

        params = {
            "ids": ids_param,
            "scale": scale,
            "format": "png"
        }

        try:
            response = requests.get(url, headers=self.headers, params=params, timeout=60)
            response.raise_for_status()
            data = response.json()

            if data.get("err"):
                logger.error(f"Figma image export error: {data['err']}")
                return None

            images = data.get("images", {})
            logger.info(f"Successfully exported {len(images)} images from Figma")
            return images

        except requests.exceptions.RequestException as e:
            logger.error(f"Error exporting images from Figma: {e}")
            return None

    def export_frames_for_analysis(self, file_key: str, max_frames: int = 5) -> List[Dict]:
        """
        Automatically find and export frames for AI vision analysis.

        Args:
            file_key: Figma file key
            max_frames: Maximum number of frames to export

        Returns:
            List of dicts with frame info and image URLs
        """
        # Get file structure
        file_data = self.get_file(file_key)
        if not file_data:
            logger.error("Failed to fetch Figma file for image export")
            return []

        # Find exportable frames
        document = file_data.get("document", {})
        frames = self.find_exportable_frames(document, max_frames=max_frames)

        if not frames:
            logger.warning("No exportable frames found in Figma file")
            return []

        logger.info(f"Found {len(frames)} frames to export")

        # Export images
        node_ids = [frame["id"] for frame in frames]
        image_urls = self.export_images(file_key, node_ids)

        if not image_urls:
            logger.error("Failed to export images from Figma")
            return []

        # Combine frame info with image URLs
        frames_with_images = []
        for frame in frames:
            frame_id = frame["id"]
            if frame_id in image_urls:
                frames_with_images.append({
                    "id": frame_id,
                    "name": frame["name"],
                    "type": frame["type"],
                    "image_url": image_urls[frame_id]
                })

        logger.info(f"Successfully prepared {len(frames_with_images)} frames for analysis")
        return frames_with_images

    def find_components(self, node: Dict, components: Optional[List] = None) -> List[Dict]:
        """
        Recursively find all components in Figma file tree.

        Args:
            node: Figma node to search
            components: List to accumulate components

        Returns:
            List of component dicts
        """
        if components is None:
            components = []

        node_type = node.get("type")
        node_name = node.get("name", "")
        node_id = node.get("id", "")

        # Check if node is a component instance
        if node_type == "INSTANCE":
            detection = detect_component_type(node_name)
            if detection:
                components.append({
                    "id": node_id,
                    "name": node_name,
                    "normalized_name": normalize_component_name(node_name),
                    "type": detection["type"],
                    "node_type": "INSTANCE",
                    "confidence": detection["confidence"]
                })

        # Check if node is a component
        elif node_type == "COMPONENT":
            detection = detect_component_type(node_name)
            if detection:
                components.append({
                    "id": node_id,
                    "name": node_name,
                    "normalized_name": normalize_component_name(node_name),
                    "type": detection["type"],
                    "node_type": "COMPONENT",
                    "confidence": detection["confidence"],
                    "is_main_component": True
                })

        # Check if node is a component set
        elif node_type == "COMPONENT_SET":
            detection = detect_component_type(node_name)
            if detection:
                variants = len(node.get("children", []))
                components.append({
                    "id": node_id,
                    "name": node_name,
                    "normalized_name": normalize_component_name(node_name),
                    "type": detection["type"],
                    "node_type": "COMPONENT_SET",
                    "confidence": detection["confidence"],
                    "variants": variants
                })

        # Recursively check children
        children = node.get("children", [])
        for child in children:
            self.find_components(child, components)

        return components

    def deduplicate_components(self, components: List[Dict]) -> List[Dict]:
        """
        Remove duplicate component detections.

        Args:
            components: List of detected components

        Returns:
            Deduplicated list
        """
        seen_types = {}

        for comp in components:
            comp_type = comp["type"]

            if comp_type not in seen_types:
                seen_types[comp_type] = comp
            else:
                # Keep the one with higher confidence
                if comp["confidence"] > seen_types[comp_type]["confidence"]:
                    seen_types[comp_type] = comp

        return list(seen_types.values())

    def extract_components(self, figma_url: str) -> Dict[str, Any]:
        """
        Extract components from Figma file.

        Args:
            figma_url: Figma file URL or key

        Returns:
            Dict with extraction results
        """
        stages = []

        # Stage 1: Extract file key
        file_key = self.extract_file_key(figma_url)
        if not file_key:
            return {
                "success": False,
                "error": "Invalid Figma URL or file key",
                "components": []
            }

        stages.append({"stage": "url_parse", "success": True, "file_key": file_key})

        # Stage 2: Fetch file data
        file_data = self.get_file(file_key)
        if not file_data:
            return {
                "success": False,
                "error": "Failed to fetch Figma file",
                "stages": stages,
                "components": []
            }

        stages.append({"stage": "file_fetch", "success": True})

        # Stage 3: Find all components
        document = file_data.get("document", {})
        all_components = self.find_components(document)

        stages.append({
            "stage": "component_discovery",
            "found": len(all_components)
        })

        # Stage 4: Deduplication
        unique_components = self.deduplicate_components(all_components)

        stages.append({
            "stage": "deduplication",
            "unique": len(unique_components)
        })

        # Extract component types
        component_types = [comp["type"] for comp in unique_components]

        return {
            "success": True,
            "method": "figma_api",
            "components": component_types,
            "detailed_components": unique_components,
            "metadata": {
                "file_name": file_data.get("name", "Unknown"),
                "total_found": len(all_components),
                "unique_types": len(unique_components),
                "stages": stages
            }
        }


def extract_components_from_figma(figma_url: str, pat_token: str) -> Dict[str, Any]:
    """
    Convenience function to extract components from Figma.

    Args:
        figma_url: Figma file URL or key
        pat_token: Figma Personal Access Token

    Returns:
        Extraction results dict
    """
    client = FigmaClient(pat_token)
    return client.extract_components(figma_url)
