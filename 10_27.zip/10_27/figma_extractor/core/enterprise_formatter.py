"""Enterprise API formatter for component requirements"""

from typing import List, Dict, Any
import uuid


class EnterpriseAPIFormatter:
    """Formats component extraction results for enterprise API consumption"""

    def __init__(self, framework: str = "angular", version: str = "17"):
        """
        Initialize formatter.

        Args:
            framework: Target framework (angular, react, vue)
            version: Framework version
        """
        self.framework = framework
        self.version = version

    def format_for_enterprise_api(
        self,
        components: List[str],
        request_id: str = None,
        generate_files: List[str] = None,
        component_features: Dict[str, List[str]] = None
    ) -> Dict[str, Any]:
        """
        Format component list for enterprise API.

        Args:
            components: List of component names
            request_id: Optional request ID (generates UUID if not provided)
            generate_files: Files to generate for each component
            component_features: Optional features per component

        Returns:
            Enterprise API formatted dict
        """
        if generate_files is None:
            generate_files = ["html", "ts", "spec", "usage"]

        if component_features is None:
            component_features = {}

        if request_id is None:
            request_id = f"figma-extract-{uuid.uuid4().hex[:8]}"

        # Build component requirements
        component_requirements = []

        for component in components:
            requirement = {
                "component": component,
                "framework": self.framework,
                "version": self.version,
                "generate": generate_files.copy()
            }

            # Add special features for specific components
            features = self._get_default_features(component)
            if component in component_features:
                features = component_features[component]

            if features:
                requirement["features"] = features

            # Add subcomponents for complex components
            subcomponents = self._get_default_subcomponents(component)
            if subcomponents:
                requirement["subcomponents"] = subcomponents

            component_requirements.append(requirement)

        return {
            "request_id": request_id,
            "component_requirements": component_requirements
        }

    def _get_default_features(self, component: str) -> List[str]:
        """
        Get default features for component types.

        Args:
            component: Component name

        Returns:
            List of feature strings
        """
        feature_map = {
            "table": ["sorting", "pagination", "filtering"],
            "data-table": ["sorting", "pagination", "filtering"],
            "select": ["search", "multi-select"],
            "text-input": ["validation", "placeholder"],
            "modal": ["backdrop", "close-button"],
            "carousel": ["autoplay", "navigation", "indicators"],
            "tabs": ["lazy-loading", "routing"],
            "accordion": ["single-expand", "animation"]
        }

        return feature_map.get(component, [])

    def _get_default_subcomponents(self, component: str) -> List[str]:
        """
        Get default subcomponents for complex components.

        Args:
            component: Component name

        Returns:
            List of subcomponent names
        """
        subcomponent_map = {
            "form": [
                "text-input",
                "select",
                "checkbox",
                "radio",
                "button"
            ],
            "table": [
                "table-header",
                "table-row",
                "table-cell",
                "pagination"
            ],
            "data-table": [
                "table-header",
                "table-row",
                "table-cell",
                "pagination"
            ],
            "card": [
                "card-header",
                "card-content",
                "card-actions"
            ],
            "modal": [
                "modal-header",
                "modal-content",
                "modal-footer"
            ],
            "navbar": [
                "nav-item",
                "nav-link",
                "menu"
            ]
        }

        return subcomponent_map.get(component, [])

    def format_simple(self, components: List[str]) -> Dict[str, Any]:
        """
        Simple format with minimal configuration.

        Args:
            components: List of component names

        Returns:
            Formatted dict
        """
        return {
            "request_id": f"figma-extract-{uuid.uuid4().hex[:8]}",
            "framework": self.framework,
            "version": self.version,
            "components": components
        }

    def format_with_instances(
        self,
        detailed_components: List[Dict],
        request_id: str = None
    ) -> Dict[str, Any]:
        """
        Format with instance counts and metadata.

        Args:
            detailed_components: Detailed component list with metadata
            request_id: Optional request ID

        Returns:
            Formatted dict with instance information
        """
        if request_id is None:
            request_id = f"figma-extract-{uuid.uuid4().hex[:8]}"

        # Group by component type and count instances
        component_counts = {}
        for comp in detailed_components:
            comp_type = comp.get("type", "unknown")
            if comp_type not in component_counts:
                component_counts[comp_type] = 0
            component_counts[comp_type] += 1

        # Build requirements with instance counts
        component_requirements = []
        for component, count in component_counts.items():
            requirement = {
                "component": component,
                "framework": self.framework,
                "version": self.version,
                "generate": ["html", "ts", "spec", "usage"],
                "instances": count
            }

            features = self._get_default_features(component)
            if features:
                requirement["features"] = features

            subcomponents = self._get_default_subcomponents(component)
            if subcomponents:
                requirement["subcomponents"] = subcomponents

            component_requirements.append(requirement)

        return {
            "request_id": request_id,
            "component_requirements": component_requirements,
            "metadata": {
                "total_components": len(detailed_components),
                "unique_types": len(component_counts)
            }
        }


def format_for_enterprise_api(
    components: List[str],
    framework: str = "angular",
    version: str = "17"
) -> Dict[str, Any]:
    """
    Convenience function to format components for enterprise API.

    Args:
        components: List of component names
        framework: Target framework
        version: Framework version

    Returns:
        Enterprise API formatted dict
    """
    formatter = EnterpriseAPIFormatter(framework, version)
    return formatter.format_for_enterprise_api(components)
