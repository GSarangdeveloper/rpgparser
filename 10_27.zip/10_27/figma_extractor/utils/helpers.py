"""Helper utilities"""

import re
from typing import Optional
from urllib.parse import urlparse


def extract_figma_file_key(url: str) -> Optional[str]:
    """
    Extract Figma file key from URL.

    Args:
        url: Figma URL or file key

    Returns:
        File key or None
    """
    if not url:
        return None

    # If it's already a key (no protocol/slashes)
    if not url.startswith('http') and '/' not in url:
        return url

    try:
        parsed = urlparse(url)
        path_parts = parsed.path.split('/')

        # Format: /file/{file_key}/...
        if 'file' in path_parts:
            file_index = path_parts.index('file')
            if file_index + 1 < len(path_parts):
                return path_parts[file_index + 1]

        return None
    except Exception:
        return None


def validate_figma_url(url: str) -> bool:
    """
    Validate Figma URL format.

    Args:
        url: URL to validate

    Returns:
        True if valid
    """
    if not url:
        return False

    # Check if it's a file key
    if re.match(r'^[a-zA-Z0-9]+$', url):
        return True

    # Check if it's a valid Figma URL
    pattern = r'^https?://(?:www\.)?figma\.com/file/[a-zA-Z0-9]+/.+'
    return bool(re.match(pattern, url))


def format_processing_time(ms: int) -> str:
    """
    Format processing time for display.

    Args:
        ms: Time in milliseconds

    Returns:
        Formatted string
    """
    if ms < 1000:
        return f"{ms}ms"
    elif ms < 60000:
        return f"{ms / 1000:.1f}s"
    else:
        minutes = ms // 60000
        seconds = (ms % 60000) / 1000
        return f"{minutes}m {seconds:.0f}s"


def truncate_text(text: str, max_length: int = 50) -> str:
    """
    Truncate text to max length.

    Args:
        text: Text to truncate
        max_length: Maximum length

    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."
