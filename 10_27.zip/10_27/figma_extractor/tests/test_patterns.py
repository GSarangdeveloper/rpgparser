"""Tests for component pattern detection"""

import pytest
from figma_extractor.core.component_patterns import (
    detect_component_type,
    normalize_component_name,
    get_all_component_types
)


class TestComponentDetection:
    """Test component type detection"""

    def test_button_detection(self):
        """Test button pattern matching"""
        test_cases = [
            ("Primary Button", "button"),
            ("btn-submit", "button"),
            ("CTA Button", "button"),
            ("Action Button", "button"),
        ]

        for name, expected_type in test_cases:
            result = detect_component_type(name)
            assert result is not None
            assert result["type"] == expected_type

    def test_input_detection(self):
        """Test input field pattern matching"""
        test_cases = [
            ("Email Input", "text-input"),
            ("TextField", "text-input"),
            ("Search Field", "text-input"),
            ("Password Input", "text-input"),
        ]

        for name, expected_type in test_cases:
            result = detect_component_type(name)
            assert result is not None
            assert result["type"] == expected_type

    def test_navigation_detection(self):
        """Test navigation component detection"""
        test_cases = [
            ("NavBar", "navbar"),
            ("Header", "navbar"),
            ("Sidebar", "sidebar"),
            ("Tabs", "tabs"),
        ]

        for name, expected_type in test_cases:
            result = detect_component_type(name)
            assert result is not None
            assert result["type"] == expected_type

    def test_card_detection(self):
        """Test card detection"""
        test_cases = [
            ("Product Card", "card"),
            ("User Card", "card"),
            ("Info Panel", "card"),
        ]

        for name, expected_type in test_cases:
            result = detect_component_type(name)
            assert result is not None
            assert result["type"] == expected_type

    def test_modal_detection(self):
        """Test modal/dialog detection"""
        test_cases = [
            ("Modal", "modal"),
            ("Dialog", "modal"),
            ("Popup", "modal"),
        ]

        for name, expected_type in test_cases:
            result = detect_component_type(name)
            assert result is not None
            assert result["type"] == expected_type

    def test_no_match(self):
        """Test cases that should not match"""
        test_cases = [
            "Random Text",
            "Unknown Component",
            "",
        ]

        for name in test_cases:
            result = detect_component_type(name)
            assert result is None or result["confidence"] < 0.5


class TestNormalization:
    """Test component name normalization"""

    def test_normalize_basic(self):
        """Test basic normalization"""
        assert normalize_component_name("Button") == "button"
        assert normalize_component_name("Primary-Button") == "primarybutton"

    def test_normalize_special_chars(self):
        """Test special character removal"""
        assert normalize_component_name("btn_submit") == "btnsubmit"
        assert normalize_component_name("btn-primary") == "btnprimary"

    def test_normalize_suffix_removal(self):
        """Test suffix removal"""
        assert normalize_component_name("ButtonComponent") == "button"
        assert normalize_component_name("InputWidget") == "input"


class TestComponentTypes:
    """Test component type utilities"""

    def test_get_all_types(self):
        """Test getting all component types"""
        types = get_all_component_types()
        assert isinstance(types, list)
        assert len(types) > 20
        assert "button" in types
        assert "text-input" in types
        assert "navbar" in types
        assert "card" in types


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
