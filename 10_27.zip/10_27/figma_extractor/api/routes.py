"""Flask API routes"""

import logging
from flask import Blueprint, request, jsonify
from typing import Dict, Any

from ..core.extractor import ComponentExtractor
from ..core.enterprise_formatter import EnterpriseAPIFormatter
from ..config import Config

logger = logging.getLogger(__name__)

# Create blueprint
api_bp = Blueprint('api', __name__, url_prefix='/api')

# Load config
config = Config.from_env()


@api_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "figma-component-extractor",
        "version": "1.0.0"
    })


@api_bp.route('/extract', methods=['POST'])
def extract_components():
    """
    Extract components from Figma design.

    Request body:
    {
        "figma_url": "https://www.figma.com/file/...",
        "pat_token": "optional_token",
        "use_vision": true,
        "screenshot_url": "optional_screenshot_url"
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({
                "status": "error",
                "error": "No JSON data provided"
            }), 400

        # Get parameters
        figma_url = data.get("figma_url")
        pat_token = data.get("pat_token") or config.figma_pat_token
        use_vision = data.get("use_vision", False)
        screenshot_url = data.get("screenshot_url")

        # Validate required fields
        if not figma_url:
            return jsonify({
                "status": "error",
                "error": "figma_url is required"
            }), 400

        if not pat_token:
            return jsonify({
                "status": "error",
                "error": "pat_token is required (provide in request or set FIGMA_PAT_TOKEN env variable)"
            }), 400

        # Check vision requirements
        gemini_key = config.gemini_api_key if use_vision else None
        if use_vision and not gemini_key:
            logger.warning("Vision analysis requested but GEMINI_API_KEY not set")
            use_vision = False

        # Create extractor
        extractor = ComponentExtractor(
            figma_token=pat_token,
            gemini_key=gemini_key,
            confidence_threshold=config.confidence_threshold
        )

        # Extract components
        results = extractor.extract(
            figma_url=figma_url,
            use_vision=use_vision,
            screenshot_url=screenshot_url
        )

        status_code = 200 if results.get("status") == "success" else 500
        return jsonify(results), status_code

    except Exception as e:
        logger.error(f"API error: {e}", exc_info=True)
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500


@api_bp.route('/extract/auto', methods=['POST'])
def extract_auto_dual_method():
    """
    Fully automatic dual-method extraction (API + Auto Vision).
    Automatically exports frames and analyzes with AI - no screenshot URL needed!

    Request body:
    {
        "figma_url": "https://www.figma.com/file/...",
        "pat_token": "optional_token",
        "max_frames": 5
    }

    Response:
    {
        "status": "success",
        "extraction_method": "both",
        "components": ["button", "card", "navbar", ...],
        "count": 12,
        "metadata": {
            "processing_time_ms": 2450,
            "frames_exported": 3,
            "frames_analyzed": 3,
            "api_found": 8,
            "vision_found": 10,
            "both_found": 6
        }
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({
                "status": "error",
                "error": "No JSON data provided"
            }), 400

        figma_url = data.get("figma_url")
        pat_token = data.get("pat_token") or config.figma_pat_token
        max_frames = data.get("max_frames", 5)

        # Validate required fields
        if not figma_url:
            return jsonify({
                "status": "error",
                "error": "figma_url is required"
            }), 400

        if not pat_token:
            return jsonify({
                "status": "error",
                "error": "pat_token is required"
            }), 400

        # Check if vision is available
        gemini_key = config.gemini_api_key
        if not gemini_key:
            logger.warning("GEMINI_API_KEY not set - falling back to API-only extraction")
            # Fall back to simple extraction
            extractor = ComponentExtractor(
                figma_token=pat_token,
                confidence_threshold=config.confidence_threshold
            )
            results = extractor.extract_simple(figma_url)
        else:
            # Full automatic dual-method extraction
            extractor = ComponentExtractor(
                figma_token=pat_token,
                gemini_key=gemini_key,
                confidence_threshold=config.confidence_threshold
            )
            results = extractor.extract_with_auto_vision(figma_url, max_frames)

        status_code = 200 if results.get("status") == "success" else 500
        return jsonify(results), status_code

    except Exception as e:
        logger.error(f"Auto extraction error: {e}", exc_info=True)
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500


@api_bp.route('/extract/simple', methods=['POST'])
def extract_simple():
    """
    Simple extraction using Figma API only.

    Request body:
    {
        "figma_url": "https://www.figma.com/file/...",
        "pat_token": "optional_token"
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({
                "status": "error",
                "error": "No JSON data provided"
            }), 400

        figma_url = data.get("figma_url")
        pat_token = data.get("pat_token") or config.figma_pat_token

        if not figma_url:
            return jsonify({
                "status": "error",
                "error": "figma_url is required"
            }), 400

        if not pat_token:
            return jsonify({
                "status": "error",
                "error": "pat_token is required"
            }), 400

        # Create extractor
        extractor = ComponentExtractor(
            figma_token=pat_token,
            confidence_threshold=config.confidence_threshold
        )

        # Extract components (API only)
        results = extractor.extract_simple(figma_url)

        status_code = 200 if results.get("status") == "success" else 500
        return jsonify(results), status_code

    except Exception as e:
        logger.error(f"API error: {e}", exc_info=True)
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500


@api_bp.route('/components/types', methods=['GET'])
def get_component_types():
    """Get list of all supported component types"""
    from ..core.component_patterns import get_all_component_types

    return jsonify({
        "status": "success",
        "component_types": get_all_component_types(),
        "count": len(get_all_component_types())
    })


@api_bp.route('/extract/enterprise', methods=['POST'])
def extract_for_enterprise_api():
    """
    Extract components and format for enterprise API consumption.

    Request body:
    {
        "figma_url": "https://www.figma.com/file/...",
        "pat_token": "optional_token",
        "framework": "angular",
        "version": "17",
        "request_id": "optional_request_id",
        "generate_files": ["html", "ts", "spec", "usage"],
        "component_features": {
            "data-table": ["sorting", "pagination", "filtering"]
        }
    }

    Response format matches enterprise API expectations:
    {
        "request_id": "figma-extract-001",
        "component_requirements": [
            {
                "component": "button",
                "framework": "angular",
                "version": "17",
                "generate": ["html", "ts", "spec", "usage"]
            }
        ]
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({
                "status": "error",
                "error": "No JSON data provided"
            }), 400

        # Get extraction parameters
        figma_url = data.get("figma_url")
        pat_token = data.get("pat_token") or config.figma_pat_token

        # Get formatting parameters
        framework = data.get("framework", "angular")
        version = data.get("version", "17")
        request_id = data.get("request_id")
        generate_files = data.get("generate_files", ["html", "ts", "spec", "usage"])
        component_features = data.get("component_features", {})

        # Validate required fields
        if not figma_url:
            return jsonify({
                "status": "error",
                "error": "figma_url is required"
            }), 400

        if not pat_token:
            return jsonify({
                "status": "error",
                "error": "pat_token is required"
            }), 400

        # Extract components
        extractor = ComponentExtractor(
            figma_token=pat_token,
            confidence_threshold=config.confidence_threshold
        )

        extraction_results = extractor.extract_simple(figma_url)

        if extraction_results.get("status") != "success":
            return jsonify({
                "status": "error",
                "error": extraction_results.get("error", "Extraction failed")
            }), 500

        # Format for enterprise API
        formatter = EnterpriseAPIFormatter(
            framework=framework,
            version=version
        )

        enterprise_format = formatter.format_for_enterprise_api(
            components=extraction_results.get("components", []),
            request_id=request_id,
            generate_files=generate_files,
            component_features=component_features
        )

        return jsonify(enterprise_format), 200

    except Exception as e:
        logger.error(f"Enterprise API format error: {e}", exc_info=True)
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500
