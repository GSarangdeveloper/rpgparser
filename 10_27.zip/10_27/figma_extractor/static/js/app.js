// Figma Component Extractor - Frontend JavaScript

// Toggle screenshot URL field based on vision checkbox
document.getElementById('useVision').addEventListener('change', function(e) {
    const screenshotGroup = document.getElementById('screenshotGroup');
    screenshotGroup.style.display = e.target.checked ? 'block' : 'none';
});

// Handle form submission
document.getElementById('extractForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const figmaUrl = document.getElementById('figmaUrl').value.trim();
    const patToken = document.getElementById('patToken').value.trim();
    const useVision = document.getElementById('useVision').checked;
    const screenshotUrl = document.getElementById('screenshotUrl').value.trim();

    if (!figmaUrl) {
        showError('Please enter a Figma URL');
        return;
    }

    // Show loading state
    const extractBtn = document.getElementById('extractBtn');
    const btnText = extractBtn.querySelector('.btn-text');
    const spinner = extractBtn.querySelector('.spinner');

    extractBtn.disabled = true;
    btnText.textContent = 'Extracting...';
    spinner.style.display = 'inline-block';

    // Hide previous results/errors
    document.getElementById('results').style.display = 'none';
    document.getElementById('error').style.display = 'none';

    try {
        // Prepare request
        const requestBody = {
            figma_url: figmaUrl,
            use_vision: useVision
        };

        if (patToken) {
            requestBody.pat_token = patToken;
        }

        if (useVision && screenshotUrl) {
            requestBody.screenshot_url = screenshotUrl;
        }

        // Make API call
        const response = await fetch('/api/extract/simple', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        const data = await response.json();

        if (data.status === 'success') {
            displayResults(data);
        } else {
            showError(data.error || 'Extraction failed');
        }

    } catch (error) {
        showError('Network error: ' + error.message);
    } finally {
        // Reset button state
        extractBtn.disabled = false;
        btnText.textContent = 'Extract Components';
        spinner.style.display = 'none';
    }
});

// Display results
function displayResults(data) {
    const resultsDiv = document.getElementById('results');
    const metaDiv = document.getElementById('resultsMeta');
    const gridDiv = document.getElementById('componentsGrid');
    const jsonOutput = document.getElementById('jsonOutput');

    // Show results card
    resultsDiv.style.display = 'block';

    // Display metadata
    metaDiv.innerHTML = `
        <div class="meta-item">
            <div class="meta-value">${data.count || 0}</div>
            <div class="meta-label">Components Found</div>
        </div>
        <div class="meta-item">
            <div class="meta-value">${data.processing_time_ms || 0}ms</div>
            <div class="meta-label">Processing Time</div>
        </div>
        <div class="meta-item">
            <div class="meta-value">${data.extraction_method || 'API'}</div>
            <div class="meta-label">Method Used</div>
        </div>
    `;

    // Display components
    if (data.components && data.components.length > 0) {
        gridDiv.innerHTML = data.components
            .map(comp => `<div class="component-badge">${comp}</div>`)
            .join('');
    } else {
        gridDiv.innerHTML = '<p>No components detected</p>';
    }

    // Display JSON
    jsonOutput.textContent = JSON.stringify(data, null, 2);

    // Scroll to results
    resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Show error
function showError(message) {
    const errorDiv = document.getElementById('error');
    const errorMessage = document.getElementById('errorMessage');

    errorMessage.textContent = message;
    errorDiv.style.display = 'block';

    // Scroll to error
    errorDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Clear form
function clearForm() {
    document.getElementById('extractForm').reset();
    document.getElementById('screenshotGroup').style.display = 'none';
    document.getElementById('results').style.display = 'none';
    document.getElementById('error').style.display = 'none';
}

// Copy JSON to clipboard
function copyJSON() {
    const jsonOutput = document.getElementById('jsonOutput');
    const text = jsonOutput.textContent;

    navigator.clipboard.writeText(text).then(() => {
        // Show feedback
        const btn = event.target;
        const originalText = btn.textContent;
        btn.textContent = 'Copied!';
        btn.style.background = '#43a047';
        btn.style.color = 'white';

        setTimeout(() => {
            btn.textContent = originalText;
            btn.style.background = '';
            btn.style.color = '';
        }, 2000);
    }).catch(err => {
        alert('Failed to copy: ' + err);
    });
}

// Load component types on page load (for reference)
async function loadComponentTypes() {
    try {
        const response = await fetch('/api/components/types');
        const data = await response.json();
        console.log('Supported component types:', data.component_types);
    } catch (error) {
        console.error('Failed to load component types:', error);
    }
}

// Initialize
window.addEventListener('DOMContentLoaded', () => {
    loadComponentTypes();
});
