"""Figma Component Extractor"""

__version__ = "1.0.0"
