"""Configuration management for Figma Component Extractor"""

import os
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


@dataclass
class Config:
    """Application configuration"""

    # Figma API
    figma_pat_token: Optional[str] = None

    # AI APIs
    gemini_api_key: Optional[str] = None
    openai_api_key: Optional[str] = None

    # Flask Configuration
    flask_env: str = "development"
    flask_debug: bool = True
    port: int = 5000

    # Processing Configuration
    max_image_size: int = 4096
    batch_size: int = 5
    confidence_threshold: float = 0.65
    processing_timeout: int = 120

    # Feature Flags
    use_gemini_vision: bool = True
    use_openai_vision: bool = False
    enable_detailed_logging: bool = True

    @classmethod
    def from_env(cls):
        """Create config from environment variables"""
        return cls(
            figma_pat_token=os.getenv("FIGMA_PAT_TOKEN"),
            gemini_api_key=os.getenv("GEMINI_API_KEY"),
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            flask_env=os.getenv("FLASK_ENV", "development"),
            flask_debug=os.getenv("FLASK_DEBUG", "True").lower() == "true",
            port=int(os.getenv("PORT", "5000")),
            max_image_size=int(os.getenv("MAX_IMAGE_SIZE", "4096")),
            batch_size=int(os.getenv("BATCH_SIZE", "5")),
            confidence_threshold=float(os.getenv("CONFIDENCE_THRESHOLD", "0.65")),
            processing_timeout=int(os.getenv("PROCESSING_TIMEOUT", "120")),
            use_gemini_vision=os.getenv("USE_GEMINI_VISION", "true").lower() == "true",
            use_openai_vision=os.getenv("USE_OPENAI_VISION", "false").lower() == "true",
            enable_detailed_logging=os.getenv("ENABLE_DETAILED_LOGGING", "true").lower() == "true"
        )


# Figma API endpoints
FIGMA_API_BASE = "https://api.figma.com/v1"

FIGMA_ENDPOINTS = {
    "get_file": f"{FIGMA_API_BASE}/files/{{file_key}}",
    "get_nodes": f"{FIGMA_API_BASE}/files/{{file_key}}/nodes",
    "get_components": f"{FIGMA_API_BASE}/files/{{file_key}}/components",
    "get_component_sets": f"{FIGMA_API_BASE}/files/{{file_key}}/component_sets",
    "get_images": f"{FIGMA_API_BASE}/images/{{file_key}}"
}

# Image export configuration
IMAGE_EXPORT_CONFIG = {
    "scale": 2,
    "format": "png",
    "max_image_size": 4096,
    "batch_size": 5
}
