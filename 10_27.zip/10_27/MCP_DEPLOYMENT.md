# 🚀 Figma Component Extractor - MCP Server Deployment

## What is This?

A **hosted MCP (Model Context Protocol) server** that exposes Figma component extraction as tools for **any MCP client** (Claude Desktop, IDEs, etc.).

Anyone can connect to your hosted server and extract Figma components!

---

## 🎯 Features

- ✅ **Hosted** - Deploy once, use anywhere
- ✅ **MCP Protocol** - Works with any MCP client
- ✅ **3 Tools Exposed**:
  1. `extract_figma_components` - Full dual-method extraction
  2. `extract_figma_for_enterprise` - Enterprise API format
  3. `list_supported_components` - List all 38+ component types
- ✅ **Low Code** - Simple deployment configs included

---

## 🚀 Quick Deploy (3 Options)

### Option 1: Railway (Easiest - Click to Deploy)

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template)

**Steps:**
1. Click the button above
2. Add environment variables:
   - `FIGMA_PAT_TOKEN` (optional - users can provide their own)
   - `GEMINI_API_KEY` (required for vision analysis)
3. Deploy!
4. Copy your MCP server URL

**Cost:** ~$5/month

---

### Option 2: Render (Free Tier Available)

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

**Steps:**
1. Fork this repo
2. Go to [Render Dashboard](https://dashboard.render.com/)
3. Click "New +" → "Blueprint"
4. Connect your forked repo
5. It will detect `render.yaml` automatically
6. Add environment variables:
   - `FIGMA_PAT_TOKEN`
   - `GEMINI_API_KEY`
7. Deploy!

**Cost:** Free tier available

---

### Option 3: Fly.io (Fast & Global)

**Steps:**
```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Login
fly auth login

# Launch app
fly launch

# Set secrets
fly secrets set FIGMA_PAT_TOKEN=your_token
fly secrets set GEMINI_API_KEY=your_key

# Deploy
fly deploy
```

**Cost:** ~$3/month

---

### Option 4: Manual Docker Deployment

**Steps:**
```bash
# Build Docker image
docker build -t figma-mcp-server .

# Run container
docker run -d \
  -p 8080:8080 \
  -e FIGMA_PAT_TOKEN=your_token \
  -e GEMINI_API_KEY=your_key \
  --name figma-mcp \
  figma-mcp-server

# Check logs
docker logs -f figma-mcp
```

Deploy to any cloud:
- AWS ECS
- Google Cloud Run
- Azure Container Instances
- DigitalOcean Apps

---

## 🔧 Configuration

### Environment Variables

```env
# Required for vision analysis
GEMINI_API_KEY=your_gemini_api_key

# Optional - users can provide their own
FIGMA_PAT_TOKEN=your_default_figma_token

# Optional configuration
CONFIDENCE_THRESHOLD=0.65
MAX_IMAGE_SIZE=4096
```

### Get API Keys

**Gemini API Key:**
1. Visit: https://makersuite.google.com/app/apikey
2. Create API Key
3. Copy key

**Figma PAT Token:**
1. Visit: https://www.figma.com/settings
2. Generate Personal Access Token
3. Copy token (starts with `figd_`)

---

## 📱 Using the MCP Server

### Option 1: Claude Desktop (Official MCP Client)

1. **Install Claude Desktop** (if not already installed)

2. **Add MCP Server to Config:**

   Edit your MCP config file:
   - **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
   - **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

3. **Add this configuration:**

```json
{
  "mcpServers": {
    "figma-extractor": {
      "command": "node",
      "args": [
        "/path/to/mcp-client-wrapper.js",
        "YOUR_DEPLOYED_SERVER_URL"
      ]
    }
  }
}
```

OR for stdio transport:

```json
{
  "mcpServers": {
    "figma-extractor": {
      "command": "python",
      "args": [
        "/path/to/mcp_server.py"
      ],
      "env": {
        "FIGMA_PAT_TOKEN": "your_token",
        "GEMINI_API_KEY": "your_key"
      }
    }
  }
}
```

4. **Restart Claude Desktop**

5. **Use in Claude:**
   ```
   User: Extract components from this Figma file:
   https://www.figma.com/file/abc123/Design

   Claude: [Uses extract_figma_components tool automatically]
   ```

---

### Option 2: Direct API Access (For Custom Clients)

If you want to build your own client:

```bash
# Connect via stdio
python mcp_server.py
```

Or use the MCP SDK:

```python
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# Connect to hosted server
server_params = StdioServerParameters(
    command="python",
    args=["mcp_server.py"],
    env={
        "FIGMA_PAT_TOKEN": "your_token",
        "GEMINI_API_KEY": "your_key"
    }
)

async with stdio_client(server_params) as (read, write):
    async with ClientSession(read, write) as session:
        # Initialize
        await session.initialize()

        # List tools
        tools = await session.list_tools()
        print(tools)

        # Call tool
        result = await session.call_tool(
            "extract_figma_components",
            {
                "figma_url": "https://www.figma.com/file/abc123/Design",
                "pat_token": "your_token"
            }
        )
        print(result)
```

---

## 🛠️ MCP Tools Available

### 1. `extract_figma_components`

**Description:** Extract all UI components from Figma file using dual-method (API + Vision)

**Input:**
```json
{
  "figma_url": "https://www.figma.com/file/abc123/Design",
  "pat_token": "figd_your_token (optional)",
  "max_frames": 5,
  "use_vision": true
}
```

**Output:**
```json
{
  "status": "success",
  "extraction_method": "both",
  "components": ["button", "card", "navbar", ...],
  "count": 12,
  "metadata": {
    "frames_exported": 3,
    "frames_analyzed": 3
  }
}
```

---

### 2. `extract_figma_for_enterprise`

**Description:** Extract and format for enterprise code generation APIs

**Input:**
```json
{
  "figma_url": "https://www.figma.com/file/abc123/Design",
  "pat_token": "figd_your_token",
  "framework": "angular",
  "version": "17"
}
```

**Output:**
```json
{
  "request_id": "figma-extract-a1b2c3d4",
  "component_requirements": [
    {
      "component": "button",
      "framework": "angular",
      "version": "17",
      "generate": ["html", "ts", "spec", "usage"]
    }
  ]
}
```

---

### 3. `list_supported_components`

**Description:** Get list of all 38+ supported component types

**Input:** None

**Output:**
```json
{
  "supported_components": [
    "button", "text-input", "select", ...
  ],
  "count": 38,
  "categories": {
    "action": ["button", "fab", "icon-button"],
    "form": ["text-input", "select", ...],
    ...
  }
}
```

---

## 🔒 Security Considerations

### For Hosted Deployment:

1. **API Keys:**
   - Don't hardcode in Docker image
   - Use environment variables
   - Use secrets management (Railway Secrets, Render Env Vars, etc.)

2. **Rate Limiting:**
   - Consider adding rate limits if public
   - Use API gateway (Cloudflare, AWS API Gateway)

3. **Authentication:**
   - For production, add API key authentication
   - Use HTTPS only

### Example with Authentication:

```python
# Add to mcp_server.py
API_KEY = os.getenv("MCP_API_KEY")

@server.call_tool()
async def handle_call_tool(name: str, arguments: dict | None) -> list[TextContent]:
    # Verify API key
    if arguments.get("api_key") != API_KEY:
        return [TextContent(type="text", text="Unauthorized")]

    # Continue with tool execution...
```

---

## 📊 Monitoring

### Railway Dashboard
- View logs
- Monitor resource usage
- Check request counts

### Render Dashboard
- View deployment logs
- Monitor health checks
- Check metrics

### Custom Monitoring

Add to your code:
```python
import sentry_sdk
sentry_sdk.init(dsn="your_sentry_dsn")
```

---

## 💰 Cost Estimates

| Platform | Free Tier | Paid (Est.) | Notes |
|----------|-----------|-------------|-------|
| Railway | $5 free credit | ~$5-10/month | Scales automatically |
| Render | 750 hours/month | ~$7/month | Free tier sufficient |
| Fly.io | None | ~$3-5/month | Pay per use |
| Heroku | Hobby $7/month | $7+/month | Simple setup |

**API Costs:**
- Figma API: Free (rate limited)
- Gemini Vision: ~$0.002 per image
- Typical request: $0.01 (5 images)

**Monthly estimate:** ~$10-20 for hosting + API usage

---

## 🧪 Testing Your Deployment

### Test Connection

```bash
# Test health
curl https://your-deployed-url.com/health

# Test via MCP (with Python)
python test_mcp_connection.py
```

### Test Script:

Create `test_mcp_connection.py`:
```python
import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def test():
    params = StdioServerParameters(
        command="python",
        args=["mcp_server.py"]
    )

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # Test list tools
            tools = await session.list_tools()
            print(f"✅ Found {len(tools.tools)} tools")

            # Test extraction
            result = await session.call_tool(
                "list_supported_components",
                {}
            )
            print("✅ Tool execution successful")
            print(result)

asyncio.run(test())
```

---

## 🎉 You're Done!

Your MCP server is now hosted and ready to use!

**Share your server with others:**
1. Give them your server URL
2. They add it to their Claude Desktop config
3. They can extract Figma components instantly!

---

## 📚 Resources

- **MCP Protocol:** https://modelcontextprotocol.io/
- **Claude Desktop:** https://claude.ai/download
- **Railway Docs:** https://docs.railway.app/
- **Render Docs:** https://render.com/docs
- **Fly.io Docs:** https://fly.io/docs/

---

## 🆘 Troubleshooting

### "Cannot connect to MCP server"

**Check:**
1. Server is running: `curl your-url/health`
2. Environment variables are set
3. Firewall allows connections
4. Config file is correct JSON

### "Tool execution failed"

**Check:**
1. Figma PAT token is valid
2. Gemini API key is set
3. Figma URL is accessible
4. Check server logs

### "Rate limited"

**Solutions:**
1. Add delays between requests
2. Cache results
3. Implement request queue
4. Use paid Figma API tier

---

**Last Updated:** October 27, 2025
**Status:** ✅ Ready for Production Deployment
