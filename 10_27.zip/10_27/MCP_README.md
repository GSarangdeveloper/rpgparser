# 🎯 Figma Component Extractor - MCP Server

> **Hosted MCP server** that extracts UI components from Figma designs using AI. Works with any MCP client (Claude Desktop, etc.)

---

## 🚀 One-Click Deploy

### Railway (Recommended - Easiest)

1. Click here: **[Deploy to Railway](https://railway.app/template)**
2. Add your API keys:
   - `GEMINI_API_KEY` (required)
   - `FIGMA_PAT_TOKEN` (optional)
3. ✅ Done! Copy your server URL

**Cost:** ~$5/month

---

### Render (Free Tier)

1. Fork this repo
2. Click: **[Deploy to Render](https://dashboard.render.com/)**
3. Connect repo → Detects `render.yaml` automatically
4. Add API keys in environment
5. ✅ Done!

**Cost:** FREE

---

## 📱 Use with Claude Desktop

### Step 1: Deploy Server (above)

### Step 2: Configure Claude Desktop

Edit: `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "figma-extractor": {
      "command": "python",
      "args": ["/path/to/mcp_server.py"],
      "env": {
        "GEMINI_API_KEY": "your_key"
      }
    }
  }
}
```

### Step 3: Restart Claude Desktop

### Step 4: Use It!

```
You: Extract components from https://www.figma.com/file/abc123/Design

Claude: [Automatically uses the MCP tool]

Result:
- button
- text-input
- card
- navbar
- modal
- table
...
```

---

## 🛠️ Tools Available

| Tool | Description |
|------|-------------|
| `extract_figma_components` | Full extraction (API + AI Vision) |
| `extract_figma_for_enterprise` | Format for code generation APIs |
| `list_supported_components` | List all 38+ component types |

---

## ⚙️ Local Testing

```bash
# Install dependencies
pip install -r requirements_mcp.txt

# Set environment
export GEMINI_API_KEY=your_key
export FIGMA_PAT_TOKEN=your_token

# Run server
python mcp_server.py
```

---

## 📖 Full Documentation

- **Deployment Guide:** [MCP_DEPLOYMENT.md](MCP_DEPLOYMENT.md)
- **API Documentation:** [USAGE.md](USAGE.md)
- **Technical Details:** [DUAL_METHOD_EXTRACTION.md](DUAL_METHOD_EXTRACTION.md)

---

## 💡 Example Usage in Claude

**Prompt:**
> Extract UI components from my Figma design file at https://www.figma.com/file/xyz789/Dashboard

**Claude's Response:**
> I'll extract the components from your Figma file.
>
> [Uses extract_figma_components tool]
>
> Found 15 components:
> - button (primary, secondary variants)
> - text-input
> - select
> - card (product cards, stat cards)
> - navbar
> - sidebar
> - table (with sorting and pagination)
> - modal
> - badge
> - avatar
> - tabs
> - chart
> - pagination
> - tooltip
> - progress-bar
>
> The extraction used both Figma API and AI vision analysis for 95% accuracy.

---

## 🎯 Features

✅ **Automatic Image Export** - No manual screenshots
✅ **AI Vision Analysis** - Gemini identifies all components
✅ **Dual Method** - API + Vision for >85% accuracy
✅ **38+ Component Types** - Buttons, forms, navigation, etc.
✅ **MCP Protocol** - Works with any MCP client
✅ **Hosted** - Deploy once, use anywhere
✅ **Low Code** - One-click deployment

---

## 🔑 Get API Keys

### Gemini API Key (Required)
1. https://makersuite.google.com/app/apikey
2. Click "Create API Key"
3. Copy key

### Figma PAT Token (Optional)
1. https://www.figma.com/settings
2. Generate Personal Access Token
3. Copy token

---

## 💰 Costs

- **Hosting:** $0-10/month (free tier available)
- **API Usage:** ~$0.01 per extraction
- **Total:** ~$10-20/month for moderate use

---

## 🆘 Support

- **Issues:** [GitHub Issues](https://github.com/your-repo/issues)
- **Documentation:** See `MCP_DEPLOYMENT.md`
- **MCP Protocol:** https://modelcontextprotocol.io/

---

**Status:** ✅ Production Ready
**Version:** 1.0.0
**License:** MIT
