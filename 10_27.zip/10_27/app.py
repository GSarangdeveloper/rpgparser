"""Main Flask application"""

import logging
from flask import Flask, render_template, send_from_directory
from flask_cors import CORS

from figma_extractor.config import Config
from figma_extractor.api.routes import api_bp

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load configuration
config = Config.from_env()

# Create Flask app
app = Flask(__name__,
            template_folder='figma_extractor/templates',
            static_folder='figma_extractor/static')
app.config['DEBUG'] = config.flask_debug

# Enable CORS
CORS(app)

# Register blueprints
app.register_blueprint(api_bp)


@app.route('/')
def index():
    """Home page"""
    return render_template('index.html')


@app.route('/favicon.ico')
def favicon():
    """Favicon"""
    return send_from_directory(
        app.static_folder,
        'favicon.ico',
        mimetype='image/vnd.microsoft.icon'
    )


@app.errorhandler(404)
def not_found(e):
    """404 error handler"""
    return {"error": "Not found"}, 404


@app.errorhandler(500)
def server_error(e):
    """500 error handler"""
    logger.error(f"Server error: {e}", exc_info=True)
    return {"error": "Internal server error"}, 500


if __name__ == '__main__':
    logger.info(f"Starting Figma Component Extractor on port {config.port}")
    logger.info(f"Debug mode: {config.flask_debug}")

    # Check if required API keys are set
    if not config.figma_pat_token:
        logger.warning("FIGMA_PAT_TOKEN not set - users must provide token in requests")

    if not config.gemini_api_key:
        logger.warning("GEMINI_API_KEY not set - vision analysis will be disabled")

    app.run(
        host='0.0.0.0',
        port=config.port,
        debug=config.flask_debug
    )
