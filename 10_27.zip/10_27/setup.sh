#!/bin/bash
# Setup script for Figma Component Extractor

echo "🎨 Figma Component Extractor - Setup"
echo "====================================="
echo ""

# Check Python version
echo "Checking Python version..."
python3 --version

if [ $? -ne 0 ]; then
    echo "❌ Python 3 is not installed. Please install Python 3.11 or higher."
    exit 1
fi

# Create virtual environment
echo ""
echo "Creating virtual environment..."
python3 -m venv venv

if [ $? -ne 0 ]; then
    echo "❌ Failed to create virtual environment"
    exit 1
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo ""
echo "Upgrading pip..."
pip install --upgrade pip

# Install dependencies
echo ""
echo "Installing dependencies..."
pip install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo ""
    echo "Creating .env file..."
    cp .env.example .env
    echo "✓ Created .env file"
    echo "⚠️  Please edit .env and add your API keys:"
    echo "   - FIGMA_PAT_TOKEN"
    echo "   - GEMINI_API_KEY (optional)"
fi

# Create necessary directories
echo ""
echo "Creating directories..."
mkdir -p figma_extractor/static/css
mkdir -p figma_extractor/static/js
mkdir -p figma_extractor/templates
mkdir -p figma_extractor/tests

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env and add your API keys"
echo "2. Activate virtual environment: source venv/bin/activate"
echo "3. Run the application: python app.py"
echo "4. Visit http://localhost:5000"
echo ""
