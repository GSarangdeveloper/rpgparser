# Figma Component Extractor - Usage Guide

Complete guide to using the Figma Component Extractor for extracting UI components and generating Angular code.

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Web Interface](#web-interface)
5. [API Usage](#api-usage)
6. [Integration with Enterprise API](#integration-with-enterprise-api)
7. [Troubleshooting](#troubleshooting)

---

## Quick Start

### 1. Install Dependencies

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install packages
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
# Copy template
cp .env.example .env

# Edit .env and add your tokens
nano .env
```

Required environment variables:
```env
FIGMA_PAT_TOKEN=figd_your_token_here
GEMINI_API_KEY=your_gemini_key_here  # Optional for vision analysis
```

### 3. Run Application

```bash
python app.py
```

Visit: http://localhost:5000

---

## Installation

### Prerequisites

- Python 3.11 or higher
- pip (Python package manager)
- Figma Personal Access Token
- (Optional) Google Gemini API key for vision analysis

### Step-by-Step Installation

#### 1. Clone or Download

```bash
cd /path/to/your/projects
# If you have the files, navigate to the directory
cd figma_extractor
```

#### 2. Create Virtual Environment

```bash
# macOS/Linux
python3 -m venv venv
source venv/bin/activate

# Windows
python -m venv venv
venv\Scripts\activate
```

#### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

#### 4. Verify Installation

```bash
python -c "import flask; import requests; print('Dependencies OK')"
```

---

## Configuration

### Getting API Keys

#### Figma PAT Token

1. Go to https://www.figma.com/settings
2. Scroll to "Personal access tokens"
3. Click "Generate new token"
4. Give it a name (e.g., "Component Extractor")
5. Copy the token (starts with `figd_`)

#### Gemini API Key (Optional)

1. Go to https://makersuite.google.com/app/apikey
2. Click "Create API Key"
3. Copy the key

### Environment Variables

Edit `.env` file:

```env
# Required
FIGMA_PAT_TOKEN=figd_xxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Optional (for AI vision analysis)
GEMINI_API_KEY=AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Optional Configuration
FLASK_ENV=development
FLASK_DEBUG=True
PORT=5000
CONFIDENCE_THRESHOLD=0.65
USE_GEMINI_VISION=true
```

### Configuration Options

| Variable | Default | Description |
|----------|---------|-------------|
| `FIGMA_PAT_TOKEN` | - | Required: Your Figma token |
| `GEMINI_API_KEY` | - | Optional: For vision analysis |
| `PORT` | 5000 | Server port |
| `CONFIDENCE_THRESHOLD` | 0.65 | Minimum confidence (0-1) |
| `USE_GEMINI_VISION` | true | Enable vision analysis |

---

## Web Interface

### Using the Web UI

1. **Start the server:**
   ```bash
   python app.py
   ```

2. **Open browser:**
   ```
   http://localhost:5000
   ```

3. **Enter Figma URL:**
   - Paste your Figma file URL
   - Format: `https://www.figma.com/file/{file_key}/...`
   - Or just the file key

4. **Add PAT Token:**
   - Enter your Figma Personal Access Token
   - Or leave empty if set in `.env`

5. **Click Extract:**
   - Components will be displayed in a grid
   - JSON output shown below

### Example Workflow

```
1. Paste URL: https://www.figma.com/file/abc123/Design-System
2. Enter Token: figd_your_token
3. Click "Extract Components"
4. View results:
   - Components: button, card, navbar, text-input...
   - Processing time: 850ms
   - JSON output for API integration
```

---

## API Usage

### Endpoint: Simple Extraction

**POST** `/api/extract/simple`

Extract components using Figma API only (fastest, no vision).

**Request:**
```json
{
  "figma_url": "https://www.figma.com/file/abc123/Design",
  "pat_token": "figd_your_token"
}
```

**Response:**
```json
{
  "status": "success",
  "components": [
    "button",
    "text-input",
    "card",
    "navbar",
    "table",
    "modal"
  ],
  "count": 6,
  "processing_time_ms": 850
}
```

### Endpoint: Full Extraction (with Vision)

**POST** `/api/extract`

Extract using both Figma API and AI Vision analysis.

**Request:**
```json
{
  "figma_url": "https://www.figma.com/file/abc123/Design",
  "pat_token": "figd_your_token",
  "use_vision": true,
  "screenshot_url": "https://example.com/screenshot.png"
}
```

**Response:**
```json
{
  "status": "success",
  "extraction_method": "both",
  "components": [
    "button",
    "text-input",
    "select",
    "card",
    "navbar",
    "sidebar",
    "table",
    "modal",
    "badge"
  ],
  "count": 9,
  "metadata": {
    "processing_time_ms": 2450,
    "methods_used": ["figma_api", "gemini_vision"],
    "api_found": 6,
    "vision_found": 7,
    "both_found": 4
  }
}
```

### Endpoint: Get Supported Types

**GET** `/api/components/types`

Get list of all supported component types.

**Response:**
```json
{
  "status": "success",
  "component_types": [
    "button",
    "fab",
    "icon-button",
    "text-input",
    "select",
    "checkbox",
    "radio",
    "switch",
    "...and 30+ more"
  ],
  "count": 38
}
```

### cURL Examples

#### Simple extraction:
```bash
curl -X POST http://localhost:5000/api/extract/simple \
  -H "Content-Type: application/json" \
  -d '{
    "figma_url": "https://www.figma.com/file/abc123/Design",
    "pat_token": "figd_your_token"
  }'
```

#### Python example:
```python
import requests

response = requests.post(
    'http://localhost:5000/api/extract/simple',
    json={
        'figma_url': 'https://www.figma.com/file/abc123/Design',
        'pat_token': 'figd_your_token'
    }
)

data = response.json()
print(f"Found {data['count']} components:")
for component in data['components']:
    print(f"  - {component}")
```

---

## Integration with Enterprise API

### Workflow: Figma → Components → Angular Code

```
Step 1: Extract Components
↓
Step 2: Format for Enterprise API
↓
Step 3: Send to Code Generation API
↓
Step 4: Receive Angular Files
```

### Step 1: Extract Components

```python
import requests

# Extract from Figma
response = requests.post(
    'http://localhost:5000/api/extract/simple',
    json={
        'figma_url': 'https://www.figma.com/file/abc123/App',
        'pat_token': 'figd_your_token'
    }
)

extraction = response.json()
components = extraction['components']
print(f"Extracted: {components}")
```

### Step 2: Format for Enterprise API

```python
# Prepare payload for your enterprise API
enterprise_payload = {
    "request_id": "req-001",
    "components": components,
    "framework": "angular",
    "version": "17",
    "generate_code": True,
    "options": {
        "standalone": True,
        "style": "scss",
        "changeDetection": "OnPush"
    }
}
```

### Step 3: Send to Code Generation

```python
# Send to your enterprise API
code_response = requests.post(
    'https://your-enterprise-api.com/generate',
    json=enterprise_payload,
    headers={'Authorization': 'Bearer your_api_key'}
)

generated_code = code_response.json()
```

### Step 4: Process Generated Files

```python
# Save generated Angular files
for file in generated_code['files']:
    with open(file['path'], 'w') as f:
        f.write(file['content'])
    print(f"Created: {file['path']}")
```

### Complete Integration Example

```python
#!/usr/bin/env python3
"""Complete workflow: Figma → Components → Angular Code"""

import requests
import json
import os

# Configuration
FIGMA_URL = "https://www.figma.com/file/abc123/MyApp"
FIGMA_TOKEN = os.getenv("FIGMA_PAT_TOKEN")
EXTRACTOR_URL = "http://localhost:5000"
ENTERPRISE_API_URL = "https://your-api.com/generate"
ENTERPRISE_API_KEY = os.getenv("ENTERPRISE_API_KEY")

def extract_components():
    """Step 1: Extract components from Figma"""
    print("Extracting components from Figma...")

    response = requests.post(
        f"{EXTRACTOR_URL}/api/extract/simple",
        json={
            "figma_url": FIGMA_URL,
            "pat_token": FIGMA_TOKEN
        }
    )

    if response.status_code != 200:
        raise Exception(f"Extraction failed: {response.text}")

    data = response.json()
    print(f"✓ Found {data['count']} components")
    return data['components']

def generate_angular_code(components):
    """Step 2-3: Send to enterprise API and get Angular code"""
    print("Generating Angular code...")

    payload = {
        "request_id": "figma-extract-001",
        "components": components,
        "framework": "angular",
        "version": "17",
        "generate_code": True
    }

    response = requests.post(
        ENTERPRISE_API_URL,
        json=payload,
        headers={"Authorization": f"Bearer {ENTERPRISE_API_KEY}"}
    )

    if response.status_code != 200:
        raise Exception(f"Code generation failed: {response.text}")

    print("✓ Code generated successfully")
    return response.json()

def save_generated_files(generated_code):
    """Step 4: Save generated files to disk"""
    print("Saving files...")

    output_dir = "generated_angular_components"
    os.makedirs(output_dir, exist_ok=True)

    for file in generated_code.get('files', []):
        file_path = os.path.join(output_dir, file['path'])
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        with open(file_path, 'w') as f:
            f.write(file['content'])

        print(f"✓ Created: {file_path}")

    print(f"\n✓ All files saved to {output_dir}/")

def main():
    """Main workflow"""
    try:
        # Step 1: Extract
        components = extract_components()

        # Step 2-3: Generate
        generated_code = generate_angular_code(components)

        # Step 4: Save
        save_generated_files(generated_code)

        print("\n✅ Complete workflow finished successfully!")

    except Exception as e:
        print(f"\n❌ Error: {e}")
        return 1

    return 0

if __name__ == "__main__":
    exit(main())
```

---

## Troubleshooting

### Common Issues

#### 1. "Invalid Figma PAT token"

**Solution:**
- Verify your token is correct
- Check token hasn't expired
- Ensure token has file access permissions

#### 2. "Failed to fetch Figma file"

**Possible causes:**
- Invalid file URL or key
- File is private and token doesn't have access
- Network connectivity issues

**Solution:**
```bash
# Test Figma API access
curl -H "X-Figma-Token: YOUR_TOKEN" \
  https://api.figma.com/v1/files/YOUR_FILE_KEY
```

#### 3. "No components detected"

**Possible causes:**
- File has no Figma components
- File only has frames/groups (not actual components)
- Components have non-standard names

**Solution:**
- Check your Figma file has component instances
- Use vision analysis for better detection
- Verify component naming follows patterns

#### 4. "Vision analysis failed"

**Possible causes:**
- No GEMINI_API_KEY set
- API key invalid or expired
- Rate limit exceeded

**Solution:**
```bash
# Verify Gemini key
export GEMINI_API_KEY="your_key"
python -c "import os; print('Key set' if os.getenv('GEMINI_API_KEY') else 'No key')"
```

#### 5. Port already in use

**Solution:**
```bash
# Change port in .env
PORT=5001

# Or specify when running
python app.py --port 5001
```

### Debug Mode

Enable detailed logging:

```bash
# In .env
ENABLE_DETAILED_LOGGING=true
FLASK_DEBUG=true

# Run with verbose output
python app.py
```

### Testing API

```bash
# Health check
curl http://localhost:5000/api/health

# Should return:
# {"status": "healthy", "service": "figma-component-extractor"}
```

---

## Support

For issues, questions, or feature requests:

1. Check this documentation
2. Review the specification document
3. Check logs for error details
4. Test with simple Figma files first

---

**Last Updated:** October 27, 2025
