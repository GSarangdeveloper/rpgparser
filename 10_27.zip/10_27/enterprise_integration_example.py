#!/usr/bin/env python3
"""
Enterprise API Integration Example
Complete workflow: Figma → Extract Components → Enterprise API → Angular Code
"""

import requests
import json
import os
from typing import Dict, Any


# Configuration
FIGMA_EXTRACTOR_URL = "http://localhost:5000"
ENTERPRISE_API_URL = "https://your-enterprise-api.com/generate"  # Replace with your actual API
ENTERPRISE_API_KEY = os.getenv("ENTERPRISE_API_KEY", "your_api_key_here")

# Test Figma file
FIGMA_URL = "https://www.figma.com/file/abc123/YourDesignFile"
FIGMA_TOKEN = os.getenv("FIGMA_PAT_TOKEN", "your_figma_token_here")


def extract_components_enterprise_format(
    figma_url: str,
    figma_token: str,
    framework: str = "angular",
    version: str = "17"
) -> Dict[str, Any]:
    """
    Step 1: Extract components from Figma in enterprise API format.

    Args:
        figma_url: Figma file URL
        figma_token: Figma PAT token
        framework: Target framework
        version: Framework version

    Returns:
        Enterprise API formatted response
    """
    print("🔍 Extracting components from Figma...")

    response = requests.post(
        f"{FIGMA_EXTRACTOR_URL}/api/extract/enterprise",
        json={
            "figma_url": figma_url,
            "pat_token": figma_token,
            "framework": framework,
            "version": version,
            "generate_files": ["html", "ts", "spec", "usage"],
            "component_features": {
                "data-table": ["sorting", "pagination", "filtering"],
                "select": ["search", "multi-select"],
                "modal": ["backdrop", "close-button"]
            }
        }
    )

    if response.status_code != 200:
        raise Exception(f"Extraction failed: {response.text}")

    data = response.json()
    print(f"✅ Extracted {len(data['component_requirements'])} components")

    return data


def send_to_enterprise_api(component_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Step 2: Send component requirements to enterprise API for code generation.

    Args:
        component_data: Component requirements from extractor

    Returns:
        Enterprise API response with generated code
    """
    print("\n📤 Sending to Enterprise API for code generation...")

    # Note: This is a mock example. Replace with your actual enterprise API call
    response = requests.post(
        ENTERPRISE_API_URL,
        json=component_data,
        headers={
            "Authorization": f"Bearer {ENTERPRISE_API_KEY}",
            "Content-Type": "application/json"
        }
    )

    if response.status_code != 200:
        raise Exception(f"Code generation failed: {response.text}")

    result = response.json()
    print(f"✅ Generated code for {len(result.get('files', []))} files")

    return result


def save_generated_files(generated_code: Dict[str, Any], output_dir: str = "generated_components"):
    """
    Step 3: Save generated Angular files to disk.

    Args:
        generated_code: Enterprise API response
        output_dir: Output directory
    """
    print(f"\n💾 Saving files to {output_dir}/...")

    os.makedirs(output_dir, exist_ok=True)

    files = generated_code.get('files', [])
    for file_info in files:
        file_path = os.path.join(output_dir, file_info['path'])

        # Create directories if needed
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        # Write file
        with open(file_path, 'w') as f:
            f.write(file_info['content'])

        print(f"  ✓ {file_info['path']}")

    print(f"\n✅ All files saved successfully")


def main():
    """Main workflow"""
    print("=" * 60)
    print("  Figma → Enterprise API Integration")
    print("=" * 60)
    print()

    try:
        # Step 1: Extract components from Figma (in enterprise format)
        component_data = extract_components_enterprise_format(
            figma_url=FIGMA_URL,
            figma_token=FIGMA_TOKEN,
            framework="angular",
            version="17"
        )

        # Display extracted components
        print("\n📋 Component Requirements:")
        print(json.dumps(component_data, indent=2))

        # Option 1: Send directly to enterprise API
        # (Uncomment when ready to use with real enterprise API)
        """
        generated_code = send_to_enterprise_api(component_data)
        save_generated_files(generated_code)
        """

        # Option 2: Save component requirements to file for manual processing
        output_file = "component_requirements.json"
        with open(output_file, 'w') as f:
            json.dump(component_data, f, indent=2)
        print(f"\n💾 Component requirements saved to: {output_file}")
        print("   You can now send this to your enterprise API")

        print("\n" + "=" * 60)
        print("  ✅ Workflow Complete!")
        print("=" * 60)

    except Exception as e:
        print(f"\n❌ Error: {e}")
        return 1

    return 0


if __name__ == "__main__":
    exit(main())
