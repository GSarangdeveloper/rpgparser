#!/bin/bash
# Quick deployment script for Figma MCP Server

echo "🚀 Figma Component Extractor - MCP Server Deployment"
echo "======================================================"
echo ""

# Check if platform is specified
if [ -z "$1" ]; then
    echo "Usage: ./deploy.sh [railway|render|fly|docker]"
    echo ""
    echo "Options:"
    echo "  railway - Deploy to Railway (easiest)"
    echo "  render  - Deploy to Render (free tier)"
    echo "  fly     - Deploy to Fly.io (fast)"
    echo "  docker  - Build and run Docker locally"
    exit 1
fi

PLATFORM=$1

case $PLATFORM in
    railway)
        echo "📦 Deploying to Railway..."
        echo ""
        echo "1. Install Railway CLI:"
        echo "   npm install -g @railway/cli"
        echo ""
        echo "2. Login:"
        echo "   railway login"
        echo ""
        echo "3. Initialize project:"
        echo "   railway init"
        echo ""
        echo "4. Add environment variables:"
        echo "   railway variables set GEMINI_API_KEY=your_key"
        echo "   railway variables set FIGMA_PAT_TOKEN=your_token"
        echo ""
        echo "5. Deploy:"
        echo "   railway up"
        echo ""
        ;;

    render)
        echo "📦 Deploying to Render..."
        echo ""
        echo "1. Go to: https://dashboard.render.com/"
        echo "2. Click 'New +' → 'Blueprint'"
        echo "3. Connect this repository"
        echo "4. It will detect render.yaml automatically"
        echo "5. Add environment variables in Render dashboard"
        echo "6. Click 'Deploy'"
        echo ""
        ;;

    fly)
        echo "📦 Deploying to Fly.io..."
        echo ""

        # Check if flyctl is installed
        if ! command -v flyctl &> /dev/null; then
            echo "Installing Fly CLI..."
            curl -L https://fly.io/install.sh | sh
        fi

        echo "Logging in to Fly.io..."
        flyctl auth login

        echo "Launching app..."
        flyctl launch --no-deploy

        echo "Setting secrets..."
        read -p "Enter GEMINI_API_KEY: " gemini_key
        read -p "Enter FIGMA_PAT_TOKEN (optional): " figma_token

        flyctl secrets set GEMINI_API_KEY="$gemini_key"

        if [ -n "$figma_token" ]; then
            flyctl secrets set FIGMA_PAT_TOKEN="$figma_token"
        fi

        echo "Deploying..."
        flyctl deploy

        echo ""
        echo "✅ Deployed successfully!"
        echo "Your MCP server URL:"
        flyctl info
        ;;

    docker)
        echo "🐳 Building Docker image..."

        # Build image
        docker build -t figma-mcp-server .

        echo ""
        echo "Running container..."

        # Check if .env exists
        if [ -f .env ]; then
            docker run -d \
                -p 8080:8080 \
                --env-file .env \
                --name figma-mcp \
                figma-mcp-server
        else
            echo "⚠️  No .env file found"
            echo "Creating from template..."
            cp .env.example .env
            echo ""
            echo "Please edit .env and add your API keys, then run:"
            echo "  docker run -d -p 8080:8080 --env-file .env --name figma-mcp figma-mcp-server"
            exit 1
        fi

        echo ""
        echo "✅ Container running!"
        echo "View logs: docker logs -f figma-mcp"
        echo "Stop: docker stop figma-mcp"
        echo "Remove: docker rm figma-mcp"
        ;;

    *)
        echo "❌ Unknown platform: $PLATFORM"
        echo "Use: railway, render, fly, or docker"
        exit 1
        ;;
esac

echo ""
echo "🎉 Deployment initiated!"
echo ""
echo "Next steps:"
echo "1. Wait for deployment to complete"
echo "2. Copy your server URL"
echo "3. Add to Claude Desktop config"
echo "4. Start using the MCP tools!"
echo ""
echo "📚 Documentation: MCP_DEPLOYMENT.md"
