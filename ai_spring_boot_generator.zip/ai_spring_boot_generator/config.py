import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('FLASK_SECRET_KEY') or 'dev-secret-key-change-in-production'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///api_generator.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
    OPENAI_MODEL = "gpt-4-turbo-preview"
    
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER') or './uploads'
    GENERATED_PROJECTS_FOLDER = os.environ.get('GENERATED_PROJECTS_FOLDER') or './generated_projects'
    TEMPLATES_LIBRARY_FOLDER = os.environ.get('TEMPLATES_LIBRARY_FOLDER') or './templates_library'
    
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'txt', 'json', 'yaml', 'yml'}
    
    SESSION_TYPE = 'filesystem'
    SESSION_PERMANENT = False
    
    STAGE_NAMES = {
        'stage1': 'Business Requirement Processing',
        'stage2': 'API Design',
        'stage3': 'Code Generation'
    }
    
    GENERATION_MODES = {
        'autonomous': 'Autonomous Mode - GPT-4 generates complete Spring Boot project',
        'template_enhanced': 'Template-Enhanced Mode - Uses organizational templates'
    }