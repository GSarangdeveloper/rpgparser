import json
from typing import Dict, Any, List, Optional
from utils.openai_client import OpenAIClient

class APIDesignAgent:
    """Stage 2 Agent: Transform API requirements into technical design"""
    
    def __init__(self):
        self.openai_client = OpenAIClient()
        self.stage_name = "API Design"
    
    def generate_technical_architecture(self, api_spec: Dict[str, Any], templates: Optional[List[Dict]] = None) -> Dict[str, Any]:
        """Generate technical architecture from API specification"""
        
        system_prompt = """You are an expert Spring Boot architect with deep knowledge of enterprise patterns.
        Design a comprehensive technical architecture for Spring Boot applications using Gradle build system.
        Consider scalability, maintainability, and best practices."""
        
        template_context = ""
        if templates:
            template_context = f"\n\nAvailable organizational templates:\n{json.dumps([t.get('name') for t in templates])}"
        
        user_prompt = f"""Based on this API specification, design the technical architecture:

        API Specification:
        {json.dumps(api_spec, indent=2)}
        {template_context}

        Generate a comprehensive technical design including:
        
        1. Project Structure:
           - Package organization (com.company.api.*)
           - Module breakdown
           - Layer separation (controller, service, repository, entity, dto, config)
        
        2. Spring Boot Components:
           - Required Spring Boot starters
           - Gradle dependencies with versions
           - Spring profiles for different environments
        
        3. Database Design:
           - JPA entities with relationships
           - Database schema
           - Migration strategy (Flyway/Liquibase)
        
        4. Security Architecture:
           - Authentication mechanism (JWT/OAuth2/Basic)
           - Authorization strategy (roles, permissions)
           - Security configurations
        
        5. Integration Patterns:
           - External API integrations
           - Message queue requirements
           - Caching strategy
        
        6. Configuration Management:
           - Application properties structure
           - Environment-specific configurations
           - Externalized configuration approach

        Return as JSON:
        {{
            "project_structure": {{...}},
            "dependencies": [...],
            "database_design": {{...}},
            "security_architecture": {{...}},
            "integration_patterns": {{...}},
            "configuration": {{...}},
            "selected_templates": [...]
        }}"""
        
        messages = [{"role": "user", "content": user_prompt}]
        
        response = self.openai_client.create_completion(
            messages=messages,
            temperature=0.3,
            max_tokens=8000,
            system_prompt=system_prompt
        )
        
        if response["success"]:
            return response["data"]
        else:
            raise Exception(f"Failed to generate technical architecture: {response.get('error', 'Unknown error')}")
    
    def design_database_schema(self, data_models: Dict[str, Any], relationships: List[Dict]) -> Dict[str, Any]:
        """Design database schema with JPA entities"""
        
        system_prompt = """You are a database architect specializing in Spring Data JPA.
        Design optimal database schemas with proper normalization and JPA annotations."""
        
        user_prompt = f"""Design a database schema for these data models:

        Data Models:
        {json.dumps(data_models, indent=2)}
        
        Relationships:
        {json.dumps(relationships, indent=2)}

        Generate:
        1. JPA Entity definitions with annotations
        2. Database tables structure
        3. Indexes and constraints
        4. Repository interfaces
        5. DTOs for data transfer

        Return as JSON:
        {{
            "entities": [
                {{
                    "name": "...",
                    "table_name": "...",
                    "fields": [...],
                    "relationships": [...],
                    "indexes": [...],
                    "jpa_code": "..."
                }}
            ],
            "repositories": [...],
            "dtos": [...],
            "migration_scripts": [...]
        }}"""
        
        messages = [{"role": "user", "content": user_prompt}]
        
        response = self.openai_client.create_completion(
            messages=messages,
            temperature=0.3,
            max_tokens=6000,
            system_prompt=system_prompt
        )
        
        if response["success"]:
            return response["data"]
        else:
            raise Exception(f"Failed to design database schema: {response.get('error', 'Unknown error')}")
    
    def select_integration_templates(self, requirements: Dict[str, Any], available_templates: List[Dict]) -> List[Dict]:
        """Select appropriate templates based on requirements"""
        
        selected_templates = []
        
        # Template selection logic based on requirements
        template_categories = {
            "security": ["authentication", "authorization", "jwt", "oauth2"],
            "database": ["jpa", "repository", "migration"],
            "api": ["rest", "controller", "exception-handling"],
            "testing": ["unit-test", "integration-test"],
            "configuration": ["properties", "profiles", "logging"]
        }
        
        for template in available_templates:
            template_cat = template.get("category", "").lower()
            template_name = template.get("name", "").lower()
            
            # Check if template matches requirements
            if "security_requirements" in requirements and template_cat == "security":
                selected_templates.append(template)
            elif "database_design" in requirements and template_cat == "database":
                selected_templates.append(template)
            elif template_cat in ["api", "configuration", "testing"]:
                selected_templates.append(template)
        
        return selected_templates
    
    def generate_gradle_configuration(self, dependencies: List[str], project_info: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Gradle build configuration"""
        
        gradle_config = {
            "build_gradle": f"""plugins {{
    id 'java'
    id 'org.springframework.boot' version '3.2.0'
    id 'io.spring.dependency-management' version '1.1.4'
}}

group = '{project_info.get('group', 'com.example')}'
version = '{project_info.get('version', '0.0.1-SNAPSHOT')}'
sourceCompatibility = '17'

configurations {{
    compileOnly {{
        extendsFrom annotationProcessor
    }}
}}

repositories {{
    mavenCentral()
}}

dependencies {{
    {chr(10).join([f"    implementation '{dep}'" for dep in dependencies])}
    
    compileOnly 'org.projectlombok:lombok'
    annotationProcessor 'org.projectlombok:lombok'
    testImplementation 'org.springframework.boot:spring-boot-starter-test'
}}

tasks.named('test') {{
    useJUnitPlatform()
}}""",
            "settings_gradle": f"""rootProject.name = '{project_info.get('name', 'api-project')}'""",
            "gradle_properties": """org.gradle.jvmargs=-Xmx2048m
org.gradle.parallel=true
org.gradle.caching=true"""
        }
        
        return gradle_config
    
    def create_design_document(self, architecture: Dict[str, Any], database: Dict[str, Any]) -> Dict[str, Any]:
        """Create comprehensive design document"""
        
        design_doc = {
            "overview": {
                "architecture_style": "Layered Architecture with Spring Boot",
                "build_system": "Gradle",
                "java_version": "17",
                "spring_boot_version": "3.2.0"
            },
            "technical_architecture": architecture,
            "database_design": database,
            "api_standards": {
                "rest_conventions": "RESTful API following OpenAPI 3.0",
                "error_handling": "RFC 7807 Problem Details",
                "versioning": "URI versioning (/api/v1)",
                "pagination": "Spring Data Pageable",
                "filtering": "Query parameters with specifications"
            },
            "security_standards": {
                "authentication": architecture.get("security_architecture", {}).get("authentication", "JWT"),
                "authorization": "Role-based access control",
                "encryption": "TLS 1.3 for transport, BCrypt for passwords"
            },
            "deployment": {
                "containerization": "Docker with multi-stage builds",
                "orchestration": "Kubernetes ready",
                "ci_cd": "GitHub Actions / Jenkins pipeline"
            }
        }
        
        return design_doc
    
    def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Main processing method for Stage 2"""
        
        try:
            # Get input from Stage 1
            requirements = input_data.get("requirements", {})
            api_spec = input_data.get("api_specification", {})
            available_templates = input_data.get("templates", [])
            
            # Generate technical architecture
            architecture = self.generate_technical_architecture(api_spec, available_templates)
            
            # Design database schema
            database_design = self.design_database_schema(
                requirements.get("data_models", {}),
                requirements.get("relationships", [])
            )
            
            # Select appropriate templates
            selected_templates = self.select_integration_templates(requirements, available_templates)
            
            # Generate Gradle configuration
            gradle_config = self.generate_gradle_configuration(
                architecture.get("dependencies", []),
                {
                    "name": requirements.get("project_name", "spring-api"),
                    "group": "com.generated.api",
                    "version": "1.0.0"
                }
            )
            
            # Create design document
            design_document = self.create_design_document(architecture, database_design)
            
            return {
                "success": True,
                "stage": self.stage_name,
                "architecture": architecture,
                "database_design": database_design,
                "selected_templates": selected_templates,
                "gradle_configuration": gradle_config,
                "design_document": design_document,
                "next_stage_input": {
                    "api_specification": api_spec,
                    "architecture": architecture,
                    "database_design": database_design,
                    "selected_templates": selected_templates,
                    "gradle_configuration": gradle_config
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "stage": self.stage_name,
                "error": str(e),
                "architecture": None,
                "database_design": None
            }