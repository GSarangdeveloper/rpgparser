import json
import os
import shutil
import zipfile
from typing import Dict, Any, List, Optional
from pathlib import Path
from utils.openai_client import OpenAIClient
from jinja2 import Environment, FileSystemLoader, Template

class CodeGenerationAgent:
    """Stage 3 Agent: Generate complete Spring Boot application code"""
    
    def __init__(self):
        self.openai_client = OpenAIClient()
        self.stage_name = "Code Generation"
        self.base_package = "com.generated.api"
    
    def create_project_structure(self, project_name: str, output_dir: str) -> Dict[str, str]:
        """Create Spring Boot project directory structure"""
        
        project_path = os.path.join(output_dir, project_name)
        
        # Define directory structure
        directories = [
            "src/main/java/com/generated/api",
            "src/main/java/com/generated/api/controller",
            "src/main/java/com/generated/api/service",
            "src/main/java/com/generated/api/repository",
            "src/main/java/com/generated/api/entity",
            "src/main/java/com/generated/api/dto",
            "src/main/java/com/generated/api/config",
            "src/main/java/com/generated/api/exception",
            "src/main/java/com/generated/api/util",
            "src/main/java/com/generated/api/security",
            "src/main/resources",
            "src/main/resources/db/migration",
            "src/test/java/com/generated/api",
            "src/test/java/com/generated/api/controller",
            "src/test/java/com/generated/api/service",
            "src/test/resources",
            "gradle/wrapper"
        ]
        
        # Create directories
        for directory in directories:
            dir_path = os.path.join(project_path, directory)
            os.makedirs(dir_path, exist_ok=True)
        
        return {
            "project_root": project_path,
            "java_src": os.path.join(project_path, "src/main/java/com/generated/api"),
            "resources": os.path.join(project_path, "src/main/resources"),
            "test_src": os.path.join(project_path, "src/test/java/com/generated/api")
        }
    
    def generate_main_application(self, project_name: str) -> str:
        """Generate main Spring Boot application class"""
        
        class_name = ''.join(word.capitalize() for word in project_name.split('-'))
        
        code = f"""package com.generated.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@SpringBootApplication
@OpenAPIDefinition(
    info = @Info(
        title = "{project_name} API",
        version = "1.0.0",
        description = "Generated Spring Boot API"
    )
)
public class {class_name}Application {{

    public static void main(String[] args) {{
        SpringApplication.run({class_name}Application.class, args);
    }}
    
    @Bean
    public CorsFilter corsFilter() {{
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOriginPattern("*");
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }}
}}"""
        
        return code
    
    def generate_entity_class(self, entity_def: Dict[str, Any]) -> str:
        """Generate JPA entity class using GPT-4"""
        
        prompt = f"""Generate a complete JPA entity class for Spring Boot with these specifications:
        
        Entity Name: {entity_def.get('name')}
        Table Name: {entity_def.get('table_name')}
        Fields: {json.dumps(entity_def.get('fields', []))}
        Relationships: {json.dumps(entity_def.get('relationships', []))}
        
        Requirements:
        - Use Lombok annotations (@Data, @Builder, @NoArgsConstructor, @AllArgsConstructor)
        - Include proper JPA annotations (@Entity, @Table, @Id, @GeneratedValue, @Column)
        - Add validation annotations (@NotNull, @Size, @Email, etc.)
        - Include audit fields (createdAt, updatedAt) with @CreatedDate and @LastModifiedDate
        - Handle relationships properly (@OneToMany, @ManyToOne, @ManyToMany)
        - Use proper fetch strategies and cascade types
        
        Return only the Java code for the entity class."""
        
        code = self.openai_client.generate_code(prompt)
        return code
    
    def generate_repository_interface(self, entity_name: str) -> str:
        """Generate Spring Data JPA repository interface"""
        
        code = f"""package com.generated.api.repository;

import com.generated.api.entity.{entity_name};
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

@Repository
public interface {entity_name}Repository extends JpaRepository<{entity_name}, Long>, JpaSpecificationExecutor<{entity_name}> {{
    
    Optional<{entity_name}> findByIdAndDeletedFalse(Long id);
    
    List<{entity_name}> findAllByDeletedFalse();
    
    @Query("SELECT e FROM {entity_name} e WHERE e.deleted = false")
    List<{entity_name}> findAllActive();
    
    boolean existsByIdAndDeletedFalse(Long id);
}}"""
        
        return code
    
    def generate_service_class(self, entity_name: str, endpoints: List[Dict]) -> str:
        """Generate service class with business logic using GPT-4"""
        
        endpoint_methods = json.dumps([
            {
                "name": endpoint.get("operationId", endpoint.get("path")),
                "description": endpoint.get("summary", ""),
                "method": endpoint.get("method"),
                "business_logic": endpoint.get("description", "")
            }
            for endpoint in endpoints if entity_name.lower() in endpoint.get("path", "").lower()
        ])
        
        prompt = f"""Generate a complete Spring Boot service class for {entity_name} with these specifications:
        
        Entity: {entity_name}
        Service Methods needed based on endpoints: {endpoint_methods}
        
        Requirements:
        - Use @Service annotation
        - Inject repository using constructor injection
        - Implement CRUD operations (create, findById, findAll, update, delete)
        - Add proper transaction management (@Transactional)
        - Include business logic validation
        - Handle exceptions properly
        - Use DTOs for data transfer
        - Implement pagination and sorting where appropriate
        - Add logging using SLF4J
        
        Return only the Java code for the service class."""
        
        code = self.openai_client.generate_code(prompt)
        return code
    
    def generate_controller_class(self, entity_name: str, endpoints: List[Dict]) -> str:
        """Generate REST controller class using GPT-4"""
        
        prompt = f"""Generate a complete Spring Boot REST controller for {entity_name} with these endpoints:
        
        Endpoints: {json.dumps(endpoints, indent=2)}
        
        Requirements:
        - Use @RestController and @RequestMapping annotations
        - Implement all specified endpoints with proper HTTP methods
        - Use proper Spring annotations (@GetMapping, @PostMapping, @PutMapping, @DeleteMapping)
        - Include request validation (@Valid, @Validated)
        - Return proper HTTP status codes using ResponseEntity
        - Add Swagger/OpenAPI annotations for documentation
        - Implement pagination using Pageable
        - Include proper error handling
        - Use DTOs for request/response
        
        Return only the Java code for the controller class."""
        
        code = self.openai_client.generate_code(prompt)
        return code
    
    def generate_dto_classes(self, entity_name: str, schemas: Dict) -> Dict[str, str]:
        """Generate DTO classes for request and response"""
        
        dtos = {}
        
        # Request DTO
        request_dto_code = f"""package com.generated.api.dto;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import javax.validation.constraints.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class {entity_name}RequestDto {{
    
    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;
    
    @Size(max = 500, message = "Description cannot exceed 500 characters")
    private String description;
    
    // Add more fields based on entity
}}"""
        
        dtos[f"{entity_name}RequestDto.java"] = request_dto_code
        
        # Response DTO
        response_dto_code = f"""package com.generated.api.dto;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class {entity_name}ResponseDto {{
    
    private Long id;
    private String name;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    // Add more fields based on entity
}}"""
        
        dtos[f"{entity_name}ResponseDto.java"] = response_dto_code
        
        return dtos
    
    def generate_configuration_classes(self) -> Dict[str, str]:
        """Generate Spring Boot configuration classes"""
        
        configs = {}
        
        # Security Config
        configs["SecurityConfig.java"] = """package com.generated.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/**").permitAll()
                .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
                .anyRequest().authenticated()
            );
        
        return http.build();
    }
    
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}"""
        
        # JPA Config
        configs["JpaConfig.java"] = """package com.generated.api.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaRepositories(basePackages = "com.generated.api.repository")
@EnableJpaAuditing
@EnableTransactionManagement
public class JpaConfig {
}"""
        
        # Swagger Config
        configs["SwaggerConfig.java"] = """package com.generated.api.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
    
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("Generated API")
                .version("1.0.0")
                .description("API generated using AI-powered Spring Boot generator")
                .contact(new Contact()
                    .name("API Support")
                    .email("support@example.com"))
                .license(new License()
                    .name("Apache 2.0")
                    .url("http://www.apache.org/licenses/LICENSE-2.0.html")));
    }
}"""
        
        return configs
    
    def generate_application_properties(self) -> str:
        """Generate application.properties file"""
        
        properties = """# Server Configuration
server.port=8080
server.servlet.context-path=/

# Database Configuration
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=

# JPA Configuration
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.use_sql_comments=true

# H2 Console
spring.h2.console.enabled=true
spring.h2.console.path=/h2-console

# Logging
logging.level.root=INFO
logging.level.com.generated.api=DEBUG
logging.level.org.springframework.web=DEBUG
logging.level.org.hibernate.SQL=DEBUG
logging.level.org.hibernate.type.descriptor.sql.BasicBinder=TRACE

# Jackson Configuration
spring.jackson.serialization.write-dates-as-timestamps=false
spring.jackson.time-zone=UTC

# API Documentation
springdoc.api-docs.path=/v3/api-docs
springdoc.swagger-ui.path=/swagger-ui.html
springdoc.swagger-ui.enabled=true

# File Upload
spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=10MB

# Actuator
management.endpoints.web.exposure.include=health,info,metrics
management.endpoint.health.show-details=always"""
        
        return properties
    
    def generate_gradle_files(self, gradle_config: Dict[str, Any]) -> Dict[str, str]:
        """Generate Gradle build files"""
        
        files = {}
        
        # Enhanced build.gradle with all necessary dependencies
        files["build.gradle"] = """plugins {
    id 'java'
    id 'org.springframework.boot' version '3.2.0'
    id 'io.spring.dependency-management' version '1.1.4'
}

group = 'com.generated.api'
version = '1.0.0'
sourceCompatibility = '17'

configurations {
    compileOnly {
        extendsFrom annotationProcessor
    }
}

repositories {
    mavenCentral()
}

dependencies {
    // Spring Boot Starters
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'org.springframework.boot:spring-boot-starter-validation'
    implementation 'org.springframework.boot:spring-boot-starter-security'
    implementation 'org.springframework.boot:spring-boot-starter-actuator'
    
    // Database
    runtimeOnly 'com.h2database:h2'
    runtimeOnly 'org.postgresql:postgresql'
    runtimeOnly 'mysql:mysql-connector-java:8.0.33'
    
    // API Documentation
    implementation 'org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0'
    
    // Lombok
    compileOnly 'org.projectlombok:lombok'
    annotationProcessor 'org.projectlombok:lombok'
    
    // Utilities
    implementation 'org.apache.commons:commons-lang3:3.14.0'
    implementation 'com.google.guava:guava:32.1.3-jre'
    
    // Testing
    testImplementation 'org.springframework.boot:spring-boot-starter-test'
    testImplementation 'org.springframework.security:spring-security-test'
    testImplementation 'com.h2database:h2'
}

tasks.named('test') {
    useJUnitPlatform()
}

tasks.named('bootJar') {
    archiveBaseName = 'generated-api'
    archiveVersion = '1.0.0'
}"""
        
        files["settings.gradle"] = gradle_config.get("settings_gradle", "rootProject.name = 'generated-api'")
        files["gradle.properties"] = gradle_config.get("gradle_properties", "")
        
        # Gradle wrapper files
        files["gradlew"] = """#!/usr/bin/env sh
# Gradle wrapper script for Unix-based systems
exec "./gradle/wrapper/gradle-wrapper.jar" "$@" """
        
        files["gradlew.bat"] = """@rem Gradle wrapper script for Windows
@if "%DEBUG%" == "" @echo off
@rem Execute Gradle
"%JAVA_HOME%\\bin\\java.exe" -jar ".\\gradle\\wrapper\\gradle-wrapper.jar" %* """
        
        return files
    
    def write_files_to_project(self, paths: Dict[str, str], files: Dict[str, str]) -> None:
        """Write generated files to project structure"""
        
        for filename, content in files.items():
            if filename.endswith(".java"):
                # Determine package path from content
                if "controller" in filename.lower():
                    file_path = os.path.join(paths["java_src"], "controller", filename)
                elif "service" in filename.lower():
                    file_path = os.path.join(paths["java_src"], "service", filename)
                elif "repository" in filename.lower():
                    file_path = os.path.join(paths["java_src"], "repository", filename)
                elif "entity" in filename.lower():
                    file_path = os.path.join(paths["java_src"], "entity", filename)
                elif "dto" in filename.lower():
                    file_path = os.path.join(paths["java_src"], "dto", filename)
                elif "config" in filename.lower():
                    file_path = os.path.join(paths["java_src"], "config", filename)
                else:
                    file_path = os.path.join(paths["java_src"], filename)
            elif filename == "application.properties":
                file_path = os.path.join(paths["resources"], filename)
            elif filename in ["build.gradle", "settings.gradle", "gradle.properties", "gradlew", "gradlew.bat"]:
                file_path = os.path.join(paths["project_root"], filename)
            else:
                file_path = os.path.join(paths["project_root"], filename)
            
            # Write file
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # Make gradlew executable
            if filename == "gradlew":
                os.chmod(file_path, 0o755)
    
    def create_project_zip(self, project_path: str, output_dir: str) -> str:
        """Create ZIP file of generated project"""
        
        project_name = os.path.basename(project_path)
        zip_path = os.path.join(output_dir, f"{project_name}.zip")
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(project_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, os.path.dirname(project_path))
                    zipf.write(file_path, arcname)
        
        return zip_path
    
    def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Main processing method for Stage 3"""
        
        try:
            # Get input from Stage 2
            api_spec = input_data.get("api_specification", {})
            architecture = input_data.get("architecture", {})
            database_design = input_data.get("database_design", {})
            gradle_config = input_data.get("gradle_configuration", {})
            selected_templates = input_data.get("selected_templates", [])
            
            project_name = api_spec.get("api_name", "generated-api").lower().replace(" ", "-")
            output_dir = "./generated_projects"
            
            # Create project structure
            paths = self.create_project_structure(project_name, output_dir)
            
            # Generate all files
            generated_files = {}
            
            # Main application class
            app_class_name = ''.join(word.capitalize() for word in project_name.split('-')) + "Application.java"
            generated_files[app_class_name] = self.generate_main_application(project_name)
            
            # Generate entities, repositories, services, controllers
            entities = database_design.get("entities", [])
            for entity in entities:
                entity_name = entity.get("name", "Entity")
                
                # Entity class
                generated_files[f"{entity_name}.java"] = self.generate_entity_class(entity)
                
                # Repository interface
                generated_files[f"{entity_name}Repository.java"] = self.generate_repository_interface(entity_name)
                
                # Service class
                endpoints = api_spec.get("endpoints", [])
                generated_files[f"{entity_name}Service.java"] = self.generate_service_class(entity_name, endpoints)
                
                # Controller class
                generated_files[f"{entity_name}Controller.java"] = self.generate_controller_class(entity_name, endpoints)
                
                # DTOs
                dto_files = self.generate_dto_classes(entity_name, api_spec.get("schemas", {}))
                generated_files.update(dto_files)
            
            # Configuration classes
            config_files = self.generate_configuration_classes()
            generated_files.update(config_files)
            
            # Application properties
            generated_files["application.properties"] = self.generate_application_properties()
            
            # Gradle files
            gradle_files = self.generate_gradle_files(gradle_config)
            generated_files.update(gradle_files)
            
            # Write all files to project
            self.write_files_to_project(paths, generated_files)
            
            # Create ZIP file
            zip_path = self.create_project_zip(paths["project_root"], output_dir)
            
            return {
                "success": True,
                "stage": self.stage_name,
                "project_path": paths["project_root"],
                "zip_path": zip_path,
                "generated_files": list(generated_files.keys()),
                "message": f"Successfully generated Spring Boot project: {project_name}",
                "instructions": {
                    "build": "cd " + project_name + " && ./gradlew build",
                    "run": "./gradlew bootRun",
                    "test": "./gradlew test",
                    "package": "./gradlew bootJar",
                    "api_docs": "http://localhost:8080/swagger-ui.html"
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "stage": self.stage_name,
                "error": str(e),
                "project_path": None,
                "zip_path": None
            }