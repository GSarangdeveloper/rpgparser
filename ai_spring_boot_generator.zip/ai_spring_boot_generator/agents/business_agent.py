import json
from typing import Dict, Any, List, Optional
from utils.openai_client import OpenAIClient
import PyPDF2
import docx
from bs4 import BeautifulSoup
import yaml

class BusinessRequirementAgent:
    """Stage 1 Agent: Process business requirements and extract API specifications"""
    
    def __init__(self):
        self.openai_client = OpenAIClient()
        self.stage_name = "Business Requirement Processing"
    
    def process_document(self, file_path: str, file_type: str) -> str:
        """Extract text content from various document formats"""
        content = ""
        
        if file_type == 'pdf':
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                for page in pdf_reader.pages:
                    content += page.extract_text()
                    
        elif file_type in ['doc', 'docx']:
            doc = docx.Document(file_path)
            for paragraph in doc.paragraphs:
                content += paragraph.text + "\n"
                
        elif file_type == 'txt':
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
                
        elif file_type in ['json', 'yaml', 'yml']:
            with open(file_path, 'r', encoding='utf-8') as file:
                if file_type == 'json':
                    data = json.load(file)
                else:
                    data = yaml.safe_load(file)
                content = json.dumps(data, indent=2)
        
        return content
    
    def extract_requirements(self, document_content: str, additional_context: Optional[Dict] = None) -> Dict[str, Any]:
        """Extract structured requirements from business documents"""
        
        system_prompt = """You are an expert business analyst specializing in API requirement extraction.
        Analyze the provided business document and extract comprehensive API requirements.
        Focus on identifying all business entities, relationships, API endpoints, and business rules.
        Return a structured JSON response."""
        
        user_prompt = f"""Analyze this business requirement document and extract the following information:

        1. Business Entities: Identify all business objects/entities with their properties
        2. API Endpoints: List all required API endpoints with:
           - HTTP method (GET, POST, PUT, DELETE, etc.)
           - Path/URL pattern
           - Purpose/description
           - Request parameters
           - Response structure
        3. Data Models: Define data structures for entities
        4. Business Rules: List validation rules, constraints, and business logic
        5. Relationships: Define relationships between entities
        6. Authentication/Authorization: Security requirements if mentioned

        Document Content:
        {document_content}

        Return the analysis as a JSON object with these keys:
        {{
            "project_name": "extracted project name",
            "description": "project description",
            "entities": [...],
            "endpoints": [...],
            "data_models": {{...}},
            "business_rules": [...],
            "relationships": [...],
            "security_requirements": {{...}}
        }}"""
        
        if additional_context:
            user_prompt += f"\n\nAdditional Context: {json.dumps(additional_context)}"
        
        messages = [{"role": "user", "content": user_prompt}]
        
        response = self.openai_client.create_completion(
            messages=messages,
            temperature=0.3,
            max_tokens=6000,
            system_prompt=system_prompt
        )
        
        if response["success"]:
            return response["data"]
        else:
            raise Exception(f"Failed to extract requirements: {response.get('error', 'Unknown error')}")
    
    def generate_api_specification(self, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Generate detailed API specification from extracted requirements"""
        
        system_prompt = """You are an expert API architect. Transform business requirements into 
        detailed API specifications following RESTful best practices and OpenAPI standards."""
        
        user_prompt = f"""Based on these extracted business requirements, generate a comprehensive API specification:

        Requirements:
        {json.dumps(requirements, indent=2)}

        Generate a detailed API specification including:
        1. Complete endpoint definitions with OpenAPI-style documentation
        2. Request/Response schemas with field types and validations
        3. Error response formats
        4. Status codes for each endpoint
        5. Authentication/Authorization schemes
        6. API versioning strategy

        Return as JSON with structure:
        {{
            "api_name": "...",
            "version": "1.0.0",
            "base_path": "/api/v1",
            "endpoints": [
                {{
                    "path": "...",
                    "method": "...",
                    "summary": "...",
                    "request_body": {{...}},
                    "responses": {{...}},
                    "parameters": [...],
                    "security": [...]
                }}
            ],
            "schemas": {{...}},
            "security_schemes": {{...}}
        }}"""
        
        messages = [{"role": "user", "content": user_prompt}]
        
        response = self.openai_client.create_completion(
            messages=messages,
            temperature=0.3,
            max_tokens=6000,
            system_prompt=system_prompt
        )
        
        if response["success"]:
            return response["data"]
        else:
            raise Exception(f"Failed to generate API specification: {response.get('error', 'Unknown error')}")
    
    def validate_requirements(self, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Validate extracted requirements for completeness and consistency"""
        
        validation_results = {
            "is_valid": True,
            "warnings": [],
            "errors": [],
            "suggestions": []
        }
        
        # Check for required fields
        required_fields = ["entities", "endpoints", "data_models"]
        for field in required_fields:
            if field not in requirements or not requirements[field]:
                validation_results["errors"].append(f"Missing required field: {field}")
                validation_results["is_valid"] = False
        
        # Validate endpoints
        if "endpoints" in requirements:
            for endpoint in requirements["endpoints"]:
                if not endpoint.get("path"):
                    validation_results["errors"].append("Endpoint missing path")
                if not endpoint.get("method"):
                    validation_results["errors"].append("Endpoint missing HTTP method")
        
        # Check for security requirements
        if not requirements.get("security_requirements"):
            validation_results["warnings"].append("No security requirements specified")
        
        # Validate data models
        if "data_models" in requirements:
            for model_name, model_def in requirements["data_models"].items():
                if not model_def.get("properties"):
                    validation_results["warnings"].append(f"Data model '{model_name}' has no properties defined")
        
        # Add suggestions for improvement
        if len(requirements.get("endpoints", [])) < 3:
            validation_results["suggestions"].append("Consider adding more CRUD operations for complete API coverage")
        
        return validation_results
    
    def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Main processing method for Stage 1"""
        
        try:
            # Extract document content
            document_content = ""
            if input_data.get("file_path"):
                document_content = self.process_document(
                    input_data["file_path"],
                    input_data.get("file_type", "txt")
                )
            elif input_data.get("content"):
                document_content = input_data["content"]
            
            # Extract requirements
            requirements = self.extract_requirements(
                document_content,
                input_data.get("context")
            )
            
            # Validate requirements
            validation = self.validate_requirements(requirements)
            
            # Generate API specification
            api_spec = self.generate_api_specification(requirements)
            
            return {
                "success": True,
                "stage": self.stage_name,
                "requirements": requirements,
                "api_specification": api_spec,
                "validation": validation,
                "next_stage_input": {
                    "requirements": requirements,
                    "api_specification": api_spec
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "stage": self.stage_name,
                "error": str(e),
                "requirements": None,
                "api_specification": None
            }