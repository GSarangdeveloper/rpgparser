import openai
from openai import OpenAI
import tiktoken
import json
from typing import List, Dict, Any, Optional
from config import Config

class OpenAIClient:
    def __init__(self):
        self.client = OpenAI(api_key=Config.OPENAI_API_KEY)
        self.model = Config.OPENAI_MODEL
        self.encoding = tiktoken.encoding_for_model("gpt-4")
    
    def count_tokens(self, text: str) -> int:
        """Count tokens in a text string"""
        return len(self.encoding.encode(text))
    
    def create_completion(self, 
                         messages: List[Dict[str, str]], 
                         temperature: float = 0.7,
                         max_tokens: int = 4000,
                         system_prompt: Optional[str] = None) -> Dict[str, Any]:
        """Create a completion using OpenAI GPT-4"""
        try:
            if system_prompt:
                messages = [{"role": "system", "content": system_prompt}] + messages
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            
            try:
                return {
                    "success": True,
                    "data": json.loads(content),
                    "usage": {
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                        "total_tokens": response.usage.total_tokens
                    }
                }
            except json.JSONDecodeError:
                return {
                    "success": True,
                    "data": {"content": content},
                    "usage": {
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                        "total_tokens": response.usage.total_tokens
                    }
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "data": None
            }
    
    def generate_code(self, 
                     prompt: str, 
                     context: Optional[Dict[str, Any]] = None,
                     temperature: float = 0.3) -> str:
        """Generate code using GPT-4 with lower temperature for consistency"""
        system_prompt = """You are an expert Spring Boot developer. Generate clean, production-ready Java code 
        following Spring Boot best practices. Use Gradle as the build system. Include proper annotations, 
        error handling, and follow RESTful API conventions."""
        
        messages = [{"role": "user", "content": prompt}]
        
        if context:
            messages.insert(0, {"role": "user", "content": f"Context: {json.dumps(context)}"})
        
        response = self.create_completion(
            messages=messages,
            temperature=temperature,
            max_tokens=8000,
            system_prompt=system_prompt
        )
        
        if response["success"]:
            return response["data"].get("code", response["data"].get("content", ""))
        else:
            raise Exception(f"Code generation failed: {response['error']}")
    
    def analyze_document(self, 
                        document_content: str, 
                        document_type: str = "business_requirement") -> Dict[str, Any]:
        """Analyze a document and extract relevant information"""
        prompts = {
            "business_requirement": """Analyze this business requirement document and extract:
                1. Business entities and their relationships
                2. API endpoints needed (with HTTP methods)
                3. Request/response structures
                4. Business rules and validation requirements
                5. Data models
                Return as structured JSON with keys: entities, endpoints, schemas, rules, data_models""",
            
            "api_specification": """Analyze this API specification and extract:
                1. All API endpoints with methods and paths
                2. Request/response schemas
                3. Authentication requirements
                4. Error handling patterns
                5. Data validation rules
                Return as structured JSON with keys: endpoints, schemas, authentication, errors, validations""",
            
            "technical_design": """Analyze this technical design and extract:
                1. Architecture patterns to implement
                2. Spring Boot components needed
                3. Database design requirements
                4. Security configurations
                5. Integration points
                Return as structured JSON with keys: architecture, components, database, security, integrations"""
        }
        
        system_prompt = prompts.get(document_type, prompts["business_requirement"])
        
        messages = [{"role": "user", "content": f"Document content:\n{document_content}"}]
        
        response = self.create_completion(
            messages=messages,
            temperature=0.3,
            max_tokens=4000,
            system_prompt=system_prompt
        )
        
        return response["data"] if response["success"] else {}
    
    def estimate_cost(self, prompt_tokens: int, completion_tokens: int) -> Dict[str, float]:
        """Estimate cost based on token usage"""
        gpt4_prompt_price = 0.03 / 1000
        gpt4_completion_price = 0.06 / 1000
        
        prompt_cost = prompt_tokens * gpt4_prompt_price
        completion_cost = completion_tokens * gpt4_completion_price
        total_cost = prompt_cost + completion_cost
        
        return {
            "prompt_cost": round(prompt_cost, 4),
            "completion_cost": round(completion_cost, 4),
            "total_cost": round(total_cost, 4)
        }