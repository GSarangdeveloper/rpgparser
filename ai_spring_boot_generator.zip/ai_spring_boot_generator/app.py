from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, flash, session
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import os
import json
from datetime import datetime
from pathlib import Path

# Import configuration
from config import Config

# Import database models
from models.database import db, Project, Stage, Template, ProjectTemplate, User

# Import AI agents
from agents.business_agent import BusinessRequirementAgent
from agents.design_agent import APIDesignAgent
from agents.code_agent import CodeGenerationAgent

# Create Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
db.init_app(app)
CORS(app)

# Create upload directories
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['GENERATED_PROJECTS_FOLDER'], exist_ok=True)
os.makedirs(app.config['TEMPLATES_LIBRARY_FOLDER'], exist_ok=True)

# Initialize AI agents
business_agent = BusinessRequirementAgent()
design_agent = APIDesignAgent()
code_agent = CodeGenerationAgent()

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
def index():
    """Main dashboard"""
    projects = Project.query.order_by(Project.created_at.desc()).all()
    return render_template('index.html', projects=projects)

@app.route('/project/<int:project_id>')
def project_pipeline(project_id):
    """Project pipeline view"""
    project = Project.query.get_or_404(project_id)
    return render_template('project.html', project=project, project_id=project_id)

@app.route('/api/projects', methods=['GET'])
def get_projects():
    """Get all projects"""
    projects = Project.query.order_by(Project.created_at.desc()).all()
    return jsonify([p.to_dict() for p in projects])

@app.route('/api/projects', methods=['POST'])
def create_project():
    """Create new project"""
    try:
        data = request.get_json()
        
        # Create new project
        project = Project(
            name=data.get('name'),
            description=data.get('description'),
            generation_mode=data.get('generation_mode', 'autonomous'),
            status='initialized'
        )
        db.session.add(project)
        db.session.commit()
        
        # Initialize stages
        stage_names = ['Business Requirement Processing', 'API Design', 'Code Generation']
        for i, stage_name in enumerate(stage_names, 1):
            stage = Stage(
                project_id=project.id,
                stage_number=i,
                stage_name=stage_name,
                status='pending'
            )
            db.session.add(stage)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'project': project.to_dict(),
            'message': 'Project created successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/projects/<int:project_id>', methods=['GET'])
def get_project(project_id):
    """Get project details"""
    project = Project.query.get_or_404(project_id)
    return jsonify(project.to_dict())

@app.route('/api/projects/<int:project_id>/upload', methods=['POST'])
def upload_document(project_id):
    """Upload business requirement document"""
    try:
        project = Project.query.get_or_404(project_id)
        
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'}), 400
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{project_id}_{timestamp}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            # Get file type
            file_type = filename.rsplit('.', 1)[1].lower()
            
            return jsonify({
                'success': True,
                'file_path': file_path,
                'file_type': file_type,
                'filename': filename
            })
        
        return jsonify({'success': False, 'error': 'Invalid file type'}), 400
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/projects/<int:project_id>/process/<int:stage_number>', methods=['POST'])
def process_stage(project_id, stage_number):
    """Process a specific stage"""
    try:
        project = Project.query.get_or_404(project_id)
        stage = Stage.query.filter_by(project_id=project_id, stage_number=stage_number).first_or_404()
        
        data = request.get_json()
        
        # Update stage status
        stage.status = 'processing'
        stage.input_data = json.dumps(data)
        db.session.commit()
        
        # Process based on stage
        if stage_number == 1:
            # Stage 1: Business Requirement Processing
            result = business_agent.process(data)
            
        elif stage_number == 2:
            # Stage 2: API Design
            # Get output from Stage 1
            prev_stage = Stage.query.filter_by(project_id=project_id, stage_number=1).first()
            if prev_stage and prev_stage.final_output:
                data['requirements'] = json.loads(prev_stage.final_output)
            
            # Get templates if template-enhanced mode
            if project.generation_mode == 'template_enhanced':
                templates = Template.query.filter_by(is_active=True).all()
                data['templates'] = [t.to_dict() for t in templates]
            
            result = design_agent.process(data)
            
        elif stage_number == 3:
            # Stage 3: Code Generation
            # Get outputs from previous stages
            stage1 = Stage.query.filter_by(project_id=project_id, stage_number=1).first()
            stage2 = Stage.query.filter_by(project_id=project_id, stage_number=2).first()
            
            if stage1 and stage1.final_output:
                stage1_output = json.loads(stage1.final_output)
                data['api_specification'] = stage1_output.get('api_specification')
            
            if stage2 and stage2.final_output:
                stage2_output = json.loads(stage2.final_output)
                data['architecture'] = stage2_output.get('architecture')
                data['database_design'] = stage2_output.get('database_design')
                data['gradle_configuration'] = stage2_output.get('gradle_configuration')
                data['selected_templates'] = stage2_output.get('selected_templates')
            
            result = code_agent.process(data)
        
        else:
            return jsonify({'success': False, 'error': 'Invalid stage number'}), 400
        
        # Update stage with results
        if result['success']:
            stage.ai_output = json.dumps(result)
            stage.status = 'review_pending'
            stage.final_output = json.dumps(result.get('next_stage_input', result))
        else:
            stage.status = 'failed'
            stage.ai_output = json.dumps(result)
        
        db.session.commit()
        
        return jsonify(result)
        
    except Exception as e:
        if stage:
            stage.status = 'failed'
            db.session.commit()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/projects/<int:project_id>/review/<int:stage_number>', methods=['POST'])
def review_stage(project_id, stage_number):
    """Submit human review for a stage"""
    try:
        stage = Stage.query.filter_by(project_id=project_id, stage_number=stage_number).first_or_404()
        
        data = request.get_json()
        
        stage.human_review = json.dumps(data.get('review'))
        stage.reviewed_by = data.get('reviewer', 'Anonymous')
        stage.reviewed_at = datetime.utcnow()
        stage.approved = data.get('approved', False)
        
        if stage.approved:
            stage.status = 'completed'
            stage.final_output = json.dumps(data.get('final_output', json.loads(stage.ai_output)))
        else:
            stage.status = 'revision_needed'
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'stage': stage.to_dict(),
            'message': 'Review submitted successfully'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/projects/<int:project_id>/download', methods=['GET'])
def download_project(project_id):
    """Download generated Spring Boot project"""
    try:
        # Get the last stage output
        stage3 = Stage.query.filter_by(project_id=project_id, stage_number=3).first()
        
        if not stage3 or not stage3.final_output:
            return jsonify({'success': False, 'error': 'Project not yet generated'}), 400
        
        output = json.loads(stage3.final_output)
        zip_path = output.get('zip_path')
        
        if not zip_path or not os.path.exists(zip_path):
            return jsonify({'success': False, 'error': 'Generated project file not found'}), 404
        
        return send_file(zip_path, as_attachment=True, download_name=f"project_{project_id}.zip")
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/templates', methods=['GET'])
def get_templates():
    """Get all templates"""
    templates = Template.query.filter_by(is_active=True).all()
    return jsonify([t.to_dict() for t in templates])

@app.route('/api/templates', methods=['POST'])
def create_template():
    """Create or upload a new template"""
    try:
        if 'file' in request.files:
            # File upload
            file = request.files['file']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"template_{timestamp}_{filename}"
                file_path = os.path.join(app.config['TEMPLATES_LIBRARY_FOLDER'], filename)
                file.save(file_path)
                
                # Read file content
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                template = Template(
                    name=request.form.get('name', filename),
                    category=request.form.get('category', 'general'),
                    description=request.form.get('description', ''),
                    content=content,
                    file_path=file_path,
                    version=request.form.get('version', '1.0.0')
                )
        else:
            # JSON data
            data = request.get_json()
            template = Template(
                name=data.get('name'),
                category=data.get('category'),
                description=data.get('description'),
                content=data.get('content'),
                version=data.get('version', '1.0.0')
            )
        
        db.session.add(template)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'template': template.to_dict(),
            'message': 'Template created successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/templates/<int:template_id>', methods=['DELETE'])
def delete_template(template_id):
    """Delete a template"""
    try:
        template = Template.query.get_or_404(template_id)
        template.is_active = False
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Template deleted successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return jsonify({'error': 'Internal server error'}), 500

# Create database tables
with app.app_context():
    db.create_all()
    print("Database tables created successfully!")

if __name__ == '__main__':
    app.run(debug=True, port=5000)