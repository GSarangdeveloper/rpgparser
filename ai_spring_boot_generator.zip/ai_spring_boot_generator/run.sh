#!/bin/bash

echo "🚀 Starting AI Spring Boot API Generator..."

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install/upgrade dependencies
echo "📚 Installing dependencies..."
pip install -r requirements.txt --quiet

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "⚠️  .env file not found. Creating from .env.example..."
    cp .env.example .env
    echo "❗ Please edit .env file and add your OpenAI API key"
    exit 1
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p uploads generated_projects templates_library

# Run the application
echo "✅ Starting Flask application..."
echo "🌐 Access the application at http://localhost:5000"
python app.py