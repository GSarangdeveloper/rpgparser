# Test Repositories

Here are some public GitHub repositories you can use to test the extension:

## JavaScript/React Projects
- https://github.com/facebook/react
- https://github.com/vercel/next.js
- https://github.com/mui/material-ui

## Python Projects
- https://github.com/django/django
- https://github.com/pallets/flask
- https://github.com/tiangolo/fastapi

## TypeScript Projects
- https://github.com/microsoft/TypeScript
- https://github.com/angular/angular
- https://github.com/nestjs/nest

## Mixed Language Projects
- https://github.com/microsoft/vscode
- https://github.com/electron/electron
- https://github.com/nodejs/node

## Small/Medium Projects (Good for Testing)
- https://github.com/bradtraversy/50projects50days
- https://github.com/trekhleb/javascript-algorithms
- https://github.com/goldbergyoni/nodebestpractices

## Testing the Extension

1. Open VS Code
2. Press F5 to launch Extension Development Host
3. Click on "Doc Generator" in the sidebar
4. Enter one of the above repository URLs
5. Select documentation types (README, API, Guide)
6. Choose a style (Technical, Beginner, Enterprise)
7. Click "Generate Prompts"
8. Copy generated prompts and paste into Cursor AI