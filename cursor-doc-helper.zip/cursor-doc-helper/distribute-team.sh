#!/bin/bash

# Cursor Documentation Generator - Team Distribution Script
# This script builds and distributes the extension to your team

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
EXTENSION_NAME="cursor-doc-helper"
VERSION="0.0.1"
VSIX_FILE="${EXTENSION_NAME}-${VERSION}.vsix"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Cursor Doc Helper - Team Distribution${NC}"
echo -e "${GREEN}========================================${NC}"

# Function to check prerequisites
check_prerequisites() {
    echo -e "\n${YELLOW}Checking prerequisites...${NC}"
    
    # Check Node.js
    if ! command -v node &> /dev/null; then
        echo -e "${RED}❌ Node.js is not installed${NC}"
        echo "Please install Node.js from https://nodejs.org/"
        exit 1
    fi
    echo -e "${GREEN}✅ Node.js found: $(node --version)${NC}"
    
    # Check npm
    if ! command -v npm &> /dev/null; then
        echo -e "${RED}❌ npm is not installed${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ npm found: $(npm --version)${NC}"
    
    # Check/Install vsce
    if ! command -v vsce &> /dev/null; then
        echo -e "${YELLOW}Installing vsce...${NC}"
        npm install -g vsce
    fi
    echo -e "${GREEN}✅ vsce is installed${NC}"
}

# Function to build the extension
build_extension() {
    echo -e "\n${YELLOW}Building extension...${NC}"
    
    # Clean previous builds
    rm -rf out/
    rm -f *.vsix
    
    # Install dependencies
    echo "Installing dependencies..."
    npm install
    
    # Compile TypeScript
    echo "Compiling TypeScript..."
    npm run compile
    
    # Copy required files
    echo "Copying templates and webview files..."
    mkdir -p out/templates out/webview
    cp src/templates/*.hbs out/templates/ 2>/dev/null || true
    cp src/webview/*.js out/webview/ 2>/dev/null || true
    cp src/webview/*.css out/webview/ 2>/dev/null || true
    
    # Package extension
    echo "Creating VSIX package..."
    vsce package --no-yarn
    
    echo -e "${GREEN}✅ Extension built successfully: ${VSIX_FILE}${NC}"
}

# Function to create distribution package
create_distribution() {
    echo -e "\n${YELLOW}Creating distribution package...${NC}"
    
    # Create distribution directory
    DIST_DIR="dist-${VERSION}"
    rm -rf "${DIST_DIR}"
    mkdir -p "${DIST_DIR}"
    
    # Copy files
    cp "${VSIX_FILE}" "${DIST_DIR}/"
    cp INSTALL_GUIDE.md "${DIST_DIR}/"
    cp README.md "${DIST_DIR}/"
    
    # Create installation script for Windows
    cat > "${DIST_DIR}/install-windows.bat" << 'EOF'
@echo off
echo Installing Cursor Documentation Generator...
code --install-extension cursor-doc-helper-0.0.1.vsix
if %ERRORLEVEL% EQU 0 (
    echo Installation successful!
    echo Please reload VS Code to use the extension.
) else (
    echo Installation failed. Please try manual installation.
)
pause
EOF
    
    # Create installation script for Mac/Linux
    cat > "${DIST_DIR}/install-unix.sh" << 'EOF'
#!/bin/bash
echo "Installing Cursor Documentation Generator..."
code --install-extension cursor-doc-helper-0.0.1.vsix
if [ $? -eq 0 ]; then
    echo "✅ Installation successful!"
    echo "Please reload VS Code to use the extension."
else
    echo "❌ Installation failed. Please try manual installation."
fi
EOF
    
    chmod +x "${DIST_DIR}/install-unix.sh"
    
    # Create quick start guide
    cat > "${DIST_DIR}/QUICK_START.md" << 'EOF'
# Quick Start Guide

## Installation
- **Windows**: Double-click `install-windows.bat`
- **Mac/Linux**: Run `./install-unix.sh`
- **Manual**: Open VS Code → Extensions → "..." → Install from VSIX

## First Use
1. Open VS Code
2. Click "Doc Generator" in sidebar
3. Enter GitHub repo URL
4. Select documentation types
5. Click "Generate Prompts" or "Execute Workflow"

## Need Help?
See INSTALL_GUIDE.md for detailed instructions.
EOF
    
    # Create ZIP archive
    if command -v zip &> /dev/null; then
        zip -r "${DIST_DIR}.zip" "${DIST_DIR}"
        echo -e "${GREEN}✅ Distribution package created: ${DIST_DIR}.zip${NC}"
    fi
    
    # Create TAR archive for Unix systems
    tar -czf "${DIST_DIR}.tar.gz" "${DIST_DIR}"
    echo -e "${GREEN}✅ Distribution package created: ${DIST_DIR}.tar.gz${NC}"
}

# Function to upload to GitHub releases (optional)
upload_to_github() {
    echo -e "\n${YELLOW}Upload to GitHub?${NC}"
    read -p "Do you want to create a GitHub release? (y/n): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if ! command -v gh &> /dev/null; then
            echo -e "${YELLOW}GitHub CLI not installed. Skipping upload.${NC}"
            echo "Install from: https://cli.github.com/"
            return
        fi
        
        echo "Creating GitHub release..."
        gh release create "v${VERSION}" \
            "${VSIX_FILE}" \
            "${DIST_DIR}.zip" \
            "${DIST_DIR}.tar.gz" \
            --title "Cursor Doc Helper v${VERSION}" \
            --notes "Automated documentation generator for Cursor AI" \
            --draft
        
        echo -e "${GREEN}✅ Draft release created on GitHub${NC}"
    fi
}

# Function to display distribution instructions
show_distribution_instructions() {
    echo -e "\n${GREEN}========================================${NC}"
    echo -e "${GREEN}Distribution Complete!${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo
    echo "📦 Files created:"
    echo "  • ${VSIX_FILE} - VS Code extension package"
    echo "  • ${DIST_DIR}/ - Distribution folder"
    echo "  • ${DIST_DIR}.zip - Windows distribution"
    echo "  • ${DIST_DIR}.tar.gz - Mac/Linux distribution"
    echo
    echo "📤 Distribution methods:"
    echo "  1. Email: Send ${DIST_DIR}.zip to team"
    echo "  2. Slack: Upload ${VSIX_FILE} to team channel"
    echo "  3. Network: Copy to \\\\shared\\tools\\"
    echo "  4. GitHub: Share release link with team"
    echo
    echo "💡 Team members can install by:"
    echo "  • Running install script in distribution package"
    echo "  • VS Code: Extensions → ... → Install from VSIX"
    echo "  • Command: code --install-extension ${VSIX_FILE}"
}

# Main execution
main() {
    check_prerequisites
    build_extension
    create_distribution
    upload_to_github
    show_distribution_instructions
}

# Run main function
main