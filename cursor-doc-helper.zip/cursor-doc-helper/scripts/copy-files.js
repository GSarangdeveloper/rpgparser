const fs = require('fs');
const path = require('path');

// Ensure output directories exist
const dirs = ['out/templates', 'out/webview'];
dirs.forEach(dir => {
    const fullPath = path.join(__dirname, '..', dir);
    if (!fs.existsSync(fullPath)) {
        fs.mkdirSync(fullPath, { recursive: true });
        console.log(`Created directory: ${dir}`);
    }
});

// Copy template files
const templateSrc = path.join(__dirname, '..', 'src', 'templates');
const templateDest = path.join(__dirname, '..', 'out', 'templates');

if (fs.existsSync(templateSrc)) {
    fs.readdirSync(templateSrc).forEach(file => {
        if (file.endsWith('.hbs')) {
            fs.copyFileSync(
                path.join(templateSrc, file),
                path.join(templateDest, file)
            );
            console.log(`Copied template: ${file}`);
        }
    });
}

// Copy webview files
const webviewSrc = path.join(__dirname, '..', 'src', 'webview');
const webviewDest = path.join(__dirname, '..', 'out', 'webview');

if (fs.existsSync(webviewSrc)) {
    fs.readdirSync(webviewSrc).forEach(file => {
        if (file.endsWith('.js') || file.endsWith('.css')) {
            fs.copyFileSync(
                path.join(webviewSrc, file),
                path.join(webviewDest, file)
            );
            console.log(`Copied webview file: ${file}`);
        }
    });
}

console.log('✅ All files copied successfully!');