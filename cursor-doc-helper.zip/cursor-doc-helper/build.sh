#!/bin/bash

echo "Building Cursor Documentation Generator Extension..."

# Install dependencies
echo "Installing dependencies..."
npm install

# Compile TypeScript
echo "Compiling TypeScript..."
npm run compile

# Create templates directory in out folder
echo "Copying templates..."
mkdir -p out/templates
cp src/templates/*.hbs out/templates/

# Copy webview files
echo "Copying webview files..."
mkdir -p out/webview
cp src/webview/*.js out/webview/
cp src/webview/*.css out/webview/

echo "Build complete! You can now run the extension with F5 in VS Code."