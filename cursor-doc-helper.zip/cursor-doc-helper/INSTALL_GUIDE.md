# 📚 Cursor Documentation Generator - Installation & Distribution Guide

## Table of Contents
- [Prerequisites](#prerequisites)
- [Installation Methods](#installation-methods)
  - [Method 1: Local Development](#method-1-local-development)
  - [Method 2: VSIX Package (Team Distribution)](#method-2-vsix-package-team-distribution)
  - [Method 3: Private Extension Registry](#method-3-private-extension-registry)
  - [Method 4: GitHub Release](#method-4-github-release)
- [Configuration](#configuration)
- [Usage Guide](#usage-guide)
- [Team Distribution](#team-distribution)
- [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Software
- **Node.js** (v16 or higher) - [Download](https://nodejs.org/)
- **VS Code** (v1.74.0 or higher) - [Download](https://code.visualstudio.com/)
- **Git** - [Download](https://git-scm.com/)
- **npm** or **yarn** package manager

### Optional (for automated mode)
- **GitHub Personal Access Token** - [Create Token](https://github.com/settings/tokens)
- **Cursor AI** installed (for full automation)

---

## Installation Methods

### Method 1: Local Development

Perfect for developers who want to modify or test the extension.

```bash
# 1. Clone the repository
git clone https://github.com/your-org/cursor-doc-helper.git
cd cursor-doc-helper

# 2. Install dependencies
npm install

# 3. Compile the TypeScript code
npm run compile

# 4. Copy template files to output directory
cp -r src/templates out/
cp -r src/webview out/

# 5. Open in VS Code
code .

# 6. Run the extension (press F5 in VS Code)
# This opens a new VS Code window with the extension loaded
```

### Method 2: VSIX Package (Team Distribution)

Best for distributing to your team without publishing to marketplace.

#### Building the VSIX Package

```bash
# 1. Install vsce (Visual Studio Code Extension manager)
npm install -g vsce

# 2. Navigate to project directory
cd cursor-doc-helper

# 3. Install dependencies
npm install

# 4. Compile the project
npm run compile

# 5. Copy required files to out directory
mkdir -p out/templates out/webview
cp src/templates/*.hbs out/templates/
cp src/webview/*.js out/webview/
cp src/webview/*.css out/webview/

# 6. Package the extension
vsce package

# This creates: cursor-doc-helper-0.0.1.vsix
```

#### Installing the VSIX Package

**Option A: Via VS Code UI**
1. Open VS Code
2. Go to Extensions (Ctrl+Shift+X)
3. Click the "..." menu at the top of Extensions sidebar
4. Select "Install from VSIX..."
5. Browse to the `cursor-doc-helper-0.0.1.vsix` file
6. Click Install

**Option B: Via Command Line**
```bash
code --install-extension cursor-doc-helper-0.0.1.vsix
```

**Option C: Via Command Palette**
1. Open Command Palette (Ctrl+Shift+P)
2. Type "Extensions: Install from VSIX"
3. Select the VSIX file

### Method 3: Private Extension Registry

For enterprise teams with private registries.

```bash
# 1. Publish to private npm registry
npm publish --registry https://your-private-registry.com

# 2. Configure VS Code to use private registry
# In .vscode/settings.json:
{
  "npm.packageManager": "npm",
  "npm.registry": "https://your-private-registry.com"
}
```

### Method 4: GitHub Release

Easiest for team distribution via GitHub.

```bash
# 1. Build the VSIX package (see Method 2)
vsce package

# 2. Create GitHub release
gh release create v0.0.1 cursor-doc-helper-0.0.1.vsix \
  --title "Cursor Doc Helper v0.0.1" \
  --notes "Initial release of automated documentation generator"

# Team members can download from:
# https://github.com/your-org/cursor-doc-helper/releases
```

---

## Configuration

### Initial Setup

1. **Open the extension**
   - Click on "Doc Generator" icon in VS Code sidebar
   - Or use Command Palette: `Cursor Doc: Open Panel`

2. **Configure GitHub Token (for automated mode)**
   ```json
   // VS Code Settings (Ctrl+,)
   {
     "cursorDocHelper.githubToken": "ghp_your_token_here",
     "cursorDocHelper.defaultBranch": "main",
     "cursorDocHelper.autoCommit": true,
     "cursorDocHelper.createPR": true
   }
   ```

3. **Environment Variables (alternative)**
   ```bash
   export GITHUB_TOKEN="ghp_your_token_here"
   ```

---

## Usage Guide

### Quick Start

#### Manual Mode (Generate Prompts Only)
1. Open Doc Generator panel
2. Enter GitHub repository URL
3. Select documentation types (README, API, Guide)
4. Choose style (Technical, Beginner, Enterprise)
5. Click "Generate Prompts"
6. Copy prompts to Cursor AI
7. Save generated documentation

#### Automated Mode (Full Workflow)
1. Switch to "Automated Mode"
2. Enter GitHub repository URL
3. Provide GitHub token
4. Select documentation types
5. Click "Execute Workflow"
6. Watch real-time progress
7. Review created Pull Request

### Step-by-Step Usage

```bash
# 1. Ensure extension is installed
code --list-extensions | grep cursor-doc-helper

# 2. Open your project
cd your-project
code .

# 3. Open Doc Generator
# - Click sidebar icon OR
# - Cmd/Ctrl+Shift+P → "Cursor Doc: Open Panel"

# 4. For automated workflow:
# - Toggle "Automated Mode"
# - Enter: https://github.com/your-org/your-repo
# - Paste GitHub token
# - Select: ✓ README ✓ API Docs ✓ User Guide
# - Click "Execute Workflow"

# 5. Monitor progress in the panel
# - Repository Analysis ✓
# - Prompt Generation ✓
# - Documentation Generation ✓
# - GitHub Upload ✓
# - Pull Request Created ✓

# 6. Review PR at provided URL
```

---

## Team Distribution

### Option 1: Shared Drive / Network Location

```bash
# 1. Build VSIX
npm run compile && vsce package

# 2. Copy to shared location
cp cursor-doc-helper-0.0.1.vsix //shared/tools/vscode-extensions/

# 3. Team installation script
echo "Installing Cursor Doc Helper..."
code --install-extension //shared/tools/vscode-extensions/cursor-doc-helper-0.0.1.vsix
```

### Option 2: Internal Package Manager

```json
// package.json for team
{
  "scripts": {
    "install-extensions": "code --install-extension ./tools/cursor-doc-helper-0.0.1.vsix"
  }
}
```

### Option 3: Docker Development Environment

```dockerfile
# Dockerfile
FROM mcr.microsoft.com/vscode/devcontainers/typescript-node:16

# Copy extension
COPY cursor-doc-helper-0.0.1.vsix /tmp/

# Install extension
RUN code-server --install-extension /tmp/cursor-doc-helper-0.0.1.vsix
```

### Option 4: Automated Deployment Script

Create `deploy-extension.sh`:

```bash
#!/bin/bash

# Configuration
EXTENSION_VERSION="0.0.1"
EXTENSION_FILE="cursor-doc-helper-${EXTENSION_VERSION}.vsix"
GITHUB_REPO="your-org/cursor-doc-helper"

# Download latest release
echo "📦 Downloading extension..."
curl -L "https://github.com/${GITHUB_REPO}/releases/download/v${EXTENSION_VERSION}/${EXTENSION_FILE}" -o "${EXTENSION_FILE}"

# Install extension
echo "🔧 Installing extension..."
code --install-extension "${EXTENSION_FILE}"

# Verify installation
if code --list-extensions | grep -q "cursor-doc-helper"; then
    echo "✅ Extension installed successfully!"
else
    echo "❌ Installation failed"
    exit 1
fi

# Clean up
rm "${EXTENSION_FILE}"
```

---

## Troubleshooting

### Common Issues & Solutions

#### Extension Not Showing in Sidebar
```bash
# Reload VS Code window
Ctrl+Shift+P → "Developer: Reload Window"

# Check if extension is enabled
code --list-extensions --show-versions | grep cursor-doc-helper
```

#### Build Errors
```bash
# Clear and rebuild
rm -rf out/ node_modules/
npm install
npm run compile

# Copy required files
cp -r src/templates out/
cp -r src/webview out/
```

#### GitHub Token Issues
```bash
# Test token validity
curl -H "Authorization: token YOUR_TOKEN" https://api.github.com/user

# Required scopes: repo, workflow (optional)
```

#### Cursor AI Not Responding
- Ensure Cursor is installed and running
- Check clipboard permissions in VS Code
- Try manual mode first, then automated

#### Template Files Not Found
```bash
# Ensure templates are copied to out directory
mkdir -p out/templates
cp src/templates/*.hbs out/templates/
```

### Debug Mode

```json
// .vscode/launch.json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Run Extension",
      "type": "extensionHost",
      "request": "launch",
      "args": ["--extensionDevelopmentPath=${workspaceFolder}"],
      "outFiles": ["${workspaceFolder}/out/**/*.js"]
    }
  ]
}
```

### Logs & Diagnostics

```bash
# View extension logs
Ctrl+Shift+P → "Developer: Show Logs" → "Extension Host"

# Enable verbose logging
code --verbose --log trace

# Check extension host status
Ctrl+Shift+P → "Developer: Show Running Extensions"
```

---

## Quick Commands Reference

```bash
# Development
npm install              # Install dependencies
npm run compile          # Compile TypeScript
npm run watch           # Watch mode
./build.sh              # Full build script

# Testing
npm test                # Run tests
code --extensionDevelopmentPath=.  # Test in new window

# Distribution
vsce package            # Create VSIX
vsce publish           # Publish to marketplace

# Installation
code --install-extension cursor-doc-helper-0.0.1.vsix
code --uninstall-extension cursor-doc-helper

# Usage
Ctrl+Shift+P → "Cursor Doc"  # Show all commands
```

---

## Support & Resources

- **Documentation**: [README.md](./README.md)
- **Workflow Guide**: [workflow.md](./workflow.md)
- **Test Repositories**: [examples/test-repos.md](./examples/test-repos.md)
- **Issues**: Create issue in your team's repository
- **Updates**: Check releases page for new versions

---

## License

MIT - See LICENSE file for details

---

## Next Steps

1. **Install the extension** using one of the methods above
2. **Test with a sample repository** from examples/test-repos.md
3. **Share with your team** using VSIX or GitHub releases
4. **Customize templates** in src/templates/ for your needs
5. **Report issues** to improve the extension

Happy documenting! 🚀