# Cursor Documentation Generator

A VS Code extension that analyzes GitHub repositories and generates ready-to-use prompts for Cursor AI documentation generation.

## Features

- 🔍 **Repository Analysis**: Automatically analyzes GitHub repository structure, language, and frameworks
- 📝 **Multiple Documentation Types**: Generate prompts for README, API documentation, and user guides
- 🎨 **Style Options**: Choose between technical, beginner-friendly, or enterprise documentation styles
- 📋 **One-Click Copy**: Easy copy-to-clipboard functionality for generated prompts
- 🚀 **Fast & Simple**: No API keys required - works with public GitHub repositories

## Installation

1. Install from VS Code Marketplace (coming soon)
2. Or install from VSIX file:
   ```bash
   code --install-extension cursor-doc-helper-0.0.1.vsix
   ```

## Usage

1. **Open the Extension**
   - Click on the "Doc Generator" icon in the VS Code sidebar
   - Or use Command Palette: `Cursor Doc: Generate Documentation Prompts`

2. **Enter Repository Details**
   - Paste a GitHub repository URL (e.g., `https://github.com/username/repo`)
   - Select documentation types you want to generate:
     - README.md
     - API Documentation
     - User Guide
   - Choose documentation style:
     - Technical (for experienced developers)
     - Beginner-friendly (with extra explanations)
     - Enterprise (comprehensive and formal)

3. **Generate Prompts**
   - Click "Generate Prompts" button
   - Extension analyzes the repository structure
   - Creates customized prompts based on detected language, framework, and project structure

4. **Use with Cursor AI**
   - Click "Copy to Clipboard" on any generated prompt
   - Open Cursor AI in your project
   - Paste the prompt into Cursor's chat interface
   - Review and refine the generated documentation

## Example Output

The extension generates detailed prompts like:

```
I need you to create a comprehensive README.md for a JavaScript React project.

Repository Analysis:
- Project Name: my-awesome-app
- Language: JavaScript
- Framework: React
- Has API endpoints
- Has test suite
- Package Manager: npm
- Entry Point: src/index.js

[... detailed instructions for documentation generation ...]
```

## Supported Languages & Frameworks

### Languages
- JavaScript/TypeScript
- Python
- Java
- C#
- Go
- Ruby
- Rust
- PHP
- And more...

### Frameworks
- React, Vue, Angular, Next.js
- Express.js, FastAPI, Django, Flask
- Spring Boot, ASP.NET Core
- And more...

## Development

### Prerequisites
```bash
npm install
```

### Compile
```bash
npm run compile
```

### Watch Mode
```bash
npm run watch
```

### Run Extension
1. Open project in VS Code
2. Press `F5` to open a new Extension Development Host window
3. Extension will be available in the sidebar

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT

## Privacy

This extension:
- Only accesses public GitHub repositories
- Does not store any repository data
- Does not require authentication
- All processing happens locally in VS Code