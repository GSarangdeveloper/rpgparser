# Documentation Generation Workflow

## Overview
This workflow defines the automated process for generating and uploading documentation using Cursor AI.

## Workflow Steps

### Step 1: Repository Analysis
- **Input**: GitHub repository URL
- **Process**: Analyze repository structure, detect language, framework, dependencies
- **Output**: Repository metadata and analysis report

### Step 2: Documentation Planning
- **Input**: Repository analysis + user preferences
- **Process**: Determine required documentation types based on project structure
- **Output**: Documentation plan with sections to generate

### Step 3: Prompt Generation
- **Input**: Documentation plan + templates
- **Process**: Generate context-aware prompts for each documentation section
- **Prompts**:
  ```
  {{PROJECT_CONTEXT}}
  Generate a comprehensive {{DOC_TYPE}} for this {{LANGUAGE}} {{FRAMEWORK}} project.
  Include: {{SECTIONS}}
  Style: {{STYLE}}
  ```

### Step 4: Cursor AI Integration
- **Input**: Generated prompts
- **Process**: Send prompts to Cursor AI for documentation generation
- **Output**: Generated documentation content

### Step 5: Documentation Assembly
- **Input**: Generated sections from Cursor AI
- **Process**: Combine sections into complete documentation files
- **Output**: Complete README.md, API.md, GUIDE.md files

### Step 6: Git Integration
- **Input**: Generated documentation files
- **Process**: 
  1. Create new branch: `docs/auto-generated-{{timestamp}}`
  2. Commit documentation files
  3. Push to repository
  4. Create pull request
- **Output**: PR URL for review

## Documentation Templates

### README.md Template
```markdown
# {{PROJECT_NAME}}

## Description
{{DESCRIPTION}}

## Installation
{{INSTALLATION_STEPS}}

## Usage
{{USAGE_EXAMPLES}}

## API Reference
{{API_SUMMARY}}

## Contributing
{{CONTRIBUTING_GUIDE}}

## License
{{LICENSE}}
```

### API.md Template
```markdown
# API Documentation

## Endpoints
{{ENDPOINT_LIST}}

## Authentication
{{AUTH_DETAILS}}

## Examples
{{API_EXAMPLES}}
```

### GUIDE.md Template
```markdown
# User Guide

## Getting Started
{{GETTING_STARTED}}

## Tutorials
{{TUTORIALS}}

## Best Practices
{{BEST_PRACTICES}}
```

## Automation Configuration

```yaml
workflow:
  name: "Cursor Documentation Generator"
  version: "1.0.0"
  
  triggers:
    - manual: true
    - on_push: false
    - scheduled: false
  
  steps:
    - analyze_repository:
        timeout: 30s
        retry: 3
    
    - generate_prompts:
        templates: ["readme", "api", "guide"]
        style: "technical"
    
    - cursor_ai_generation:
        model: "claude-3"
        max_tokens: 8000
        temperature: 0.7
    
    - git_upload:
        branch_prefix: "docs/auto-"
        commit_message: "📚 Auto-generated documentation"
        create_pr: true
        pr_title: "Documentation Update"
        pr_body: "This PR contains auto-generated documentation."

  outputs:
    - documentation_files: ["README.md", "API.md", "GUIDE.md"]
    - pr_url: "{{GITHUB_PR_URL}}"
```

## Error Handling

### Retry Logic
- Repository analysis: 3 retries with exponential backoff
- Cursor AI calls: 2 retries with 5s delay
- Git operations: 1 retry

### Fallback Strategies
- If Cursor AI fails: Use simplified templates
- If Git push fails: Save locally and notify user
- If PR creation fails: Commit directly to branch

## User Inputs

### Required Fields
- `repository_url`: GitHub repository URL
- `documentation_types`: Array of ["readme", "api", "guide"]
- `style`: One of ["technical", "beginner", "enterprise"]

### Optional Fields
- `target_branch`: Branch to create PR against (default: main)
- `custom_sections`: Additional sections to include
- `exclude_sections`: Sections to skip
- `language_override`: Override detected language
- `framework_override`: Override detected framework