import * as vscode from 'vscode';
import { GitHubService } from '../services/GitHubService';
import { CodeAnalyzer } from '../services/CodeAnalyzer';
import { PromptBuilder } from '../services/PromptBuilder';
import { WorkflowProcessor, WorkflowConfig } from '../services/WorkflowProcessor';

export class DocGeneratorPanel implements vscode.WebviewViewProvider {
    public static readonly viewType = 'docGeneratorView';
    private _view?: vscode.WebviewView;
    private githubService: GitHubService;
    private codeAnalyzer: CodeAnalyzer;
    private promptBuilder: PromptBuilder;
    private workflowProcessor: WorkflowProcessor;

    constructor(private readonly _extensionUri: vscode.Uri) {
        this.githubService = new GitHubService();
        this.codeAnalyzer = new CodeAnalyzer();
        this.promptBuilder = new PromptBuilder();
        this.workflowProcessor = new WorkflowProcessor();
    }

    public resolveWebviewView(
        webviewView: vscode.WebviewView,
        context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken,
    ) {
        this._view = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this._extensionUri]
        };

        webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);

        webviewView.webview.onDidReceiveMessage(async data => {
            switch (data.type) {
                case 'generatePrompts': {
                    await this.handleGeneratePrompts(data.payload);
                    break;
                }
                case 'executeWorkflow': {
                    await this.handleExecuteWorkflow(data.payload);
                    break;
                }
                case 'copyToClipboard': {
                    await vscode.env.clipboard.writeText(data.text);
                    vscode.window.showInformationMessage('Prompt copied to clipboard!');
                    break;
                }
                case 'saveToken': {
                    await this.saveGitHubToken(data.token);
                    break;
                }
            }
        });
    }

    public refresh() {
        if (this._view) {
            this._view.webview.postMessage({ type: 'refresh' });
        }
    }

    public generatePrompts() {
        if (this._view) {
            this._view.webview.postMessage({ type: 'startGeneration' });
        }
    }

    private async handleExecuteWorkflow(payload: any) {
        const config: WorkflowConfig = {
            repository_url: payload.repoUrl,
            documentation_types: payload.docTypes,
            style: payload.style,
            github_token: payload.githubToken,
            auto_commit: payload.autoCommit,
            create_pr: payload.createPR,
            target_branch: payload.targetBranch || 'main'
        };

        const result = await this.workflowProcessor.executeWorkflow(
            config,
            (step, message) => {
                this._view?.webview.postMessage({ 
                    type: 'workflowProgress', 
                    step, 
                    message 
                });
            }
        );

        if (result.success) {
            this._view?.webview.postMessage({ 
                type: 'workflowComplete', 
                result 
            });
        } else {
            this._view?.webview.postMessage({ 
                type: 'workflowError', 
                error: result.error 
            });
        }
    }

    private async saveGitHubToken(token: string) {
        await vscode.workspace.getConfiguration('cursorDocHelper').update(
            'githubToken', 
            token, 
            vscode.ConfigurationTarget.Global
        );
        vscode.window.showInformationMessage('GitHub token saved securely');
    }

    private async handleGeneratePrompts(payload: any) {
        const { repoUrl, docTypes, style } = payload;

        try {
            this._view?.webview.postMessage({ type: 'status', message: 'Analyzing repository...' });

            const repoInfo = await this.githubService.getRepositoryInfo(repoUrl);
            const analysis = await this.codeAnalyzer.analyzeRepository(repoInfo);
            
            const prompts: any = {};

            if (docTypes.includes('readme')) {
                prompts.readme = await this.promptBuilder.buildPrompt('readme', {
                    ...analysis,
                    style,
                    repoName: repoInfo.name,
                    repoDescription: repoInfo.description
                });
            }

            if (docTypes.includes('api')) {
                prompts.api = await this.promptBuilder.buildPrompt('api', {
                    ...analysis,
                    style,
                    repoName: repoInfo.name
                });
            }

            if (docTypes.includes('guide')) {
                prompts.guide = await this.promptBuilder.buildPrompt('guide', {
                    ...analysis,
                    style,
                    repoName: repoInfo.name
                });
            }

            this._view?.webview.postMessage({ 
                type: 'promptsGenerated', 
                prompts 
            });

        } catch (error: any) {
            this._view?.webview.postMessage({ 
                type: 'error', 
                message: error.message 
            });
        }
    }

    private _getHtmlForWebview(webview: vscode.Webview) {
        const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'src', 'webview', 'main.js'));
        const workflowScriptUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'src', 'webview', 'workflow.js'));
        const styleUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'src', 'webview', 'style.css'));

        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="${styleUri}" rel="stylesheet">
    <title>Documentation Generator</title>
</head>
<body>
    <div class="container">
        <h2>📚 Cursor Documentation Generator</h2>
        <p class="subtitle">Automated documentation generation with Cursor AI and GitHub integration</p>
        
        <div class="mode-selector">
            <label>
                <input type="radio" name="mode" value="manual" checked> Manual Mode (Generate Prompts)
            </label>
            <label>
                <input type="radio" name="mode" value="automated"> Automated Mode (Full Workflow)
            </label>
        </div>

        <div class="form-container">
            <div class="form-group">
                <label for="repoUrl">GitHub Repository URL</label>
                <input type="url" id="repoUrl" placeholder="https://github.com/username/repository" required>
            </div>

            <div class="form-group">
                <label>Documentation Types</label>
                <div class="doc-types">
                    <label class="checkbox">
                        <input type="checkbox" value="readme" checked> README.md
                    </label>
                    <label class="checkbox">
                        <input type="checkbox" value="api"> API Documentation
                    </label>
                    <label class="checkbox">
                        <input type="checkbox" value="guide"> User Guide
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label for="style">Documentation Style</label>
                <select id="style">
                    <option value="technical">Technical</option>
                    <option value="beginner">Beginner-friendly</option>
                    <option value="enterprise">Enterprise</option>
                </select>
            </div>

            <div class="form-group automated-only" style="display:none;">
                <label for="githubToken">GitHub Personal Access Token</label>
                <input type="password" id="githubToken" placeholder="ghp_xxxxxxxxxxxxx">
                <small>Required for automatic upload. <a href="#" id="tokenHelp">How to get a token?</a></small>
            </div>

            <div class="form-group automated-only" style="display:none;">
                <label for="targetBranch">Target Branch</label>
                <input type="text" id="targetBranch" placeholder="main" value="main">
            </div>

            <div class="form-group automated-only" style="display:none;">
                <label class="checkbox">
                    <input type="checkbox" id="autoCommit" checked> Auto-commit to GitHub
                </label>
                <label class="checkbox">
                    <input type="checkbox" id="createPR" checked> Create Pull Request
                </label>
            </div>

            <button id="generateBtn" class="btn-primary">Generate Prompts</button>
            <button id="executeBtn" class="btn-primary" style="display:none;">Execute Workflow</button>
        </div>

        <div id="statusMessage" class="status-message"></div>

        <div id="promptsOutput" class="prompts-output"></div>
    </div>

    <script src="${scriptUri}"></script>
    <script src="${workflowScriptUri}"></script>
</body>
</html>`;
    }
}