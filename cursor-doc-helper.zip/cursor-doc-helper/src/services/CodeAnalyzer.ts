import { RepositoryInfo } from './GitHubService';

export interface ProjectAnalysis {
    language: string;
    framework?: string;
    hasAPI: boolean;
    hasTests: boolean;
    packageManager: string;
    entryFile: string;
    structure: string[];
    dependencies: string[];
    buildTools: string[];
}

export class CodeAnalyzer {
    private languageExtensions: Map<string, string> = new Map([
        ['js', 'JavaScript'],
        ['jsx', 'JavaScript'],
        ['ts', 'TypeScript'],
        ['tsx', 'TypeScript'],
        ['py', 'Python'],
        ['java', 'Java'],
        ['cs', 'C#'],
        ['cpp', 'C++'],
        ['c', 'C'],
        ['rb', 'Ruby'],
        ['go', 'Go'],
        ['rs', 'Rust'],
        ['php', 'PHP'],
        ['swift', 'Swift'],
        ['kt', 'Kotlin'],
        ['scala', 'Scala'],
        ['r', 'R'],
        ['dart', 'Dart']
    ]);

    async analyzeRepository(repoInfo: RepositoryInfo): Promise<ProjectAnalysis> {
        const files = repoInfo.files;
        
        const language = this.detectPrimaryLanguage(files, repoInfo.language);
        const framework = this.detectFramework(files, language);
        const hasAPI = this.hasAPIFiles(files);
        const hasTests = this.hasTestFiles(files);
        const packageManager = this.detectPackageManager(files);
        const entryFile = this.detectEntryFile(files, language);
        const structure = this.analyzeStructure(files);
        const dependencies = this.extractDependencies(files);
        const buildTools = this.detectBuildTools(files);

        return {
            language,
            framework,
            hasAPI,
            hasTests,
            packageManager,
            entryFile,
            structure,
            dependencies,
            buildTools
        };
    }

    private detectPrimaryLanguage(files: string[], githubLanguage: string | null): string {
        if (githubLanguage) {
            return githubLanguage;
        }

        const extensionCounts: Map<string, number> = new Map();
        
        files.forEach(file => {
            const ext = file.split('.').pop()?.toLowerCase();
            if (ext && this.languageExtensions.has(ext)) {
                extensionCounts.set(ext, (extensionCounts.get(ext) || 0) + 1);
            }
        });

        if (extensionCounts.size === 0) {
            return 'Unknown';
        }

        const mostCommonExt = Array.from(extensionCounts.entries())
            .sort((a, b) => b[1] - a[1])[0][0];

        return this.languageExtensions.get(mostCommonExt) || 'Unknown';
    }

    private detectFramework(files: string[], language: string): string | undefined {
        const fileSet = new Set(files);

        if (language === 'JavaScript' || language === 'TypeScript') {
            if (fileSet.has('package.json')) {
                if (files.some(f => f.includes('next.config'))) return 'Next.js';
                if (files.some(f => f.includes('.nuxt'))) return 'Nuxt.js';
                if (files.some(f => f.includes('gatsby-config'))) return 'Gatsby';
                if (files.some(f => f.includes('angular.json'))) return 'Angular';
                if (files.some(f => f.includes('vue.config'))) return 'Vue.js';
                if (files.some(f => f.match(/src\/(App|app)\.(jsx?|tsx?)$/))) return 'React';
                if (fileSet.has('app.js') || fileSet.has('server.js')) return 'Express.js';
            }
        }

        if (language === 'Python') {
            if (fileSet.has('manage.py')) return 'Django';
            if (files.some(f => f.includes('flask'))) return 'Flask';
            if (fileSet.has('main.py') && files.some(f => f.includes('fastapi'))) return 'FastAPI';
            if (fileSet.has('streamlit_app.py')) return 'Streamlit';
        }

        if (language === 'Ruby') {
            if (fileSet.has('Gemfile') && files.some(f => f.includes('rails'))) return 'Ruby on Rails';
        }

        if (language === 'Java') {
            if (fileSet.has('pom.xml') || fileSet.has('build.gradle')) {
                if (files.some(f => f.includes('spring'))) return 'Spring Boot';
            }
        }

        if (language === 'C#') {
            if (files.some(f => f.endsWith('.csproj'))) {
                if (files.some(f => f.includes('Startup.cs'))) return 'ASP.NET Core';
            }
        }

        return undefined;
    }

    private hasAPIFiles(files: string[]): boolean {
        const apiIndicators = [
            /api\//i,
            /routes\//i,
            /controllers\//i,
            /endpoints\//i,
            /swagger/i,
            /openapi/i,
            /rest/i,
            /graphql/i,
            /\.proto$/
        ];

        return files.some(file => 
            apiIndicators.some(pattern => pattern.test(file))
        );
    }

    private hasTestFiles(files: string[]): boolean {
        const testIndicators = [
            /test/i,
            /spec/i,
            /\.test\./,
            /\.spec\./,
            /__tests__/,
            /tests\//
        ];

        return files.some(file => 
            testIndicators.some(pattern => pattern.test(file))
        );
    }

    private detectPackageManager(files: string[]): string {
        const fileSet = new Set(files);

        if (fileSet.has('package-lock.json')) return 'npm';
        if (fileSet.has('yarn.lock')) return 'yarn';
        if (fileSet.has('pnpm-lock.yaml')) return 'pnpm';
        if (fileSet.has('requirements.txt') || fileSet.has('Pipfile')) return 'pip';
        if (fileSet.has('Gemfile')) return 'bundler';
        if (fileSet.has('pom.xml')) return 'maven';
        if (fileSet.has('build.gradle')) return 'gradle';
        if (fileSet.has('Cargo.toml')) return 'cargo';
        if (fileSet.has('go.mod')) return 'go mod';
        if (fileSet.has('composer.json')) return 'composer';
        if (fileSet.has('pubspec.yaml')) return 'pub';

        return 'unknown';
    }

    private detectEntryFile(files: string[], language: string): string {
        const fileSet = new Set(files);

        const commonEntryPoints = [
            'index.js', 'index.ts', 'main.js', 'main.ts', 'app.js', 'app.ts',
            'server.js', 'server.ts', 'index.html', 'main.py', 'app.py',
            'manage.py', 'main.go', 'main.rs', 'Main.java', 'Program.cs',
            'main.cpp', 'main.c', 'index.php'
        ];

        for (const entry of commonEntryPoints) {
            if (fileSet.has(entry)) {
                return entry;
            }
        }

        for (const file of files) {
            if (file.startsWith('src/')) {
                const filename = file.substring(4);
                if (commonEntryPoints.includes(filename)) {
                    return file;
                }
            }
        }

        return 'unknown';
    }

    private analyzeStructure(files: string[]): string[] {
        const directories = new Set<string>();

        files.forEach(file => {
            const parts = file.split('/');
            if (parts.length > 1) {
                directories.add(parts[0]);
                if (parts[0] === 'src' && parts.length > 2) {
                    directories.add(`src/${parts[1]}`);
                }
            }
        });

        return Array.from(directories).sort().slice(0, 10);
    }

    private extractDependencies(files: string[]): string[] {
        const dependencies: string[] = [];

        const packageJsonFile = files.find(f => f === 'package.json');
        if (packageJsonFile) {
            dependencies.push('Check package.json for Node.js dependencies');
        }

        const requirementsFile = files.find(f => f === 'requirements.txt');
        if (requirementsFile) {
            dependencies.push('Check requirements.txt for Python dependencies');
        }

        const gemfileFile = files.find(f => f === 'Gemfile');
        if (gemfileFile) {
            dependencies.push('Check Gemfile for Ruby dependencies');
        }

        return dependencies;
    }

    private detectBuildTools(files: string[]): string[] {
        const buildTools: string[] = [];
        const fileSet = new Set(files);

        if (fileSet.has('webpack.config.js')) buildTools.push('Webpack');
        if (fileSet.has('rollup.config.js')) buildTools.push('Rollup');
        if (fileSet.has('vite.config.js') || fileSet.has('vite.config.ts')) buildTools.push('Vite');
        if (fileSet.has('gulpfile.js')) buildTools.push('Gulp');
        if (fileSet.has('Gruntfile.js')) buildTools.push('Grunt');
        if (fileSet.has('Makefile')) buildTools.push('Make');
        if (fileSet.has('Dockerfile')) buildTools.push('Docker');
        if (fileSet.has('.github/workflows') || files.some(f => f.startsWith('.github/workflows/'))) {
            buildTools.push('GitHub Actions');
        }

        return buildTools;
    }
}