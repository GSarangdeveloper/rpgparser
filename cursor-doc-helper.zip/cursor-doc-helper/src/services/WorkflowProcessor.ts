import * as fs from 'fs';
import * as path from 'path';
import { GitHubService, RepositoryInfo } from './GitHubService';
import { CodeAnalyzer, ProjectAnalysis } from './CodeAnalyzer';
import { PromptBuilder } from './PromptBuilder';
import { CursorAIService } from './CursorAIService';
import { GitService } from './GitService';

export interface WorkflowConfig {
    repository_url: string;
    documentation_types: string[];
    style: string;
    target_branch?: string;
    custom_sections?: string[];
    exclude_sections?: string[];
    github_token?: string;
    auto_commit: boolean;
    create_pr: boolean;
}

export interface WorkflowResult {
    success: boolean;
    files: { [key: string]: string };
    pr_url?: string;
    error?: string;
}

export class WorkflowProcessor {
    private githubService: GitHubService;
    private codeAnalyzer: CodeAnalyzer;
    private promptBuilder: PromptBuilder;
    private cursorAI: CursorAIService;
    private gitService: GitService;
    private workflowConfig: any;

    constructor() {
        this.githubService = new GitHubService();
        this.codeAnalyzer = new CodeAnalyzer();
        this.promptBuilder = new PromptBuilder();
        this.cursorAI = new CursorAIService();
        this.gitService = new GitService();
        this.loadWorkflowConfig();
    }

    private loadWorkflowConfig() {
        try {
            const configPath = path.join(__dirname, '../../workflow.md');
            const content = fs.readFileSync(configPath, 'utf8');
            this.workflowConfig = this.parseWorkflowConfig(content);
        } catch (error) {
            console.error('Failed to load workflow config:', error);
            this.workflowConfig = this.getDefaultConfig();
        }
    }

    private parseWorkflowConfig(content: string): any {
        const yamlMatch = content.match(/```yaml\n([\s\S]*?)\n```/);
        if (yamlMatch) {
            // In a real implementation, you'd use a YAML parser
            return {
                name: 'Cursor Documentation Generator',
                version: '1.0.0',
                steps: ['analyze', 'generate', 'cursor', 'git'],
                retry: { analyze: 3, cursor: 2, git: 1 }
            };
        }
        return this.getDefaultConfig();
    }

    private getDefaultConfig() {
        return {
            name: 'Cursor Documentation Generator',
            version: '1.0.0',
            steps: ['analyze', 'generate', 'cursor', 'git'],
            retry: { analyze: 3, cursor: 2, git: 1 }
        };
    }

    async executeWorkflow(config: WorkflowConfig, onProgress?: (step: string, message: string) => void): Promise<WorkflowResult> {
        const result: WorkflowResult = {
            success: false,
            files: {}
        };

        try {
            // Step 1: Analyze Repository
            onProgress?.('analyze', 'Analyzing repository structure...');
            const repoInfo = await this.analyzeRepository(config.repository_url);
            
            // Step 2: Generate Prompts
            onProgress?.('prompts', 'Generating documentation prompts...');
            const prompts = await this.generatePrompts(repoInfo, config);
            
            // Step 3: Generate Documentation with Cursor AI
            onProgress?.('cursor', 'Generating documentation with Cursor AI...');
            const documentation = await this.generateDocumentation(prompts, config);
            result.files = documentation;
            
            // Step 4: Git Integration (if enabled)
            if (config.auto_commit && config.github_token) {
                onProgress?.('git', 'Uploading documentation to GitHub...');
                const gitResult = await this.uploadToGit(documentation, config);
                result.pr_url = gitResult.pr_url;
            }
            
            result.success = true;
            onProgress?.('complete', 'Documentation generation complete!');
            
        } catch (error: any) {
            result.error = error.message;
            onProgress?.('error', `Error: ${error.message}`);
        }
        
        return result;
    }

    private async analyzeRepository(repoUrl: string): Promise<{ info: RepositoryInfo; analysis: ProjectAnalysis }> {
        const info = await this.githubService.getRepositoryInfo(repoUrl);
        const analysis = await this.codeAnalyzer.analyzeRepository(info);
        return { info, analysis };
    }

    private async generatePrompts(
        repoData: { info: RepositoryInfo; analysis: ProjectAnalysis },
        config: WorkflowConfig
    ): Promise<{ [key: string]: string }> {
        const prompts: { [key: string]: string } = {};
        const context = {
            ...repoData.analysis,
            repoName: repoData.info.name,
            repoDescription: repoData.info.description,
            style: config.style,
            customSections: config.custom_sections,
            excludeSections: config.exclude_sections
        };

        for (const docType of config.documentation_types) {
            prompts[docType] = await this.promptBuilder.buildPrompt(docType, context);
        }

        return prompts;
    }

    private async generateDocumentation(
        prompts: { [key: string]: string },
        config: WorkflowConfig
    ): Promise<{ [key: string]: string }> {
        const documentation: { [key: string]: string } = {};
        
        for (const [type, prompt] of Object.entries(prompts)) {
            // Generate documentation using Cursor AI
            const content = await this.cursorAI.generateContent(prompt, {
                maxTokens: 8000,
                temperature: 0.7,
                model: 'claude-3'
            });
            
            // Map to appropriate filename
            const filename = this.getFilenameForType(type);
            documentation[filename] = content;
        }
        
        return documentation;
    }

    private async uploadToGit(
        documentation: { [key: string]: string },
        config: WorkflowConfig
    ): Promise<{ pr_url?: string }> {
        if (!config.github_token) {
            throw new Error('GitHub token required for auto-upload');
        }

        this.gitService.setToken(config.github_token);
        
        // Parse repository info from URL
        const { owner, repo } = this.parseGitHubUrl(config.repository_url);
        
        // Create branch
        const timestamp = Date.now();
        const branchName = `docs/auto-generated-${timestamp}`;
        await this.gitService.createBranch(owner, repo, branchName, config.target_branch || 'main');
        
        // Upload files
        for (const [filename, content] of Object.entries(documentation)) {
            await this.gitService.createOrUpdateFile(
                owner, 
                repo, 
                filename, 
                content, 
                `📚 Add ${filename}`,
                branchName
            );
        }
        
        // Create PR if requested
        if (config.create_pr) {
            const pr = await this.gitService.createPullRequest(
                owner,
                repo,
                branchName,
                config.target_branch || 'main',
                '📚 Documentation Update',
                'This PR contains auto-generated documentation using Cursor AI.\n\n' +
                'Files updated:\n' + 
                Object.keys(documentation).map(f => `- ${f}`).join('\n')
            );
            
            return { pr_url: pr.html_url };
        }
        
        return {};
    }

    private getFilenameForType(type: string): string {
        const mapping: { [key: string]: string } = {
            'readme': 'README.md',
            'api': 'docs/API.md',
            'guide': 'docs/GUIDE.md',
            'contributing': 'CONTRIBUTING.md',
            'changelog': 'CHANGELOG.md'
        };
        return mapping[type] || `${type.toUpperCase()}.md`;
    }

    private parseGitHubUrl(url: string): { owner: string; repo: string } {
        const match = url.match(/github\.com\/([^\/]+)\/([^\/\?]+)/);
        if (!match) {
            throw new Error('Invalid GitHub URL');
        }
        return { owner: match[1], repo: match[2].replace(/\.git$/, '') };
    }
}