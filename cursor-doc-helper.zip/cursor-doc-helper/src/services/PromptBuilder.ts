import * as Handlebars from 'handlebars';
import * as fs from 'fs';
import * as path from 'path';

export class PromptBuilder {
    private templates: Map<string, HandlebarsTemplateDelegate> = new Map();

    constructor() {
        this.loadTemplates();
        this.registerHelpers();
    }

    private loadTemplates() {
        const templateDir = path.join(__dirname, '..', 'templates');
        const templateFiles = {
            'readme': 'readme-prompt.hbs',
            'api': 'api-prompt.hbs',
            'guide': 'guide-prompt.hbs'
        };

        for (const [key, filename] of Object.entries(templateFiles)) {
            const templatePath = path.join(templateDir, filename);
            try {
                const templateContent = fs.readFileSync(templatePath, 'utf8');
                this.templates.set(key, Handlebars.compile(templateContent));
            } catch (error) {
                console.error(`Failed to load template ${filename}:`, error);
                this.templates.set(key, this.getDefaultTemplate(key));
            }
        }
    }

    private registerHelpers() {
        Handlebars.registerHelper('eq', (a: any, b: any) => a === b);
        Handlebars.registerHelper('includes', (arr: any[], val: any) => arr && arr.includes(val));
        Handlebars.registerHelper('capitalize', (str: string) => 
            str ? str.charAt(0).toUpperCase() + str.slice(1) : ''
        );
    }

    async buildPrompt(type: string, context: any): Promise<string> {
        const template = this.templates.get(type);
        
        if (!template) {
            throw new Error(`Template type '${type}' not found`);
        }

        try {
            return template(context);
        } catch (error: any) {
            console.error(`Error generating prompt for ${type}:`, error);
            return this.getFallbackPrompt(type, context);
        }
    }

    private getDefaultTemplate(type: string): HandlebarsTemplateDelegate {
        const defaultTemplates: Record<string, string> = {
            'readme': `Create a comprehensive README.md for a {{language}} project named {{repoName}}.
Include installation instructions, usage examples, and contribution guidelines.
Style: {{style}}`,
            
            'api': `Create API documentation for a {{language}} {{framework}} project named {{repoName}}.
Include endpoint documentation, authentication details, and example requests.
Style: {{style}}`,
            
            'guide': `Create a user guide for a {{language}} project named {{repoName}}.
Include getting started instructions, tutorials, and troubleshooting.
Style: {{style}}`
        };

        return Handlebars.compile(defaultTemplates[type] || 'Generate documentation for {{repoName}}');
    }

    private getFallbackPrompt(type: string, context: any): string {
        const { language, framework, repoName, style, hasAPI, hasTests } = context;
        
        let prompt = `Please create ${type === 'readme' ? 'a README.md' : type === 'api' ? 'API documentation' : 'a user guide'} `;
        prompt += `for a ${language}${framework ? ` ${framework}` : ''} project called "${repoName}". `;
        
        if (type === 'readme') {
            prompt += `Include the following sections:
1. Project description and features
2. Installation instructions using ${context.packageManager}
3. Usage examples and code snippets
4. Configuration options
5. Contributing guidelines
6. License information`;
            
            if (hasAPI) prompt += `\n7. API overview and examples`;
            if (hasTests) prompt += `\n8. Testing instructions`;
        } else if (type === 'api') {
            prompt += `Document all API endpoints with:
- HTTP methods and paths
- Request/response formats
- Authentication requirements
- Error codes
- Example requests using curl or fetch`;
        } else if (type === 'guide') {
            prompt += `Create a comprehensive guide with:
- Getting started tutorial
- Core concepts explanation
- Step-by-step walkthroughs
- Common use cases
- Troubleshooting section
- Best practices`;
        }
        
        prompt += `\n\nDocumentation style: ${style}`;
        prompt += `\nMake it ${style === 'beginner' ? 'beginner-friendly with lots of examples' : 
                           style === 'enterprise' ? 'professional and comprehensive for enterprise teams' : 
                           'technical and detailed for experienced developers'}.`;
        
        return prompt;
    }
}