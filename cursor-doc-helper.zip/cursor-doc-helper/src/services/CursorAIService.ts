import * as vscode from 'vscode';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface CursorAIOptions {
    model?: string;
    maxTokens?: number;
    temperature?: number;
}

export class CursorAIService {
    private cursorPath: string | null = null;

    constructor() {
        this.detectCursorInstallation();
    }

    private async detectCursorInstallation() {
        // Try to find Cursor installation
        const possiblePaths = [
            process.platform === 'win32' ? 
                `${process.env.LOCALAPPDATA}\\Programs\\cursor\\Cursor.exe` :
                '/Applications/Cursor.app/Contents/MacOS/Cursor',
            process.platform === 'linux' ? 
                '/usr/bin/cursor' : ''
        ];

        for (const path of possiblePaths) {
            if (path && await this.fileExists(path)) {
                this.cursorPath = path;
                break;
            }
        }
    }

    private async fileExists(path: string): Promise<boolean> {
        try {
            const fs = require('fs').promises;
            await fs.access(path);
            return true;
        } catch {
            return false;
        }
    }

    async generateContent(prompt: string, options?: CursorAIOptions): Promise<string> {
        // Since Cursor doesn't have a public API, we'll implement different strategies:
        
        // Strategy 1: Use Cursor CLI if available (hypothetical future feature)
        if (this.cursorPath && await this.hasCursorCLI()) {
            return await this.generateViaCLI(prompt, options);
        }
        
        // Strategy 2: Use VS Code's Cursor extension if installed
        const cursorExtension = vscode.extensions.getExtension('cursor.cursor-vscode');
        if (cursorExtension) {
            return await this.generateViaExtension(prompt, options);
        }
        
        // Strategy 3: Generate via clipboard automation (fallback)
        return await this.generateViaClipboard(prompt, options);
    }

    private async hasCursorCLI(): Promise<boolean> {
        try {
            const { stdout } = await execAsync('cursor --version');
            return stdout.includes('Cursor');
        } catch {
            return false;
        }
    }

    private async generateViaCLI(prompt: string, options?: CursorAIOptions): Promise<string> {
        // Hypothetical CLI command (not yet available)
        // This would be the ideal implementation if Cursor adds CLI support
        const command = `cursor generate --prompt "${prompt.replace(/"/g, '\\"')}" --model ${options?.model || 'claude-3'} --max-tokens ${options?.maxTokens || 8000}`;
        
        try {
            const { stdout } = await execAsync(command);
            return stdout;
        } catch (error: any) {
            throw new Error(`Cursor CLI generation failed: ${error.message}`);
        }
    }

    private async generateViaExtension(prompt: string, options?: CursorAIOptions): Promise<string> {
        // Attempt to use Cursor's VS Code extension API
        try {
            // Send command to Cursor extension
            const result = await vscode.commands.executeCommand('cursor.generateDocumentation', {
                prompt,
                options
            });
            
            if (typeof result === 'string') {
                return result;
            }
            
            throw new Error('Invalid response from Cursor extension');
        } catch (error: any) {
            throw new Error(`Cursor extension generation failed: ${error.message}`);
        }
    }

    private async generateViaClipboard(prompt: string, options?: CursorAIOptions): Promise<string> {
        // Fallback: Copy prompt to clipboard and provide instructions
        await vscode.env.clipboard.writeText(prompt);
        
        // Show notification with instructions
        const action = await vscode.window.showInformationMessage(
            'Prompt copied to clipboard. Please paste it in Cursor and copy the response back.',
            'I\'ve Generated the Documentation'
        );
        
        if (action === 'I\'ve Generated the Documentation') {
            // Read the generated content from clipboard
            const generatedContent = await vscode.env.clipboard.readText();
            
            // Basic validation
            if (generatedContent.length < 100) {
                throw new Error('Generated content seems too short. Please ensure you copied the full response.');
            }
            
            return generatedContent;
        }
        
        throw new Error('Documentation generation cancelled');
    }

    async generateWithTemplate(templateContent: string, context: any, options?: CursorAIOptions): Promise<string> {
        // Replace template variables
        let prompt = templateContent;
        for (const [key, value] of Object.entries(context)) {
            const regex = new RegExp(`{{${key}}}`, 'g');
            prompt = prompt.replace(regex, String(value));
        }
        
        return await this.generateContent(prompt, options);
    }

    async batchGenerate(prompts: string[], options?: CursorAIOptions): Promise<string[]> {
        const results: string[] = [];
        
        for (const prompt of prompts) {
            try {
                const content = await this.generateContent(prompt, options);
                results.push(content);
                
                // Add delay to avoid rate limiting
                await this.delay(2000);
            } catch (error: any) {
                console.error(`Failed to generate content for prompt: ${error.message}`);
                results.push(''); // Add empty string for failed generations
            }
        }
        
        return results;
    }

    private delay(ms: number): Promise<void> {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Simulate API call for testing
    async simulateGeneration(prompt: string, options?: CursorAIOptions): Promise<string> {
        // This is a mock implementation for testing
        await this.delay(1000); // Simulate API delay
        
        const templates: { [key: string]: string } = {
            readme: `# Project Name

## Description
This is an auto-generated README for your project based on the analysis.

## Installation
\`\`\`bash
npm install
\`\`\`

## Usage
\`\`\`javascript
// Example usage
const app = require('./index');
app.start();
\`\`\`

## API Reference
See API.md for detailed API documentation.

## Contributing
Contributions are welcome! Please read CONTRIBUTING.md.

## License
MIT`,
            
            api: `# API Documentation

## Base URL
\`http://localhost:3000/api\`

## Endpoints

### GET /users
Returns a list of users.

### POST /users
Creates a new user.

### GET /users/:id
Returns a specific user.

### PUT /users/:id  
Updates a user.

### DELETE /users/:id
Deletes a user.`,
            
            guide: `# User Guide

## Getting Started
Follow these steps to get started with the application.

## Installation
1. Clone the repository
2. Install dependencies
3. Configure environment
4. Run the application

## Basic Usage
Learn the basics of using the application.

## Advanced Features
Explore advanced features and configurations.`
        };
        
        // Determine which template to use based on prompt content
        if (prompt.toLowerCase().includes('readme')) {
            return templates.readme;
        } else if (prompt.toLowerCase().includes('api')) {
            return templates.api;
        } else if (prompt.toLowerCase().includes('guide')) {
            return templates.guide;
        }
        
        return `# Generated Documentation\n\nThis is simulated content based on your prompt:\n\n${prompt.substring(0, 200)}...`;
    }
}