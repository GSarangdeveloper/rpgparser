import { Octokit } from '@octokit/rest';

export class GitService {
    private octokit: Octokit | null = null;

    setToken(token: string) {
        this.octokit = new Octokit({ auth: token });
    }

    async createBranch(owner: string, repo: string, branchName: string, baseBranch: string = 'main'): Promise<void> {
        if (!this.octokit) throw new Error('GitHub token not set');

        try {
            // Get the SHA of the base branch
            const { data: refData } = await this.octokit.git.getRef({
                owner,
                repo,
                ref: `heads/${baseBranch}`
            });

            // Create new branch
            await this.octokit.git.createRef({
                owner,
                repo,
                ref: `refs/heads/${branchName}`,
                sha: refData.object.sha
            });
        } catch (error: any) {
            if (error.status === 422) {
                // Branch already exists
                console.log(`Branch ${branchName} already exists`);
            } else {
                throw new Error(`Failed to create branch: ${error.message}`);
            }
        }
    }

    async createOrUpdateFile(
        owner: string,
        repo: string,
        path: string,
        content: string,
        message: string,
        branch: string
    ): Promise<void> {
        if (!this.octokit) throw new Error('GitHub token not set');

        try {
            // Check if file exists
            let sha: string | undefined;
            try {
                const { data: fileData } = await this.octokit.repos.getContent({
                    owner,
                    repo,
                    path,
                    ref: branch
                });
                
                if (!Array.isArray(fileData) && fileData.type === 'file') {
                    sha = fileData.sha;
                }
            } catch (error: any) {
                // File doesn't exist, which is fine
                if (error.status !== 404) {
                    throw error;
                }
            }

            // Create or update file
            await this.octokit.repos.createOrUpdateFileContents({
                owner,
                repo,
                path,
                message,
                content: Buffer.from(content).toString('base64'),
                branch,
                sha
            });
        } catch (error: any) {
            throw new Error(`Failed to create/update file: ${error.message}`);
        }
    }

    async createPullRequest(
        owner: string,
        repo: string,
        head: string,
        base: string,
        title: string,
        body: string
    ): Promise<any> {
        if (!this.octokit) throw new Error('GitHub token not set');

        try {
            const { data: pr } = await this.octokit.pulls.create({
                owner,
                repo,
                title,
                head,
                base,
                body
            });

            return pr;
        } catch (error: any) {
            throw new Error(`Failed to create pull request: ${error.message}`);
        }
    }

    async getFile(owner: string, repo: string, path: string, ref?: string): Promise<string | null> {
        if (!this.octokit) throw new Error('GitHub token not set');

        try {
            const { data } = await this.octokit.repos.getContent({
                owner,
                repo,
                path,
                ref
            });

            if (!Array.isArray(data) && data.type === 'file') {
                const content = Buffer.from(data.content, 'base64').toString('utf8');
                return content;
            }
            
            return null;
        } catch (error: any) {
            if (error.status === 404) {
                return null;
            }
            throw new Error(`Failed to get file: ${error.message}`);
        }
    }

    async listFiles(owner: string, repo: string, path: string = '', ref?: string): Promise<string[]> {
        if (!this.octokit) throw new Error('GitHub token not set');

        try {
            const { data } = await this.octokit.repos.getContent({
                owner,
                repo,
                path,
                ref
            });

            if (Array.isArray(data)) {
                return data
                    .filter(item => item.type === 'file')
                    .map(item => item.path);
            }
            
            return [];
        } catch (error: any) {
            throw new Error(`Failed to list files: ${error.message}`);
        }
    }

    async validateToken(token: string): Promise<boolean> {
        try {
            const testOctokit = new Octokit({ auth: token });
            await testOctokit.users.getAuthenticated();
            return true;
        } catch {
            return false;
        }
    }

    async getRepositoryPermissions(owner: string, repo: string): Promise<string> {
        if (!this.octokit) throw new Error('GitHub token not set');

        try {
            const { data } = await this.octokit.repos.get({
                owner,
                repo
            });

            if (data.permissions) {
                if (data.permissions.admin) return 'admin';
                if (data.permissions.push) return 'write';
                if (data.permissions.pull) return 'read';
            }
            
            return 'none';
        } catch (error: any) {
            throw new Error(`Failed to get repository permissions: ${error.message}`);
        }
    }
}