import { Octokit } from '@octokit/rest';

export interface RepositoryInfo {
    name: string;
    description: string | null;
    language: string | null;
    defaultBranch: string;
    files: string[];
    owner: string;
    repo: string;
}

export class GitHubService {
    private octokit: Octokit;

    constructor() {
        this.octokit = new Octokit();
    }

    async getRepositoryInfo(repoUrl: string): Promise<RepositoryInfo> {
        const { owner, repo } = this.parseGitHubUrl(repoUrl);

        try {
            const [repoData, treeData] = await Promise.all([
                this.octokit.rest.repos.get({ owner, repo }),
                this.getFileTree(owner, repo)
            ]);

            return {
                name: repoData.data.name,
                description: repoData.data.description,
                language: repoData.data.language,
                defaultBranch: repoData.data.default_branch,
                files: treeData,
                owner,
                repo
            };
        } catch (error: any) {
            if (error.status === 404) {
                throw new Error('Repository not found. Please check the URL and ensure the repository is public.');
            }
            throw new Error(`Failed to access repository: ${error.message}`);
        }
    }

    private async getFileTree(owner: string, repo: string): Promise<string[]> {
        try {
            const { data: repoData } = await this.octokit.rest.repos.get({ owner, repo });
            const { data: treeData } = await this.octokit.rest.git.getTree({
                owner,
                repo,
                tree_sha: repoData.default_branch,
                recursive: '1'
            });

            return treeData.tree
                .filter(item => item.type === 'blob')
                .map(item => item.path!)
                .filter(Boolean);
        } catch (error) {
            console.error('Error fetching file tree:', error);
            return [];
        }
    }

    private parseGitHubUrl(url: string): { owner: string; repo: string } {
        const urlPattern = /^https?:\/\/github\.com\/([^\/]+)\/([^\/\?]+)/;
        const match = url.match(urlPattern);

        if (!match) {
            throw new Error('Invalid GitHub URL. Please provide a URL in the format: https://github.com/owner/repo');
        }

        return {
            owner: match[1],
            repo: match[2].replace(/\.git$/, '')
        };
    }
}