import * as vscode from 'vscode';
import { DocGeneratorPanel } from './panels/DocGeneratorPanel';

export function activate(context: vscode.ExtensionContext) {
    console.log('Cursor Documentation Generator is now active!');

    const provider = new DocGeneratorPanel(context.extensionUri);

    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider(DocGeneratorPanel.viewType, provider)
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('docGenerator.refresh', () => {
            provider.refresh();
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('docGenerator.generatePrompts', () => {
            provider.generatePrompts();
        })
    );
}

export function deactivate() {}