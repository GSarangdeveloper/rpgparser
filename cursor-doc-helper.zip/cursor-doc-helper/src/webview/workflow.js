(function() {
    const vscode = acquireVsCodeApi();
    
    // Elements
    const modeRadios = document.querySelectorAll('input[name="mode"]');
    const generateBtn = document.getElementById('generateBtn');
    const executeBtn = document.getElementById('executeBtn');
    const repoUrlInput = document.getElementById('repoUrl');
    const githubTokenInput = document.getElementById('githubToken');
    const targetBranchInput = document.getElementById('targetBranch');
    const autoCommitCheckbox = document.getElementById('autoCommit');
    const createPRCheckbox = document.getElementById('createPR');
    const statusMessage = document.getElementById('statusMessage');
    const promptsOutput = document.getElementById('promptsOutput');
    const automatedElements = document.querySelectorAll('.automated-only');
    const tokenHelp = document.getElementById('tokenHelp');
    
    let currentMode = 'manual';
    let workflowInProgress = false;

    // Mode switching
    modeRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            currentMode = e.target.value;
            updateUIForMode();
        });
    });

    function updateUIForMode() {
        if (currentMode === 'automated') {
            // Show automated options
            automatedElements.forEach(el => el.style.display = 'block');
            generateBtn.style.display = 'none';
            executeBtn.style.display = 'block';
            executeBtn.textContent = 'Execute Full Workflow';
        } else {
            // Show manual options
            automatedElements.forEach(el => el.style.display = 'none');
            generateBtn.style.display = 'block';
            executeBtn.style.display = 'none';
        }
    }

    // Token help link
    if (tokenHelp) {
        tokenHelp.addEventListener('click', (e) => {
            e.preventDefault();
            showTokenHelp();
        });
    }

    function showTokenHelp() {
        const helpMessage = `
To create a GitHub Personal Access Token:
1. Go to GitHub Settings > Developer settings > Personal access tokens
2. Click "Generate new token (classic)"
3. Give it a name and select these scopes:
   - repo (all)
   - workflow (if using GitHub Actions)
4. Click "Generate token"
5. Copy the token (starts with ghp_)

Note: Keep your token secure and never commit it to code!
        `;
        vscode.postMessage({ type: 'showInfo', message: helpMessage });
    }

    // Execute workflow button
    executeBtn.addEventListener('click', async () => {
        if (workflowInProgress) {
            showStatus('Workflow already in progress...', 'info');
            return;
        }

        const repoUrl = repoUrlInput.value.trim();
        const docTypes = getSelectedDocTypes();
        const style = document.getElementById('style').value;
        const githubToken = githubTokenInput.value.trim();
        const targetBranch = targetBranchInput.value.trim() || 'main';
        const autoCommit = autoCommitCheckbox.checked;
        const createPR = createPRCheckbox.checked;

        // Validation
        if (!repoUrl) {
            showStatus('Please enter a GitHub repository URL', 'error');
            return;
        }

        if (docTypes.length === 0) {
            showStatus('Please select at least one documentation type', 'error');
            return;
        }

        if (autoCommit && !githubToken) {
            showStatus('GitHub token is required for auto-commit', 'error');
            return;
        }

        // Start workflow
        workflowInProgress = true;
        executeBtn.disabled = true;
        executeBtn.innerHTML = 'Executing Workflow... <span class="loading"></span>';
        showWorkflowProgress();

        vscode.postMessage({
            type: 'executeWorkflow',
            payload: {
                repoUrl,
                docTypes,
                style,
                githubToken,
                targetBranch,
                autoCommit,
                createPR
            }
        });
    });

    function getSelectedDocTypes() {
        const checkboxes = document.querySelectorAll('.doc-types input[type="checkbox"]:checked');
        return Array.from(checkboxes).map(cb => cb.value);
    }

    function showStatus(message, type) {
        statusMessage.textContent = message;
        statusMessage.className = 'status-message ' + type;
    }

    function showWorkflowProgress() {
        promptsOutput.innerHTML = '';
        
        const progressContainer = document.createElement('div');
        progressContainer.className = 'workflow-progress';
        progressContainer.innerHTML = `
            <h3>🚀 Workflow Progress</h3>
            <div class="progress-steps">
                <div class="step" id="step-analyze">
                    <span class="step-icon">🔍</span>
                    <span class="step-text">Analyzing Repository</span>
                    <span class="step-status pending">⏳</span>
                </div>
                <div class="step" id="step-prompts">
                    <span class="step-icon">📝</span>
                    <span class="step-text">Generating Prompts</span>
                    <span class="step-status pending">⏳</span>
                </div>
                <div class="step" id="step-cursor">
                    <span class="step-icon">🤖</span>
                    <span class="step-text">Generating Documentation</span>
                    <span class="step-status pending">⏳</span>
                </div>
                <div class="step" id="step-git">
                    <span class="step-icon">📤</span>
                    <span class="step-text">Uploading to GitHub</span>
                    <span class="step-status pending">⏳</span>
                </div>
                <div class="step" id="step-complete">
                    <span class="step-icon">✅</span>
                    <span class="step-text">Complete</span>
                    <span class="step-status pending">⏳</span>
                </div>
            </div>
            <div class="progress-log" id="progressLog"></div>
        `;
        
        promptsOutput.appendChild(progressContainer);
        promptsOutput.classList.add('visible');
    }

    function updateWorkflowStep(step, status, message) {
        const stepElement = document.getElementById(`step-${step}`);
        if (stepElement) {
            const statusElement = stepElement.querySelector('.step-status');
            if (status === 'in-progress') {
                statusElement.textContent = '⏳';
                statusElement.className = 'step-status in-progress';
            } else if (status === 'completed') {
                statusElement.textContent = '✅';
                statusElement.className = 'step-status completed';
            } else if (status === 'error') {
                statusElement.textContent = '❌';
                statusElement.className = 'step-status error';
            }
        }

        // Add to log
        const log = document.getElementById('progressLog');
        if (log && message) {
            const logEntry = document.createElement('div');
            logEntry.className = 'log-entry';
            logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
            log.appendChild(logEntry);
            log.scrollTop = log.scrollHeight;
        }
    }

    // Message handlers
    window.addEventListener('message', event => {
        const message = event.data;
        
        switch (message.type) {
            case 'workflowProgress':
                handleWorkflowProgress(message.step, message.message);
                break;
                
            case 'workflowComplete':
                handleWorkflowComplete(message.result);
                break;
                
            case 'workflowError':
                handleWorkflowError(message.error);
                break;
                
            case 'promptsGenerated':
                if (currentMode === 'manual') {
                    displayPrompts(message.prompts);
                }
                break;
                
            case 'error':
                showStatus('❌ Error: ' + message.message, 'error');
                resetWorkflowUI();
                break;
        }
    });

    function handleWorkflowProgress(step, message) {
        const stepMap = {
            'analyze': 'analyze',
            'prompts': 'prompts', 
            'cursor': 'cursor',
            'git': 'git',
            'complete': 'complete'
        };

        if (stepMap[step]) {
            updateWorkflowStep(stepMap[step], 'in-progress', message);
            
            // Mark previous steps as completed
            const steps = ['analyze', 'prompts', 'cursor', 'git', 'complete'];
            const currentIndex = steps.indexOf(stepMap[step]);
            for (let i = 0; i < currentIndex; i++) {
                updateWorkflowStep(steps[i], 'completed', '');
            }
        }
    }

    function handleWorkflowComplete(result) {
        workflowInProgress = false;
        executeBtn.disabled = false;
        executeBtn.textContent = 'Execute Full Workflow';
        
        updateWorkflowStep('complete', 'completed', 'Workflow completed successfully!');
        
        if (result.pr_url) {
            const successDiv = document.createElement('div');
            successDiv.className = 'success-message';
            successDiv.innerHTML = `
                <h3>🎉 Documentation Generated and Uploaded!</h3>
                <p>Pull Request created: <a href="${result.pr_url}" target="_blank">${result.pr_url}</a></p>
                <p>Files generated:</p>
                <ul>
                    ${Object.keys(result.files).map(f => `<li>${f}</li>`).join('')}
                </ul>
            `;
            promptsOutput.appendChild(successDiv);
        }
        
        showStatus('✅ Workflow completed successfully!', 'success');
    }

    function handleWorkflowError(error) {
        workflowInProgress = false;
        executeBtn.disabled = false;
        executeBtn.textContent = 'Execute Full Workflow';
        
        updateWorkflowStep('complete', 'error', `Error: ${error}`);
        showStatus('❌ Workflow failed: ' + error, 'error');
    }

    function resetWorkflowUI() {
        workflowInProgress = false;
        executeBtn.disabled = false;
        executeBtn.textContent = 'Execute Full Workflow';
    }

    function displayPrompts(prompts) {
        // Existing prompt display logic from main.js
        generateBtn.disabled = false;
        generateBtn.textContent = 'Generate Prompts';
        
        promptsOutput.innerHTML = '';
        // ... rest of display logic
    }

    // Initialize
    updateUIForMode();
})();