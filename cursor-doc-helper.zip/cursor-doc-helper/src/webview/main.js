(function() {
    const vscode = acquireVsCodeApi();
    
    const generateBtn = document.getElementById('generateBtn');
    const repoUrlInput = document.getElementById('repoUrl');
    const styleSelect = document.getElementById('style');
    const statusMessage = document.getElementById('statusMessage');
    const promptsOutput = document.getElementById('promptsOutput');
    
    let generatedPrompts = {};

    generateBtn.addEventListener('click', () => {
        const repoUrl = repoUrlInput.value.trim();
        const docTypes = getSelectedDocTypes();
        const style = styleSelect.value;

        if (!repoUrl) {
            showStatus('Please enter a GitHub repository URL', 'error');
            return;
        }

        if (docTypes.length === 0) {
            showStatus('Please select at least one documentation type', 'error');
            return;
        }

        if (!isValidGitHubUrl(repoUrl)) {
            showStatus('Please enter a valid GitHub repository URL (e.g., https://github.com/owner/repo)', 'error');
            return;
        }

        generateBtn.disabled = true;
        generateBtn.innerHTML = 'Generating... <span class="loading"></span>';
        showStatus('Analyzing repository and generating prompts...', 'info');
        promptsOutput.classList.remove('visible');

        vscode.postMessage({
            type: 'generatePrompts',
            payload: {
                repoUrl,
                docTypes,
                style
            }
        });
    });

    function getSelectedDocTypes() {
        const checkboxes = document.querySelectorAll('.doc-types input[type="checkbox"]:checked');
        return Array.from(checkboxes).map(cb => cb.value);
    }

    function isValidGitHubUrl(url) {
        const pattern = /^https?:\/\/github\.com\/[^\/]+\/[^\/\?]+/;
        return pattern.test(url);
    }

    function showStatus(message, type) {
        statusMessage.textContent = message;
        statusMessage.className = 'status-message ' + type;
    }

    function displayPrompts(prompts) {
        generatedPrompts = prompts;
        promptsOutput.innerHTML = '';

        if (Object.keys(prompts).length === 0) {
            showStatus('No prompts generated. Please try again.', 'error');
            return;
        }

        const instructions = document.createElement('div');
        instructions.className = 'instructions';
        instructions.innerHTML = `
            <h4>📝 How to use these prompts:</h4>
            <ol>
                <li>Click "Copy to Clipboard" on the prompt you want to use</li>
                <li>Open Cursor AI in your project</li>
                <li>Start a new chat or continue an existing one</li>
                <li>Paste the prompt and press Enter</li>
                <li>Review the generated documentation and save to your project</li>
            </ol>
        `;
        promptsOutput.appendChild(instructions);

        const promptTypeNames = {
            readme: '📖 README Generation Prompt',
            api: '🔌 API Documentation Prompt',
            guide: '📚 User Guide Prompt'
        };

        for (const [type, prompt] of Object.entries(prompts)) {
            const promptItem = document.createElement('div');
            promptItem.className = 'prompt-item';
            
            const title = document.createElement('h3');
            title.textContent = promptTypeNames[type] || type;
            
            const textarea = document.createElement('textarea');
            textarea.value = prompt;
            textarea.readOnly = true;
            textarea.id = `prompt-${type}`;
            
            const copyBtn = document.createElement('button');
            copyBtn.className = 'btn-secondary copy-button';
            copyBtn.textContent = '📋 Copy to Clipboard';
            copyBtn.onclick = () => copyToClipboard(type, prompt);
            
            promptItem.appendChild(title);
            promptItem.appendChild(textarea);
            promptItem.appendChild(copyBtn);
            
            promptsOutput.appendChild(promptItem);
        }

        promptsOutput.classList.add('visible');
        showStatus('✅ Prompts generated successfully! Copy and paste into Cursor AI to generate documentation.', 'success');
    }

    function copyToClipboard(type, text) {
        vscode.postMessage({
            type: 'copyToClipboard',
            text: text
        });

        const copyBtn = event.target;
        const originalText = copyBtn.textContent;
        copyBtn.textContent = '✅ Copied!';
        copyBtn.style.backgroundColor = 'var(--vscode-terminal-ansiGreen)';
        
        setTimeout(() => {
            copyBtn.textContent = originalText;
            copyBtn.style.backgroundColor = '';
        }, 2000);
    }

    window.addEventListener('message', event => {
        const message = event.data;
        
        switch (message.type) {
            case 'promptsGenerated':
                generateBtn.disabled = false;
                generateBtn.textContent = 'Generate Prompts';
                displayPrompts(message.prompts);
                break;
                
            case 'error':
                generateBtn.disabled = false;
                generateBtn.textContent = 'Generate Prompts';
                showStatus('❌ Error: ' + message.message, 'error');
                break;
                
            case 'status':
                showStatus(message.message, 'info');
                break;
                
            case 'refresh':
                repoUrlInput.value = '';
                document.querySelectorAll('.doc-types input[type="checkbox"]').forEach(cb => {
                    cb.checked = cb.value === 'readme';
                });
                styleSelect.value = 'technical';
                promptsOutput.innerHTML = '';
                promptsOutput.classList.remove('visible');
                statusMessage.className = 'status-message';
                statusMessage.textContent = '';
                break;
        }
    });

    repoUrlInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            generateBtn.click();
        }
    });
})();