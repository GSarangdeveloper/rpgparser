# Cursor Documentation Generator - Team Distribution Script (Windows)
# Run this script in PowerShell to build and distribute the extension

$ErrorActionPreference = "Stop"

# Configuration
$EXTENSION_NAME = "cursor-doc-helper"
$VERSION = "0.0.1"
$VSIX_FILE = "$EXTENSION_NAME-$VERSION.vsix"

Write-Host "========================================" -ForegroundColor Green
Write-Host "Cursor Doc Helper - Team Distribution" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green

# Function to check prerequisites
function Check-Prerequisites {
    Write-Host "`nChecking prerequisites..." -ForegroundColor Yellow
    
    # Check Node.js
    try {
        $nodeVersion = node --version
        Write-Host "✅ Node.js found: $nodeVersion" -ForegroundColor Green
    } catch {
        Write-Host "❌ Node.js is not installed" -ForegroundColor Red
        Write-Host "Please install Node.js from https://nodejs.org/"
        exit 1
    }
    
    # Check npm
    try {
        $npmVersion = npm --version
        Write-Host "✅ npm found: $npmVersion" -ForegroundColor Green
    } catch {
        Write-Host "❌ npm is not installed" -ForegroundColor Red
        exit 1
    }
    
    # Check/Install vsce
    try {
        vsce --version | Out-Null
        Write-Host "✅ vsce is installed" -ForegroundColor Green
    } catch {
        Write-Host "Installing vsce..." -ForegroundColor Yellow
        npm install -g vsce
    }
}

# Function to build the extension
function Build-Extension {
    Write-Host "`nBuilding extension..." -ForegroundColor Yellow
    
    # Clean previous builds
    if (Test-Path "out") { Remove-Item -Recurse -Force "out" }
    if (Test-Path "*.vsix") { Remove-Item -Force "*.vsix" }
    
    # Install dependencies
    Write-Host "Installing dependencies..."
    npm install
    
    # Compile TypeScript
    Write-Host "Compiling TypeScript..."
    npm run compile
    
    # Copy required files
    Write-Host "Copying templates and webview files..."
    New-Item -ItemType Directory -Force -Path "out\templates" | Out-Null
    New-Item -ItemType Directory -Force -Path "out\webview" | Out-Null
    
    Copy-Item "src\templates\*.hbs" "out\templates\" -ErrorAction SilentlyContinue
    Copy-Item "src\webview\*.js" "out\webview\" -ErrorAction SilentlyContinue
    Copy-Item "src\webview\*.css" "out\webview\" -ErrorAction SilentlyContinue
    
    # Package extension
    Write-Host "Creating VSIX package..."
    vsce package --no-yarn
    
    Write-Host "✅ Extension built successfully: $VSIX_FILE" -ForegroundColor Green
}

# Function to create distribution package
function Create-Distribution {
    Write-Host "`nCreating distribution package..." -ForegroundColor Yellow
    
    # Create distribution directory
    $DIST_DIR = "dist-$VERSION"
    if (Test-Path $DIST_DIR) { Remove-Item -Recurse -Force $DIST_DIR }
    New-Item -ItemType Directory -Force -Path $DIST_DIR | Out-Null
    
    # Copy files
    Copy-Item $VSIX_FILE "$DIST_DIR\"
    Copy-Item "INSTALL_GUIDE.md" "$DIST_DIR\"
    Copy-Item "README.md" "$DIST_DIR\"
    
    # Create installation script for Windows
    $installScript = @"
@echo off
echo Installing Cursor Documentation Generator...
code --install-extension $VSIX_FILE
if %ERRORLEVEL% EQU 0 (
    echo Installation successful!
    echo Please reload VS Code to use the extension.
) else (
    echo Installation failed. Please try manual installation.
)
pause
"@
    Set-Content -Path "$DIST_DIR\install.bat" -Value $installScript
    
    # Create quick start guide
    $quickStart = @"
# Quick Start Guide

## Installation
1. Double-click `install.bat`
2. Or open VS Code → Extensions → "..." → Install from VSIX

## First Use
1. Open VS Code
2. Click "Doc Generator" in sidebar
3. Enter GitHub repo URL
4. Select documentation types
5. Click "Generate Prompts" or "Execute Workflow"

## Need Help?
See INSTALL_GUIDE.md for detailed instructions.
"@
    Set-Content -Path "$DIST_DIR\QUICK_START.md" -Value $quickStart
    
    # Create ZIP archive
    Compress-Archive -Path $DIST_DIR -DestinationPath "$DIST_DIR.zip" -Force
    Write-Host "✅ Distribution package created: $DIST_DIR.zip" -ForegroundColor Green
}

# Function to display distribution instructions
function Show-DistributionInstructions {
    Write-Host "`n========================================" -ForegroundColor Green
    Write-Host "Distribution Complete!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "📦 Files created:"
    Write-Host "  • $VSIX_FILE - VS Code extension package"
    Write-Host "  • dist-$VERSION\ - Distribution folder"
    Write-Host "  • dist-$VERSION.zip - Distribution archive"
    Write-Host ""
    Write-Host "📤 Distribution methods:"
    Write-Host "  1. Email: Send dist-$VERSION.zip to team"
    Write-Host "  2. Teams/Slack: Upload $VSIX_FILE to team channel"
    Write-Host "  3. Network: Copy to \\shared\tools\"
    Write-Host "  4. SharePoint: Upload to team site"
    Write-Host ""
    Write-Host "💡 Team members can install by:"
    Write-Host "  • Running install.bat from distribution package"
    Write-Host "  • VS Code: Extensions → ... → Install from VSIX"
    Write-Host "  • Command: code --install-extension $VSIX_FILE"
}

# Main execution
try {
    Check-Prerequisites
    Build-Extension
    Create-Distribution
    Show-DistributionInstructions
    
    Write-Host "`nPress any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
} catch {
    Write-Host "Error: $_" -ForegroundColor Red
    Write-Host "`nPress any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}