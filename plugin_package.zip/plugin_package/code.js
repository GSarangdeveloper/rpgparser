"use strict";
// Figma-to-HTML/CSS Plugin
// This plugin converts Figma designs to HTML and CSS
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// Show the plugin UI
figma.showUI(__html__, { width: 550, height: 700 });
// Process Figma selection and convert to HTML/CSS
figma.ui.onmessage = (msg) => __awaiter(void 0, void 0, void 0, function* () {
    if (msg.type === 'generate-code') {
        const selection = figma.currentPage.selection;
        if (selection.length === 0) {
            figma.ui.postMessage({
                type: 'error',
                message: 'Please select at least one Figma element to convert.'
            });
            return;
        }
        try {
            // Get the options from the UI
            const options = msg.options || {
                includeAbsolutePositioning: true,
                useFlex: true,
                extractColors: true,
                extractFontStyles: true,
                extractImages: true,
                extractEffects: true,
                includePseudoClasses: false
            };
            // Process the selection and generate HTML/CSS
            const { html, css, previewHtml } = yield processSelection(selection, options);
            // Send the generated code back to the UI
            figma.ui.postMessage({
                type: 'code-generated',
                html,
                css,
                previewHtml
            });
        }
        catch (error) {
            figma.ui.postMessage({
                type: 'error',
                message: `Error generating code: ${error instanceof Error ? error.message : String(error)}`
            });
        }
    }
    else if (msg.type === 'cancel') {
        figma.closePlugin();
    }
    else if (msg.type === 'extract-all') {
        try {
            // Select all top-level frames in the current page
            const allFrames = figma.currentPage.children.filter(node => node.type === 'FRAME' &&
                node.parent && node.parent.type === 'PAGE');
            if (allFrames.length === 0) {
                figma.ui.postMessage({
                    type: 'error',
                    message: 'No frames found in the current page.'
                });
                return;
            }
            // Get the options from the UI
            const options = msg.options || {
                includeAbsolutePositioning: true,
                useFlex: true,
                extractColors: true,
                extractFontStyles: true,
                extractImages: true,
                extractEffects: true,
                includePseudoClasses: false
            };
            // Process all frames
            const { html, css, previewHtml } = yield processSelection(allFrames, options);
            // Send the generated code back to the UI
            figma.ui.postMessage({
                type: 'code-generated',
                html,
                css,
                previewHtml
            });
        }
        catch (error) {
            figma.ui.postMessage({
                type: 'error',
                message: `Error generating code: ${error instanceof Error ? error.message : String(error)}`
            });
        }
    }
});
// Main function to process selection and generate HTML/CSS
function processSelection(selection, options = {
    includeAbsolutePositioning: true,
    useFlex: true,
    extractColors: true,
    extractFontStyles: true,
    extractImages: true,
    extractEffects: true,
    includePseudoClasses: false
}) {
    return __awaiter(this, void 0, void 0, function* () {
        let htmlOutput = '';
        let cssOutput = '';
        // Collect all exportable assets (images)
        const assets = {};
        // Process selected nodes
        for (const node of selection) {
            const { html, css, nodeAssets } = yield processNode(node, 'root', 0, options);
            htmlOutput += html;
            cssOutput += css;
            // Merge assets
            Object.assign(assets, nodeAssets);
        }
        // CSS Reset and base styles for better consistency
        const cssReset = `
/* Reset and base styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: sans-serif;
}
`;
        // Create final CSS
        const finalCss = cssReset + cssOutput;
        // Create preview HTML that includes the CSS
        const previewHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Figma Design Preview</title>
  <style>
${finalCss}
  </style>
</head>
<body>
${htmlOutput}
</body>
</html>
`;
        return {
            html: htmlOutput,
            css: finalCss,
            previewHtml
        };
    });
}
// Process a single Figma node
function processNode(node, parentId = 'root', depth = 0, options = {
    includeAbsolutePositioning: true,
    useFlex: true,
    extractColors: true,
    extractFontStyles: true,
    extractImages: true,
    extractEffects: true,
    includePseudoClasses: false
}) {
    return __awaiter(this, void 0, void 0, function* () {
        // Skip nodes that are not visible
        if ('visible' in node && !node.visible) {
            return { html: '', css: '', nodeAssets: {} };
        }
        // Generate a unique ID for this node
        const nodeId = `node-${node.id.replace(/:/g, '-')}`;
        const className = node.name ? `${slugify(node.name)} ${nodeId}` : nodeId;
        let html = '';
        let css = '';
        const nodeAssets = {};
        // Process different node types
        if (node.type === 'FRAME' || node.type === 'GROUP' || node.type === 'RECTANGLE' ||
            node.type === 'ELLIPSE' || node.type === 'TEXT' || node.type === 'VECTOR' ||
            node.type === 'COMPONENT' || node.type === 'INSTANCE' || node.type === 'COMPONENT_SET' ||
            node.type === 'STAR' || node.type === 'POLYGON' || node.type === 'LINE') {
            // Determine HTML element type based on node type and name
            let elementType = determineHtmlElementType(node);
            // Start HTML element with appropriate attributes
            const nameAttr = node.name ? ` data-name="${node.name}"` : '';
            html += `<${elementType} id="${nodeId}" class="${className}"${nameAttr}>`;
            // Add text content for TEXT nodes
            if (node.type === 'TEXT') {
                html += node.characters;
            }
            // Process children recursively (if any)
            if ('children' in node) {
                for (const child of node.children) {
                    const childResult = yield processNode(child, nodeId, depth + 1, options);
                    html += childResult.html;
                    css += childResult.css;
                    Object.assign(nodeAssets, childResult.nodeAssets);
                }
            }
            // Close HTML element
            html += `</${elementType}>`;
            // Generate CSS based on options
            css += generateCSS(node, className, options);
            // Handle image fills if present and enabled in options
            if (options.extractImages && 'fills' in node && Array.isArray(node.fills)) {
                // Only process if the node has valid fills
                const imageFills = yield processImageFills(node, className);
                css += imageFills.css;
                Object.assign(nodeAssets, imageFills.assets);
            }
            // Generate hover states if enabled
            if (options.includePseudoClasses) {
                css += generatePseudoClasses(node, className);
            }
        }
        return { html, css, nodeAssets };
    });
}
// Helper function to generate slug from node name
function slugify(text) {
    return text
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
}
// Determine the most appropriate HTML element type based on the node
function determineHtmlElementType(node) {
    if (node.type === 'TEXT') {
        // Check for text content and styling to determine the element type
        if (node.name.toLowerCase().includes('button')) {
            return 'button';
        }
        if (node.name.toLowerCase().includes('heading') ||
            node.name.toLowerCase().includes('title') ||
            node.name.toLowerCase().includes('h1')) {
            return 'h1';
        }
        if (node.name.toLowerCase().includes('h2')) {
            return 'h2';
        }
        if (node.name.toLowerCase().includes('h3')) {
            return 'h3';
        }
        if (node.name.toLowerCase().includes('h4')) {
            return 'h4';
        }
        if (node.name.toLowerCase().includes('h5')) {
            return 'h5';
        }
        if (node.name.toLowerCase().includes('h6')) {
            return 'h6';
        }
        if (node.name.toLowerCase().includes('label')) {
            return 'label';
        }
        if (node.name.toLowerCase().includes('link') ||
            node.name.toLowerCase().includes('anchor')) {
            return 'a';
        }
        if (node.name.toLowerCase().includes('paragraph') ||
            node.name.toLowerCase().includes('body')) {
            return 'p';
        }
        // Default for text nodes
        return 'p';
    }
    // Check for common UI element patterns in the node name
    if (node.name.toLowerCase().includes('button')) {
        return 'button';
    }
    if (node.name.toLowerCase().includes('input') ||
        node.name.toLowerCase().includes('textfield')) {
        return 'input';
    }
    if (node.name.toLowerCase().includes('link')) {
        return 'a';
    }
    if (node.name.toLowerCase().includes('image') ||
        node.name.toLowerCase().includes('img') ||
        node.name.toLowerCase().includes('photo')) {
        return 'img';
    }
    if (node.name.toLowerCase().includes('header')) {
        return 'header';
    }
    if (node.name.toLowerCase().includes('footer')) {
        return 'footer';
    }
    if (node.name.toLowerCase().includes('section')) {
        return 'section';
    }
    if (node.name.toLowerCase().includes('article')) {
        return 'article';
    }
    if (node.name.toLowerCase().includes('main')) {
        return 'main';
    }
    if (node.name.toLowerCase().includes('nav') ||
        node.name.toLowerCase().includes('navbar') ||
        node.name.toLowerCase().includes('navigation')) {
        return 'nav';
    }
    if (node.name.toLowerCase().includes('ul') ||
        node.name.toLowerCase().includes('list')) {
        return 'ul';
    }
    if (node.name.toLowerCase().includes('li') ||
        node.name.toLowerCase().includes('item')) {
        if (node.parent &&
            (node.parent.name.toLowerCase().includes('ul') ||
                node.parent.name.toLowerCase().includes('list'))) {
            return 'li';
        }
    }
    if (node.name.toLowerCase().includes('form')) {
        return 'form';
    }
    // Default to div
    return 'div';
}
// Generate pseudo-classes like :hover
function generatePseudoClasses(node, className) {
    let css = '';
    // Add hover state with slight color adjustment for interactive elements
    if (node.name.toLowerCase().includes('button') ||
        node.name.toLowerCase().includes('link') ||
        node.type === 'INSTANCE' ||
        node.name.toLowerCase().includes('card')) {
        css += `.${className}:hover {\n`;
        css += `  opacity: 0.9;\n`;
        css += `  cursor: pointer;\n`;
        // Add a subtle transform for buttons
        if (node.name.toLowerCase().includes('button')) {
            css += `  transform: translateY(-1px);\n`;
            css += `  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n`;
        }
        css += `}\n\n`;
        // Add active state
        css += `.${className}:active {\n`;
        css += `  opacity: 0.8;\n`;
        if (node.name.toLowerCase().includes('button')) {
            css += `  transform: translateY(0px);\n`;
        }
        css += `}\n\n`;
    }
    return css;
}
// Generate CSS for a Figma node
function generateCSS(node, className, options = {
    includeAbsolutePositioning: true,
    useFlex: true,
    extractColors: true,
    extractFontStyles: true,
    extractImages: true,
    extractEffects: true,
    includePseudoClasses: false
}) {
    let css = `.${className} {\n`;
    // Sizing
    if ('width' in node && 'height' in node) {
        // Only use fixed dimensions if the container is not "auto" size
        const isAutoWidth = typeof node.width === 'string' &&
            (node.width === 'AUTO' || node.width === 'HUG');
        const isAutoHeight = typeof node.height === 'string' &&
            (node.height === 'AUTO' || node.height === 'HUG');
        if (!isAutoWidth && typeof node.width === 'number') {
            css += `  width: ${node.width}px;\n`;
        }
        if (!isAutoHeight && typeof node.height === 'number') {
            css += `  height: ${node.height}px;\n`;
        }
        // Add min/max dimensions for constraints
        if ('constraints' in node) {
            if (node.constraints && node.constraints.horizontal === 'SCALE') {
                css += `  width: 100%;\n`;
            }
            if (node.constraints && node.constraints.vertical === 'SCALE') {
                css += `  height: 100%;\n`;
            }
        }
    }
    // Position - only if absolute positioning is enabled
    if (options.includeAbsolutePositioning && 'x' in node && 'y' in node) {
        // Check if the parent has a layout mode, if so, don't use absolute positioning
        const hasLayoutParent = node.parent &&
            'layoutMode' in node.parent &&
            (node.parent.layoutMode === 'HORIZONTAL' || node.parent.layoutMode === 'VERTICAL');
        if (!hasLayoutParent || !options.useFlex) {
            css += `  position: absolute;\n`;
            css += `  left: ${node.x}px;\n`;
            css += `  top: ${node.y}px;\n`;
        }
    }
    // Background color (fill) - only if colors are enabled
    if (options.extractColors && 'fills' in node && Array.isArray(node.fills)) {
        const solidFill = node.fills.find(fill => fill.type === 'SOLID' && fill.visible !== false);
        if (solidFill && solidFill.type === 'SOLID') {
            const { r, g, b, a } = solidFill.color;
            const rgba = `rgba(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)}, ${a})`;
            css += `  background-color: ${rgba};\n`;
        }
        // Handle gradient fills
        const gradientFill = node.fills.find(fill => fill.type === 'GRADIENT_LINEAR' && fill.visible !== false);
        if (gradientFill && gradientFill.type === 'GRADIENT_LINEAR') {
            const { gradientStops, gradientTransform } = gradientFill;
            let gradientColors = '';
            gradientStops.forEach((stop, index) => {
                const { r, g, b, a } = stop.color;
                const rgba = `rgba(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)}, ${a})`;
                gradientColors += `${rgba} ${Math.round(stop.position * 100)}%`;
                if (index < gradientStops.length - 1) {
                    gradientColors += ', ';
                }
            });
            // Calculate angle from transform matrix (simplified)
            let angle = 90; // Default to top-to-bottom
            if (gradientTransform && gradientTransform.length === 6) {
                // This is a simplified calculation of the angle - not perfect, but usually works
                const [a, b, c, d, e, f] = gradientTransform;
                angle = Math.round(Math.atan2(b, a) * (180 / Math.PI));
                if (angle < 0)
                    angle += 360;
            }
            css += `  background: linear-gradient(${angle}deg, ${gradientColors});\n`;
        }
    }
    // Borders/strokes - only if colors are enabled
    if (options.extractColors && 'strokes' in node && Array.isArray(node.strokes) && node.strokes.length > 0) {
        const stroke = node.strokes[0];
        if (stroke.type === 'SOLID') {
            const { r, g, b, a } = stroke.color;
            const rgba = `rgba(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)}, ${a})`;
            if ('strokeWeight' in node) {
                // Check for individual borders or uniform border
                if ('strokeAlign' in node && node.strokeAlign === 'INSIDE') {
                    css += `  box-sizing: border-box;\n`;
                }
                // Check for different border weights on each side
                if ('strokeTopWeight' in node && 'strokeRightWeight' in node &&
                    'strokeBottomWeight' in node && 'strokeLeftWeight' in node &&
                    (node.strokeTopWeight !== node.strokeRightWeight ||
                        node.strokeRightWeight !== node.strokeBottomWeight ||
                        node.strokeBottomWeight !== node.strokeLeftWeight)) {
                    css += `  border-top: ${node.strokeTopWeight}px solid ${rgba};\n`;
                    css += `  border-right: ${node.strokeRightWeight}px solid ${rgba};\n`;
                    css += `  border-bottom: ${node.strokeBottomWeight}px solid ${rgba};\n`;
                    css += `  border-left: ${node.strokeLeftWeight}px solid ${rgba};\n`;
                }
                else {
                    const weight = typeof node.strokeWeight === 'number' ? node.strokeWeight : 1;
                    css += `  border: ${weight}px solid ${rgba};\n`;
                }
            }
            // Check for border styles
            if ('strokeDashes' in node && node.strokeDashes &&
                Array.isArray(node.strokeDashes) && node.strokeDashes.length > 0) {
                const dashPattern = node.strokeDashes.join(', ');
                css += `  border-style: dashed;\n`;
                css += `  border-dash: ${dashPattern};\n`;
            }
        }
    }
    // Corner radius
    if ('cornerRadius' in node) {
        if (node.cornerRadius !== undefined &&
            typeof node.cornerRadius === 'number' &&
            node.cornerRadius > 0) {
            css += `  border-radius: ${node.cornerRadius}px;\n`;
        }
        else if ('topLeftRadius' in node && 'topRightRadius' in node &&
            'bottomRightRadius' in node && 'bottomLeftRadius' in node) {
            const { topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius } = node;
            // Check if all corners have the same radius
            if (topLeftRadius === topRightRadius && topRightRadius === bottomRightRadius &&
                bottomRightRadius === bottomLeftRadius && topLeftRadius > 0) {
                css += `  border-radius: ${topLeftRadius}px;\n`;
            }
            // Different radii for each corner
            else if (topLeftRadius > 0 || topRightRadius > 0 || bottomRightRadius > 0 || bottomLeftRadius > 0) {
                css += `  border-radius: ${topLeftRadius}px ${topRightRadius}px ${bottomRightRadius}px ${bottomLeftRadius}px;\n`;
            }
        }
    }
    // Effects (shadows, blurs) - only if effects are enabled
    if (options.extractEffects && 'effects' in node && Array.isArray(node.effects)) {
        // Process drop shadows
        const dropShadows = node.effects.filter(effect => effect.type === 'DROP_SHADOW' && effect.visible !== false);
        if (dropShadows.length > 0) {
            if (dropShadows.length === 1) {
                const shadow = dropShadows[0];
                const { color, offset, radius, spread } = shadow;
                const rgba = `rgba(${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}, ${color.a})`;
                const spreadValue = spread || 0;
                css += `  box-shadow: ${offset.x}px ${offset.y}px ${radius}px ${spreadValue}px ${rgba};\n`;
            }
            else {
                // Multiple shadows
                css += `  box-shadow: `;
                dropShadows.forEach((shadow, index) => {
                    const { color, offset, radius, spread } = shadow;
                    const rgba = `rgba(${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}, ${color.a})`;
                    const spreadValue = spread || 0;
                    css += `${offset.x}px ${offset.y}px ${radius}px ${spreadValue}px ${rgba}`;
                    if (index < dropShadows.length - 1) {
                        css += ', ';
                    }
                });
                css += ';\n';
            }
        }
        // Process inner shadows
        const innerShadows = node.effects.filter(effect => effect.type === 'INNER_SHADOW' && effect.visible !== false);
        if (innerShadows.length > 0) {
            if (dropShadows.length > 0) {
                // We already have a box-shadow, so we need to combine them
                css = css.replace('box-shadow: ', 'box-shadow: inset ');
                css = css.replace(';\n', ', ');
                innerShadows.forEach((shadow, index) => {
                    const { color, offset, radius, spread } = shadow;
                    const rgba = `rgba(${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}, ${color.a})`;
                    const spreadValue = spread || 0;
                    css += `inset ${offset.x}px ${offset.y}px ${radius}px ${spreadValue}px ${rgba}`;
                    if (index < innerShadows.length - 1) {
                        css += ', ';
                    }
                });
                css += ';\n';
            }
            else {
                // No existing box-shadow
                css += `  box-shadow: `;
                innerShadows.forEach((shadow, index) => {
                    const { color, offset, radius, spread } = shadow;
                    const rgba = `rgba(${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}, ${color.a})`;
                    const spreadValue = spread || 0;
                    css += `inset ${offset.x}px ${offset.y}px ${radius}px ${spreadValue}px ${rgba}`;
                    if (index < innerShadows.length - 1) {
                        css += ', ';
                    }
                });
                css += ';\n';
            }
        }
        // Process blur effects
        const blurEffects = node.effects.filter(effect => effect.type === 'LAYER_BLUR' && effect.visible !== false);
        if (blurEffects.length > 0) {
            const blur = blurEffects[0];
            css += `  filter: blur(${blur.radius}px);\n`;
        }
    }
    // Opacity
    if ('opacity' in node && node.opacity < 1) {
        css += `  opacity: ${node.opacity};\n`;
    }
    // Text styling - only if font styles are enabled
    if (options.extractFontStyles && node.type === 'TEXT') {
        if (node.fontSize && typeof node.fontSize === 'number') {
            css += `  font-size: ${node.fontSize}px;\n`;
        }
        if (node.fontName && typeof node.fontName === 'object' && 'family' in node.fontName) {
            const fontFamily = node.fontName.family;
            const genericFontFamily = determineGenericFontFamily(fontFamily);
            css += `  font-family: ${fontFamily}, ${genericFontFamily};\n`;
        }
        if (node.fontWeight && typeof node.fontWeight === 'number') {
            css += `  font-weight: ${node.fontWeight};\n`;
        }
        // Line height
        if ('lineHeight' in node && node.lineHeight && typeof node.lineHeight === 'object') {
            // Type guard for the lineHeight object
            const lineHeight = node.lineHeight;
            if ('unit' in lineHeight && 'value' in lineHeight) {
                if (lineHeight.unit === 'PIXELS') {
                    css += `  line-height: ${lineHeight.value}px;\n`;
                }
                else if (lineHeight.unit === 'PERCENT') {
                    css += `  line-height: ${lineHeight.value / 100};\n`;
                }
            }
        }
        // Letter spacing
        if ('letterSpacing' in node && node.letterSpacing && typeof node.letterSpacing === 'object') {
            // Type guard for the letterSpacing object
            const letterSpacing = node.letterSpacing;
            if ('unit' in letterSpacing && 'value' in letterSpacing) {
                if (letterSpacing.unit === 'PIXELS') {
                    css += `  letter-spacing: ${letterSpacing.value}px;\n`;
                }
                else if (letterSpacing.unit === 'PERCENT') {
                    const emValue = letterSpacing.value / 100;
                    css += `  letter-spacing: ${emValue}em;\n`;
                }
            }
        }
        // Text decoration
        if ('textDecoration' in node) {
            if (node.textDecoration === 'UNDERLINE') {
                css += `  text-decoration: underline;\n`;
            }
            else if (node.textDecoration === 'STRIKETHROUGH') {
                css += `  text-decoration: line-through;\n`;
            }
        }
        // Text case
        if ('textCase' in node) {
            if (node.textCase === 'UPPER') {
                css += `  text-transform: uppercase;\n`;
            }
            else if (node.textCase === 'LOWER') {
                css += `  text-transform: lowercase;\n`;
            }
            else if (node.textCase === 'TITLE') {
                css += `  text-transform: capitalize;\n`;
            }
        }
        // Text color - only if colors are enabled
        if (options.extractColors && node.fills && Array.isArray(node.fills)) {
            const textFill = node.fills.find(fill => fill.type === 'SOLID' && fill.visible !== false);
            if (textFill && textFill.type === 'SOLID') {
                const { r, g, b, a } = textFill.color;
                const rgba = `rgba(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)}, ${a})`;
                css += `  color: ${rgba};\n`;
            }
        }
        // Text alignment
        if (node.textAlignHorizontal) {
            css += `  text-align: ${node.textAlignHorizontal.toLowerCase()};\n`;
        }
        // Vertical alignment
        if (node.textAlignVertical) {
            switch (node.textAlignVertical) {
                case 'TOP':
                    css += `  vertical-align: top;\n`;
                    break;
                case 'CENTER':
                    css += `  vertical-align: middle;\n`;
                    break;
                case 'BOTTOM':
                    css += `  vertical-align: bottom;\n`;
                    break;
            }
        }
    }
    // Auto Layout (Flexbox) - only if flex is enabled
    if (options.useFlex && 'layoutMode' in node) {
        if (node.layoutMode === 'HORIZONTAL') {
            css += `  display: flex;\n`;
            css += `  flex-direction: row;\n`;
        }
        else if (node.layoutMode === 'VERTICAL') {
            css += `  display: flex;\n`;
            css += `  flex-direction: column;\n`;
        }
        // Spacing between items
        if ('itemSpacing' in node) {
            css += `  gap: ${node.itemSpacing}px;\n`;
        }
        // Padding
        if ('paddingLeft' in node && 'paddingTop' in node &&
            'paddingRight' in node && 'paddingBottom' in node) {
            // Check if all paddings are equal
            if (node.paddingTop === node.paddingRight &&
                node.paddingRight === node.paddingBottom &&
                node.paddingBottom === node.paddingLeft) {
                css += `  padding: ${node.paddingTop}px;\n`;
            }
            // Check if vertical paddings are equal and horizontal paddings are equal
            else if (node.paddingTop === node.paddingBottom &&
                node.paddingLeft === node.paddingRight) {
                css += `  padding: ${node.paddingTop}px ${node.paddingRight}px;\n`;
            }
            // All paddings are different
            else {
                css += `  padding: ${node.paddingTop}px ${node.paddingRight}px ${node.paddingBottom}px ${node.paddingLeft}px;\n`;
            }
        }
        // Alignment
        if ('primaryAxisAlignItems' in node) {
            switch (node.primaryAxisAlignItems) {
                case 'MIN':
                    css += `  justify-content: flex-start;\n`;
                    break;
                case 'CENTER':
                    css += `  justify-content: center;\n`;
                    break;
                case 'MAX':
                    css += `  justify-content: flex-end;\n`;
                    break;
                case 'SPACE_BETWEEN':
                    css += `  justify-content: space-between;\n`;
                    break;
            }
        }
        if ('counterAxisAlignItems' in node) {
            switch (node.counterAxisAlignItems) {
                case 'MIN':
                    css += `  align-items: flex-start;\n`;
                    break;
                case 'CENTER':
                    css += `  align-items: center;\n`;
                    break;
                case 'MAX':
                    css += `  align-items: flex-end;\n`;
                    break;
            }
        }
        // Flex properties for children
        if ('layoutSizingHorizontal' in node) {
            switch (node.layoutSizingHorizontal) {
                case 'FILL':
                    css += `  width: 100%;\n`;
                    break;
                case 'HUG':
                    css += `  width: fit-content;\n`;
                    break;
            }
        }
        if ('layoutSizingVertical' in node) {
            switch (node.layoutSizingVertical) {
                case 'FILL':
                    css += `  height: 100%;\n`;
                    break;
                case 'HUG':
                    css += `  height: fit-content;\n`;
                    break;
            }
        }
        // Handle flex grow/shrink
        if ('layoutGrow' in node && node.layoutGrow !== 0) {
            css += `  flex-grow: ${node.layoutGrow};\n`;
        }
        if ('layoutAlign' in node && node.layoutAlign === 'STRETCH') {
            css += `  align-self: stretch;\n`;
        }
    }
    // Overflow
    if ('clipsContent' in node && node.clipsContent) {
        css += `  overflow: hidden;\n`;
    }
    // For buttons and other interactive elements
    if (node.type === 'INSTANCE' || node.name.toLowerCase().includes('button')) {
        css += `  cursor: pointer;\n`;
    }
    // Background blend mode if present
    if ('blendMode' in node && node.blendMode !== 'NORMAL') {
        const blendMode = node.blendMode.toLowerCase().replace('_', '-');
        css += `  mix-blend-mode: ${blendMode};\n`;
    }
    // For images
    if (node.type === 'RECTANGLE' && node.name.toLowerCase().includes('image')) {
        css += `  object-fit: cover;\n`;
    }
    // Element-specific styles based on name
    if (node.name.toLowerCase().includes('button')) {
        css += `  cursor: pointer;\n`;
        css += `  user-select: none;\n`;
    }
    else if (node.name.toLowerCase().includes('input')) {
        css += `  outline: none;\n`;
    }
    // Add transition for any components that might be interactive
    if (node.type === 'INSTANCE' ||
        node.name.toLowerCase().includes('button') ||
        node.name.toLowerCase().includes('link') ||
        node.name.toLowerCase().includes('card')) {
        css += `  transition: all 0.2s ease-in-out;\n`;
    }
    css += '}\n\n';
    return css;
}
// Helper function to determine the generic font family
function determineGenericFontFamily(fontFamily) {
    const fontLower = fontFamily.toLowerCase();
    // Check for common serif fonts
    if (fontLower.includes('times') || fontLower.includes('georgia') ||
        fontLower.includes('garamond') || fontLower.includes('bodoni') ||
        fontLower.includes('didot') || fontLower.includes('serif')) {
        return 'serif';
    }
    // Check for common monospace fonts
    if (fontLower.includes('mono') || fontLower.includes('courier') ||
        fontLower.includes('console') || fontLower.includes('code') ||
        fontLower.includes('fixed')) {
        return 'monospace';
    }
    // Check for common display/decorative fonts
    if (fontLower.includes('comic') || fontLower.includes('brush') ||
        fontLower.includes('script') || fontLower.includes('display')) {
        return 'cursive';
    }
    // Default to sans-serif
    return 'sans-serif';
}
// Process image fills in nodes
function processImageFills(node, className) {
    return __awaiter(this, void 0, void 0, function* () {
        let css = '';
        const assets = {};
        if (!node.fills)
            return { css, assets };
        // Find image fills
        const imageFills = node.fills.filter(fill => fill.type === 'IMAGE' && fill.visible !== false);
        // If node is configured as an image element or named as an image
        const isImageElement = node.type === 'RECTANGLE' &&
            (node.name.toLowerCase().includes('image') ||
                node.name.toLowerCase().includes('img') ||
                node.name.toLowerCase().includes('photo') ||
                node.name.toLowerCase().includes('pic'));
        for (let i = 0; i < imageFills.length; i++) {
            const fill = imageFills[i];
            if (!fill.imageHash)
                continue;
            // Get image from Figma
            try {
                const image = yield figma.getImageByHash(fill.imageHash);
                if (!image)
                    continue;
                const bytes = yield image.getBytesAsync();
                const imageFileName = `image-${className.split(' ')[0]}-${i}.png`;
                // Store the image bytes for export
                assets[imageFileName] = bytes;
                // If this is an image element, use <img> src instead of background
                if (isImageElement) {
                    // The img tag will be created separately, but we need to add the data-src to the CSS
                    css += `.${className} {\n`;
                    css += `  content: attr(data-src);\n`;
                    css += `  object-fit: cover;\n`;
                    css += `  width: 100%;\n`;
                    css += `  height: 100%;\n`;
                    css += '}\n\n';
                }
                else {
                    // Add CSS for background image
                    css += `.${className} {\n`;
                    // Handle different image scalings
                    if (fill.scaleMode === 'FILL') {
                        css += `  background-image: url('images/${imageFileName}');\n`;
                        css += `  background-size: cover;\n`;
                        css += `  background-position: center;\n`;
                    }
                    else if (fill.scaleMode === 'FIT') {
                        css += `  background-image: url('images/${imageFileName}');\n`;
                        css += `  background-size: contain;\n`;
                        css += `  background-repeat: no-repeat;\n`;
                        css += `  background-position: center;\n`;
                    }
                    else if (fill.scaleMode === 'TILE') {
                        css += `  background-image: url('images/${imageFileName}');\n`;
                        css += `  background-repeat: repeat;\n`;
                        css += `  background-size: auto;\n`;
                    }
                    else {
                        css += `  background-image: url('images/${imageFileName}');\n`;
                        css += `  background-size: 100% 100%;\n`;
                    }
                    // Handle image blend mode if present
                    if (fill.blendMode && fill.blendMode !== 'NORMAL') {
                        const blendMode = String(fill.blendMode).toLowerCase().replace('_', '-');
                        css += `  background-blend-mode: ${blendMode};\n`;
                    }
                    css += '}\n\n';
                }
            }
            catch (error) {
                console.error('Error processing image fill:', error);
            }
        }
        return { css, assets };
    });
}
