# UI Spark - Complete Workflow Documentation

## Workflow Overview

UI Spark follows a 3-step workflow to transform designs into Angular code:

1. **Step 1**: Analyze PNG image → Generate UI description & user stories
2. **Step 2**: Load Figma design → Parse structure and measurements
3. **Step 3**: Generate Angular code → Combine all inputs with AI

## Detailed Workflow Steps

### Step 1: Image Analysis

#### 1a. Generate UI Description
**Purpose**: Extract structured information from visual design

**Prompt Used**:
```
Analyze this UI design image and provide a structured description including:
1. Overall layout structure (header, main content, sidebar, footer, etc.)
2. UI components present (buttons, forms, cards, navigation, etc.)
3. Color scheme and typography observations
4. Spacing and alignment patterns
5. Any interactive elements or states visible

Format your response as a detailed, structured description that can be used to generate code.
```

**Output**: Detailed textual description of UI elements and structure

#### 1b. Generate User Stories
**Purpose**: Understand functional requirements from UI

**Prompt Used**:
```
Based on this UI description, generate user stories that explain the functional purpose of each UI element:

UI Description:
{ui_description}

Generate 3-5 user stories in the format:
"As a [user type], I want to [action] so that [benefit]"

Focus on the key interactive elements and their purposes.
```

**Output**: Functional user stories for the UI

### Step 2: Figma Design Loading

#### 2a. Load Figma File
**Process**:
1. Extract file key from Figma URL
2. Use LangChain Figma Loader with access token
3. Fetch design data via Figma API

#### 2b. Parse Figma Data
**Extracted Information**:
- Element hierarchy and structure
- Exact measurements (width, height, padding, gaps)
- Layout properties (flexbox, grid, constraints)
- Colors, fonts, and effects
- Component definitions and instances
- Responsive constraints

**Parser Output Structure**:
```json
{
  "name": "Design Name",
  "description": "Structured analysis",
  "elements": [
    {
      "id": "element_id",
      "type": "FRAME",
      "bounds": {"width": 340, "height": 400},
      "layout": {
        "direction": "column",
        "gap": 16,
        "padding": {"top": 32, "right": 32, "bottom": 28, "left": 32}
      },
      "fills": [{"color": "rgba(247, 248, 243, 1)"}],
      "cornerRadius": 18
    }
  ]
}
```

### Step 3: Code Generation

#### 3a. Initial Code Generation
**Combined Prompt Structure**:
```
Generate Angular component code based on:

1. UI DESCRIPTION (from PNG analysis):
{ui_description}

2. USER STORIES (from PNG analysis):
{user_stories}

3. FIGMA DESIGN DATA:
Design Name: {parsed_data.name}
{parsed_data.description}

KEY ELEMENTS:
{elements_summary}

PRECISE FIGMA VALUES TO USE:
{precise_values}

4. REFERENCE IMAGE: Attached PNG showing the visual design

5. CUSTOM CSS TO USE: (if provided)
{custom_css}

6. ADDITIONAL REQUIREMENTS: (if provided)
{additional_prompt}

Requirements:
- Use Angular 16+ syntax with standalone components
- Match the PNG image visual design EXACTLY
- Use precise Figma measurements
- Implement all user story functionality
- Make fully responsive
```

#### 3b. Code Refinement (Optional)
**Refinement Prompt**:
```
Please refine the following Angular code to improve:
1. Visual accuracy - ensure it matches the attached image EXACTLY
2. Responsive behavior - improve mobile/tablet/desktop layouts
3. Code quality - fix any issues, improve structure
4. Styling precision - match exact colors, spacing, typography from Figma

[Initial code provided]

Requirements:
- Match the visual design in the attached image EXACTLY
- Ensure all Figma measurements are applied correctly
- Improve responsive behavior with proper breakpoints
```

## Configuration Options

### Sidebar Settings
1. **Framework Selection**: Currently Angular (React/Vue coming soon)
2. **Code Refinement**: Enable/disable 2-pass generation
3. **Custom CSS**: Provide existing styles or framework classes
4. **Additional Instructions**: Specific requirements for generation

## Output Artifacts

### Generated Files
1. **component.ts** - Angular TypeScript component
2. **template.html** - Component HTML template
3. **styles.scss** - SCSS styles with Figma measurements

### Additional Artifacts
1. **UI Description** - Text analysis of the image
2. **User Stories** - Functional requirements
3. **Parsed Figma Data** - Structured design data (JSON)
4. **Preview HTML** - Live preview of generated UI

## Export Options

1. **Copy All Code** - One-click clipboard copy
2. **Download ZIP** - All files with README
3. **Download Artifacts** - Complete documentation

## Best Practices

1. **Image Quality**: Use high-resolution PNG/JPG for better analysis
2. **Figma Preparation**: Ensure Figma design uses Auto Layout
3. **Custom CSS**: Provide design system classes for consistency
4. **Instructions**: Be specific about technical requirements
5. **Refinement**: Enable for complex designs requiring precision

## Error Handling

1. **Missing API Keys**: Configure in .env file
2. **Figma Access**: Ensure token has file read permissions
3. **Generation Timeout**: Increase timeout for complex designs
4. **Preview Issues**: Check SCSS syntax if preview fails