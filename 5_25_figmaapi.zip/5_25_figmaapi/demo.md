# UI Spark - Demo Guide

## Demo Overview

This guide walks through a complete demonstration of UI Spark, showing how to transform a Figma design into production-ready Angular code.

## Prerequisites

1. **API Keys configured**:
   - OpenAI API key with GPT-4 access
   - Figma access token

2. **Sample Resources**:
   - UI design PNG/JPG file
   - Figma design URL
   - (Optional) Custom CSS framework

## Demo Script

### 1. Introduction (1 minute)

"Welcome to UI Spark - an AI-powered UI development accelerator that transforms your designs into production-ready Angular code in minutes."

**Key Points**:
- Combines GPT-4 vision with Figma integration
- Generates complete Angular components
- Preserves exact design specifications
- Includes responsive behavior

### 2. Setup & Configuration (30 seconds)

**Show**:
- Streamlit interface
- Configuration sidebar
- Enable code refinement
- Custom CSS area (optional)

### 3. Step 1: Image Analysis (2 minutes)

**Actions**:
1. Upload a UI design PNG (e.g., order summary card)
2. Click "Generate UI Description"
   - Show the AI analyzing the image
   - Display generated description
3. Click "Generate User Stories"
   - Show functional requirements extracted
   - Highlight user-centric approach

**Sample Output**:
```
UI Description:
"The design shows an order summary card with a light green background (#f7f8f3). 
The card has rounded corners (18px) and contains:
- Title 'Order summary' in 20px bold text
- Line items for Subtotal, Shipping, and Tax in 14px regular text
- Total row with emphasized styling
- Green CTA button with arrow icon..."

User Stories:
"As a customer, I want to see my order breakdown so that I understand the total cost"
"As a customer, I want to proceed to payment so that I can complete my purchase"
```

### 4. Step 2: Figma Integration (1 minute)

**Actions**:
1. Paste Figma URL
2. Click "Load & Parse Figma"
3. Show parsed data summary

**Highlight**:
- Exact measurements extracted
- Component hierarchy preserved
- Responsive constraints captured

### 5. Step 3: Code Generation (2 minutes)

**Actions**:
1. Click "Generate Angular Code"
2. Show progress indicators:
   - Initial generation
   - Refinement pass
3. Display generated code tabs

**Showcase**:
- TypeScript component with proper types
- HTML template with Angular directives
- SCSS with exact Figma measurements
- Live preview matching original design

### 6. Results Review (2 minutes)

**Component.ts**:
```typescript
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-order-summary',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order-summary.component.html',
  styleUrls: ['./order-summary.component.scss']
})
export class OrderSummaryComponent {
  subtotal = 65.00;
  shipping = 5.00;
  tax = 8.40;
  
  get total(): number {
    return this.subtotal + this.shipping + this.tax;
  }
  
  onContinue(): void {
    // Navigate to payment
  }
}
```

**Highlight**:
- Pixel-perfect styling
- Responsive breakpoints
- Figma measurements preserved
- Clean, production-ready code

### 7. Export Options (1 minute)

**Demonstrate**:
1. Copy to clipboard functionality
2. Download ZIP with all files
3. Show artifacts included

### 8. Advanced Features (1 minute)

**Show**:
- Custom CSS integration
- Additional instructions usage
- Debug information panel
- Multiple component generation

## Demo Tips

### DO:
- Use high-quality design images
- Prepare Figma file with Auto Layout
- Show the live preview
- Emphasize time savings
- Highlight accuracy of measurements

### DON'T:
- Rush through generation
- Skip showing the parsed data
- Forget to show responsive behavior
- Ignore the refinement feature

## Common Questions & Answers

**Q: How accurate is the code generation?**
A: With refinement enabled, typically 90-95% accurate to the original design.

**Q: Can it handle complex layouts?**
A: Yes, it preserves Figma's Auto Layout as CSS Flexbox/Grid.

**Q: What about custom design systems?**
A: Provide your CSS classes in the Custom CSS field.

**Q: How long does generation take?**
A: 2-5 minutes for initial, 4-10 minutes with refinement.

**Q: Can it generate multiple components?**
A: Yes, it identifies and generates reusable components from Figma.

## Troubleshooting

1. **Slow generation**: Normal for complex designs
2. **Preview issues**: Check browser console
3. **API errors**: Verify keys and quotas
4. **Figma access**: Check token permissions

## Demo Variations

### Quick Demo (3 minutes)
- Skip user stories
- Use pre-loaded Figma URL
- Show only final results

### Technical Demo (10 minutes)
- Show all intermediate outputs
- Explain prompts used
- Debug panel walkthrough
- Multiple examples

### Sales Demo (5 minutes)
- Focus on time savings
- Show before/after
- Emphasize accuracy
- ROI discussion