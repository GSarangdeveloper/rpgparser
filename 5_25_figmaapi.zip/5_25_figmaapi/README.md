# UI Spark ⚡ - AI-Powered UI Development Accelerator

Transform UI designs into Angular code using GPT-4 vision capabilities and Figma integration.

## Features

- 🖼️ **Image Analysis**: Upload UI screenshots and get them analyzed by GPT-4 vision
- 🎨 **Figma Integration**: Direct integration with Figma API using LangChain loader
- 🚀 **Angular Code Generation**: Generate clean Angular components with TypeScript, HTML, and SCSS
- 👁️ **Live Preview**: See your generated UI in real-time
- 📝 **User Story Generation**: Automatically create user stories from UI descriptions
- 💾 **Export Options**: Download generated code files individually or copy all at once

## Setup

### Prerequisites

- Python 3.8+
- OpenAI API key with GPT-4 access
- Figma access token (optional, for Figma integration)

### Installation

1. Clone the repository:
```bash
cd 5_25_figmaapi
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Create a `.env` file based on `.env.example`:
```bash
cp .env.example .env
```

4. Add your API keys to `.env`:
```
OPENAI_API_KEY=your_openai_api_key_here
FIGMA_ACCESS_TOKEN=your_figma_access_token_here
```

### Running the Application

```bash
streamlit run app.py
```

The application will open in your default browser at `http://localhost:8501`

## Usage

1. **Choose Input Type**: Select between uploading an image or providing a Figma URL
2. **Configure Options**: 
   - Enable/disable user story generation
   - Add custom CSS if you have existing styles
3. **Generate Code**: Click the "Generate Code" button
4. **Review Output**: 
   - Preview the generated UI
   - View and download individual code files
   - Copy all code at once

## Project Structure

```
designxtgen/
├── components/
│   ├── image_analyzer.py    # GPT-4 vision integration
│   └── figma_loader.py      # Figma API integration
├── parsers/
│   └── figma_parser.py      # Figma data parsing
├── generators/
│   └── angular_generator.py # Angular code generation
└── utils/
    └── preview.py           # HTML preview generation
```

## API Keys

### OpenAI API Key
Get your API key from [OpenAI Platform](https://platform.openai.com/api-keys)

### Figma Access Token
1. Go to [Figma Account Settings](https://www.figma.com/settings)
2. Under "Personal Access Tokens", create a new token
3. Copy and add to your `.env` file

## License

MIT