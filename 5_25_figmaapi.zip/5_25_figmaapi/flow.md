# UI Spark - System Flow Documentation

## Overview
UI Spark is an AI-powered UI development accelerator that transforms design mockups and Figma designs into production-ready Angular code using GPT-4 vision capabilities and the LangChain Figma loader.

## System Architecture Flow

```mermaid
flowchart TB
    subgraph Input ["🎨 Design Input"]
        PNG[PNG/JPG Image]
        FIGMA[Figma Design URL]
    end
    
    subgraph Analysis ["🔍 Analysis Phase"]
        IMG_ANALYSIS[GPT-4 Vision Analysis]
        UI_DESC[UI Description Generation]
        USER_STORIES[User Stories Generation]
        FIGMA_LOADER[LangChain Figma Loader]
        FIGMA_PARSER[Figma Data Parser]
    end
    
    subgraph Processing ["⚙️ Processing Phase"]
        CONTEXT[Context Builder]
        PROMPT[Prompt Engineering]
        CODE_GEN[GPT-4 Code Generation]
        REFINE[Code Refinement]
    end
    
    subgraph Output ["📦 Output"]
        TS[TypeScript Component]
        HTML[HTML Template]
        SCSS[SCSS Styles]
        PREVIEW[Live Preview]
        ARTIFACTS[Artifacts Export]
    end
    
    PNG --> IMG_ANALYSIS
    IMG_ANALYSIS --> UI_DESC
    UI_DESC --> USER_STORIES
    
    FIGMA --> FIGMA_LOADER
    FIGMA_LOADER --> FIGMA_PARSER
    
    UI_DESC --> CONTEXT
    USER_STORIES --> CONTEXT
    FIGMA_PARSER --> CONTEXT
    
    CONTEXT --> PROMPT
    PROMPT --> CODE_GEN
    CODE_GEN --> REFINE
    
    REFINE --> TS
    REFINE --> HTML
    REFINE --> SCSS
    
    HTML --> PREVIEW
    SCSS --> PREVIEW
    
    TS --> ARTIFACTS
    HTML --> ARTIFACTS
    SCSS --> ARTIFACTS
```

## Detailed Process Flow

### Step 1: Image Analysis (1a & 1b)
1. **User uploads PNG/JPG** → Stored in session state
2. **GPT-4 Vision analyzes image** → Generates structured UI description
3. **UI Description processed** → Generates functional user stories

### Step 2: Figma Integration
1. **User provides Figma URL** → Validated and parsed
2. **LangChain Figma Loader** → Fetches design data via API
3. **Figma Parser** → Transforms raw data into structured format
   - Extracts exact measurements
   - Identifies components and instances
   - Maps layout properties to CSS
   - Preserves responsive constraints

### Step 3: Code Generation
1. **Context Assembly** → Combines all inputs:
   - UI Description
   - User Stories
   - Parsed Figma Data
   - Original PNG image
   - Custom CSS (optional)
   - Additional instructions (optional)

2. **Initial Generation** → GPT-4 processes combined context
3. **Refinement Pass** (optional) → Improves accuracy against visual design
4. **Output Processing** → Validates and formats generated code

## Data Flow

### Input Data Structure
```json
{
  "image_bytes": "base64_encoded_png",
  "ui_description": "Detailed textual description",
  "user_stories": ["Story 1", "Story 2", ...],
  "figma_data": {
    "elements": [...],
    "styles": {...},
    "components": [...]
  },
  "custom_css": "optional CSS",
  "additional_prompt": "optional instructions"
}
```

### Output Data Structure
```json
{
  "typescript": "Angular component code",
  "html": "Template markup",
  "scss": "Styles with Figma measurements",
  "preview_html": "Rendered preview",
  "artifacts": {
    "ui_description": "...",
    "user_stories": "...",
    "parsed_figma_data": {...}
  }
}
```

## Key Technologies

1. **Frontend**: Streamlit (Python)
2. **AI Models**: GPT-4 with vision capabilities
3. **Design Integration**: LangChain Figma Loader
4. **Code Generation**: Custom prompt engineering
5. **Preview**: Real-time HTML/CSS rendering

## Error Handling Flow

1. **API Key Validation** → Check on startup
2. **Image Processing** → Fallback to basic analysis
3. **Figma Loading** → Retry with error messages
4. **Code Generation** → Timeout and validation checks
5. **Preview Generation** → Fallback to simple preview

## Performance Optimizations

1. **Caching**: Session state for all intermediate results
2. **Parallel Processing**: Multiple API calls when possible
3. **Incremental Updates**: UI updates during long operations
4. **Token Management**: Configurable max tokens (32K)
5. **Timeout Handling**: 5-minute timeout for API calls