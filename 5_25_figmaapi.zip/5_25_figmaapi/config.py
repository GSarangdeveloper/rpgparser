import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    FIGMA_ACCESS_TOKEN = os.getenv("FIGMA_ACCESS_TOKEN")
    GPT_MODEL = "gpt-4.1"
    MAX_TOKENS = 32768  # Maximum supported completion tokens for this model
    TEMPERATURE = 0.7
    REQUEST_TIMEOUT = 300  # 5 minutes timeout
    
    @classmethod
    def validate(cls):
        if not cls.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY not found in environment variables")
        return True