def generate_preview_html(html_content: str, css_content: str) -> str:
    # Process CSS to ensure it works in preview
    import re
    
    # Fix common SCSS syntax that might remain
    css_processed = css_content
    
    # Handle nested selectors with max iterations to prevent infinite loops
    # Convert .parent { .child { ... } } to .parent .child { ... }
    max_iterations = 10
    iterations = 0
    while re.search(r'(\.[a-zA-Z-_]+)\s*{([^{}]*){', css_processed) and iterations < max_iterations:
        css_processed = re.sub(
            r'(\.[a-zA-Z-_]+)\s*{([^{}]*?)(\.[a-zA-Z-_]+)\s*{([^}]*)}',
            r'\1 \3 { \4 } \1 { \2',
            css_processed
        )
        iterations += 1
    
    # Handle & references
    css_processed = re.sub(r'&([.:#\[])', r'\1', css_processed)
    
    # Add some default styles for better preview
    preview_template = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UI Preview</title>
    <style>
        /* Reset and base styles */
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Inter', Roboto, sans-serif;
            background-color: #ffffff;
            color: #222222;
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }}
        
        /* Preview wrapper - neutral background */
        .preview-wrapper {{
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
            background-color: #fafafa;
        }}
        
        /* Component styles */
        {css_processed}
        
        /* Ensure buttons are interactive in preview */
        button {{
            cursor: pointer;
        }}
        
        /* Add default transitions */
        button, a {{
            transition: all 0.2s ease;
        }}
    </style>
</head>
<body>
    <div class="preview-wrapper">
        {html_content}
    </div>
    
    <script>
        // Add mock data for preview
        document.addEventListener('DOMContentLoaded', function() {{
            // Replace Angular interpolations with sample data
            document.body.innerHTML = document.body.innerHTML
                .replace(/\\{{\\s*subtotal\\s*\\|[^}}]*\\}}/g, '$65.00')
                .replace(/\\{{\\s*shipping\\s*\\|[^}}]*\\}}/g, '$5.00')
                .replace(/\\{{\\s*tax\\s*\\|[^}}]*\\}}/g, '$8.40')
                .replace(/\\{{\\s*total\\s*\\|[^}}]*\\}}/g, '$78.40')
                .replace(/\\{{\\s*([^}}|]+?)\\s*\\}}/g, 'Sample $1');
            
            // Add click handlers for preview
            document.querySelectorAll('button').forEach(btn => {{
                btn.addEventListener('click', (e) => {{
                    e.preventDefault();
                    console.log('Button clicked:', e.target.textContent);
                }});
            }});
        }});
    </script>
</body>
</html>
"""
    return preview_template