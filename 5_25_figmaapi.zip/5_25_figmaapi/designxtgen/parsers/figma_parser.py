from typing import Dict, List, Any, Optional
import json

class FigmaParser:
    def __init__(self):
        self.parsed_data = {
            'elements': [],
            'styles': {},
            'description': '',
            'hierarchy': {}
        }
    
    def parse(self, figma_data: Dict) -> Dict:
        # Handle the case where documents might be a list from LangChain loader
        documents = figma_data.get('documents', [])
        
        # Extract content from documents if it's a list
        if isinstance(documents, list) and documents:
            # LangChain returns Document objects with page_content
            content = documents[0].page_content if hasattr(documents[0], 'page_content') else str(documents[0])
            # Try to parse the content as JSON if possible
            try:
                import json
                doc_data = json.loads(content)
                file_data = doc_data
            except:
                # If not JSON, use the raw file_data from API
                file_data = figma_data.get('file_data', {})
        else:
            file_data = figma_data.get('file_data', {})
        
        document = file_data.get('document', {})
        
        self.parsed_data['name'] = file_data.get('name', 'Untitled')
        self.parsed_data['elements'] = self._parse_node(document)
        self.parsed_data['styles'] = self._parse_styles(figma_data.get('styles', {}))
        self.parsed_data['description'] = self._generate_description()
        
        return self.parsed_data
    
    def _parse_node(self, node: Dict, parent_id: Optional[str] = None) -> List[Dict]:
        elements = []
        
        if not node:
            return elements
        
        element = {
            'id': node.get('id'),
            'name': node.get('name'),
            'type': node.get('type'),
            'parent_id': parent_id,
            'visible': node.get('visible', True),
            'locked': node.get('locked', False),
            'opacity': node.get('opacity', 1)
        }
        
        # Handle component instances
        if node.get('type') == 'INSTANCE':
            element['component_id'] = node.get('componentId')
            element['is_component_instance'] = True
            element['overrides'] = node.get('overrides', [])
        
        # Handle components
        if node.get('type') == 'COMPONENT' or node.get('type') == 'COMPONENT_SET':
            element['is_component'] = True
            element['component_properties'] = node.get('componentPropertyDefinitions', {})
        
        if node.get('type') == 'TEXT':
            element['content'] = node.get('characters', '')
            element['style'] = self._parse_text_style(node.get('style', {}))
        
        if 'absoluteBoundingBox' in node:
            bounds = node['absoluteBoundingBox']
            element['bounds'] = {
                'x': bounds.get('x', 0),
                'y': bounds.get('y', 0),
                'width': bounds.get('width', 0),
                'height': bounds.get('height', 0)
            }
        
        if 'layoutMode' in node:
            element['layout'] = {
                'mode': node.get('layoutMode'),
                'direction': self._get_flex_direction(node.get('layoutMode')),
                'align': self._get_alignment(node),
                'gap': node.get('itemSpacing', 0),
                'padding': self._get_padding(node),
                'spacing_mode': node.get('itemSpacing', 'PACKED'),
                'wrap': node.get('layoutWrap', 'NO_WRAP'),
                'primary_axis_sizing': node.get('primaryAxisSizingMode', 'FIXED'),
                'counter_axis_sizing': node.get('counterAxisSizingMode', 'FIXED')
            }
        
        # Constraints for responsive design
        if 'constraints' in node:
            element['constraints'] = {
                'horizontal': node['constraints'].get('horizontal', 'LEFT'),
                'vertical': node['constraints'].get('vertical', 'TOP')
            }
        
        # Export settings for images
        if 'exportSettings' in node:
            element['export_settings'] = node['exportSettings']
        
        # Interaction/prototype data
        if 'interactions' in node:
            element['interactions'] = self._parse_interactions(node['interactions'])
        
        if 'fills' in node:
            element['fills'] = self._parse_fills(node['fills'])
        
        if 'strokes' in node:
            element['strokes'] = self._parse_strokes(node['strokes'])
        
        if 'effects' in node:
            element['effects'] = self._parse_effects(node['effects'])
        
        if 'cornerRadius' in node:
            element['cornerRadius'] = node['cornerRadius']
        
        elements.append(element)
        
        if 'children' in node:
            for child in node['children']:
                elements.extend(self._parse_node(child, element['id']))
        
        return elements
    
    def _get_flex_direction(self, layout_mode: str) -> str:
        return 'row' if layout_mode == 'HORIZONTAL' else 'column'
    
    def _get_alignment(self, node: Dict) -> Dict:
        return {
            'primary': node.get('primaryAxisAlignItems', 'MIN'),
            'counter': node.get('counterAxisAlignItems', 'MIN')
        }
    
    def _get_padding(self, node: Dict) -> Dict:
        return {
            'top': node.get('paddingTop', 0),
            'right': node.get('paddingRight', 0),
            'bottom': node.get('paddingBottom', 0),
            'left': node.get('paddingLeft', 0)
        }
    
    def _parse_fills(self, fills: List) -> List[Dict]:
        parsed_fills = []
        for fill in fills:
            if fill.get('visible', True):
                parsed_fill = {
                    'type': fill.get('type'),
                    'opacity': fill.get('opacity', 1)
                }
                if 'color' in fill:
                    color = fill['color']
                    parsed_fill['color'] = f"rgba({int(color['r']*255)}, {int(color['g']*255)}, {int(color['b']*255)}, {color.get('a', 1)})"
                parsed_fills.append(parsed_fill)
        return parsed_fills
    
    def _parse_strokes(self, strokes: List) -> List[Dict]:
        parsed_strokes = []
        for stroke in strokes:
            if stroke.get('visible', True):
                parsed_stroke = {
                    'type': stroke.get('type'),
                    'weight': stroke.get('weight', 1)
                }
                if 'color' in stroke:
                    color = stroke['color']
                    parsed_stroke['color'] = f"rgba({int(color['r']*255)}, {int(color['g']*255)}, {int(color['b']*255)}, {color.get('a', 1)})"
                parsed_strokes.append(parsed_stroke)
        return parsed_strokes
    
    def _parse_effects(self, effects: List) -> List[Dict]:
        parsed_effects = []
        for effect in effects:
            if effect.get('visible', True):
                parsed_effect = {
                    'type': effect.get('type')
                }
                if effect['type'] == 'DROP_SHADOW':
                    parsed_effect['offset'] = {
                        'x': effect.get('offset', {}).get('x', 0),
                        'y': effect.get('offset', {}).get('y', 0)
                    }
                    parsed_effect['radius'] = effect.get('radius', 0)
                    if 'color' in effect:
                        color = effect['color']
                        parsed_effect['color'] = f"rgba({int(color['r']*255)}, {int(color['g']*255)}, {int(color['b']*255)}, {color.get('a', 1)})"
                parsed_effects.append(parsed_effect)
        return parsed_effects
    
    def _parse_text_style(self, style: Dict) -> Dict:
        return {
            'fontFamily': style.get('fontFamily', 'Roboto'),
            'fontSize': style.get('fontSize', 16),
            'fontWeight': style.get('fontWeight', 400),
            'letterSpacing': style.get('letterSpacing', 0),
            'lineHeight': style.get('lineHeightPx', style.get('fontSize', 16) * 1.5),
            'textAlign': style.get('textAlignHorizontal', 'LEFT').lower()
        }
    
    def _parse_styles(self, styles_data: Dict) -> Dict:
        parsed_styles = {}
        if isinstance(styles_data, dict):
            meta = styles_data.get('meta', {})
            if isinstance(meta, dict) and 'styles' in meta:
                styles = meta['styles']
                if isinstance(styles, dict):
                    for style_id, style_info in styles.items():
                        if isinstance(style_info, dict):
                            parsed_styles[style_id] = {
                                'name': style_info.get('name'),
                                'type': style_info.get('styleType'),
                                'description': style_info.get('description', '')
                            }
        return parsed_styles
    
    def _parse_interactions(self, interactions: List) -> List[Dict]:
        parsed_interactions = []
        for interaction in interactions:
            parsed_interactions.append({
                'trigger': interaction.get('trigger', {}).get('type'),
                'action': interaction.get('action', {}).get('type'),
                'destination': interaction.get('action', {}).get('destinationId'),
                'navigation': interaction.get('action', {}).get('navigation'),
                'transition': interaction.get('action', {}).get('transition')
            })
        return parsed_interactions
    
    def _generate_description(self) -> str:
        elements = self.parsed_data['elements']
        frames = [e for e in elements if e['type'] == 'FRAME']
        texts = [e for e in elements if e['type'] == 'TEXT']
        components = [e for e in elements if e.get('is_component')]
        instances = [e for e in elements if e.get('is_component_instance')]
        images = [e for e in elements if e['type'] in ['RECTANGLE', 'ELLIPSE'] and e.get('export_settings')]
        
        description = f"Design: {self.parsed_data.get('name', 'Untitled')}\\n\\n"
        description += f"Structure Overview:\\n"
        description += f"- {len(frames)} frames/containers\\n"
        description += f"- {len(texts)} text elements\\n"
        description += f"- {len(components)} components\\n"
        description += f"- {len(instances)} component instances\\n"
        description += f"- {len(images)} potential images/icons\\n"
        description += f"- {len(elements)} total elements\\n\\n"
        
        description += "Layout Analysis:\\n"
        for frame in frames[:10]:
            if 'layout' in frame:
                description += f"- {frame['name']}: {frame['layout']['direction']} layout"
                if frame['layout']['gap'] > 0:
                    description += f" with {frame['layout']['gap']}px gap"
                if frame.get('constraints'):
                    description += f" (responsive: {frame['constraints']['horizontal']})"
                description += "\\n"
        
        description += "\\nComponent Analysis:\\n"
        for comp in components[:5]:
            description += f"- {comp['name']} (reusable component)\\n"
        
        if instances:
            description += f"\\nFound {len(instances)} instances of reusable components\\n"
        
        # Analyze text hierarchy
        text_sizes = {}
        for text in texts:
            if 'style' in text:
                size = text['style'].get('fontSize', 16)
                text_sizes[size] = text_sizes.get(size, 0) + 1
        
        if text_sizes:
            description += "\\nTypography Hierarchy:\\n"
            for size, count in sorted(text_sizes.items(), reverse=True)[:5]:
                description += f"- {size}px: {count} instances\\n"
        
        return description