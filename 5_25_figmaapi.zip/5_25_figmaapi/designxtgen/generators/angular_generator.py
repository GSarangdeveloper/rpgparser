from typing import Dict, Optional, List
from openai import OpenAI
from config import Config
import json
import base64
import re

class AngularGenerator:
    def __init__(self):
        self.client = OpenAI(api_key=Config.OPENAI_API_KEY)
        self.model = "gpt-4.1"
    
    def generate(self, ui_description: str, user_stories: Optional[str] = None, 
                 custom_css: Optional[str] = None) -> Dict[str, str]:
        
        prompt = self._build_prompt(ui_description, user_stories, custom_css)
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert Angular developer. Generate clean, modern Angular code following best practices."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=Config.MAX_TOKENS,
            temperature=0.3
        )
        
        return self._parse_response(response.choices[0].message.content)
    
    def generate_from_figma(self, parsed_data: Dict, user_stories: Optional[str] = None,
                           custom_css: Optional[str] = None) -> Dict[str, str]:
        
        prompt = self._build_figma_prompt(parsed_data, user_stories, custom_css)
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert Angular developer. Generate clean, modern Angular code from Figma design data following best practices."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=Config.MAX_TOKENS,
            temperature=0.3
        )
        
        return self._parse_response(response.choices[0].message.content)
    
    def _build_prompt(self, ui_description: str, user_stories: Optional[str], 
                      custom_css: Optional[str]) -> str:
        prompt = f"""Generate Angular component code based on this UI description:

UI DESCRIPTION:
{ui_description}

"""
        
        if user_stories:
            prompt += f"""USER STORIES:
{user_stories}

"""
        
        if custom_css:
            prompt += f"""CUSTOM CSS TO USE:
{custom_css}

Please use the provided CSS classes where appropriate.

"""
        
        prompt += """Generate the following files:
1. TypeScript component file (.ts)
2. HTML template file (.html)
3. SCSS styles file (.scss)

Requirements:
- Use Angular 16+ syntax
- Include proper TypeScript types
- Use semantic HTML
- Follow Angular style guide
- Make the component responsive
- Use flexbox/grid for layouts
- Include basic interactivity stubs

Format your response as:
```typescript
// component.ts content
```

```html
<!-- template.html content -->
```

```scss
// styles.scss content
```"""
        
        return prompt
    
    def _build_figma_prompt(self, parsed_data: Dict, user_stories: Optional[str],
                           custom_css: Optional[str]) -> str:
        
        elements_summary = self._summarize_elements(parsed_data['elements'])
        
        prompt = f"""Generate Angular component code based on this Figma design data:

DESIGN NAME: {parsed_data.get('name', 'Component')}

DESIGN STRUCTURE:
{parsed_data['description']}

KEY ELEMENTS:
{elements_summary}

"""
        
        if user_stories:
            prompt += f"""USER STORIES:
{user_stories}

"""
        
        if custom_css:
            prompt += f"""CUSTOM CSS TO USE:
{custom_css}

Please use the provided CSS classes where appropriate.

"""
        
        prompt += """Generate the following files:
1. TypeScript component file (.ts)
2. HTML template file (.html)  
3. SCSS styles file (.scss)

Requirements:
- Use Angular 16+ syntax
- Include proper TypeScript types
- Use semantic HTML
- Follow Angular style guide
- Accurately reflect the Figma layout properties (flex direction, gaps, padding)
- Match the colors, fonts, and spacing from the design
- Make the component responsive
- Include basic interactivity stubs

Format your response as:
```typescript
// component.ts content
```

```html
<!-- template.html content -->
```

```scss
// styles.scss content
```"""
        
        return prompt
    
    def _summarize_elements(self, elements: List[Dict]) -> str:
        summary = []
        
        frames = [e for e in elements if e['type'] == 'FRAME']
        texts = [e for e in elements if e['type'] == 'TEXT']
        components = [e for e in elements if e.get('is_component')]
        instances = [e for e in elements if e.get('is_component_instance')]
        
        # Component summary
        if components:
            summary.append("REUSABLE COMPONENTS:")
            for comp in components[:5]:
                summary.append(f"- {comp['name']} (define as Angular component)")
        
        # Layout summary with responsive info
        summary.append("\\nLAYOUT STRUCTURE:")
        for frame in frames[:10]:
            frame_desc = f"- {frame['name']}"
            if 'layout' in frame:
                layout = frame['layout']
                frame_desc += f": {layout['direction']} layout"
                if layout['gap'] > 0:
                    frame_desc += f", {layout['gap']}px gap"
                if layout.get('wrap') != 'NO_WRAP':
                    frame_desc += ", flex-wrap"
            if frame.get('constraints'):
                frame_desc += f" [Responsive: H-{frame['constraints']['horizontal']}, V-{frame['constraints']['vertical']}]"
            summary.append(frame_desc)
        
        # Component instances
        if instances:
            summary.append(f"\\nCOMPONENT INSTANCES: {len(instances)} instances found")
            instance_map = {}
            for inst in instances:
                comp_id = inst.get('component_id', 'unknown')
                instance_map[comp_id] = instance_map.get(comp_id, 0) + 1
            for comp_id, count in list(instance_map.items())[:3]:
                summary.append(f"- {count} instances of component {comp_id}")
        
        # Interactions
        interactive_elements = [e for e in elements if e.get('interactions')]
        if interactive_elements:
            summary.append(f"\\nINTERACTIONS: {len(interactive_elements)} interactive elements")
            for elem in interactive_elements[:3]:
                for interaction in elem['interactions'][:1]:
                    summary.append(f"- {elem['name']}: {interaction.get('trigger')} → {interaction.get('action')}")
        
        # Text hierarchy
        summary.append(f"\\nTEXT ELEMENTS: {len(texts)} total")
        text_sizes = {}
        for text in texts:
            if 'style' in text:
                size = text['style'].get('fontSize', 16)
                text_sizes[size] = text_sizes.get(size, 0) + 1
        for size, count in sorted(text_sizes.items(), reverse=True)[:3]:
            summary.append(f"- {size}px: {count} instances (likely {'heading' if size > 20 else 'body'} text)")
        
        return "\\n".join(summary)
    
    def _extract_precise_values(self, elements: List[Dict]) -> str:
        values = []
        
        # Extract precise measurements from frames
        main_frames = [e for e in elements if e['type'] == 'FRAME' and e.get('parent_id') is None]
        
        for frame in main_frames[:3]:
            values.append(f"\\n{frame['name']} EXACT MEASUREMENTS:")
            
            # Dimensions
            if 'bounds' in frame:
                values.append(f"- Width: {frame['bounds']['width']}px")
                values.append(f"- Height: {frame['bounds']['height']}px")
            
            # Padding
            if 'layout' in frame and 'padding' in frame['layout']:
                padding = frame['layout']['padding']
                values.append(f"- Padding: {padding['top']}px {padding['right']}px {padding['bottom']}px {padding['left']}px")
            
            # Gap
            if 'layout' in frame and frame['layout'].get('gap'):
                values.append(f"- Gap between items: {frame['layout']['gap']}px")
            
            # Border radius
            if 'cornerRadius' in frame:
                values.append(f"- Border radius: {frame['cornerRadius']}px")
            
            # Background
            if 'fills' in frame and frame['fills']:
                for fill in frame['fills']:
                    if 'color' in fill:
                        values.append(f"- Background color: {fill['color']}")
            
            # Effects
            if 'effects' in frame:
                for effect in frame['effects']:
                    if effect['type'] == 'DROP_SHADOW':
                        values.append(f"- Shadow: {effect.get('offset', {}).get('x', 0)}px {effect.get('offset', {}).get('y', 0)}px {effect.get('radius', 0)}px {effect.get('color', 'rgba(0,0,0,0.1)')}")
        
        # Extract text styles
        texts = [e for e in elements if e['type'] == 'TEXT']
        unique_sizes = set()
        for text in texts:
            if 'style' in text:
                size = text['style'].get('fontSize')
                if size:
                    unique_sizes.add(size)
        
        if unique_sizes:
            values.append("\\nTEXT SIZES TO USE:")
            for size in sorted(unique_sizes, reverse=True):
                values.append(f"- {size}px")
        
        return "\\n".join(values)
    
    def _parse_response(self, response: str) -> Dict[str, str]:
        result = {
            'typescript': '',
            'html': '',
            'scss': '',
            'css': ''
        }
        
        # More robust parsing
        import re
        
        # Extract TypeScript
        ts_match = re.search(r'```typescript\s*\n(.*?)```', response, re.DOTALL)
        if ts_match:
            result['typescript'] = ts_match.group(1).strip()
        
        # Extract HTML
        html_match = re.search(r'```html\s*\n(.*?)```', response, re.DOTALL)
        if html_match:
            result['html'] = html_match.group(1).strip()
            # Remove any leading comment lines
            result['html'] = re.sub(r'^<!--.*?-->\s*\n', '', result['html'], flags=re.MULTILINE)
        
        # Extract SCSS
        scss_match = re.search(r'```scss\s*\n(.*?)```', response, re.DOTALL)
        if scss_match:
            result['scss'] = scss_match.group(1).strip()
            # Remove any leading comment lines
            result['scss'] = re.sub(r'^//.*?\n', '', result['scss'], flags=re.MULTILINE)
            # Convert SCSS to CSS for preview (basic conversion)
            result['css'] = self._scss_to_css(result['scss'])
        
        # Validation
        if not result['typescript']:
            result['typescript'] = self._generate_default_component()
        
        # Validate completeness
        self._validate_generated_code(result)
        
        return result
    
    def _scss_to_css(self, scss: str) -> str:
        # Basic SCSS to CSS conversion for preview
        # This is simplified - in production you'd use a proper SCSS compiler
        css = scss
        
        # Handle nested selectors (basic)
        css = re.sub(r'(\.[a-zA-Z-]+)\s*{\s*([^{}]*?)\s*(\.[a-zA-Z-]+)\s*{', r'\1 \3 { \2', css)
        
        # Handle & parent references
        css = re.sub(r'&\.([a-zA-Z-]+)', r'.\1', css)
        css = re.sub(r'&:([a-zA-Z-]+)', r':\1', css)
        
        # Handle variables (convert to CSS custom properties)
        css = re.sub(r'\$([a-zA-Z-]+):\s*([^;]+);', r'--\1: \2;', css)
        css = re.sub(r'\$([a-zA-Z-]+)', r'var(--\1)', css)
        
        return css
    
    def _validate_generated_code(self, result: Dict[str, str]) -> None:
        issues = []
        
        # Check for incomplete files
        if result['html'] and result['html'].endswith(('...', '…')):
            issues.append("HTML appears to be truncated")
        
        if result['scss'] and not result['scss'].strip().endswith('}'):
            issues.append("SCSS appears to be incomplete (missing closing brace)")
        
        if result['typescript'] and not re.search(r'export\s+class', result['typescript']):
            issues.append("TypeScript missing export class declaration")
        
        # Check for basic Angular structure
        if result['html'] and not any(marker in result['html'] for marker in ['(click)', '[(ngModel)]', '*ngFor', '*ngIf', '{{', '|']):
            issues.append("HTML missing Angular template syntax")
        
        if issues:
            error_msg = "Code generation validation issues:\\n" + "\\n".join(f"- {issue}" for issue in issues)
            print(f"Warning: {error_msg}")  # Log issues but don't fail
    
    def _generate_default_component(self) -> str:
        return """import { Component } from '@angular/core';

@Component({
  selector: 'app-generated',
  templateUrl: './generated.component.html',
  styleUrls: ['./generated.component.scss']
})
export class GeneratedComponent {
  title = 'Generated Component';
  
  constructor() { }
  
  ngOnInit(): void {
  }
}"""
    
    def generate_from_all_inputs(self, parsed_data: Dict, ui_description: str, user_stories: str,
                                image_bytes: Optional[bytes] = None, custom_css: Optional[str] = None,
                                additional_prompt: Optional[str] = None) -> Dict[str, str]:
        
        messages = [
            {
                "role": "system",
                "content": "You are an expert Angular developer. Generate clean, modern Angular code from the provided Figma design data, user stories, and reference image."
            }
        ]
        
        # Build the text prompt
        prompt = self._build_combined_prompt(parsed_data, ui_description, user_stories, custom_css, additional_prompt)
        
        # Create the user message content
        content = [
            {
                "type": "text",
                "text": prompt
            }
        ]
        
        # Add image if provided
        if image_bytes:
            base64_image = base64.b64encode(image_bytes).decode('utf-8')
            content.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/png;base64,{base64_image}"
                }
            })
        
        messages.append({
            "role": "user",
            "content": content
        })
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=Config.MAX_TOKENS,
            temperature=0.3,
            timeout=Config.REQUEST_TIMEOUT
        )
        
        return self._parse_response(response.choices[0].message.content)
    
    def _build_combined_prompt(self, parsed_data: Dict, ui_description: str, user_stories: str, 
                              custom_css: Optional[str], additional_prompt: Optional[str]) -> str:
        elements_summary = self._summarize_elements(parsed_data['elements'])
        precise_values = self._extract_precise_values(parsed_data['elements'])
        
        prompt = f"""Generate Angular component code based on:

1. UI DESCRIPTION (from PNG analysis):
{ui_description}

2. USER STORIES (from PNG analysis):
{user_stories}

3. FIGMA DESIGN DATA:
Design Name: {parsed_data.get('name', 'Component')}
{parsed_data['description']}

KEY ELEMENTS:
{elements_summary}

PRECISE FIGMA VALUES TO USE:
{precise_values}

4. REFERENCE IMAGE: Attached PNG showing the visual design

"""
        
        if custom_css:
            prompt += f"""5. CUSTOM CSS TO USE:
{custom_css}

Please use the provided CSS classes where appropriate.

"""
        
        if additional_prompt:
            prompt += f"""6. ADDITIONAL REQUIREMENTS:
{additional_prompt}

"""
        
        prompt += """Generate the following files:
1. TypeScript component file (.ts)
2. HTML template file (.html)  
3. SCSS styles file (.scss)

Requirements:
- Use Angular 16+ syntax with standalone components
- Match the PNG image visual design EXACTLY - every pixel matters
- Implement ALL functionality from user stories completely

CRITICAL FIGMA DATA USAGE:
1. EXACT MEASUREMENTS - Use precise values from Figma:
   - If gap is 16px in Figma, use gap: 16px in CSS
   - If padding is "32px 24px 28px 24px", use those exact values
   - Match border-radius exactly (e.g., 18px not 20px)
   - Use exact font sizes (20px, 14px, etc.) from the text hierarchy

2. LAYOUT STRUCTURE from parsed Figma data:
   - Use display: flex with exact flex-direction from layout data
   - Apply exact gap values from Figma Auto Layout
   - Implement flex-wrap where indicated
   - Use precise padding values from all four sides

3. COLORS & STYLING:
   - Extract exact colors from fills/strokes in Figma data
   - Match shadows and effects precisely
   - Use exact opacity values

4. COMPONENT ARCHITECTURE:
   - Create separate @Component for each Figma component
   - Use component instances as Angular component usage
   - Pass data via @Input() decorators

5. RESPONSIVE BEHAVIOR:
   - Implement Figma constraints (SCALE, CENTER, LEFT_RIGHT, etc.)
   - Add breakpoints based on frame sizes in Figma
   - Maintain aspect ratios where needed

6. COMPLETE CODE GENERATION:
   - Ensure ALL files are complete with closing braces
   - Include all necessary imports
   - Add proper types for all variables
   - Complete all CSS rules without truncation

Format your response as:
```typescript
// component.ts content
```

```html
<!-- template.html content -->
```

```scss
// styles.scss content
```"""
        
        return prompt
    def refine_generated_code(self, initial_code: Dict[str, str], parsed_data: Dict, 
                            ui_description: str, image_bytes: Optional[bytes] = None) -> Dict[str, str]:
        """
        Refine the initially generated code for better accuracy
        """
        messages = [
            {
                "role": "system",
                "content": "You are an expert Angular developer. Your task is to refine and improve the provided Angular code to better match the design and requirements."
            }
        ]
        
        # Build refinement prompt
        refinement_prompt = f"""Please refine the following Angular code to improve:
1. Visual accuracy - ensure it matches the attached image EXACTLY
2. Responsive behavior - improve mobile/tablet/desktop layouts
3. Code quality - fix any issues, improve structure
4. Styling precision - match exact colors, spacing, typography from Figma

INITIAL CODE TO REFINE:

TypeScript:
```typescript
{initial_code["typescript"]}
```

HTML:
```html
{initial_code["html"]}
```

SCSS:
```scss
{initial_code["scss"]}
```

UI DESCRIPTION:
{ui_description}

FIGMA MEASUREMENTS TO MATCH:
{self._extract_precise_values(parsed_data["elements"])}

REQUIREMENTS:
- Match the visual design in the attached image EXACTLY
- Ensure all Figma measurements are applied correctly
- Improve responsive behavior with proper breakpoints
- Fix any styling issues or inconsistencies
- Ensure Angular best practices are followed
- Keep the same component structure

Return the refined code in the same format."""
        
        content = [
            {
                "type": "text",
                "text": refinement_prompt
            }
        ]
        
        # Add image for visual reference
        if image_bytes:
            base64_image = base64.b64encode(image_bytes).decode("utf-8")
            content.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/png;base64,{base64_image}"
                }
            })
        
        messages.append({
            "role": "user",
            "content": content
        })
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=Config.MAX_TOKENS,
                temperature=0.2,  # Lower temperature for refinement
                timeout=Config.REQUEST_TIMEOUT
            )
            
            refined_code = self._parse_response(response.choices[0].message.content)
            
            # If parsing fails, return the initial code
            if not refined_code["typescript"] or not refined_code["html"] or not refined_code["scss"]:
                return initial_code
                
            return refined_code
            
        except Exception as e:
            print(f"Refinement error: {str(e)}")
            # Return initial code if refinement fails
            return initial_code
