import re
import requests
from typing import Dict, Any
from langchain_community.document_loaders import FigmaFileLoader
from config import Config

class FigmaLoader:
    def __init__(self):
        self.access_token = Config.FIGMA_ACCESS_TOKEN
        
    def extract_file_key(self, figma_url: str) -> str:
        # Updated pattern to handle both /file/ and /design/ URLs
        pattern = r'figma\.com/(?:file|design)/([a-zA-Z0-9]+)'
        match = re.search(pattern, figma_url)
        if match:
            return match.group(1)
        raise ValueError("Invalid Figma URL format")
    
    def load_figma_file(self, figma_url: str) -> Dict[str, Any]:
        try:
            file_key = self.extract_file_key(figma_url)
            
            # FigmaFileLoader expects: access_token, node_ids, file_key
            # For now, we'll load all nodes by passing an empty string for node_ids
            loader = FigmaFileLoader(
                self.access_token,  # access_token
                "",                 # node_ids (empty to get all nodes)
                file_key           # file_key
            )
            
            documents = loader.load()
            
            headers = {
                'X-FIGMA-TOKEN': self.access_token
            }
            
            file_response = requests.get(
                f'https://api.figma.com/v1/files/{file_key}',
                headers=headers
            )
            file_data = file_response.json()
            
            styles_response = requests.get(
                f'https://api.figma.com/v1/files/{file_key}/styles',
                headers=headers
            )
            styles_data = styles_response.json() if styles_response.status_code == 200 else {}
            
            return {
                'documents': documents,
                'file_data': file_data,
                'styles': styles_data,
                'file_key': file_key
            }
            
        except Exception as e:
            raise Exception(f"Error loading Figma file: {str(e)}")
    
    def get_node_by_id(self, file_data: Dict, node_id: str) -> Dict:
        def search_node(node: Dict, target_id: str) -> Dict:
            if node.get('id') == target_id:
                return node
            
            if 'children' in node:
                for child in node['children']:
                    result = search_node(child, target_id)
                    if result:
                        return result
            
            return None
        
        return search_node(file_data['document'], node_id)