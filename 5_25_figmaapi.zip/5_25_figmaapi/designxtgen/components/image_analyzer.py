import base64
from openai import OpenAI
from config import Config

class ImageAnalyzer:
    def __init__(self):
        self.client = OpenAI(api_key=Config.OPENAI_API_KEY)
        self.model = Config.GPT_MODEL
    
    def encode_image(self, image_bytes):
        return base64.b64encode(image_bytes).decode('utf-8')
    
    def analyze_image(self, image_bytes):
        base64_image = self.encode_image(image_bytes)
        
        prompt = """Analyze this UI design image and provide a structured description including:
        1. Overall layout structure (header, main content, sidebar, footer, etc.)
        2. UI components present (buttons, forms, cards, navigation, etc.)
        3. Color scheme and typography observations
        4. Spacing and alignment patterns
        5. Any interactive elements or states visible
        
        Format your response as a detailed, structured description that can be used to generate code."""
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=Config.MAX_TOKENS,
            temperature=Config.TEMPERATURE
        )
        
        return response.choices[0].message.content
    
    def generate_user_stories(self, ui_description):
        prompt = f"""Based on this UI description, generate user stories that explain the functional purpose of each UI element:

UI Description:
{ui_description}

Generate 3-5 user stories in the format:
"As a [user type], I want to [action] so that [benefit]"

Focus on the key interactive elements and their purposes."""
        
        response = self.client.chat.completions.create(
            model="gpt-4.1",
            messages=[
                {
                    "role": "system",
                    "content": "You are a product manager creating user stories from UI descriptions."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=1000,
            temperature=0.7
        )
        
        return response.choices[0].message.content