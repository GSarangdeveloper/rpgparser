import streamlit as st
from PIL import Image
import io
import base64
from pathlib import Path
import time
import json

from config import Config
from designxtgen.components.image_analyzer import ImageAnalyzer
from designxtgen.components.figma_loader import FigmaLoader
from designxtgen.parsers.figma_parser import FigmaParser
from designxtgen.generators.angular_generator import AngularGenerator
from designxtgen.utils.preview import generate_preview_html

st.set_page_config(
    page_title="UI Spark - AI-Powered UI Development Accelerator",
    page_icon="⚡",
    layout="wide"
)

def init_session_state():
    if 'generated_code' not in st.session_state:
        st.session_state.generated_code = None
    if 'ui_description' not in st.session_state:
        st.session_state.ui_description = None
    if 'user_stories' not in st.session_state:
        st.session_state.user_stories = None
    if 'preview_html' not in st.session_state:
        st.session_state.preview_html = None
    if 'parsed_figma_data' not in st.session_state:
        st.session_state.parsed_figma_data = None

def main():
    init_session_state()
    
    st.title("⚡ UI Spark - AI-Powered UI Development Accelerator")
    st.markdown("Transform your UI designs into Angular code using GPT-4 and Figma integration")
    
    try:
        Config.validate()
    except ValueError as e:
        st.error(f"Configuration Error: {str(e)}")
        st.info("Please create a .env file with your API keys (see .env.example)")
        return
    
    with st.sidebar:
        st.header("📋 Workflow Steps")
        st.info("""**Step 1: Image Analysis**
• 1a. Generate UI Description from PNG
• 1b. Generate User Stories

**Step 2: Figma Integration**
• Load & Parse Figma Design

**Step 3: Code Generation**
• Generate Angular Code with AI
• Optional: Refine for accuracy""")
        
        st.header("⚙️ Configuration")
        framework = st.selectbox(
            "Target Framework:",
            ["Angular", "React (Coming Soon)", "Vue (Coming Soon)"]
        )
        
        enable_refinement = st.checkbox(
            "Enable Code Refinement (2-pass generation)",
            value=True,
            help="Generate code twice to improve accuracy and match the design better"
        )
        
        custom_css = st.text_area(
            "Custom CSS (Optional)",
            placeholder="Paste your existing CSS or design system classes here...",
            height=150
        )
        
        additional_prompt = st.text_area(
            "Additional Instructions (Optional)",
            placeholder="Add any specific requirements or instructions for code generation...\n\nExamples:\n- Use RxJS for state management\n- Include form validation\n- Add accessibility features\n- Use specific naming conventions",
            height=150
        )
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.header("📥 Step 1: Analyze PNG Image")
        
        uploaded_file = st.file_uploader(
            "Upload UI design image (PNG)",
            type=['png', 'jpg', 'jpeg'],
            help="Upload a screenshot or mockup of your UI design"
        )
        
        if uploaded_file is not None:
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded UI Design", use_container_width=True)
            
            # Store image in session state
            image_bytes = io.BytesIO()
            image.save(image_bytes, format='PNG')
            st.session_state.image_bytes = image_bytes.getvalue()
            
            col1a, col1b = st.columns(2)
            
            with col1a:
                if st.button("📄 1a. Generate UI Description", type="primary"):
                    with st.spinner("Analyzing image and generating UI description..."):
                        try:
                            analyzer = ImageAnalyzer()
                            ui_description = analyzer.analyze_image(st.session_state.image_bytes)
                            st.session_state.ui_description = ui_description
                            st.success("✅ UI description generated!")
                        except Exception as e:
                            st.error(f"Error: {str(e)}")
            
            with col1b:
                if st.button("📝 1b. Generate User Stories", type="primary", 
                           disabled=not st.session_state.get('ui_description')):
                    with st.spinner("Generating user stories from UI description..."):
                        try:
                            analyzer = ImageAnalyzer()
                            user_stories = analyzer.generate_user_stories(st.session_state.ui_description)
                            st.session_state.user_stories = user_stories
                            st.success("✅ User stories generated!")
                        except Exception as e:
                            st.error(f"Error: {str(e)}")
        
        if st.session_state.get('ui_description'):
            with st.expander("Generated UI Description", expanded=True):
                st.write(st.session_state.ui_description)
        
        if st.session_state.get('user_stories'):
            with st.expander("Generated User Stories", expanded=True):
                st.write(st.session_state.user_stories)
        
        st.divider()
        
        st.header("📐 Step 2: Load Figma Design")
        
        figma_url = st.text_input(
            "Figma File URL",
            placeholder="https://www.figma.com/file/..."
        )
        
        if figma_url and st.button("🔄 Load & Parse Figma", type="secondary"):
            with st.spinner("Loading and parsing Figma design..."):
                try:
                    loader = FigmaLoader()
                    figma_data = loader.load_figma_file(figma_url)
                    
                    parser = FigmaParser()
                    parsed_data = parser.parse(figma_data)
                    
                    st.session_state.parsed_figma_data = parsed_data
                    
                    st.success("✅ Figma design loaded and parsed successfully!")
                    
                except Exception as e:
                    st.error(f"Error loading Figma: {str(e)}")
        
        if st.session_state.parsed_figma_data:
            with st.expander("Parsed Figma Summary"):
                st.write(st.session_state.parsed_figma_data['description'])
        
        st.divider()
        
        st.header("🚀 Step 3: Generate Angular Code")
        
        if st.button("🎯 Generate Angular Code", type="primary", disabled=not (st.session_state.user_stories and st.session_state.parsed_figma_data)):
            with st.spinner("🔄 Generating Angular code (this may take 2-5 minutes)..."):
                try:
                    generator = AngularGenerator()
                    
                    # Initial generation
                    st.write("🛠️ Generating initial Angular code...")
                    generated_code = generator.generate_from_all_inputs(
                        parsed_data=st.session_state.parsed_figma_data,
                        ui_description=st.session_state.ui_description,
                        user_stories=st.session_state.user_stories,
                        image_bytes=st.session_state.get('image_bytes'),
                        custom_css=custom_css if custom_css else None,
                        additional_prompt=additional_prompt if additional_prompt else None
                    )
                    
                    # Refinement pass if enabled
                    if enable_refinement:
                        st.write("🔧 Refining code for better accuracy...")
                        generated_code = generator.refine_generated_code(
                            initial_code=generated_code,
                            parsed_data=st.session_state.parsed_figma_data,
                            ui_description=st.session_state.ui_description,
                            image_bytes=st.session_state.get('image_bytes')
                        )
                        st.write("✅ Code refinement completed")
                    
                    st.session_state.generated_code = generated_code
                    
                    # Debug info
                    with st.expander("Debug: Generated Code Lengths"):
                        st.write(f"TypeScript: {len(generated_code['typescript'])} chars")
                        st.write(f"HTML: {len(generated_code['html'])} chars")
                        st.write(f"SCSS: {len(generated_code['scss'])} chars")
                        if generated_code['scss']:
                            st.write(f"SCSS ends with: ...{generated_code['scss'][-50:]}")
                        st.write("✅ Code generation completed")
                    
                    try:
                        st.write("🔄 Generating preview...")
                        # Use SCSS directly for now, skip complex conversion
                        st.session_state.preview_html = generate_preview_html(
                            generated_code['html'], 
                            generated_code.get('scss', generated_code.get('css', ''))
                        )
                        st.write("✅ Preview generated")
                    except Exception as e:
                        st.error(f"Preview generation error: {str(e)}")
                        # Fallback: simple preview without CSS processing
                        st.session_state.preview_html = f"""
                        <div style="padding: 20px; background: #f5f5f5;">
                            {generated_code['html']}
                        </div>
                        <style>{generated_code.get('scss', '')}</style>
                        """
                    
                    st.success("✅ Angular code generated successfully!")
                    st.rerun()  # Force UI update
                    
                except Exception as e:
                    st.error(f"Error generating code: {str(e)}")
    
    with col2:
        st.header("📤 Output")
        
        if st.session_state.generated_code:
            tab1, tab2, tab3, tab4, tab5 = st.tabs([
                "Preview", "Component (.ts)", "Template (.html)", "Styles (.scss)", "Artifacts"
            ])
            
            with tab1:
                st.subheader("Live Preview")
                if st.session_state.preview_html:
                    st.components.v1.html(
                        st.session_state.preview_html,
                        height=600,
                        scrolling=True
                    )
            
            with tab2:
                st.subheader("Angular Component (TypeScript)")
                st.code(st.session_state.generated_code['typescript'], language='typescript')
                st.download_button(
                    "⬇️ Download component.ts",
                    st.session_state.generated_code['typescript'],
                    "component.ts",
                    mime="text/plain"
                )
            
            with tab3:
                st.subheader("HTML Template")
                st.code(st.session_state.generated_code['html'], language='html')
                st.download_button(
                    "⬇️ Download template.html",
                    st.session_state.generated_code['html'],
                    "template.html",
                    mime="text/html"
                )
            
            with tab4:
                st.subheader("SCSS Styles")
                st.code(st.session_state.generated_code['scss'], language='scss')
                st.download_button(
                    "⬇️ Download styles.scss",
                    st.session_state.generated_code['scss'],
                    "styles.scss",
                    mime="text/plain"
                )
            
            with tab5:
                st.subheader("Generated Artifacts")
                
                if st.session_state.ui_description:
                    with st.expander("UI Description"):
                        st.write(st.session_state.ui_description)
                
                if st.session_state.user_stories:
                    with st.expander("User Stories"):
                        st.write(st.session_state.user_stories)
                
                if st.session_state.parsed_figma_data:
                    with st.expander("Parsed Figma JSON"):
                        import json
                        st.json(st.session_state.parsed_figma_data)
                        st.download_button(
                            "⬇️ Download parsed_figma.json",
                            json.dumps(st.session_state.parsed_figma_data, indent=2),
                            "parsed_figma.json",
                            mime="application/json"
                        )
                
                # Action buttons
                col_btn1, col_btn2, col_btn3 = st.columns(3)
                
                with col_btn1:
                    if st.button("📋 Copy All Code"):
                        all_code = f"""// component.ts
{st.session_state.generated_code['typescript']}

<!-- template.html -->
{st.session_state.generated_code['html']}

/* styles.scss */
{st.session_state.generated_code['scss']}"""
                        
                        # Create a unique key for this copy operation
                        copy_key = f"copy_{int(time.time())}"
                        
                        # JavaScript to copy to clipboard
                        st.markdown(f"""
<textarea id="{copy_key}" style="position: absolute; left: -9999px;">{all_code}</textarea>
<script>
    var copyText = document.getElementById("{copy_key}");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
</script>
                        """, unsafe_allow_html=True)
                        
                        st.success("✅ All code copied to clipboard!")
                        
                        # Also show the code for manual copying if needed
                        with st.expander("View All Code"):
                            st.code(all_code)
                
                with col_btn2:
                    if st.button("💾 Download All Files"):
                        import zipfile
                        
                        # Create a zip file in memory
                        zip_buffer = io.BytesIO()
                        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                            # Add component files
                            zip_file.writestr("component.ts", st.session_state.generated_code['typescript'])
                            zip_file.writestr("template.html", st.session_state.generated_code['html'])
                            zip_file.writestr("styles.scss", st.session_state.generated_code['scss'])
                            
                            # Add artifacts
                            if st.session_state.ui_description:
                                zip_file.writestr("artifacts/ui-description.txt", st.session_state.ui_description)
                            if st.session_state.user_stories:
                                zip_file.writestr("artifacts/user-stories.txt", st.session_state.user_stories)
                            if st.session_state.parsed_figma_data:
                                zip_file.writestr("artifacts/parsed-figma-data.json", 
                                                json.dumps(st.session_state.parsed_figma_data, indent=2))
                            
                            # Add README
                            readme_content = f"""# Generated Angular Component

This component was generated using UI Spark - AI-Powered UI Development Accelerator.

## Files Included:
- `component.ts` - Angular TypeScript component
- `template.html` - Component HTML template
- `styles.scss` - Component SCSS styles
- `artifacts/` - Generation artifacts and metadata

## Usage:

1. Copy these files to your Angular project
2. Update the component selector and file names as needed
3. Import the component in your module or use as standalone
4. Install any missing dependencies

## Generation Details:
- Generated on: {time.strftime('%Y-%m-%d %H:%M:%S')}
- Framework: Angular 16+
- Based on: Figma design + UI image analysis

## Component Integration:

```typescript
// In your module or standalone component
import {{ GeneratedComponent }} from './generated.component';
```

## Notes:
- Review and adjust responsive breakpoints as needed
- Ensure all required Angular dependencies are installed
- Update API endpoints and data bindings as per your backend
"""
                            zip_file.writestr("README.md", readme_content)
                        
                        # Download button
                        st.download_button(
                            label="⬇️ Download generated-code.zip",
                            data=zip_buffer.getvalue(),
                            file_name="generated-code.zip",
                            mime="application/zip"
                        )
                
                with col_btn3:
                    if st.button("📄 Download All Artifacts"):
                        artifacts_content = "=== GENERATED ARTIFACTS ===\n\n"
                        
                        if st.session_state.ui_description:
                            artifacts_content += "=== UI DESCRIPTION ===\n"
                            artifacts_content += st.session_state.ui_description + "\n\n"
                        
                        if st.session_state.user_stories:
                            artifacts_content += "=== USER STORIES ===\n"
                            artifacts_content += st.session_state.user_stories + "\n\n"
                        
                        if st.session_state.parsed_figma_data:
                            artifacts_content += "=== PARSED FIGMA DATA ===\n"
                            artifacts_content += json.dumps(st.session_state.parsed_figma_data, indent=2) + "\n\n"
                        
                        artifacts_content += "=== ANGULAR COMPONENT CODE ===\n\n"
                        artifacts_content += "// component.ts\n"
                        artifacts_content += st.session_state.generated_code['typescript'] + "\n\n"
                        artifacts_content += "<!-- template.html -->\n"
                        artifacts_content += st.session_state.generated_code['html'] + "\n\n"
                        artifacts_content += "/* styles.scss */\n"
                        artifacts_content += st.session_state.generated_code['scss']
                        
                        st.download_button(
                            label="⬇️ Download all-artifacts.txt",
                            data=artifacts_content,
                            file_name="all-artifacts.txt",
                            mime="text/plain"
                        )

if __name__ == "__main__":
    main()