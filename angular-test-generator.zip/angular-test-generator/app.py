"""
Streamlit Application for AI-Powered Angular Test Scenario Generator
"""

import streamlit as st
from PIL import Image
import json
import os
from datetime import datetime
import logging
from typing import Optional, Dict, Any
import traceback
import base64
from io import BytesIO

from figma_client import FigmaClient
from rally_client import RallyClient
from gpt4_client import GPT4VisionClient, AnalysisLevel
from test_generator import TestGenerator, TestGenerationConfig

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="AI Test Generator",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .stButton>button {
        width: 100%;
        background-color: #4CAF50;
        color: white;
    }
    .success-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
    }
    .error-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        color: #721c24;
    }
    .info-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #d1ecf1;
        border: 1px solid #bee5eb;
        color: #0c5460;
    }
</style>
""", unsafe_allow_html=True)


def init_session_state():
    """Initialize session state variables"""
    if 'api_keys' not in st.session_state:
        st.session_state.api_keys = {
            'openai': os.getenv('OPENAI_API_KEY', ''),
            'figma': os.getenv('FIGMA_API_KEY', ''),
            'rally': os.getenv('RALLY_API_KEY', '')
        }
    
    if 'test_config' not in st.session_state:
        st.session_state.test_config = TestGenerationConfig()
    
    if 'generation_result' not in st.session_state:
        st.session_state.generation_result = None
    
    if 'design_preview' not in st.session_state:
        st.session_state.design_preview = None
    
    if 'user_story_preview' not in st.session_state:
        st.session_state.user_story_preview = None
    
    if 'generation_progress' not in st.session_state:
        st.session_state.generation_progress = 0


def validate_api_keys() -> bool:
    """Validate that all required API keys are present"""
    keys = st.session_state.api_keys
    return all([keys['openai'], keys['figma'], keys['rally']])


def create_sidebar():
    """Create configuration sidebar"""
    with st.sidebar:
        st.title("⚙️ Configuration")
        
        # API Keys Section
        with st.expander("🔑 API Keys", expanded=not validate_api_keys()):
            st.session_state.api_keys['openai'] = st.text_input(
                "OpenAI API Key",
                value=st.session_state.api_keys['openai'],
                type="password",
                help="Your OpenAI API key for GPT-4 Vision"
            )
            
            st.session_state.api_keys['figma'] = st.text_input(
                "Figma API Key",
                value=st.session_state.api_keys['figma'],
                type="password",
                help="Your Figma personal access token"
            )
            
            st.session_state.api_keys['rally'] = st.text_input(
                "Rally API Key",
                value=st.session_state.api_keys['rally'],
                type="password",
                help="Your Rally API key"
            )
            
            if st.button("Validate Keys"):
                if validate_api_keys():
                    st.success("✅ All API keys are configured!")
                else:
                    st.error("❌ Please provide all API keys")
        
        # Test Configuration
        st.subheader("🧪 Test Configuration")
        
        st.session_state.test_config.framework = st.selectbox(
            "Framework",
            options=["angular", "react", "vue"],
            index=0,
            help="Testing framework to use"
        )
        
        st.session_state.test_config.test_style = st.selectbox(
            "Test Style",
            options=["jasmine", "jest", "mocha"],
            index=0,
            help="Test syntax style"
        )
        
        st.session_state.test_config.test_types = st.multiselect(
            "Test Types",
            options=["unit", "integration", "e2e"],
            default=["unit", "integration"],
            help="Types of tests to generate"
        )
        
        st.session_state.test_config.include_accessibility = st.checkbox(
            "Include Accessibility Tests",
            value=True,
            help="Generate accessibility test scenarios"
        )
        
        st.session_state.test_config.include_performance = st.checkbox(
            "Include Performance Tests",
            value=True,
            help="Generate performance test scenarios"
        )
        
        st.session_state.test_config.max_scenarios_per_type = st.slider(
            "Max Scenarios per Type",
            min_value=1,
            max_value=20,
            value=10,
            help="Maximum number of scenarios per test type"
        )
        
        # Advanced Settings
        with st.expander("🔧 Advanced Settings"):
            rally_workspace = st.text_input(
                "Rally Workspace ID",
                help="Optional: Specific Rally workspace"
            )
            
            rally_project = st.text_input(
                "Rally Project ID",
                help="Optional: Specific Rally project"
            )
            
            gpt4_model = st.selectbox(
                "GPT-4 Model",
                options=["gpt-4-vision-preview", "gpt-4-turbo-preview"],
                index=0,
                help="GPT-4 model variant to use"
            )
        
        # Cost Estimation
        st.subheader("💰 Cost Estimation")
        st.info("""
        **Estimated costs per generation:**
        - GPT-4 Vision: ~$0.10-$0.30
        - Total tokens: ~5000-15000
        
        *Actual costs may vary based on content complexity*
        """)


def fetch_and_preview_figma(figma_url: str) -> Optional[Image.Image]:
    """Fetch and display Figma design preview"""
    try:
        if not st.session_state.api_keys['figma']:
            st.error("Please provide Figma API key")
            return None
        
        with st.spinner("Fetching Figma design..."):
            figma_client = FigmaClient(st.session_state.api_keys['figma'])
            image = figma_client.get_design_screenshot(figma_url)
            st.session_state.design_preview = image
            return image
    
    except Exception as e:
        st.error(f"Failed to fetch Figma design: {str(e)}")
        logger.error(f"Figma fetch error: {traceback.format_exc()}")
        return None


def fetch_and_preview_rally(story_id: str) -> Optional[Dict[str, Any]]:
    """Fetch and display Rally user story preview"""
    try:
        if not st.session_state.api_keys['rally']:
            st.error("Please provide Rally API key")
            return None
        
        with st.spinner("Fetching Rally user story..."):
            rally_client = RallyClient(st.session_state.api_keys['rally'])
            story = rally_client.get_user_story(story_id)
            st.session_state.user_story_preview = story
            return story
    
    except Exception as e:
        st.error(f"Failed to fetch Rally story: {str(e)}")
        logger.error(f"Rally fetch error: {traceback.format_exc()}")
        return None


def generate_tests(figma_url: str, rally_id: str, context: str):
    """Generate tests using the test generator"""
    try:
        if not validate_api_keys():
            st.error("Please configure all API keys in the sidebar")
            return
        
        # Initialize clients
        figma_client = FigmaClient(st.session_state.api_keys['figma'])
        rally_client = RallyClient(st.session_state.api_keys['rally'])
        gpt4_client = GPT4VisionClient(st.session_state.api_keys['openai'])
        
        # Create test generator
        generator = TestGenerator(
            figma_client,
            rally_client,
            gpt4_client,
            st.session_state.test_config
        )
        
        # Generate tests
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        status_text.text("Starting test generation...")
        progress_bar.progress(10)
        
        result = generator.generate_from_urls(
            figma_url,
            rally_id,
            context if context else None
        )
        
        progress_bar.progress(100)
        status_text.text("Test generation completed!")
        
        st.session_state.generation_result = result
        
        return result
    
    except Exception as e:
        st.error(f"Test generation failed: {str(e)}")
        logger.error(f"Generation error: {traceback.format_exc()}")
        return None


def display_generation_results(result):
    """Display test generation results"""
    st.success(f"✅ Successfully generated {len(result.scenarios)} test scenarios!")
    
    # Create tabs for different views
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Summary", 
        "🎯 Scenarios", 
        "📝 Test Code", 
        "🔍 Analysis",
        "💾 Export"
    ])
    
    with tab1:
        st.subheader("Generation Summary")
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Scenarios", len(result.scenarios))
        with col2:
            st.metric("Test Files", len(result.test_files))
        with col3:
            st.metric("Framework", result.metadata['framework'])
        with col4:
            st.metric("Generated At", result.timestamp.strftime("%H:%M:%S"))
        
        # Scenarios by type
        st.subheader("Scenarios by Type")
        scenario_counts = {}
        for scenario in result.scenarios:
            test_type = scenario.get('test_type', 'unknown')
            scenario_counts[test_type] = scenario_counts.get(test_type, 0) + 1
        
        for test_type, count in scenario_counts.items():
            st.write(f"- **{test_type.capitalize()}**: {count} scenarios")
    
    with tab2:
        st.subheader("Generated Test Scenarios")
        
        for i, scenario in enumerate(result.scenarios, 1):
            with st.expander(f"{i}. {scenario.get('name', 'Scenario')} ({scenario.get('test_type', 'unknown')})"):
                st.write(f"**Description:** {scenario.get('description', 'N/A')}")
                st.write(f"**Priority:** {scenario.get('priority', 'medium')}")
                
                if scenario.get('preconditions'):
                    st.write("**Preconditions:**")
                    for condition in scenario['preconditions']:
                        st.write(f"- {condition}")
                
                if scenario.get('steps'):
                    st.write("**Test Steps:**")
                    for j, step in enumerate(scenario['steps'], 1):
                        st.write(f"{j}. **Action:** {step.get('action', '')}")
                        st.write(f"   **Expected:** {step.get('expected', '')}")
                
                if scenario.get('assertions'):
                    st.write("**Assertions:**")
                    for assertion in scenario['assertions']:
                        st.write(f"- {assertion}")
    
    with tab3:
        st.subheader("Generated Test Code")
        
        for filename, content in result.test_files.items():
            with st.expander(f"📄 {filename}"):
                st.code(content, language="typescript" if filename.endswith('.ts') else "javascript")
    
    with tab4:
        st.subheader("Design Analysis")
        
        if 'analysis' in result.design_analysis:
            analysis = result.design_analysis['analysis']
            
            if isinstance(analysis, dict):
                for category, items in analysis.items():
                    with st.expander(f"📋 {category}"):
                        if isinstance(items, list):
                            for item in items:
                                st.write(f"- {item}")
                        else:
                            st.json(items)
            else:
                st.json(analysis)
        
        st.subheader("Token Usage")
        if 'usage' in result.design_analysis:
            usage = result.design_analysis['usage']
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Prompt Tokens", usage.get('prompt_tokens', 0))
            with col2:
                st.metric("Completion Tokens", usage.get('completion_tokens', 0))
            with col3:
                st.metric("Total Tokens", usage.get('total_tokens', 0))
    
    with tab5:
        st.subheader("Export Options")
        
        # Generate ZIP export
        if st.button("📦 Generate ZIP Export"):
            with st.spinner("Creating ZIP file..."):
                generator = TestGenerator(
                    None, None, None, st.session_state.test_config
                )
                zip_bytes = generator.export_to_zip(result)
                
                st.download_button(
                    label="⬇️ Download Test Suite ZIP",
                    data=zip_bytes,
                    file_name=f"test-suite-{result.user_story['id']}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.zip",
                    mime="application/zip"
                )
        
        # Individual file downloads
        st.subheader("Individual Files")
        for filename, content in result.test_files.items():
            st.download_button(
                label=f"📄 {filename}",
                data=content,
                file_name=filename,
                mime="text/plain"
            )


def main():
    """Main application"""
    init_session_state()
    create_sidebar()
    
    # Header
    st.title("🤖 AI-Powered Angular Test Scenario Generator")
    st.markdown("*Generate comprehensive test scenarios from Figma designs and Rally user stories using GPT-4 Vision*")
    
    # Input Section
    st.header("1️⃣ Input Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        figma_url = st.text_input(
            "Figma Design URL",
            placeholder="https://www.figma.com/file/...",
            help="Enter the URL of your Figma design"
        )
        
        if figma_url and st.button("👁️ Preview Figma Design"):
            fetch_and_preview_figma(figma_url)
    
    with col2:
        rally_id = st.text_input(
            "Rally User Story ID",
            placeholder="US12345",
            help="Enter the Rally user story ID"
        )
        
        if rally_id and st.button("📋 Preview User Story"):
            fetch_and_preview_rally(rally_id)
    
    # Additional Context
    context = st.text_area(
        "Additional Context (Optional)",
        placeholder="Add any additional context about the feature, business rules, or specific test requirements...",
        help="This context will help GPT-4 generate more accurate test scenarios"
    )
    
    # Preview Section
    if st.session_state.design_preview or st.session_state.user_story_preview:
        st.header("2️⃣ Preview")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.session_state.design_preview:
                st.subheader("Figma Design")
                st.image(st.session_state.design_preview, use_column_width=True)
        
        with col2:
            if st.session_state.user_story_preview:
                st.subheader("Rally User Story")
                story = st.session_state.user_story_preview
                st.write(f"**ID:** {story['id']}")
                st.write(f"**Name:** {story['name']}")
                st.write(f"**Description:** {story['description']}")
                
                if story['acceptance_criteria']:
                    st.write("**Acceptance Criteria:**")
                    for ac in story['acceptance_criteria']:
                        st.write(f"- {ac}")
    
    # Generation Section
    st.header("3️⃣ Generate Tests")
    
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        if st.button("🚀 Generate Test Scenarios", type="primary", disabled=not (figma_url and rally_id)):
            if figma_url and rally_id:
                result = generate_tests(figma_url, rally_id, context)
                if result:
                    st.balloons()
    
    with col2:
        if st.session_state.generation_result:
            if st.button("🔄 Regenerate"):
                st.session_state.generation_result = None
                st.rerun()
    
    with col3:
        if st.button("🗑️ Clear All"):
            st.session_state.generation_result = None
            st.session_state.design_preview = None
            st.session_state.user_story_preview = None
            st.rerun()
    
    # Results Section
    if st.session_state.generation_result:
        st.header("4️⃣ Results")
        display_generation_results(st.session_state.generation_result)
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: #666;'>
        <p>Built with Streamlit, GPT-4 Vision, and Python | POC Version 1.0</p>
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()