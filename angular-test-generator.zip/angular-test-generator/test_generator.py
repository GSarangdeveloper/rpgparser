"""
Test Generator Module - Orchestrates test generation process
"""

import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
import json
import re
from pathlib import Path
import zipfile
import io

from figma_client import FigmaClient
from rally_client import RallyClient
from gpt4_client import GPT4VisionClient, AnalysisLevel

logger = logging.getLogger(__name__)


@dataclass
class TestGenerationConfig:
    """Configuration for test generation"""
    framework: str = "angular"
    test_style: str = "jasmine"
    test_types: List[str] = field(default_factory=lambda: ["unit", "integration", "e2e"])
    include_accessibility: bool = True
    include_performance: bool = True
    max_scenarios_per_type: int = 10
    output_format: str = "typescript"


@dataclass
class TestGenerationResult:
    """Result of test generation process"""
    scenarios: List[Dict[str, Any]]
    test_files: Dict[str, str]
    design_analysis: Dict[str, Any]
    user_story: Dict[str, Any]
    metadata: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)


class TestGenerator:
    """Orchestrates the test generation process"""
    
    def __init__(self,
                 figma_client: FigmaClient,
                 rally_client: RallyClient,
                 gpt4_client: GPT4VisionClient,
                 config: Optional[TestGenerationConfig] = None):
        """
        Initialize test generator
        
        Args:
            figma_client: Figma API client
            rally_client: Rally API client
            gpt4_client: GPT-4 Vision client
            config: Generation configuration
        """
        self.figma = figma_client
        self.rally = rally_client
        self.gpt4 = gpt4_client
        self.config = config or TestGenerationConfig()
        
    def generate_from_urls(self,
                          figma_url: str,
                          rally_story_id: str,
                          additional_context: Optional[str] = None) -> TestGenerationResult:
        """
        Generate tests from Figma URL and Rally story ID
        
        Args:
            figma_url: Figma design URL
            rally_story_id: Rally user story ID
            additional_context: Optional additional context
            
        Returns:
            Test generation result
        """
        try:
            logger.info(f"Starting test generation for Figma: {figma_url}, Rally: {rally_story_id}")
            
            # Step 1: Fetch Figma design
            logger.info("Fetching Figma design...")
            design_image = self.figma.get_design_screenshot(figma_url)
            
            # Step 2: Fetch Rally user story
            logger.info("Fetching Rally user story...")
            user_story = self.rally.get_user_story(rally_story_id)
            
            # Step 3: Analyze design with GPT-4 Vision
            logger.info("Analyzing design with GPT-4 Vision...")
            design_analysis = self.gpt4.analyze_ui_design(
                design_image,
                AnalysisLevel.TEST_INFERENCE,
                context=additional_context
            )
            
            # Step 4: Generate test scenarios
            logger.info("Generating test scenarios...")
            all_scenarios = []
            
            for test_type in self.config.test_types:
                scenarios = self.gpt4.generate_test_scenarios(
                    design_analysis,
                    user_story,
                    self.config.framework,
                    test_type
                )
                
                # Limit scenarios per type
                scenarios = scenarios[:self.config.max_scenarios_per_type]
                
                # Add test type to each scenario
                for scenario in scenarios:
                    scenario['test_type'] = test_type
                    
                all_scenarios.extend(scenarios)
            
            # Step 5: Generate test code
            logger.info("Generating test code...")
            test_files = self._generate_test_files(all_scenarios, user_story)
            
            # Step 6: Create result
            result = TestGenerationResult(
                scenarios=all_scenarios,
                test_files=test_files,
                design_analysis=design_analysis,
                user_story=user_story,
                metadata={
                    'figma_url': figma_url,
                    'rally_story_id': rally_story_id,
                    'framework': self.config.framework,
                    'test_style': self.config.test_style,
                    'scenario_count': len(all_scenarios),
                    'additional_context': additional_context
                }
            )
            
            logger.info(f"Test generation completed. Generated {len(all_scenarios)} scenarios.")
            return result
            
        except Exception as e:
            logger.error(f"Test generation failed: {e}")
            raise
    
    def _generate_test_files(self, 
                           scenarios: List[Dict[str, Any]], 
                           user_story: Dict[str, Any]) -> Dict[str, str]:
        """
        Generate test files from scenarios
        
        Args:
            scenarios: List of test scenarios
            user_story: User story data
            
        Returns:
            Dictionary of filename -> content
        """
        test_files = {}
        
        # Group scenarios by test type
        scenarios_by_type = {}
        for scenario in scenarios:
            test_type = scenario.get('test_type', 'unit')
            if test_type not in scenarios_by_type:
                scenarios_by_type[test_type] = []
            scenarios_by_type[test_type].append(scenario)
        
        # Generate file for each test type
        for test_type, type_scenarios in scenarios_by_type.items():
            filename = self._generate_filename(user_story, test_type)
            content = self._generate_file_content(type_scenarios, user_story, test_type)
            test_files[filename] = content
        
        # Add test data file if needed
        test_data = self._extract_test_data(scenarios)
        if test_data:
            test_files['test-data.json'] = json.dumps(test_data, indent=2)
        
        # Add helper utilities if framework is Angular
        if self.config.framework == 'angular':
            test_files['test-helpers.ts'] = self._generate_angular_helpers()
        
        return test_files
    
    def _generate_filename(self, user_story: Dict[str, Any], test_type: str) -> str:
        """Generate appropriate filename for test file"""
        
        story_id = user_story.get('id', 'unknown').lower().replace(' ', '-')
        
        if self.config.framework == 'angular':
            if test_type == 'unit':
                return f"{story_id}.spec.ts"
            elif test_type == 'integration':
                return f"{story_id}.integration.spec.ts"
            elif test_type == 'e2e':
                return f"{story_id}.e2e-spec.ts"
        elif self.config.framework == 'react':
            if test_type == 'unit':
                return f"{story_id}.test.tsx"
            elif test_type == 'integration':
                return f"{story_id}.integration.test.tsx"
            elif test_type == 'e2e':
                return f"{story_id}.e2e.test.ts"
        
        return f"{story_id}.{test_type}.test.ts"
    
    def _generate_file_content(self, 
                              scenarios: List[Dict[str, Any]], 
                              user_story: Dict[str, Any],
                              test_type: str) -> str:
        """Generate test file content"""
        
        if self.config.framework == 'angular':
            return self._generate_angular_tests(scenarios, user_story, test_type)
        elif self.config.framework == 'react':
            return self._generate_react_tests(scenarios, user_story, test_type)
        else:
            return self._generate_generic_tests(scenarios, user_story, test_type)
    
    def _generate_angular_tests(self, scenarios: List[Dict[str, Any]], user_story: Dict[str, Any], test_type: str) -> str:
        """Generate Angular test file content"""
        
        imports = self._get_angular_imports(test_type)
        
        test_content = f"""{imports}

describe('{user_story.get("name", "Component")} - {user_story.get("id", "")}', () => {{
"""
        
        # Add setup
        if test_type == 'unit':
            test_content += self._get_angular_unit_setup()
        elif test_type == 'integration':
            test_content += self._get_angular_integration_setup()
        elif test_type == 'e2e':
            test_content += self._get_angular_e2e_setup()
        
        # Add test cases
        for scenario in scenarios:
            test_code = self.gpt4.generate_test_code(
                scenario,
                self.config.framework,
                self.config.test_style
            )
            test_content += f"\n  {self._format_test_code(test_code)}\n"
        
        test_content += "});\n"
        
        return test_content
    
    def _generate_react_tests(self, scenarios: List[Dict[str, Any]], user_story: Dict[str, Any], test_type: str) -> str:
        """Generate React test file content"""
        
        imports = self._get_react_imports(test_type)
        
        test_content = f"""{imports}

describe('{user_story.get("name", "Component")} - {user_story.get("id", "")}', () => {{
"""
        
        # Add test cases
        for scenario in scenarios:
            test_code = self.gpt4.generate_test_code(
                scenario,
                self.config.framework,
                self.config.test_style
            )
            test_content += f"\n  {self._format_test_code(test_code)}\n"
        
        test_content += "});\n"
        
        return test_content
    
    def _generate_generic_tests(self, scenarios: List[Dict[str, Any]], user_story: Dict[str, Any], test_type: str) -> str:
        """Generate generic test file content"""
        
        test_content = f"""// Test Suite: {user_story.get("name", "Component")}
// Story ID: {user_story.get("id", "")}
// Test Type: {test_type}

describe('{user_story.get("name", "Component")}', () => {{
"""
        
        for scenario in scenarios:
            test_content += f"""
  it('should {scenario.get("name", "test scenario")}', () => {{
    // {scenario.get("description", "")}
    
    // Preconditions
"""
            for precondition in scenario.get('preconditions', []):
                test_content += f"    // - {precondition}\n"
            
            test_content += "\n    // Test steps\n"
            for i, step in enumerate(scenario.get('steps', []), 1):
                test_content += f"    // Step {i}: {step.get('action', '')}\n"
                test_content += f"    // Expected: {step.get('expected', '')}\n\n"
            
            test_content += "    // Assertions\n"
            for assertion in scenario.get('assertions', []):
                test_content += f"    // - {assertion}\n"
            
            test_content += "  });\n"
        
        test_content += "});\n"
        
        return test_content
    
    def _get_angular_imports(self, test_type: str) -> str:
        """Get Angular test imports"""
        
        if test_type == 'unit':
            return """import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';"""
        
        elif test_type == 'integration':
            return """import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';"""
        
        elif test_type == 'e2e':
            return """import { browser, by, element, ExpectedConditions as EC } from 'protractor';
import { AppPage } from './app.po';"""
        
        return ""
    
    def _get_react_imports(self, test_type: str) -> str:
        """Get React test imports"""
        
        if test_type in ['unit', 'integration']:
            return """import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import userEvent from '@testing-library/user-event';"""
        
        elif test_type == 'e2e':
            return """import { test, expect } from '@playwright/test';"""
        
        return ""
    
    def _get_angular_unit_setup(self) -> str:
        """Get Angular unit test setup"""
        
        return """  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        RouterTestingModule
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });
"""
    
    def _get_angular_integration_setup(self) -> str:
        """Get Angular integration test setup"""
        
        return """  let fixture: ComponentFixture<TestComponent>;
  let app: TestComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([])
      ],
      declarations: [ TestComponent ]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    app = fixture.componentInstance;
  });
"""
    
    def _get_angular_e2e_setup(self) -> str:
        """Get Angular E2E test setup"""
        
        return """  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });
"""
    
    def _format_test_code(self, code: str) -> str:
        """Format generated test code with proper indentation"""
        
        # Remove leading/trailing whitespace
        code = code.strip()
        
        # Ensure proper indentation
        lines = code.split('\n')
        formatted_lines = []
        
        for line in lines:
            # Skip import statements
            if line.startswith('import'):
                continue
            # Add base indentation for test content
            if line.strip():
                formatted_lines.append('  ' + line)
            else:
                formatted_lines.append('')
        
        return '\n'.join(formatted_lines)
    
    def _extract_test_data(self, scenarios: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Extract test data from scenarios"""
        
        test_data = {
            'valid_inputs': {},
            'invalid_inputs': {},
            'boundary_values': {},
            'mock_responses': {}
        }
        
        for scenario in scenarios:
            scenario_data = scenario.get('test_data', {})
            
            # Merge test data
            for key, value in scenario_data.items():
                if 'valid' in key.lower():
                    test_data['valid_inputs'].update({key: value})
                elif 'invalid' in key.lower():
                    test_data['invalid_inputs'].update({key: value})
                elif 'boundary' in key.lower():
                    test_data['boundary_values'].update({key: value})
                elif 'mock' in key.lower() or 'response' in key.lower():
                    test_data['mock_responses'].update({key: value})
        
        return test_data if any(test_data.values()) else {}
    
    def _generate_angular_helpers(self) -> str:
        """Generate Angular test helper utilities"""
        
        return """// Angular Test Helper Utilities

export class TestHelpers {
  static clickElement(fixture: any, selector: string): void {
    const element = fixture.debugElement.query(By.css(selector));
    element.nativeElement.click();
    fixture.detectChanges();
  }

  static setInputValue(fixture: any, selector: string, value: string): void {
    const input = fixture.debugElement.query(By.css(selector));
    input.nativeElement.value = value;
    input.nativeElement.dispatchEvent(new Event('input'));
    fixture.detectChanges();
  }

  static getElementText(fixture: any, selector: string): string {
    const element = fixture.debugElement.query(By.css(selector));
    return element ? element.nativeElement.textContent.trim() : '';
  }

  static async waitForAsync(fixture: any, condition: () => boolean, timeout = 5000): Promise<void> {
    const startTime = Date.now();
    while (!condition()) {
      if (Date.now() - startTime > timeout) {
        throw new Error('Timeout waiting for condition');
      }
      fixture.detectChanges();
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  static createMockService(methods: string[]): any {
    const mock: any = {};
    methods.forEach(method => {
      mock[method] = jasmine.createSpy(method);
    });
    return mock;
  }
}

export const testData = {
  validEmail: 'test@example.com',
  invalidEmail: 'invalid.email',
  validPassword: 'SecureP@ss123',
  weakPassword: '123',
  validPhone: '+1234567890',
  invalidPhone: '123',
  futureDate: new Date(Date.now() + 86400000),
  pastDate: new Date(Date.now() - 86400000),
  longText: 'a'.repeat(256),
  specialChars: '!@#$%^&*()_+-=[]{}|;:,.<>?',
  sqlInjection: "'; DROP TABLE users; --",
  xssAttempt: '<script>alert("XSS")</script>'
};
"""
    
    def export_to_zip(self, result: TestGenerationResult) -> bytes:
        """
        Export test generation result to ZIP file
        
        Args:
            result: Test generation result
            
        Returns:
            ZIP file bytes
        """
        zip_buffer = io.BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            # Add test files
            for filename, content in result.test_files.items():
                zip_file.writestr(f"tests/{filename}", content)
            
            # Add scenarios as JSON
            scenarios_json = json.dumps(result.scenarios, indent=2)
            zip_file.writestr("scenarios.json", scenarios_json)
            
            # Add analysis report
            report = self._generate_report(result)
            zip_file.writestr("test-generation-report.md", report)
            
            # Add metadata
            metadata = {
                **result.metadata,
                'timestamp': result.timestamp.isoformat(),
                'file_count': len(result.test_files),
                'scenario_count': len(result.scenarios)
            }
            zip_file.writestr("metadata.json", json.dumps(metadata, indent=2))
        
        zip_buffer.seek(0)
        return zip_buffer.getvalue()
    
    def _generate_report(self, result: TestGenerationResult) -> str:
        """Generate markdown report of test generation"""
        
        report = f"""# Test Generation Report

## Summary
- **Generated**: {result.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
- **User Story**: {result.user_story.get('id')} - {result.user_story.get('name')}
- **Framework**: {result.metadata.get('framework')}
- **Test Style**: {result.metadata.get('test_style')}
- **Total Scenarios**: {len(result.scenarios)}
- **Total Test Files**: {len(result.test_files)}

## User Story Details
### Description
{result.user_story.get('description', 'N/A')}

### Acceptance Criteria
"""
        
        for ac in result.user_story.get('acceptance_criteria', []):
            report += f"- {ac}\n"
        
        report += f"""

## Design Analysis
### UI Components Detected
"""
        
        if 'analysis' in result.design_analysis:
            analysis = result.design_analysis['analysis']
            if isinstance(analysis, dict):
                for category, items in analysis.items():
                    report += f"\n#### {category}\n"
                    if isinstance(items, list):
                        for item in items:
                            report += f"- {item}\n"
                    else:
                        report += f"{items}\n"
        
        report += f"""

## Generated Test Scenarios

### By Test Type
"""
        
        # Group scenarios by type
        by_type = {}
        for scenario in result.scenarios:
            test_type = scenario.get('test_type', 'unknown')
            if test_type not in by_type:
                by_type[test_type] = []
            by_type[test_type].append(scenario)
        
        for test_type, scenarios in by_type.items():
            report += f"\n#### {test_type.capitalize()} Tests ({len(scenarios)})\n"
            for scenario in scenarios:
                report += f"- **{scenario.get('name')}**: {scenario.get('description')}\n"
        
        report += f"""

## Generated Files
"""
        
        for filename in result.test_files.keys():
            report += f"- `{filename}`\n"
        
        return report