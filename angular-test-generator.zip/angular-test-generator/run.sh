#!/bin/bash

# AI-Powered Angular Test Scenario Generator - Startup Script

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_color() {
    echo -e "${2}${1}${NC}"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Header
print_color "=====================================" "$GREEN"
print_color "AI-Powered Test Scenario Generator" "$GREEN"
print_color "=====================================" "$GREEN"
echo ""

# Check Python version
print_color "Checking Python version..." "$YELLOW"
if command_exists python3; then
    PYTHON_VERSION=$(python3 --version 2>&1 | grep -Po '(?<=Python )\d+\.\d+')
    REQUIRED_VERSION="3.10"
    
    if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" = "$REQUIRED_VERSION" ]; then
        print_color "✓ Python $PYTHON_VERSION found" "$GREEN"
    else
        print_color "✗ Python $REQUIRED_VERSION or higher required (found $PYTHON_VERSION)" "$RED"
        exit 1
    fi
else
    print_color "✗ Python not found. Please install Python 3.10 or higher" "$RED"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    print_color "Creating virtual environment..." "$YELLOW"
    python3 -m venv venv
    print_color "✓ Virtual environment created" "$GREEN"
fi

# Activate virtual environment
print_color "Activating virtual environment..." "$YELLOW"
source venv/bin/activate
print_color "✓ Virtual environment activated" "$GREEN"

# Install/update dependencies
print_color "Installing dependencies..." "$YELLOW"
pip install -q --upgrade pip
pip install -q -r requirements.txt
print_color "✓ Dependencies installed" "$GREEN"

# Check for .env file
if [ ! -f ".env" ]; then
    print_color "⚠ .env file not found. Creating from template..." "$YELLOW"
    cp .env.example .env
    print_color "Please edit .env file with your API keys" "$YELLOW"
fi

# Source environment variables
if [ -f ".env" ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Check API keys
print_color "Checking API keys..." "$YELLOW"
MISSING_KEYS=""

if [ -z "$OPENAI_API_KEY" ]; then
    MISSING_KEYS="${MISSING_KEYS}OPENAI_API_KEY "
fi

if [ -z "$FIGMA_API_KEY" ]; then
    MISSING_KEYS="${MISSING_KEYS}FIGMA_API_KEY "
fi

if [ -z "$RALLY_API_KEY" ]; then
    MISSING_KEYS="${MISSING_KEYS}RALLY_API_KEY "
fi

if [ -n "$MISSING_KEYS" ]; then
    print_color "⚠ Missing API keys: $MISSING_KEYS" "$YELLOW"
    print_color "Please add them to .env file" "$YELLOW"
else
    print_color "✓ All API keys configured" "$GREEN"
fi

# Menu
echo ""
print_color "Select application to run:" "$GREEN"
print_color "1. Streamlit Web Application (Recommended)" "$NC"
print_color "2. FastAPI MCP Server" "$NC"
print_color "3. Both (in separate terminals)" "$NC"
print_color "4. Run tests" "$NC"
print_color "5. Exit" "$NC"
echo ""

read -p "Enter your choice (1-5): " choice

case $choice in
    1)
        print_color "Starting Streamlit application..." "$GREEN"
        print_color "Opening http://localhost:8501 in your browser..." "$YELLOW"
        
        # Try to open browser
        if command_exists xdg-open; then
            (sleep 3 && xdg-open http://localhost:8501) &
        elif command_exists open; then
            (sleep 3 && open http://localhost:8501) &
        fi
        
        streamlit run app.py
        ;;
    
    2)
        print_color "Starting FastAPI MCP Server..." "$GREEN"
        print_color "Server will be available at http://localhost:8000" "$YELLOW"
        print_color "API docs at http://localhost:8000/docs" "$YELLOW"
        uvicorn mcp_server:app --reload --host 0.0.0.0 --port 8000
        ;;
    
    3)
        print_color "Starting both servers..." "$GREEN"
        
        # Start MCP server in background
        print_color "Starting MCP Server in background..." "$YELLOW"
        uvicorn mcp_server:app --reload --host 0.0.0.0 --port 8000 &
        MCP_PID=$!
        
        # Give MCP server time to start
        sleep 2
        
        # Start Streamlit
        print_color "Starting Streamlit application..." "$YELLOW"
        streamlit run app.py
        
        # Kill MCP server when Streamlit exits
        kill $MCP_PID 2>/dev/null
        ;;
    
    4)
        print_color "Running tests..." "$GREEN"
        pytest tests/ -v --cov=. --cov-report=html
        print_color "Test coverage report generated in htmlcov/index.html" "$GREEN"
        ;;
    
    5)
        print_color "Exiting..." "$GREEN"
        exit 0
        ;;
    
    *)
        print_color "Invalid choice. Please run the script again." "$RED"
        exit 1
        ;;
esac