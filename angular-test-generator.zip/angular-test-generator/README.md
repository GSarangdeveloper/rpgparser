# AI-Powered Angular Test Scenario Generator

An intelligent test scenario generator that combines Figma designs with Rally user stories to automatically create comprehensive Angular test cases using GPT-4 Vision API.

## Features

- **Visual Design Analysis**: Uses GPT-4 Vision to understand UI designs from Figma screenshots
- **Requirements Integration**: Fetches and incorporates Rally user stories and acceptance criteria
- **Comprehensive Test Generation**: Creates unit, integration, and E2E tests
- **Multi-Framework Support**: Supports Angular, React, and Vue testing frameworks
- **Streamlit Web Interface**: User-friendly web application for easy interaction
- **MCP Server Integration**: FastAPI server for Cursor AI tool integration
- **Smart Caching**: Reduces API costs with intelligent response caching
- **Export Options**: Generate ZIP files with complete test suites

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Figma API     │────▶│  GPT-4 Vision   │◀────│   Rally API     │
└─────────────────┘     └─────────────────┘     └─────────────────┘
         │                       │                        │
         └───────────────────────┼────────────────────────┘
                                 │
                     ┌───────────▼───────────┐
                     │   Test Generator      │
                     │     (Python)          │
                     └───────────┬───────────┘
                                 │
                ┌────────────────┼────────────────┐
                │                                 │
    ┌───────────▼──────────┐        ┌────────────▼──────────┐
    │  Streamlit Web App   │        │   FastAPI MCP Server  │
    └──────────────────────┘        └───────────────────────┘
```

## Installation

### Prerequisites

- Python 3.10 or higher
- OpenAI API key with GPT-4 Vision access
- Figma personal access token
- Rally API key

### Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd angular-test-generator
```

2. Create virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Configure environment variables:
```bash
cp .env.example .env
# Edit .env with your API keys
```

## Usage

### Streamlit Web Application

Run the Streamlit application:
```bash
streamlit run app.py
```

Navigate to `http://localhost:8501` in your browser.

#### Using the Application:

1. **Configure API Keys**: Enter your API keys in the sidebar configuration
2. **Input URLs**: Provide Figma design URL and Rally story ID
3. **Set Test Configuration**: Choose framework, test types, and other options
4. **Generate Tests**: Click "Generate Test Scenarios" to create tests
5. **Review Results**: Explore generated scenarios, test code, and analysis
6. **Export**: Download individual files or complete ZIP package

### MCP Server (for Cursor AI Integration)

Run the FastAPI MCP server:
```bash
uvicorn mcp_server:app --reload --host 0.0.0.0 --port 8000
```

The server provides endpoints for:
- `/initialize` - Initialize test generation session
- `/analyze-design` - Analyze Figma designs
- `/fetch-story` - Get Rally user stories
- `/generate` - Generate test scenarios
- `/export/{session_id}` - Export generated tests

### Command Line Usage

```python
from figma_client import FigmaClient
from rally_client import RallyClient
from gpt4_client import GPT4VisionClient
from test_generator import TestGenerator, TestGenerationConfig

# Initialize clients
figma = FigmaClient("your-figma-token")
rally = RallyClient("your-rally-key")
gpt4 = GPT4VisionClient("your-openai-key")

# Configure generation
config = TestGenerationConfig(
    framework="angular",
    test_style="jasmine",
    test_types=["unit", "integration"]
)

# Create generator
generator = TestGenerator(figma, rally, gpt4, config)

# Generate tests
result = generator.generate_from_urls(
    figma_url="https://www.figma.com/file/...",
    rally_story_id="US12345"
)

# Export to ZIP
zip_bytes = generator.export_to_zip(result)
with open("test-suite.zip", "wb") as f:
    f.write(zip_bytes)
```

## Configuration Options

### Test Generation Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `framework` | Testing framework (angular, react, vue) | angular |
| `test_style` | Test syntax style (jasmine, jest, mocha) | jasmine |
| `test_types` | Types of tests to generate | ["unit", "integration"] |
| `include_accessibility` | Generate accessibility tests | true |
| `include_performance` | Generate performance tests | false |
| `max_scenarios_per_type` | Maximum scenarios per test type | 10 |

### GPT-4 Vision Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `model` | GPT-4 model variant | gpt-4-vision-preview |
| `max_tokens` | Maximum response tokens | 4096 |
| `temperature` | Response creativity (0-1) | 0.2 |
| `image_detail` | Image analysis detail level | high |

## API Endpoints (MCP Server)

### POST `/initialize`
Initialize a new test generation session.

**Request:**
```json
{
  "openai_api_key": "sk-...",
  "figma_api_key": "...",
  "rally_api_key": "...",
  "framework": "angular",
  "test_style": "jasmine"
}
```

### POST `/generate`
Generate test scenarios from Figma and Rally.

**Request:**
```json
{
  "session_id": "uuid",
  "figma_url": "https://www.figma.com/file/...",
  "rally_story_id": "US12345",
  "additional_context": "Optional context"
}
```

### GET `/export/{session_id}`
Export generated tests as ZIP or JSON.

**Query Parameters:**
- `format`: "zip" or "json" (default: "zip")

## Generated Test Structure

The generator creates the following test structure:

```
tests/
├── us12345.spec.ts           # Unit tests
├── us12345.integration.spec.ts # Integration tests
├── us12345.e2e-spec.ts       # E2E tests
├── test-data.json            # Test data fixtures
└── test-helpers.ts           # Helper utilities
```

### Example Generated Test

```typescript
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';

describe('Login Component - US12345', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginComponent ]
    }).compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should validate email format', () => {
    const emailInput = fixture.debugElement.query(By.css('#email'));
    emailInput.nativeElement.value = 'invalid.email';
    emailInput.nativeElement.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    
    const errorMessage = fixture.debugElement.query(By.css('.error-message'));
    expect(errorMessage.nativeElement.textContent).toContain('Invalid email');
  });
});
```

## Cost Optimization

The system implements several cost optimization strategies:

1. **Caching**: 15-minute cache for identical requests
2. **Token Management**: Optimized prompts to minimize token usage
3. **Batch Processing**: Groups similar operations
4. **Image Compression**: Reduces image size before GPT-4 Vision processing

Estimated costs per generation:
- GPT-4 Vision analysis: ~$0.10-$0.20
- Test scenario generation: ~$0.05-$0.10
- **Total per run**: ~$0.15-$0.30

## Troubleshooting

### Common Issues

1. **API Key Errors**
   - Ensure all API keys are correctly set in `.env`
   - Verify API key permissions and quotas

2. **Figma Access Issues**
   - Check Figma token has read access
   - Ensure Figma file is not restricted

3. **Rally Connection Problems**
   - Verify Rally workspace and project IDs
   - Check network connectivity to Rally

4. **GPT-4 Rate Limits**
   - Implement retry logic with exponential backoff
   - Consider upgrading OpenAI tier for higher limits

## Development

### Running Tests

```bash
pytest tests/ -v --cov=.
```

### Code Formatting

```bash
black .
pylint *.py
mypy *.py
```

### Building Docker Image

```bash
docker build -t angular-test-generator .
docker run -p 8501:8501 -p 8000:8000 angular-test-generator
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT License - See LICENSE file for details

## Support

For issues and questions:
- Create an issue on GitHub
- Contact the development team
- Check the documentation

## Roadmap

- [ ] Support for additional testing frameworks (Cypress, Playwright)
- [ ] Integration with CI/CD pipelines
- [ ] Real-time collaboration features
- [ ] Advanced test data generation
- [ ] Visual regression testing support
- [ ] Performance testing capabilities
- [ ] Multi-language support

## Acknowledgments

- OpenAI for GPT-4 Vision API
- Streamlit for the web framework
- FastAPI for the API server
- The open-source community