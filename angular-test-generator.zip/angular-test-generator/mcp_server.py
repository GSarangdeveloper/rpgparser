"""
FastAPI MCP Server for Cursor AI Integration
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List, AsyncGenerator
import asyncio
import json
import logging
from datetime import datetime
import uuid
from contextlib import asynccontextmanager

from figma_client import FigmaClient
from rally_client import RallyClient
from gpt4_client import GPT4VisionClient, AnalysisLevel
from test_generator import TestGenerator, TestGenerationConfig

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global storage for active sessions
sessions: Dict[str, Dict[str, Any]] = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle"""
    logger.info("MCP Server starting up...")
    yield
    logger.info("MCP Server shutting down...")
    sessions.clear()


# Initialize FastAPI app
app = FastAPI(
    title="Test Generator MCP Server",
    description="MCP Server for AI-powered test generation from Figma and Rally",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Pydantic models for requests/responses
class InitializeRequest(BaseModel):
    """Request model for initialization"""
    openai_api_key: str = Field(..., description="OpenAI API key")
    figma_api_key: str = Field(..., description="Figma API key")
    rally_api_key: str = Field(..., description="Rally API key")
    framework: str = Field("angular", description="Testing framework")
    test_style: str = Field("jasmine", description="Test style")
    test_types: List[str] = Field(["unit", "integration"], description="Test types to generate")


class GenerateRequest(BaseModel):
    """Request model for test generation"""
    session_id: str = Field(..., description="Session ID")
    figma_url: str = Field(..., description="Figma design URL")
    rally_story_id: str = Field(..., description="Rally user story ID")
    additional_context: Optional[str] = Field(None, description="Additional context")


class AnalyzeDesignRequest(BaseModel):
    """Request model for design analysis"""
    session_id: str = Field(..., description="Session ID")
    figma_url: str = Field(..., description="Figma design URL")
    analysis_level: str = Field("test_inference", description="Analysis level")


class SessionResponse(BaseModel):
    """Response model for session operations"""
    session_id: str
    status: str
    message: str
    data: Optional[Dict[str, Any]] = None


class MCPToolResponse(BaseModel):
    """MCP tool response format"""
    tool: str
    status: str
    result: Any


# MCP Tool definitions
MCP_TOOLS = {
    "initialize_generator": {
        "name": "initialize_generator",
        "description": "Initialize test generator with API keys",
        "parameters": {
            "type": "object",
            "properties": {
                "openai_api_key": {"type": "string"},
                "figma_api_key": {"type": "string"},
                "rally_api_key": {"type": "string"},
                "framework": {"type": "string"},
                "test_style": {"type": "string"}
            },
            "required": ["openai_api_key", "figma_api_key", "rally_api_key"]
        }
    },
    "analyze_figma_design": {
        "name": "analyze_figma_design",
        "description": "Analyze a Figma design using GPT-4 Vision",
        "parameters": {
            "type": "object",
            "properties": {
                "session_id": {"type": "string"},
                "figma_url": {"type": "string"},
                "analysis_level": {"type": "string"}
            },
            "required": ["session_id", "figma_url"]
        }
    },
    "fetch_rally_story": {
        "name": "fetch_rally_story",
        "description": "Fetch Rally user story details",
        "parameters": {
            "type": "object",
            "properties": {
                "session_id": {"type": "string"},
                "story_id": {"type": "string"}
            },
            "required": ["session_id", "story_id"]
        }
    },
    "generate_test_scenarios": {
        "name": "generate_test_scenarios",
        "description": "Generate test scenarios from Figma and Rally",
        "parameters": {
            "type": "object",
            "properties": {
                "session_id": {"type": "string"},
                "figma_url": {"type": "string"},
                "rally_story_id": {"type": "string"},
                "additional_context": {"type": "string"}
            },
            "required": ["session_id", "figma_url", "rally_story_id"]
        }
    },
    "export_tests": {
        "name": "export_tests",
        "description": "Export generated tests",
        "parameters": {
            "type": "object",
            "properties": {
                "session_id": {"type": "string"},
                "format": {"type": "string"}
            },
            "required": ["session_id"]
        }
    }
}


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "Test Generator MCP Server",
        "version": "1.0.0",
        "status": "running",
        "tools": list(MCP_TOOLS.keys())
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "active_sessions": len(sessions)
    }


@app.get("/tools")
async def get_tools():
    """Get available MCP tools"""
    return {"tools": MCP_TOOLS}


@app.post("/initialize", response_model=SessionResponse)
async def initialize_session(request: InitializeRequest):
    """Initialize a new test generation session"""
    try:
        session_id = str(uuid.uuid4())
        
        # Create clients
        figma_client = FigmaClient(request.figma_api_key)
        rally_client = RallyClient(request.rally_api_key)
        gpt4_client = GPT4VisionClient(request.openai_api_key)
        
        # Create configuration
        config = TestGenerationConfig(
            framework=request.framework,
            test_style=request.test_style,
            test_types=request.test_types
        )
        
        # Create test generator
        generator = TestGenerator(figma_client, rally_client, gpt4_client, config)
        
        # Store session
        sessions[session_id] = {
            "generator": generator,
            "config": config,
            "created_at": datetime.now(),
            "results": None
        }
        
        logger.info(f"Session initialized: {session_id}")
        
        return SessionResponse(
            session_id=session_id,
            status="success",
            message="Session initialized successfully",
            data={"framework": request.framework, "test_style": request.test_style}
        )
    
    except Exception as e:
        logger.error(f"Failed to initialize session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/analyze-design")
async def analyze_design(request: AnalyzeDesignRequest):
    """Analyze a Figma design"""
    try:
        session = sessions.get(request.session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        generator = session["generator"]
        
        # Fetch Figma design
        design_image = generator.figma.get_design_screenshot(request.figma_url)
        
        # Analyze with GPT-4 Vision
        analysis_level = AnalysisLevel[request.analysis_level.upper()]
        analysis = generator.gpt4.analyze_ui_design(design_image, analysis_level)
        
        return {
            "status": "success",
            "analysis": analysis,
            "timestamp": datetime.now().isoformat()
        }
    
    except Exception as e:
        logger.error(f"Failed to analyze design: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/fetch-story")
async def fetch_rally_story(session_id: str, story_id: str):
    """Fetch Rally user story"""
    try:
        session = sessions.get(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        generator = session["generator"]
        story = generator.rally.get_user_story(story_id)
        
        return {
            "status": "success",
            "story": story,
            "timestamp": datetime.now().isoformat()
        }
    
    except Exception as e:
        logger.error(f"Failed to fetch story: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/generate")
async def generate_tests(request: GenerateRequest):
    """Generate test scenarios"""
    try:
        session = sessions.get(request.session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        generator = session["generator"]
        
        # Generate tests
        result = generator.generate_from_urls(
            request.figma_url,
            request.rally_story_id,
            request.additional_context
        )
        
        # Store result in session
        session["results"] = result
        
        return {
            "status": "success",
            "scenarios_count": len(result.scenarios),
            "files_count": len(result.test_files),
            "timestamp": result.timestamp.isoformat()
        }
    
    except Exception as e:
        logger.error(f"Failed to generate tests: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/results/{session_id}")
async def get_results(session_id: str):
    """Get generation results"""
    try:
        session = sessions.get(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        if not session.get("results"):
            return {"status": "pending", "message": "No results available yet"}
        
        result = session["results"]
        
        return {
            "status": "success",
            "scenarios": result.scenarios,
            "test_files": result.test_files,
            "metadata": result.metadata,
            "timestamp": result.timestamp.isoformat()
        }
    
    except Exception as e:
        logger.error(f"Failed to get results: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/export/{session_id}")
async def export_tests(session_id: str, format: str = "zip"):
    """Export generated tests"""
    try:
        session = sessions.get(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        if not session.get("results"):
            raise HTTPException(status_code=400, detail="No results to export")
        
        result = session["results"]
        generator = session["generator"]
        
        if format == "zip":
            zip_bytes = generator.export_to_zip(result)
            return StreamingResponse(
                io.BytesIO(zip_bytes),
                media_type="application/zip",
                headers={
                    "Content-Disposition": f"attachment; filename=test-suite-{datetime.now().strftime('%Y%m%d-%H%M%S')}.zip"
                }
            )
        elif format == "json":
            return {
                "scenarios": result.scenarios,
                "test_files": result.test_files,
                "metadata": result.metadata
            }
        else:
            raise HTTPException(status_code=400, detail="Unsupported export format")
    
    except Exception as e:
        logger.error(f"Failed to export tests: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/stream-generate")
async def stream_generation(request: GenerateRequest):
    """Stream test generation progress"""
    
    async def generate_stream() -> AsyncGenerator[str, None]:
        try:
            session = sessions.get(request.session_id)
            if not session:
                yield f"data: {json.dumps({'error': 'Session not found'})}\n\n"
                return
            
            generator = session["generator"]
            
            # Stream progress updates
            yield f"data: {json.dumps({'status': 'starting', 'message': 'Initializing test generation...'})}\n\n"
            await asyncio.sleep(0.5)
            
            yield f"data: {json.dumps({'status': 'fetching_figma', 'message': 'Fetching Figma design...'})}\n\n"
            design_image = generator.figma.get_design_screenshot(request.figma_url)
            await asyncio.sleep(0.5)
            
            yield f"data: {json.dumps({'status': 'fetching_rally', 'message': 'Fetching Rally user story...'})}\n\n"
            user_story = generator.rally.get_user_story(request.rally_story_id)
            await asyncio.sleep(0.5)
            
            yield f"data: {json.dumps({'status': 'analyzing', 'message': 'Analyzing design with GPT-4 Vision...'})}\n\n"
            design_analysis = generator.gpt4.analyze_ui_design(
                design_image,
                AnalysisLevel.TEST_INFERENCE,
                context=request.additional_context
            )
            await asyncio.sleep(0.5)
            
            yield f"data: {json.dumps({'status': 'generating', 'message': 'Generating test scenarios...'})}\n\n"
            
            all_scenarios = []
            for test_type in session["config"].test_types:
                scenarios = generator.gpt4.generate_test_scenarios(
                    design_analysis,
                    user_story,
                    session["config"].framework,
                    test_type
                )
                all_scenarios.extend(scenarios)
                
                yield f"data: {json.dumps({'status': 'progress', 'message': f'Generated {len(scenarios)} {test_type} scenarios'})}\n\n"
                await asyncio.sleep(0.5)
            
            yield f"data: {json.dumps({'status': 'completed', 'message': f'Successfully generated {len(all_scenarios)} test scenarios'})}\n\n"
            
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )


@app.delete("/session/{session_id}")
async def delete_session(session_id: str):
    """Delete a session"""
    try:
        if session_id in sessions:
            del sessions[session_id]
            logger.info(f"Session deleted: {session_id}")
            return {"status": "success", "message": "Session deleted"}
        else:
            raise HTTPException(status_code=404, detail="Session not found")
    
    except Exception as e:
        logger.error(f"Failed to delete session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/sessions")
async def list_sessions():
    """List all active sessions"""
    return {
        "sessions": [
            {
                "id": sid,
                "created_at": session["created_at"].isoformat(),
                "has_results": session.get("results") is not None
            }
            for sid, session in sessions.items()
        ]
    }


# MCP Protocol endpoints
@app.post("/mcp/execute")
async def execute_mcp_tool(request: Request):
    """Execute MCP tool"""
    try:
        body = await request.json()
        tool_name = body.get("tool")
        parameters = body.get("parameters", {})
        
        if tool_name not in MCP_TOOLS:
            raise HTTPException(status_code=400, detail=f"Unknown tool: {tool_name}")
        
        # Execute tool based on name
        if tool_name == "initialize_generator":
            result = await initialize_session(InitializeRequest(**parameters))
            return MCPToolResponse(tool=tool_name, status="success", result=result.dict())
        
        elif tool_name == "analyze_figma_design":
            result = await analyze_design(AnalyzeDesignRequest(**parameters))
            return MCPToolResponse(tool=tool_name, status="success", result=result)
        
        elif tool_name == "fetch_rally_story":
            result = await fetch_rally_story(
                parameters["session_id"],
                parameters["story_id"]
            )
            return MCPToolResponse(tool=tool_name, status="success", result=result)
        
        elif tool_name == "generate_test_scenarios":
            result = await generate_tests(GenerateRequest(**parameters))
            return MCPToolResponse(tool=tool_name, status="success", result=result)
        
        elif tool_name == "export_tests":
            result = await get_results(parameters["session_id"])
            return MCPToolResponse(tool=tool_name, status="success", result=result)
        
        else:
            raise HTTPException(status_code=400, detail=f"Tool not implemented: {tool_name}")
    
    except Exception as e:
        logger.error(f"MCP execution failed: {e}")
        return MCPToolResponse(tool=tool_name, status="error", result={"error": str(e)})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)