"""
Validation utilities for input data
"""

import re
from typing import Optional, Dict, Any
from urllib.parse import urlparse


def validate_figma_url(url: str) -> bool:
    """
    Validate Figma URL format
    
    Args:
        url: Figma URL to validate
        
    Returns:
        True if valid Figma URL
    """
    if not url:
        return False
    
    try:
        parsed = urlparse(url)
        
        # Check if it's a Figma domain
        if parsed.hostname not in ['www.figma.com', 'figma.com']:
            return False
        
        # Check if path contains file
        if '/file/' not in parsed.path and '/proto/' not in parsed.path:
            return False
        
        return True
    except Exception:
        return False


def validate_rally_story_id(story_id: str) -> bool:
    """
    Validate Rally story ID format
    
    Args:
        story_id: Rally story ID (e.g., US12345, DE67890)
        
    Returns:
        True if valid Rally ID
    """
    if not story_id:
        return False
    
    # Rally IDs typically follow pattern: US##### or DE#####
    pattern = r'^(US|DE|TA|TC)\d{3,7}$'
    return bool(re.match(pattern, story_id.upper()))


def validate_api_key(key: str, key_type: str) -> bool:
    """
    Basic validation for API keys
    
    Args:
        key: API key string
        key_type: Type of key (openai, figma, rally)
        
    Returns:
        True if key appears valid
    """
    if not key or not isinstance(key, str):
        return False
    
    # Remove whitespace
    key = key.strip()
    
    # Check minimum length
    if len(key) < 10:
        return False
    
    # Specific validations per key type
    if key_type == 'openai':
        # OpenAI keys typically start with 'sk-'
        return key.startswith('sk-') and len(key) > 40
    
    elif key_type == 'figma':
        # Figma tokens are typically long alphanumeric strings
        return len(key) > 20 and key.replace('-', '').replace('_', '').isalnum()
    
    elif key_type == 'rally':
        # Rally keys are typically base64 encoded
        return len(key) > 20
    
    return True


def validate_test_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate test generation configuration
    
    Args:
        config: Configuration dictionary
        
    Returns:
        Validated configuration with defaults
    """
    validated = {
        'framework': 'angular',
        'test_style': 'jasmine',
        'test_types': ['unit', 'integration'],
        'include_accessibility': True,
        'include_performance': False,
        'max_scenarios_per_type': 10
    }
    
    if config:
        # Validate framework
        if config.get('framework') in ['angular', 'react', 'vue']:
            validated['framework'] = config['framework']
        
        # Validate test style
        if config.get('test_style') in ['jasmine', 'jest', 'mocha']:
            validated['test_style'] = config['test_style']
        
        # Validate test types
        if isinstance(config.get('test_types'), list):
            valid_types = [t for t in config['test_types'] if t in ['unit', 'integration', 'e2e']]
            if valid_types:
                validated['test_types'] = valid_types
        
        # Boolean flags
        if isinstance(config.get('include_accessibility'), bool):
            validated['include_accessibility'] = config['include_accessibility']
        
        if isinstance(config.get('include_performance'), bool):
            validated['include_performance'] = config['include_performance']
        
        # Numeric values
        if isinstance(config.get('max_scenarios_per_type'), int):
            validated['max_scenarios_per_type'] = min(max(1, config['max_scenarios_per_type']), 50)
    
    return validated


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename for safe file system usage
    
    Args:
        filename: Original filename
        
    Returns:
        Sanitized filename
    """
    # Remove or replace invalid characters
    invalid_chars = '<>:"|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    
    # Remove leading/trailing dots and spaces
    filename = filename.strip('. ')
    
    # Limit length
    if len(filename) > 200:
        filename = filename[:200]
    
    # Ensure it's not empty
    if not filename:
        filename = 'unnamed'
    
    return filename


def validate_json_response(response: str) -> Optional[Dict[str, Any]]:
    """
    Validate and parse JSON response from GPT-4
    
    Args:
        response: Response string that might contain JSON
        
    Returns:
        Parsed JSON or None if invalid
    """
    import json
    
    # Try direct parsing
    try:
        return json.loads(response)
    except json.JSONDecodeError:
        pass
    
    # Try to extract JSON from markdown code blocks
    import re
    json_pattern = r'```json\s*(.*?)\s*```'
    matches = re.findall(json_pattern, response, re.DOTALL)
    
    if matches:
        try:
            return json.loads(matches[0])
        except json.JSONDecodeError:
            pass
    
    # Try to find JSON-like structure
    json_start = response.find('{')
    json_end = response.rfind('}') + 1
    
    if json_start >= 0 and json_end > json_start:
        try:
            return json.loads(response[json_start:json_end])
        except json.JSONDecodeError:
            pass
    
    return None