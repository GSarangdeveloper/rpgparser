"""
Helper utilities for the test generator
"""

import hashlib
import json
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class Cache:
    """Simple in-memory cache with TTL"""
    
    def __init__(self, default_ttl: int = 900):  # 15 minutes default
        """
        Initialize cache
        
        Args:
            default_ttl: Default TTL in seconds
        """
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.default_ttl = default_ttl
    
    def _generate_key(self, *args) -> str:
        """Generate cache key from arguments"""
        key_str = json.dumps(args, sort_keys=True)
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def get(self, *args) -> Optional[Any]:
        """Get value from cache"""
        key = self._generate_key(*args)
        
        if key in self.cache:
            entry = self.cache[key]
            if datetime.now() < entry['expires']:
                logger.debug(f"Cache hit for key: {key}")
                return entry['value']
            else:
                # Expired, remove from cache
                del self.cache[key]
                logger.debug(f"Cache expired for key: {key}")
        
        return None
    
    def set(self, value: Any, ttl: Optional[int] = None, *args):
        """Set value in cache"""
        key = self._generate_key(*args)
        ttl = ttl or self.default_ttl
        
        self.cache[key] = {
            'value': value,
            'expires': datetime.now() + timedelta(seconds=ttl)
        }
        logger.debug(f"Cache set for key: {key}, TTL: {ttl}s")
    
    def clear(self):
        """Clear all cache entries"""
        self.cache.clear()
        logger.debug("Cache cleared")
    
    def cleanup(self):
        """Remove expired entries"""
        now = datetime.now()
        expired_keys = [
            key for key, entry in self.cache.items()
            if now >= entry['expires']
        ]
        
        for key in expired_keys:
            del self.cache[key]
        
        if expired_keys:
            logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")


def format_test_name(name: str, test_type: str = "") -> str:
    """
    Format test name according to conventions
    
    Args:
        name: Original name
        test_type: Type of test (unit, integration, e2e)
        
    Returns:
        Formatted test name
    """
    # Convert to lowercase and replace spaces with hyphens
    formatted = name.lower().replace(' ', '-')
    
    # Remove special characters
    import re
    formatted = re.sub(r'[^a-z0-9\-_]', '', formatted)
    
    # Add test type suffix if provided
    if test_type:
        if test_type == 'unit':
            formatted += '.spec'
        elif test_type == 'integration':
            formatted += '.integration.spec'
        elif test_type == 'e2e':
            formatted += '.e2e-spec'
    
    return formatted


def estimate_tokens(text: str) -> int:
    """
    Estimate token count for text (rough approximation)
    
    Args:
        text: Input text
        
    Returns:
        Estimated token count
    """
    # Rough estimation: 1 token ≈ 4 characters
    return len(text) // 4


def calculate_cost(input_tokens: int, output_tokens: int, model: str = "gpt-4") -> float:
    """
    Calculate estimated API cost
    
    Args:
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
        model: Model name
        
    Returns:
        Estimated cost in USD
    """
    # Pricing as of 2024 (may need updates)
    pricing = {
        "gpt-4": {
            "input": 0.03,  # per 1K tokens
            "output": 0.06   # per 1K tokens
        },
        "gpt-4-vision-preview": {
            "input": 0.01,
            "output": 0.03
        },
        "gpt-4-turbo-preview": {
            "input": 0.01,
            "output": 0.03
        }
    }
    
    model_pricing = pricing.get(model, pricing["gpt-4"])
    
    input_cost = (input_tokens / 1000) * model_pricing["input"]
    output_cost = (output_tokens / 1000) * model_pricing["output"]
    
    return round(input_cost + output_cost, 4)


def merge_test_scenarios(scenarios1: List[Dict], scenarios2: List[Dict]) -> List[Dict]:
    """
    Merge two lists of test scenarios, removing duplicates
    
    Args:
        scenarios1: First list of scenarios
        scenarios2: Second list of scenarios
        
    Returns:
        Merged list without duplicates
    """
    merged = list(scenarios1)
    
    # Create set of scenario identifiers from first list
    existing_ids = {
        (s.get('name', ''), s.get('test_type', ''))
        for s in scenarios1
    }
    
    # Add non-duplicate scenarios from second list
    for scenario in scenarios2:
        scenario_id = (scenario.get('name', ''), scenario.get('test_type', ''))
        if scenario_id not in existing_ids:
            merged.append(scenario)
            existing_ids.add(scenario_id)
    
    return merged


def group_scenarios_by_component(scenarios: List[Dict]) -> Dict[str, List[Dict]]:
    """
    Group test scenarios by component
    
    Args:
        scenarios: List of test scenarios
        
    Returns:
        Dictionary with component names as keys
    """
    grouped = {}
    
    for scenario in scenarios:
        # Try to extract component name from scenario
        component = scenario.get('component', 'general')
        
        if component not in grouped:
            grouped[component] = []
        
        grouped[component].append(scenario)
    
    return grouped


def extract_test_data_from_scenarios(scenarios: List[Dict]) -> Dict[str, Any]:
    """
    Extract and consolidate test data from scenarios
    
    Args:
        scenarios: List of test scenarios
        
    Returns:
        Consolidated test data
    """
    test_data = {
        'valid_inputs': {},
        'invalid_inputs': {},
        'boundary_values': {},
        'mock_data': {},
        'error_messages': []
    }
    
    for scenario in scenarios:
        scenario_data = scenario.get('test_data', {})
        
        # Merge valid inputs
        if 'valid' in scenario_data:
            test_data['valid_inputs'].update(scenario_data['valid'])
        
        # Merge invalid inputs
        if 'invalid' in scenario_data:
            test_data['invalid_inputs'].update(scenario_data['invalid'])
        
        # Merge boundary values
        if 'boundary' in scenario_data:
            test_data['boundary_values'].update(scenario_data['boundary'])
        
        # Collect error messages
        for assertion in scenario.get('assertions', []):
            if 'error' in assertion.lower():
                test_data['error_messages'].append(assertion)
    
    # Remove duplicates from error messages
    test_data['error_messages'] = list(set(test_data['error_messages']))
    
    return test_data


def generate_test_report_summary(result: Any) -> str:
    """
    Generate a summary report from test generation result
    
    Args:
        result: TestGenerationResult object
        
    Returns:
        Summary string
    """
    summary_lines = [
        f"Test Generation Summary",
        f"=" * 50,
        f"Generated: {result.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
        f"User Story: {result.user_story.get('id')} - {result.user_story.get('name')}",
        f"Total Scenarios: {len(result.scenarios)}",
        f"Total Test Files: {len(result.test_files)}",
        f"Framework: {result.metadata.get('framework')}",
        f"Test Style: {result.metadata.get('test_style')}",
        ""
    ]
    
    # Count scenarios by type
    type_counts = {}
    for scenario in result.scenarios:
        test_type = scenario.get('test_type', 'unknown')
        type_counts[test_type] = type_counts.get(test_type, 0) + 1
    
    summary_lines.append("Scenarios by Type:")
    for test_type, count in type_counts.items():
        summary_lines.append(f"  - {test_type}: {count}")
    
    summary_lines.append("")
    summary_lines.append("Generated Files:")
    for filename in result.test_files.keys():
        summary_lines.append(f"  - {filename}")
    
    return "\n".join(summary_lines)


def create_test_data_fixture(test_data: Dict[str, Any], framework: str) -> str:
    """
    Create test data fixture file content
    
    Args:
        test_data: Test data dictionary
        framework: Testing framework
        
    Returns:
        Fixture file content
    """
    if framework == 'angular':
        return f"""// Test Data Fixtures
export const testData = {json.dumps(test_data, indent=2)};

export const mockApiResponses = {{
  success: {{
    status: 200,
    data: {{
      message: 'Success',
      result: []
    }}
  }},
  error: {{
    status: 400,
    data: {{
      message: 'Error',
      errors: []
    }}
  }}
}};

export const testHelpers = {{
  generateRandomEmail: () => `test${{Date.now()}}@example.com`,
  generateRandomString: (length: number) => Math.random().toString(36).substring(2, 2 + length),
  waitForElement: (selector: string, timeout = 5000) => {{
    return new Promise((resolve, reject) => {{
      const start = Date.now();
      const interval = setInterval(() => {{
        const element = document.querySelector(selector);
        if (element) {{
          clearInterval(interval);
          resolve(element);
        }} else if (Date.now() - start > timeout) {{
          clearInterval(interval);
          reject(new Error(`Element ${{selector}} not found within ${{timeout}}ms`));
        }}
      }}, 100);
    }});
  }}
}};
"""
    
    elif framework == 'react':
        return f"""// Test Data Fixtures
export const testData = {json.dumps(test_data, indent=2)};

export const renderWithProviders = (component, {{ initialState = {{}}, ...renderOptions }} = {{}}) => {{
  // Add any providers needed for testing
  return render(component, renderOptions);
}};

export const mockApiCall = (data, delay = 0) => {{
  return new Promise((resolve) => {{
    setTimeout(() => resolve(data), delay);
  }});
}};
"""
    
    else:
        return f"""// Test Data Fixtures
export const testData = {json.dumps(test_data, indent=2)};
"""