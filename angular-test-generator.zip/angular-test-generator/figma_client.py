"""
Figma API Client for fetching design screenshots
"""

import requests
from typing import Optional, Dict, Any
from PIL import Image
from io import BytesIO
import logging
from urllib.parse import urlparse
import time
from functools import wraps

logger = logging.getLogger(__name__)


def retry_on_failure(max_retries: int = 3, delay: float = 1.0):
    """Decorator for retry logic with exponential backoff"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    wait_time = delay * (2 ** attempt)
                    logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
            return None
        return wrapper
    return decorator


class FigmaClient:
    """Client for interacting with Figma API"""
    
    def __init__(self, api_key: str):
        """
        Initialize Figma client
        
        Args:
            api_key: Figma API access token
        """
        self.api_key = api_key
        self.base_url = "https://api.figma.com/v1"
        self.headers = {
            "X-Figma-Token": api_key
        }
        
    def parse_figma_url(self, url: str) -> Dict[str, str]:
        """
        Parse Figma URL to extract file key and node ID
        
        Args:
            url: Figma file or node URL
            
        Returns:
            Dictionary with file_key and optional node_id
        """
        parsed = urlparse(url)
        path_parts = parsed.path.strip('/').split('/')
        
        if len(path_parts) < 2:
            raise ValueError("Invalid Figma URL format")
        
        file_key = path_parts[1]
        
        # Check if node-id is in the URL
        node_id = None
        if 'node-id=' in parsed.fragment:
            node_id = parsed.fragment.split('node-id=')[1].split('&')[0]
            
        return {
            'file_key': file_key,
            'node_id': node_id
        }
    
    @retry_on_failure(max_retries=3)
    def get_file_info(self, file_key: str) -> Dict[str, Any]:
        """
        Get file information from Figma
        
        Args:
            file_key: Figma file key
            
        Returns:
            File metadata
        """
        url = f"{self.base_url}/files/{file_key}"
        response = requests.get(url, headers=self.headers)
        response.raise_for_status()
        return response.json()
    
    @retry_on_failure(max_retries=3)
    def get_image(self, 
                  file_key: str, 
                  node_id: Optional[str] = None,
                  scale: float = 2.0,
                  format: str = "png") -> bytes:
        """
        Get image export from Figma
        
        Args:
            file_key: Figma file key
            node_id: Optional specific node/frame ID
            scale: Image scale (1-4)
            format: Image format (png, jpg, svg, pdf)
            
        Returns:
            Image bytes
        """
        url = f"{self.base_url}/images/{file_key}"
        
        params = {
            "scale": scale,
            "format": format
        }
        
        if node_id:
            params["ids"] = node_id
            
        # Get image URLs
        response = requests.get(url, headers=self.headers, params=params)
        response.raise_for_status()
        
        data = response.json()
        
        if data.get("err"):
            raise Exception(f"Figma API error: {data['err']}")
        
        # Get the first image URL
        images = data.get("images", {})
        if not images:
            raise Exception("No images returned from Figma")
        
        image_url = list(images.values())[0]
        
        # Download the image
        image_response = requests.get(image_url)
        image_response.raise_for_status()
        
        return image_response.content
    
    def get_design_screenshot(self, url: str) -> Image.Image:
        """
        Get a screenshot of a Figma design from URL
        
        Args:
            url: Figma URL
            
        Returns:
            PIL Image object
        """
        try:
            # Parse the URL
            parsed = self.parse_figma_url(url)
            
            # Get the image
            image_bytes = self.get_image(
                file_key=parsed['file_key'],
                node_id=parsed.get('node_id'),
                scale=2.0,
                format='png'
            )
            
            # Convert to PIL Image
            image = Image.open(BytesIO(image_bytes))
            
            logger.info(f"Successfully fetched Figma design: {image.size}")
            return image
            
        except Exception as e:
            logger.error(f"Failed to fetch Figma design: {e}")
            raise
    
    def get_component_details(self, file_key: str, node_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific component
        
        Args:
            file_key: Figma file key
            node_id: Component node ID
            
        Returns:
            Component details
        """
        try:
            file_data = self.get_file_info(file_key)
            
            # Navigate to find the specific node
            def find_node(node: Dict, target_id: str) -> Optional[Dict]:
                if node.get('id') == target_id:
                    return node
                for child in node.get('children', []):
                    result = find_node(child, target_id)
                    if result:
                        return result
                return None
            
            component = find_node(file_data['document'], node_id)
            
            if not component:
                raise ValueError(f"Component {node_id} not found")
            
            return {
                'name': component.get('name'),
                'type': component.get('type'),
                'visible': component.get('visible', True),
                'bounds': component.get('absoluteBoundingBox'),
                'children_count': len(component.get('children', []))
            }
            
        except Exception as e:
            logger.error(f"Failed to get component details: {e}")
            raise