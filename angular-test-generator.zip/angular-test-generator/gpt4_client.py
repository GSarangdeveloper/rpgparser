"""
GPT-4 Vision API Client for UI analysis and test generation
"""

import openai
from typing import Optional, Dict, Any, List, Union
import base64
from PIL import Image
import io
import json
import logging
import tiktoken
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class AnalysisLevel(Enum):
    """Different levels of UI analysis"""
    ELEMENT_DETECTION = "element_detection"
    CONTEXT_UNDERSTANDING = "context_understanding"
    INTERACTION_MAPPING = "interaction_mapping"
    TEST_INFERENCE = "test_inference"


@dataclass
class GPT4Response:
    """Structured response from GPT-4"""
    content: str
    usage: Dict[str, int]
    model: str
    finish_reason: str


class GPT4VisionClient:
    """Client for GPT-4 Vision API interactions"""
    
    def __init__(self, api_key: str, model: str = "gpt-4-vision-preview"):
        """
        Initialize GPT-4 Vision client
        
        Args:
            api_key: OpenAI API key
            model: Model to use (default: gpt-4-vision-preview)
        """
        self.client = openai.OpenAI(api_key=api_key)
        self.model = model
        self.tokenizer = tiktoken.encoding_for_model("gpt-4")
        
    def encode_image(self, image: Union[Image.Image, bytes]) -> str:
        """
        Encode image to base64 for GPT-4 Vision
        
        Args:
            image: PIL Image or bytes
            
        Returns:
            Base64 encoded string
        """
        if isinstance(image, Image.Image):
            # Convert PIL Image to bytes
            buffer = io.BytesIO()
            image.save(buffer, format='PNG')
            image_bytes = buffer.getvalue()
        else:
            image_bytes = image
            
        return base64.b64encode(image_bytes).decode('utf-8')
    
    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text
        
        Args:
            text: Input text
            
        Returns:
            Token count
        """
        return len(self.tokenizer.encode(text))
    
    def analyze_ui_design(self, 
                         image: Union[Image.Image, bytes],
                         analysis_level: AnalysisLevel = AnalysisLevel.TEST_INFERENCE,
                         context: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze UI design using GPT-4 Vision
        
        Args:
            image: UI design image
            analysis_level: Level of analysis detail
            context: Additional context about the design
            
        Returns:
            Analysis results
        """
        try:
            # Encode image
            base64_image = self.encode_image(image)
            
            # Build prompt based on analysis level
            prompt = self._build_analysis_prompt(analysis_level, context)
            
            # Make API call
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert QA engineer analyzing UI designs to generate comprehensive test scenarios."
                    },
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/png;base64,{base64_image}",
                                    "detail": "high"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=4096,
                temperature=0.2
            )
            
            # Parse and structure response
            result = self._parse_analysis_response(
                response.choices[0].message.content,
                analysis_level
            )
            
            return {
                'analysis': result,
                'level': analysis_level.value,
                'usage': {
                    'prompt_tokens': response.usage.prompt_tokens,
                    'completion_tokens': response.usage.completion_tokens,
                    'total_tokens': response.usage.total_tokens
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to analyze UI design: {e}")
            raise
    
    def generate_test_scenarios(self,
                               design_analysis: Dict[str, Any],
                               user_story: Dict[str, Any],
                               framework: str = "angular",
                               test_type: str = "unit") -> List[Dict[str, Any]]:
        """
        Generate test scenarios based on design analysis and user story
        
        Args:
            design_analysis: Analysis from analyze_ui_design
            user_story: Rally user story data
            framework: Testing framework (angular, react, vue)
            test_type: Type of tests (unit, integration, e2e)
            
        Returns:
            List of test scenarios
        """
        try:
            # Build comprehensive prompt
            prompt = self._build_test_generation_prompt(
                design_analysis,
                user_story,
                framework,
                test_type
            )
            
            response = self.client.chat.completions.create(
                model="gpt-4-turbo-preview",
                messages=[
                    {
                        "role": "system",
                        "content": f"You are an expert {framework} test engineer. Generate comprehensive test scenarios following best practices."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=4096,
                temperature=0.3,
                response_format={"type": "json_object"}
            )
            
            # Parse JSON response
            test_scenarios = json.loads(response.choices[0].message.content)
            
            return test_scenarios.get('scenarios', [])
            
        except Exception as e:
            logger.error(f"Failed to generate test scenarios: {e}")
            raise
    
    def generate_test_code(self,
                          test_scenario: Dict[str, Any],
                          framework: str = "angular",
                          style: str = "jasmine") -> str:
        """
        Generate actual test code from a scenario
        
        Args:
            test_scenario: Test scenario dictionary
            framework: Testing framework
            style: Test style (jasmine, jest, mocha)
            
        Returns:
            Generated test code
        """
        try:
            prompt = self._build_code_generation_prompt(test_scenario, framework, style)
            
            response = self.client.chat.completions.create(
                model="gpt-4-turbo-preview",
                messages=[
                    {
                        "role": "system",
                        "content": f"You are an expert {framework} developer. Generate clean, maintainable test code."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=2048,
                temperature=0.2
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Failed to generate test code: {e}")
            raise
    
    def _build_analysis_prompt(self, level: AnalysisLevel, context: Optional[str]) -> str:
        """Build analysis prompt based on level"""
        
        base_prompt = "Analyze this UI design and provide detailed information about:\n\n"
        
        level_prompts = {
            AnalysisLevel.ELEMENT_DETECTION: """
1. All visible UI elements (buttons, inputs, labels, etc.)
2. Form fields and their types
3. Navigation elements
4. Data display components (tables, lists, cards)
5. Interactive elements
Format as JSON with categories.""",
            
            AnalysisLevel.CONTEXT_UNDERSTANDING: """
1. Purpose of each UI component
2. Required vs optional fields
3. Validation rules you can infer
4. Error states and messages
5. Component relationships and dependencies
Format as JSON with detailed descriptions.""",
            
            AnalysisLevel.INTERACTION_MAPPING: """
1. User interaction flows
2. Click/tap targets
3. Input sequences
4. Navigation paths
5. State changes and transitions
Format as JSON with interaction sequences.""",
            
            AnalysisLevel.TEST_INFERENCE: """
1. All testable components and interactions
2. Validation rules and boundaries
3. Edge cases and error scenarios
4. User flow test cases
5. Data requirements for testing
6. Accessibility considerations
Format as comprehensive JSON with test scenarios."""
        }
        
        prompt = base_prompt + level_prompts[level]
        
        if context:
            prompt += f"\n\nAdditional context: {context}"
            
        return prompt
    
    def _build_test_generation_prompt(self, 
                                     design_analysis: Dict[str, Any],
                                     user_story: Dict[str, Any],
                                     framework: str,
                                     test_type: str) -> str:
        """Build test generation prompt"""
        
        prompt = f"""Generate comprehensive {test_type} test scenarios for {framework}.

Design Analysis:
{json.dumps(design_analysis['analysis'], indent=2)}

User Story:
- ID: {user_story.get('id')}
- Name: {user_story.get('name')}
- Description: {user_story.get('description')}
- Acceptance Criteria:
{chr(10).join(['  - ' + ac for ac in user_story.get('acceptance_criteria', [])])}

Generate test scenarios in JSON format with the following structure:
{{
  "scenarios": [
    {{
      "id": "unique_id",
      "name": "test scenario name",
      "description": "what is being tested",
      "type": "{test_type}",
      "priority": "high|medium|low",
      "preconditions": ["list of preconditions"],
      "steps": [
        {{
          "action": "user action",
          "expected": "expected result"
        }}
      ],
      "test_data": {{}},
      "assertions": ["list of assertions"],
      "tags": ["relevant tags"]
    }}
  ]
}}

Focus on:
1. Happy path scenarios
2. Edge cases
3. Error handling
4. Validation testing
5. Accessibility testing
6. Performance considerations"""
        
        return prompt
    
    def _build_code_generation_prompt(self, scenario: Dict[str, Any], framework: str, style: str) -> str:
        """Build code generation prompt"""
        
        prompt = f"""Generate {style} test code for {framework} based on this scenario:

Scenario: {scenario.get('name')}
Description: {scenario.get('description')}
Type: {scenario.get('type')}

Steps:
{json.dumps(scenario.get('steps', []), indent=2)}

Assertions:
{chr(10).join(['- ' + a for a in scenario.get('assertions', [])])}

Test Data:
{json.dumps(scenario.get('test_data', {}), indent=2)}

Generate clean, well-commented test code following {framework} best practices.
Include:
1. Proper imports
2. Test setup and teardown
3. Clear test descriptions
4. Comprehensive assertions
5. Error handling
6. Mock data where appropriate

Return only the test code, no explanations."""
        
        return prompt
    
    def _parse_analysis_response(self, response: str, level: AnalysisLevel) -> Dict[str, Any]:
        """Parse GPT-4 analysis response"""
        
        try:
            # Try to parse as JSON first
            if response.strip().startswith('{'):
                return json.loads(response)
        except json.JSONDecodeError:
            pass
        
        # Extract JSON from markdown code blocks
        import re
        json_match = re.search(r'```json\n(.*?)\n```', response, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except json.JSONDecodeError:
                pass
        
        # Return structured response if parsing fails
        return {
            'raw_analysis': response,
            'level': level.value,
            'parsed': False
        }
    
    def estimate_cost(self, image_size: tuple, text_length: int) -> Dict[str, float]:
        """
        Estimate API costs
        
        Args:
            image_size: Image dimensions (width, height)
            text_length: Approximate text length
            
        Returns:
            Cost estimates
        """
        # Rough estimates based on OpenAI pricing
        image_tokens = 765  # Base tokens for high-detail image
        text_tokens = self.count_tokens("x" * text_length)
        
        total_tokens = image_tokens + text_tokens
        
        # GPT-4 Vision pricing (example rates)
        input_cost = (total_tokens / 1000) * 0.01
        output_cost = (2000 / 1000) * 0.03  # Assume 2000 output tokens
        
        return {
            'estimated_input_tokens': total_tokens,
            'estimated_output_tokens': 2000,
            'estimated_cost': round(input_cost + output_cost, 4)
        }