"""
Rally API Client for fetching user stories and acceptance criteria
"""

import requests
from typing import Optional, Dict, Any, List
import json
import logging
from datetime import datetime
import base64

logger = logging.getLogger(__name__)


class RallyClient:
    """Client for interacting with Rally (CA Agile Central) API"""
    
    def __init__(self, api_key: str, workspace: Optional[str] = None, project: Optional[str] = None):
        """
        Initialize Rally client
        
        Args:
            api_key: Rally API key
            workspace: Optional workspace ID
            project: Optional project ID
        """
        self.api_key = api_key
        self.workspace = workspace
        self.project = project
        self.base_url = "https://rally1.rallydev.com/slm/webservice/v2.0"
        
        # Create authentication header
        auth_string = f"{api_key}:"
        auth_bytes = auth_string.encode('ascii')
        auth_b64 = base64.b64encode(auth_bytes).decode('ascii')
        
        self.headers = {
            "Authorization": f"Basic {auth_b64}",
            "Content-Type": "application/json"
        }
        
    def _make_request(self, endpoint: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Make a request to Rally API
        
        Args:
            endpoint: API endpoint
            params: Query parameters
            
        Returns:
            API response data
        """
        url = f"{self.base_url}/{endpoint}"
        
        if params is None:
            params = {}
            
        # Add workspace and project if specified
        if self.workspace:
            params['workspace'] = f"/workspace/{self.workspace}"
        if self.project:
            params['project'] = f"/project/{self.project}"
            
        params['fetch'] = 'true'  # Fetch full objects
        
        try:
            response = requests.get(url, headers=self.headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Rally API request failed: {e}")
            raise
    
    def get_user_story(self, story_id: str) -> Dict[str, Any]:
        """
        Get a specific user story by ID
        
        Args:
            story_id: User story formatted ID (e.g., "US12345")
            
        Returns:
            User story data
        """
        try:
            # Query for the user story
            params = {
                'query': f'(FormattedID = "{story_id}")',
                'fetch': 'FormattedID,Name,Description,AcceptanceCriteria,Notes,Feature,c_BusinessValue,PlanEstimate,ScheduleState,Owner'
            }
            
            data = self._make_request('HierarchicalRequirement', params)
            
            if data['QueryResult']['TotalResultCount'] == 0:
                raise ValueError(f"User story {story_id} not found")
            
            story = data['QueryResult']['Results'][0]
            
            return self._format_user_story(story)
            
        except Exception as e:
            logger.error(f"Failed to fetch user story {story_id}: {e}")
            raise
    
    def get_user_stories_by_feature(self, feature_id: str) -> List[Dict[str, Any]]:
        """
        Get all user stories for a feature
        
        Args:
            feature_id: Feature ID
            
        Returns:
            List of user stories
        """
        try:
            params = {
                'query': f'(Feature.FormattedID = "{feature_id}")',
                'fetch': 'FormattedID,Name,Description,AcceptanceCriteria,Notes',
                'order': 'Rank'
            }
            
            data = self._make_request('HierarchicalRequirement', params)
            
            stories = []
            for story in data['QueryResult']['Results']:
                stories.append(self._format_user_story(story))
            
            return stories
            
        except Exception as e:
            logger.error(f"Failed to fetch stories for feature {feature_id}: {e}")
            raise
    
    def get_test_cases_for_story(self, story_id: str) -> List[Dict[str, Any]]:
        """
        Get test cases associated with a user story
        
        Args:
            story_id: User story ID
            
        Returns:
            List of test cases
        """
        try:
            params = {
                'query': f'(WorkProduct.FormattedID = "{story_id}")',
                'fetch': 'FormattedID,Name,Description,Method,Type,Priority,Risk,PreConditions,PostConditions,ExpectedResult,Steps'
            }
            
            data = self._make_request('TestCase', params)
            
            test_cases = []
            for tc in data['QueryResult']['Results']:
                test_cases.append({
                    'id': tc.get('FormattedID'),
                    'name': tc.get('Name'),
                    'description': tc.get('Description'),
                    'method': tc.get('Method'),
                    'type': tc.get('Type'),
                    'priority': tc.get('Priority'),
                    'risk': tc.get('Risk'),
                    'pre_conditions': tc.get('PreConditions'),
                    'post_conditions': tc.get('PostConditions'),
                    'expected_result': tc.get('ExpectedResult'),
                    'steps': self._parse_test_steps(tc.get('Steps'))
                })
            
            return test_cases
            
        except Exception as e:
            logger.error(f"Failed to fetch test cases for story {story_id}: {e}")
            raise
    
    def _format_user_story(self, story: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format user story data for easier consumption
        
        Args:
            story: Raw user story data
            
        Returns:
            Formatted user story
        """
        return {
            'id': story.get('FormattedID'),
            'name': story.get('Name'),
            'description': self._clean_html(story.get('Description', '')),
            'acceptance_criteria': self._parse_acceptance_criteria(story.get('AcceptanceCriteria')),
            'notes': self._clean_html(story.get('Notes', '')),
            'plan_estimate': story.get('PlanEstimate'),
            'state': story.get('ScheduleState'),
            'feature': self._extract_reference(story.get('Feature')),
            'owner': self._extract_reference(story.get('Owner')),
            'business_value': story.get('c_BusinessValue')
        }
    
    def _parse_acceptance_criteria(self, criteria: Optional[str]) -> List[str]:
        """
        Parse acceptance criteria into list of items
        
        Args:
            criteria: HTML formatted acceptance criteria
            
        Returns:
            List of criteria items
        """
        if not criteria:
            return []
        
        # Clean HTML and split into items
        cleaned = self._clean_html(criteria)
        
        # Try to split by common patterns
        items = []
        
        # Split by numbered lists (1., 2., etc.)
        import re
        numbered = re.split(r'\d+\.\s+', cleaned)
        if len(numbered) > 1:
            items = [item.strip() for item in numbered if item.strip()]
        # Split by bullet points
        elif '•' in cleaned or '-' in cleaned:
            items = re.split(r'[•\-]\s+', cleaned)
            items = [item.strip() for item in items if item.strip()]
        # Split by newlines
        elif '\n' in cleaned:
            items = [item.strip() for item in cleaned.split('\n') if item.strip()]
        else:
            items = [cleaned.strip()] if cleaned.strip() else []
        
        return items
    
    def _parse_test_steps(self, steps_data: Any) -> List[Dict[str, str]]:
        """
        Parse test steps data
        
        Args:
            steps_data: Test steps from Rally
            
        Returns:
            List of step dictionaries
        """
        if not steps_data:
            return []
        
        steps = []
        
        # Handle different step formats
        if isinstance(steps_data, list):
            for i, step in enumerate(steps_data, 1):
                steps.append({
                    'step_number': i,
                    'input': step.get('Input', ''),
                    'expected_result': step.get('ExpectedResult', '')
                })
        
        return steps
    
    def _clean_html(self, html_content: str) -> str:
        """
        Remove HTML tags from content
        
        Args:
            html_content: HTML formatted text
            
        Returns:
            Plain text
        """
        if not html_content:
            return ''
        
        # Simple HTML tag removal
        import re
        clean_text = re.sub(r'<[^>]+>', '', html_content)
        # Replace HTML entities
        clean_text = clean_text.replace('&nbsp;', ' ')
        clean_text = clean_text.replace('&lt;', '<')
        clean_text = clean_text.replace('&gt;', '>')
        clean_text = clean_text.replace('&amp;', '&')
        clean_text = clean_text.replace('&quot;', '"')
        clean_text = clean_text.replace('&#39;', "'")
        
        return clean_text.strip()
    
    def _extract_reference(self, ref_data: Any) -> Optional[str]:
        """
        Extract reference information
        
        Args:
            ref_data: Reference object from Rally
            
        Returns:
            Reference name or ID
        """
        if not ref_data:
            return None
        
        if isinstance(ref_data, dict):
            return ref_data.get('_refObjectName') or ref_data.get('_ref')
        
        return str(ref_data)
    
    def search_user_stories(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Search for user stories based on query
        
        Args:
            query: Search query
            limit: Maximum number of results
            
        Returns:
            List of matching user stories
        """
        try:
            params = {
                'query': f'(Name contains "{query}")',
                'fetch': 'FormattedID,Name,Description,AcceptanceCriteria',
                'pagesize': limit
            }
            
            data = self._make_request('HierarchicalRequirement', params)
            
            stories = []
            for story in data['QueryResult']['Results'][:limit]:
                stories.append(self._format_user_story(story))
            
            return stories
            
        except Exception as e:
            logger.error(f"Failed to search user stories: {e}")
            raise