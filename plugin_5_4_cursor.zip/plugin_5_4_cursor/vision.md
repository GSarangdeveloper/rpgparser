Provide a flexible Component Mapping Strategy: Allow users to map Figma components to existing Angular components in their codebase/library (preferred) or generate new Angular components. This mapping should handle component selectors (<my-component>) and necessary module imports. Configuration could be managed via the plugin UI (potentially using `figma.clientStorage`) or a user-managed configuration file within their project for more complex scenarios.
Handle Instance Overrides: Translate overrides applied via `componentProperties` to input bindings. Address deep nested overrides potentially through Angular's content projection (`<ng-content>`), generating flatter components with more explicit inputs, or acknowledging that complex cases might require manual developer refinement.
Raster Image Handling: Identify image fills (`imageHash`) and raster export settings (PNG, JPG). Provide a strategy for export, potentially involving coordination with the Figma REST API (via the plugin UI – noting this adds complexity for authentication and file handling) or clearer instructions for manual export by the user. Generate `<img>` tags or CSS `background-image` rules referencing a conventional asset path (e.g., `src/assets/images/`).
ui: Points to the HTML/JS/React/Vue file for the plugin's user interface (e.g., `dist/ui.html` compiled from `src/ui.tsx`). The UI will handle user interactions, configuration (like component mapping, export settings, potentially persisted using `figma.clientStorage`), displaying results, and potentially network requests.
No Application Logic: The plugin will focus solely on generating the UI structure and styling, not complex application logic, state management, or data fetching implementation within the Angular components. Generated code provides the structural and stylistic foundation.
graph TD
    A[Start Plugin] --> B(Plugin UI Opens)
    B --> C{User Configures Options?}
    C -- Yes --> D[Set Mapping, Tokens, Path etc.]
    D --> E
    C -- No --> E(User Clicks 'Generate Code')
    E --> I(Extract Global Tokens/Styles/Variables)
    I -- Variables --> J[`figma.getLocalVariablesAsync()`]
    I -- Styles --> K[Get Local Styles]
    J --> L
    K --> L
    L --> F(Access Selected Nodes/Page)
    F --> H{Process Nodes Recursively}

    subgraph H [Node Processing Loop]
        direction LR
        H_Start(For Each Node) --> H_GetData{Gather Node Data}
        H_GetData --> H_Type{Type?}
        H_GetData --> H_Geo{Geometry?}
        H_GetData --> H_Style{Styling?}
        H_GetData --> H_Text{Text Content/Style?}
        H_GetData --> H_Layout{Layout: Auto/Constraints?}
        H_GetData --> H_Component{Component/Instance Info?}
        H_GetData --> H_Tokens{Token Usage?}
        H_GetData --> H_Assets{Asset Info?}
        H_Assets -- Image Fill --> H_Img(Note Image Req.)
        H_Assets -- Vector --> H_SVG(Note SVG Req.)
        H_Assets -- Font Use --> H_Font(Note Font Req.)
        H_Img --> H_EndLoop
        H_SVG --> H_EndLoop
        H_Font --> H_EndLoop
        H_Type --> H_EndLoop(Store Processed Node Info)
        H_Geo --> H_EndLoop
        H_Style --> H_EndLoop
        H_Text --> H_EndLoop
        H_Layout --> H_EndLoop
        H_Component --> H_EndLoop
        H_Tokens --> H_EndLoop
        H_Assets -- None --> H_EndLoop
    end

    H -- Processed Node Data --> M(Code Generation Stage)
    I -- Global Token/Style Data --> M

    subgraph M [Code Generation]
        direction TB
        M_Input(Input: Processed Nodes + Tokens) --> M_Logic(Translate to Angular Structure)
        M_Logic --> M_HTML(Generate HTML Template)
        M_Logic --> M_SCSS(Generate SCSS/CSS)
        M_Logic --> M_TS(Generate TS Component Class)
        M_HTML --> M_Output
        M_SCSS --> M_Output
        M_TS --> M_Output(Output: .html, .scss, .ts files)
    end

    M --> R(Prepare Output)
    R --> R1[Assemble Files]
    R --> R2{Provide Download (ZIP)?}
    R --> R3[Display Code Snippets?]
    R --> R4[Provide Asset/Font Instructions]
    R1 --> S
    R2 --> S
    R3 --> S
    R4 --> S(End: Plugin Closes / Waits)

    subgraph Z [External Interactions]
        direction TB
        Z1[Figma REST API (Optional for Images)]
        Z2[Manual Asset Export (User Task)]
        Z3[Developer Provides Font Files (User Task)]
    end

    H_Img --> Z1
    H_Img --> Z2
    H_Font --> Z3 