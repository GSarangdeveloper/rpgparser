/// <reference types="@figma/plugin-typings" />

// Figma Plugin Code (code.ts)

// --- Interfaces (Optional but Recommended) ---
interface ProcessedNode {
  id: string;
  name: string;
  type: SceneNode['type'];
  htmlTag: string;
  cssClasses: string[];
  styles: Record<string, string | number>;
  textContent?: string;
  children: ProcessedNode[];
  // Instance-specific properties
  isInstance?: boolean;
  componentName?: string; // Original Figma component name
  inputs?: Record<string, any>; // Store extracted overrides { propName: value }
  // Asset properties
  svgContent?: string;
}

// --- Token Interfaces ---
interface TokenCollection {
  cssVariables: Record<string, string | number>; // Map CSS var name (--name) to value
  variableMap: Map<string, string>; // Map Figma Variable ID to CSS var name
  paintStyleMap: Map<string, string>; // StyleId -> cssVarName (for color)
  effectStyleMap: Map<string, string>; // StyleId -> cssVarName (for effects)
  textStyleMap: Map<string, Record<string, string>>; // StyleId -> {cssProp: cssVarName}
  // TODO: Add maps for Style IDs if implementing style fallback
}

// Add interface for parsed mapping
interface ComponentMapping {
    [figmaName: string]: string; // Maps Figma component name to Angular selector
}

// --- Main Plugin Logic ---

figma.showUI(__html__, { width: 450, height: 600 });

// Variable to store loaded mapping until UI is ready
let initialMappingConfig: string | undefined;

// Load mapping config on start
figma.clientStorage.getAsync('componentMapping').then(mapping => {
    initialMappingConfig = mapping || '';
    console.log("Loaded initial mapping from storage:", initialMappingConfig);
}).catch(err => {
    console.error("Error loading mapping from clientStorage:", err);
    initialMappingConfig = ''; // Ensure it's defined even on error
});

figma.ui.onmessage = async (msg: { type: string; config?: { mapping?: string } }) => { 
  console.log("Message received from UI:", msg);

  if (msg.type === 'ui-ready') {
      // Send loaded mapping to UI now that it's ready
      if (initialMappingConfig !== undefined) {
         figma.ui.postMessage({ type: 'load-mapping', mapping: initialMappingConfig });
      }
  } else if (msg.type === 'generate-code') {
    const selection = figma.currentPage.selection;
    if (selection.length === 0) {
      figma.notify("Please select at least one layer or frame.", { error: true });
      return;
    }

    const mappingConfigString = msg.config?.mapping || '';
    const componentMapping: ComponentMapping = parseMappingConfig(mappingConfigString);
    console.log("Using component mapping:", componentMapping);

    figma.clientStorage.setAsync('componentMapping', mappingConfigString).catch(err => {
        console.error("Error saving mapping to clientStorage:", err);
    });
    
    try {
      figma.notify("Processing nodes...");
      const tokens = await extractGlobalTokens(); 
      const processedNodes: ProcessedNode[] = [];
      for (const node of selection) {
          await loadNodeFonts(node);
          processedNodes.push(await processNode(node, tokens, componentMapping)); 
      }
      const generatedCode = generateAngularCode(processedNodes, tokens, componentMapping);
      figma.ui.postMessage({ type: 'code-generated', data: generatedCode });
      figma.notify("Code generated successfully!");
    } catch (error) {
        console.error("Error during code generation:", error);
        figma.notify(`Error: ${error instanceof Error ? error.message : String(error)}`, { error: true, timeout: 6000 });
        figma.ui.postMessage({ type: 'generation-error', error: String(error) });
    }

  } else if (msg.type === 'cancel') {
    figma.closePlugin();
  }
};

// --- Helper Functions ---

async function extractGlobalTokens(): Promise<TokenCollection> {
    console.log("Extracting global tokens...");
    const tokenCollection: TokenCollection = {
        cssVariables: {},
        variableMap: new Map<string, string>(),
        paintStyleMap: new Map<string, string>(),
        effectStyleMap: new Map<string, string>(),
        textStyleMap: new Map<string, Record<string, string>>()
    };

    try {
        const localVariables = await figma.variables.getLocalVariablesAsync();
        console.log(`Found ${localVariables.length} local variables.`);

        for (const variable of localVariables) {
            // Skip remote variables for now, focus on local definitions
            // if (variable.remote) continue;
            
            // Determine the CSS variable name (e.g., convert "colors/primary/base" to "--colors-primary-base")
            const cssVarName = `--${variable.name.toLowerCase().replace(/\//g, '-')}`;
            
            // Get the value for the current mode (simplification: using the first mode's value)
            // Production implementation might need mode selection UI
            const modes = Object.keys(variable.valuesByMode);
            if (modes.length > 0) {
                const firstMode = modes[0];
                const value = variable.valuesByMode[firstMode];
                let cssValue: string | number | undefined = undefined;

                // Convert Figma variable value to CSS value based on resolvedType
                switch (variable.resolvedType) {
                    case 'BOOLEAN':
                        // Not typically used directly in CSS styling
                        break;
                    case 'COLOR':
                        if (typeof value === 'object' && value !== null && ('r' in value)) {
                            cssValue = colorToCSS(value as RGBA);
                        } else {
                            console.warn(`Variable ${variable.name} has type COLOR but value is unexpected:`, value);
                        }
                        break;
                    case 'FLOAT':
                        if (typeof value === 'number') {
                             // Check if it looks like a pixel value (common use case)
                             // Heuristic: if name includes 'size', 'spacing', 'radius', 'border-width', assume px
                             if (variable.name.toLowerCase().includes('size') ||
                                 variable.name.toLowerCase().includes('spacing') ||
                                 variable.name.toLowerCase().includes('radius') ||
                                 variable.name.toLowerCase().includes('border-width') ||
                                 variable.name.toLowerCase().includes('font-size')) {
                                 cssValue = `${value}px`;
                             } else {
                                 cssValue = value; // Use raw number otherwise
                             }
                        } else {
                            console.warn(`Variable ${variable.name} has type FLOAT but value is not a number:`, value);
                        }
                        break;
                    case 'STRING':
                         if (typeof value === 'string') {
                             // Check if it looks like a font family
                             // Heuristic: if name includes 'font-family' or 'font'
                             if (variable.name.toLowerCase().includes('font-family') || variable.name.toLowerCase().includes('font')) {
                                 cssValue = `"${value}"`; // Add quotes for font families
                             } else {
                                 cssValue = value; // Use raw string otherwise
                             }
                         } else {
                             console.warn(`Variable ${variable.name} has type STRING but value is not a string:`, value);
                         }
                        break;
                    default:
                        console.warn(`Unsupported variable type: ${variable.resolvedType} for variable ${variable.name}`);
                }

                if (cssValue !== undefined) {
                    tokenCollection.cssVariables[cssVarName] = cssValue;
                    tokenCollection.variableMap.set(variable.id, cssVarName);
                    console.log(`  -> Mapped Variable ID ${variable.id} (${variable.name}) to ${cssVarName}: ${cssValue}`);
                } else {
                    console.log(`  -> Skipping Variable ID ${variable.id} (${variable.name}) - could not determine CSS value.`);
                }
            } else {
                 console.log(`  -> Skipping Variable ID ${variable.id} (${variable.name}) - no modes found.`);
            }
        }
    } catch (e) {
        console.error("Error fetching or processing Figma Variables:", e);
        figma.notify("Error extracting design tokens (variables).", { error: true });
    }

    // Helper to generate CSS var names consistently
    const generateCssVarName = (prefix: string, name: string): string => {
        return `--${prefix}-${name.toLowerCase().replace(/\s*\/\s*/g, '-').replace(/[^a-z0-9\-]+/g, '-')}`.replace(/\-+$/, '');
    };

    // --- 2. Process Paint Styles --- 
    try {
        const paintStyles = figma.getLocalPaintStyles();
        console.log(`Found ${paintStyles.length} paint styles.`);
        for (const style of paintStyles) {
            const paint = style.paints[0]; // Simplification: Use the first paint
            if (!paint || paint.type !== 'SOLID') continue; // Only handle solid for now

            const cssVarName = generateCssVarName('paint', style.name);
            const cssValue = colorToCSS(paint.color, paint.opacity);
            
            tokenCollection.cssVariables[cssVarName] = cssValue;
            tokenCollection.paintStyleMap.set(style.id, cssVarName);
            console.log(`  -> Mapped Paint Style ID ${style.id} (${style.name}) to ${cssVarName}: ${cssValue}`);
        }
    } catch (e) {
        console.error("Error processing Paint Styles:", e);
    }

    // --- 3. Process Effect Styles --- 
     try {
        const effectStyles = figma.getLocalEffectStyles();
        console.log(`Found ${effectStyles.length} effect styles.`);
        for (const style of effectStyles) {
            const visibleEffects = style.effects.filter(e => e.visible);
            if (visibleEffects.length === 0) continue;

            // Combine effects into single CSS values (simplification)
            const shadows = visibleEffects.filter(e => e.type === 'DROP_SHADOW' || e.type === 'INNER_SHADOW')
                                          .map(shadowToCSS).join(', ');
            const layerBlur = visibleEffects.find(b => b.type === 'LAYER_BLUR');
            // Note: backdrop-filter needs separate handling or specific variable

            let cssValue: string | undefined;
            if (shadows) {
                cssValue = shadows;
            } else if (layerBlur) {
                 cssValue = `blur(${layerBlur.radius}px)`;
            }
            // TODO: Handle multiple effect types more robustly (e.g., separate vars)

            if (cssValue) {
                 const cssVarName = generateCssVarName('effect', style.name);
                 tokenCollection.cssVariables[cssVarName] = cssValue; // Note: might be box-shadow or filter
                 tokenCollection.effectStyleMap.set(style.id, cssVarName);
                 console.log(`  -> Mapped Effect Style ID ${style.id} (${style.name}) to ${cssVarName}: ${cssValue}`);
            }
        }
    } catch (e) {
        console.error("Error processing Effect Styles:", e);
    }

    // --- 4. Process Text Styles --- 
    try {
        const textStyles = figma.getLocalTextStyles();
        console.log(`Found ${textStyles.length} text styles.`);
        for (const style of textStyles) {
            const styleId = style.id;
            const baseName = style.name;
            const propToVarMap: Record<string, string> = {};

            // Font Size
            if (typeof style.fontSize === 'number') {
                 const cssVarName = generateCssVarName('text', `${baseName}-font-size`);
                 const cssValue = `${style.fontSize}px`;
                 tokenCollection.cssVariables[cssVarName] = cssValue;
                 propToVarMap['font-size'] = cssVarName;
            }
             // Font Family
            if (style.fontName?.family) {
                 const cssVarName = generateCssVarName('text', `${baseName}-font-family`);
                 const cssValue = `"${style.fontName.family}"`;
                 tokenCollection.cssVariables[cssVarName] = cssValue;
                 propToVarMap['font-family'] = cssVarName;
            }
             // Font Weight
             if (style.fontName?.style) {
                 const weight = mapFontWeight(style.fontName.style);
                 if (weight !== undefined) {
                     const cssVarName = generateCssVarName('text', `${baseName}-font-weight`);
                     tokenCollection.cssVariables[cssVarName] = weight;
                     propToVarMap['font-weight'] = cssVarName;
                 }
            }
             // Line Height
            if (style.lineHeight?.unit !== 'AUTO' && typeof style.lineHeight?.value === 'number') {
                 const cssVarName = generateCssVarName('text', `${baseName}-line-height`);
                 const cssValue = `${style.lineHeight.value}${style.lineHeight.unit === 'PERCENT' ? '%' : 'px'}`;
                 tokenCollection.cssVariables[cssVarName] = cssValue;
                 propToVarMap['line-height'] = cssVarName;
            }
             // Letter Spacing
            if (style.letterSpacing?.value !== 0 && typeof style.letterSpacing?.value === 'number') {
                 const cssVarName = generateCssVarName('text', `${baseName}-letter-spacing`);
                 const cssValue = `${style.letterSpacing.value}${style.letterSpacing.unit === 'PERCENT' ? '%' : 'px'}`;
                 tokenCollection.cssVariables[cssVarName] = cssValue;
                 propToVarMap['letter-spacing'] = cssVarName;
            }
            // TODO: Add Text Case, Decoration if needed as variables

            if (Object.keys(propToVarMap).length > 0) {
                 tokenCollection.textStyleMap.set(styleId, propToVarMap);
                 console.log(`  -> Mapped Text Style ID ${styleId} (${baseName}) to variables:`, propToVarMap);
            }
        }
    } catch (e) {
        console.error("Error processing Text Styles:", e);
    }

    console.log("Finished extracting tokens.", tokenCollection);
    return tokenCollection;
}

async function loadNodeFonts(node: SceneNode): Promise<void> {
    const fonts: FontName[] = [];
    const collectFonts = (n: SceneNode) => {
        if (n.type === 'TEXT' && n.hasMissingFont === false) {
            if (Array.isArray(n.fontName)) {
                n.fontName.forEach(f => fonts.push(f));
            } else {
                fonts.push(n.fontName as FontName);
            }
        }
        if ('children' in n) {
            n.children.forEach(collectFonts);
        }
    };

    collectFonts(node);

    // Deduplicate fonts
    const uniqueFonts = Array.from(new Map(fonts.map(f => [`${f.family}-${f.style}`, f])).values());

    if (uniqueFonts.length > 0) {
        console.log('Loading fonts:', uniqueFonts);
        try {
            await Promise.all(uniqueFonts.map(font => figma.loadFontAsync(font)));
            console.log('Fonts loaded successfully');
        } catch (e) {
            console.error('Error loading fonts:', e);
            figma.notify('Error loading required fonts. Some text may not render correctly.', { error: true });
            // Decide if you want to proceed without fonts or stop
        }
    }
}

async function processNode(node: SceneNode, tokens: TokenCollection, mapping: ComponentMapping): Promise<ProcessedNode> {
    console.log(`Processing node: ${node.name} (${node.type}) ID: ${node.id}`); 
    const processed: ProcessedNode = {
        id: node.id,
        name: node.name,
        type: node.type,
        htmlTag: 'div', 
        cssClasses: [`node-${node.id.replace(/[:;]/g, '-')}`], 
        styles: {},
        children: [],
    };

    // --- Basic Properties ---
    if ('visible' in node && !node.visible) {
        processed.styles['display'] = 'none'; // Use display:none for hidden nodes
        // Skip further processing for hidden nodes?
        // return processed; // Or maybe just don't process children/styles? For now, let's style it hidden.
    }
    if ('opacity' in node && node.opacity < 1) { // Only add if not fully opaque
        processed.styles['opacity'] = node.opacity;
    }
    // TODO: Extract blend modes if needed

    // --- Layout Processing (Pass Parent for Context) ---
    processLayout(node, node.parent, processed, tokens);

    // --- Styling Processing ---
    processStyling(node, processed, tokens);

    // --- Text Processing ---
    if (node.type === 'TEXT') {
        processTextNode(node, processed, tokens, mapping);
    }

    // --- Component/Instance Processing ---
    if (node.type === 'INSTANCE') {
        processed.isInstance = true;
        const mainComponent = node.mainComponent;
        if (mainComponent) {
            processed.componentName = mainComponent.name; 
            console.log(`  -> Instance of: ${mainComponent.name} (ID: ${mainComponent.id})`);
            
            // Check for user-defined mapping FIRST
            let selectorName = mapping[mainComponent.name];
            if (selectorName) {
                console.log(`    Found user mapping: ${mainComponent.name} -> ${selectorName}`);
            } else {
                // Fallback to default generated selector
                selectorName = `app-${mainComponent.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
                console.log(`    Using default selector: <${selectorName}>`);
            }
            processed.htmlTag = selectorName;
            
            // --- Extract Component Properties (Overrides) ---
            processed.inputs = {}; 
            const overrides = node.componentProperties;
            if (overrides) {
                 console.log("    Component Properties (Overrides):", JSON.stringify(overrides)); 
                 for (const propName in overrides) {
                     const propData = overrides[propName];
                     let valueToStore = propData.value;

                     // Ensure VARIANT types are stored as strings for binding
                     if (propData.type === 'VARIANT' && typeof valueToStore !== 'string') {
                         console.warn(`      -> Variant property ${propName} has unexpected value type: ${typeof valueToStore}. Storing as string.`);
                         valueToStore = String(valueToStore); 
                     }
                      // TODO: Handle INSTANCE_SWAP type? Maybe store the preferredValue.id?

                     processed.inputs[propName] = valueToStore;
                     console.log(`      -> Extracted Input: ${propName} (${propData.type}) = ${JSON.stringify(valueToStore)}`);
                 }
            }
        } else {
             console.warn(`  -> Instance node ${node.name} has no mainComponent.`);
             processed.htmlTag = 'div'; 
        }
        // Stop processing children
    } else if (node.type === 'COMPONENT' || node.type === 'COMPONENT_SET') {
        // Don't generate code directly for main components/sets unless specifically requested?
        // For now, treat like a regular frame/div.
        processed.htmlTag = 'div'; 
        console.log(`  -> Node is a main component/set (${node.name}), treating as div.`);
         // If we wanted to generate the component definition itself, logic would go here.
    }

    // --- Asset Processing (SVG/Images) ---
    let isLikelySvg = false;
    if (processed.htmlTag === 'div') { 
        if (node.type === 'VECTOR' || node.type === 'BOOLEAN_OPERATION' || node.type === 'STAR' || node.type === 'LINE' || node.type === 'ELLIPSE' || node.type === 'POLYGON') {
            // Assume these types are SVGs unless they have image fills (unlikely but possible)
            isLikelySvg = true;
            if ('fills' in node && Array.isArray(node.fills)) {
                if (node.fills.some(f => f.type === 'IMAGE')) {
                    isLikelySvg = false; 
                }
            }
        } 
        // Treat RECTANGLE as SVG only if it DOES NOT have an image fill (handled in processStyling)
        // And maybe only if it has vectorNetwork information? For now, let's skip rectangles here.
    }

    if (isLikelySvg) {
        console.log(`  -> Node ${node.name} identified as SVG. Exporting...`);
        try {
            const svgBytes = await node.exportAsync({ 
                format: 'SVG', 
                svgOutlineText: false, 
                svgIdAttribute: true   
            });
            
            // Manual Uint8Array to string conversion (Figma sandbox safe)
            let svgString = '';
            const chunkSize = 8192; // Process in chunks to avoid stack issues
            for (let i = 0; i < svgBytes.length; i += chunkSize) {
                const chunk = svgBytes.subarray(i, i + chunkSize);
                svgString += String.fromCharCode.apply(null, chunk as any); // Need 'as any' for apply
            }
            
            processed.svgContent = svgString;
            
            if (processed.svgContent) {
                 processed.svgContent = processed.svgContent.replace(/<\?xml.*\?>\n?/, ''); 
                 processed.svgContent = processed.svgContent.replace(/ width="\d+(\.\d+)?(px)?"/, ''); 
                 processed.svgContent = processed.svgContent.replace(/ height="\d+(\.\d+)?(px)?"/, ''); 
                 // Keep the htmlTag as 'div' and add a class for styling the container
                 processed.htmlTag = 'div'; 
                 processed.cssClasses.push('svg-container'); 
                 console.log(`    -> SVG Export successful for ${node.name}. Content length: ${processed.svgContent.length}`);
            } else {
                 console.warn(`    -> SVG Export returned empty content for ${node.name}.`);
                 processed.htmlTag = 'div'; // Fallback if content is empty after decoding
            }
           
        } catch (e) {
            console.error(`    -> Error exporting SVG for ${node.name}:`, e);
            processed.htmlTag = 'div'; // Fallback on error
        }
    }
    // Image handling is done via fills in processStyling

    // --- Process Children Recursively ---
    if ('children' in node && node.type !== 'INSTANCE') {
        console.log(`  -> Processing ${node.children.length} children of ${node.name}`);
        const childPromises = node.children.map(child => processNode(child, tokens, mapping)); 
        processed.children = await Promise.all(childPromises);
    }

    return processed;
}

// Update processLayout signature to accept parent node
function processLayout(node: SceneNode, parent: (BaseNode & ChildrenMixin) | SceneNode | null, processed: ProcessedNode, tokens: TokenCollection) {
    processed.styles['box-sizing'] = 'border-box'; 
    console.log(`  [Layout] Processing node: ${node.name}, Type: ${node.type}, Parent: ${parent?.type}`);

    // --- Auto Layout Container --- 
    if ('layoutMode' in node && (node.layoutMode === 'HORIZONTAL' || node.layoutMode === 'VERTICAL')) {
        console.log(`    -> Node is Auto Layout container (${node.layoutMode})`);
        processed.styles['display'] = 'flex';
        processed.styles['flex-direction'] = node.layoutMode === 'HORIZONTAL' ? 'row' : 'column';

        // Sizing of the container itself
        if (node.primaryAxisSizingMode === 'AUTO') processed.styles[node.layoutMode === 'HORIZONTAL' ? 'width' : 'height'] = 'fit-content';
        if (node.counterAxisSizingMode === 'AUTO') processed.styles[node.layoutMode === 'HORIZONTAL' ? 'height' : 'width'] = 'fit-content';
        // If Fixed, width/height are set below in the general case

        // Padding
        if (node.paddingLeft > 0) processed.styles['padding-left'] = `${node.paddingLeft}px`;
        if (node.paddingRight > 0) processed.styles['padding-right'] = `${node.paddingRight}px`;
        if (node.paddingTop > 0) processed.styles['padding-top'] = `${node.paddingTop}px`;
        if (node.paddingBottom > 0) processed.styles['padding-bottom'] = `${node.paddingBottom}px`;
        
        // Gap
        if (node.itemSpacing > 0) processed.styles['gap'] = `${node.itemSpacing}px`;

        // Alignment
        processed.styles['justify-content'] = convertAlignContent(node.primaryAxisAlignItems);
        processed.styles['align-items'] = convertAlignItems(node.counterAxisAlignItems);

        // Wrap
        if (node.layoutWrap === 'WRAP') processed.styles['flex-wrap'] = 'wrap';

        processed.styles['position'] = 'relative'; // Auto layout containers act as positioning context
    }

    // --- Positioning & Sizing of Item (Relative to Parent) ---
    if (parent && 'children' in parent && 'width' in parent && 'height' in parent) { // Need parent dimensions for constraints
        const parentIsAutoLayout = 'layoutMode' in parent && parent.layoutMode !== 'NONE';
        
        // --- Item within Auto Layout Parent ---
        if (parentIsAutoLayout) {
             console.log(`    -> Node is child of Auto Layout parent (${parent.layoutMode})`);
             // Check if the current node *can* have these layout properties
             if ('layoutPositioning' in node && 'layoutGrow' in node && 'layoutAlign' in node && 'layoutSizingHorizontal' in node && 'layoutSizingVertical' in node) {
                 // Absolute Position override within Auto Layout?
                 if (node.layoutPositioning === 'ABSOLUTE') {
                    console.log(`      -> Child has ABSOLUTE positioning`);
                    processed.styles['position'] = 'absolute';
                    console.log(`        Absolute Pos: x=${node.x}, y=${node.y}, w=${node.width}, h=${node.height}`);
                    processed.styles['left'] = `${node.x}px`; 
                    processed.styles['top'] = `${node.y}px`;
                    processed.styles['width'] = `${node.width}px`; 
                    processed.styles['height'] = `${node.height}px`;
                 } else {
                    // Regular child in Auto Layout (RELATIVE positioning)
                    console.log(`      -> Child has RELATIVE positioning (layoutGrow: ${node.layoutGrow}, layoutAlign: ${node.layoutAlign})`);
                    if (node.layoutGrow === 1) {
                        processed.styles['flex-grow'] = 1;
                        console.log(`        Added flex-grow: 1`);
                    }
                    if (node.layoutAlign !== 'INHERIT' && node.layoutAlign !== 'STRETCH') {
                        processed.styles['align-self'] = convertAlignSelf(node.layoutAlign);
                        console.log(`        Added align-self: ${processed.styles['align-self']}`);
                    } else if (node.layoutAlign === 'STRETCH') {
                        console.log(`        Child uses STRETCH align-self (usually default)`);
                    }

                    // --- Sizing (Fixed/Fill/Hug) within Auto Layout ---
                    console.log(`        Sizing H: ${node.layoutSizingHorizontal}, V: ${node.layoutSizingVertical}`);
                    if (parent.layoutMode === 'HORIZONTAL') {
                        if (node.layoutSizingHorizontal === 'FIXED') {
                            processed.styles['width'] = `${node.width}px`;
                            processed.styles['flex-shrink'] = 0; 
                            console.log(`        Added fixed width: ${node.width}px, flex-shrink: 0`);
                        } else if (node.layoutSizingHorizontal === 'FILL') {
                            if (!processed.styles['flex-grow']) {
                                processed.styles['width'] = '100%'; 
                                console.log(`        Added FILL width: 100% (no flex-grow)`);
                            }
                        } 

                        if (node.layoutSizingVertical === 'FIXED') {
                            processed.styles['height'] = `${node.height}px`;
                            console.log(`        Added fixed height: ${node.height}px`);
                        } else if (node.layoutSizingVertical === 'FILL') {
                            if (processed.styles['align-self'] !== 'center' && processed.styles['align-self'] !== 'flex-start' && processed.styles['align-self'] !== 'flex-end') {
                                processed.styles['align-self'] = 'stretch';
                                console.log(`        Added FILL align-self: stretch`);
                            } else {
                                console.log(`        FILL height requested, but align-self already set to ${processed.styles['align-self']}`);
                            }
                        } 

                    } else { // VERTICAL parent
                        if (node.layoutSizingVertical === 'FIXED') {
                            processed.styles['height'] = `${node.height}px`;
                            processed.styles['flex-shrink'] = 0; 
                            console.log(`        Added fixed height: ${node.height}px, flex-shrink: 0`);
                        } else if (node.layoutSizingVertical === 'FILL') {
                            if (!processed.styles['flex-grow']) {
                                processed.styles['height'] = '100%';
                                console.log(`        Added FILL height: 100% (no flex-grow)`);
                            }
                        } 

                        if (node.layoutSizingHorizontal === 'FIXED') {
                            processed.styles['width'] = `${node.width}px`;
                            console.log(`        Added fixed width: ${node.width}px`);
                        } else if (node.layoutSizingHorizontal === 'FILL') {
                            if (processed.styles['align-self'] !== 'center' && processed.styles['align-self'] !== 'flex-start' && processed.styles['align-self'] !== 'flex-end') {
                                processed.styles['align-self'] = 'stretch';
                                console.log(`        Added FILL align-self: stretch`);
                            } else {
                                console.log(`        FILL width requested, but align-self already set to ${processed.styles['align-self']}`);
                            }
                        } 
                    }
                 }
             } else {
                 // Node is child of Auto Layout but doesn't support individual layout properties (e.g., a Group or Slice)
                 console.log(`    -> Node ${node.name} (${node.type}) is child of Auto Layout but lacks layout properties. Applying basic W/H.`);
                 processed.styles['width'] = `${node.width}px`;
                 processed.styles['height'] = `${node.height}px`;
             }
        } else {
             console.log(`    -> Parent ${parent.name} (${parent.type}) is NOT Auto Layout. Applying constraints.`);
            // --- Item within Non-Auto Layout Parent (Constraints) ---
            if ('constraints' in node) {
                 console.log(`      Node ${node.name} has constraints: H=${node.constraints.horizontal}, V=${node.constraints.vertical}`);
                 // Parent Frame needs to be a positioning context
                 // We should ideally add this to the parent when *it* is processed,
                 // but for simplicity, we'll add it here if the parent is a FRAME/COMPONENT/INSTANCE.
                 // This is not ideal as it might miss Group parents or apply unnecessarily.
                 // A better approach involves post-processing or context passing.
                 // *** Let's OMIT adding relative to parent FOR NOW to avoid complexity ***
                 // *** Assume parent frame/component will handle its own position:relative if needed ***
                 
                 processed.styles['position'] = 'absolute';

                 // --- Basic Constraint Handling --- 
                 // Horizontal - Use string literals (linter might complain, but should work)
                 switch (node.constraints.horizontal) {
                     case 'LEFT': 
                         processed.styles['left'] = `${node.x}px`;
                         processed.styles['width'] = `${node.width}px`;
                         break;
                     case 'RIGHT':
                         processed.styles['right'] = `${parent.width - (node.x + node.width)}px`;
                         processed.styles['width'] = `${node.width}px`;
                         break;
                     case 'CENTER':
                         const hCenterOffset = node.x + node.width / 2 - parent.width / 2;
                         processed.styles['left'] = `calc(50% + ${hCenterOffset}px)`;
                         processed.styles['width'] = `${node.width}px`;
                         break;
                     case 'LEFT_RIGHT': // Stretch
                         processed.styles['left'] = `${node.x}px`;
                         processed.styles['right'] = `${parent.width - (node.x + node.width)}px`;
                         break;
                     case 'SCALE':
                         processed.styles['left'] = `${(node.x / parent.width) * 100}%`;
                         processed.styles['width'] = `${(node.width / parent.width) * 100}%`;
                         break;
                 }

                 // Vertical - Use string literals
                 switch (node.constraints.vertical) {
                     case 'TOP':
                         processed.styles['top'] = `${node.y}px`;
                         processed.styles['height'] = `${node.height}px`;
                         break;
                     case 'BOTTOM':
                         processed.styles['bottom'] = `${parent.height - (node.y + node.height)}px`;
                         processed.styles['height'] = `${node.height}px`;
                         break;
                     case 'CENTER':
                         const vCenterOffset = node.y + node.height / 2 - parent.height / 2;
                         processed.styles['top'] = `calc(50% + ${vCenterOffset}px)`;
                          if (processed.styles['left']?.toString().startsWith('calc')) {
                               processed.styles['transform'] = 'translate(-50%, -50%)';
                               processed.styles['left'] = '50%'; 
                               processed.styles['top'] = '50%';
                          } else {
                               processed.styles['transform'] = 'translateY(-50%)';
                          }
                         processed.styles['height'] = `${node.height}px`;
                         break;
                     case 'TOP_BOTTOM': // Stretch
                         processed.styles['top'] = `${node.y}px`;
                         processed.styles['bottom'] = `${parent.height - (node.y + node.height)}px`;
                         break;
                     case 'SCALE':
                         processed.styles['top'] = `${(node.y / parent.height) * 100}%`;
                         processed.styles['height'] = `${(node.height / parent.height) * 100}%`;
                         break;
                 }
                 console.log(`      Applied absolute positioning styles:`, processed.styles); 
             } else {
                 // Node is in a non-AutoLayout parent but has no constraints? Apply basic size/pos.
                 console.log(`      Node ${node.name} in non-AL parent but no constraints found. Applying basic W/H.`);
                 if (!processed.styles['width']) processed.styles['width'] = `${node.width}px`;
                 if (!processed.styles['height']) processed.styles['height'] = `${node.height}px`;
             }
        }
    } else {
         // Root node or parent info unavailable
         console.log(`    -> Node has no parent or parent info unavailable. Applying basic W/H.`);
         if ('width' in node) processed.styles['width'] = `${node.width}px`;
         if ('height' in node) processed.styles['height'] = `${node.height}px`;
    }
}

function processStyling(node: SceneNode, processed: ProcessedNode, tokens: TokenCollection) {
    // --- Background / Fills ---
    if ('fills' in node && Array.isArray(node.fills) && node.fills.length > 0) {
        const fill = node.fills.find(f => f.visible);
        if (fill) {
            let appliedToken = false;
            // 1. Check for bound variable
            if ('boundVariables' in fill && fill.boundVariables?.color) {
                const variableId = fill.boundVariables.color.id;
                const cssVarName = tokens.variableMap.get(variableId);
                if (cssVarName) {
                    processed.styles['background-color'] = `var(${cssVarName})`;
                    appliedToken = true;
                    console.log(`    Applied background token (Variable): var(${cssVarName})`);
                }
            }
            // 2. Check for Paint Style ID (if no variable applied)
            else if (!appliedToken && 'fillStyleId' in node && node.fillStyleId && typeof node.fillStyleId === 'string') {
                const cssVarName = tokens.paintStyleMap.get(node.fillStyleId);
                if (cssVarName) {
                     processed.styles['background-color'] = `var(${cssVarName})`;
                     appliedToken = true;
                     console.log(`    Applied background token (Paint Style): var(${cssVarName})`);
                }
            }
            
            // 3. Fallback to raw value 
            if (!appliedToken) {
                 console.log(`    Applying raw background value (no variable or style found/applied)`);
                if (fill.type === 'SOLID') {
                    processed.styles['background-color'] = colorToCSS(fill.color, fill.opacity);
                } else if (fill.type === 'GRADIENT_LINEAR') {
                    processed.styles['background'] = gradientToCSS(fill);
                } else if (fill.type === 'IMAGE') {
                    // Generate background-image style referencing a conventional asset path
                    // Clean the node name to create a likely filename
                    const imageName = node.name.toLowerCase().replace(/[^a-z0-9_\-\.]+/g, '_') + '.png'; // Default to png, could check export settings
                    // Assume a standard Angular assets path
                    const imagePath = `./assets/images/${imageName}`;
                    processed.styles['background-image'] = `url('${imagePath}')`;
                    // Add styles for background size/position if needed (using fill.scaleMode, fill.imageTransform)
                    processed.styles['background-size'] = mapScaleMode(fill.scaleMode); // e.g., 'cover', 'contain'
                    processed.styles['background-repeat'] = 'no-repeat'; // Common default
                    processed.styles['background-position'] = 'center'; // Common default
                    // TODO: Translate fill.imageTransform to background-position more accurately if needed
                    console.log(`    Applied background-image: url('${imagePath}') (Scale: ${fill.scaleMode})`);
                    // Remove background-color if an image is applied, unless it's meant to be a fallback?
                    delete processed.styles['background-color']; 
                }
            }
        }
    }

    // --- Border / Strokes ---
    if ('strokes' in node && Array.isArray(node.strokes) && node.strokes.length > 0) {
        const stroke = node.strokes.find(s => s.visible);
        if (stroke && 'strokeWeight' in node) {
            const weight = node.strokeWeight ?? 1;
            let strokeColorValue: string | undefined;
            let appliedColorToken = false;

            // 1. Check for bound color variable
            if ('boundVariables' in stroke && stroke.boundVariables?.color) {
                const variableId = stroke.boundVariables.color.id;
                const cssVarName = tokens.variableMap.get(variableId);
                if (cssVarName) {
                    strokeColorValue = `var(${cssVarName})`;
                    appliedColorToken = true;
                     console.log(`    Applied stroke color token (Variable): ${strokeColorValue}`);
                }
            }
            // 2. Check for Paint Style ID (if no variable)
            else if (!appliedColorToken && 'strokeStyleId' in node && node.strokeStyleId && typeof node.strokeStyleId === 'string') {
                 const cssVarName = tokens.paintStyleMap.get(node.strokeStyleId);
                 if (cssVarName) {
                     strokeColorValue = `var(${cssVarName})`;
                     appliedColorToken = true;
                     console.log(`    Applied stroke color token (Paint Style): ${strokeColorValue}`);
                 }
            }
            
            // 3. Fallback to raw color
            if (!appliedColorToken && stroke.type === 'SOLID') {
                 strokeColorValue = colorToCSS(stroke.color, stroke.opacity);
                 console.log(`    Applying raw stroke color (no variable or style found/applied)`);
            }

            // TODO: Check for strokeWeight variable/style binding

            // Apply border style if we determined a color
            if (strokeColorValue) {
                 processed.styles['border'] = `${weight}px solid ${strokeColorValue}`;
            }
        }
    }

    // --- Corner Radius ---
    if ('cornerRadius' in node) {
        if (typeof node.cornerRadius === 'number' && node.cornerRadius > 0) {
            processed.styles['border-radius'] = `${node.cornerRadius}px`;
        } else if (typeof node.cornerRadius !== 'number') { // Individual corners
             // Need to check if topLeftRadius etc. exist before accessing
            if ('topLeftRadius' in node && node.topLeftRadius > 0)
                processed.styles['border-top-left-radius'] = `${node.topLeftRadius}px`;
            if ('topRightRadius' in node && node.topRightRadius > 0)
                processed.styles['border-top-right-radius'] = `${node.topRightRadius}px`;
            if ('bottomLeftRadius' in node && node.bottomLeftRadius > 0)
                processed.styles['border-bottom-left-radius'] = `${node.bottomLeftRadius}px`;
            if ('bottomRightRadius' in node && node.bottomRightRadius > 0)
                processed.styles['border-bottom-right-radius'] = `${node.bottomRightRadius}px`;
        }
    }

    // --- Effects (Shadows, Blur) ---
    if ('effects' in node && Array.isArray(node.effects) && node.effects.length > 0) {
        let appliedToken = false;
        // 1. Check for Effect Style ID
        if ('effectStyleId' in node && node.effectStyleId && typeof node.effectStyleId === 'string') {
             const cssVarName = tokens.effectStyleMap.get(node.effectStyleId);
             if (cssVarName) {
                 // Determine if it's likely a shadow or filter based on the generated value
                 const effectValue = tokens.cssVariables[cssVarName];
                 if (typeof effectValue === 'string') {
                     if (effectValue.includes('blur')) {
                        processed.styles['filter'] = `var(${cssVarName})`;
                        // TODO: Handle backdrop-filter separately if style has it
                     } else {
                        processed.styles['box-shadow'] = `var(${cssVarName})`;
                     }
                     appliedToken = true;
                      console.log(`    Applied effect token (Effect Style): var(${cssVarName})`);
                 }
             }
        }
        // 2. Fallback to raw effect processing (if no style applied)
        if (!appliedToken) {
             console.log(`    Applying raw effects (no style found/applied)`);
             const visibleEffects = node.effects.filter(e => e.visible);
             const shadows = visibleEffects.filter(e => e.type === 'DROP_SHADOW' || e.type === 'INNER_SHADOW')
                                           .map(shadowToCSS).join(', ');
             const layerBlur = visibleEffects.find(b => b.type === 'LAYER_BLUR');
             // ... (rest of existing raw effects logic) ...
        }
    }
}

function processTextNode(node: TextNode, processed: ProcessedNode, tokens: TokenCollection, mapping: ComponentMapping) {
    processed.htmlTag = 'span'; 
    processed.textContent = node.characters;

    // --- Typography ---
    let appliedTextStyle = false;
    // 1. Check for Text Style ID FIRST
    if ('textStyleId' in node && node.textStyleId && typeof node.textStyleId === 'string') {
        const styleVars = tokens.textStyleMap.get(node.textStyleId);
        if (styleVars) {
            console.log(`    Applying text style token variables for style ID: ${node.textStyleId}`);
            for (const [cssProp, cssVarName] of Object.entries(styleVars)) {
                processed.styles[cssProp] = `var(${cssVarName})`;
            }
            appliedTextStyle = true;
        }
    }

    // 2. If no text style applied, process individual properties (checking variables)
    if (!appliedTextStyle) {
        console.log(`    Applying raw text properties (no style found/applied)`);
        const fontSize = node.fontSize;
        const fontName = node.fontName;
        const textDecoration = node.textDecoration;
        const textCase = node.textCase;
        const lineHeight = node.lineHeight;
        const letterSpacing = node.letterSpacing;
        const textAlignHorizontal = node.textAlignHorizontal;
        const paragraphIndent = node.paragraphIndent;
        const paragraphSpacing = node.paragraphSpacing;

        // Font Size (check variable)
        let fontSizeVarId: string | undefined;
        if (node.boundVariables?.fontSize) {
             // Handle potential array of aliases - use the first one
             const fontSizeBinding = Array.isArray(node.boundVariables.fontSize) ? node.boundVariables.fontSize[0] : node.boundVariables.fontSize;
             fontSizeVarId = fontSizeBinding?.id;
        }
        let fontSizeVar = fontSizeVarId ? tokens.variableMap.get(fontSizeVarId) : undefined;
        if (fontSizeVar) {
            processed.styles['font-size'] = `var(${fontSizeVar})`;
            console.log(`    Applied font-size token (Variable): var(${fontSizeVar})`);
        } else if (typeof fontSize === 'number') {
            processed.styles['font-size'] = `${fontSize}px`;
        }

        // Font Family (check variable or use raw)
        // TODO: Add check for font family variable binding
        if (fontName !== figma.mixed && fontName?.family) {
            processed.styles['font-family'] = `"${fontName.family}"`; 
        }

        // Font Weight (check variable or use raw)
        // TODO: Add check for font weight variable binding
        if (fontName !== figma.mixed && typeof fontName?.style === 'string') {
            const weight = mapFontWeight(fontName.style);
            if (weight !== undefined) processed.styles['font-weight'] = String(weight);
        }

        // Text Decoration
        if (textDecoration !== figma.mixed) {
            if (textDecoration === 'UNDERLINE') processed.styles['text-decoration'] = 'underline';
            if (textDecoration === 'STRIKETHROUGH') processed.styles['text-decoration'] = 'line-through';
        }

        // Text Case
        if (textCase !== figma.mixed) {
            if (textCase === 'UPPER') processed.styles['text-transform'] = 'uppercase';
            if (textCase === 'LOWER') processed.styles['text-transform'] = 'lowercase';
            if (textCase === 'TITLE') processed.styles['text-transform'] = 'capitalize';
        }

        // Line Height (check variable)
        let lineHeightVarId: string | undefined;
        if (node.boundVariables?.lineHeight) {
             const lineHeightBinding = Array.isArray(node.boundVariables.lineHeight) ? node.boundVariables.lineHeight[0] : node.boundVariables.lineHeight;
             lineHeightVarId = lineHeightBinding?.id;
        }
        let lineHeightVar = lineHeightVarId ? tokens.variableMap.get(lineHeightVarId) : undefined;
        if (lineHeightVar) {
            processed.styles['line-height'] = `var(${lineHeightVar})`;
            console.log(`    Applied line-height token (Variable): var(${lineHeightVar})`);
        } else if (lineHeight !== figma.mixed && lineHeight.unit !== 'AUTO') {
            if (typeof lineHeight.value === 'number') {
                processed.styles['line-height'] = `${String(lineHeight.value)}${lineHeight.unit === 'PERCENT' ? '%' : 'px'}`;
            }
        }
        
        // Letter Spacing (check variable)
        let letterSpacingVarId: string | undefined;
        if (node.boundVariables?.letterSpacing) {
            const letterSpacingBinding = Array.isArray(node.boundVariables.letterSpacing) ? node.boundVariables.letterSpacing[0] : node.boundVariables.letterSpacing;
            letterSpacingVarId = letterSpacingBinding?.id;
        }
        let letterSpacingVar = letterSpacingVarId ? tokens.variableMap.get(letterSpacingVarId) : undefined;
         if (letterSpacingVar) {
            processed.styles['letter-spacing'] = `var(${letterSpacingVar})`;
            console.log(`    Applied letter-spacing token (Variable): var(${letterSpacingVar})`);
        } else if (letterSpacing !== figma.mixed) {
            if (typeof letterSpacing.value === 'number' && letterSpacing.value !== 0) {
                processed.styles['letter-spacing'] = `${String(letterSpacing.value)}${letterSpacing.unit === 'PERCENT' ? '%' : 'px'}`;
            }
        }

        // Text Align
        if (textAlignHorizontal !== figma.mixed) {
            processed.styles['text-align'] = textAlignHorizontal.toLowerCase();
        }

        // Paragraph Indent & Spacing
        // TODO: Check for bound variables if applicable
        if (paragraphIndent > 0) processed.styles['text-indent'] = `${paragraphIndent}px`;
        if (paragraphSpacing > 0) processed.styles['margin-bottom'] = `${paragraphSpacing}px`;
    }

    // --- Text Color (from fills) ---
    // Apply fill variable/style OR raw fill color AFTER text style vars
    if (Array.isArray(node.fills) && node.fills.length > 0) {
        const fill = node.fills.find(f => f.visible && f.type === 'SOLID');
        if (fill && fill.type === 'SOLID') {
             let appliedColorToken = false;
            // Check bound fill variable 
            if ('boundVariables' in fill && fill.boundVariables?.color) {
                 // ... (apply color var) ...
                 appliedColorToken = true;
            }
            // Check textStyleId for fillStyleId association? (Less common)
            // Check fillStyleId on the text node itself?
            else if (!appliedColorToken && 'fillStyleId' in node && node.fillStyleId && typeof node.fillStyleId === 'string') {
                 const cssVarName = tokens.paintStyleMap.get(node.fillStyleId);
                 if (cssVarName) {
                     processed.styles['color'] = `var(${cssVarName})`;
                     appliedColorToken = true;
                     console.log(`    Applied text color token (Paint Style): var(${cssVarName})`);
                 }
            }
            
            if (!appliedColorToken) {
                 console.log(`    Applying raw text color (no variable or style found/applied)`);
                processed.styles['color'] = colorToCSS(fill.color, fill.opacity);
            }
        }
    }
}

// --- Code Generation Functions ---

function generateAngularCode(nodes: ProcessedNode[], tokens: TokenCollection, mapping: ComponentMapping): { html: string; scss: string; ts: string } {
    let html = '';
    let scss = '';
    const componentName = 'GeneratedComponent'; 
    const selectorName = 'app-generated';

    // Generate :root definitions for CSS Variables
    const tokenDefinitions = Object.entries(tokens.cssVariables)
        .map(([name, value]) => `  ${name}: ${value};`)
        .join('\n');
    
    scss += `:root {
${tokenDefinitions}
}

`;

    // Collect all unique inputs from processed instances
    const allInputs = new Map<string, string>(); // Map input name to inferred TS type
    const traverseForInputs = (pNode: ProcessedNode) => {
        if (pNode.isInstance && pNode.inputs) {
            Object.entries(pNode.inputs).forEach(([inputName, value]) => { // Use Object.entries to get value
                if (!allInputs.has(inputName)) {
                    // Infer basic type from the override value
                    let inputType = 'any'; // Default
                    const valueType = typeof value;
                    if (valueType === 'string') {
                        inputType = 'string';
                    } else if (valueType === 'boolean') {
                        inputType = 'boolean';
                    } else if (valueType === 'number') {
                        inputType = 'number';
                    } 
                    // TODO: Can we use the actual propData.type from component definition for better inference?
                    // This would require accessing mainComponent.componentPropertyDefinitions perhaps.
                    allInputs.set(inputName, inputType); 
                    console.log(`    -> Inferred input type for ${inputName}: ${inputType}`);
                }
            });
        }
        pNode.children.forEach(traverseForInputs);
    };
    nodes.forEach(traverseForInputs);

    // Generate HTML and SCSS for nodes
    for (const node of nodes) {
        html += generateNodeHtml(node);
        scss += generateNodeScss(node);
    }

    // Add basic :host styles
    scss += `
:host {
  display: block; 
}
`; 

    // Generate TS structure with @Input()s
    let inputDefinitions = '';
    if (allInputs.size > 0) {
        inputDefinitions = Array.from(allInputs.entries())
            .map(([name, type]) => `  @Input() ${name}: ${type};`)
            .join('\n');
        inputDefinitions += '\n'; // Add a newline after inputs
    }

    const ts = `import { Component, Input } from '@angular/core';

@Component({
  selector: '${selectorName}',
  templateUrl: './${componentName.toLowerCase()}.component.html',
  styleUrls: ['./${componentName.toLowerCase()}.component.scss']
})
export class ${componentName} {
${inputDefinitions}
  constructor() { }
}
`;

    return { html, scss, ts };
}

function generateNodeHtml(node: ProcessedNode, indent: string = ''): string {
    let attributes = node.cssClasses.length > 0 ? ` class="${node.cssClasses.join(' ')}"` : '';
    
    if (node.isInstance && node.inputs) {
        for (const inputName in node.inputs) {
            const value = node.inputs[inputName];
            let bindingValue: string;
            if (typeof value === 'string') {
                // Escape single quotes within string value for binding inside single quotes
                const escapedValue = value.replace(/\'/g, "\\'"); 
                bindingValue = `'${escapedValue}'`; 
            } else if (typeof value === 'boolean' || typeof value === 'number') {
                bindingValue = String(value); 
            } else {
                // Includes objects (e.g., from INSTANCE_SWAP) or null/undefined
                 console.warn(`Unsupported input type for binding: ${typeof value} for input ${inputName}. Binding as string.`);
                 bindingValue = `'${String(value)}'`; // Fallback to string representation
            }
            attributes += ` [${inputName}]="${bindingValue}"`;
        }
    }

    let startTag = `${indent}<${node.htmlTag}${attributes}>`;
    let innerHtml = '';

    // --- Embed SVG Content --- 
    if (node.svgContent) {
        // Indent the SVG content slightly for readability
        const indentedSvg = node.svgContent.split('\n').map(line => indent + '  ' + line).join('\n');
        innerHtml = '\n' + indentedSvg + '\n' + indent;
    } else if (node.children.length > 0) {
        // --- Standard Children --- 
        innerHtml += '\n';
        for (const child of node.children) {
            innerHtml += generateNodeHtml(child, indent + '  ');
        }
        innerHtml += indent;
    } else if (node.textContent) {
        // --- Text Content --- 
        const escapedText = node.textContent
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        innerHtml += escapedText;
    } 
    
    return `${startTag}${innerHtml}</${node.htmlTag}>\n`;
}

function generateNodeScss(node: ProcessedNode, indent: string = ''): string {
    let nodeScss = '';
    const selector = `.${node.cssClasses[0]}`; // Use the unique ID class

    const styleEntries = Object.entries(node.styles);
    if (styleEntries.length > 0) {
        nodeScss += `${indent}${selector} {
`;
        for (const [key, value] of styleEntries) {
            nodeScss += `${indent}  ${key}: ${value};
`;
        }
        nodeScss += `${indent}}

`;
    }

    // Recursively add children styles
    for (const child of node.children) {
        nodeScss += generateNodeScss(child, indent); // Keep same indent level for flat SCSS structure
    }

    return nodeScss;
}

// --- Utility Functions ---

function colorToCSS(rgb: RGB | RGBA, opacity?: number): string {
    const r = Math.round(rgb.r * 255);
    const g = Math.round(rgb.g * 255);
    const b = Math.round(rgb.b * 255);
    const a = opacity ?? ('a' in rgb ? rgb.a : 1);

    if (a === 1) {
        return `rgb(${r}, ${g}, ${b})`;
    } else {
        // Limit alpha to 3 decimal places for cleaner output
        return `rgba(${r}, ${g}, ${b}, ${a.toFixed(3)})`;
    }
}

function gradientToCSS(fill: GradientPaint): string {
    // Basic Linear Gradient
    if (fill.type === 'GRADIENT_LINEAR') {
        const stops = fill.gradientStops.map(stop => 
            `${colorToCSS(stop.color)} ${Math.round(stop.position * 100)}%`
        ).join(', ');
        // TODO: Calculate angle from transform
        const angle = calculateGradientAngle(fill.gradientTransform);
        return `linear-gradient(${angle.toFixed(1)}deg, ${stops})`;
    }
    // TODO: Add other gradient types (RADIAL, ANGULAR, DIAMOND)
    return '/* Unsupported gradient type */';
}

function calculateGradientAngle(transform: Transform): number {
    // Simplified: Assumes transform maps [0, 0] to [1, 0] for the gradient vector
    // More accurate calculation involves atan2(transform[1][0], transform[0][0])
    // Defaulting to 180deg (top to bottom) for simplicity if transform is standard
    if (isApprox(transform[0][0], 1) && isApprox(transform[0][1], 0) && isApprox(transform[1][0], 0) && isApprox(transform[1][1], 1)) {
         return 180;
    }
    // A common case is left-to-right (90deg)
    if (isApprox(transform[0][0], 0) && isApprox(transform[0][1], 1) && isApprox(transform[1][0], -1) && isApprox(transform[1][1], 0)) {
        return 90;
    }
    // Basic calculation using atan2 for the direction of the x-axis under the transform
    let angleRad = Math.atan2(transform[1][0], transform[0][0]);
    let angleDeg = (angleRad * 180 / Math.PI);
    // Adjust angle based on CSS convention (0deg = to top, 90deg = to right)
    return (angleDeg + 90) % 360;
}

function isApprox(num1: number, num2: number, epsilon = 0.001): boolean {
    return Math.abs(num1 - num2) < epsilon;
}


function shadowToCSS(effect: DropShadowEffect | InnerShadowEffect): string {
    const type = effect.type === 'INNER_SHADOW' ? 'inset ' : '';
    const x = effect.offset.x;
    const y = effect.offset.y;
    const blur = effect.radius;
    const spread = effect.spread || 0;
    const color = colorToCSS(effect.color);
    return `${type}${x}px ${y}px ${blur}px ${spread}px ${color}`;
}

function convertAlignContent(figmaAlign: 'MIN' | 'CENTER' | 'MAX' | 'SPACE_BETWEEN'): string {
    switch (figmaAlign) {
        case 'MIN': return 'flex-start';
        case 'CENTER': return 'center';
        case 'MAX': return 'flex-end';
        case 'SPACE_BETWEEN': return 'space-between';
        // Figma doesn't have space-around/space-evenly for primary axis alignment
        default: return 'flex-start'; // Default
    }
}

function convertAlignItems(figmaAlign: 'MIN' | 'CENTER' | 'MAX' | 'BASELINE'): string {
     // Note: Figma's 'BASELINE' alignment for counter axis is tricky. 
     // CSS 'baseline' usually works if direct children are text or have intrinsic baseline.
     // Might require more complex handling (e.g., wrapper divs) in some cases.
    switch (figmaAlign) {
        case 'MIN': return 'flex-start';
        case 'CENTER': return 'center';
        case 'MAX': return 'flex-end';
        case 'BASELINE': return 'baseline'; 
        default: return 'stretch'; // Default for align-items is often stretch
    }
}

function convertAlignSelf(figmaAlign: 'MIN' | 'CENTER' | 'MAX' | 'BASELINE' | 'STRETCH'): string {
     switch (figmaAlign) {
        case 'MIN': return 'flex-start';
        case 'CENTER': return 'center';
        case 'MAX': return 'flex-end';
        case 'BASELINE': return 'baseline';
        case 'STRETCH': return 'stretch';
        default: return 'auto';
    }
}

function mapFontWeight(style: string): number | string | undefined {
    const lowerStyle = style.toLowerCase();
    if (lowerStyle.includes('thin')) return 100;
    if (lowerStyle.includes('extralight') || lowerStyle.includes('ultra light')) return 200;
    if (lowerStyle.includes('light')) return 300;
    if (lowerStyle.includes('normal') || lowerStyle.includes('regular')) return 400;
    if (lowerStyle.includes('medium')) return 500;
    if (lowerStyle.includes('semibold') || lowerStyle.includes('demi bold')) return 600;
    if (lowerStyle.includes('bold') && !lowerStyle.includes('extra') && !lowerStyle.includes('black')) return 700;
    if (lowerStyle.includes('extrabold') || lowerStyle.includes('ultra bold')) return 800;
    if (lowerStyle.includes('black') || lowerStyle.includes('heavy')) return 900;
    // Fallback for named styles like 'Bold', 'Regular'
    if (style === 'Bold') return 700;
    if (style === 'Regular') return 400;
    return undefined; // Cannot map reliably
}

// Add helper function for image scale mode
function mapScaleMode(scaleMode: 'FILL' | 'FIT' | 'CROP' | 'TILE'): string {
    switch (scaleMode) {
        case 'FILL': return 'cover';
        case 'FIT': return 'contain';
        case 'CROP': return 'cover'; // CSS cover is often the closest for CROP
        case 'TILE': return 'auto'; // CSS default tiling, or use background-repeat: repeat?
        default: return 'cover';
    }
}

// Add function to parse mapping string
function parseMappingConfig(mappingString: string): ComponentMapping {
    const mapping: ComponentMapping = {};
    if (!mappingString) return mapping;

    const lines = mappingString.split('\n');
    for (const line of lines) {
        const trimmedLine = line.trim();
        if (!trimmedLine || trimmedLine.startsWith('#') || trimmedLine.startsWith('//')) continue; // Skip empty lines/comments
        
        const parts = trimmedLine.split('=');
        if (parts.length === 2) {
            const figmaName = parts[0].trim();
            const angularSelector = parts[1].trim();
            if (figmaName && angularSelector) {
                mapping[figmaName] = angularSelector;
            }
        } else {
             console.warn(`Invalid mapping line skipped: "${trimmedLine}"`);
        }
    }
    return mapping;
}

// TODO: Add more utility functions as needed (e.g., for token mapping, asset handling) 