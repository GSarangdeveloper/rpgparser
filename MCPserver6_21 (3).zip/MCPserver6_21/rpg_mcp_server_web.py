#!/usr/bin/env python3
"""
RPG Processing Tool MCP Server with Web Interface
This version provides both MCP protocol and HTTP/SSE endpoints
"""

import os
import json
import uuid
import asyncio
import subprocess
import tempfile
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
import logging

# Web framework imports
from aiohttp import web
from aiohttp_sse import sse_response
import aiohttp_cors

# MCP SDK imports
from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.types import Tool, TextContent, Resource, ResourceContents

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RPGProcessingWebServer:
    def __init__(self, tool_path: str = None, web_port: int = 8080):
        """Initialize the RPG Processing Server with Web Interface"""
        self.server = Server("rpg-processor-web")
        self.tool_path = tool_path or os.getenv("RPG_TOOL_PATH", "./rpg_processor.exe")
        self.jobs: Dict[str, Dict[str, Any]] = {}
        self.output_dir = Path("./rpg_outputs")
        self.output_dir.mkdir(exist_ok=True)
        self.web_port = web_port
        self.web_app = web.Application()
        self.sse_clients: Dict[str, List[web.StreamResponse]] = {}
        
        # Setup web routes
        self._setup_web_routes()
        
        # Register MCP handlers
        self._register_mcp_handlers()
    
    def _setup_web_routes(self):
        """Setup HTTP endpoints"""
        # Configure CORS
        cors = aiohttp_cors.setup(self.web_app, defaults={
            "*": aiohttp_cors.ResourceOptions(
                allow_credentials=True,
                expose_headers="*",
                allow_headers="*"
            )
        })
        
        # Define routes
        self.web_app.router.add_post('/api/process', self.handle_web_process)
        self.web_app.router.add_get('/api/jobs/{job_id}', self.handle_get_job)
        self.web_app.router.add_get('/api/jobs/{job_id}/artifacts/{artifact_name}', self.handle_get_artifact)
        self.web_app.router.add_get('/api/jobs', self.handle_list_jobs)
        self.web_app.router.add_get('/api/sse/{job_id}', self.handle_sse)
        self.web_app.router.add_get('/health', self.handle_health)
        
        # Add CORS to all routes
        for route in list(self.web_app.router.routes()):
            cors.add(route)
    
    async def handle_health(self, request):
        """Health check endpoint"""
        return web.json_response({
            "status": "healthy",
            "version": "1.2.0",
            "mcp_enabled": True,
            "web_enabled": True
        })
    
    async def handle_web_process(self, request):
        """Handle web-based processing requests"""
        try:
            data = await request.json()
            
            # Validate input
            required_fields = ['rpg_file_content', 'parameter1', 'parameter2']
            for field in required_fields:
                if field not in data:
                    return web.json_response(
                        {"error": f"Missing required field: {field}"},
                        status=400
                    )
            
            # Start processing
            job_id = str(uuid.uuid4())
            
            # Start async processing
            asyncio.create_task(self._process_rpg_async(job_id, data))
            
            # Return job ID immediately
            return web.json_response({
                "job_id": job_id,
                "status": "processing",
                "sse_url": f"/api/sse/{job_id}",
                "poll_url": f"/api/jobs/{job_id}"
            })
            
        except Exception as e:
            return web.json_response(
                {"error": str(e)},
                status=500
            )
    
    async def handle_get_job(self, request):
        """Get job status"""
        job_id = request.match_info['job_id']
        
        if job_id not in self.jobs:
            return web.json_response(
                {"error": "Job not found"},
                status=404
            )
        
        return web.json_response(self.jobs[job_id])
    
    async def handle_get_artifact(self, request):
        """Download artifact"""
        job_id = request.match_info['job_id']
        artifact_name = request.match_info['artifact_name']
        
        if job_id not in self.jobs:
            return web.json_response(
                {"error": "Job not found"},
                status=404
            )
        
        job_data = self.jobs[job_id]
        for artifact in job_data.get("artifacts", []):
            if artifact["name"] == artifact_name:
                file_path = Path(artifact["path"])
                if file_path.exists():
                    return web.FileResponse(
                        file_path,
                        headers={
                            'Content-Type': 'text/markdown',
                            'Content-Disposition': f'attachment; filename="{artifact_name}"'
                        }
                    )
        
        return web.json_response(
            {"error": "Artifact not found"},
            status=404
        )
    
    async def handle_list_jobs(self, request):
        """List all jobs"""
        return web.json_response({
            "jobs": list(self.jobs.values())
        })
    
    async def handle_sse(self, request):
        """Server-Sent Events endpoint for real-time updates"""
        job_id = request.match_info['job_id']
        
        async with sse_response(request) as resp:
            # Register client
            if job_id not in self.sse_clients:
                self.sse_clients[job_id] = []
            self.sse_clients[job_id].append(resp)
            
            try:
                # Send initial status
                if job_id in self.jobs:
                    await resp.send(json.dumps(self.jobs[job_id]), event='status')
                
                # Keep connection alive
                while not resp.task.done():
                    await asyncio.sleep(1)
                    
            finally:
                # Cleanup
                if job_id in self.sse_clients:
                    self.sse_clients[job_id].remove(resp)
                    if not self.sse_clients[job_id]:
                        del self.sse_clients[job_id]
        
        return resp
    
    async def _broadcast_progress(self, job_id: str, data: Dict[str, Any]):
        """Broadcast progress to SSE clients"""
        if job_id in self.sse_clients:
            for client in self.sse_clients[job_id]:
                try:
                    await client.send(json.dumps(data), event='progress')
                except Exception:
                    pass  # Client disconnected
    
    async def _process_rpg_async(self, job_id: str, data: Dict[str, Any]):
        """Async processing with progress updates"""
        job_dir = self.output_dir / job_id
        job_dir.mkdir(exist_ok=True)
        
        try:
            # Initialize job
            self.jobs[job_id] = {
                "id": job_id,
                "status": "processing",
                "started_at": datetime.now().isoformat(),
                "parameters": {
                    "parameter1": data['parameter1'],
                    "parameter2": data['parameter2']
                },
                "progress": 0
            }
            
            await self._broadcast_progress(job_id, {
                "message": "Starting processing...",
                "progress": 0
            })
            
            # Create temp file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tmp_file:
                tmp_file.write(data['rpg_file_content'])
                tmp_file_path = tmp_file.name
            
            # Execute tool
            cmd = [
                self.tool_path,
                tmp_file_path,
                data['parameter1'],
                data['parameter2'],
                str(job_dir)
            ]
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            # Simulate progress (replace with actual progress parsing)
            progress_steps = [
                (10, "Parsing RPG code..."),
                (30, "Analyzing business logic..."),
                (50, "Generating flow diagram..."),
                (70, "Creating target code..."),
                (90, "Finalizing documentation...")
            ]
            
            for progress, message in progress_steps:
                await asyncio.sleep(1)  # Simulate work
                self.jobs[job_id]["progress"] = progress
                await self._broadcast_progress(job_id, {
                    "message": message,
                    "progress": progress
                })
            
            # Wait for completion
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                raise Exception(f"Tool failed: {stderr.decode()}")
            
            # Collect artifacts
            artifacts = []
            expected_files = [
                ("business_logic.md", "Business Logic"),
                ("parsed_code.md", "Parsed Code"),
                ("flow_diagram.md", "Flow Diagram"),
                ("target_code.md", "Target Code"),
                ("documentation.md", "Documentation")
            ]
            
            for filename, artifact_type in expected_files:
                file_path = job_dir / filename
                if file_path.exists():
                    artifacts.append({
                        "name": filename,
                        "type": artifact_type,
                        "path": str(file_path),
                        "size": file_path.stat().st_size,
                        "download_url": f"/api/jobs/{job_id}/artifacts/{filename}"
                    })
            
            # Update job status
            self.jobs[job_id].update({
                "status": "completed",
                "completed_at": datetime.now().isoformat(),
                "artifacts": artifacts,
                "progress": 100
            })
            
            await self._broadcast_progress(job_id, {
                "message": "Processing complete!",
                "progress": 100,
                "artifacts": artifacts
            })
            
        except Exception as e:
            self.jobs[job_id].update({
                "status": "failed",
                "error": str(e),
                "progress": -1
            })
            
            await self._broadcast_progress(job_id, {
                "message": f"Error: {str(e)}",
                "progress": -1
            })
        
        finally:
            if 'tmp_file_path' in locals() and os.path.exists(tmp_file_path):
                os.unlink(tmp_file_path)
    
    def _register_mcp_handlers(self):
        """Register MCP protocol handlers"""
        
        @self.server.list_tools()
        async def handle_list_tools() -> List[Tool]:
            return [
                Tool(
                    name="process_rpg",
                    description="Process RPG code via web interface",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "rpg_file_content": {"type": "string"},
                            "parameter1": {"type": "string"},
                            "parameter2": {"type": "string"}
                        },
                        "required": ["rpg_file_content", "parameter1", "parameter2"]
                    }
                )
            ]
        
        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            if name == "process_rpg":
                # Use web processing
                job_id = str(uuid.uuid4())
                await self._process_rpg_async(job_id, arguments)
                
                # Wait for completion (with timeout)
                timeout = 300  # 5 minutes
                start_time = asyncio.get_event_loop().time()
                
                while self.jobs[job_id]["status"] == "processing":
                    if asyncio.get_event_loop().time() - start_time > timeout:
                        return [TextContent(type="text", text="Processing timeout")]
                    await asyncio.sleep(1)
                
                if self.jobs[job_id]["status"] == "completed":
                    response = f"Processing complete! Job ID: {job_id}\n\n"
                    response += f"Web UI: http://localhost:{self.web_port}/api/jobs/{job_id}\n\n"
                    response += "Artifacts:\n"
                    for artifact in self.jobs[job_id]["artifacts"]:
                        response += f"- {artifact['type']}: {artifact['download_url']}\n"
                    return [TextContent(type="text", text=response)]
                else:
                    return [TextContent(type="text", text=f"Processing failed: {self.jobs[job_id].get('error')}")]
            
            raise ValueError(f"Unknown tool: {name}")
    
    async def run(self):
        """Run both MCP and Web servers"""
        # Start web server
        runner = web.AppRunner(self.web_app)
        await runner.setup()
        site = web.TCPSite(runner, 'localhost', self.web_port)
        
        asyncio.create_task(site.start())
        logger.info(f"Web server started on http://localhost:{self.web_port}")
        
        # Run MCP server
        from mcp.server.stdio import stdio_server
        
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="rpg-processor-web",
                    server_version="1.2.0"
                )
            )

def main():
    """Main entry point"""
    import sys
    
    tool_path = sys.argv[1] if len(sys.argv) > 1 else None
    web_port = int(sys.argv[2]) if len(sys.argv) > 2 else 8080
    
    server = RPGProcessingWebServer(tool_path, web_port)
    asyncio.run(server.run())

if __name__ == "__main__":
    main()