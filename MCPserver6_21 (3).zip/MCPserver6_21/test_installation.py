#!/usr/bin/env python3
"""
Installation test script for RPG MCP Server
Tests dependencies and configuration
"""

import sys
import subprocess
import json
from pathlib import Path

def check_python_version():
    """Check Python version"""
    version = sys.version_info
    print(f"Python version: {version.major}.{version.minor}.{version.micro}")
    if version.major >= 3 and version.minor >= 7:
        print("✓ Python version is compatible")
        return True
    else:
        print("✗ Python 3.7+ is required")
        return False

def check_package(package_name):
    """Check if a package is installed"""
    try:
        result = subprocess.run([sys.executable, "-m", "pip", "show", package_name], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            # Extract version
            for line in result.stdout.split('\n'):
                if line.startswith('Version:'):
                    version = line.split(':', 1)[1].strip()
                    print(f"✓ {package_name} is installed (version {version})")
                    return True
        print(f"✗ {package_name} is not installed")
        return False
    except Exception as e:
        print(f"✗ Could not check {package_name}: {e}")
        return False

def check_tool_executable():
    """Check if the mock tool is executable"""
    tool_path = Path("./mock_rpg_tool.py")
    if tool_path.exists():
        print(f"✓ Mock RPG tool exists at {tool_path}")
        # Test execution
        try:
            result = subprocess.run([sys.executable, str(tool_path)], 
                                  capture_output=True, text=True)
            if "Usage:" in result.stdout:
                print("✓ Mock RPG tool is executable")
                return True
        except Exception as e:
            print(f"✗ Mock RPG tool execution failed: {e}")
    else:
        print("✗ Mock RPG tool not found")
    return False

def check_config_files():
    """Check configuration files"""
    config_files = {
        "rpg_processor_config.json": "MCP configuration",
        "requirements.txt": "Basic dependencies",
        "requirements_web.txt": "Web server dependencies"
    }
    
    all_exist = True
    for file, description in config_files.items():
        if Path(file).exists():
            print(f"✓ {description} file exists: {file}")
            
            # Validate JSON files
            if file.endswith('.json'):
                try:
                    with open(file, 'r') as f:
                        json.load(f)
                    print(f"  └─ JSON is valid")
                except json.JSONDecodeError as e:
                    print(f"  └─ JSON is invalid: {e}")
                    all_exist = False
        else:
            print(f"✗ {description} file missing: {file}")
            all_exist = False
    
    return all_exist

def simulate_server_init():
    """Simulate server initialization"""
    print("\n=== Simulating Server Initialization ===")
    
    # Check if output directory would be created
    output_dir = Path("./rpg_outputs")
    if output_dir.exists():
        print(f"✓ Output directory exists: {output_dir}")
    else:
        print(f"→ Output directory would be created: {output_dir}")
    
    # Simulate environment variable check
    import os
    tool_path = os.getenv("RPG_TOOL_PATH", "./mock_rpg_tool.py")
    print(f"→ Tool path from env or default: {tool_path}")
    
    # Check if tool path exists
    if Path(tool_path).exists():
        print(f"✓ Tool path is valid")
    else:
        print(f"⚠ Tool path not found (will need configuration)")

def generate_cursor_config():
    """Generate Cursor configuration example"""
    print("\n=== Cursor AI Configuration ===")
    
    config = {
        "mcpServers": {
            "rpg-processor": {
                "command": "python",
                "args": [str(Path.cwd() / "rpg_mcp_server.py")],
                "env": {
                    "RPG_TOOL_PATH": str(Path.cwd() / "mock_rpg_tool.py")
                }
            }
        }
    }
    
    print("Add this to your Cursor settings:")
    print(json.dumps(config, indent=2))
    
    # Save to file for easy copying
    with open("cursor_config_example.json", "w") as f:
        json.dump(config, f, indent=2)
    print("\n✓ Configuration saved to cursor_config_example.json")

def main():
    print("=== RPG MCP Server Installation Test ===\n")
    
    # Run checks
    checks = [
        ("Python Version", check_python_version),
        ("Mock Tool", check_tool_executable),
        ("Configuration Files", check_config_files)
    ]
    
    all_passed = True
    for name, check_func in checks:
        print(f"\n--- {name} Check ---")
        if not check_func():
            all_passed = False
    
    # Check dependencies (without failing if pip doesn't exist)
    print("\n--- Package Dependencies ---")
    print("Required packages:")
    packages = ["mcp", "asyncio", "pathlib"]
    for package in packages:
        if subprocess.run([sys.executable, "-c", f"import {package}"], 
                         capture_output=True).returncode == 0:
            print(f"✓ {package} is available")
        else:
            print(f"✗ {package} needs to be installed")
    
    # Simulate initialization
    simulate_server_init()
    
    # Generate config
    generate_cursor_config()
    
    print("\n=== Summary ===")
    if all_passed:
        print("✓ Basic requirements are met!")
        print("\nNext steps:")
        print("1. Install MCP package: pip install mcp")
        print("2. Update RPG_TOOL_PATH to point to your actual RPG tool")
        print("3. Copy cursor_config_example.json content to Cursor settings")
        print("4. Restart Cursor to load the MCP server")
    else:
        print("✗ Some requirements are missing. Please fix the issues above.")

if __name__ == "__main__":
    main()