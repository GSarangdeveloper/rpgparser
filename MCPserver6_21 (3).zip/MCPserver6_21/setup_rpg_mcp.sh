#!/bin/bash
# Setup script for RPG Processing MCP Server

echo "Setting up RPG Processing MCP Server..."

# Create virtual environment
echo "Creating virtual environment..."
python -m venv venv

# Activate virtual environment
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    source venv/Scripts/activate
else
    source venv/bin/activate
fi

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Create output directory
mkdir -p rpg_outputs

echo "Setup complete!"
echo ""
echo "To configure for Cursor AI:"
echo "1. Copy the content of rpg_processor_config.json to your Cursor settings"
echo "2. Update RPG_TOOL_PATH in the config to point to your RPG processing tool"
echo "3. Restart Cursor to load the MCP server"
echo ""
echo "To run the server manually:"
echo "python rpg_mcp_server.py [path_to_your_rpg_tool]"