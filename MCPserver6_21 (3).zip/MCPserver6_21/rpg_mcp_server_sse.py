#!/usr/bin/env python3
"""
RPG Processing Tool MCP Server with SSE Support
This version includes Server-Sent Events for real-time progress updates
"""

import os
import json
import uuid
import asyncio
import subprocess
import tempfile
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
import logging

# MCP SDK imports
from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.types import (
    Tool,
    TextContent,
    Resource,
    ResourceContents,
    Notification,
    LoggingLevel
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RPGProcessingServerSSE:
    def __init__(self, tool_path: str = None):
        """Initialize the RPG Processing MCP Server with SSE support"""
        self.server = Server("rpg-processor-sse")
        self.tool_path = tool_path or os.getenv("RPG_TOOL_PATH", "./rpg_processor.exe")
        self.jobs: Dict[str, Dict[str, Any]] = {}
        self.output_dir = Path("./rpg_outputs")
        self.output_dir.mkdir(exist_ok=True)
        
        # Register handlers
        self._register_handlers()
    
    def _register_handlers(self):
        """Register all MCP protocol handlers"""
        
        @self.server.list_tools()
        async def handle_list_tools() -> List[Tool]:
            """List available tools"""
            return [
                Tool(
                    name="process_rpg",
                    description="Process RPG code file with real-time progress updates",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "rpg_file_content": {
                                "type": "string",
                                "description": "The RPG code content to process"
                            },
                            "parameter1": {
                                "type": "string",
                                "description": "First additional parameter for processing"
                            },
                            "parameter2": {
                                "type": "string",
                                "description": "Second additional parameter for processing"
                            }
                        },
                        "required": ["rpg_file_content", "parameter1", "parameter2"]
                    }
                )
            ]
        
        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            """Handle tool execution with progress notifications"""
            if name == "process_rpg":
                return await self._process_rpg_with_progress(arguments)
            else:
                raise ValueError(f"Unknown tool: {name}")
        
        @self.server.list_resources()
        async def handle_list_resources() -> List[Resource]:
            """List all available resources"""
            resources = []
            for job_id, job_data in self.jobs.items():
                if job_data.get("status") == "completed":
                    for artifact in job_data.get("artifacts", []):
                        resources.append(
                            Resource(
                                uri=f"rpg://jobs/{job_id}/{artifact['name']}",
                                name=f"{job_id}/{artifact['name']}",
                                description=f"{artifact['type']} for job {job_id}",
                                mimeType="text/markdown"
                            )
                        )
            return resources
        
        @self.server.read_resource()
        async def handle_read_resource(uri: str) -> ResourceContents:
            """Read a specific resource"""
            parts = uri.replace("rpg://", "").split("/")
            if len(parts) >= 3 and parts[0] == "jobs":
                job_id = parts[1]
                artifact_name = "/".join(parts[2:])
                
                if job_id in self.jobs:
                    job_data = self.jobs[job_id]
                    for artifact in job_data.get("artifacts", []):
                        if artifact["name"] == artifact_name:
                            file_path = Path(artifact["path"])
                            if file_path.exists():
                                content = file_path.read_text(encoding='utf-8')
                                return ResourceContents(
                                    uri=uri,
                                    mimeType="text/markdown",
                                    contents=[TextContent(type="text", text=content)]
                                )
            
            raise ValueError(f"Resource not found: {uri}")
    
    async def _send_progress(self, job_id: str, message: str, progress: int = None):
        """Send progress notification"""
        notification_data = {
            "job_id": job_id,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        
        if progress is not None:
            notification_data["progress"] = progress
        
        # Send notification through MCP protocol
        await self.server.send_notification(
            Notification(
                method="rpg/progress",
                params=notification_data
            )
        )
        
        # Also log for debugging
        logger.info(f"Progress [{job_id}]: {message}")
    
    async def _process_rpg_with_progress(self, arguments: Dict[str, Any]) -> List[TextContent]:
        """Process RPG file with progress notifications"""
        job_id = str(uuid.uuid4())
        job_dir = self.output_dir / job_id
        job_dir.mkdir(exist_ok=True)
        
        try:
            # Send initial progress
            await self._send_progress(job_id, "Starting RPG processing...", 0)
            
            # Create temporary RPG file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tmp_file:
                tmp_file.write(arguments['rpg_file_content'])
                tmp_file_path = tmp_file.name
            
            await self._send_progress(job_id, "RPG file created, initializing processing...", 10)
            
            # Record job start
            self.jobs[job_id] = {
                "id": job_id,
                "status": "processing",
                "started_at": datetime.now().isoformat(),
                "parameters": {
                    "parameter1": arguments['parameter1'],
                    "parameter2": arguments['parameter2']
                }
            }
            
            # Prepare command
            cmd = [
                self.tool_path,
                tmp_file_path,
                arguments['parameter1'],
                arguments['parameter2'],
                str(job_dir)
            ]
            
            await self._send_progress(job_id, "Executing RPG processor...", 20)
            
            # Run the tool with real-time output
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            # Monitor process output
            progress_map = {
                "parsing": 30,
                "analyzing": 40,
                "generating business logic": 50,
                "creating flow diagram": 60,
                "generating target code": 70,
                "creating documentation": 80,
                "finalizing": 90
            }
            
            # Read output line by line for progress
            async def read_output():
                while True:
                    line = await process.stdout.readline()
                    if not line:
                        break
                    
                    line_text = line.decode().strip()
                    
                    # Check for progress indicators in output
                    for keyword, progress_value in progress_map.items():
                        if keyword in line_text.lower():
                            await self._send_progress(
                                job_id, 
                                f"Processing: {keyword}...", 
                                progress_value
                            )
                            break
            
            # Start reading output
            await read_output()
            
            # Wait for completion
            returncode = await process.wait()
            
            if returncode != 0:
                stderr = await process.stderr.read()
                error_msg = f"Tool execution failed: {stderr.decode()}"
                await self._send_progress(job_id, f"Error: {error_msg}", -1)
                
                self.jobs[job_id]["status"] = "failed"
                self.jobs[job_id]["error"] = error_msg
                return [TextContent(type="text", text=f"Error: {error_msg}")]
            
            await self._send_progress(job_id, "Processing complete, collecting artifacts...", 95)
            
            # Find generated artifacts
            artifacts = []
            expected_files = [
                ("business_logic.md", "Business Logic"),
                ("parsed_code.md", "Parsed Code"),
                ("flow_diagram.md", "Flow Diagram"),
                ("target_code.md", "Target Code"),
                ("documentation.md", "Documentation")
            ]
            
            for filename, artifact_type in expected_files:
                file_path = job_dir / filename
                if file_path.exists():
                    artifacts.append({
                        "name": filename,
                        "type": artifact_type,
                        "path": str(file_path),
                        "size": file_path.stat().st_size
                    })
            
            # Update job status
            self.jobs[job_id]["status"] = "completed"
            self.jobs[job_id]["completed_at"] = datetime.now().isoformat()
            self.jobs[job_id]["artifacts"] = artifacts
            
            await self._send_progress(job_id, "All artifacts generated successfully!", 100)
            
            # Prepare response
            response_text = f"""✅ RPG Processing completed successfully!

📋 Job ID: {job_id}

📁 Generated Artifacts:
"""
            for artifact in artifacts:
                response_text += f"• {artifact['type']}: rpg://jobs/{job_id}/{artifact['name']} ({artifact['size']} bytes)\n"
            
            response_text += f"""
🚀 Next Steps:
1. Read each artifact using the MCP resource URLs above
2. Save them to your project directory
3. Use this prompt for code generation:

"Using the business logic, parsed code, flow diagram, and target code from the RPG processing, please generate a Python application that implements the converted functionality. The application should follow the patterns shown in the target code while maintaining the business logic rules defined in the business_logic.md file."

⚙️ Parameters used:
• Parameter 1: {arguments['parameter1']}
• Parameter 2: {arguments['parameter2']}

💡 Tip: The artifacts are now available through the MCP resource system and can be accessed by any connected client.
"""
            
            return [TextContent(type="text", text=response_text)]
            
        except Exception as e:
            await self._send_progress(job_id, f"Fatal error: {str(e)}", -1)
            logger.error(f"Error processing RPG: {str(e)}")
            self.jobs[job_id]["status"] = "failed"
            self.jobs[job_id]["error"] = str(e)
            return [TextContent(type="text", text=f"Error: {str(e)}")]
        
        finally:
            # Cleanup temporary file
            if 'tmp_file_path' in locals() and os.path.exists(tmp_file_path):
                os.unlink(tmp_file_path)
    
    async def run(self):
        """Run the MCP server with SSE support"""
        from mcp.server.stdio import stdio_server
        
        # Log server capabilities
        await self.server.send_log(
            level=LoggingLevel.INFO,
            logger="rpg-processor",
            message="RPG Processing Server with SSE support started",
            data={"version": "1.1.0", "sse_enabled": True}
        )
        
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="rpg-processor-sse",
                    server_version="1.1.0",
                    capabilities={
                        "notifications": True,
                        "logging": True
                    }
                )
            )

def main():
    """Main entry point"""
    import sys
    
    # Get tool path from command line or environment
    tool_path = sys.argv[1] if len(sys.argv) > 1 else None
    
    # Create and run server
    server = RPGProcessingServerSSE(tool_path)
    asyncio.run(server.run())

if __name__ == "__main__":
    main()