#!/usr/bin/env python3
"""
Test script to verify MCP server syntax and structure
"""

import ast
import sys
from pathlib import Path

def check_python_syntax(file_path):
    """Check if Python file has valid syntax"""
    file_path = Path(file_path)
    try:
        with open(file_path, 'r') as f:
            source = f.read()
        
        # Parse the source code
        ast.parse(source)
        print(f"✓ {file_path.name}: Syntax is valid")
        return True
    except SyntaxError as e:
        print(f"✗ {file_path.name}: Syntax error at line {e.lineno}: {e.msg}")
        return False
    except Exception as e:
        print(f"✗ {file_path.name}: Error: {e}")
        return False

def check_imports(file_path):
    """Check which imports are available"""
    file_path = Path(file_path)
    with open(file_path, 'r') as f:
        source = f.read()
    
    tree = ast.parse(source)
    imports = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ''
            for alias in node.names:
                imports.append(f"{module}.{alias.name}" if module else alias.name)
    
    print(f"\nImports in {file_path.name}:")
    for imp in sorted(set(imports)):
        print(f"  - {imp}")
    
    return imports

def analyze_server_structure(file_path):
    """Analyze the server structure"""
    file_path = Path(file_path)
    with open(file_path, 'r') as f:
        source = f.read()
    
    tree = ast.parse(source)
    
    # Find classes and methods
    classes = []
    functions = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            classes.append(node.name)
            print(f"\nClass: {node.name}")
            for item in node.body:
                if isinstance(item, ast.FunctionDef):
                    print(f"  Method: {item.name}")
        elif isinstance(node, ast.FunctionDef) and node.col_offset == 0:
            functions.append(node.name)
    
    print(f"\nTop-level functions: {', '.join(functions)}")

def test_mock_tool():
    """Test the mock RPG tool"""
    print("\n=== Testing Mock RPG Tool ===")
    import subprocess
    import tempfile
    
    # Create test input
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write("TEST RPG CODE\nLINE 2\nLINE 3")
        test_file = f.name
    
    # Create temp output dir
    output_dir = Path("./test_output")
    output_dir.mkdir(exist_ok=True)
    
    try:
        # Run mock tool
        result = subprocess.run([
            sys.executable, "mock_rpg_tool.py",
            test_file, "param1_value", "param2_value", str(output_dir)
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✓ Mock tool executed successfully")
            print("Output:", result.stdout)
            
            # Check generated files
            expected_files = ["business_logic.md", "parsed_code.md", "flow_diagram.md", 
                            "target_code.md", "documentation.md"]
            for file in expected_files:
                if (output_dir / file).exists():
                    print(f"✓ Generated: {file}")
                else:
                    print(f"✗ Missing: {file}")
        else:
            print("✗ Mock tool failed:", result.stderr)
    
    finally:
        # Cleanup
        import os
        os.unlink(test_file)
        import shutil
        if output_dir.exists():
            shutil.rmtree(output_dir)

def main():
    print("=== MCP Server Syntax and Structure Test ===\n")
    
    # Test all server files
    server_files = [
        "rpg_mcp_server.py",
        "rpg_mcp_server_sse.py", 
        "rpg_mcp_server_web.py"
    ]
    
    all_valid = True
    for file in server_files:
        if Path(file).exists():
            print(f"\n--- Checking {file} ---")
            if not check_python_syntax(file):
                all_valid = False
            else:
                check_imports(file)
                if file == "rpg_mcp_server.py":
                    analyze_server_structure(file)
    
    # Test mock tool
    test_mock_tool()
    
    if all_valid:
        print("\n✓ All server files have valid Python syntax!")
        print("\nNote: The MCP package needs to be installed to run the servers.")
        print("Install with: pip install mcp")
    else:
        print("\n✗ Some files have syntax errors!")

if __name__ == "__main__":
    main()