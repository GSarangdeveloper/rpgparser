#!/usr/bin/env python3
"""
RPG Processing Tool MCP Server
This server wraps an existing RPG processing tool to expose it via MCP protocol
"""

import os
import json
import uuid
import asyncio
import subprocess
import tempfile
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
import logging

# MCP SDK imports
from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.types import (
    Tool,
    TextContent,
    Resource,
    ResourceContents,
    ResourceTemplate,
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RPGProcessingServer:
    def __init__(self, tool_path: str = None):
        """Initialize the RPG Processing MCP Server"""
        self.server = Server("rpg-processor")
        self.tool_path = tool_path or os.getenv("RPG_TOOL_PATH", "./rpg_processor.exe")
        self.jobs: Dict[str, Dict[str, Any]] = {}
        self.output_dir = Path("./rpg_outputs")
        self.output_dir.mkdir(exist_ok=True)
        
        # Register handlers
        self._register_handlers()
    
    def _register_handlers(self):
        """Register all MCP protocol handlers"""
        
        @self.server.list_tools()
        async def handle_list_tools() -> List[Tool]:
            """List available tools"""
            return [
                Tool(
                    name="process_rpg",
                    description="Process RPG code file and generate business logic, parsed code, flow diagram, target code, and documentation",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "rpg_file_content": {
                                "type": "string",
                                "description": "The RPG code content to process"
                            },
                            "parameter1": {
                                "type": "string",
                                "description": "First additional parameter for processing"
                            },
                            "parameter2": {
                                "type": "string",
                                "description": "Second additional parameter for processing"
                            }
                        },
                        "required": ["rpg_file_content", "parameter1", "parameter2"]
                    }
                )
            ]
        
        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            """Handle tool execution"""
            if name == "process_rpg":
                return await self._process_rpg(arguments)
            else:
                raise ValueError(f"Unknown tool: {name}")
        
        @self.server.list_resources()
        async def handle_list_resources() -> List[Resource]:
            """List all available resources (generated artifacts)"""
            resources = []
            for job_id, job_data in self.jobs.items():
                if job_data.get("status") == "completed":
                    for artifact in job_data.get("artifacts", []):
                        resources.append(
                            Resource(
                                uri=f"rpg://jobs/{job_id}/{artifact['name']}",
                                name=f"{job_id}/{artifact['name']}",
                                description=f"{artifact['type']} for job {job_id}",
                                mimeType="text/markdown"
                            )
                        )
            return resources
        
        @self.server.read_resource()
        async def handle_read_resource(uri: str) -> ResourceContents:
            """Read a specific resource"""
            parts = uri.replace("rpg://", "").split("/")
            if len(parts) >= 3 and parts[0] == "jobs":
                job_id = parts[1]
                artifact_name = "/".join(parts[2:])
                
                if job_id in self.jobs:
                    job_data = self.jobs[job_id]
                    for artifact in job_data.get("artifacts", []):
                        if artifact["name"] == artifact_name:
                            file_path = Path(artifact["path"])
                            if file_path.exists():
                                content = file_path.read_text(encoding='utf-8')
                                return ResourceContents(
                                    uri=uri,
                                    mimeType="text/markdown",
                                    contents=[TextContent(type="text", text=content)]
                                )
            
            raise ValueError(f"Resource not found: {uri}")
    
    async def _process_rpg(self, arguments: Dict[str, Any]) -> List[TextContent]:
        """Process RPG file using the external tool"""
        job_id = str(uuid.uuid4())
        job_dir = self.output_dir / job_id
        job_dir.mkdir(exist_ok=True)
        
        try:
            # Create temporary RPG file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tmp_file:
                tmp_file.write(arguments['rpg_file_content'])
                tmp_file_path = tmp_file.name
            
            # Record job start
            self.jobs[job_id] = {
                "id": job_id,
                "status": "processing",
                "started_at": datetime.now().isoformat(),
                "parameters": {
                    "parameter1": arguments['parameter1'],
                    "parameter2": arguments['parameter2']
                }
            }
            
            # Call external tool
            # Adjust this command based on how your tool is invoked
            cmd = [
                self.tool_path,
                tmp_file_path,
                arguments['parameter1'],
                arguments['parameter2'],
                str(job_dir)  # Output directory
            ]
            
            # If your tool works differently, modify this section
            # For example, if it's a Python script:
            # cmd = ['python', self.tool_path, tmp_file_path, ...]
            
            logger.info(f"Executing command: {' '.join(cmd)}")
            
            # Run the tool
            result = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await result.communicate()
            
            if result.returncode != 0:
                error_msg = f"Tool execution failed: {stderr.decode()}"
                logger.error(error_msg)
                self.jobs[job_id]["status"] = "failed"
                self.jobs[job_id]["error"] = error_msg
                return [TextContent(type="text", text=f"Error: {error_msg}")]
            
            # Find generated artifacts
            artifacts = []
            expected_files = [
                ("business_logic.md", "Business Logic"),
                ("parsed_code.md", "Parsed Code"),
                ("flow_diagram.md", "Flow Diagram"),
                ("target_code.md", "Target Code"),
                ("documentation.md", "Documentation")
            ]
            
            for filename, artifact_type in expected_files:
                file_path = job_dir / filename
                if file_path.exists():
                    artifacts.append({
                        "name": filename,
                        "type": artifact_type,
                        "path": str(file_path)
                    })
                else:
                    # Try alternative naming patterns
                    # Adjust based on your tool's output
                    for f in job_dir.iterdir():
                        if artifact_type.lower().replace(" ", "_") in f.name.lower():
                            artifacts.append({
                                "name": f.name,
                                "type": artifact_type,
                                "path": str(f)
                            })
                            break
            
            # Update job status
            self.jobs[job_id]["status"] = "completed"
            self.jobs[job_id]["completed_at"] = datetime.now().isoformat()
            self.jobs[job_id]["artifacts"] = artifacts
            
            # Prepare response
            response_text = f"""RPG Processing completed successfully!

Job ID: {job_id}

Generated Artifacts:
"""
            for artifact in artifacts:
                response_text += f"- {artifact['type']}: rpg://jobs/{job_id}/{artifact['name']}\n"
            
            response_text += f"""
To use these artifacts in your workspace:
1. Read each artifact using the MCP resource URLs above
2. Save them to your project directory
3. Use the following prompt for next steps:

"Using the business logic, parsed code, flow diagram, and target code from the RPG processing, please generate a Python application that implements the converted functionality. The application should follow the patterns shown in the target code while maintaining the business logic rules defined in the business_logic.md file."

Parameters used:
- Parameter 1: {arguments['parameter1']}
- Parameter 2: {arguments['parameter2']}
"""
            
            return [TextContent(type="text", text=response_text)]
            
        except Exception as e:
            logger.error(f"Error processing RPG: {str(e)}")
            self.jobs[job_id]["status"] = "failed"
            self.jobs[job_id]["error"] = str(e)
            return [TextContent(type="text", text=f"Error: {str(e)}")]
        
        finally:
            # Cleanup temporary file
            if 'tmp_file_path' in locals() and os.path.exists(tmp_file_path):
                os.unlink(tmp_file_path)
    
    async def run(self):
        """Run the MCP server"""
        from mcp.server.stdio import stdio_server
        
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="rpg-processor",
                    server_version="1.0.0"
                )
            )

def main():
    """Main entry point"""
    import sys
    
    # Get tool path from command line or environment
    tool_path = sys.argv[1] if len(sys.argv) > 1 else None
    
    # Create and run server
    server = RPGProcessingServer(tool_path)
    asyncio.run(server.run())

if __name__ == "__main__":
    main()