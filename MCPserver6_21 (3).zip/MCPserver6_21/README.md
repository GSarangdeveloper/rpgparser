# RPG Processing MCP Server

This MCP server wraps your existing RPG processing tool to make it accessible to AI clients like Cursor.

## Installation

### Windows
```bash
setup_rpg_mcp.bat
```

### Linux/Mac
```bash
chmod +x setup_rpg_mcp.sh
./setup_rpg_mcp.sh
```

## Configuration

### 1. Update Tool Path

Edit `rpg_mcp_server.py` line 24 to point to your RPG processing tool:

```python
self.tool_path = tool_path or os.getenv("RPG_TOOL_PATH", "./your_actual_tool.exe")
```

### 2. Adjust Tool Invocation

The server assumes your tool is called with:
```bash
tool.exe <input_file> <param1> <param2> <output_directory>
```

If your tool works differently, modify the `_process_rpg` method in `rpg_mcp_server.py` around line 140:

```python
# Example for Python script:
cmd = ['python', 'your_tool.py', tmp_file_path, ...]

# Example for different parameter order:
cmd = [self.tool_path, '--input', tmp_file_path, '--param1', arguments['parameter1'], ...]
```

### 3. Configure Output File Names

If your tool generates files with different names, update the `expected_files` list in `rpg_mcp_server.py` around line 180:

```python
expected_files = [
    ("your_business_logic_filename.md", "Business Logic"),
    ("your_parsed_code_filename.md", "Parsed Code"),
    # ... etc
]
```

## Integration with Cursor AI

### Method 1: Direct Configuration

1. Open Cursor Settings (Cmd/Ctrl + ,)
2. Search for "MCP"
3. Add this configuration:

```json
{
  "mcpServers": {
    "rpg-processor": {
      "command": "python",
      "args": ["C:/path/to/your/tool/folder/rpg_mcp_server.py"],
      "env": {
        "RPG_TOOL_PATH": "C:/path/to/your/rpg_tool.exe"
      }
    }
  }
}
```

### Method 2: Using Config File

1. Copy the content from `rpg_processor_config.json`
2. Update paths to match your system
3. Add to Cursor's MCP settings

## Usage in Cursor

Once configured, you can use the tool in Cursor like this:

```
@rpg-processor process_rpg with the RPG code file and parameters param1="value1" and param2="value2"
```

The server will:
1. Process your RPG code
2. Generate 5 markdown documents
3. Return links to access each document
4. Provide instructions for the next steps

## Troubleshooting

### Server Not Found
- Ensure Python path is correct in Cursor config
- Check that all dependencies are installed
- Verify file paths use forward slashes or escaped backslashes

### Tool Execution Fails
- Check `RPG_TOOL_PATH` environment variable
- Verify your tool accepts command-line parameters
- Check tool permissions and execution rights

### Output Not Generated
- Verify output directory permissions
- Check if tool generates files with expected names
- Review server logs for error messages

## Customization

### Different Output Formats
If your tool generates different file types (not .md), update:
- File extensions in `expected_files`
- MIME types in resource definitions

### Additional Parameters
To add more parameters:
1. Update tool schema in `handle_list_tools()`
2. Modify command construction in `_process_rpg()`
3. Update documentation

### Async Processing
For long-running processes, consider:
- Implementing progress callbacks
- Adding timeout configurations
- Using background task queues