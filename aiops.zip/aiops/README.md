# AIOps - AI-Powered Case Investigation Platform

An Agentic AI application for investigating Salesforce cases through GCP logs, identifying root causes, and generating fix recommendations.

## Architecture

- **Frontend**: React with Material-UI
- **Backend**: Flask (Python)
- **Agent Framework**: Google ADK with Vertex AI (Gemini)
- **Database**: MongoDB
- **Integrations**: GCP Cloud Logging, GitHub, Kubernetes

## Features

- **Salesforce Case Investigation**: Enter a Case ID to start AI-powered investigation
- **GCP Log Analysis**: Automatically searches logs for case references
- **Container Identification**: Identifies affected containers/pods
- **Root Cause Analysis**: AI-generated RCA reports with confidence scores
- **Fix Recommendations**: Proposed code fixes with risk assessment

## Investigation Workflow

1. **Query Construction** - Builds GCP logging queries from SFDC case ID
2. **Log Retrieval** - Fetches relevant logs from GCP Cloud Logging
3. **Log Parsing** - Extracts containers, stack traces, errors
4. **Container Identification** - Ranks containers by issue likelihood
5. **Code Analysis** - Fetches code from GitHub, analyzes for root cause
6. **RCA Synthesis** - Generates comprehensive RCA report
7. **Fix Generation** - Proposes fixes with testing plans

## Prerequisites

- Python 3.11+
- Node.js 18+
- MongoDB
- GCP Project with:
  - Cloud Logging API enabled
  - Vertex AI API enabled
  - Service account with appropriate permissions
- GitHub Personal Access Token (for code analysis)

## Quick Start

### 1. Clone and Setup

```bash
cd aiops

# Create environment file
cp backend/.env.example backend/.env
# Edit backend/.env with your credentials
```

### 2. Configure Environment Variables

Edit `backend/.env`:

```env
# GCP Configuration
GOOGLE_CLOUD_PROJECT=your-gcp-project-id
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
VERTEX_AI_LOCATION=us-central1

# MongoDB
MONGODB_URI=mongodb://localhost:27017/aiops

# GitHub
GITHUB_TOKEN=ghp_your_github_token

# Application
SECRET_KEY=your-secret-key
API_KEY=your-api-key-for-authentication
```

### 3. Run with Docker Compose

```bash
docker-compose up -d
```

### 4. Or Run Locally

**Backend:**
```bash
cd backend
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows
pip install -r requirements.txt
python run.py
```

**Frontend:**
```bash
cd frontend
npm install
npm start
```

### 5. Access the Application

- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- API Health: http://localhost:5000/api/health

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/login | Authenticate with API key |
| GET | /api/auth/verify | Verify API key |
| POST | /api/investigation/start | Start new investigation |
| GET | /api/investigation/:id | Get investigation details |
| GET | /api/investigation/:id/stream | SSE stream for real-time updates |
| GET | /api/investigation/ | List all investigations |
| POST | /api/investigation/:id/retry | Retry failed investigation |

## AI Agents

### Query Construction Agent
Builds GCP logging queries to search for Salesforce case IDs in log payloads.

### Log Parsing Agent
Parses log entries, extracts stack traces, error patterns, and correlation IDs.

### Container Identification Agent
Ranks containers by error frequency and timing to identify the primary issue source.

### Code Analysis Agent
Maps containers to GitHub repositories and analyzes code at identified failure points.

### RCA Synthesis Agent
Synthesizes all findings into a comprehensive Root Cause Analysis report.

### Fix Generator Agent
Generates code fix recommendations with testing plans and risk assessments.

## Project Structure

```
aiops/
├── backend/
│   ├── app/
│   │   ├── agents/          # AI agents
│   │   ├── routes/          # API endpoints
│   │   ├── services/        # External service integrations
│   │   ├── models/          # Data models
│   │   └── utils/           # Utilities
│   ├── requirements.txt
│   └── run.py
├── frontend/
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── pages/           # Page components
│   │   ├── hooks/           # Custom hooks
│   │   ├── context/         # React context
│   │   └── services/        # API services
│   └── package.json
├── docker-compose.yml
└── README.md
```

## Configuration

### GCP Permissions Required

The service account needs:
- `roles/logging.viewer` - Read logs
- `roles/aiplatform.user` - Use Vertex AI

### GitHub Token Scopes

- `repo` - Access private repositories (if needed)
- `read:org` - Read organization data

## Development

### Running Tests

```bash
# Backend
cd backend
pytest

# Frontend
cd frontend
npm test
```

### Adding New Agents

1. Create agent in `backend/app/agents/`
2. Follow the existing pattern with `run()` method
3. Register in orchestrator
4. Add to `__init__.py`

## Troubleshooting

### No logs found
- Check if logs contain the case ID pattern (e.g., `sfdc:CASE_ID`)
- Verify GCP project and permissions
- Adjust the time range (default: 7 days)

### Container not identified
- Ensure logs have `resource.labels.container_name`
- Check if application logs include case ID

### Code analysis fails
- Verify GitHub token permissions
- Check container-to-repo mapping in `github_service.py`

## License

Private - Internal Use Only
