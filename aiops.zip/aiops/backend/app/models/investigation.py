"""Investigation model definitions using Pydantic."""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


class InvestigationStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class PhaseStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class Phase(BaseModel):
    name: str
    status: PhaseStatus = PhaseStatus.PENDING
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    result_summary: Optional[Dict[str, Any]] = None


class Container(BaseModel):
    container_name: Optional[str] = None
    name: Optional[str] = None  # Alias
    pod_name: Optional[str] = None
    namespace: Optional[str] = None
    error_count: int = 0
    warning_count: int = 0
    first_occurrence: Optional[str] = None
    last_occurrence: Optional[str] = None
    score: Optional[float] = None
    score_breakdown: Optional[Dict[str, float]] = None


class RootCause(BaseModel):
    description: Optional[str] = None
    evidence: List[str] = []
    confidence: float = 0.0


class Impact(BaseModel):
    severity: Optional[str] = None
    affected_users: Optional[str] = None
    affected_services: List[str] = []
    duration: Optional[str] = None


class RemediationItem(BaseModel):
    action: str
    owner: Optional[str] = None
    priority: str = "medium"


class RCAReport(BaseModel):
    executive_summary: Optional[str] = None
    problem_statement: Optional[str] = None
    root_cause: Optional[RootCause] = None
    impact: Optional[Impact] = None
    timeline: List[Dict[str, Any]] = []
    contributing_factors: List[Dict[str, Any]] = []
    immediate_actions: List[str] = []
    long_term_remediation: List[RemediationItem] = []
    prevention_measures: List[str] = []
    lessons_learned: List[str] = []


class CodeChange(BaseModel):
    file: Optional[str] = None
    before: Optional[str] = None
    after: Optional[str] = None
    explanation: Optional[str] = None


class Fix(BaseModel):
    id: Optional[str] = None
    title: str
    description: Optional[str] = None
    type: str = "code_change"
    priority: str = "medium"
    risk_level: str = "medium"
    estimated_effort: Optional[str] = None
    code_change: Optional[CodeChange] = None
    testing_plan: List[str] = []
    rollback_plan: Optional[str] = None
    dependencies: List[str] = []


class LogEntry(BaseModel):
    insert_id: Optional[str] = None
    timestamp: Optional[str] = None
    severity: Optional[str] = None
    resource: Optional[Dict[str, Any]] = None
    payload: Optional[Any] = None
    payload_type: Optional[str] = None
    labels: Optional[Dict[str, str]] = None


class Investigation(BaseModel):
    id: Optional[str] = Field(None, alias="_id")
    sfdc_case_id: str
    status: InvestigationStatus = InvestigationStatus.PENDING
    user_id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    phases: List[Phase] = []
    containers: List[Container] = []
    log_entries: List[LogEntry] = []
    rca_report: Optional[RCAReport] = None
    rca_summary: Optional[str] = None
    fix_recommendations: List[Fix] = []
    confidence_score: Optional[float] = None
    error: Optional[str] = None

    class Config:
        populate_by_name = True
