"""MongoDB service with in-memory fallback for development."""

from datetime import datetime
import uuid

# Global MongoDB client
mongo_client = None
db = None
use_memory_db = False

# In-memory storage fallback
memory_db = {
    'investigations': {},
    'container_mappings': {}
}


def init_mongodb(app):
    """Initialize MongoDB connection with fallback to in-memory storage."""
    global mongo_client, db, use_memory_db

    try:
        from pymongo import MongoClient
        mongo_client = MongoClient(
            app.config['MONGODB_URI'],
            serverSelectionTimeoutMS=3000  # 3 second timeout
        )
        # Test connection
        mongo_client.server_info()
        db = mongo_client.get_database()
        use_memory_db = False
        print("Connected to MongoDB successfully")
        return db
    except Exception as e:
        print(f"MongoDB not available: {e}")
        print("Using in-memory database (data will not persist)")
        use_memory_db = True
        return None


def get_db():
    """Get database instance."""
    return db


class InvestigationRepository:
    """Repository for investigation documents."""

    @staticmethod
    def create(sfdc_case_id: str, user_id: str = None) -> dict:
        """Create a new investigation."""
        investigation = {
            'sfdc_case_id': sfdc_case_id,
            'status': 'pending',
            'user_id': user_id,
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow(),
            'phases': [],
            'containers': [],
            'log_entries': [],
            'rca_report': None,
            'fix_recommendations': [],
            'confidence_score': None
        }

        if use_memory_db:
            inv_id = str(uuid.uuid4())[:24]  # Simulate MongoDB ObjectId
            investigation['_id'] = inv_id
            memory_db['investigations'][inv_id] = investigation.copy()
            return investigation
        else:
            result = db.investigations.insert_one(investigation)
            investigation['_id'] = str(result.inserted_id)
            return investigation

    @staticmethod
    def get_by_id(investigation_id: str) -> dict:
        """Get investigation by ID."""
        if use_memory_db:
            inv = memory_db['investigations'].get(investigation_id)
            if inv:
                return inv.copy()
            return None
        else:
            from bson import ObjectId
            try:
                investigation = db.investigations.find_one({'_id': ObjectId(investigation_id)})
                if investigation:
                    investigation['_id'] = str(investigation['_id'])
                return investigation
            except:
                return None

    @staticmethod
    def update(investigation_id: str, update_data: dict) -> bool:
        """Update investigation."""
        update_data['updated_at'] = datetime.utcnow()

        if use_memory_db:
            if investigation_id in memory_db['investigations']:
                memory_db['investigations'][investigation_id].update(update_data)
                return True
            return False
        else:
            from bson import ObjectId
            result = db.investigations.update_one(
                {'_id': ObjectId(investigation_id)},
                {'$set': update_data}
            )
            return result.modified_count > 0

    @staticmethod
    def add_phase(investigation_id: str, phase: dict) -> bool:
        """Add a phase to investigation."""
        if use_memory_db:
            if investigation_id in memory_db['investigations']:
                memory_db['investigations'][investigation_id]['phases'].append(phase)
                memory_db['investigations'][investigation_id]['updated_at'] = datetime.utcnow()
                return True
            return False
        else:
            from bson import ObjectId
            result = db.investigations.update_one(
                {'_id': ObjectId(investigation_id)},
                {
                    '$push': {'phases': phase},
                    '$set': {'updated_at': datetime.utcnow()}
                }
            )
            return result.modified_count > 0

    @staticmethod
    def update_phase(investigation_id: str, phase_name: str, phase_data: dict) -> bool:
        """Update a specific phase in investigation."""
        if use_memory_db:
            if investigation_id in memory_db['investigations']:
                inv = memory_db['investigations'][investigation_id]
                for i, phase in enumerate(inv['phases']):
                    if phase.get('name') == phase_name:
                        inv['phases'][i] = phase_data
                        inv['updated_at'] = datetime.utcnow()
                        return True
            return False
        else:
            from bson import ObjectId
            result = db.investigations.update_one(
                {'_id': ObjectId(investigation_id), 'phases.name': phase_name},
                {
                    '$set': {
                        'phases.$': phase_data,
                        'updated_at': datetime.utcnow()
                    }
                }
            )
            return result.modified_count > 0

    @staticmethod
    def list_all(user_id: str = None, limit: int = 50) -> list:
        """List all investigations."""
        if use_memory_db:
            investigations = list(memory_db['investigations'].values())
            if user_id:
                investigations = [i for i in investigations if i.get('user_id') == user_id]
            # Sort by created_at descending
            investigations.sort(key=lambda x: x.get('created_at', datetime.min), reverse=True)
            return [inv.copy() for inv in investigations[:limit]]
        else:
            query = {}
            if user_id:
                query['user_id'] = user_id
            investigations = list(
                db.investigations.find(query)
                .sort('created_at', -1)
                .limit(limit)
            )
            for inv in investigations:
                inv['_id'] = str(inv['_id'])
            return investigations
