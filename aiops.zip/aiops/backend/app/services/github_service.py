from github import Github
from flask import current_app
import base64


class GitHubService:
    """Service for interacting with GitHub API."""

    def __init__(self):
        self.client = None

    def initialize(self):
        """Initialize GitHub client."""
        token = current_app.config.get('GITHUB_TOKEN')
        if token:
            self.client = Github(token)
        return self

    def get_file_content(self, repo_name: str, file_path: str, ref: str = None) -> dict:
        """Get file content from a repository."""
        if not self.client:
            self.initialize()

        try:
            repo = self.client.get_repo(repo_name)
            contents = repo.get_contents(file_path, ref=ref)

            if contents.encoding == 'base64':
                content = base64.b64decode(contents.content).decode('utf-8')
            else:
                content = contents.content

            return {
                'path': contents.path,
                'content': content,
                'sha': contents.sha,
                'size': contents.size,
                'url': contents.html_url
            }
        except Exception as e:
            return {'error': str(e)}

    def get_file_with_context(self, repo_name: str, file_path: str,
                               line_number: int, context_lines: int = 50,
                               ref: str = None) -> dict:
        """Get file content with context around a specific line."""
        file_data = self.get_file_content(repo_name, file_path, ref)

        if 'error' in file_data:
            return file_data

        lines = file_data['content'].split('\n')
        start_line = max(0, line_number - context_lines - 1)
        end_line = min(len(lines), line_number + context_lines)

        context_content = '\n'.join(lines[start_line:end_line])

        return {
            **file_data,
            'context_content': context_content,
            'start_line': start_line + 1,
            'end_line': end_line,
            'target_line': line_number,
            'total_lines': len(lines)
        }

    def get_blame(self, repo_name: str, file_path: str, ref: str = None) -> list:
        """Get git blame information for a file."""
        if not self.client:
            self.initialize()

        try:
            repo = self.client.get_repo(repo_name)
            # Note: PyGithub doesn't directly support blame API
            # We'll use commits for the file instead
            commits = list(repo.get_commits(path=file_path, sha=ref)[:10])

            return [{
                'sha': c.sha[:7],
                'author': c.commit.author.name if c.commit.author else 'Unknown',
                'date': c.commit.author.date.isoformat() if c.commit.author else None,
                'message': c.commit.message.split('\n')[0]
            } for c in commits]
        except Exception as e:
            return [{'error': str(e)}]

    def get_recent_commits(self, repo_name: str, file_path: str = None,
                           limit: int = 10, ref: str = None) -> list:
        """Get recent commits for a file or repository."""
        if not self.client:
            self.initialize()

        try:
            repo = self.client.get_repo(repo_name)
            commits = repo.get_commits(path=file_path, sha=ref)[:limit]

            return [{
                'sha': c.sha,
                'short_sha': c.sha[:7],
                'author': c.commit.author.name if c.commit.author else 'Unknown',
                'email': c.commit.author.email if c.commit.author else None,
                'date': c.commit.author.date.isoformat() if c.commit.author else None,
                'message': c.commit.message,
                'url': c.html_url
            } for c in commits]
        except Exception as e:
            return [{'error': str(e)}]

    def search_code(self, query: str, repo_name: str = None) -> list:
        """Search for code across repositories."""
        if not self.client:
            self.initialize()

        try:
            if repo_name:
                query = f"{query} repo:{repo_name}"

            results = self.client.search_code(query)[:20]

            return [{
                'path': r.path,
                'repository': r.repository.full_name,
                'url': r.html_url,
                'sha': r.sha
            } for r in results]
        except Exception as e:
            return [{'error': str(e)}]

    def map_container_to_repo(self, container_name: str, image_tag: str = None) -> dict:
        """Map a container name to its GitHub repository.

        Uses the ContainerMappingService to look up mappings from MongoDB.
        """
        from app.services.container_mapping_service import ContainerMappingService

        # Try to find mapping by container name
        mapping = ContainerMappingService.get_mapping(container_name)

        # If not found by name, try by image pattern
        if not mapping and image_tag:
            mapping = ContainerMappingService.get_mapping_by_image(image_tag)

        if mapping:
            version = 'main'
            if image_tag and ':' in image_tag:
                version = image_tag.split(':')[-1]

            return {
                'container_name': container_name,
                'image_tag': image_tag,
                'repository': mapping.get('repository'),
                'version': version,
                'default_branch': mapping.get('default_branch', 'main'),
                'found': True
            }

        return {
            'container_name': container_name,
            'image_tag': image_tag,
            'repository': None,
            'version': None,
            'found': False
        }


# Singleton instance
github_service = GitHubService()
