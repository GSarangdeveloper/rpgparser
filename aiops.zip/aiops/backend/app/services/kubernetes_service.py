from kubernetes import client, config
from flask import current_app
import os


class KubernetesService:
    """Service for interacting with Kubernetes API."""

    def __init__(self):
        self.core_v1 = None
        self.apps_v1 = None
        self.initialized = False

    def initialize(self):
        """Initialize Kubernetes client."""
        try:
            # Try in-cluster config first (when running in K8s)
            config.load_incluster_config()
        except config.ConfigException:
            try:
                # Fall back to kubeconfig
                config.load_kube_config()
            except config.ConfigException:
                # No config available
                return self

        self.core_v1 = client.CoreV1Api()
        self.apps_v1 = client.AppsV1Api()
        self.initialized = True
        return self

    def get_pod_info(self, pod_name: str, namespace: str = 'default') -> dict:
        """Get detailed information about a pod."""
        if not self.initialized:
            self.initialize()

        if not self.core_v1:
            return {'error': 'Kubernetes not configured'}

        try:
            pod = self.core_v1.read_namespaced_pod(pod_name, namespace)

            containers = []
            for container in pod.spec.containers:
                containers.append({
                    'name': container.name,
                    'image': container.image,
                    'ports': [{'container_port': p.container_port, 'protocol': p.protocol}
                              for p in (container.ports or [])]
                })

            return {
                'name': pod.metadata.name,
                'namespace': pod.metadata.namespace,
                'labels': pod.metadata.labels or {},
                'annotations': pod.metadata.annotations or {},
                'status': pod.status.phase,
                'node_name': pod.spec.node_name,
                'created_at': pod.metadata.creation_timestamp.isoformat() if pod.metadata.creation_timestamp else None,
                'containers': containers,
                'conditions': [
                    {'type': c.type, 'status': c.status, 'reason': c.reason}
                    for c in (pod.status.conditions or [])
                ]
            }
        except Exception as e:
            return {'error': str(e)}

    def get_deployment_info(self, deployment_name: str, namespace: str = 'default') -> dict:
        """Get deployment information including version/image."""
        if not self.initialized:
            self.initialize()

        if not self.apps_v1:
            return {'error': 'Kubernetes not configured'}

        try:
            deployment = self.apps_v1.read_namespaced_deployment(deployment_name, namespace)

            containers = []
            for container in deployment.spec.template.spec.containers:
                containers.append({
                    'name': container.name,
                    'image': container.image
                })

            return {
                'name': deployment.metadata.name,
                'namespace': deployment.metadata.namespace,
                'labels': deployment.metadata.labels or {},
                'annotations': deployment.metadata.annotations or {},
                'replicas': deployment.spec.replicas,
                'available_replicas': deployment.status.available_replicas,
                'containers': containers,
                'created_at': deployment.metadata.creation_timestamp.isoformat() if deployment.metadata.creation_timestamp else None
            }
        except Exception as e:
            return {'error': str(e)}

    def list_pods_by_label(self, label_selector: str, namespace: str = None) -> list:
        """List pods matching a label selector."""
        if not self.initialized:
            self.initialize()

        if not self.core_v1:
            return [{'error': 'Kubernetes not configured'}]

        try:
            if namespace:
                pods = self.core_v1.list_namespaced_pod(namespace, label_selector=label_selector)
            else:
                pods = self.core_v1.list_pod_for_all_namespaces(label_selector=label_selector)

            return [{
                'name': pod.metadata.name,
                'namespace': pod.metadata.namespace,
                'status': pod.status.phase,
                'node': pod.spec.node_name,
                'containers': [c.name for c in pod.spec.containers]
            } for pod in pods.items]
        except Exception as e:
            return [{'error': str(e)}]

    def get_container_image_version(self, container_name: str, namespace: str) -> dict:
        """Get the image version for a container."""
        if not self.initialized:
            self.initialize()

        if not self.core_v1:
            return {'error': 'Kubernetes not configured'}

        try:
            # Try to find deployment with this container
            deployments = self.apps_v1.list_namespaced_deployment(namespace)

            for deployment in deployments.items:
                for container in deployment.spec.template.spec.containers:
                    if container.name == container_name:
                        image = container.image
                        parts = image.split(':')
                        return {
                            'container_name': container_name,
                            'deployment_name': deployment.metadata.name,
                            'image': image,
                            'image_name': parts[0] if parts else image,
                            'image_tag': parts[1] if len(parts) > 1 else 'latest'
                        }

            return {'error': f'Container {container_name} not found'}
        except Exception as e:
            return {'error': str(e)}


# Singleton instance
kubernetes_service = KubernetesService()
