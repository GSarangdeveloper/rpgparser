from google.cloud import logging as gcp_logging
from google.cloud.logging_v2 import Client
from flask import current_app
from datetime import datetime, timedelta
import json


class GCPLoggingService:
    """Service for interacting with GCP Cloud Logging."""

    def __init__(self):
        self.client = None
        self.project_id = None

    def initialize(self):
        """Initialize the GCP Logging client."""
        self.project_id = current_app.config.get('GOOGLE_CLOUD_PROJECT')
        self.client = Client(project=self.project_id)
        return self

    def build_sfdc_query(self, sfdc_case_id: str, days_back: int = 7) -> str:
        """Build a GCP logging query to search for SFDC case ID."""
        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days_back)

        # Build query with multiple patterns for SFDC case ID
        query = f'''
resource.type="k8s_container"
AND (
    textPayload=~"sfdc:{sfdc_case_id}"
    OR textPayload=~"salesforce:{sfdc_case_id}"
    OR textPayload=~"case_id:{sfdc_case_id}"
    OR textPayload=~"case:{sfdc_case_id}"
    OR textPayload=~"{sfdc_case_id}"
    OR jsonPayload.sfdc_case_id="{sfdc_case_id}"
    OR jsonPayload.salesforce_case_id="{sfdc_case_id}"
    OR jsonPayload.case_id="{sfdc_case_id}"
)
AND timestamp >= "{start_time.isoformat()}Z"
AND timestamp <= "{end_time.isoformat()}Z"
'''
        return query.strip()

    def execute_query(self, query: str, max_results: int = 1000) -> list:
        """Execute a logging query and return results."""
        if not self.client:
            self.initialize()

        entries = []
        for entry in self.client.list_entries(
            filter_=query,
            page_size=max_results,
            order_by=gcp_logging.DESCENDING
        ):
            entry_dict = self._parse_log_entry(entry)
            entries.append(entry_dict)

            if len(entries) >= max_results:
                break

        return entries

    def _parse_log_entry(self, entry) -> dict:
        """Parse a log entry into a structured dict."""
        parsed = {
            'insert_id': entry.insert_id,
            'timestamp': entry.timestamp.isoformat() if entry.timestamp else None,
            'severity': entry.severity if hasattr(entry, 'severity') else None,
            'resource': {},
            'payload': None,
            'labels': {}
        }

        # Parse resource labels
        if entry.resource:
            parsed['resource'] = {
                'type': entry.resource.type,
                'labels': dict(entry.resource.labels) if entry.resource.labels else {}
            }

        # Parse payload
        if entry.payload:
            if isinstance(entry.payload, str):
                parsed['payload'] = entry.payload
                parsed['payload_type'] = 'text'
            elif isinstance(entry.payload, dict):
                parsed['payload'] = entry.payload
                parsed['payload_type'] = 'json'
            else:
                parsed['payload'] = str(entry.payload)
                parsed['payload_type'] = 'proto'

        # Parse labels
        if entry.labels:
            parsed['labels'] = dict(entry.labels)

        return parsed

    def search_by_sfdc_id(self, sfdc_case_id: str, days_back: int = 7) -> dict:
        """Search logs by Salesforce case ID and return structured results."""
        query = self.build_sfdc_query(sfdc_case_id, days_back)
        entries = self.execute_query(query)

        # Group by container
        containers = {}
        for entry in entries:
            container_name = entry.get('resource', {}).get('labels', {}).get('container_name', 'unknown')
            pod_name = entry.get('resource', {}).get('labels', {}).get('pod_name', 'unknown')
            namespace = entry.get('resource', {}).get('labels', {}).get('namespace_name', 'unknown')

            key = f"{namespace}/{container_name}"
            if key not in containers:
                containers[key] = {
                    'container_name': container_name,
                    'pod_name': pod_name,
                    'namespace': namespace,
                    'entries': [],
                    'error_count': 0,
                    'warning_count': 0,
                    'first_occurrence': None,
                    'last_occurrence': None
                }

            containers[key]['entries'].append(entry)

            # Count severities
            severity = entry.get('severity', '')
            if severity == 'ERROR':
                containers[key]['error_count'] += 1
            elif severity == 'WARNING':
                containers[key]['warning_count'] += 1

            # Track timestamps
            timestamp = entry.get('timestamp')
            if timestamp:
                if not containers[key]['first_occurrence'] or timestamp < containers[key]['first_occurrence']:
                    containers[key]['first_occurrence'] = timestamp
                if not containers[key]['last_occurrence'] or timestamp > containers[key]['last_occurrence']:
                    containers[key]['last_occurrence'] = timestamp

        return {
            'sfdc_case_id': sfdc_case_id,
            'query': query,
            'total_entries': len(entries),
            'containers': list(containers.values()),
            'raw_entries': entries
        }

    def get_container_logs(self, container_name: str, namespace: str,
                           start_time: str = None, end_time: str = None,
                           severity: str = None, limit: int = 500) -> list:
        """Get logs for a specific container."""
        if not self.client:
            self.initialize()

        query_parts = [
            'resource.type="k8s_container"',
            f'resource.labels.container_name="{container_name}"',
            f'resource.labels.namespace_name="{namespace}"'
        ]

        if start_time:
            query_parts.append(f'timestamp >= "{start_time}"')
        if end_time:
            query_parts.append(f'timestamp <= "{end_time}"')
        if severity:
            query_parts.append(f'severity="{severity}"')

        query = " AND ".join(query_parts)
        return self.execute_query(query, max_results=limit)


# Singleton instance
gcp_logging_service = GCPLoggingService()
