"""Container to GitHub Repository Mapping Service.

This service manages the mapping between Kubernetes containers/services
and their corresponding GitHub repositories. Mappings are stored in MongoDB
for easy maintenance and updates.
"""

from datetime import datetime
from app.services.mongodb_service import get_db


class ContainerMappingService:
    """Service for managing container-to-repository mappings."""

    COLLECTION_NAME = 'container_mappings'

    @staticmethod
    def get_collection():
        """Get the mappings collection."""
        db = get_db()
        return db[ContainerMappingService.COLLECTION_NAME]

    @classmethod
    def create_mapping(cls, container_name: str, repository: str,
                       namespace: str = None, image_pattern: str = None,
                       default_branch: str = 'main') -> dict:
        """Create or update a container-to-repo mapping."""
        collection = cls.get_collection()

        mapping = {
            'container_name': container_name,
            'repository': repository,  # e.g., 'org/repo-name'
            'namespace': namespace,
            'image_pattern': image_pattern,  # e.g., 'gcr.io/project/payment-*'
            'default_branch': default_branch,
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow()
        }

        # Upsert - update if exists, insert if not
        result = collection.update_one(
            {'container_name': container_name},
            {'$set': mapping},
            upsert=True
        )

        mapping['_id'] = str(result.upserted_id) if result.upserted_id else None
        return mapping

    @classmethod
    def get_mapping(cls, container_name: str) -> dict:
        """Get mapping for a specific container."""
        collection = cls.get_collection()
        mapping = collection.find_one({'container_name': container_name})

        if mapping:
            mapping['_id'] = str(mapping['_id'])

        return mapping

    @classmethod
    def get_mapping_by_image(cls, image_name: str) -> dict:
        """Get mapping by image pattern matching."""
        collection = cls.get_collection()

        # Try exact container name match from image
        # e.g., gcr.io/project/payment-service:v1 -> payment-service
        container_name = image_name.split('/')[-1].split(':')[0]
        mapping = collection.find_one({'container_name': container_name})

        if mapping:
            mapping['_id'] = str(mapping['_id'])
            return mapping

        # Try pattern matching
        mappings = list(collection.find({'image_pattern': {'$exists': True}}))
        for m in mappings:
            pattern = m.get('image_pattern', '')
            if pattern and cls._matches_pattern(image_name, pattern):
                m['_id'] = str(m['_id'])
                return m

        return None

    @staticmethod
    def _matches_pattern(image_name: str, pattern: str) -> bool:
        """Check if image matches a pattern (supports * wildcard)."""
        import re
        regex_pattern = pattern.replace('*', '.*')
        return bool(re.match(regex_pattern, image_name))

    @classmethod
    def list_all_mappings(cls) -> list:
        """List all container mappings."""
        collection = cls.get_collection()
        mappings = list(collection.find().sort('container_name', 1))

        for mapping in mappings:
            mapping['_id'] = str(mapping['_id'])

        return mappings

    @classmethod
    def delete_mapping(cls, container_name: str) -> bool:
        """Delete a container mapping."""
        collection = cls.get_collection()
        result = collection.delete_one({'container_name': container_name})
        return result.deleted_count > 0

    @classmethod
    def bulk_import(cls, mappings: list) -> dict:
        """Bulk import mappings from a list."""
        created = 0
        updated = 0
        errors = []

        for mapping in mappings:
            try:
                container_name = mapping.get('container_name')
                repository = mapping.get('repository')

                if not container_name or not repository:
                    errors.append(f"Missing required fields: {mapping}")
                    continue

                existing = cls.get_mapping(container_name)
                cls.create_mapping(
                    container_name=container_name,
                    repository=repository,
                    namespace=mapping.get('namespace'),
                    image_pattern=mapping.get('image_pattern'),
                    default_branch=mapping.get('default_branch', 'main')
                )

                if existing:
                    updated += 1
                else:
                    created += 1

            except Exception as e:
                errors.append(f"Error processing {mapping}: {str(e)}")

        return {
            'created': created,
            'updated': updated,
            'errors': errors
        }

    @classmethod
    def seed_default_mappings(cls):
        """Seed default mappings for common patterns.

        Call this on app startup to ensure some defaults exist.
        You should customize these for your organization.
        """
        default_mappings = [
            # Add your organization's container-to-repo mappings here
            # Example:
            # {
            #     'container_name': 'payment-service',
            #     'repository': 'myorg/payment-service',
            #     'namespace': 'production',
            #     'default_branch': 'main'
            # },
        ]

        for mapping in default_mappings:
            existing = cls.get_mapping(mapping['container_name'])
            if not existing:
                cls.create_mapping(**mapping)


# Singleton instance
container_mapping_service = ContainerMappingService()
