import os
from google import genai
from google.genai import types
from flask import current_app


class VertexAIService:
    """Service for interacting with Gemini via Vertex AI."""

    def __init__(self):
        self.client = None
        self.model_name = None

    def initialize(self):
        """Initialize the Vertex AI client."""
        project_id = current_app.config.get('GOOGLE_CLOUD_PROJECT')
        location = current_app.config.get('VERTEX_AI_LOCATION', 'us-central1')
        self.model_name = current_app.config.get('GEMINI_MODEL', 'gemini-1.5-pro')

        self.client = genai.Client(
            vertexai=True,
            project=project_id,
            location=location
        )
        return self

    def generate(self, prompt: str, system_instruction: str = None, temperature: float = 0.7) -> str:
        """Generate text using Gemini."""
        if not self.client:
            self.initialize()

        config = types.GenerateContentConfig(
            temperature=temperature,
            max_output_tokens=8192,
        )

        if system_instruction:
            config.system_instruction = system_instruction

        response = self.client.models.generate_content(
            model=self.model_name,
            contents=prompt,
            config=config
        )

        return response.text

    def generate_with_context(self, messages: list, system_instruction: str = None) -> str:
        """Generate with conversation history."""
        if not self.client:
            self.initialize()

        config = types.GenerateContentConfig(
            temperature=0.7,
            max_output_tokens=8192,
        )

        if system_instruction:
            config.system_instruction = system_instruction

        response = self.client.models.generate_content(
            model=self.model_name,
            contents=messages,
            config=config
        )

        return response.text

    def analyze_logs(self, logs: list, context: str = None) -> dict:
        """Analyze logs using Gemini."""
        system_prompt = """You are an expert log analyzer for cloud-native applications.
Analyze the provided logs and extract:
1. Error patterns and their frequency
2. Stack traces with file paths and line numbers
3. Container/pod information
4. Correlation IDs and request traces
5. Root cause indicators

Respond in JSON format."""

        log_text = "\n".join([str(log) for log in logs[:100]])  # Limit logs
        prompt = f"Analyze these logs:\n\n{log_text}"

        if context:
            prompt = f"Context: {context}\n\n{prompt}"

        response = self.generate(prompt, system_instruction=system_prompt, temperature=0.3)
        return response

    def generate_rca(self, findings: dict) -> dict:
        """Generate Root Cause Analysis report."""
        system_prompt = """You are an expert SRE performing Root Cause Analysis.
Based on the investigation findings, generate a comprehensive RCA report including:
1. Executive Summary
2. Timeline of events
3. Root cause identification with confidence level
4. Impact assessment
5. Immediate and long-term remediation steps

Be specific and actionable. Respond in JSON format."""

        prompt = f"Generate RCA based on these findings:\n\n{findings}"
        response = self.generate(prompt, system_instruction=system_prompt, temperature=0.3)
        return response


# Singleton instance
vertex_ai_service = VertexAIService()
