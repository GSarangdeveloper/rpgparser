from flask import Blueprint, request, jsonify, Response, current_app
import json
import time
from datetime import datetime

from app.routes.auth import require_api_key
from app.services.mongodb_service import InvestigationRepository
from app.agents.orchestrator import InvestigationOrchestrator

investigation_bp = Blueprint('investigation', __name__)


@investigation_bp.route('/start', methods=['POST'])
@require_api_key
def start_investigation():
    """Start a new investigation.

    Accepts either:
    - sfdc_case_id: Salesforce Case ID (15 or 18 chars)
    - search_term: Any generic search term (error message, ID, etc.)

    The system will automatically detect the search type and build
    appropriate queries.
    """
    data = request.get_json()

    if not data:
        return jsonify({'error': 'Request body required'}), 400

    # Accept either sfdc_case_id or search_term
    search_term = data.get('search_term') or data.get('sfdc_case_id')

    if not search_term:
        return jsonify({'error': 'search_term or sfdc_case_id is required'}), 400

    search_term = search_term.strip()

    if not search_term:
        return jsonify({'error': 'Search term cannot be empty'}), 400

    if len(search_term) < 3:
        return jsonify({'error': 'Search term must be at least 3 characters'}), 400

    # Detect search type for response
    from app.agents.query_construction_agent import QueryConstructionAgent
    query_agent = QueryConstructionAgent()
    search_type = query_agent.detect_search_type(search_term)

    # Create investigation record
    investigation = InvestigationRepository.create(
        sfdc_case_id=search_term,  # Store search term in this field for compatibility
        user_id=data.get('user_id')
    )

    # Add search metadata
    InvestigationRepository.update(investigation['_id'], {
        'search_term': search_term,
        'search_type': search_type
    })

    # Start the investigation asynchronously
    # In production, this would be handled by a task queue (Celery, etc.)
    orchestrator = InvestigationOrchestrator()

    try:
        # Update status to in_progress
        InvestigationRepository.update(investigation['_id'], {'status': 'in_progress'})

        # Run investigation (in production, this would be async)
        result = orchestrator.run_investigation(investigation['_id'], search_term)

        # Update with results
        InvestigationRepository.update(investigation['_id'], {
            'status': 'completed',
            **result
        })

    except Exception as e:
        InvestigationRepository.update(investigation['_id'], {
            'status': 'failed',
            'error': str(e)
        })

    return jsonify({
        'investigation_id': investigation['_id'],
        'search_term': search_term,
        'search_type': search_type,
        'status': 'started'
    }), 201


@investigation_bp.route('/<investigation_id>', methods=['GET'])
@require_api_key
def get_investigation(investigation_id):
    """Get investigation details by ID."""
    investigation = InvestigationRepository.get_by_id(investigation_id)

    if not investigation:
        return jsonify({'error': 'Investigation not found'}), 404

    return jsonify(investigation)


@investigation_bp.route('/<investigation_id>/stream', methods=['GET'])
def stream_investigation(investigation_id):
    """Stream investigation updates using Server-Sent Events."""

    def generate():
        """Generator for SSE stream."""
        last_update = None

        while True:
            investigation = InvestigationRepository.get_by_id(investigation_id)

            if not investigation:
                yield f"data: {json.dumps({'error': 'Investigation not found'})}\n\n"
                break

            current_update = investigation.get('updated_at')

            # Send update if changed
            if current_update != last_update:
                last_update = current_update

                # Convert datetime to string for JSON
                if isinstance(investigation.get('created_at'), datetime):
                    investigation['created_at'] = investigation['created_at'].isoformat()
                if isinstance(investigation.get('updated_at'), datetime):
                    investigation['updated_at'] = investigation['updated_at'].isoformat()

                yield f"data: {json.dumps(investigation)}\n\n"

            # Check if investigation is complete
            if investigation.get('status') in ['completed', 'failed']:
                yield f"data: {json.dumps({'event': 'complete', 'status': investigation.get('status')})}\n\n"
                break

            time.sleep(1)  # Poll every second

    return Response(
        generate(),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no'
        }
    )


@investigation_bp.route('/', methods=['GET'])
@require_api_key
def list_investigations():
    """List all investigations."""
    user_id = request.args.get('user_id')
    limit = request.args.get('limit', 50, type=int)

    investigations = InvestigationRepository.list_all(user_id=user_id, limit=limit)

    return jsonify({
        'investigations': investigations,
        'count': len(investigations)
    })


@investigation_bp.route('/<investigation_id>/retry', methods=['POST'])
@require_api_key
def retry_investigation(investigation_id):
    """Retry a failed investigation."""
    investigation = InvestigationRepository.get_by_id(investigation_id)

    if not investigation:
        return jsonify({'error': 'Investigation not found'}), 404

    if investigation.get('status') != 'failed':
        return jsonify({'error': 'Can only retry failed investigations'}), 400

    # Get the search term (could be sfdc_case_id or search_term)
    search_term = investigation.get('search_term') or investigation.get('sfdc_case_id')

    # Reset and restart
    InvestigationRepository.update(investigation_id, {
        'status': 'pending',
        'phases': [],
        'error': None
    })

    # Re-run investigation
    orchestrator = InvestigationOrchestrator()

    try:
        InvestigationRepository.update(investigation_id, {'status': 'in_progress'})
        result = orchestrator.run_investigation(investigation_id, search_term)
        InvestigationRepository.update(investigation_id, {
            'status': 'completed',
            **result
        })
    except Exception as e:
        InvestigationRepository.update(investigation_id, {
            'status': 'failed',
            'error': str(e)
        })

    return jsonify({
        'investigation_id': investigation_id,
        'status': 'retrying'
    })
