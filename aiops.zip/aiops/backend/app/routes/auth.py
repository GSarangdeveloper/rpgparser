from flask import Blueprint, request, jsonify, current_app
from functools import wraps
import hashlib
import secrets

auth_bp = Blueprint('auth', __name__)


def require_api_key(f):
    """Decorator to require API key authentication."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')

        if not api_key:
            return jsonify({'error': 'API key required'}), 401

        expected_key = current_app.config.get('API_KEY')
        if api_key != expected_key:
            return jsonify({'error': 'Invalid API key'}), 401

        return f(*args, **kwargs)
    return decorated_function


@auth_bp.route('/login', methods=['POST'])
def login():
    """Authenticate with API key."""
    data = request.get_json()

    if not data or 'api_key' not in data:
        return jsonify({'error': 'API key required'}), 400

    api_key = data['api_key']
    expected_key = current_app.config.get('API_KEY')

    if api_key == expected_key:
        # Generate a session token
        token = secrets.token_hex(32)

        return jsonify({
            'success': True,
            'token': token,
            'user': {
                'id': 'user_1',
                'role': 'analyst'
            }
        })
    else:
        return jsonify({'error': 'Invalid API key'}), 401


@auth_bp.route('/verify', methods=['GET'])
@require_api_key
def verify():
    """Verify API key is valid."""
    return jsonify({
        'valid': True,
        'message': 'API key is valid'
    })
