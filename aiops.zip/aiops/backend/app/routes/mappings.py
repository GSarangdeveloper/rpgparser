"""API routes for managing container-to-repository mappings."""

from flask import Blueprint, request, jsonify
from app.routes.auth import require_api_key
from app.services.container_mapping_service import ContainerMappingService

mappings_bp = Blueprint('mappings', __name__)


@mappings_bp.route('/', methods=['GET'])
@require_api_key
def list_mappings():
    """List all container-to-repo mappings."""
    mappings = ContainerMappingService.list_all_mappings()
    return jsonify({
        'mappings': mappings,
        'count': len(mappings)
    })


@mappings_bp.route('/', methods=['POST'])
@require_api_key
def create_mapping():
    """Create a new container-to-repo mapping."""
    data = request.get_json()

    if not data:
        return jsonify({'error': 'Request body required'}), 400

    container_name = data.get('container_name')
    repository = data.get('repository')

    if not container_name:
        return jsonify({'error': 'container_name is required'}), 400
    if not repository:
        return jsonify({'error': 'repository is required'}), 400

    mapping = ContainerMappingService.create_mapping(
        container_name=container_name,
        repository=repository,
        namespace=data.get('namespace'),
        image_pattern=data.get('image_pattern'),
        default_branch=data.get('default_branch', 'main')
    )

    return jsonify({
        'success': True,
        'mapping': mapping
    }), 201


@mappings_bp.route('/<container_name>', methods=['GET'])
@require_api_key
def get_mapping(container_name):
    """Get mapping for a specific container."""
    mapping = ContainerMappingService.get_mapping(container_name)

    if not mapping:
        return jsonify({'error': 'Mapping not found'}), 404

    return jsonify(mapping)


@mappings_bp.route('/<container_name>', methods=['PUT'])
@require_api_key
def update_mapping(container_name):
    """Update an existing container mapping."""
    data = request.get_json()

    if not data:
        return jsonify({'error': 'Request body required'}), 400

    # Check if mapping exists
    existing = ContainerMappingService.get_mapping(container_name)
    if not existing:
        return jsonify({'error': 'Mapping not found'}), 404

    mapping = ContainerMappingService.create_mapping(
        container_name=container_name,
        repository=data.get('repository', existing.get('repository')),
        namespace=data.get('namespace', existing.get('namespace')),
        image_pattern=data.get('image_pattern', existing.get('image_pattern')),
        default_branch=data.get('default_branch', existing.get('default_branch', 'main'))
    )

    return jsonify({
        'success': True,
        'mapping': mapping
    })


@mappings_bp.route('/<container_name>', methods=['DELETE'])
@require_api_key
def delete_mapping(container_name):
    """Delete a container mapping."""
    deleted = ContainerMappingService.delete_mapping(container_name)

    if not deleted:
        return jsonify({'error': 'Mapping not found'}), 404

    return jsonify({
        'success': True,
        'message': f'Mapping for {container_name} deleted'
    })


@mappings_bp.route('/bulk', methods=['POST'])
@require_api_key
def bulk_import():
    """Bulk import mappings.

    Expected body:
    {
        "mappings": [
            {
                "container_name": "payment-service",
                "repository": "myorg/payment-service",
                "namespace": "production",
                "default_branch": "main"
            },
            ...
        ]
    }
    """
    data = request.get_json()

    if not data or 'mappings' not in data:
        return jsonify({'error': 'mappings array required'}), 400

    result = ContainerMappingService.bulk_import(data['mappings'])

    return jsonify({
        'success': True,
        'created': result['created'],
        'updated': result['updated'],
        'errors': result['errors']
    })
