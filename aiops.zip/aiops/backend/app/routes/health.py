from flask import Blueprint, jsonify

health_bp = Blueprint('health', __name__)


@health_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'service': 'aiops-backend'
    })


@health_bp.route('/ready', methods=['GET'])
def readiness_check():
    """Readiness check endpoint."""
    # Add checks for database connectivity, etc.
    checks = {
        'database': True,
        'services': True
    }

    all_ready = all(checks.values())

    return jsonify({
        'ready': all_ready,
        'checks': checks
    }), 200 if all_ready else 503
