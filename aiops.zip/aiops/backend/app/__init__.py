from flask import Flask
from flask_cors import CORS

from app.config import config


def create_app(config_name='default'):
    """Application factory for creating Flask app."""
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    # Enable CORS for React frontend
    CORS(app, resources={
        r"/api/*": {
            "origins": ["http://localhost:3000"],
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization", "X-API-Key"]
        }
    })

    # Initialize services
    from app.services.mongodb_service import init_mongodb
    init_mongodb(app)

    # Register blueprints
    from app.routes.health import health_bp
    from app.routes.auth import auth_bp
    from app.routes.investigation import investigation_bp
    from app.routes.mappings import mappings_bp

    app.register_blueprint(health_bp, url_prefix='/api')
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(investigation_bp, url_prefix='/api/investigation')
    app.register_blueprint(mappings_bp, url_prefix='/api/mappings')

    return app
