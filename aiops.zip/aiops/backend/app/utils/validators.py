"""Validation utilities."""

import re


def validate_sfdc_case_id(case_id: str) -> dict:
    """Validate Salesforce case ID format.

    Salesforce Case IDs are either 15 or 18 alphanumeric characters.
    Case objects start with '500'.

    Returns:
        dict with 'valid', 'normalized', and 'errors' keys
    """
    result = {
        'valid': False,
        'original': case_id,
        'normalized': None,
        'errors': []
    }

    if not case_id:
        result['errors'].append('Case ID is empty')
        return result

    # Remove whitespace
    clean_id = case_id.strip()

    # Check length (15 or 18 characters)
    if len(clean_id) not in [15, 18]:
        result['errors'].append(f'Invalid length: {len(clean_id)} (expected 15 or 18)')
        return result

    # Check alphanumeric
    if not clean_id.isalnum():
        result['errors'].append('Case ID must be alphanumeric')
        return result

    # Validate Salesforce ID prefix
    # 500 = Case object (but we don't strictly require this)
    if not clean_id.startswith('500'):
        result['errors'].append(f'Warning: Unexpected prefix {clean_id[:3]} (expected 500 for Case)')
        # This is a warning, not an error - still valid

    result['valid'] = True
    result['normalized'] = clean_id

    return result


def validate_gcp_project_id(project_id: str) -> bool:
    """Validate GCP project ID format.

    GCP project IDs must:
    - Be 6-30 characters
    - Start with a letter
    - Contain only lowercase letters, digits, and hyphens
    - Not end with a hyphen
    """
    if not project_id:
        return False

    pattern = r'^[a-z][a-z0-9-]{4,28}[a-z0-9]$'
    return bool(re.match(pattern, project_id))


def sanitize_log_query(query: str) -> str:
    """Sanitize a log query to prevent injection.

    Note: GCP Cloud Logging has its own query language,
    so this is a basic sanitization.
    """
    # Remove potentially dangerous characters
    # Allow alphanumeric, spaces, and common query operators
    allowed_pattern = r'[^a-zA-Z0-9\s\.\:\=\>\<\"\'\-\_\/\(\)\[\]\~\*\&\|]'
    return re.sub(allowed_pattern, '', query)


def extract_container_name(pod_name: str) -> str:
    """Extract likely container name from pod name.

    Kubernetes pod names often follow the pattern:
    {deployment-name}-{replicaset-hash}-{pod-hash}
    e.g., payment-service-7d8f9c-xk2m9 -> payment-service
    """
    if not pod_name:
        return None

    # Split by '-' and try to find the base name
    parts = pod_name.split('-')

    # If we have multiple parts, remove the last 2 (likely hashes)
    if len(parts) > 2:
        # Check if last parts look like hashes (alphanumeric, 5+ chars)
        potential_hashes = 0
        for part in reversed(parts):
            if len(part) >= 5 and part.isalnum():
                potential_hashes += 1
            else:
                break

        if potential_hashes >= 2:
            return '-'.join(parts[:-2])

    return pod_name
