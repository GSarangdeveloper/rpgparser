"""Fix Generator Agent - Generates fix recommendations."""

import json
import re
from typing import Dict, List
from app.services.vertex_ai import vertex_ai_service


class FixGeneratorAgent:
    """Agent for generating fix recommendations based on RCA findings."""

    SYSTEM_PROMPT = """You are an expert software engineer generating fix recommendations.
Based on the root cause analysis, propose specific, actionable code fixes.

For each fix:
1. Provide exact code changes when possible
2. Explain the change and why it fixes the issue
3. Assess the risk level of the change
4. Include testing recommendations
5. Consider backward compatibility

Prioritize fixes by:
1. Immediate impact on the issue
2. Risk level (prefer lower risk)
3. Implementation complexity
4. Long-term maintainability"""

    def __init__(self):
        self.llm = vertex_ai_service

    def generate_fixes(self, rca: Dict, code_analysis: Dict = None) -> Dict:
        """Generate fix recommendations based on RCA."""
        # Prepare context for LLM
        context = {
            'root_cause': rca.get('rca', {}).get('root_cause', {}),
            'immediate_actions': rca.get('rca', {}).get('immediate_actions', []),
            'long_term_remediation': rca.get('rca', {}).get('long_term_remediation', [])
        }

        if code_analysis:
            context['code_issues'] = code_analysis.get('code_analysis', {}).get('potential_issues', [])
            context['recommended_fixes'] = code_analysis.get('code_analysis', {}).get('recommended_fixes', [])

        prompt = f"""Based on this root cause analysis, generate detailed fix recommendations:

Context:
{json.dumps(context, indent=2)}

Generate fixes in JSON format:
{{
    "fixes": [
        {{
            "id": "FIX-001",
            "title": "Short descriptive title",
            "description": "Detailed description of the fix",
            "type": "code_change|config_change|infrastructure|process",
            "priority": "critical|high|medium|low",
            "risk_level": "low|medium|high",
            "estimated_effort": "hours|days|weeks",
            "code_change": {{
                "file": "path/to/file",
                "before": "code before change",
                "after": "code after change",
                "explanation": "why this change fixes the issue"
            }},
            "testing_plan": [
                "Test case 1",
                "Test case 2"
            ],
            "rollback_plan": "How to rollback if something goes wrong",
            "dependencies": ["list of dependencies or prerequisites"]
        }}
    ],
    "implementation_order": ["FIX-001", "FIX-002"],
    "total_estimated_effort": "overall time estimate",
    "risk_assessment": "overall risk assessment"
}}"""

        try:
            response = self.llm.generate(prompt, system_instruction=self.SYSTEM_PROMPT, temperature=0.4)

            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                return json.loads(json_match.group())
            return {'raw_response': response}
        except Exception as e:
            return {'error': str(e)}

    def prioritize_fixes(self, fixes: List[Dict]) -> List[Dict]:
        """Prioritize fixes based on impact and risk."""
        priority_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
        risk_order = {'low': 0, 'medium': 1, 'high': 2}

        def score_fix(fix):
            priority_score = priority_order.get(fix.get('priority', 'medium'), 2)
            risk_score = risk_order.get(fix.get('risk_level', 'medium'), 1)
            # Lower score = higher priority (prioritize high priority, low risk)
            return (priority_score * 2) + risk_score

        return sorted(fixes, key=score_fix)

    def generate_pr_description(self, fix: Dict) -> str:
        """Generate a pull request description for a fix."""
        code_change = fix.get('code_change', {})

        pr_template = f"""## Summary
{fix.get('description', 'No description provided')}

## Root Cause
{fix.get('code_change', {}).get('explanation', 'See RCA report for details')}

## Changes Made
- **File**: `{code_change.get('file', 'TBD')}`
- **Type**: {fix.get('type', 'code_change')}

### Before
```
{code_change.get('before', 'N/A')}
```

### After
```
{code_change.get('after', 'N/A')}
```

## Testing Plan
{chr(10).join(['- [ ] ' + t for t in fix.get('testing_plan', ['Manual testing required'])])}

## Risk Assessment
- **Risk Level**: {fix.get('risk_level', 'medium')}
- **Rollback Plan**: {fix.get('rollback_plan', 'Revert this commit')}

## Related
- Priority: {fix.get('priority', 'medium')}
- Estimated Effort: {fix.get('estimated_effort', 'TBD')}
"""
        return pr_template

    def generate_hotfix_script(self, fix: Dict) -> str:
        """Generate a hotfix deployment script."""
        script = f"""#!/bin/bash
# Hotfix Script for: {fix.get('title', 'Unknown Fix')}
# Generated: $(date)
# Risk Level: {fix.get('risk_level', 'medium')}

set -e

echo "========================================="
echo "HOTFIX: {fix.get('id', 'FIX-XXX')}"
echo "========================================="

# Pre-flight checks
echo "Running pre-flight checks..."

# Check current deployment status
kubectl get pods -l app={fix.get('affected_service', 'unknown')} -n production

# Backup current state
echo "Creating backup..."
kubectl get deployment {fix.get('affected_service', 'unknown')} -n production -o yaml > /tmp/backup-$(date +%Y%m%d%H%M%S).yaml

# Apply fix
echo "Applying fix..."
# Add specific fix commands here

# Verify fix
echo "Verifying fix..."
# Add verification commands here

echo "========================================="
echo "Hotfix complete. Monitor for issues."
echo "========================================="

# Rollback instructions
echo ""
echo "TO ROLLBACK:"
echo "kubectl apply -f /tmp/backup-*.yaml"
"""
        return script

    def assess_risk(self, fixes: List[Dict]) -> Dict:
        """Assess overall risk of implementing fixes."""
        if not fixes:
            return {'overall_risk': 'unknown', 'details': 'No fixes to assess'}

        risk_counts = {'low': 0, 'medium': 0, 'high': 0}
        for fix in fixes:
            risk = fix.get('risk_level', 'medium')
            risk_counts[risk] = risk_counts.get(risk, 0) + 1

        # Determine overall risk
        if risk_counts.get('high', 0) > 0:
            overall = 'high'
        elif risk_counts.get('medium', 0) > len(fixes) / 2:
            overall = 'medium'
        else:
            overall = 'low'

        return {
            'overall_risk': overall,
            'risk_distribution': risk_counts,
            'total_fixes': len(fixes),
            'recommendation': self._get_risk_recommendation(overall)
        }

    def _get_risk_recommendation(self, risk: str) -> str:
        """Get recommendation based on risk level."""
        recommendations = {
            'low': 'Safe to proceed with standard deployment process.',
            'medium': 'Recommend deploying during low-traffic period with monitoring.',
            'high': 'Recommend phased rollout with immediate rollback capability. Consider staging deployment first.'
        }
        return recommendations.get(risk, 'Assess carefully before proceeding.')

    def run(self, rca: Dict, code_analysis: Dict = None) -> Dict:
        """Main entry point for the agent."""
        # Generate fixes
        fix_result = self.generate_fixes(rca, code_analysis)

        fixes = fix_result.get('fixes', [])

        # Prioritize fixes
        prioritized_fixes = self.prioritize_fixes(fixes)

        # Assess overall risk
        risk_assessment = self.assess_risk(prioritized_fixes)

        # Generate PR descriptions for each fix
        pr_descriptions = {}
        for fix in prioritized_fixes:
            fix_id = fix.get('id', f"FIX-{len(pr_descriptions)+1}")
            pr_descriptions[fix_id] = self.generate_pr_description(fix)

        return {
            'success': True,
            'fixes': prioritized_fixes,
            'implementation_order': fix_result.get('implementation_order', [f.get('id') for f in prioritized_fixes]),
            'total_estimated_effort': fix_result.get('total_estimated_effort', 'TBD'),
            'risk_assessment': risk_assessment,
            'pr_descriptions': pr_descriptions,
            'hotfix_available': any(f.get('priority') == 'critical' for f in prioritized_fixes)
        }
