"""Query Construction Agent - Builds GCP logging queries for log investigation."""

import re
import json
from datetime import datetime, timedelta
from app.services.vertex_ai import vertex_ai_service


class QueryConstructionAgent:
    """Agent for constructing GCP Cloud Logging queries.

    Supports:
    - Salesforce Case ID search (with validation)
    - Generic text search (any search term)
    - LLM-enhanced query generation
    """

    SYSTEM_PROMPT = """You are an expert at constructing GCP Cloud Logging queries.
Your task is to build effective queries to find logs related to a search term.

Guidelines:
1. Search for the term in various formats and patterns
2. Search both textPayload and jsonPayload fields
3. Use regex patterns for flexible matching
4. Consider common log formats and patterns
5. Prioritize k8s_container resource type for container discovery
6. Consider error patterns, exception messages, and correlation IDs

Output a JSON object with:
{
    "queries": [
        {
            "query": "the GCP logging query string",
            "priority": 1-5,
            "description": "what this query searches for"
        }
    ],
    "search_patterns": ["list of patterns being searched"],
    "time_range_days": number
}"""

    def __init__(self):
        self.llm = vertex_ai_service

    def detect_search_type(self, search_term: str) -> str:
        """Detect the type of search term provided.

        Returns: 'sfdc_case_id', 'error_message', 'correlation_id', or 'generic'
        """
        term = search_term.strip()

        # Check for SFDC Case ID pattern (15 or 18 chars, starts with 500)
        if len(term) in [15, 18] and term.isalnum() and term.startswith('500'):
            return 'sfdc_case_id'

        # Check for UUID/correlation ID pattern
        uuid_pattern = r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'
        if re.match(uuid_pattern, term.lower()):
            return 'correlation_id'

        # Check for common error patterns
        error_keywords = ['error', 'exception', 'failed', 'timeout', 'null', 'undefined']
        if any(kw in term.lower() for kw in error_keywords):
            return 'error_message'

        return 'generic'

    def validate_sfdc_id(self, sfdc_case_id: str) -> dict:
        """Validate Salesforce case ID format."""
        result = {
            'valid': False,
            'original': sfdc_case_id,
            'normalized': None,
            'format': None,
            'errors': []
        }

        if not sfdc_case_id:
            result['errors'].append('Case ID is empty')
            return result

        # Remove whitespace
        clean_id = sfdc_case_id.strip()

        # Check length (15 or 18 characters)
        if len(clean_id) == 15:
            result['format'] = '15-char'
            result['normalized'] = clean_id
        elif len(clean_id) == 18:
            result['format'] = '18-char'
            result['normalized'] = clean_id
        else:
            result['errors'].append(f'Invalid length: {len(clean_id)} (expected 15 or 18)')
            return result

        # Check alphanumeric
        if not clean_id.isalnum():
            result['errors'].append('Case ID must be alphanumeric')
            return result

        # Validate Salesforce ID prefix (first 3 chars indicate object type)
        # 500 = Case object
        if not clean_id.startswith('500'):
            result['errors'].append(f'Unexpected prefix: {clean_id[:3]} (expected 500 for Case)')
            # Still valid, just a warning

        result['valid'] = True
        return result

    def build_queries(self, sfdc_case_id: str, days_back: int = 7) -> dict:
        """Build GCP logging queries for the case ID."""
        # Validate first
        validation = self.validate_sfdc_id(sfdc_case_id)
        if not validation['valid'] and validation['errors']:
            return {
                'success': False,
                'error': validation['errors'][0],
                'validation': validation
            }

        case_id = validation['normalized'] or sfdc_case_id

        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days_back)

        # Build multiple query variations
        queries = [
            {
                'query': self._build_primary_query(case_id, start_time, end_time),
                'priority': 1,
                'description': 'Primary query - searches common SFDC patterns in textPayload'
            },
            {
                'query': self._build_json_payload_query(case_id, start_time, end_time),
                'priority': 2,
                'description': 'JSON payload query - searches structured log fields'
            },
            {
                'query': self._build_broad_query(case_id, start_time, end_time),
                'priority': 3,
                'description': 'Broad query - searches for case ID anywhere in logs'
            }
        ]

        # Also try with 15-char variant if 18-char provided
        if len(case_id) == 18:
            short_id = case_id[:15]
            queries.append({
                'query': self._build_primary_query(short_id, start_time, end_time),
                'priority': 4,
                'description': f'15-char variant query for {short_id}'
            })

        return {
            'success': True,
            'sfdc_case_id': case_id,
            'validation': validation,
            'queries': queries,
            'time_range': {
                'start': start_time.isoformat() + 'Z',
                'end': end_time.isoformat() + 'Z',
                'days': days_back
            },
            'search_patterns': [
                f'sfdc:{case_id}',
                f'salesforce:{case_id}',
                f'case_id:{case_id}',
                f'case:{case_id}',
                case_id
            ]
        }

    def _build_primary_query(self, case_id: str, start_time: datetime, end_time: datetime) -> str:
        """Build primary query for common SFDC patterns."""
        return f'''resource.type="k8s_container"
AND (
    textPayload=~"sfdc:{case_id}"
    OR textPayload=~"salesforce:{case_id}"
    OR textPayload=~"case_id:{case_id}"
    OR textPayload=~"case:{case_id}"
    OR textPayload=~"sfdc_case_id[=:]{case_id}"
)
AND timestamp >= "{start_time.isoformat()}Z"
AND timestamp <= "{end_time.isoformat()}Z"'''

    def _build_json_payload_query(self, case_id: str, start_time: datetime, end_time: datetime) -> str:
        """Build query for JSON payload fields."""
        return f'''resource.type="k8s_container"
AND (
    jsonPayload.sfdc_case_id="{case_id}"
    OR jsonPayload.salesforce_case_id="{case_id}"
    OR jsonPayload.case_id="{case_id}"
    OR jsonPayload.salesforce.case_id="{case_id}"
    OR jsonPayload.metadata.case_id="{case_id}"
)
AND timestamp >= "{start_time.isoformat()}Z"
AND timestamp <= "{end_time.isoformat()}Z"'''

    def _build_broad_query(self, case_id: str, start_time: datetime, end_time: datetime) -> str:
        """Build broad query searching anywhere."""
        return f'''resource.type="k8s_container"
AND textPayload=~"{case_id}"
AND timestamp >= "{start_time.isoformat()}Z"
AND timestamp <= "{end_time.isoformat()}Z"'''

    def build_generic_queries(self, search_term: str, days_back: int = 7) -> dict:
        """Build GCP logging queries for any generic search term.

        This allows searching for ANY text across all logs - error messages,
        user IDs, transaction IDs, or any other identifier.
        """
        term = search_term.strip()
        search_type = self.detect_search_type(term)

        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days_back)

        queries = []

        # Primary: Search in textPayload
        queries.append({
            'query': f'''resource.type="k8s_container"
AND textPayload=~"{self._escape_regex(term)}"
AND timestamp >= "{start_time.isoformat()}Z"
AND timestamp <= "{end_time.isoformat()}Z"''',
            'priority': 1,
            'description': f'Search for "{term}" in text logs'
        })

        # Secondary: Search in jsonPayload message field
        queries.append({
            'query': f'''resource.type="k8s_container"
AND (
    jsonPayload.message=~"{self._escape_regex(term)}"
    OR jsonPayload.error=~"{self._escape_regex(term)}"
    OR jsonPayload.msg=~"{self._escape_regex(term)}"
)
AND timestamp >= "{start_time.isoformat()}Z"
AND timestamp <= "{end_time.isoformat()}Z"''',
            'priority': 2,
            'description': f'Search for "{term}" in JSON message/error fields'
        })

        # Tertiary: Search ERROR severity logs with the term
        queries.append({
            'query': f'''resource.type="k8s_container"
AND severity="ERROR"
AND textPayload=~"{self._escape_regex(term)}"
AND timestamp >= "{start_time.isoformat()}Z"
AND timestamp <= "{end_time.isoformat()}Z"''',
            'priority': 3,
            'description': f'Search ERROR logs containing "{term}"'
        })

        # If it looks like an error, also search without the exact term for related errors
        if search_type == 'error_message':
            # Extract key words from error message
            keywords = [w for w in term.split() if len(w) > 3][:3]
            if keywords:
                keyword_pattern = '.*'.join(keywords)
                queries.append({
                    'query': f'''resource.type="k8s_container"
AND severity="ERROR"
AND textPayload=~"{keyword_pattern}"
AND timestamp >= "{start_time.isoformat()}Z"
AND timestamp <= "{end_time.isoformat()}Z"''',
                    'priority': 4,
                    'description': f'Search ERROR logs with keywords: {", ".join(keywords)}'
                })

        return {
            'success': True,
            'search_term': term,
            'search_type': search_type,
            'queries': queries,
            'time_range': {
                'start': start_time.isoformat() + 'Z',
                'end': end_time.isoformat() + 'Z',
                'days': days_back
            },
            'search_patterns': [term]
        }

    def _escape_regex(self, text: str) -> str:
        """Escape special regex characters for GCP logging query."""
        # Escape characters that have special meaning in regex
        special_chars = r'\.^$*+?{}[]|()'
        escaped = text
        for char in special_chars:
            escaped = escaped.replace(char, '\\' + char)
        return escaped

    def generate_query_with_llm(self, search_term: str, context: str = None) -> dict:
        """Use LLM to generate optimized queries based on context."""
        search_type = self.detect_search_type(search_term)

        prompt = f"""Generate GCP Cloud Logging queries to find logs related to: "{search_term}"

Search type detected: {search_type}
Additional context: {context or 'No additional context provided'}

Consider:
1. The search term might appear in different formats or contexts
2. Look for both text and JSON log payloads
3. Focus on k8s_container resource type
4. Consider related error patterns and exception messages
5. Look for correlation IDs or request traces if applicable

Provide your response as a valid JSON object."""

        try:
            response = self.llm.generate(prompt, system_instruction=self.SYSTEM_PROMPT, temperature=0.3)

            # Try to parse JSON from response
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                return json.loads(json_match.group())
            else:
                return {'error': 'Could not parse LLM response', 'raw': response}
        except Exception as e:
            return {'error': str(e)}

    def run(self, search_term: str, days_back: int = 7, use_llm: bool = False) -> dict:
        """Main entry point for the agent.

        Automatically detects whether the search term is a Salesforce Case ID
        or a generic search term and builds appropriate queries.

        Args:
            search_term: The term to search for (SFDC Case ID, error message, etc.)
            days_back: Number of days to search back
            use_llm: Whether to use LLM for enhanced query generation

        Returns:
            dict with queries and metadata
        """
        search_type = self.detect_search_type(search_term)

        # Use SFDC-specific queries if it looks like a case ID
        if search_type == 'sfdc_case_id':
            result = self.build_queries(search_term, days_back)
        else:
            # Use generic queries for any other search term
            result = self.build_generic_queries(search_term, days_back)

        if use_llm and result.get('success'):
            llm_queries = self.generate_query_with_llm(search_term)
            if 'queries' in llm_queries:
                result['llm_enhanced_queries'] = llm_queries['queries']

        return result
