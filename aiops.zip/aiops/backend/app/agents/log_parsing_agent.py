"""Log Parsing Agent - Parses logs and extracts structured information."""

import re
import json
from typing import List, Dict, Any
from app.services.vertex_ai import vertex_ai_service


class LogParsingAgent:
    """Agent for parsing log entries and extracting structured data."""

    SYSTEM_PROMPT = """You are an expert log analyzer for cloud-native applications.
Your task is to parse log entries and extract:

1. Stack traces with file paths and line numbers
2. Error messages and exception types
3. Correlation IDs and request traces
4. Key-value pairs from structured logs
5. Timestamps and severity levels
6. Service/component identifiers

Be precise and extract actual data from the logs. Do not make up information.
Output valid JSON with your findings."""

    # Common stack trace patterns
    STACK_TRACE_PATTERNS = [
        # Python
        r'File "([^"]+)", line (\d+), in (\w+)',
        r'at ([^\s]+):(\d+)',
        # Java
        r'at ([a-zA-Z0-9.$_]+)\(([^:]+):(\d+)\)',
        # JavaScript/Node
        r'at ([^\s]+) \(([^:]+):(\d+):(\d+)\)',
        # Go
        r'([a-zA-Z0-9/_.-]+\.go):(\d+)',
    ]

    # Common error patterns
    ERROR_PATTERNS = [
        r'(?:Error|Exception|Failed|Failure):\s*(.+?)(?:\n|$)',
        r'(?:error|exception|failed|failure):\s*(.+?)(?:\n|$)',
        r'(\w+Exception):\s*(.+?)(?:\n|$)',
        r'(\w+Error):\s*(.+?)(?:\n|$)',
    ]

    def __init__(self):
        self.llm = vertex_ai_service

    def parse_log_entries(self, entries: List[Dict]) -> Dict:
        """Parse multiple log entries and extract structured data."""
        result = {
            'total_entries': len(entries),
            'parsed_entries': [],
            'stack_traces': [],
            'errors': [],
            'correlation_ids': set(),
            'containers': {},
            'severity_counts': {},
            'timeline': []
        }

        for entry in entries:
            parsed = self.parse_single_entry(entry)
            result['parsed_entries'].append(parsed)

            # Collect stack traces
            if parsed.get('stack_trace'):
                result['stack_traces'].append(parsed['stack_trace'])

            # Collect errors
            if parsed.get('error_info'):
                result['errors'].append(parsed['error_info'])

            # Collect correlation IDs
            if parsed.get('correlation_id'):
                result['correlation_ids'].add(parsed['correlation_id'])

            # Group by container
            container_key = parsed.get('container_name', 'unknown')
            if container_key not in result['containers']:
                result['containers'][container_key] = {
                    'name': container_key,
                    'pod': parsed.get('pod_name'),
                    'namespace': parsed.get('namespace'),
                    'entries': [],
                    'error_count': 0
                }
            result['containers'][container_key]['entries'].append(parsed)
            if parsed.get('severity') == 'ERROR':
                result['containers'][container_key]['error_count'] += 1

            # Count severities
            severity = parsed.get('severity', 'UNKNOWN')
            result['severity_counts'][severity] = result['severity_counts'].get(severity, 0) + 1

            # Timeline
            if parsed.get('timestamp'):
                result['timeline'].append({
                    'timestamp': parsed['timestamp'],
                    'severity': severity,
                    'container': container_key,
                    'summary': parsed.get('message_summary', '')[:100]
                })

        # Convert set to list for JSON serialization
        result['correlation_ids'] = list(result['correlation_ids'])
        result['containers'] = list(result['containers'].values())

        # Sort timeline
        result['timeline'].sort(key=lambda x: x['timestamp'] if x['timestamp'] else '')

        return result

    def parse_single_entry(self, entry: Dict) -> Dict:
        """Parse a single log entry."""
        parsed = {
            'timestamp': entry.get('timestamp'),
            'severity': entry.get('severity'),
            'insert_id': entry.get('insert_id'),
            'container_name': None,
            'pod_name': None,
            'namespace': None,
            'payload': None,
            'payload_type': entry.get('payload_type'),
            'message_summary': None,
            'stack_trace': None,
            'error_info': None,
            'correlation_id': None,
            'extracted_fields': {}
        }

        # Extract resource labels
        resource = entry.get('resource', {})
        labels = resource.get('labels', {})
        parsed['container_name'] = labels.get('container_name')
        parsed['pod_name'] = labels.get('pod_name')
        parsed['namespace'] = labels.get('namespace_name')

        # Parse payload
        payload = entry.get('payload')
        if isinstance(payload, str):
            parsed['payload'] = payload
            parsed['message_summary'] = payload[:200] if payload else None

            # Extract stack trace
            stack_trace = self.extract_stack_trace(payload)
            if stack_trace:
                parsed['stack_trace'] = stack_trace

            # Extract error info
            error_info = self.extract_error_info(payload)
            if error_info:
                parsed['error_info'] = error_info

            # Extract correlation ID
            correlation_id = self.extract_correlation_id(payload)
            if correlation_id:
                parsed['correlation_id'] = correlation_id

            # Extract key-value pairs
            parsed['extracted_fields'] = self.extract_key_values(payload)

        elif isinstance(payload, dict):
            parsed['payload'] = payload
            parsed['message_summary'] = payload.get('message', str(payload))[:200]

            # Extract from JSON structure
            if 'stack_trace' in payload:
                parsed['stack_trace'] = {'raw': payload['stack_trace']}
            if 'error' in payload:
                parsed['error_info'] = {'message': payload['error']}
            if 'correlation_id' in payload:
                parsed['correlation_id'] = payload['correlation_id']
            elif 'request_id' in payload:
                parsed['correlation_id'] = payload['request_id']

            parsed['extracted_fields'] = self._flatten_dict(payload)

        return parsed

    def extract_stack_trace(self, text: str) -> Dict:
        """Extract stack trace from text."""
        if not text:
            return None

        frames = []

        for pattern in self.STACK_TRACE_PATTERNS:
            matches = re.findall(pattern, text)
            for match in matches:
                if len(match) >= 2:
                    frames.append({
                        'file': match[0],
                        'line': int(match[1]) if match[1].isdigit() else match[1],
                        'function': match[2] if len(match) > 2 else None
                    })

        if frames:
            return {
                'frames': frames,
                'primary_frame': frames[0] if frames else None,
                'frame_count': len(frames)
            }

        return None

    def extract_error_info(self, text: str) -> Dict:
        """Extract error information from text."""
        if not text:
            return None

        for pattern in self.ERROR_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                groups = match.groups()
                if len(groups) >= 2:
                    return {
                        'exception_type': groups[0],
                        'message': groups[1].strip()
                    }
                elif len(groups) == 1:
                    return {
                        'message': groups[0].strip()
                    }

        return None

    def extract_correlation_id(self, text: str) -> str:
        """Extract correlation/request ID from text."""
        patterns = [
            r'correlation[_-]?id[=:]\s*([a-zA-Z0-9-]+)',
            r'request[_-]?id[=:]\s*([a-zA-Z0-9-]+)',
            r'trace[_-]?id[=:]\s*([a-zA-Z0-9-]+)',
            r'x-request-id[=:]\s*([a-zA-Z0-9-]+)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)

        return None

    def extract_key_values(self, text: str) -> Dict:
        """Extract key-value pairs from text."""
        extracted = {}

        # Pattern: key=value or key:value
        patterns = [
            r'(\w+)=([^\s,]+)',
            r'(\w+):\s*([^\s,]+)',
        ]

        for pattern in patterns:
            matches = re.findall(pattern, text)
            for key, value in matches:
                if key.lower() not in ['http', 'https', 'file']:  # Skip URLs
                    extracted[key] = value

        return extracted

    def _flatten_dict(self, d: Dict, prefix: str = '') -> Dict:
        """Flatten nested dictionary."""
        items = {}
        for k, v in d.items():
            new_key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, dict):
                items.update(self._flatten_dict(v, new_key))
            else:
                items[new_key] = v
        return items

    def analyze_with_llm(self, entries: List[Dict], context: str = None) -> Dict:
        """Use LLM for deeper log analysis."""
        # Prepare log summary for LLM
        log_summary = []
        for entry in entries[:50]:  # Limit to 50 entries
            summary = {
                'timestamp': entry.get('timestamp'),
                'severity': entry.get('severity'),
                'container': entry.get('resource', {}).get('labels', {}).get('container_name'),
                'message': str(entry.get('payload', ''))[:500]
            }
            log_summary.append(summary)

        prompt = f"""Analyze these log entries and identify:
1. Root cause indicators
2. Error patterns and their relationships
3. The sequence of events leading to the issue
4. Affected components and their dependencies

Logs:
{json.dumps(log_summary, indent=2)}

Context: {context or 'Investigating a Salesforce case issue'}

Provide analysis in JSON format with:
- root_cause_indicators: list of potential root causes
- error_chain: sequence of errors
- affected_components: list of components
- recommendations: list of investigation steps"""

        try:
            response = self.llm.generate(prompt, system_instruction=self.SYSTEM_PROMPT, temperature=0.3)

            # Parse JSON from response
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                return json.loads(json_match.group())
            return {'raw_analysis': response}
        except Exception as e:
            return {'error': str(e)}

    def run(self, log_entries: List[Dict], use_llm: bool = True) -> Dict:
        """Main entry point for the agent."""
        # First, do rule-based parsing
        result = self.parse_log_entries(log_entries)

        # Then, enhance with LLM analysis if requested
        if use_llm and log_entries:
            llm_analysis = self.analyze_with_llm(log_entries)
            result['llm_analysis'] = llm_analysis

        return result
