"""Investigation Orchestrator - Coordinates all agents for case investigation."""

from datetime import datetime
from typing import Dict, Callable
from flask import current_app

from app.services.mongodb_service import InvestigationRepository
from app.services.gcp_logging import gcp_logging_service
from app.agents.query_construction_agent import QueryConstructionAgent
from app.agents.log_parsing_agent import LogParsingAgent
from app.agents.container_identification_agent import ContainerIdentificationAgent
from app.agents.code_analysis_agent import CodeAnalysisAgent
from app.agents.rca_synthesis_agent import RCASynthesisAgent
from app.agents.fix_generator_agent import FixGeneratorAgent


class InvestigationOrchestrator:
    """Orchestrates the multi-agent investigation workflow."""

    PHASES = [
        'query_construction',
        'log_retrieval',
        'log_parsing',
        'container_identification',
        'code_analysis',
        'rca_synthesis',
        'fix_generation'
    ]

    def __init__(self):
        self.query_agent = QueryConstructionAgent()
        self.log_parsing_agent = LogParsingAgent()
        self.container_agent = ContainerIdentificationAgent()
        self.code_agent = CodeAnalysisAgent()
        self.rca_agent = RCASynthesisAgent()
        self.fix_agent = FixGeneratorAgent()

    def run_investigation(self, investigation_id: str, sfdc_case_id: str) -> Dict:
        """Run the complete investigation workflow."""
        findings = {
            'sfdc_case_id': sfdc_case_id,
            'investigation_id': investigation_id,
            'started_at': datetime.utcnow().isoformat()
        }

        try:
            # Phase 1: Query Construction
            findings['query_construction'] = self._run_phase(
                investigation_id,
                'query_construction',
                lambda: self.query_agent.run(sfdc_case_id, days_back=7, use_llm=False)
            )

            if not findings['query_construction'].get('success'):
                raise Exception(f"Query construction failed: {findings['query_construction'].get('error')}")

            # Phase 2: Log Retrieval
            findings['log_retrieval'] = self._run_phase(
                investigation_id,
                'log_retrieval',
                lambda: self._retrieve_logs(findings['query_construction'])
            )

            # Phase 3: Log Parsing
            log_entries = findings['log_retrieval'].get('raw_entries', [])
            findings['log_parsing'] = self._run_phase(
                investigation_id,
                'log_parsing',
                lambda: self.log_parsing_agent.run(log_entries, use_llm=True)
            )

            # Phase 4: Container Identification
            containers = findings['log_parsing'].get('containers', [])
            findings['container_identification'] = self._run_phase(
                investigation_id,
                'container_identification',
                lambda: self.container_agent.run(containers, use_llm=True)
            )

            # Phase 5: Code Analysis
            primary_container = findings['container_identification'].get('primary_container')
            stack_traces = findings['log_parsing'].get('stack_traces', [])
            primary_stack_trace = stack_traces[0] if stack_traces else None

            findings['code_analysis'] = self._run_phase(
                investigation_id,
                'code_analysis',
                lambda: self.code_agent.run(
                    stack_trace=primary_stack_trace,
                    container_info=primary_container,
                    error_info=findings['log_parsing'].get('errors', [{}])[0] if findings['log_parsing'].get('errors') else None
                )
            )

            # Phase 6: RCA Synthesis
            findings['rca_synthesis'] = self._run_phase(
                investigation_id,
                'rca_synthesis',
                lambda: self.rca_agent.run(findings, sfdc_case_id)
            )

            # Phase 7: Fix Generation
            findings['fix_generation'] = self._run_phase(
                investigation_id,
                'fix_generation',
                lambda: self.fix_agent.run(
                    findings['rca_synthesis'],
                    findings.get('code_analysis')
                )
            )

            findings['completed_at'] = datetime.utcnow().isoformat()
            findings['success'] = True

        except Exception as e:
            findings['error'] = str(e)
            findings['success'] = False
            findings['failed_at'] = datetime.utcnow().isoformat()

        return self._format_results(findings)

    def _run_phase(self, investigation_id: str, phase_name: str, phase_func: Callable) -> Dict:
        """Run a single phase and track it."""
        phase_data = {
            'name': phase_name,
            'status': 'in_progress',
            'started_at': datetime.utcnow().isoformat()
        }

        # Update investigation with phase start
        InvestigationRepository.add_phase(investigation_id, phase_data)

        try:
            result = phase_func()

            phase_data['status'] = 'completed'
            phase_data['completed_at'] = datetime.utcnow().isoformat()
            phase_data['result_summary'] = self._summarize_result(result)

            # Update phase status
            InvestigationRepository.update_phase(investigation_id, phase_name, phase_data)

            return result

        except Exception as e:
            phase_data['status'] = 'failed'
            phase_data['error'] = str(e)
            phase_data['failed_at'] = datetime.utcnow().isoformat()

            InvestigationRepository.update_phase(investigation_id, phase_name, phase_data)

            raise

    def _retrieve_logs(self, query_result: Dict) -> Dict:
        """Execute queries and retrieve logs."""
        queries = query_result.get('queries', [])

        all_entries = []
        query_results = []

        for query_info in queries:
            query = query_info.get('query')
            if not query:
                continue

            try:
                entries = gcp_logging_service.execute_query(query, max_results=500)
                query_results.append({
                    'query': query[:200] + '...' if len(query) > 200 else query,
                    'priority': query_info.get('priority'),
                    'entries_found': len(entries)
                })
                all_entries.extend(entries)

                # If we found entries with higher priority query, we can skip lower priority
                if entries and query_info.get('priority', 5) <= 2:
                    break

            except Exception as e:
                query_results.append({
                    'query': query[:200] + '...' if len(query) > 200 else query,
                    'error': str(e)
                })

        # Deduplicate by insert_id
        seen_ids = set()
        unique_entries = []
        for entry in all_entries:
            insert_id = entry.get('insert_id')
            if insert_id and insert_id not in seen_ids:
                seen_ids.add(insert_id)
                unique_entries.append(entry)

        return {
            'success': True,
            'total_entries': len(unique_entries),
            'query_results': query_results,
            'raw_entries': unique_entries
        }

    def _summarize_result(self, result: Dict) -> Dict:
        """Create a summary of a phase result for storage."""
        if not result:
            return {}

        summary = {'success': result.get('success', True)}

        # Phase-specific summaries
        if 'queries' in result:
            summary['queries_generated'] = len(result.get('queries', []))

        if 'total_entries' in result:
            summary['log_entries'] = result['total_entries']

        if 'containers' in result:
            summary['containers_found'] = len(result.get('containers', []))

        if 'primary_container' in result:
            pc = result['primary_container']
            summary['primary_container'] = pc.get('container_name') or pc.get('name')
            summary['confidence'] = result.get('confidence')

        if 'rca' in result:
            rca = result['rca']
            summary['root_cause'] = rca.get('root_cause', {}).get('description', '')[:200]

        if 'fixes' in result:
            summary['fixes_generated'] = len(result.get('fixes', []))

        return summary

    def _format_results(self, findings: Dict) -> Dict:
        """Format final results for storage."""
        # Extract key information for top-level fields
        result = {
            'success': findings.get('success', False),
            'sfdc_case_id': findings.get('sfdc_case_id'),
            'started_at': findings.get('started_at'),
            'completed_at': findings.get('completed_at'),
            'failed_at': findings.get('failed_at'),
            'error': findings.get('error')
        }

        # Containers
        container_id = findings.get('container_identification', {})
        if container_id.get('primary_container'):
            result['containers'] = [container_id['primary_container']] + container_id.get('related_containers', [])
        else:
            result['containers'] = []

        # Log entries (limited)
        log_retrieval = findings.get('log_retrieval', {})
        result['log_entries'] = log_retrieval.get('raw_entries', [])[:100]  # Limit stored entries

        # RCA Report
        rca_synthesis = findings.get('rca_synthesis', {})
        result['rca_report'] = rca_synthesis.get('rca')
        result['rca_summary'] = rca_synthesis.get('summary_report')

        # Fix recommendations
        fix_gen = findings.get('fix_generation', {})
        result['fix_recommendations'] = fix_gen.get('fixes', [])

        # Confidence score
        result['confidence_score'] = rca_synthesis.get('confidence', {}).get('percentage', 0) / 100

        # Full findings for detailed view
        result['full_findings'] = findings

        return result

    def run_phase_only(self, investigation_id: str, sfdc_case_id: str, phase: str) -> Dict:
        """Run only a specific phase (for retrying failed phases)."""
        # Get current investigation state
        investigation = InvestigationRepository.get_by_id(investigation_id)
        if not investigation:
            return {'error': 'Investigation not found'}

        # Get previous phase results
        findings = investigation.get('full_findings', {})

        # Run the specific phase
        phase_handlers = {
            'query_construction': lambda: self.query_agent.run(sfdc_case_id, days_back=7),
            'log_retrieval': lambda: self._retrieve_logs(findings.get('query_construction', {})),
            'log_parsing': lambda: self.log_parsing_agent.run(
                findings.get('log_retrieval', {}).get('raw_entries', [])
            ),
            'container_identification': lambda: self.container_agent.run(
                findings.get('log_parsing', {}).get('containers', [])
            ),
            'code_analysis': lambda: self.code_agent.run(
                stack_trace=findings.get('log_parsing', {}).get('stack_traces', [{}])[0] if findings.get('log_parsing', {}).get('stack_traces') else None,
                container_info=findings.get('container_identification', {}).get('primary_container')
            ),
            'rca_synthesis': lambda: self.rca_agent.run(findings, sfdc_case_id),
            'fix_generation': lambda: self.fix_agent.run(
                findings.get('rca_synthesis', {}),
                findings.get('code_analysis')
            )
        }

        if phase not in phase_handlers:
            return {'error': f'Unknown phase: {phase}'}

        result = self._run_phase(investigation_id, phase, phase_handlers[phase])
        return result
