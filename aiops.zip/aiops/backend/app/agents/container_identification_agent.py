"""Container Identification Agent - Identifies primary issue container."""

import json
from typing import List, Dict
from app.services.vertex_ai import vertex_ai_service


class ContainerIdentificationAgent:
    """Agent for identifying and ranking containers by issue likelihood."""

    SYSTEM_PROMPT = """You are an expert SRE analyzing container issues in a Kubernetes environment.
Your task is to identify which container is the PRIMARY source of an issue based on log analysis.

Consider these factors when ranking:
1. Error frequency and severity - more errors = more likely to be the source
2. Timestamp ordering - earlier errors often indicate root cause
3. Error types - application errors vs downstream effects
4. Container relationships - upstream services cause downstream failures
5. Stack trace depth - deeper traces often indicate the actual failure point

Provide your analysis in JSON format with confidence scores and reasoning."""

    def __init__(self):
        self.llm = vertex_ai_service

    def rank_containers(self, containers: List[Dict]) -> Dict:
        """Rank containers by likelihood of being the issue source."""
        if not containers:
            return {
                'success': False,
                'error': 'No containers provided',
                'ranked_containers': []
            }

        # Calculate scores for each container
        scored_containers = []
        for container in containers:
            score = self._calculate_container_score(container)
            scored_containers.append({
                **container,
                'score': score,
                'score_breakdown': self._get_score_breakdown(container)
            })

        # Sort by score (descending)
        scored_containers.sort(key=lambda x: x['score'], reverse=True)

        # Determine primary and related containers
        primary = scored_containers[0] if scored_containers else None
        related = scored_containers[1:] if len(scored_containers) > 1 else []

        return {
            'success': True,
            'primary_container': primary,
            'related_containers': related,
            'total_containers': len(containers),
            'confidence': self._calculate_confidence(scored_containers)
        }

    def _calculate_container_score(self, container: Dict) -> float:
        """Calculate a score for a container based on various factors."""
        score = 0.0

        # Error count (0-40 points)
        error_count = container.get('error_count', 0)
        score += min(error_count * 4, 40)

        # Warning count (0-10 points)
        warning_count = container.get('warning_count', 0)
        score += min(warning_count * 1, 10)

        # Has stack trace (20 points)
        entries = container.get('entries', [])
        has_stack_trace = any(
            e.get('stack_trace') or 'stack' in str(e.get('payload', '')).lower()
            for e in entries
        )
        if has_stack_trace:
            score += 20

        # Has exception (15 points)
        has_exception = any(
            'exception' in str(e.get('payload', '')).lower()
            for e in entries
        )
        if has_exception:
            score += 15

        # Timestamp factor - earlier = higher score (0-15 points)
        first_occurrence = container.get('first_occurrence')
        if first_occurrence:
            # Bonus for being first
            score += 15

        return score

    def _get_score_breakdown(self, container: Dict) -> Dict:
        """Get detailed score breakdown for transparency."""
        error_count = container.get('error_count', 0)
        warning_count = container.get('warning_count', 0)

        entries = container.get('entries', [])
        has_stack_trace = any(
            e.get('stack_trace') or 'stack' in str(e.get('payload', '')).lower()
            for e in entries
        )
        has_exception = any(
            'exception' in str(e.get('payload', '')).lower()
            for e in entries
        )

        return {
            'error_score': min(error_count * 4, 40),
            'warning_score': min(warning_count * 1, 10),
            'stack_trace_score': 20 if has_stack_trace else 0,
            'exception_score': 15 if has_exception else 0,
            'timestamp_score': 15 if container.get('first_occurrence') else 0
        }

    def _calculate_confidence(self, scored_containers: List[Dict]) -> float:
        """Calculate confidence in the identification."""
        if not scored_containers:
            return 0.0

        if len(scored_containers) == 1:
            return 0.95  # High confidence with single container

        # Calculate score gap between top 2
        top_score = scored_containers[0]['score']
        second_score = scored_containers[1]['score'] if len(scored_containers) > 1 else 0

        if top_score == 0:
            return 0.3  # Low confidence with no clear indicators

        score_gap = (top_score - second_score) / top_score

        # Higher gap = higher confidence
        if score_gap > 0.5:
            return 0.95
        elif score_gap > 0.3:
            return 0.85
        elif score_gap > 0.1:
            return 0.70
        else:
            return 0.50  # Similar scores = uncertain

    def analyze_with_llm(self, containers: List[Dict], log_context: str = None) -> Dict:
        """Use LLM for deeper container analysis."""
        # Prepare container summary for LLM
        container_summary = []
        for c in containers:
            entries = c.get('entries', [])
            error_messages = [
                str(e.get('payload', ''))[:200]
                for e in entries
                if e.get('severity') == 'ERROR'
            ][:5]  # Limit to 5 error messages

            container_summary.append({
                'name': c.get('container_name') or c.get('name'),
                'namespace': c.get('namespace'),
                'error_count': c.get('error_count', 0),
                'warning_count': c.get('warning_count', 0),
                'first_occurrence': c.get('first_occurrence'),
                'last_occurrence': c.get('last_occurrence'),
                'sample_errors': error_messages
            })

        prompt = f"""Analyze these containers to identify the PRIMARY source of the issue:

Containers:
{json.dumps(container_summary, indent=2)}

Additional Context: {log_context or 'Investigating a customer-reported issue'}

For each container, determine:
1. Is it likely the ROOT CAUSE or a DOWNSTREAM EFFECT?
2. What is the relationship between containers (if multiple)?
3. Which container should be investigated first?

Provide your analysis in JSON format:
{{
    "primary_container": {{
        "name": "container name",
        "confidence": 0.0-1.0,
        "reasoning": "why this is the primary container"
    }},
    "container_relationships": [
        {{
            "from": "source container",
            "to": "affected container",
            "relationship": "causes/triggers/depends_on"
        }}
    ],
    "investigation_order": ["container1", "container2"],
    "overall_assessment": "summary of the issue"
}}"""

        try:
            response = self.llm.generate(prompt, system_instruction=self.SYSTEM_PROMPT, temperature=0.3)

            # Parse JSON from response
            json_match = json.loads(response) if response.strip().startswith('{') else None
            if not json_match:
                import re
                json_match_str = re.search(r'\{[\s\S]*\}', response)
                if json_match_str:
                    json_match = json.loads(json_match_str.group())

            return json_match or {'raw_analysis': response}
        except Exception as e:
            return {'error': str(e)}

    def identify_downstream_effects(self, containers: List[Dict]) -> List[Dict]:
        """Identify containers that are likely downstream effects."""
        if len(containers) < 2:
            return []

        downstream = []
        primary = containers[0] if containers else None

        if not primary:
            return []

        primary_time = primary.get('first_occurrence')

        for container in containers[1:]:
            container_time = container.get('first_occurrence')

            # Later timestamp suggests downstream
            if primary_time and container_time and container_time > primary_time:
                downstream.append({
                    **container,
                    'relationship': 'downstream',
                    'time_delta': container_time
                })

            # Check for notification/alert patterns
            name = (container.get('container_name') or container.get('name') or '').lower()
            if any(x in name for x in ['notification', 'alert', 'email', 'webhook']):
                downstream.append({
                    **container,
                    'relationship': 'notification_service',
                    'likely_downstream': True
                })

        return downstream

    def run(self, containers: List[Dict], use_llm: bool = True) -> Dict:
        """Main entry point for the agent."""
        # First, do rule-based ranking
        result = self.rank_containers(containers)

        # Identify downstream effects
        if result.get('success'):
            result['downstream_analysis'] = self.identify_downstream_effects(
                [result['primary_container']] + result.get('related_containers', [])
            )

        # Enhance with LLM analysis if requested
        if use_llm and containers:
            llm_analysis = self.analyze_with_llm(containers)
            result['llm_analysis'] = llm_analysis

            # Update confidence if LLM provides it
            if 'primary_container' in llm_analysis:
                llm_confidence = llm_analysis['primary_container'].get('confidence')
                if llm_confidence:
                    # Average rule-based and LLM confidence
                    result['confidence'] = (result['confidence'] + llm_confidence) / 2

        return result
