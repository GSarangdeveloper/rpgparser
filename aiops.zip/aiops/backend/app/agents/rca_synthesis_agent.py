"""RCA Synthesis Agent - Synthesizes Root Cause Analysis report."""

import json
from datetime import datetime
from typing import Dict, List
from app.services.vertex_ai import vertex_ai_service


class RCASynthesisAgent:
    """Agent for synthesizing comprehensive Root Cause Analysis reports."""

    SYSTEM_PROMPT = """You are an expert Site Reliability Engineer creating Root Cause Analysis reports.
Your task is to synthesize all investigation findings into a comprehensive RCA report.

A good RCA report includes:
1. Executive Summary - Clear, concise problem statement
2. Timeline - Chronological sequence of events
3. Root Cause - The actual underlying cause (not symptoms)
4. Impact Assessment - Who/what was affected and how
5. Contributing Factors - Things that made the issue worse
6. Remediation - Immediate and long-term fixes
7. Prevention - How to prevent recurrence

Be specific, actionable, and data-driven. Reference actual log entries, code, and timestamps."""

    def __init__(self):
        self.llm = vertex_ai_service

    def build_timeline(self, findings: Dict) -> List[Dict]:
        """Build chronological timeline from findings."""
        events = []

        # Extract events from log parsing
        log_analysis = findings.get('log_parsing', {})
        timeline_entries = log_analysis.get('timeline', [])

        for entry in timeline_entries:
            events.append({
                'timestamp': entry.get('timestamp'),
                'type': 'log_entry',
                'severity': entry.get('severity'),
                'source': entry.get('container'),
                'description': entry.get('summary', '')[:200]
            })

        # Add container identification events
        container_analysis = findings.get('container_identification', {})
        primary = container_analysis.get('primary_container')
        if primary:
            events.append({
                'timestamp': primary.get('first_occurrence'),
                'type': 'issue_detected',
                'severity': 'ERROR',
                'source': primary.get('container_name') or primary.get('name'),
                'description': f"First error detected in primary container"
            })

        # Add code-related events
        code_analysis = findings.get('code_analysis', {})
        commit_analysis = code_analysis.get('commit_analysis', {})
        suspicious_commits = commit_analysis.get('suspicious_commits', [])

        for commit in suspicious_commits:
            events.append({
                'timestamp': commit.get('date'),
                'type': 'code_change',
                'severity': commit.get('risk_level', 'medium').upper(),
                'source': 'GitHub',
                'description': f"Suspicious commit: {commit.get('sha')} - {commit.get('reason', '')}"
            })

        # Sort by timestamp
        events.sort(key=lambda x: x.get('timestamp') or '')

        return events

    def calculate_confidence_score(self, findings: Dict) -> Dict:
        """Calculate overall confidence in the RCA."""
        scores = {
            'log_evidence': 0,
            'container_identification': 0,
            'code_correlation': 0,
            'timeline_clarity': 0
        }

        # Log evidence score
        log_analysis = findings.get('log_parsing', {})
        if log_analysis.get('stack_traces'):
            scores['log_evidence'] += 30
        if log_analysis.get('errors'):
            scores['log_evidence'] += 20

        # Container identification score
        container_analysis = findings.get('container_identification', {})
        container_confidence = container_analysis.get('confidence', 0)
        scores['container_identification'] = int(container_confidence * 25)

        # Code correlation score
        code_analysis = findings.get('code_analysis', {})
        if code_analysis.get('code_analysis'):
            scores['code_correlation'] += 15
        if code_analysis.get('commit_analysis'):
            scores['code_correlation'] += 10

        # Timeline clarity
        timeline = self.build_timeline(findings)
        if len(timeline) > 5:
            scores['timeline_clarity'] = 15
        elif len(timeline) > 2:
            scores['timeline_clarity'] = 10

        total = sum(scores.values())
        max_score = 100

        return {
            'overall_score': total,
            'max_score': max_score,
            'percentage': round(total / max_score * 100, 1),
            'breakdown': scores,
            'confidence_level': 'high' if total > 75 else 'medium' if total > 50 else 'low'
        }

    def synthesize_rca(self, findings: Dict, sfdc_case_id: str) -> Dict:
        """Synthesize all findings into RCA report using LLM."""
        # Prepare findings summary
        summary = {
            'sfdc_case_id': sfdc_case_id,
            'investigation_timestamp': datetime.utcnow().isoformat(),
            'findings': {}
        }

        # Log parsing summary
        log_analysis = findings.get('log_parsing', {})
        summary['findings']['logs'] = {
            'total_entries': log_analysis.get('total_entries', 0),
            'error_count': log_analysis.get('severity_counts', {}).get('ERROR', 0),
            'containers_affected': len(log_analysis.get('containers', [])),
            'has_stack_traces': len(log_analysis.get('stack_traces', [])) > 0,
            'sample_errors': [e.get('message', '')[:100] for e in log_analysis.get('errors', [])[:3]]
        }

        # Container identification summary
        container_analysis = findings.get('container_identification', {})
        primary = container_analysis.get('primary_container', {})
        summary['findings']['primary_container'] = {
            'name': primary.get('container_name') or primary.get('name'),
            'namespace': primary.get('namespace'),
            'error_count': primary.get('error_count', 0),
            'confidence': container_analysis.get('confidence', 0)
        }

        # Code analysis summary
        code_analysis = findings.get('code_analysis', {})
        code_result = code_analysis.get('code_analysis', {})
        summary['findings']['code'] = {
            'potential_issues': code_result.get('potential_issues', [])[:3],
            'root_cause_likelihood': code_result.get('root_cause_likelihood', 0),
            'suspicious_commits': [
                c.get('sha') for c in
                code_analysis.get('commit_analysis', {}).get('suspicious_commits', [])
            ][:3]
        }

        # Build prompt
        prompt = f"""Based on these investigation findings, create a comprehensive Root Cause Analysis report:

{json.dumps(summary, indent=2)}

Create an RCA report in JSON format:
{{
    "executive_summary": "2-3 sentence summary of the issue and root cause",
    "problem_statement": "Clear description of what went wrong",
    "root_cause": {{
        "description": "The actual root cause",
        "evidence": ["list of evidence supporting this conclusion"],
        "confidence": 0.0-1.0
    }},
    "impact": {{
        "affected_users": "description of affected users",
        "affected_services": ["list of services"],
        "severity": "critical/high/medium/low",
        "duration": "estimated duration of impact"
    }},
    "timeline": [
        {{
            "time": "timestamp or relative time",
            "event": "what happened",
            "significance": "why it matters"
        }}
    ],
    "contributing_factors": [
        {{
            "factor": "description",
            "how_it_contributed": "explanation"
        }}
    ],
    "immediate_actions": [
        "action 1",
        "action 2"
    ],
    "long_term_remediation": [
        {{
            "action": "what to do",
            "owner": "suggested owner/team",
            "priority": "high/medium/low"
        }}
    ],
    "prevention_measures": [
        "measure 1",
        "measure 2"
    ],
    "lessons_learned": [
        "lesson 1",
        "lesson 2"
    ]
}}"""

        try:
            response = self.llm.generate(prompt, system_instruction=self.SYSTEM_PROMPT, temperature=0.4)

            # Parse JSON
            import re
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                return json.loads(json_match.group())
            return {'raw_rca': response}
        except Exception as e:
            return {'error': str(e)}

    def generate_summary_report(self, rca: Dict, sfdc_case_id: str) -> str:
        """Generate a human-readable summary report."""
        summary = f"""
================================================================================
ROOT CAUSE ANALYSIS REPORT
================================================================================

Case ID: {sfdc_case_id}
Generated: {datetime.utcnow().isoformat()}

EXECUTIVE SUMMARY
-----------------
{rca.get('executive_summary', 'Not available')}

PROBLEM STATEMENT
-----------------
{rca.get('problem_statement', 'Not available')}

ROOT CAUSE
----------
{rca.get('root_cause', {}).get('description', 'Not determined')}

Confidence: {rca.get('root_cause', {}).get('confidence', 0) * 100:.0f}%

Evidence:
"""
        for evidence in rca.get('root_cause', {}).get('evidence', []):
            summary += f"  - {evidence}\n"

        summary += f"""
IMPACT
------
Severity: {rca.get('impact', {}).get('severity', 'Unknown')}
Affected Users: {rca.get('impact', {}).get('affected_users', 'Unknown')}
Duration: {rca.get('impact', {}).get('duration', 'Unknown')}

IMMEDIATE ACTIONS REQUIRED
--------------------------
"""
        for i, action in enumerate(rca.get('immediate_actions', []), 1):
            summary += f"  {i}. {action}\n"

        summary += """
LONG-TERM REMEDIATION
---------------------
"""
        for item in rca.get('long_term_remediation', []):
            summary += f"  - [{item.get('priority', 'medium').upper()}] {item.get('action', '')} (Owner: {item.get('owner', 'TBD')})\n"

        summary += """
================================================================================
"""
        return summary

    def run(self, findings: Dict, sfdc_case_id: str) -> Dict:
        """Main entry point for the agent."""
        # Build timeline
        timeline = self.build_timeline(findings)

        # Calculate confidence
        confidence = self.calculate_confidence_score(findings)

        # Synthesize RCA with LLM
        rca = self.synthesize_rca(findings, sfdc_case_id)

        # Generate human-readable report
        summary_report = self.generate_summary_report(rca, sfdc_case_id)

        return {
            'success': True,
            'sfdc_case_id': sfdc_case_id,
            'rca': rca,
            'timeline': timeline,
            'confidence': confidence,
            'summary_report': summary_report,
            'generated_at': datetime.utcnow().isoformat()
        }
