"""Code Analysis Agent - Analyzes code for root cause identification."""

import json
import re
from typing import Dict, List
from app.services.vertex_ai import vertex_ai_service
from app.services.github_service import github_service


class CodeAnalysisAgent:
    """Agent for analyzing source code to identify root causes."""

    SYSTEM_PROMPT = """You are an expert code analyst performing root cause analysis.
Your task is to analyze code and identify potential issues based on:

1. Stack traces pointing to specific lines
2. Error messages indicating the failure point
3. Recent code changes that may have introduced bugs
4. Code patterns that commonly cause issues

When analyzing code:
- Look for error handling gaps
- Identify potential null/undefined references
- Check for race conditions or timing issues
- Look for resource management problems
- Identify logical errors

Provide your analysis in structured JSON format with specific line references."""

    def __init__(self):
        self.llm = vertex_ai_service
        self.github = github_service

    def analyze_stack_trace(self, stack_trace: Dict, repo_mapping: Dict = None) -> Dict:
        """Analyze a stack trace and fetch relevant code."""
        if not stack_trace:
            return {'error': 'No stack trace provided'}

        frames = stack_trace.get('frames', [])
        if not frames:
            return {'error': 'No frames in stack trace'}

        analysis_results = []

        for frame in frames[:5]:  # Analyze top 5 frames
            file_path = frame.get('file', '')
            line_number = frame.get('line')
            function_name = frame.get('function')

            # Try to fetch code if we have repo mapping
            code_context = None
            if repo_mapping and file_path:
                repo_name = repo_mapping.get('repository')
                if repo_name:
                    # Normalize file path (remove leading /app/ or similar)
                    normalized_path = re.sub(r'^/app/', '', file_path)
                    normalized_path = re.sub(r'^/src/', 'src/', normalized_path)

                    code_result = self.github.get_file_with_context(
                        repo_name,
                        normalized_path,
                        line_number,
                        context_lines=30,
                        ref=repo_mapping.get('version')
                    )

                    if 'error' not in code_result:
                        code_context = code_result

            analysis_results.append({
                'frame': frame,
                'file_path': file_path,
                'line_number': line_number,
                'function_name': function_name,
                'code_context': code_context
            })

        return {
            'stack_trace': stack_trace,
            'analyzed_frames': analysis_results,
            'primary_frame': analysis_results[0] if analysis_results else None
        }

    def analyze_code_with_llm(self, code_context: Dict, error_info: Dict = None) -> Dict:
        """Use LLM to analyze code and identify potential issues."""
        if not code_context:
            return {'error': 'No code context provided'}

        code_content = code_context.get('context_content', code_context.get('content', ''))
        file_path = code_context.get('path', 'unknown')
        target_line = code_context.get('target_line')

        prompt = f"""Analyze this code for potential issues:

File: {file_path}
Target Line: {target_line}

Code:
```
{code_content}
```

Error Information: {json.dumps(error_info) if error_info else 'Not provided'}

Identify:
1. What the code is trying to do at the target line
2. Potential issues that could cause failures
3. Missing error handling
4. Edge cases not handled
5. Recommendations for fixes

Provide your analysis in JSON format:
{{
    "code_purpose": "what this code does",
    "target_line_analysis": "analysis of the specific line",
    "potential_issues": [
        {{
            "issue": "description",
            "severity": "high/medium/low",
            "line_number": number,
            "evidence": "why this is an issue"
        }}
    ],
    "root_cause_likelihood": 0.0-1.0,
    "recommended_fixes": [
        {{
            "description": "fix description",
            "code_change": "suggested code",
            "risk": "low/medium/high"
        }}
    ]
}}"""

        try:
            response = self.llm.generate(prompt, system_instruction=self.SYSTEM_PROMPT, temperature=0.3)

            # Parse JSON
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                return json.loads(json_match.group())
            return {'raw_analysis': response}
        except Exception as e:
            return {'error': str(e)}

    def analyze_recent_commits(self, repo_name: str, file_path: str, ref: str = None) -> Dict:
        """Analyze recent commits to the file for potential issue introduction."""
        commits = self.github.get_recent_commits(repo_name, file_path, limit=10, ref=ref)

        if not commits or (commits and 'error' in commits[0]):
            return {'error': 'Could not fetch commits', 'details': commits}

        # Analyze commits with LLM
        commit_summary = []
        for commit in commits[:5]:
            commit_summary.append({
                'sha': commit.get('short_sha'),
                'author': commit.get('author'),
                'date': commit.get('date'),
                'message': commit.get('message', '')[:200]
            })

        prompt = f"""Analyze these recent commits to {file_path}:

{json.dumps(commit_summary, indent=2)}

Identify:
1. Which commit is most likely to have introduced a bug
2. Changes that might have caused regressions
3. Risk level of each change

Respond in JSON format:
{{
    "suspicious_commits": [
        {{
            "sha": "commit sha",
            "reason": "why suspicious",
            "risk_level": "high/medium/low"
        }}
    ],
    "recommended_investigation": "which commit to investigate first"
}}"""

        try:
            response = self.llm.generate(prompt, system_instruction=self.SYSTEM_PROMPT, temperature=0.3)
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                result = json.loads(json_match.group())
                result['commits'] = commits
                return result
            return {'commits': commits, 'raw_analysis': response}
        except Exception as e:
            return {'commits': commits, 'error': str(e)}

    def map_container_to_code(self, container_info: Dict) -> Dict:
        """Map container information to source code repository."""
        container_name = container_info.get('container_name') or container_info.get('name')
        image = container_info.get('image', '')

        # Extract image tag/version
        if ':' in image:
            image_name, image_tag = image.rsplit(':', 1)
        else:
            image_name = image
            image_tag = 'latest'

        # Use GitHub service to map
        mapping = self.github.map_container_to_repo(container_name, image)

        return {
            'container_name': container_name,
            'image': image,
            'image_name': image_name,
            'image_tag': image_tag,
            'repository': mapping.get('repository'),
            'version': mapping.get('version'),
            'mapping_found': mapping.get('found', False)
        }

    def run(self, stack_trace: Dict = None, container_info: Dict = None,
            error_info: Dict = None, repo_mapping: Dict = None) -> Dict:
        """Main entry point for the agent."""
        result = {
            'success': True,
            'stack_trace_analysis': None,
            'code_analysis': None,
            'commit_analysis': None,
            'container_mapping': None
        }

        # Map container to code if provided
        if container_info:
            result['container_mapping'] = self.map_container_to_code(container_info)
            if not repo_mapping:
                repo_mapping = result['container_mapping']

        # Analyze stack trace
        if stack_trace:
            stack_analysis = self.analyze_stack_trace(stack_trace, repo_mapping)
            result['stack_trace_analysis'] = stack_analysis

            # If we got code context, analyze it with LLM
            primary_frame = stack_analysis.get('primary_frame', {})
            code_context = primary_frame.get('code_context')
            if code_context:
                result['code_analysis'] = self.analyze_code_with_llm(code_context, error_info)

        # Analyze recent commits if we have repo info
        if repo_mapping and repo_mapping.get('repository'):
            file_path = None
            if stack_trace and stack_trace.get('frames'):
                file_path = stack_trace['frames'][0].get('file')
                # Normalize path
                if file_path:
                    file_path = re.sub(r'^/app/', '', file_path)

            if file_path:
                result['commit_analysis'] = self.analyze_recent_commits(
                    repo_mapping['repository'],
                    file_path,
                    repo_mapping.get('version')
                )

        return result
