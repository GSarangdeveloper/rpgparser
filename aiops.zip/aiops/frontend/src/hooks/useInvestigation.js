import { useState, useEffect, useCallback } from 'react';
import { investigationApi } from '../services/api';

export function useInvestigation(investigationId) {
  const [investigation, setInvestigation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [streaming, setStreaming] = useState(false);

  const fetchInvestigation = useCallback(async () => {
    if (!investigationId) return;

    try {
      setLoading(true);
      const response = await investigationApi.get(investigationId);
      setInvestigation(response.data);
      setError(null);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to fetch investigation');
    } finally {
      setLoading(false);
    }
  }, [investigationId]);

  const startStream = useCallback(() => {
    if (!investigationId || streaming) return;

    setStreaming(true);
    const eventSource = investigationApi.stream(investigationId);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.error) {
          setError(data.error);
          eventSource.close();
          setStreaming(false);
          return;
        }

        if (data.event === 'complete') {
          eventSource.close();
          setStreaming(false);
          fetchInvestigation();
          return;
        }

        setInvestigation(data);
      } catch (e) {
        console.error('Error parsing SSE data:', e);
      }
    };

    eventSource.onerror = () => {
      eventSource.close();
      setStreaming(false);
    };

    return () => {
      eventSource.close();
      setStreaming(false);
    };
  }, [investigationId, streaming, fetchInvestigation]);

  useEffect(() => {
    fetchInvestigation();
  }, [fetchInvestigation]);

  useEffect(() => {
    // Auto-start streaming if investigation is in progress
    if (investigation?.status === 'in_progress' && !streaming) {
      const cleanup = startStream();
      return cleanup;
    }
  }, [investigation?.status, streaming, startStream]);

  const retry = async () => {
    try {
      await investigationApi.retry(investigationId);
      fetchInvestigation();
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to retry investigation');
    }
  };

  return {
    investigation,
    loading,
    error,
    streaming,
    refresh: fetchInvestigation,
    retry,
  };
}

export function useInvestigationList() {
  const [investigations, setInvestigations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchInvestigations = useCallback(async () => {
    try {
      setLoading(true);
      const response = await investigationApi.list();
      setInvestigations(response.data.investigations || []);
      setError(null);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to fetch investigations');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInvestigations();
  }, [fetchInvestigations]);

  const startInvestigation = async (sfdcCaseId) => {
    try {
      const response = await investigationApi.start(sfdcCaseId);
      await fetchInvestigations();
      return response.data;
    } catch (err) {
      throw new Error(err.response?.data?.error || 'Failed to start investigation');
    }
  };

  return {
    investigations,
    loading,
    error,
    refresh: fetchInvestigations,
    startInvestigation,
  };
}
