import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [apiKey, setApiKey] = useState(localStorage.getItem('apiKey') || '');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if we have a stored API key
    const storedKey = localStorage.getItem('apiKey');
    if (storedKey) {
      verifyApiKey(storedKey);
    } else {
      setLoading(false);
    }
  }, []);

  const verifyApiKey = async (key) => {
    try {
      api.defaults.headers.common['X-API-Key'] = key;
      const response = await api.get('/api/auth/verify');
      if (response.data.valid) {
        setApiKey(key);
        setIsAuthenticated(true);
        setUser({ role: 'analyst' });
      }
    } catch (error) {
      localStorage.removeItem('apiKey');
      setIsAuthenticated(false);
    } finally {
      setLoading(false);
    }
  };

  const login = async (key) => {
    try {
      api.defaults.headers.common['X-API-Key'] = key;
      const response = await api.post('/api/auth/login', { api_key: key });

      if (response.data.success) {
        localStorage.setItem('apiKey', key);
        setApiKey(key);
        setUser(response.data.user);
        setIsAuthenticated(true);
        return { success: true };
      }
      return { success: false, error: 'Invalid API key' };
    } catch (error) {
      return { success: false, error: error.response?.data?.error || 'Login failed' };
    }
  };

  const logout = () => {
    localStorage.removeItem('apiKey');
    delete api.defaults.headers.common['X-API-Key'];
    setApiKey('');
    setUser(null);
    setIsAuthenticated(false);
  };

  const value = {
    user,
    apiKey,
    isAuthenticated,
    loading,
    login,
    logout,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
