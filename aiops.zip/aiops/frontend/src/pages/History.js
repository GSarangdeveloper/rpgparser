import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  CircularProgress,
  Alert,
  Button,
} from '@mui/material';
import {
  Visibility as ViewIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { useInvestigationList } from '../hooks/useInvestigation';
import { format } from 'date-fns';

const statusColors = {
  completed: 'success',
  failed: 'error',
  in_progress: 'primary',
  pending: 'default',
};

export default function History() {
  const { investigations, loading, error, refresh } = useInvestigationList();
  const navigate = useNavigate();

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error">
        {error}
        <Button onClick={refresh} sx={{ ml: 2 }}>
          Retry
        </Button>
      </Alert>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4">
          Investigation History
        </Typography>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={refresh}
        >
          Refresh
        </Button>
      </Box>

      {investigations.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="body1" color="text.secondary">
            No investigations found
          </Typography>
          <Button
            variant="contained"
            onClick={() => navigate('/')}
            sx={{ mt: 2 }}
          >
            Start New Investigation
          </Button>
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Case ID</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Confidence</TableCell>
                <TableCell>Containers</TableCell>
                <TableCell>Created</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {investigations.map((inv) => (
                <TableRow
                  key={inv._id}
                  hover
                  sx={{ cursor: 'pointer' }}
                  onClick={() => navigate(`/investigation/${inv._id}`)}
                >
                  <TableCell>
                    <Typography variant="subtitle2">
                      {inv.sfdc_case_id}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={inv.status}
                      color={statusColors[inv.status]}
                    />
                  </TableCell>
                  <TableCell>
                    {inv.confidence_score
                      ? `${Math.round(inv.confidence_score * 100)}%`
                      : '-'}
                  </TableCell>
                  <TableCell>
                    {inv.containers?.length || 0}
                  </TableCell>
                  <TableCell>
                    {inv.created_at
                      ? format(new Date(inv.created_at), 'MMM d, yyyy HH:mm')
                      : '-'}
                  </TableCell>
                  <TableCell align="right">
                    <IconButton
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/investigation/${inv._id}`);
                      }}
                    >
                      <ViewIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
}
