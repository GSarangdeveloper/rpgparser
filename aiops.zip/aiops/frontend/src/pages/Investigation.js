import React from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Tabs,
  Tab,
  CircularProgress,
  Alert,
  Button,
  Chip,
} from '@mui/material';
import { Refresh as RefreshIcon } from '@mui/icons-material';
import { useInvestigation } from '../hooks/useInvestigation';
import InvestigationTimeline from '../components/Investigation/InvestigationTimeline';
import ContainerCard from '../components/Investigation/ContainerCard';
import LogViewer from '../components/Investigation/LogViewer';
import RCAReport from '../components/Investigation/RCAReport';
import FixRecommendation from '../components/Investigation/FixRecommendation';

const statusColors = {
  completed: 'success',
  failed: 'error',
  in_progress: 'primary',
  pending: 'default',
};

export default function Investigation() {
  const { id } = useParams();
  const { investigation, loading, error, streaming, refresh, retry } = useInvestigation(id);
  const [tabValue, setTabValue] = React.useState(0);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ mb: 2 }}>
        {error}
        <Button onClick={refresh} sx={{ ml: 2 }}>
          Retry
        </Button>
      </Alert>
    );
  }

  if (!investigation) {
    return (
      <Alert severity="warning">
        Investigation not found
      </Alert>
    );
  }

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h4" gutterBottom>
            Investigation: {investigation.sfdc_case_id}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Chip
              label={investigation.status}
              color={statusColors[investigation.status]}
            />
            {streaming && (
              <Chip
                icon={<CircularProgress size={16} />}
                label="Live Updates"
                variant="outlined"
                color="primary"
              />
            )}
            {investigation.confidence_score && (
              <Chip
                label={`Confidence: ${Math.round(investigation.confidence_score * 100)}%`}
                variant="outlined"
              />
            )}
          </Box>
        </Box>
        <Box>
          {investigation.status === 'failed' && (
            <Button
              variant="contained"
              color="warning"
              onClick={retry}
              sx={{ mr: 1 }}
            >
              Retry Investigation
            </Button>
          )}
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={refresh}
          >
            Refresh
          </Button>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {/* Timeline */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Investigation Progress
            </Typography>
            <InvestigationTimeline phases={investigation.phases || []} />
          </Paper>
        </Grid>

        {/* Main Content */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ mb: 3 }}>
            <Tabs
              value={tabValue}
              onChange={handleTabChange}
              variant="scrollable"
              scrollButtons="auto"
            >
              <Tab label="Overview" />
              <Tab label="Containers" />
              <Tab label="Logs" />
              <Tab label="RCA Report" />
              <Tab label="Fix Recommendations" />
            </Tabs>
          </Paper>

          {/* Tab Panels */}
          {tabValue === 0 && (
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Investigation Overview
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6} md={3}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Status
                  </Typography>
                  <Typography variant="body1">{investigation.status}</Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Containers Found
                  </Typography>
                  <Typography variant="body1">
                    {investigation.containers?.length || 0}
                  </Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Log Entries
                  </Typography>
                  <Typography variant="body1">
                    {investigation.log_entries?.length || 0}
                  </Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Fixes Proposed
                  </Typography>
                  <Typography variant="body1">
                    {investigation.fix_recommendations?.length || 0}
                  </Typography>
                </Grid>
              </Grid>

              {investigation.rca_report?.executive_summary && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Executive Summary
                  </Typography>
                  <Typography variant="body1">
                    {investigation.rca_report.executive_summary}
                  </Typography>
                </Box>
              )}
            </Paper>
          )}

          {tabValue === 1 && (
            <Box>
              {investigation.containers?.length > 0 ? (
                investigation.containers.map((container, index) => (
                  <ContainerCard
                    key={index}
                    container={container}
                    isPrimary={index === 0}
                  />
                ))
              ) : (
                <Alert severity="info">
                  No containers identified yet
                </Alert>
              )}
            </Box>
          )}

          {tabValue === 2 && (
            <LogViewer logs={investigation.log_entries || []} />
          )}

          {tabValue === 3 && (
            <RCAReport report={investigation.rca_report} summary={investigation.rca_summary} />
          )}

          {tabValue === 4 && (
            <FixRecommendation fixes={investigation.fix_recommendations || []} />
          )}
        </Grid>
      </Grid>
    </Box>
  );
}
