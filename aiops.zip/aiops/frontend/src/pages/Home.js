import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Alert,
  Grid,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Chip,
  CircularProgress,
  ToggleButtonGroup,
  ToggleButton,
  Tooltip,
} from '@mui/material';
import {
  Search as SearchIcon,
  ArrowForward as ArrowForwardIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  HourglassEmpty as PendingIcon,
  Badge as CaseIcon,
  TextFields as TextIcon,
} from '@mui/icons-material';
import { useInvestigationList } from '../hooks/useInvestigation';
import { format } from 'date-fns';

const statusIcons = {
  completed: <CheckCircleIcon color="success" />,
  failed: <ErrorIcon color="error" />,
  in_progress: <CircularProgress size={20} />,
  pending: <PendingIcon color="disabled" />,
};

const statusColors = {
  completed: 'success',
  failed: 'error',
  in_progress: 'primary',
  pending: 'default',
};

const searchTypeColors = {
  sfdc_case_id: 'primary',
  error_message: 'error',
  correlation_id: 'info',
  generic: 'default',
};

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchMode, setSearchMode] = useState('auto'); // 'auto', 'sfdc', 'generic'
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { investigations, loading, startInvestigation } = useInvestigationList();
  const navigate = useNavigate();

  const detectSearchType = (term) => {
    const cleaned = term.trim();
    if (!cleaned) return null;

    // SFDC Case ID pattern
    if (cleaned.length >= 15 && cleaned.length <= 18 && /^[a-zA-Z0-9]+$/.test(cleaned) && cleaned.startsWith('500')) {
      return 'sfdc_case_id';
    }

    // UUID pattern
    if (/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(cleaned)) {
      return 'correlation_id';
    }

    // Error keywords
    const errorKeywords = ['error', 'exception', 'failed', 'timeout', 'null', 'undefined'];
    if (errorKeywords.some(kw => cleaned.toLowerCase().includes(kw))) {
      return 'error_message';
    }

    return 'generic';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const cleanTerm = searchTerm.trim();
    if (!cleanTerm) {
      setError('Please enter a search term');
      return;
    }

    if (cleanTerm.length < 3) {
      setError('Search term must be at least 3 characters');
      return;
    }

    // If SFDC mode is selected, validate the format
    if (searchMode === 'sfdc') {
      if (cleanTerm.length !== 15 && cleanTerm.length !== 18) {
        setError('Salesforce Case ID must be 15 or 18 characters');
        return;
      }
      if (!/^[a-zA-Z0-9]+$/.test(cleanTerm)) {
        setError('Salesforce Case ID must be alphanumeric');
        return;
      }
    }

    setSubmitting(true);
    try {
      const result = await startInvestigation(cleanTerm);
      navigate(`/investigation/${result.investigation_id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const detectedType = detectSearchType(searchTerm);
  const recentInvestigations = investigations.slice(0, 5);

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Start Investigation
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        Search across all GCP logs to investigate issues and find root causes
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  New Investigation
                </Typography>
                <ToggleButtonGroup
                  size="small"
                  value={searchMode}
                  exclusive
                  onChange={(e, v) => v && setSearchMode(v)}
                >
                  <ToggleButton value="auto">
                    <Tooltip title="Auto-detect search type">
                      <SearchIcon fontSize="small" />
                    </Tooltip>
                  </ToggleButton>
                  <ToggleButton value="sfdc">
                    <Tooltip title="Salesforce Case ID">
                      <CaseIcon fontSize="small" />
                    </Tooltip>
                  </ToggleButton>
                  <ToggleButton value="generic">
                    <Tooltip title="Generic text search">
                      <TextIcon fontSize="small" />
                    </Tooltip>
                  </ToggleButton>
                </ToggleButtonGroup>
              </Box>

              {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {error}
                </Alert>
              )}

              <form onSubmit={handleSubmit}>
                <TextField
                  fullWidth
                  label={searchMode === 'sfdc' ? 'Salesforce Case ID' : 'Search Term'}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder={
                    searchMode === 'sfdc'
                      ? 'e.g., 5008c00002AbCdE'
                      : 'Error message, Case ID, correlation ID, or any text...'
                  }
                  margin="normal"
                  multiline={searchMode === 'generic'}
                  rows={searchMode === 'generic' ? 2 : 1}
                  helperText={
                    searchMode === 'sfdc'
                      ? 'Enter 15 or 18 character Salesforce Case ID'
                      : 'Enter any text to search across all logs'
                  }
                  InputProps={{
                    startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />,
                  }}
                />

                {searchTerm && searchMode === 'auto' && detectedType && (
                  <Box sx={{ mt: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="caption" color="text.secondary">
                      Detected type:
                    </Typography>
                    <Chip
                      size="small"
                      label={detectedType.replace('_', ' ')}
                      color={searchTypeColors[detectedType]}
                    />
                  </Box>
                )}

                <Button
                  fullWidth
                  type="submit"
                  variant="contained"
                  size="large"
                  disabled={submitting || !searchTerm.trim()}
                  sx={{ mt: 2 }}
                >
                  {submitting ? 'Starting Investigation...' : 'Start Investigation'}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Paper sx={{ p: 2, mt: 3 }}>
            <Typography variant="subtitle2" color="text.secondary" gutterBottom>
              What can you search for?
            </Typography>
            <Box component="ul" sx={{ pl: 2, mb: 0, '& li': { mb: 0.5 } }}>
              <li><strong>Salesforce Case ID</strong> - e.g., 5008c00002AbCdE</li>
              <li><strong>Error messages</strong> - e.g., "NullPointerException"</li>
              <li><strong>Correlation IDs</strong> - e.g., UUID traces</li>
              <li><strong>User IDs</strong> - e.g., user-12345</li>
              <li><strong>Any text</strong> - searches across all logs</li>
            </Box>
          </Paper>

          <Paper sx={{ p: 2, mt: 2 }}>
            <Typography variant="subtitle2" color="text.secondary" gutterBottom>
              Investigation Workflow
            </Typography>
            <Box component="ol" sx={{ pl: 2, mb: 0 }}>
              <li>Query GCP logs for search term</li>
              <li>Identify affected containers</li>
              <li>Extract stack traces and errors</li>
              <li>Analyze code for root cause (if GitHub mapped)</li>
              <li>Generate RCA report</li>
              <li>Propose fix recommendations</li>
            </Box>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recent Investigations
              </Typography>

              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                </Box>
              ) : recentInvestigations.length === 0 ? (
                <Typography variant="body2" color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
                  No investigations yet
                </Typography>
              ) : (
                <List>
                  {recentInvestigations.map((inv) => (
                    <ListItem
                      key={inv._id}
                      sx={{
                        border: 1,
                        borderColor: 'divider',
                        borderRadius: 1,
                        mb: 1,
                      }}
                    >
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                            {statusIcons[inv.status]}
                            <Typography variant="subtitle2" sx={{ wordBreak: 'break-all' }}>
                              {(inv.search_term || inv.sfdc_case_id || '').substring(0, 50)}
                              {(inv.search_term || inv.sfdc_case_id || '').length > 50 ? '...' : ''}
                            </Typography>
                            <Chip
                              size="small"
                              label={inv.status}
                              color={statusColors[inv.status]}
                            />
                            {inv.search_type && (
                              <Chip
                                size="small"
                                label={inv.search_type.replace('_', ' ')}
                                variant="outlined"
                                color={searchTypeColors[inv.search_type]}
                              />
                            )}
                          </Box>
                        }
                        secondary={
                          inv.created_at
                            ? format(new Date(inv.created_at), 'MMM d, yyyy HH:mm')
                            : 'Unknown date'
                        }
                      />
                      <ListItemSecondaryAction>
                        <IconButton
                          edge="end"
                          onClick={() => navigate(`/investigation/${inv._id}`)}
                        >
                          <ArrowForwardIcon />
                        </IconButton>
                      </ListItemSecondaryAction>
                    </ListItem>
                  ))}
                </List>
              )}

              {investigations.length > 5 && (
                <Button
                  fullWidth
                  onClick={() => navigate('/history')}
                  sx={{ mt: 2 }}
                >
                  View All Investigations
                </Button>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
