import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  Grid,
  LinearProgress,
  Divider,
} from '@mui/material';
import {
  Storage as ContainerIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
} from '@mui/icons-material';

export default function ContainerCard({ container, isPrimary = false }) {
  const score = container.score || 0;
  const maxScore = 100;
  const scorePercentage = Math.min((score / maxScore) * 100, 100);

  return (
    <Card
      sx={{
        mb: 2,
        border: isPrimary ? 2 : 1,
        borderColor: isPrimary ? 'primary.main' : 'divider',
      }}
    >
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <ContainerIcon color={isPrimary ? 'primary' : 'action'} />
            <Typography variant="h6">
              {container.container_name || container.name || 'Unknown Container'}
            </Typography>
            {isPrimary && (
              <Chip label="Primary" color="primary" size="small" />
            )}
          </Box>
          {container.score !== undefined && (
            <Chip
              label={`Score: ${Math.round(score)}`}
              variant="outlined"
              size="small"
            />
          )}
        </Box>

        <Grid container spacing={2}>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" color="text.secondary" display="block">
              Namespace
            </Typography>
            <Typography variant="body2">
              {container.namespace || '-'}
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" color="text.secondary" display="block">
              Pod
            </Typography>
            <Typography variant="body2" sx={{ wordBreak: 'break-all' }}>
              {container.pod_name || container.pod || '-'}
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <ErrorIcon color="error" fontSize="small" />
              <Typography variant="caption" color="text.secondary">
                Errors
              </Typography>
            </Box>
            <Typography variant="h6" color="error.main">
              {container.error_count || 0}
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <WarningIcon color="warning" fontSize="small" />
              <Typography variant="caption" color="text.secondary">
                Warnings
              </Typography>
            </Box>
            <Typography variant="h6" color="warning.main">
              {container.warning_count || 0}
            </Typography>
          </Grid>
        </Grid>

        {container.score !== undefined && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="caption" color="text.secondary">
              Issue Likelihood Score
            </Typography>
            <LinearProgress
              variant="determinate"
              value={scorePercentage}
              color={isPrimary ? 'primary' : 'inherit'}
              sx={{ height: 8, borderRadius: 1, mt: 0.5 }}
            />
          </Box>
        )}

        {container.score_breakdown && (
          <>
            <Divider sx={{ my: 2 }} />
            <Typography variant="caption" color="text.secondary" gutterBottom display="block">
              Score Breakdown
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {Object.entries(container.score_breakdown).map(([key, value]) => (
                <Chip
                  key={key}
                  label={`${key.replace(/_/g, ' ')}: ${value}`}
                  size="small"
                  variant="outlined"
                />
              ))}
            </Box>
          </>
        )}

        {(container.first_occurrence || container.last_occurrence) && (
          <>
            <Divider sx={{ my: 2 }} />
            <Grid container spacing={2}>
              {container.first_occurrence && (
                <Grid item xs={6}>
                  <Typography variant="caption" color="text.secondary" display="block">
                    First Occurrence
                  </Typography>
                  <Typography variant="body2">
                    {new Date(container.first_occurrence).toLocaleString()}
                  </Typography>
                </Grid>
              )}
              {container.last_occurrence && (
                <Grid item xs={6}>
                  <Typography variant="caption" color="text.secondary" display="block">
                    Last Occurrence
                  </Typography>
                  <Typography variant="body2">
                    {new Date(container.last_occurrence).toLocaleString()}
                  </Typography>
                </Grid>
              )}
            </Grid>
          </>
        )}
      </CardContent>
    </Card>
  );
}
