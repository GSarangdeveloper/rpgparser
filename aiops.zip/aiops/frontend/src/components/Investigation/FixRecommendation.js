import React, { useState } from 'react';
import {
  Paper,
  Box,
  Typography,
  Chip,
  Grid,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  CheckCircle as CheckIcon,
  Code as CodeIcon,
  ContentCopy as CopyIcon,
  Build as BuildIcon,
  Warning as WarningIcon,
  Speed as SpeedIcon,
} from '@mui/icons-material';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { materialLight } from 'react-syntax-highlighter/dist/esm/styles/prism';

const priorityColors = {
  critical: 'error',
  high: 'warning',
  medium: 'info',
  low: 'default',
};

const riskColors = {
  low: 'success',
  medium: 'warning',
  high: 'error',
};

function FixCard({ fix, index }) {
  const [prDialogOpen, setPrDialogOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const codeChange = fix.code_change || {};

  return (
    <Accordion defaultExpanded={index === 0}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%', pr: 2 }}>
          <Chip
            label={fix.id || `FIX-${String(index + 1).padStart(3, '0')}`}
            size="small"
            color="primary"
            variant="outlined"
          />
          <Typography variant="subtitle1" sx={{ flexGrow: 1 }}>
            {fix.title || 'Untitled Fix'}
          </Typography>
          <Chip
            label={fix.priority || 'medium'}
            size="small"
            color={priorityColors[fix.priority] || 'default'}
          />
          <Chip
            label={`Risk: ${fix.risk_level || 'medium'}`}
            size="small"
            color={riskColors[fix.risk_level] || 'warning'}
            variant="outlined"
          />
        </Box>
      </AccordionSummary>
      <AccordionDetails>
        <Typography variant="body1" paragraph>
          {fix.description || 'No description available'}
        </Typography>

        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" color="text.secondary">
              Type
            </Typography>
            <Typography variant="body2">
              {fix.type || 'code_change'}
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" color="text.secondary">
              Estimated Effort
            </Typography>
            <Typography variant="body2">
              {fix.estimated_effort || 'TBD'}
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" color="text.secondary">
              Priority
            </Typography>
            <Chip
              label={fix.priority || 'medium'}
              size="small"
              color={priorityColors[fix.priority] || 'default'}
            />
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" color="text.secondary">
              Risk Level
            </Typography>
            <Chip
              label={fix.risk_level || 'medium'}
              size="small"
              color={riskColors[fix.risk_level] || 'warning'}
            />
          </Grid>
        </Grid>

        {/* Code Change */}
        {codeChange.file && (
          <Box sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
              <Typography variant="subtitle2">
                <CodeIcon fontSize="small" sx={{ mr: 0.5, verticalAlign: 'middle' }} />
                Code Change: {codeChange.file}
              </Typography>
              <Tooltip title={copied ? 'Copied!' : 'Copy code'}>
                <IconButton
                  size="small"
                  onClick={() => handleCopy(codeChange.after || '')}
                >
                  <CopyIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>

            {codeChange.before && (
              <Box sx={{ mb: 1 }}>
                <Typography variant="caption" color="error.main" fontWeight="bold">
                  - Before:
                </Typography>
                <SyntaxHighlighter
                  language="javascript"
                  style={materialLight}
                  customStyle={{
                    margin: 0,
                    borderRadius: 4,
                    fontSize: '0.75rem',
                    backgroundColor: '#ffebee',
                  }}
                >
                  {codeChange.before}
                </SyntaxHighlighter>
              </Box>
            )}

            {codeChange.after && (
              <Box sx={{ mb: 1 }}>
                <Typography variant="caption" color="success.main" fontWeight="bold">
                  + After:
                </Typography>
                <SyntaxHighlighter
                  language="javascript"
                  style={materialLight}
                  customStyle={{
                    margin: 0,
                    borderRadius: 4,
                    fontSize: '0.75rem',
                    backgroundColor: '#e8f5e9',
                  }}
                >
                  {codeChange.after}
                </SyntaxHighlighter>
              </Box>
            )}

            {codeChange.explanation && (
              <Alert severity="info" sx={{ mt: 1 }}>
                {codeChange.explanation}
              </Alert>
            )}
          </Box>
        )}

        {/* Testing Plan */}
        {fix.testing_plan && fix.testing_plan.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              <CheckIcon fontSize="small" sx={{ mr: 0.5, verticalAlign: 'middle' }} />
              Testing Plan
            </Typography>
            <List dense>
              {fix.testing_plan.map((test, i) => (
                <ListItem key={i}>
                  <ListItemIcon>
                    <CheckIcon color="success" fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary={test} />
                </ListItem>
              ))}
            </List>
          </Box>
        )}

        {/* Rollback Plan */}
        {fix.rollback_plan && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              <WarningIcon fontSize="small" sx={{ mr: 0.5, verticalAlign: 'middle', color: 'warning.main' }} />
              Rollback Plan
            </Typography>
            <Alert severity="warning">
              {fix.rollback_plan}
            </Alert>
          </Box>
        )}

        {/* Dependencies */}
        {fix.dependencies && fix.dependencies.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Dependencies
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {fix.dependencies.map((dep, i) => (
                <Chip key={i} label={dep} size="small" variant="outlined" />
              ))}
            </Box>
          </Box>
        )}

        <Divider sx={{ my: 2 }} />

        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button
            variant="outlined"
            size="small"
            startIcon={<CodeIcon />}
            onClick={() => setPrDialogOpen(true)}
          >
            View PR Description
          </Button>
        </Box>

        {/* PR Description Dialog */}
        <Dialog open={prDialogOpen} onClose={() => setPrDialogOpen(false)} maxWidth="md" fullWidth>
          <DialogTitle>
            Pull Request Description
            <IconButton
              onClick={() => handleCopy(generatePRDescription(fix))}
              sx={{ position: 'absolute', right: 8, top: 8 }}
            >
              <CopyIcon />
            </IconButton>
          </DialogTitle>
          <DialogContent>
            <Box
              component="pre"
              sx={{
                whiteSpace: 'pre-wrap',
                fontFamily: 'monospace',
                fontSize: '0.8rem',
                bgcolor: 'grey.100',
                p: 2,
                borderRadius: 1,
              }}
            >
              {generatePRDescription(fix)}
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setPrDialogOpen(false)}>Close</Button>
            <Button
              variant="contained"
              onClick={() => handleCopy(generatePRDescription(fix))}
            >
              Copy to Clipboard
            </Button>
          </DialogActions>
        </Dialog>
      </AccordionDetails>
    </Accordion>
  );
}

function generatePRDescription(fix) {
  const codeChange = fix.code_change || {};
  return `## Summary
${fix.description || 'No description provided'}

## Root Cause
${codeChange.explanation || 'See RCA report for details'}

## Changes Made
- **File**: \`${codeChange.file || 'TBD'}\`
- **Type**: ${fix.type || 'code_change'}

## Testing Plan
${(fix.testing_plan || ['Manual testing required']).map(t => `- [ ] ${t}`).join('\n')}

## Risk Assessment
- **Risk Level**: ${fix.risk_level || 'medium'}
- **Rollback Plan**: ${fix.rollback_plan || 'Revert this commit'}

## Related
- Priority: ${fix.priority || 'medium'}
- Estimated Effort: ${fix.estimated_effort || 'TBD'}
`;
}

export default function FixRecommendation({ fixes = [] }) {
  if (fixes.length === 0) {
    return (
      <Alert severity="info">
        No fix recommendations available yet. The investigation may still be in progress.
      </Alert>
    );
  }

  // Calculate overall risk
  const riskCounts = fixes.reduce((acc, fix) => {
    const risk = fix.risk_level || 'medium';
    acc[risk] = (acc[risk] || 0) + 1;
    return acc;
  }, {});

  return (
    <Box>
      {/* Summary Card */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={4}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <BuildIcon color="primary" />
              <Typography variant="h6">
                {fixes.length} Fix{fixes.length !== 1 ? 'es' : ''} Recommended
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={8}>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              {riskCounts.low && (
                <Chip
                  label={`${riskCounts.low} Low Risk`}
                  color="success"
                  size="small"
                />
              )}
              {riskCounts.medium && (
                <Chip
                  label={`${riskCounts.medium} Medium Risk`}
                  color="warning"
                  size="small"
                />
              )}
              {riskCounts.high && (
                <Chip
                  label={`${riskCounts.high} High Risk`}
                  color="error"
                  size="small"
                />
              )}
            </Box>
          </Grid>
        </Grid>
      </Paper>

      {/* Implementation Order Notice */}
      <Alert severity="info" sx={{ mb: 2 }} icon={<SpeedIcon />}>
        Fixes are ordered by priority and risk. Implement in the order shown for best results.
      </Alert>

      {/* Fix Cards */}
      {fixes.map((fix, index) => (
        <FixCard key={fix.id || index} fix={fix} index={index} />
      ))}
    </Box>
  );
}
