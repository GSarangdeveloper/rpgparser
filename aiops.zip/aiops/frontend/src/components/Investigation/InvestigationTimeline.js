import React from 'react';
import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
  TimelineOppositeContent,
} from '@mui/lab';
import { Typography, Box } from '@mui/material';
import {
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  HourglassEmpty as PendingIcon,
  PlayArrow as InProgressIcon,
} from '@mui/icons-material';
import { format } from 'date-fns';

const phaseLabels = {
  query_construction: 'Query Construction',
  log_retrieval: 'Log Retrieval',
  log_parsing: 'Log Parsing',
  container_identification: 'Container Identification',
  code_analysis: 'Code Analysis',
  rca_synthesis: 'RCA Synthesis',
  fix_generation: 'Fix Generation',
};

const statusConfig = {
  completed: {
    icon: <CheckCircleIcon />,
    color: 'success',
  },
  failed: {
    icon: <ErrorIcon />,
    color: 'error',
  },
  in_progress: {
    icon: <InProgressIcon />,
    color: 'primary',
  },
  pending: {
    icon: <PendingIcon />,
    color: 'grey',
  },
};

export default function InvestigationTimeline({ phases = [] }) {
  // Create a map of phases by name
  const phaseMap = {};
  phases.forEach((phase) => {
    phaseMap[phase.name] = phase;
  });

  // Define all phases in order
  const allPhases = [
    'query_construction',
    'log_retrieval',
    'log_parsing',
    'container_identification',
    'code_analysis',
    'rca_synthesis',
    'fix_generation',
  ];

  return (
    <Timeline position="right" sx={{ p: 0 }}>
      {allPhases.map((phaseName, index) => {
        const phase = phaseMap[phaseName];
        const status = phase?.status || 'pending';
        const config = statusConfig[status];

        return (
          <TimelineItem key={phaseName}>
            <TimelineOppositeContent sx={{ flex: 0.3, py: 1 }}>
              {phase?.completed_at && (
                <Typography variant="caption" color="text.secondary">
                  {format(new Date(phase.completed_at), 'HH:mm:ss')}
                </Typography>
              )}
            </TimelineOppositeContent>
            <TimelineSeparator>
              <TimelineDot color={config.color} variant={status === 'pending' ? 'outlined' : 'filled'}>
                {config.icon}
              </TimelineDot>
              {index < allPhases.length - 1 && <TimelineConnector />}
            </TimelineSeparator>
            <TimelineContent sx={{ py: 1 }}>
              <Typography variant="subtitle2">
                {phaseLabels[phaseName]}
              </Typography>
              {phase?.result_summary && (
                <Box sx={{ mt: 0.5 }}>
                  {phase.result_summary.queries_generated && (
                    <Typography variant="caption" display="block" color="text.secondary">
                      {phase.result_summary.queries_generated} queries generated
                    </Typography>
                  )}
                  {phase.result_summary.log_entries !== undefined && (
                    <Typography variant="caption" display="block" color="text.secondary">
                      {phase.result_summary.log_entries} log entries
                    </Typography>
                  )}
                  {phase.result_summary.containers_found !== undefined && (
                    <Typography variant="caption" display="block" color="text.secondary">
                      {phase.result_summary.containers_found} containers found
                    </Typography>
                  )}
                  {phase.result_summary.primary_container && (
                    <Typography variant="caption" display="block" color="text.secondary">
                      Primary: {phase.result_summary.primary_container}
                    </Typography>
                  )}
                  {phase.result_summary.fixes_generated !== undefined && (
                    <Typography variant="caption" display="block" color="text.secondary">
                      {phase.result_summary.fixes_generated} fixes proposed
                    </Typography>
                  )}
                </Box>
              )}
              {phase?.error && (
                <Typography variant="caption" color="error">
                  Error: {phase.error}
                </Typography>
              )}
            </TimelineContent>
          </TimelineItem>
        );
      })}
    </Timeline>
  );
}
