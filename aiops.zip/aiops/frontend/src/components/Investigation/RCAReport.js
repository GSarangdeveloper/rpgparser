import React from 'react';
import {
  Paper,
  Box,
  Typography,
  Chip,
  Grid,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Alert,
  LinearProgress,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  CheckCircle as CheckIcon,
  RadioButtonUnchecked as PendingIcon,
  Timeline as TimelineIcon,
  BugReport as BugIcon,
  Security as SecurityIcon,
  Build as BuildIcon,
  School as LearnIcon,
} from '@mui/icons-material';

function Section({ title, icon, children, defaultExpanded = true }) {
  return (
    <Accordion defaultExpanded={defaultExpanded}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {icon}
          <Typography variant="subtitle1" fontWeight="medium">
            {title}
          </Typography>
        </Box>
      </AccordionSummary>
      <AccordionDetails>{children}</AccordionDetails>
    </Accordion>
  );
}

export default function RCAReport({ report, summary }) {
  if (!report) {
    return (
      <Alert severity="info">
        RCA report not yet available. The investigation may still be in progress.
      </Alert>
    );
  }

  const confidenceLevel = report.root_cause?.confidence || 0;
  const confidencePercent = Math.round(confidenceLevel * 100);

  return (
    <Box>
      {/* Executive Summary Card */}
      <Paper sx={{ p: 3, mb: 3, bgcolor: 'primary.50' }}>
        <Typography variant="h6" gutterBottom color="primary">
          Executive Summary
        </Typography>
        <Typography variant="body1">
          {report.executive_summary || 'No summary available'}
        </Typography>
      </Paper>

      {/* Confidence Indicator */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
          Root Cause Confidence
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <LinearProgress
            variant="determinate"
            value={confidencePercent}
            sx={{ flexGrow: 1, height: 10, borderRadius: 1 }}
            color={confidencePercent > 75 ? 'success' : confidencePercent > 50 ? 'warning' : 'error'}
          />
          <Typography variant="h6">{confidencePercent}%</Typography>
        </Box>
      </Paper>

      {/* Problem Statement */}
      <Section title="Problem Statement" icon={<BugIcon color="error" />}>
        <Typography variant="body1">
          {report.problem_statement || 'Not determined'}
        </Typography>
      </Section>

      {/* Root Cause */}
      <Section title="Root Cause" icon={<SecurityIcon color="warning" />}>
        <Typography variant="body1" paragraph>
          {report.root_cause?.description || 'Not determined'}
        </Typography>

        {report.root_cause?.evidence && report.root_cause.evidence.length > 0 && (
          <>
            <Typography variant="subtitle2" gutterBottom>
              Evidence:
            </Typography>
            <List dense>
              {report.root_cause.evidence.map((item, index) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    <CheckIcon color="success" fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary={item} />
                </ListItem>
              ))}
            </List>
          </>
        )}
      </Section>

      {/* Impact Assessment */}
      {report.impact && (
        <Section title="Impact Assessment" icon={<TimelineIcon color="info" />}>
          <Grid container spacing={2}>
            <Grid item xs={6} md={3}>
              <Typography variant="caption" color="text.secondary">
                Severity
              </Typography>
              <Box>
                <Chip
                  label={report.impact.severity || 'Unknown'}
                  color={
                    report.impact.severity === 'critical' ? 'error' :
                    report.impact.severity === 'high' ? 'warning' :
                    report.impact.severity === 'medium' ? 'info' : 'default'
                  }
                />
              </Box>
            </Grid>
            <Grid item xs={6} md={3}>
              <Typography variant="caption" color="text.secondary">
                Duration
              </Typography>
              <Typography variant="body1">
                {report.impact.duration || 'Unknown'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="caption" color="text.secondary">
                Affected Users
              </Typography>
              <Typography variant="body1">
                {report.impact.affected_users || 'Unknown'}
              </Typography>
            </Grid>
          </Grid>

          {report.impact.affected_services && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="caption" color="text.secondary">
                Affected Services:
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                {report.impact.affected_services.map((service, index) => (
                  <Chip key={index} label={service} size="small" variant="outlined" />
                ))}
              </Box>
            </Box>
          )}
        </Section>
      )}

      {/* Timeline */}
      {report.timeline && report.timeline.length > 0 && (
        <Section title="Timeline" icon={<TimelineIcon />} defaultExpanded={false}>
          <List dense>
            {report.timeline.map((event, index) => (
              <ListItem key={index}>
                <ListItemIcon>
                  <Typography variant="caption" color="text.secondary" sx={{ minWidth: 80 }}>
                    {event.time}
                  </Typography>
                </ListItemIcon>
                <ListItemText
                  primary={event.event}
                  secondary={event.significance}
                />
              </ListItem>
            ))}
          </List>
        </Section>
      )}

      {/* Contributing Factors */}
      {report.contributing_factors && report.contributing_factors.length > 0 && (
        <Section title="Contributing Factors" icon={<BugIcon />} defaultExpanded={false}>
          <List>
            {report.contributing_factors.map((factor, index) => (
              <ListItem key={index}>
                <ListItemText
                  primary={factor.factor}
                  secondary={factor.how_it_contributed}
                />
              </ListItem>
            ))}
          </List>
        </Section>
      )}

      {/* Immediate Actions */}
      {report.immediate_actions && report.immediate_actions.length > 0 && (
        <Section title="Immediate Actions Required" icon={<BuildIcon color="error" />}>
          <List>
            {report.immediate_actions.map((action, index) => (
              <ListItem key={index}>
                <ListItemIcon>
                  <PendingIcon color="warning" />
                </ListItemIcon>
                <ListItemText primary={action} />
              </ListItem>
            ))}
          </List>
        </Section>
      )}

      {/* Long-term Remediation */}
      {report.long_term_remediation && report.long_term_remediation.length > 0 && (
        <Section title="Long-term Remediation" icon={<BuildIcon />} defaultExpanded={false}>
          <List>
            {report.long_term_remediation.map((item, index) => (
              <ListItem key={index}>
                <ListItemIcon>
                  <Chip
                    label={item.priority}
                    size="small"
                    color={item.priority === 'high' ? 'error' : item.priority === 'medium' ? 'warning' : 'default'}
                  />
                </ListItemIcon>
                <ListItemText
                  primary={item.action}
                  secondary={`Owner: ${item.owner || 'TBD'}`}
                />
              </ListItem>
            ))}
          </List>
        </Section>
      )}

      {/* Prevention Measures */}
      {report.prevention_measures && report.prevention_measures.length > 0 && (
        <Section title="Prevention Measures" icon={<SecurityIcon />} defaultExpanded={false}>
          <List dense>
            {report.prevention_measures.map((measure, index) => (
              <ListItem key={index}>
                <ListItemIcon>
                  <CheckIcon color="success" fontSize="small" />
                </ListItemIcon>
                <ListItemText primary={measure} />
              </ListItem>
            ))}
          </List>
        </Section>
      )}

      {/* Lessons Learned */}
      {report.lessons_learned && report.lessons_learned.length > 0 && (
        <Section title="Lessons Learned" icon={<LearnIcon />} defaultExpanded={false}>
          <List dense>
            {report.lessons_learned.map((lesson, index) => (
              <ListItem key={index}>
                <ListItemIcon>
                  <LearnIcon color="info" fontSize="small" />
                </ListItemIcon>
                <ListItemText primary={lesson} />
              </ListItem>
            ))}
          </List>
        </Section>
      )}

      {/* Raw Summary */}
      {summary && (
        <Section title="Full Report Text" icon={<TimelineIcon />} defaultExpanded={false}>
          <Box
            component="pre"
            sx={{
              whiteSpace: 'pre-wrap',
              fontFamily: 'monospace',
              fontSize: '0.75rem',
              bgcolor: 'grey.100',
              p: 2,
              borderRadius: 1,
              overflow: 'auto',
            }}
          >
            {summary}
          </Box>
        </Section>
      )}
    </Box>
  );
}
