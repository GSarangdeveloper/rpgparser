import React, { useState } from 'react';
import {
  Paper,
  Box,
  Typography,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Collapse,
  Alert,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
} from '@mui/icons-material';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { materialLight } from 'react-syntax-highlighter/dist/esm/styles/prism';

const severityConfig = {
  ERROR: { icon: <ErrorIcon fontSize="small" />, color: 'error' },
  WARNING: { icon: <WarningIcon fontSize="small" />, color: 'warning' },
  INFO: { icon: <InfoIcon fontSize="small" />, color: 'info' },
  DEBUG: { icon: <InfoIcon fontSize="small" />, color: 'default' },
};

function LogRow({ log, expanded, onToggle }) {
  const severity = log.severity || 'INFO';
  const config = severityConfig[severity] || severityConfig.INFO;
  const payload = log.payload || log.message || '';
  const payloadStr = typeof payload === 'object' ? JSON.stringify(payload, null, 2) : String(payload);

  return (
    <>
      <TableRow
        hover
        onClick={onToggle}
        sx={{ cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' } }}
      >
        <TableCell padding="checkbox">
          <IconButton size="small">
            {expanded ? <ExpandLessIcon /> : <ExpandMoreIcon />}
          </IconButton>
        </TableCell>
        <TableCell>
          <Typography variant="caption" sx={{ fontFamily: 'monospace' }}>
            {log.timestamp ? new Date(log.timestamp).toLocaleTimeString() : '-'}
          </Typography>
        </TableCell>
        <TableCell>
          <Chip
            icon={config.icon}
            label={severity}
            size="small"
            color={config.color}
            variant="outlined"
          />
        </TableCell>
        <TableCell>
          <Typography variant="caption">
            {log.resource?.labels?.container_name || '-'}
          </Typography>
        </TableCell>
        <TableCell>
          <Typography
            variant="body2"
            sx={{
              fontFamily: 'monospace',
              fontSize: '0.75rem',
              maxWidth: 400,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
          >
            {payloadStr.substring(0, 100)}
            {payloadStr.length > 100 ? '...' : ''}
          </Typography>
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell colSpan={5} sx={{ p: 0, borderBottom: expanded ? 1 : 0 }}>
          <Collapse in={expanded}>
            <Box sx={{ p: 2, bgcolor: 'grey.50' }}>
              <Typography variant="subtitle2" gutterBottom>
                Full Log Entry
              </Typography>
              <SyntaxHighlighter
                language="json"
                style={materialLight}
                customStyle={{
                  margin: 0,
                  borderRadius: 4,
                  fontSize: '0.75rem',
                }}
              >
                {JSON.stringify(log, null, 2)}
              </SyntaxHighlighter>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </>
  );
}

export default function LogViewer({ logs = [] }) {
  const [filter, setFilter] = useState('');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [expandedRows, setExpandedRows] = useState(new Set());

  const toggleRow = (index) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedRows(newExpanded);
  };

  const filteredLogs = logs.filter((log) => {
    // Severity filter
    if (severityFilter !== 'all' && log.severity !== severityFilter) {
      return false;
    }

    // Text filter
    if (filter) {
      const payloadStr = typeof log.payload === 'object'
        ? JSON.stringify(log.payload)
        : String(log.payload || '');
      const containerName = log.resource?.labels?.container_name || '';

      return (
        payloadStr.toLowerCase().includes(filter.toLowerCase()) ||
        containerName.toLowerCase().includes(filter.toLowerCase())
      );
    }

    return true;
  });

  if (logs.length === 0) {
    return (
      <Alert severity="info">
        No log entries available
      </Alert>
    );
  }

  return (
    <Paper sx={{ p: 2 }}>
      <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
        <TextField
          size="small"
          label="Filter logs"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          sx={{ flexGrow: 1 }}
        />
        <FormControl size="small" sx={{ minWidth: 120 }}>
          <InputLabel>Severity</InputLabel>
          <Select
            value={severityFilter}
            label="Severity"
            onChange={(e) => setSeverityFilter(e.target.value)}
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="ERROR">Error</MenuItem>
            <MenuItem value="WARNING">Warning</MenuItem>
            <MenuItem value="INFO">Info</MenuItem>
            <MenuItem value="DEBUG">Debug</MenuItem>
          </Select>
        </FormControl>
      </Box>

      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Showing {filteredLogs.length} of {logs.length} entries
      </Typography>

      <TableContainer sx={{ maxHeight: 600 }}>
        <Table stickyHeader size="small">
          <TableHead>
            <TableRow>
              <TableCell padding="checkbox" />
              <TableCell>Time</TableCell>
              <TableCell>Severity</TableCell>
              <TableCell>Container</TableCell>
              <TableCell>Message</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredLogs.slice(0, 100).map((log, index) => (
              <LogRow
                key={log.insert_id || index}
                log={log}
                expanded={expandedRows.has(index)}
                onToggle={() => toggleRow(index)}
              />
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {filteredLogs.length > 100 && (
        <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
          Showing first 100 entries. Use filters to narrow down results.
        </Typography>
      )}
    </Paper>
  );
}
