import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add API key from localStorage if available
const apiKey = localStorage.getItem('apiKey');
if (apiKey) {
  api.defaults.headers.common['X-API-Key'] = apiKey;
}

// Investigation API
export const investigationApi = {
  // Start investigation with any search term (SFDC ID, error message, etc.)
  start: (searchTerm) =>
    api.post('/api/investigation/start', { search_term: searchTerm }),

  get: (investigationId) =>
    api.get(`/api/investigation/${investigationId}`),

  list: (params = {}) =>
    api.get('/api/investigation/', { params }),

  retry: (investigationId) =>
    api.post(`/api/investigation/${investigationId}/retry`),

  // SSE stream for real-time updates
  stream: (investigationId) => {
    const eventSource = new EventSource(
      `${api.defaults.baseURL}/api/investigation/${investigationId}/stream`
    );
    return eventSource;
  },
};

// Container Mappings API (for managing container-to-GitHub repo mappings)
export const mappingsApi = {
  list: () => api.get('/api/mappings/'),

  get: (containerName) => api.get(`/api/mappings/${containerName}`),

  create: (mapping) => api.post('/api/mappings/', mapping),

  update: (containerName, mapping) =>
    api.put(`/api/mappings/${containerName}`, mapping),

  delete: (containerName) => api.delete(`/api/mappings/${containerName}`),

  bulkImport: (mappings) => api.post('/api/mappings/bulk', { mappings }),
};

// Health check
export const healthApi = {
  check: () => api.get('/api/health'),
  ready: () => api.get('/api/ready'),
};

export default api;
