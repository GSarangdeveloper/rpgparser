# Database Schema Design

## Overview
The IQTOP platform uses a **hybrid database approach**:
- **PostgreSQL**: Relational data (users, workflows, test results)
- **MongoDB**: Unstructured data (LLM responses, audit logs)
- **MinIO/S3**: Binary data (screenshots, videos, reports)

---

## PostgreSQL Schema

### Complete DDL

```sql
-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Custom types
CREATE TYPE user_role AS ENUM ('admin', 'tester', 'viewer');
CREATE TYPE test_type AS ENUM ('ui', 'api', 'legacy', 'standalone');
CREATE TYPE workflow_status AS ENUM (
    'pending',
    'phase_1_generating',
    'phase_2_awaiting_review',
    'phase_3_executing',
    'phase_4_defects',
    'phase_5_scripts',
    'phase_6_reporting',
    'phase_7_regression',
    'phase_8_committing',
    'completed',
    'failed',
    'cancelled'
);
CREATE TYPE artifact_type AS ENUM (
    'script', 'report', 'screenshot', 'video', 'trace', 'document'
);

-- ============================================================================
-- USERS & AUTHENTICATION
-- ============================================================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    role user_role DEFAULT 'tester' NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

COMMENT ON TABLE users IS 'Application users with role-based access control';

-- ============================================================================
-- PROJECTS
-- ============================================================================

CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    github_repo_url VARCHAR(500),
    rally_project_id VARCHAR(100),
    jira_project_key VARCHAR(50),
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_archived BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_projects_created_by ON projects(created_by);
CREATE INDEX idx_projects_name ON projects(name);
CREATE INDEX idx_projects_archived ON projects(is_archived);

COMMENT ON TABLE projects IS 'Testing projects that contain workflows';

-- ============================================================================
-- WORKFLOWS
-- ============================================================================

CREATE TABLE workflows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
    test_type test_type NOT NULL,
    status workflow_status DEFAULT 'pending' NOT NULL,
    current_phase INTEGER DEFAULT 1,
    input_data JSONB NOT NULL,
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    duration_ms INTEGER GENERATED ALWAYS AS (
        CASE
            WHEN completed_at IS NOT NULL AND started_at IS NOT NULL
            THEN EXTRACT(EPOCH FROM (completed_at - started_at)) * 1000
            ELSE NULL
        END
    ) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_workflows_project ON workflows(project_id);
CREATE INDEX idx_workflows_status ON workflows(status);
CREATE INDEX idx_workflows_test_type ON workflows(test_type);
CREATE INDEX idx_workflows_created_by ON workflows(created_by);
CREATE INDEX idx_workflows_created_at ON workflows(created_at DESC);
CREATE INDEX idx_workflows_completed_at ON workflows(completed_at DESC) WHERE completed_at IS NOT NULL;

COMMENT ON TABLE workflows IS 'Main workflow instances tracking 8-phase execution';
COMMENT ON COLUMN workflows.input_data IS 'JSON containing Figma URL, Rally story, etc.';

-- ============================================================================
-- WORKFLOW PHASES (Audit Trail)
-- ============================================================================

CREATE TABLE workflow_phases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE NOT NULL,
    phase_number INTEGER NOT NULL CHECK (phase_number BETWEEN 1 AND 8),
    phase_name VARCHAR(100) NOT NULL,
    agent_name VARCHAR(100),
    status VARCHAR(50) DEFAULT 'pending',
    input_data JSONB,
    output_data JSONB,
    error_message TEXT,
    error_stack_trace TEXT,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    duration_ms INTEGER GENERATED ALWAYS AS (
        CASE
            WHEN completed_at IS NOT NULL AND started_at IS NOT NULL
            THEN EXTRACT(EPOCH FROM (completed_at - started_at)) * 1000
            ELSE NULL
        END
    ) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_workflow_phases_workflow ON workflow_phases(workflow_id);
CREATE INDEX idx_workflow_phases_phase ON workflow_phases(phase_number);
CREATE INDEX idx_workflow_phases_agent ON workflow_phases(agent_name);

COMMENT ON TABLE workflow_phases IS 'Detailed execution log for each phase of a workflow';

-- ============================================================================
-- TEST SCENARIOS
-- ============================================================================

CREATE TABLE test_scenarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE NOT NULL,
    scenario_json JSONB NOT NULL,
    approved BOOLEAN DEFAULT FALSE,
    approved_by UUID REFERENCES users(id) ON DELETE SET NULL,
    approved_at TIMESTAMP,
    edited BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_test_scenarios_workflow ON test_scenarios(workflow_id);
CREATE INDEX idx_test_scenarios_approved ON test_scenarios(approved);

COMMENT ON TABLE test_scenarios IS 'LLM-generated test scenarios awaiting or approved';
COMMENT ON COLUMN test_scenarios.scenario_json IS 'Full JSON with test steps, expected results';

-- ============================================================================
-- TEST EXECUTIONS
-- ============================================================================

CREATE TABLE test_executions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE NOT NULL,
    scenario_id UUID REFERENCES test_scenarios(id) ON DELETE SET NULL,
    test_name VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL CHECK (status IN ('passed', 'failed', 'skipped', 'flaky')),
    execution_time_ms INTEGER,
    browser VARCHAR(50),
    error_message TEXT,
    stack_trace TEXT,
    screenshot_url VARCHAR(500),
    video_url VARCHAR(500),
    trace_url VARCHAR(500),
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_test_executions_workflow ON test_executions(workflow_id);
CREATE INDEX idx_test_executions_scenario ON test_executions(scenario_id);
CREATE INDEX idx_test_executions_status ON test_executions(status);
CREATE INDEX idx_test_executions_test_name ON test_executions(test_name);
CREATE INDEX idx_test_executions_executed_at ON test_executions(executed_at DESC);

COMMENT ON TABLE test_executions IS 'Individual test execution results from Playwright/pytest';

-- ============================================================================
-- ARTIFACTS
-- ============================================================================

CREATE TABLE artifacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE NOT NULL,
    artifact_type artifact_type NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    storage_url VARCHAR(500) NOT NULL,
    file_size_bytes BIGINT,
    mime_type VARCHAR(100),
    checksum VARCHAR(64),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_artifacts_workflow ON artifacts(workflow_id);
CREATE INDEX idx_artifacts_type ON artifacts(artifact_type);

COMMENT ON TABLE artifacts IS 'Metadata for files stored in MinIO/S3';

-- ============================================================================
-- GITHUB COMMITS
-- ============================================================================

CREATE TABLE github_commits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE NOT NULL,
    commit_sha VARCHAR(40) NOT NULL,
    branch_name VARCHAR(255) NOT NULL,
    pr_url VARCHAR(500),
    pr_number INTEGER,
    pr_status VARCHAR(50) DEFAULT 'open',
    committed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_github_commits_workflow ON github_commits(workflow_id);
CREATE INDEX idx_github_commits_sha ON github_commits(commit_sha);
CREATE INDEX idx_github_commits_pr_number ON github_commits(pr_number);

COMMENT ON TABLE github_commits IS 'GitHub integration tracking for committed scripts';

-- ============================================================================
-- DEFECTS
-- ============================================================================

CREATE TABLE defects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE NOT NULL,
    test_execution_id UUID REFERENCES test_executions(id) ON DELETE SET NULL,
    external_id VARCHAR(100) NOT NULL,
    external_system VARCHAR(50) DEFAULT 'rally',
    title VARCHAR(500) NOT NULL,
    description TEXT,
    severity VARCHAR(50),
    status VARCHAR(50),
    assigned_to VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_defects_workflow ON defects(workflow_id);
CREATE INDEX idx_defects_test_execution ON defects(test_execution_id);
CREATE INDEX idx_defects_external_id ON defects(external_id);
CREATE INDEX idx_defects_status ON defects(status);

COMMENT ON TABLE defects IS 'Defects auto-logged to Rally/Jira';
COMMENT ON COLUMN defects.external_id IS 'Rally defect ID or Jira issue key';

-- ============================================================================
-- REGRESSION BASELINES
-- ============================================================================

CREATE TABLE regression_baselines (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
    test_name VARCHAR(255) NOT NULL,
    baseline_metrics JSONB NOT NULL,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id, test_name)
);

CREATE INDEX idx_regression_baselines_project ON regression_baselines(project_id);
CREATE INDEX idx_regression_baselines_test_name ON regression_baselines(test_name);

COMMENT ON TABLE regression_baselines IS 'Historical baselines for regression detection';
COMMENT ON COLUMN regression_baselines.baseline_metrics IS 'JSON: avg_time, coverage%, flakiness_score';

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_workflows_updated_at BEFORE UPDATE ON workflows
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_defects_updated_at BEFORE UPDATE ON defects
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- VIEWS (Optional)
-- ============================================================================

-- Summary view for workflow dashboard
CREATE OR REPLACE VIEW vw_workflow_summary AS
SELECT
    w.id AS workflow_id,
    w.project_id,
    p.name AS project_name,
    w.test_type,
    w.status,
    w.current_phase,
    w.created_by,
    u.full_name AS created_by_name,
    w.created_at,
    w.started_at,
    w.completed_at,
    w.duration_ms,
    COUNT(DISTINCT te.id) AS total_tests,
    COUNT(DISTINCT CASE WHEN te.status = 'passed' THEN te.id END) AS passed_tests,
    COUNT(DISTINCT CASE WHEN te.status = 'failed' THEN te.id END) AS failed_tests,
    COUNT(DISTINCT d.id) AS defects_logged,
    gc.pr_url AS github_pr_url
FROM workflows w
LEFT JOIN projects p ON w.project_id = p.id
LEFT JOIN users u ON w.created_by = u.id
LEFT JOIN test_executions te ON w.id = te.workflow_id
LEFT JOIN defects d ON w.id = d.workflow_id
LEFT JOIN github_commits gc ON w.id = gc.workflow_id
GROUP BY w.id, p.name, u.full_name, gc.pr_url;

COMMENT ON VIEW vw_workflow_summary IS 'Aggregated workflow data for dashboard';

-- ============================================================================
-- SAMPLE DATA (For Development)
-- ============================================================================

-- Insert admin user (password: 'admin123' hashed with bcrypt)
INSERT INTO users (email, hashed_password, full_name, role) VALUES
('admin@iqtop.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5SG6vFtKvC9FW', 'Admin User', 'admin'),
('tester@iqtop.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5SG6vFtKvC9FW', 'Test User', 'tester');

-- Insert sample project
INSERT INTO projects (name, description, github_repo_url, rally_project_id, created_by) VALUES
('E-Commerce Platform', 'Testing for main e-commerce application', 'https://github.com/example/ecommerce', 'PROJ12345',
 (SELECT id FROM users WHERE email = 'admin@iqtop.com'));
```

---

## MongoDB Schema

### Collections

#### 1. `test_scenarios_full`
Stores complete LLM interactions for test scenario generation.

```javascript
{
  "_id": ObjectId("..."),
  "workflow_id": "uuid",
  "timestamp": ISODate("2025-01-11T12:00:00Z"),
  "llm_model": "gpt-4o",
  "prompt": "Generate test scenarios for...",
  "prompt_tokens": 1500,
  "completion": "{ scenarios: [...] }",
  "completion_tokens": 3000,
  "total_tokens": 4500,
  "cost_usd": 0.12,
  "latency_ms": 3500,
  "metadata": {
    "figma_url": "https://...",
    "rally_story_id": "US12345"
  }
}
```

**Indexes:**
```javascript
db.test_scenarios_full.createIndex({ "workflow_id": 1 });
db.test_scenarios_full.createIndex({ "timestamp": -1 });
db.test_scenarios_full.createIndex({ "llm_model": 1 });
```

#### 2. `agent_logs`
Detailed execution logs from all agents.

```javascript
{
  "_id": ObjectId("..."),
  "workflow_id": "uuid",
  "agent_name": "playwright_executor",
  "timestamp": ISODate("2025-01-11T12:05:00Z"),
  "log_level": "ERROR",
  "message": "Test failed: Timeout waiting for element",
  "context": {
    "test_name": "login_test",
    "browser": "chromium",
    "url": "https://staging.example.com/login"
  },
  "stack_trace": "Error: Timeout...",
  "duration_ms": 30000
}
```

**Indexes:**
```javascript
db.agent_logs.createIndex({ "workflow_id": 1, "timestamp": -1 });
db.agent_logs.createIndex({ "agent_name": 1, "timestamp": -1 });
db.agent_logs.createIndex({ "log_level": 1, "timestamp": -1 });
```

#### 3. `audit_trail`
Complete audit log of all user actions and system events.

```javascript
{
  "_id": ObjectId("..."),
  "user_id": "uuid",
  "user_email": "tester@iqtop.com",
  "action": "workflow_approved",
  "resource_type": "workflow",
  "resource_id": "workflow_uuid",
  "ip_address": "192.168.1.100",
  "user_agent": "Mozilla/5.0...",
  "timestamp": ISODate("2025-01-11T12:03:00Z"),
  "details": {
    "edited_scenarios": false,
    "approval_comment": "Looks good"
  }
}
```

**Indexes:**
```javascript
db.audit_trail.createIndex({ "user_id": 1, "timestamp": -1 });
db.audit_trail.createIndex({ "resource_type": 1, "resource_id": 1 });
db.audit_trail.createIndex({ "timestamp": -1 });
db.audit_trail.createIndex({ "action": 1, "timestamp": -1 });
```

#### 4. `llm_interactions`
All LLM API calls for cost tracking and analysis.

```javascript
{
  "_id": ObjectId("..."),
  "workflow_id": "uuid",
  "agent_name": "script_generator",
  "timestamp": ISODate("2025-01-11T12:10:00Z"),
  "llm_provider": "azure_openai",
  "model": "gpt-4o",
  "prompt_tokens": 2000,
  "completion_tokens": 5000,
  "total_tokens": 7000,
  "cost_usd": 0.18,
  "latency_ms": 4200,
  "success": true,
  "error": null
}
```

**Indexes:**
```javascript
db.llm_interactions.createIndex({ "workflow_id": 1 });
db.llm_interactions.createIndex({ "timestamp": -1 });
db.llm_interactions.createIndex({ "llm_provider": 1, "model": 1, "timestamp": -1 });
```

---

## MinIO / S3 Bucket Structure

```
iqtop-artifacts/
├── screenshots/
│   └── {workflow_id}/
│       ├── TC001_failure.png
│       ├── TC002_failure.png
│       └── ...
├── videos/
│   └── {workflow_id}/
│       ├── TC001_test.mp4
│       └── ...
├── traces/
│   └── {workflow_id}/
│       ├── TC001_trace.zip
│       └── ...
├── reports/
│   └── {workflow_id}/
│       ├── allure-report/
│       │   ├── index.html
│       │   └── ...
│       ├── playwright-report/
│       │   ├── index.html
│       │   └── ...
│       └── summary.pdf
├── scripts/
│   └── {workflow_id}/
│       ├── login.spec.ts
│       ├── pages/
│       │   └── LoginPage.ts
│       └── ...
└── uploads/
    └── {workflow_id}/
        ├── swagger.json
        ├── legacy_docs.pdf
        └── ...
```

**Naming Convention:**
- `{workflow_id}` = UUID of the workflow
- Files: `{test_name}_{type}.{ext}`

**Lifecycle Policy:**
- Delete screenshots/videos > 30 days
- Archive reports > 90 days to Glacier
- Keep scripts indefinitely (small size)

---

## Database Sizing Estimates

### PostgreSQL
| Table | Est. Rows/Month | Row Size | Storage/Month |
|-------|-----------------|----------|---------------|
| workflows | 1,000 | 1 KB | 1 MB |
| workflow_phases | 8,000 | 2 KB | 16 MB |
| test_scenarios | 1,000 | 10 KB | 10 MB |
| test_executions | 50,000 | 1 KB | 50 MB |
| artifacts | 100,000 | 0.5 KB | 50 MB |
| github_commits | 1,000 | 0.5 KB | 0.5 MB |
| defects | 2,000 | 1 KB | 2 MB |
| **Total** | | | **~130 MB/month** |

**1-year projection**: ~1.5 GB

### MongoDB
| Collection | Est. Docs/Month | Doc Size | Storage/Month |
|------------|-----------------|----------|---------------|
| test_scenarios_full | 1,000 | 50 KB | 50 MB |
| agent_logs | 100,000 | 5 KB | 500 MB |
| audit_trail | 50,000 | 2 KB | 100 MB |
| llm_interactions | 5,000 | 3 KB | 15 MB |
| **Total** | | | **~665 MB/month** |

**1-year projection**: ~8 GB

### MinIO / S3
| Type | Count/Month | Avg Size | Storage/Month |
|------|-------------|----------|---------------|
| Screenshots | 10,000 | 500 KB | 5 GB |
| Videos | 1,000 | 10 MB | 10 GB |
| Traces | 1,000 | 5 MB | 5 GB |
| Reports | 1,000 | 20 MB | 20 GB |
| Scripts | 1,000 | 100 KB | 100 MB |
| **Total** | | | **~40 GB/month** |

**1-year projection (with 30-day retention)**: ~40 GB steady-state

---

## Backup Strategy

### PostgreSQL
- **Frequency**: Daily full backup + continuous WAL archiving
- **Retention**: 30 days
- **Tool**: pg_dump or pgBackRest
- **Storage**: S3 with versioning

### MongoDB
- **Frequency**: Daily snapshot
- **Retention**: 30 days
- **Tool**: mongodump or Atlas backup
- **Storage**: S3

### MinIO
- **Replication**: 4-node distributed mode (built-in redundancy)
- **Backup**: S3 bucket replication to separate region
- **Retention**: Per lifecycle policy

---

## Migration Strategy

### Initial Setup
```bash
# PostgreSQL
psql -U postgres -f schema.sql

# MongoDB
mongosh < mongodb_indexes.js

# MinIO
mc mb minio/iqtop-artifacts
mc policy set download minio/iqtop-artifacts/reports
```

### Schema Versioning
- Use **Alembic** (Python) for PostgreSQL migrations
- Track schema version in `alembic_version` table
- All schema changes via migration scripts
- Never edit schema.sql directly after initial setup

---

## Performance Optimization

### PostgreSQL
1. **Connection Pooling**: Use pgBouncer (max 100 connections)
2. **Indexes**: Ensure all FK columns are indexed
3. **Partitioning**: Partition `test_executions` by date (monthly) after 1M rows
4. **Vacuum**: Auto-vacuum configured (default is fine)
5. **Query Optimization**: Use EXPLAIN ANALYZE for slow queries

### MongoDB
1. **Indexes**: Compound indexes for common queries
2. **TTL Indexes**: Auto-delete old logs
   ```javascript
   db.agent_logs.createIndex({ "timestamp": 1 }, { expireAfterSeconds: 2592000 }) // 30 days
   ```
3. **Sharding**: Consider sharding if > 100GB data

### MinIO
1. **Distributed Mode**: 4+ nodes for performance + redundancy
2. **Erasure Coding**: Automatic data protection
3. **CDN**: CloudFront or Cloudflare for report URLs

---

This schema is designed for **scalability**, **performance**, and **maintainability** in a production environment.
