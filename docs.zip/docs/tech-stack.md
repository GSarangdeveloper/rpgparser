# Comprehensive Technology Stack

## Frontend Layer

| Component | Technology | Version | Purpose | Rationale |
|-----------|-----------|---------|---------|-----------|
| **Framework** | Angular | 18+ | SPA framework | Enterprise-grade, TypeScript native, strong tooling |
| **UI Library** | Angular Material | Latest | Component library | Google-backed, accessibility, consistency |
| **Advanced Components** | PrimeNG | Latest | Data tables, charts | Rich components, better than Material for complex UIs |
| **State Management** | NgRx | 18+ | Redux pattern | Predictable state, time-travel debugging, DevTools |
| **Real-time Communication** | Socket.IO Client | 4.7+ | WebSocket | Auto-reconnection, fallback to polling, room support |
| **Forms** | Reactive Forms | Built-in | Form handling | Type-safe, validation, dynamic forms |
| **Dynamic Forms** | ngx-formly | Latest | Form generator | Generate forms from JSON schemas |
| **Code Editor** | Monaco Editor | Latest | Code viewer/editor | Same as VS Code, syntax highlighting |
| **Markdown** | ngx-markdown | Latest | Rich text input | Markdown support for test cases |
| **File Upload** | ngx-dropzone | Latest | Drag-drop upload | Intuitive file uploads |
| **Charts** | Chart.js + ng2-charts | Latest | Visualizations | Test trends, coverage metrics |
| **HTTP Client** | HttpClient | Built-in | API calls | Angular native, interceptors |
| **Routing** | Angular Router | Built-in | SPA routing | Lazy loading, guards |
| **Build Tool** | Vite | Latest | Fast builds | 10x faster than Webpack |
| **Testing** | Jasmine + Karma | Latest | Unit tests | Angular default testing framework |
| **E2E Testing** | Cypress | Latest | E2E tests | Fast, reliable, great DX |

---

## Backend - API Gateway

| Component | Technology | Version | Purpose | Rationale |
|-----------|-----------|---------|---------|-----------|
| **Framework** | FastAPI | 0.110+ | REST API | Async Python, auto docs, fast |
| **ASGI Server** | Uvicorn | Latest | Production server | Lightning fast, HTTP/2 support |
| **Validation** | Pydantic v2 | 2.7+ | Schema validation | 5-50x faster than v1, type-safe |
| **ORM** | SQLAlchemy | 2.0+ | Database ORM | Mature, async support, migrations |
| **Async DB Driver** | asyncpg | Latest | PostgreSQL driver | Fastest async Postgres driver |
| **MongoDB Driver** | Motor | Latest | Async MongoDB | Official async driver |
| **RabbitMQ Client** | aio-pika | Latest | AMQP client | Async RabbitMQ for Python |
| **Redis Client** | redis-py | Latest | Redis client | Official Python Redis client |
| **Authentication** | FastAPI-Users | Latest | Auth framework | OAuth2, JWT, refresh tokens |
| **JWT** | python-jose | Latest | JWT tokens | HS256/RS256 algorithms |
| **Password Hashing** | passlib + bcrypt | Latest | Secure hashing | Industry standard |
| **WebSocket** | FastAPI WebSockets | Built-in | Native WS support | Simple, integrated |
| **Socket.IO (alt)** | python-socketio | Latest | Advanced WS | Rooms, namespaces, fallback |
| **Rate Limiting** | slowapi | Latest | API throttling | Per-user/IP rate limits |
| **CORS** | fastapi-cors | Built-in | Cross-origin | Secure CORS configuration |
| **Testing** | pytest + pytest-asyncio | Latest | Unit/integration tests | Industry standard |

---

## Orchestration Layer

| Component | Technology | Version | Purpose | Rationale |
|-----------|-----------|---------|---------|-----------|
| **Workflow Engine (Primary)** | LangGraph | 0.2+ | State machine | LangChain's workflow lib, human-in-loop support |
| **Alternative** | Temporal.io | 1.6+ | Workflow orchestration | Enterprise-grade, durability, saga pattern |
| **LLM Framework** | LangChain | Latest | LLM orchestration | Prompt management, chains, agents |
| **Retry Logic** | tenacity | Latest | Exponential backoff | Robust retry with custom conditions |
| **Logging** | structlog | Latest | Structured logging | JSON logs for ELK/Datadog |
| **Error Tracking** | Sentry SDK | Latest | Error monitoring | Real-time alerts, stack traces |
| **Metrics** | Prometheus Client | Latest | Metrics export | Custom metrics for Prometheus |

---

## Message Broker & Caching

| Component | Technology | Version | Purpose | Rationale |
|-----------|-----------|---------|---------|-----------|
| **Message Queue (Primary)** | RabbitMQ | 3.13+ | AMQP broker | Reliable, mature, priority queues |
| **Alternative** | Apache Kafka | 3.7+ | Event streaming | If need log retention, high throughput |
| **Cache + PubSub** | Redis | 7.2+ | In-memory store | Fast cache, PubSub, distributed locks |
| **Redis HA** | Redis Sentinel | Built-in | High availability | Auto-failover for Redis |
| **Task Queue (Optional)** | Celery | 5.4+ | Distributed tasks | If prefer task-based vs messages |

---

## MCP Layer (Model Context Protocol)

| Component | Technology | Version | Purpose | Rationale |
|-----------|-----------|---------|---------|-----------|
| **MCP Server** | FastAPI | Latest | Tool routing | RESTful MCP implementation |
| **Protocol** | HTTP/2 + gRPC (optional) | - | Communication | HTTP/2 for streaming, gRPC for perf |
| **Service Discovery** | Consul or etcd | Latest | Agent discovery | If microservices architecture |
| **Load Balancer** | Nginx or HAProxy | Latest | Traffic distribution | Distribute across agent pools |
| **Health Checks** | Custom FastAPI | - | Agent monitoring | Periodic health pings |

---

## Specialized Agents

### Common Dependencies (All Agents)
| Library | Purpose |
|---------|---------|
| httpx | Async HTTP client |
| pydantic | Data validation |
| structlog | Structured logging |
| tenacity | Retry logic |

### Test Scenario Generator Agent
| Technology | Purpose |
|-----------|---------|
| Python 3.11+ | Runtime |
| openai | Azure OpenAI SDK |
| langchain | LLM orchestration |
| requests | Figma/Rally API calls |
| rally-restapi-python | Rally integration |

### Playwright Executor Agent
| Technology | Purpose |
|-----------|---------|
| Node.js 20+ | Runtime |
| @playwright/test | Browser automation |
| playwright | Core library |
| allure-playwright | Reporting |

### API Test Executor Agent
| Technology | Purpose |
|-----------|---------|
| Python 3.11+ | Runtime |
| httpx | Async HTTP client |
| pytest | Test framework |
| jsonschema | Schema validation |
| prance | OpenAPI parser |

### Defect Logger Agent
| Technology | Purpose |
|-----------|---------|
| Python 3.11+ | Runtime |
| requests | HTTP client |
| rally-restapi-python | Rally API |
| jira-python | Jira API |

### Script Generator Agent
| Technology | Purpose |
|-----------|---------|
| Python 3.11+ | Runtime |
| openai | LLM for code generation |
| jinja2 | Template engine |
| black | Python code formatter |
| prettier (via subprocess) | TypeScript formatter |

### Report Generator Agent
| Technology | Purpose |
|-----------|---------|
| Python 3.11+ | Runtime |
| allure-pytest | Allure CLI wrapper |
| playwright | Native reporting |
| reportlab | PDF generation |

### Regression Analyzer Agent
| Technology | Purpose |
|-----------|---------|
| Python 3.11+ | Runtime |
| pandas | Data analysis |
| scikit-learn | ML for flakiness detection |
| numpy | Numerical computing |

### GitHub Integrator Agent
| Technology | Purpose |
|-----------|---------|
| Python 3.11+ | Runtime |
| GitPython | Git operations |
| PyGithub | GitHub API |

### Legacy Modernizer Agent
| Technology | Purpose |
|-----------|---------|
| Python 3.11+ | Runtime |
| pytesseract | OCR for PDFs |
| python-docx | Word document parsing |
| openpyxl | Excel parsing |
| PyPDF2 | PDF text extraction |
| openai | LLM for modernization |

---

## LLM & AI Services

| Service | Model | Context | Use Case |
|---------|-------|---------|----------|
| **Azure OpenAI** | GPT-4o | 128K tokens | Primary LLM for all generation tasks |
| **Azure OpenAI** | GPT-4 Vision | 128K tokens | Image analysis (Figma designs, screenshots) |
| **Azure OpenAI** | text-embedding-3-large | - | Semantic search, similarity detection |
| **Prompt Management** | LangSmith | - | Version control for prompts, A/B testing |
| **Fallback** | Anthropic Claude 3.5 Sonnet | 200K tokens | Via AWS Bedrock if Azure quota exceeded |

---

## Data Persistence

| Component | Technology | Version | Purpose | Persistence |
|-----------|-----------|---------|---------|-------------|
| **Primary Database** | PostgreSQL | 16+ | Relational data | StatefulSet, PVC, daily backups |
| **Extensions** | pgcrypto, TimescaleDB | Built-in | Encryption, time-series | - |
| **Connection Pooling** | pgBouncer | Latest | Connection management | Reduces DB connections |
| **Document Store** | MongoDB | 7.0+ | Unstructured data | StatefulSet, replica set |
| **Object Storage** | MinIO (self-hosted) | Latest | Large files | StatefulSet, distributed mode |
| **Alternative Storage** | AWS S3 | - | Cloud object storage | For production |
| **Search (Optional)** | Elasticsearch | 8.13+ | Full-text search | Test cases, logs |

---

## External Integrations

| Service | SDK/Library | Purpose |
|---------|-------------|---------|
| **Azure OpenAI** | openai (Python), @azure/openai (TS) | LLM API calls |
| **Figma API** | requests (Python) | Fetch designs |
| **Rally API** | rally-restapi-python | User stories, defects |
| **Jira API** | jira-python | Alternative to Rally |
| **GitHub API** | PyGithub | Git operations, PRs |
| **Jenkins API** | python-jenkins | Trigger CI/CD |
| **GitLab CI API** | python-gitlab | Alternative CI/CD |
| **Slack API** | slack-sdk | Notifications |
| **MS Teams** | pymsteams | Notifications |

---

## Infrastructure & DevOps

### Containerization
| Technology | Purpose |
|-----------|---------|
| Docker | Container runtime |
| Docker Compose | Local development |
| Docker BuildKit | Faster image builds |

### Orchestration
| Technology | Purpose |
|-----------|---------|
| Kubernetes (K8s) | Container orchestration |
| Helm | K8s package manager |
| kubectl | K8s CLI |

### Service Mesh (Optional)
| Technology | Purpose |
|-----------|---------|
| Istio | Traffic management, mTLS |
| Envoy | Sidecar proxy |

### CI/CD
| Technology | Purpose |
|-----------|---------|
| GitHub Actions | Primary CI/CD |
| GitLab CI (alternative) | Alternative CI/CD |
| ArgoCD | GitOps deployment |

### Secrets Management
| Technology | Purpose |
|-----------|---------|
| HashiCorp Vault | Secret storage |
| AWS Secrets Manager (alternative) | Cloud-native secrets |
| External Secrets Operator | K8s secrets sync |

### Monitoring
| Technology | Purpose |
|-----------|---------|
| Prometheus | Metrics collection |
| Grafana | Dashboards |
| Alertmanager | Alert routing |

### Logging
| Technology | Purpose |
|-----------|---------|
| Fluentd / Fluent Bit | Log collection |
| Elasticsearch | Log storage |
| Kibana | Log visualization |

### Tracing
| Technology | Purpose |
|-----------|---------|
| Jaeger | Distributed tracing |
| OpenTelemetry | Instrumentation |

### Alerting
| Technology | Purpose |
|-----------|---------|
| PagerDuty | On-call management |
| Opsgenie (alternative) | Alternative on-call |

---

## Security

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Authentication** | OAuth2 + JWT | User auth |
| **Identity Provider** | Azure AD / Okta | SSO, OIDC |
| **Authorization** | Casbin | RBAC engine |
| **API Security** | OWASP ZAP | Automated security scans |
| **TLS/SSL** | Let's Encrypt + cert-manager | HTTPS certificates |
| **WAF** | Cloudflare / AWS WAF | DDoS protection |
| **Vulnerability Scanning** | Trivy | Container image scanning |
| **Secrets Scanning** | GitGuardian | Prevent secret leaks |

---

## Development Tools

| Tool | Purpose |
|------|---------|
| **IDE** | VS Code, PyCharm, WebStorm |
| **Python Linting** | ruff (fastest), pylint |
| **Python Formatting** | black, isort |
| **TypeScript Linting** | ESLint |
| **TypeScript Formatting** | Prettier |
| **Pre-commit Hooks** | pre-commit (Python) |
| **API Testing** | Postman, Insomnia |
| **Database Client** | DBeaver, pgAdmin |
| **K8s Management** | Lens, k9s |

---

## Production Infrastructure

### Cloud Providers (Choose One)
- **AWS**: EKS, RDS, ElastiCache, S3, Secrets Manager
- **Azure**: AKS, Azure Database, Azure Cache, Blob Storage
- **GCP**: GKE, Cloud SQL, Memorystore, Cloud Storage

### Estimated Costs (AWS Example)
| Resource | Spec | Monthly Cost (USD) |
|----------|------|--------------------|
| EKS Cluster | Control plane | $72 |
| EC2 Nodes (3x) | t3.xlarge (4 vCPU, 16GB) | $300 |
| RDS PostgreSQL | db.t3.large (2 vCPU, 8GB) | $150 |
| ElastiCache Redis | cache.t3.medium | $50 |
| S3 Storage | 500 GB | $12 |
| Data Transfer | 1 TB/month | $90 |
| **Total** | | **~$674/month** |

---

## Summary

- **Frontend**: Angular 18+ with Material/PrimeNG, NgRx, Socket.IO
- **Backend**: FastAPI + Python 3.11+, PostgreSQL, MongoDB, RabbitMQ, Redis
- **Orchestration**: LangGraph for workflows, MCP for agent communication
- **LLM**: Azure OpenAI (GPT-4o, GPT-4 Vision)
- **Agents**: 9+ specialized agents (Python + Node.js)
- **Deployment**: Kubernetes on AWS/Azure/GCP
- **Monitoring**: Prometheus, Grafana, ELK stack, Jaeger

This stack is **production-ready**, **scalable**, and follows **industry best practices**.
