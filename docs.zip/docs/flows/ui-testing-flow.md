# UI Testing Flow - 8-Phase Workflow

## Overview
Complete end-to-end flow for UI testing, from Figma URL + Rally story input to GitHub commit with generated test scripts.

## Flow Diagram

```
┌──────────┐
│  TESTER  │
└────┬─────┘
     │ 1. Fill form (Figma URL + Rally Story)
     ↓
┌─────────────────────────────────────────────────────────────────┐
│                      ANGULAR UI                                 │
│  [Project Selection] → [Test Type: UI] → [Input Form]          │
└────┬────────────────────────────────────────────────────────────┘
     │ POST /api/v1/workflows/ui-test
     │ { figma_url, rally_story_id, project_id }
     ↓
┌─────────────────────────────────────────────────────────────────┐
│                   FASTAPI GATEWAY                               │
│  • Validate input                                               │
│  • Generate workflow_id                                         │
│  • Save to PostgreSQL (status: PENDING)                         │
│  • Publish to RabbitMQ: "start_ui_workflow"                     │
│  • Return: 202 Accepted { workflow_id }                         │
└────┬────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 1: DESIGN ANALYSIS                                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent (LangGraph State Machine)                   │  │
│  │  • Consume RabbitMQ message                              │  │
│  │  • Update status: PHASE_1_GENERATING                     │  │
│  │  • Call MCP: generate_test_scenarios(figma, rally)       │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ MCP Server → Test Scenario Agent                         │  │
│  │  • Fetch Figma design (REST API)                         │  │
│  │  • Fetch Rally story (REST API)                          │  │
│  │  • Send context to Azure OpenAI GPT-4                    │  │
│  │  • Receive JSON test scenarios                           │  │
│  │  • Return to Master Agent                                │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  OUTPUT: Test scenarios in structured JSON format               │
│  Example:                                                        │
│  [                                                               │
│    {                                                             │
│      "scenario_id": "TC001",                                     │
│      "title": "User login with valid credentials",              │
│      "steps": [                                                  │
│        "Navigate to login page",                                 │
│        "Enter valid username",                                   │
│        "Enter valid password",                                   │
│        "Click login button"                                      │
│      ],                                                          │
│      "expected_result": "User is redirected to dashboard"        │
│    }                                                             │
│  ]                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 2: HUMAN-IN-THE-LOOP APPROVAL                             │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent                                             │  │
│  │  • Save scenarios to PostgreSQL                          │  │
│  │  • Update status: PHASE_2_AWAITING_REVIEW                │  │
│  │  • Publish to Redis PubSub: "review_ready"               │  │
│  │  • PAUSE workflow (wait for resume signal)               │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ FastAPI Gateway → WebSocket Push                         │  │
│  │  • Listen to Redis PubSub                                │  │
│  │  • Emit to Angular: { scenarios, workflow_id }           │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│                      ANGULAR UI                                 │
│  • Render scenarios in editable table                           │
│  • Display [Approve] [Disapprove] [Edit] buttons               │
│  • Tester reviews and optionally edits scenarios                │
│  • Tester clicks "Approve"                                      │
│  • POST /api/v1/workflows/{id}/approve                          │
└────┬────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│                   FASTAPI GATEWAY                               │
│  • Validate approval                                            │
│  • Update test_scenarios.approved = true                        │
│  • Publish to RabbitMQ: "resume_workflow"                       │
└────┬────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 3: FUNCTIONAL TESTING (PLAYWRIGHT)                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent                                             │  │
│  │  • Resume from PAUSED state                              │  │
│  │  • Update status: PHASE_3_EXECUTING_TESTS                │  │
│  │  • Call MCP: execute_functional_tests(scenarios)         │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ MCP Server → Playwright Agent (Node.js)                  │  │
│  │  • Generate test.spec.ts files dynamically               │  │
│  │  • Run: npx playwright test --headed                     │  │
│  │  • Execute in 3 browsers: Chromium, Firefox, WebKit      │  │
│  │  • Capture: screenshots (on failure), videos, traces     │  │
│  │  • Upload artifacts to MinIO                             │  │
│  │  • Return: results + artifacts URLs                      │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  OUTPUT: Execution results                                       │
│  {                                                               │
│    "total": 15,                                                  │
│    "passed": 12,                                                 │
│    "failed": 3,                                                  │
│    "skipped": 0,                                                 │
│    "duration_ms": 125000,                                        │
│    "failures": [                                                 │
│      {                                                           │
│        "test_name": "TC003: Login with invalid password",        │
│        "error": "Assertion failed...",                           │
│        "screenshot_url": "s3://screenshots/tc003.png"            │
│      }                                                           │
│    ]                                                             │
│  }                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 4: DEFECT ANALYSIS                                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent                                             │  │
│  │  • Update status: PHASE_4_DEFECTS                        │  │
│  │  • Call MCP: auto_defect_logging(results)                │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ MCP Server → Defect Logger Agent                         │  │
│  │  • Analyze failed tests                                  │  │
│  │  • For each failure:                                     │  │
│  │    - Generate defect description using LLM              │  │
│  │    - Attach screenshot from MinIO                        │  │
│  │    - Call Rally API: POST /defect                        │  │
│  │    - Link to Rally user story                            │  │
│  │  • Return: defect_ids[]                                  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  OUTPUT: Created defects                                         │
│  {                                                               │
│    "defects_created": 3,                                         │
│    "defect_ids": ["DE12345", "DE12346", "DE12347"]              │
│  }                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 5: SCRIPT GENERATION                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent                                             │  │
│  │  • Update status: PHASE_5_GENERATING_SCRIPTS             │  │
│  │  • Call MCP: generate_automation_scripts(scenarios)      │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ MCP Server → Script Generator Agent                      │  │
│  │  • Use GPT-4 to generate production-ready .ts files      │  │
│  │  • Apply Page Object Model (POM) pattern                 │  │
│  │  • Add comprehensive assertions                          │  │
│  │  • Add error handling and retries                        │  │
│  │  • Format with Prettier                                  │  │
│  │  • Save to MinIO                                         │  │
│  │  • Return: script_files[]                                │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  OUTPUT: Generated script files                                 │
│  [                                                               │
│    "tests/ui/login.spec.ts",                                     │
│    "tests/ui/pages/LoginPage.ts",                                │
│    "tests/ui/fixtures/testData.json"                             │
│  ]                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 6: REPORTING                                              │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent                                             │  │
│  │  • Update status: PHASE_6_REPORTING                      │  │
│  │  • Call MCP: automation_test_reporting(results)          │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ MCP Server → Reporting Agent                             │  │
│  │  • Run: allure generate allure-results                   │  │
│  │  • Generate: Playwright HTML report                      │  │
│  │  • Create: Custom PDF report                             │  │
│  │  • Upload all reports to MinIO                           │  │
│  │  • Generate: Public shareable URLs                       │  │
│  │  • Return: report_urls                                   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  OUTPUT: Report URLs                                             │
│  {                                                               │
│    "allure_report": "https://s3.../allure-report/index.html",   │
│    "playwright_report": "https://s3.../playwright/index.html",  │
│    "pdf_summary": "https://s3.../summary.pdf"                   │
│  }                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 7: REGRESSION BASELINING                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent                                             │  │
│  │  • Update status: PHASE_7_REGRESSION                     │  │
│  │  • Call MCP: regression_baselining(results)              │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ MCP Server → Regression Analyzer Agent                   │  │
│  │  • Fetch historical test results from PostgreSQL        │  │
│  │  • Compare current vs baseline:                          │  │
│  │    - Coverage delta                                      │  │
│  │    - Execution time trends                               │  │
│  │    - Flakiness detection (ML-based)                      │  │
│  │  • Update regression_baselines table                     │  │
│  │  • Flag: New failures, Performance regressions           │  │
│  │  • Return: analysis_summary                              │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  OUTPUT: Regression analysis                                     │
│  {                                                               │
│    "coverage_delta": "+5%",                                      │
│    "avg_execution_time_ms": 8500,                                │
│    "baseline_updated": true,                                     │
│    "flaky_tests": ["TC009"],                                     │
│    "new_failures": 2                                             │
│  }                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 8: GITHUB INTEGRATION                                     │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent                                             │  │
│  │  • Update status: PHASE_8_COMMITTING_ASSETS              │  │
│  │  • Call MCP: commit_generated_assets(scripts, reports)   │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ MCP Server → GitHub Agent                                │  │
│  │  • git clone <repo>                                      │  │
│  │  • git checkout -b test/ui-automated-{timestamp}         │  │
│  │  • Download scripts from MinIO                           │  │
│  │  • Copy scripts to /tests/ui/                            │  │
│  │  • git add .                                             │  │
│  │  • git commit -m "Add automated UI tests for US12345"    │  │
│  │  • git push origin <branch>                              │  │
│  │  • Create PR via GitHub API:                             │  │
│  │    - Title: "Automated UI tests for Rally US12345"       │  │
│  │    - Body: Summary + test report links                   │  │
│  │    - Reviewers: Auto-assign from project config          │  │
│  │  • Return: commit_url, pr_url                            │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  OUTPUT: GitHub integration results                              │
│  {                                                               │
│    "commit_sha": "a1b2c3d4e5f6",                                 │
│    "branch": "test/ui-automated-20250111-143025",                │
│    "pr_url": "https://github.com/org/repo/pull/123",            │
│    "pr_number": 123                                              │
│  }                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌─────────────────────────────────────────────────────────────────┐
│ WORKFLOW COMPLETION                                             │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Master Agent                                             │  │
│  │  • Update status: COMPLETED                              │  │
│  │  • Calculate total duration                              │  │
│  │  • Publish to Redis: "workflow_complete"                 │  │
│  └────┬─────────────────────────────────────────────────────┘  │
│       ↓                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ FastAPI Gateway → WebSocket Push                         │  │
│  │  • Emit to Angular: {                                    │  │
│  │      status: "COMPLETED",                                │  │
│  │      duration_ms: 245000,                                │  │
│  │      artifacts: {                                         │  │
│  │        allure_report_url,                                │  │
│  │        github_pr_url,                                    │  │
│  │        defect_ids: ["DE12345", ...]                      │  │
│  │      }                                                    │  │
│  │    }                                                      │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
     │
     ↓
┌──────────┐
│  TESTER  │
│  Views:  │
│  • ✅ Test Report (Allure) - Interactive HTML                   │
│  • ✅ GitHub PR link - Ready for review                         │
│  • ✅ Defect tickets in Rally - Auto-logged                     │
│  • ✅ Execution timeline - Phase-wise breakdown                 │
│  • ✅ Regression insights - Coverage, trends                    │
└─────────────────────────────────────────────────────────────────┘
```

## Timing Estimates

| Phase | Estimated Duration | Bottleneck |
|-------|-------------------|------------|
| Phase 1: Generate Scenarios | 30-60 seconds | LLM API latency |
| Phase 2: Await Approval | Variable (user-dependent) | Human review |
| Phase 3: Execute Tests | 2-5 minutes | Playwright execution |
| Phase 4: Log Defects | 15-30 seconds | Rally API |
| Phase 5: Generate Scripts | 30-60 seconds | LLM API latency |
| Phase 6: Reporting | 15-30 seconds | Allure generation |
| Phase 7: Regression Analysis | 10-20 seconds | Database queries |
| Phase 8: GitHub Commit | 20-40 seconds | Git operations |

**Total Automated Time**: ~4-8 minutes (excluding human approval)

## Error Handling

- **Phase 1 Failure**: Retry up to 3 times with exponential backoff. If fails, notify tester.
- **Phase 3 Failure**: Partial test execution is acceptable. Failed tests logged as defects.
- **Phase 8 Failure**: If GitHub push fails, save scripts to MinIO and notify tester to manually commit.

## Success Criteria

1. ✅ Test scenarios generated and approved
2. ✅ Tests executed successfully (or failures logged as defects)
3. ✅ Production-ready scripts generated
4. ✅ Comprehensive reports available
5. ✅ Scripts committed to GitHub
6. ✅ PR created and reviewers assigned
