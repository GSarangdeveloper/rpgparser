# C2: Container Architecture Diagram

## Overview
The C2 diagram shows the **high-level containers** (applications, services, databases) that make up the IQTOP system and how they interact.

## Full System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         PRESENTATION LAYER                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Angular 18+ SPA (Material Design / PrimeNG)                 │  │
│  │  Technology: TypeScript, Angular, NgRx                       │  │
│  │  Port: 4200 (dev) / 443 (prod)                               │  │
│  │                                                               │  │
│  │  Features:                                                    │  │
│  │  • Project Management Dashboard                              │  │
│  │  • Test Configuration Wizards (4 types)                      │  │
│  │  • Real-time Workflow Monitoring (WebSocket)                 │  │
│  │  • Artifact Viewer (Reports, Scripts, Test Cases)            │  │
│  │  • Approval Interface (Human-in-the-Loop)                    │  │
│  │  • Monaco Code Editor Integration                            │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────────┬────────────────────────────────────┘
                                 │
                    REST API (HTTPS) + WebSocket (WSS)
                                 │
┌────────────────────────────────┴────────────────────────────────────┐
│                          API GATEWAY LAYER                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  FastAPI Gateway                                             │  │
│  │  Technology: Python 3.11+, FastAPI, Uvicorn                  │  │
│  │  Port: 8000                                                  │  │
│  │                                                               │  │
│  │  Components:                                                  │  │
│  │  • REST API Endpoints (/api/v1/*)                            │  │
│  │  • WebSocket Manager (Socket.IO / native)                    │  │
│  │  • Authentication & Authorization (JWT, OAuth2)              │  │
│  │  • Request Validation (Pydantic v2)                          │  │
│  │  • Rate Limiting (slowapi)                                   │  │
│  │  • API Documentation (Swagger UI, Redoc)                     │  │
│  │                                                               │  │
│  │  Responsibilities:                                            │  │
│  │  • Receive user requests (create workflow, approve, etc.)    │  │
│  │  • Publish messages to RabbitMQ                              │  │
│  │  • Listen to Redis PubSub for status updates                 │  │
│  │  • Push real-time updates via WebSocket                      │  │
│  │  • Query/write to PostgreSQL and MongoDB                     │  │
│  └──────────────────────────────────────────────────────────────┘  │
└──────┬───────────────┬─────────────────┬────────────────┬──────────┘
       │               │                 │                │
       │               │                 │                │
┌──────▼──────┐  ┌────▼──────┐  ┌───────▼────────┐  ┌───▼────────┐
│ PostgreSQL  │  │ MongoDB   │  │ RabbitMQ       │  │ Redis      │
│ Database    │  │ Database  │  │ Message Broker │  │ Cache      │
│             │  │           │  │                │  │ + PubSub   │
│ Ver: 16+    │  │ Ver: 7.0+ │  │ Ver: 3.13+     │  │ Ver: 7.2+  │
│ Port: 5432  │  │ Port:27017│  │ Port: 5672     │  │ Port: 6379 │
│             │  │           │  │ Mgmt: 15672    │  │            │
└─────────────┘  └───────────┘  └───────┬────────┘  └────────────┘
                                        │
                                        │ AMQP
                                        │
┌───────────────────────────────────────┴─────────────────────────────┐
│                    ORCHESTRATION LAYER                              │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Master Agent Service                                        │  │
│  │  Technology: Python 3.11+, LangGraph / Temporal.io          │  │
│  │  Replicas: 2 (with leader election via Redis)               │  │
│  │                                                               │  │
│  │  Responsibilities:                                            │  │
│  │  • Consume workflow messages from RabbitMQ                   │  │
│  │  • Manage 8-phase state machine (LangGraph)                  │  │
│  │  • Delegate tasks to specialized agents via MCP              │  │
│  │  • Handle human-in-loop pause/resume logic                   │  │
│  │  • Update workflow status in PostgreSQL                      │  │
│  │  • Publish status updates to Redis PubSub                    │  │
│  │  • Error recovery and retry with exponential backoff         │  │
│  │  • Audit logging to MongoDB                                  │  │
│  └──────────────────────────────────────────────────────────────┘  │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
                    MCP Protocol (HTTP/gRPC)
                               │
┌──────────────────────────────┴──────────────────────────────────────┐
│                    MCP SERVER (Router + Registry)                   │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  MCP Server Service                                          │  │
│  │  Technology: Python 3.11+, FastAPI                           │  │
│  │  Port: 8001                                                  │  │
│  │  Replicas: 3 (load balanced)                                 │  │
│  │                                                               │  │
│  │  Responsibilities:                                            │  │
│  │  • Maintain agent registry (tool_name -> agent_url)          │  │
│  │  • Route tool calls to appropriate agents                    │  │
│  │  • Load balancing across agent pools                         │  │
│  │  • Health checks for all registered agents                   │  │
│  │  • Circuit breaker pattern for agent failures                │  │
│  │  • Request/response logging                                  │  │
│  └──────────────────────────────────────────────────────────────┘  │
└───┬─────────┬─────────┬─────────┬─────────┬─────────┬─────────┬───┘
    │         │         │         │         │         │         │
    │ HTTP    │ HTTP    │ HTTP    │ HTTP    │ HTTP    │ HTTP    │ HTTP
    │         │         │         │         │         │         │
┌───▼────┐ ┌──▼────┐ ┌──▼────┐ ┌──▼────┐ ┌──▼────┐ ┌──▼────┐ ┌──▼────┐
│Test    │ │Play-  │ │API    │ │Defect │ │Script │ │Report │ │GitHub │
│Scenario│ │wright │ │Test   │ │Logger │ │Gen    │ │Gen    │ │Agent  │
│Gen     │ │Exec   │ │Exec   │ │Agent  │ │Agent  │ │Agent  │ │       │
└───┬────┘ └──┬────┘ └──┬────┘ └──┬────┘ └──┬────┘ └──┬────┘ └──┬────┘
    │         │         │         │         │         │         │
    │         │         │         │         │         │         │
┌───▼─────────▼─────────▼─────────▼─────────▼─────────▼─────────▼─────┐
│                    SPECIALIZED AGENT LAYER                           │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  1. Test Scenario Generator Agent                          │    │
│  │     Tech: Python, openai, langchain                         │    │
│  │     Purpose: Generate test scenarios from Figma + Rally     │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  2. Playwright Executor Agent                               │    │
│  │     Tech: Node.js 20+, @playwright/test                     │    │
│  │     Purpose: Execute UI tests in Chromium/Firefox/WebKit    │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  3. API Test Executor Agent                                 │    │
│  │     Tech: Python, httpx, pytest                             │    │
│  │     Purpose: Execute API tests from OpenAPI specs           │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  4. Defect Logger Agent                                     │    │
│  │     Tech: Python, requests, rally-api, jira-python          │    │
│  │     Purpose: Auto-create defect tickets                     │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  5. Script Generator Agent                                  │    │
│  │     Tech: Python, openai, jinja2                            │    │
│  │     Purpose: Generate production-ready test scripts         │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  6. Report Generator Agent                                  │    │
│  │     Tech: Python, allure-pytest, playwright                 │    │
│  │     Purpose: Generate HTML test reports                     │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  7. Regression Analyzer Agent                               │    │
│  │     Tech: Python, scikit-learn, pandas                      │    │
│  │     Purpose: Analyze test trends, detect flakiness          │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  8. GitHub Integrator Agent                                 │    │
│  │     Tech: Python, GitPython, PyGithub                       │    │
│  │     Purpose: Commit scripts, create PRs                     │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  9. Legacy Modernizer Agent                                 │    │
│  │     Tech: Python, pytesseract, python-docx, openai          │    │
│  │     Purpose: Modernize legacy test documentation            │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                       │
│  Each agent is a containerized microservice (Docker)                 │
│  Agents can scale horizontally based on queue depth                  │
└───┬───────────────────────────────────────────────────────────┬─────┘
    │                                                             │
    │ HTTPS API Calls                                             │
    │                                                             │
┌───▼─────────────────────────────────────────────────────────────▼───┐
│                    EXTERNAL INTEGRATIONS LAYER                      │
│                                                                       │
│  ┌─────────────┐ ┌──────────┐ ┌─────────┐ ┌────────┐ ┌─────────┐  │
│  │ Azure       │ │ Figma    │ │ Rally   │ │ GitHub │ │ Jenkins │  │
│  │ OpenAI      │ │ API      │ │ API     │ │ API    │ │ API     │  │
│  │ (GPT-4o)    │ │          │ │ /Jira   │ │        │ │         │  │
│  └─────────────┘ └──────────┘ └─────────┘ └────────┘ └─────────┘  │
└───────────────────────────────────────────────────────────────────────┘
    │                 │            │           │          │
    │ REST API        │ REST API   │ REST API  │ REST API │ REST API
    │                 │            │           │          │
    └─────────────────┴────────────┴───────────┴──────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         DATA PERSISTENCE LAYER                      │
│                                                                       │
│  ┌────────────────────┐  ┌──────────────────┐  ┌────────────────┐  │
│  │ PostgreSQL 16      │  │ MongoDB 7.0      │  │ MinIO / S3     │  │
│  │ Port: 5432         │  │ Port: 27017      │  │ Port: 9000     │  │
│  │                    │  │                  │  │                │  │
│  │ Stores:            │  │ Stores:          │  │ Stores:        │  │
│  │ • Workflows        │  │ • Test Scenarios │  │ • Screenshots  │  │
│  │ • Projects         │  │ • LLM Responses  │  │ • Videos       │  │
│  │ • Users/Auth       │  │ • Audit Logs     │  │ • Traces       │  │
│  │ • Test Results     │  │ • Large JSONs    │  │ • Reports      │  │
│  │ • Artifacts meta   │  │ • Agent Logs     │  │ • Scripts      │  │
│  │                    │  │                  │  │ • Documents    │  │
│  │ Persistence:       │  │ Persistence:     │  │ Persistence:   │  │
│  │ • StatefulSet      │  │ • StatefulSet    │  │ • StatefulSet  │  │
│  │ • PVC (100GB)      │  │ • PVC (50GB)     │  │ • PVC (500GB)  │  │
│  │ • Daily backups    │  │ • Daily backups  │  │ • Versioning   │  │
│  └────────────────────┘  └──────────────────┘  └────────────────┘  │
└───────────────────────────────────────────────────────────────────────┘
```

## Container Descriptions

### 1. Angular SPA Container
- **Technology**: Angular 18+, TypeScript, Material Design
- **Purpose**: User interface for all interactions
- **Communication**:
  - REST API calls to FastAPI Gateway (HTTPS)
  - WebSocket connection for real-time updates (WSS)
- **Deployment**: Static files served via Nginx or CDN
- **Scaling**: CDN distribution, no backend scaling needed

### 2. FastAPI Gateway Container
- **Technology**: Python 3.11+, FastAPI, Uvicorn (ASGI)
- **Purpose**: API gateway and WebSocket hub
- **Communication**:
  - Receives HTTP/WS from Angular
  - Publishes to RabbitMQ
  - Subscribes to Redis PubSub
  - Queries PostgreSQL and MongoDB
- **Deployment**: Kubernetes Deployment (3+ replicas)
- **Scaling**: Horizontal (CPU-based HPA)

### 3. PostgreSQL Container
- **Technology**: PostgreSQL 16 with pgcrypto extension
- **Purpose**: Primary relational data store
- **Data**: Users, projects, workflows, test results, artifacts metadata
- **Deployment**: Kubernetes StatefulSet (1 primary + 2 replicas)
- **Backup**: Daily automated backups to S3

### 4. MongoDB Container
- **Technology**: MongoDB 7.0
- **Purpose**: Document store for unstructured data
- **Data**: LLM responses, test scenarios (large JSON), audit logs
- **Deployment**: Kubernetes StatefulSet (3-node replica set)
- **Backup**: Daily automated backups

### 5. RabbitMQ Container
- **Technology**: RabbitMQ 3.13 with management plugin
- **Purpose**: Message broker for async workflows
- **Queues**:
  - `start_ui_workflow`, `start_api_workflow`, etc.
  - `resume_workflow`
  - Dead letter queues for failed messages
- **Deployment**: Kubernetes StatefulSet (3-node cluster)
- **Persistence**: Durable queues with disk persistence

### 6. Redis Container
- **Technology**: Redis 7.2 with Sentinel
- **Purpose**:
  - Cache (session store, workflow status)
  - PubSub (WebSocket fanout)
  - Distributed locks (leader election)
- **Deployment**: Kubernetes StatefulSet (3 nodes: 1 master + 2 replicas)
- **Persistence**: RDB snapshots + AOF

### 7. Master Agent Container
- **Technology**: Python 3.11+, LangGraph, structlog
- **Purpose**: Orchestrate 8-phase workflows
- **Communication**:
  - Consumes from RabbitMQ
  - Calls MCP Server (HTTP/gRPC)
  - Updates PostgreSQL and MongoDB
  - Publishes to Redis PubSub
- **Deployment**: Kubernetes Deployment (2 replicas with leader election)
- **Scaling**: Active-passive (only 1 leader at a time)

### 8. MCP Server Container
- **Technology**: Python 3.11+, FastAPI
- **Purpose**: Route tool calls to specialized agents
- **Communication**:
  - Receives HTTP/gRPC from Master Agent
  - Forwards to agent containers (HTTP)
  - Health checks via HTTP
- **Deployment**: Kubernetes Deployment (3 replicas)
- **Scaling**: Horizontal (request-based HPA)

### 9. Specialized Agent Containers (9 agents)
- **Technology**: Python 3.11+ or Node.js 20+ (Playwright)
- **Purpose**: Execute specific tasks (test gen, execution, reporting, etc.)
- **Communication**:
  - Receive HTTP requests from MCP Server
  - Call external APIs (Azure OpenAI, Figma, Rally, GitHub)
  - Upload artifacts to MinIO
- **Deployment**: Kubernetes Deployment (1-5 replicas per agent)
- **Scaling**: Horizontal (queue-depth-based HPA)

### 10. MinIO / S3 Container
- **Technology**: MinIO (S3-compatible)
- **Purpose**: Object storage for large artifacts
- **Data**: Screenshots, videos, Playwright traces, Allure reports, scripts
- **Deployment**: Kubernetes StatefulSet (4 nodes for distributed mode)
- **Persistence**: PVC (500GB per node)

## Communication Protocols

| From | To | Protocol | Purpose |
|------|----|---------| --------|
| Angular | FastAPI Gateway | HTTPS (REST) | API calls |
| Angular | FastAPI Gateway | WSS (WebSocket) | Real-time updates |
| FastAPI Gateway | RabbitMQ | AMQP | Publish workflow messages |
| FastAPI Gateway | Redis | Redis Protocol | Cache, PubSub |
| FastAPI Gateway | PostgreSQL | PostgreSQL Wire | Query/write data |
| FastAPI Gateway | MongoDB | MongoDB Wire | Query/write documents |
| Master Agent | RabbitMQ | AMQP | Consume workflow messages |
| Master Agent | MCP Server | HTTP/2 or gRPC | Call tools |
| Master Agent | Redis | Redis Protocol | Leader election, status updates |
| Master Agent | PostgreSQL | PostgreSQL Wire | Update workflow state |
| MCP Server | Agents | HTTP | Route tool calls |
| Agents | Azure OpenAI | HTTPS | LLM API calls |
| Agents | Figma | HTTPS | Fetch designs |
| Agents | Rally/Jira | HTTPS | Fetch stories, create defects |
| Agents | GitHub | HTTPS | Git operations, PR creation |
| Agents | MinIO | S3 API (HTTPS) | Upload artifacts |

## Data Stores

### PostgreSQL Schema (Simplified)
```
Tables:
- users (id, email, hashed_password, role)
- projects (id, name, github_repo_url, rally_project_id)
- workflows (id, project_id, test_type, status, phase, input_data)
- workflow_phases (id, workflow_id, phase_number, agent_name, status, output_data)
- test_scenarios (id, workflow_id, scenario_json, approved)
- test_executions (id, workflow_id, status, execution_time_ms, error_message)
- artifacts (id, workflow_id, artifact_type, storage_url)
- github_commits (id, workflow_id, commit_sha, pr_url)
```

### MongoDB Collections
```
Collections:
- test_scenarios_full (full LLM responses with prompts)
- agent_logs (detailed execution logs per agent)
- audit_trail (user actions, system events)
- llm_interactions (prompts, responses, tokens used)
```

### MinIO Buckets
```
Buckets:
- screenshots/ (PNG images from Playwright)
- videos/ (MP4 videos from Playwright)
- traces/ (Playwright trace files)
- reports/ (Allure HTML reports, zipped)
- scripts/ (Generated test scripts)
- uploads/ (User-uploaded files: Swagger, legacy docs)
```

## Deployment Considerations

### Resource Requirements (Per Container)

| Container | CPU | Memory | Disk | Replicas |
|-----------|-----|--------|------|----------|
| Angular (Nginx) | 100m | 128Mi | - | N/A (CDN) |
| FastAPI Gateway | 500m | 1Gi | - | 3 |
| Master Agent | 500m | 1Gi | - | 2 (active-passive) |
| MCP Server | 250m | 512Mi | - | 3 |
| Test Scenario Agent | 500m | 1Gi | - | 2 |
| Playwright Agent | 1000m | 2Gi | - | 3 |
| API Test Agent | 250m | 512Mi | - | 2 |
| Other Agents (6x) | 250m | 512Mi | - | 1-2 each |
| PostgreSQL | 1000m | 4Gi | 100Gi | 1+2 replicas |
| MongoDB | 500m | 2Gi | 50Gi | 3 |
| RabbitMQ | 500m | 1Gi | 10Gi | 3 |
| Redis | 250m | 512Mi | 5Gi | 3 |
| MinIO | 500m | 2Gi | 500Gi | 4 |

**Total Cluster Requirements**: ~12 CPU cores, 30GB RAM, 1TB disk (minimum for production)

## Security Between Containers

1. **Network Policies**: Kubernetes NetworkPolicies restrict pod-to-pod communication
2. **Service Mesh (Optional)**: Istio for mTLS between all services
3. **Secrets Management**: Kubernetes Secrets + External Secrets Operator
4. **TLS**: All external communication via HTTPS/WSS
5. **Authentication**: JWT tokens validated at API Gateway
6. **Authorization**: RBAC enforced at API Gateway layer

## Monitoring & Observability

Each container exposes:
- **Metrics**: Prometheus `/metrics` endpoint
- **Health**: `/health` (liveness) and `/ready` (readiness) endpoints
- **Logs**: Structured JSON logs to stdout (collected by Fluentd/Fluent Bit)
- **Traces**: OpenTelemetry instrumentation (exported to Jaeger)
