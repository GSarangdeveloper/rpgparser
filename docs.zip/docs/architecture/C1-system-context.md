# C1: System Context Diagram

## Overview
The C1 diagram shows the **IQTOP system** in the context of users and external systems it integrates with.

## Diagram

```
                    ┌──────────────────────────────────────────┐
                    │                                          │
                    │  Intelligent QA Testing Orchestration    │
                    │         Platform (IQTOP)                 │
                    │                                          │
                    │  Purpose: AI-powered test automation     │
                    │  platform for UI, API, Legacy, and       │
                    │  standalone test case generation         │
                    │                                          │
                    └────────────┬─────────────────────────────┘
                                 │
         ┌───────────────────────┼───────────────────────┐
         │                       │                       │
         ↓                       ↓                       ↓
    ┌─────────┐          ┌──────────────┐        ┌──────────────┐
    │  Admin  │          │   QA Tester  │        │   Viewer     │
    │  User   │          │              │        │  (Manager)   │
    └────┬────┘          └──────┬───────┘        └──────┬───────┘
         │                      │                       │
         │ • Manage users       │ • Create projects     │ • View reports
         │ • Configure system   │ • Start workflows     │ • Monitor status
         │ • View all projects  │ • Approve scenarios   │ • Export data
         │                      │ • View results        │
         │                      │                       │
         └──────────────────────┼───────────────────────┘
                                ↓
         ┌──────────────────────────────────────────────┐
         │          IQTOP System (Main)                 │
         │                                              │
         │  • Web UI (Angular)                          │
         │  • API Gateway (FastAPI)                     │
         │  • Orchestration Engine                      │
         │  • Agent Execution Framework                 │
         │  • Data Storage & Caching                    │
         └────┬──────────┬──────────┬──────────┬────────┘
              │          │          │          │
              ↓          ↓          ↓          ↓
    ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
    │   Azure     │ │   Figma     │ │   Rally     │ │   GitHub    │
    │  OpenAI     │ │    API      │ │  /  Jira    │ │     API     │
    │   (GPT-4)   │ │             │ │     API     │ │             │
    └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘
         ↑                ↑                ↑                ↑
         │                │                │                │
         │ • Generate     │ • Fetch        │ • Fetch        │ • Commit
         │   test cases   │   designs      │   stories      │   scripts
         │ • Analyze      │ • Parse        │ • Create       │ • Create PRs
         │   scenarios    │   components   │   defects      │ • Manage repos
         │ • Code         │                │                │
         │   generation   │                │                │
         │                │                │                │
         └────────────────┴────────────────┴────────────────┘
                              External Systems


    Additional External Integrations:

    ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
    │  Jenkins/   │  │  Slack/     │  │  Email      │  │  Azure AD/  │
    │  GitLab CI  │  │  MS Teams   │  │  SMTP       │  │  Okta       │
    └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘
         ↑                 ↑                ↑                ↑
         │                 │                │                │
         │ • Trigger       │ • Send         │ • Send         │ • SSO
         │   test runs     │   notifications│   reports      │ • User auth
         │ • Get build     │ • Alerts       │ • Alerts       │ • Groups
         │   status        │                │                │
```

## Actors

### 1. Admin User
- **Role**: System administrator
- **Responsibilities**:
  - User management (create, disable, role assignment)
  - System configuration (integrations, API keys)
  - Monitor system health
  - Access all projects

### 2. QA Tester
- **Role**: Primary user of the platform
- **Responsibilities**:
  - Create and manage testing projects
  - Initiate testing workflows (UI, API, Legacy, Standalone)
  - Review and approve AI-generated test scenarios
  - View test execution results
  - Access reports and artifacts
  - Manage defect tickets

### 3. Viewer (Manager/Stakeholder)
- **Role**: Read-only observer
- **Responsibilities**:
  - View project dashboards
  - Access test reports
  - Monitor workflow status
  - Export metrics and data
  - No create/edit permissions

## External Systems

### 1. Azure OpenAI Service
- **Purpose**: LLM provider for AI capabilities
- **Interactions**:
  - Generate test scenarios from requirements
  - Analyze Figma designs and Rally stories
  - Generate test automation scripts
  - Modernize legacy test documentation
  - Code generation and optimization
- **Models Used**: GPT-4o (128K), GPT-4 Vision

### 2. Figma API
- **Purpose**: Design collaboration tool
- **Interactions**:
  - Fetch design specifications
  - Parse UI components and layouts
  - Extract design tokens (colors, spacing, typography)
  - Analyze user flows
- **Authentication**: Figma API token

### 3. Rally / Jira API
- **Purpose**: Agile project management
- **Interactions**:
  - Fetch user stories and requirements
  - Parse acceptance criteria
  - Create defect tickets automatically
  - Update test case status
  - Link test results to stories
- **Authentication**: OAuth2 or API key

### 4. GitHub API
- **Purpose**: Version control and collaboration
- **Interactions**:
  - Clone test repositories
  - Commit generated test scripts
  - Create pull requests
  - Manage branches
  - Add reviewers and labels
- **Authentication**: GitHub App or Personal Access Token

### 5. Jenkins / GitLab CI (Optional)
- **Purpose**: CI/CD automation
- **Interactions**:
  - Trigger test execution pipelines
  - Fetch build status
  - Integrate test results into CI/CD
- **Authentication**: API token

### 6. Slack / MS Teams (Optional)
- **Purpose**: Team communication
- **Interactions**:
  - Send workflow completion notifications
  - Alert on test failures
  - Daily summary reports
- **Authentication**: Webhook URL or OAuth

### 7. Email / SMTP
- **Purpose**: Email notifications
- **Interactions**:
  - Send workflow status updates
  - Alert on critical failures
  - Weekly summary reports
- **Authentication**: SMTP credentials

### 8. Azure AD / Okta
- **Purpose**: Identity and access management
- **Interactions**:
  - Single Sign-On (SSO)
  - User authentication
  - Group/role synchronization
- **Authentication**: OAuth2 / OIDC

## Data Flow Summary

### Inbound Data
1. User inputs (Figma URLs, Swagger specs, legacy docs)
2. Figma design specifications
3. Rally/Jira user stories
4. GitHub repository metadata
5. User authentication tokens

### Outbound Data
1. Test automation scripts (to GitHub)
2. Defect tickets (to Rally/Jira)
3. Test execution reports (to users)
4. Notifications (to Slack/Email)
5. Metrics and logs (to monitoring systems)

## System Boundaries

### Inside IQTOP
- Web application interface
- API gateway and backend services
- Workflow orchestration engine
- AI agent execution framework
- Test execution engines (Playwright, pytest)
- Database and storage systems
- Message queues and caching

### Outside IQTOP
- External LLM providers (Azure OpenAI)
- Design tools (Figma)
- Project management tools (Rally, Jira)
- Version control systems (GitHub)
- CI/CD platforms (Jenkins, GitLab)
- Communication tools (Slack, Email)
- Identity providers (Azure AD, Okta)

## Key Characteristics

| Aspect | Description |
|--------|-------------|
| **Type** | Web-based SaaS platform |
| **Users** | 3 role types: Admin, Tester, Viewer |
| **Scale** | Enterprise-ready (100+ concurrent users) |
| **Availability** | 99.9% uptime SLA |
| **Security** | OAuth2, JWT, RBAC, TLS 1.3 |
| **Deployment** | Kubernetes (cloud-native) |
| **Integration Points** | 8+ external systems via REST APIs |

## Business Value

1. **Time Savings**: 70-80% reduction in test creation time
2. **Quality Improvement**: AI-generated comprehensive test coverage
3. **Consistency**: Standardized test formats and patterns
4. **Automation**: End-to-end workflow from requirements to execution
5. **Visibility**: Real-time dashboards and comprehensive reporting
6. **Maintainability**: Auto-generated, well-structured test code

## Non-Functional Requirements

- **Performance**: Workflow completion < 5 minutes (90th percentile)
- **Scalability**: Support 500+ concurrent workflows
- **Reliability**: 99.9% availability, automatic failover
- **Security**: SOC 2 compliant, GDPR ready
- **Usability**: Intuitive UI, minimal training required
- **Maintainability**: Modular architecture, 80%+ test coverage
