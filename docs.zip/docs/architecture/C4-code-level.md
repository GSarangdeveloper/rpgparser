# C4: Code-Level Architecture

## Overview
The C4 diagram shows **code-level patterns**, class structures, key interfaces, and implementation details for critical components.

---

## 1. FastAPI Gateway - Workflow Router (Python)

### File: `api/v1/workflows.py`

```python
from fastapi import APIRouter, Depends, HTTPException, status
from typing import Dict, Any
from uuid import UUID

from schemas.workflow_schema import (
    UIWorkflowCreate,
    WorkflowResponse,
    WorkflowApproval
)
from services.workflow_service import WorkflowService
from services.auth_service import get_current_user
from db.models import User

router = APIRouter(prefix="/workflows", tags=["workflows"])


@router.post("/ui-test", response_model=WorkflowResponse, status_code=status.HTTP_202_ACCEPTED)
async def create_ui_workflow(
    workflow: UIWorkflowCreate,
    current_user: User = Depends(get_current_user),
    workflow_service: WorkflowService = Depends()
) -> WorkflowResponse:
    """
    Create a new UI testing workflow.

    Args:
        workflow: UI workflow creation request (Figma URL, Rally story)
        current_user: Authenticated user (from JWT)
        workflow_service: Injected workflow service

    Returns:
        WorkflowResponse with workflow_id and status

    Raises:
        HTTPException: If project not found or validation fails
    """
    try:
        # Create workflow in database
        workflow_obj = await workflow_service.create_workflow(
            project_id=workflow.project_id,
            test_type="ui",
            input_data={
                "figma_url": workflow.figma_url,
                "rally_story_id": workflow.rally_story_id,
            },
            created_by=current_user.id
        )

        # Publish to RabbitMQ asynchronously
        await workflow_service.publish_workflow_message(
            queue_name="start_ui_workflow",
            workflow_id=workflow_obj.id,
            input_data=workflow_obj.input_data
        )

        # Return immediate response
        return WorkflowResponse(
            workflow_id=workflow_obj.id,
            status=workflow_obj.status,
            message="Workflow initiated successfully"
        )

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create workflow"
        )


@router.post("/{workflow_id}/approve", response_model=WorkflowResponse)
async def approve_workflow(
    workflow_id: UUID,
    approval: WorkflowApproval,
    current_user: User = Depends(get_current_user),
    workflow_service: WorkflowService = Depends()
) -> WorkflowResponse:
    """
    Approve test scenarios and resume workflow.

    Args:
        workflow_id: UUID of the workflow
        approval: Approval decision (approved, edited_scenarios)
        current_user: Authenticated user
        workflow_service: Injected service

    Returns:
        Updated workflow status
    """
    # Update approval in database
    await workflow_service.approve_scenarios(
        workflow_id=workflow_id,
        approved_by=current_user.id,
        edited_scenarios=approval.edited_scenarios
    )

    # Publish resume message to RabbitMQ
    await workflow_service.publish_resume_message(workflow_id)

    return WorkflowResponse(
        workflow_id=workflow_id,
        status="resumed",
        message="Workflow resumed successfully"
    )


@router.get("/{workflow_id}", response_model=WorkflowResponse)
async def get_workflow_status(
    workflow_id: UUID,
    current_user: User = Depends(get_current_user),
    workflow_service: WorkflowService = Depends()
) -> WorkflowResponse:
    """Get current workflow status with phase details."""
    workflow = await workflow_service.get_workflow(workflow_id)

    if not workflow:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workflow not found"
        )

    return WorkflowResponse.from_orm(workflow)
```

### Schema Definition

### File: `schemas/workflow_schema.py`

```python
from pydantic import BaseModel, HttpUrl, Field, UUID4
from typing import Optional, Dict, Any, List
from enum import Enum

class TestType(str, Enum):
    UI = "ui"
    API = "api"
    LEGACY = "legacy"
    STANDALONE = "standalone"

class WorkflowStatus(str, Enum):
    PENDING = "pending"
    PHASE_1_GENERATING = "phase_1_generating"
    PHASE_2_AWAITING_REVIEW = "phase_2_awaiting_review"
    PHASE_3_EXECUTING = "phase_3_executing"
    # ... other phases
    COMPLETED = "completed"
    FAILED = "failed"

class UIWorkflowCreate(BaseModel):
    """Request schema for creating UI testing workflow."""
    project_id: UUID4
    figma_url: HttpUrl = Field(..., description="Figma design URL")
    rally_story_id: str = Field(..., min_length=1, description="Rally user story ID")

    class Config:
        json_schema_extra = {
            "example": {
                "project_id": "123e4567-e89b-12d3-a456-426614174000",
                "figma_url": "https://www.figma.com/file/ABC123/Design",
                "rally_story_id": "US12345"
            }
        }

class WorkflowResponse(BaseModel):
    """Response schema for workflow operations."""
    workflow_id: UUID4
    status: WorkflowStatus
    current_phase: Optional[int] = None
    message: Optional[str] = None
    artifacts: Optional[List[Dict[str, Any]]] = None

    class Config:
        from_attributes = True  # Pydantic v2 (was orm_mode in v1)

class WorkflowApproval(BaseModel):
    """Request schema for approving scenarios."""
    approved: bool = True
    edited_scenarios: Optional[List[Dict[str, Any]]] = None
    comments: Optional[str] = None
```

---

## 2. Master Agent - Workflow Orchestrator (Python + LangGraph)

### File: `orchestrator/ui_testing_workflow.py`

```python
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated, Sequence
import operator
from uuid import UUID

from mcp_client.mcp_client import MCPClient
from persistence.workflow_state_manager import WorkflowStateManager


class WorkflowState(TypedDict):
    """State object passed through the workflow graph."""
    workflow_id: UUID
    project_id: UUID
    input_data: dict
    test_scenarios: Annotated[list, operator.add]  # Accumulate scenarios
    test_results: dict
    defect_ids: list
    generated_scripts: list
    report_urls: list
    github_commit: dict
    error: str | None
    current_phase: int


class UITestingWorkflow:
    """8-phase UI testing workflow using LangGraph."""

    def __init__(self, mcp_client: MCPClient, state_manager: WorkflowStateManager):
        self.mcp_client = mcp_client
        self.state_manager = state_manager
        self.graph = self._build_graph()

    def _build_graph(self) -> StateGraph:
        """Build the LangGraph state machine."""
        workflow = StateGraph(WorkflowState)

        # Add nodes (phases)
        workflow.add_node("phase_1_generate_scenarios", self.phase_1_generate_scenarios)
        workflow.add_node("phase_2_await_approval", self.phase_2_await_approval)
        workflow.add_node("phase_3_execute_tests", self.phase_3_execute_tests)
        workflow.add_node("phase_4_log_defects", self.phase_4_log_defects)
        workflow.add_node("phase_5_generate_scripts", self.phase_5_generate_scripts)
        workflow.add_node("phase_6_create_reports", self.phase_6_create_reports)
        workflow.add_node("phase_7_regression_analysis", self.phase_7_regression_analysis)
        workflow.add_node("phase_8_commit_to_github", self.phase_8_commit_to_github)

        # Define edges (workflow flow)
        workflow.set_entry_point("phase_1_generate_scenarios")
        workflow.add_edge("phase_1_generate_scenarios", "phase_2_await_approval")
        # phase_2 is a PAUSE node - will resume via external trigger
        workflow.add_edge("phase_2_await_approval", "phase_3_execute_tests")
        workflow.add_edge("phase_3_execute_tests", "phase_4_log_defects")
        workflow.add_edge("phase_4_log_defects", "phase_5_generate_scripts")
        workflow.add_edge("phase_5_generate_scripts", "phase_6_create_reports")
        workflow.add_edge("phase_6_create_reports", "phase_7_regression_analysis")
        workflow.add_edge("phase_7_regression_analysis", "phase_8_commit_to_github")
        workflow.add_edge("phase_8_commit_to_github", END)

        return workflow.compile()

    async def phase_1_generate_scenarios(self, state: WorkflowState) -> WorkflowState:
        """Phase 1: Generate test scenarios using LLM."""
        print(f"[Phase 1] Generating scenarios for workflow {state['workflow_id']}")

        # Update status in database
        await self.state_manager.update_phase_status(
            workflow_id=state["workflow_id"],
            phase=1,
            status="in_progress"
        )

        # Call MCP tool
        result = await self.mcp_client.call_tool(
            tool_name="generate_test_scenarios",
            figma_url=state["input_data"]["figma_url"],
            rally_story_id=state["input_data"]["rally_story_id"]
        )

        if result["status"] == "success":
            state["test_scenarios"] = result["scenarios"]
            state["current_phase"] = 1

            # Save scenarios to database
            await self.state_manager.save_scenarios(
                workflow_id=state["workflow_id"],
                scenarios=result["scenarios"]
            )

            await self.state_manager.update_phase_status(
                workflow_id=state["workflow_id"],
                phase=1,
                status="completed"
            )
        else:
            state["error"] = result.get("error", "Unknown error")
            await self.state_manager.update_phase_status(
                workflow_id=state["workflow_id"],
                phase=1,
                status="failed",
                error=state["error"]
            )

        return state

    async def phase_2_await_approval(self, state: WorkflowState) -> WorkflowState:
        """Phase 2: Human-in-the-loop approval (PAUSE node)."""
        print(f"[Phase 2] Awaiting approval for workflow {state['workflow_id']}")

        # Update status to awaiting review
        await self.state_manager.update_workflow_status(
            workflow_id=state["workflow_id"],
            status="PHASE_2_AWAITING_REVIEW"
        )

        # Publish to Redis PubSub for WebSocket push
        await self.state_manager.publish_status_update(
            workflow_id=state["workflow_id"],
            status="awaiting_review",
            data={"scenarios": state["test_scenarios"]}
        )

        # This node effectively pauses the workflow
        # Workflow will resume when Master Agent receives "resume_workflow" message
        state["current_phase"] = 2

        # Save checkpoint
        await self.state_manager.save_checkpoint(state)

        return state

    async def phase_3_execute_tests(self, state: WorkflowState) -> WorkflowState:
        """Phase 3: Execute Playwright tests."""
        print(f"[Phase 3] Executing tests for workflow {state['workflow_id']}")

        await self.state_manager.update_workflow_status(
            workflow_id=state["workflow_id"],
            status="PHASE_3_EXECUTING_TESTS"
        )

        # Call Playwright agent
        result = await self.mcp_client.call_tool(
            tool_name="execute_functional_tests",
            scenarios=state["test_scenarios"],
            target_url=state["input_data"].get("target_url", "https://staging.example.com")
        )

        state["test_results"] = result
        state["current_phase"] = 3

        return state

    # ... phases 4-8 follow similar pattern ...

    async def execute(self, initial_state: WorkflowState) -> WorkflowState:
        """Execute the workflow from start or resume from checkpoint."""
        # Check if there's a checkpoint
        checkpoint = await self.state_manager.load_checkpoint(initial_state["workflow_id"])

        if checkpoint:
            print(f"Resuming workflow from phase {checkpoint['current_phase']}")
            state = checkpoint
        else:
            state = initial_state

        # Run the graph
        final_state = await self.graph.ainvoke(state)

        return final_state
```

---

## 3. MCP Client (Python)

### File: `mcp_client/mcp_client.py`

```python
import httpx
from typing import Dict, Any
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type
)
import structlog

logger = structlog.get_logger()


class MCPClient:
    """Client for communicating with MCP Server."""

    def __init__(self, mcp_server_url: str, timeout: int = 300):
        self.mcp_server_url = mcp_server_url
        self.timeout = timeout
        self.client = httpx.AsyncClient(timeout=timeout)

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError))
    )
    async def call_tool(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        """
        Call a tool via MCP Server.

        Args:
            tool_name: Name of the tool (e.g., "generate_test_scenarios")
            **kwargs: Tool-specific parameters

        Returns:
            Dict containing tool execution result

        Raises:
            httpx.HTTPStatusError: If MCP server returns error
            httpx.TimeoutException: If request times out
        """
        logger.info(
            "mcp_call_tool",
            tool_name=tool_name,
            params=kwargs
        )

        url = f"{self.mcp_server_url}/mcp/v1/call_tool"

        payload = {
            "tool_name": tool_name,
            "parameters": kwargs
        }

        try:
            response = await self.client.post(url, json=payload)
            response.raise_for_status()

            result = response.json()

            logger.info(
                "mcp_call_tool_success",
                tool_name=tool_name,
                status=result.get("status")
            )

            return result

        except httpx.HTTPStatusError as e:
            logger.error(
                "mcp_call_tool_http_error",
                tool_name=tool_name,
                status_code=e.response.status_code,
                error=str(e)
            )
            return {
                "status": "error",
                "error": f"MCP Server error: {e.response.status_code}"
            }

        except httpx.TimeoutException:
            logger.error(
                "mcp_call_tool_timeout",
                tool_name=tool_name,
                timeout=self.timeout
            )
            raise

        except Exception as e:
            logger.error(
                "mcp_call_tool_unexpected_error",
                tool_name=tool_name,
                error=str(e)
            )
            return {
                "status": "error",
                "error": f"Unexpected error: {str(e)}"
            }

    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()
```

---

## 4. Angular - Workflow Service (TypeScript)

### File: `src/app/services/workflow.service.ts`

```typescript
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { io, Socket } from 'socket.io-client';
import { environment } from '../../environments/environment';

export interface UIWorkflowCreate {
  project_id: string;
  figma_url: string;
  rally_story_id: string;
}

export interface WorkflowResponse {
  workflow_id: string;
  status: string;
  current_phase?: number;
  message?: string;
  artifacts?: any[];
}

export interface WorkflowStatusUpdate {
  workflow_id: string;
  status: string;
  phase: number;
  data?: any;
}

@Injectable({
  providedIn: 'root'
})
export class WorkflowService {
  private apiUrl = `${environment.apiUrl}/api/v1/workflows`;
  private socket: Socket;
  private workflowUpdates$ = new Subject<WorkflowStatusUpdate>();

  constructor(private http: HttpClient) {
    this.initializeWebSocket();
  }

  /**
   * Initialize WebSocket connection for real-time updates
   */
  private initializeWebSocket(): void {
    this.socket = io(environment.wsUrl, {
      auth: {
        token: localStorage.getItem('access_token')
      },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5
    });

    this.socket.on('connect', () => {
      console.log('[WebSocket] Connected');
    });

    this.socket.on('workflow_update', (data: WorkflowStatusUpdate) => {
      console.log('[WebSocket] Workflow update:', data);
      this.workflowUpdates$.next(data);
    });

    this.socket.on('disconnect', (reason: string) => {
      console.log('[WebSocket] Disconnected:', reason);
    });

    this.socket.on('error', (error: any) => {
      console.error('[WebSocket] Error:', error);
    });
  }

  /**
   * Create a new UI testing workflow
   */
  createUIWorkflow(workflow: UIWorkflowCreate): Observable<WorkflowResponse> {
    return this.http.post<WorkflowResponse>(
      `${this.apiUrl}/ui-test`,
      workflow
    );
  }

  /**
   * Approve test scenarios and resume workflow
   */
  approveWorkflow(
    workflowId: string,
    editedScenarios?: any[]
  ): Observable<WorkflowResponse> {
    return this.http.post<WorkflowResponse>(
      `${this.apiUrl}/${workflowId}/approve`,
      {
        approved: true,
        edited_scenarios: editedScenarios
      }
    );
  }

  /**
   * Get current workflow status
   */
  getWorkflowStatus(workflowId: string): Observable<WorkflowResponse> {
    return this.http.get<WorkflowResponse>(`${this.apiUrl}/${workflowId}`);
  }

  /**
   * Subscribe to workflow updates via WebSocket
   */
  subscribeToWorkflowUpdates(): Observable<WorkflowStatusUpdate> {
    return this.workflowUpdates$.asObservable();
  }

  /**
   * Join a specific workflow room for targeted updates
   */
  joinWorkflowRoom(workflowId: string): void {
    this.socket.emit('join_workflow', { workflow_id: workflowId });
  }

  /**
   * Leave workflow room
   */
  leaveWorkflowRoom(workflowId: string): void {
    this.socket.emit('leave_workflow', { workflow_id: workflowId });
  }

  /**
   * Disconnect WebSocket (called on service destroy)
   */
  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
    }
  }
}
```

---

## 5. Angular - Workflow Status Component (TypeScript + HTML)

### File: `src/app/components/workflow-status/workflow-status.component.ts`

```typescript
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject, takeUntil, interval } from 'rxjs';
import { WorkflowService, WorkflowResponse, WorkflowStatusUpdate } from '../../services/workflow.service';

@Component({
  selector: 'app-workflow-status',
  templateUrl: './workflow-status.component.html',
  styleUrls: ['./workflow-status.component.scss']
})
export class WorkflowStatusComponent implements OnInit, OnDestroy {
  workflowId: string;
  workflow: WorkflowResponse;
  phases: PhaseInfo[] = [];
  isLoading = true;
  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private workflowService: WorkflowService
  ) {}

  ngOnInit(): void {
    // Get workflow ID from route
    this.workflowId = this.route.snapshot.paramMap.get('id');

    // Load initial workflow status
    this.loadWorkflowStatus();

    // Subscribe to real-time updates
    this.subscribeToUpdates();

    // Join workflow room for targeted WebSocket updates
    this.workflowService.joinWorkflowRoom(this.workflowId);

    // Poll for status every 5 seconds as fallback
    interval(5000)
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        if (!this.isWorkflowComplete()) {
          this.loadWorkflowStatus();
        }
      });
  }

  ngOnDestroy(): void {
    this.workflowService.leaveWorkflowRoom(this.workflowId);
    this.destroy$.next();
    this.destroy$.complete();
  }

  private loadWorkflowStatus(): void {
    this.workflowService.getWorkflowStatus(this.workflowId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (workflow) => {
          this.workflow = workflow;
          this.updatePhases();
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error loading workflow:', error);
          this.isLoading = false;
        }
      });
  }

  private subscribeToUpdates(): void {
    this.workflowService.subscribeToWorkflowUpdates()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (update: WorkflowStatusUpdate) => {
          if (update.workflow_id === this.workflowId) {
            console.log('Real-time update:', update);
            this.handleStatusUpdate(update);
          }
        }
      });
  }

  private handleStatusUpdate(update: WorkflowStatusUpdate): void {
    // Update workflow status
    this.workflow.status = update.status;
    this.workflow.current_phase = update.phase;

    // Update phases visualization
    this.updatePhases();

    // Show notification
    this.showNotification(update);
  }

  private updatePhases(): void {
    this.phases = [
      { number: 1, name: 'Generate Scenarios', status: this.getPhaseStatus(1) },
      { number: 2, name: 'Await Approval', status: this.getPhaseStatus(2) },
      { number: 3, name: 'Execute Tests', status: this.getPhaseStatus(3) },
      { number: 4, name: 'Log Defects', status: this.getPhaseStatus(4) },
      { number: 5, name: 'Generate Scripts', status: this.getPhaseStatus(5) },
      { number: 6, name: 'Create Reports', status: this.getPhaseStatus(6) },
      { number: 7, name: 'Regression Analysis', status: this.getPhaseStatus(7) },
      { number: 8, name: 'Commit to GitHub', status: this.getPhaseStatus(8) }
    ];
  }

  private getPhaseStatus(phaseNumber: number): 'pending' | 'in_progress' | 'completed' {
    if (this.workflow.current_phase > phaseNumber) {
      return 'completed';
    } else if (this.workflow.current_phase === phaseNumber) {
      return 'in_progress';
    } else {
      return 'pending';
    }
  }

  private isWorkflowComplete(): boolean {
    return this.workflow?.status === 'completed' || this.workflow?.status === 'failed';
  }

  private showNotification(update: WorkflowStatusUpdate): void {
    // Implementation for toast/snackbar notification
  }
}

interface PhaseInfo {
  number: number;
  name: string;
  status: 'pending' | 'in_progress' | 'completed';
}
```

---

## 6. Database Models (SQLAlchemy)

### File: `db/models.py`

```python
from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, Enum, ForeignKey, TIMESTAMP, BigInteger
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum

Base = declarative_base()


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    TESTER = "tester"
    VIEWER = "viewer"


class TestType(str, enum.Enum):
    UI = "ui"
    API = "api"
    LEGACY = "legacy"
    STANDALONE = "standalone"


class WorkflowStatus(str, enum.Enum):
    PENDING = "pending"
    PHASE_1_GENERATING = "phase_1_generating"
    PHASE_2_AWAITING_REVIEW = "phase_2_awaiting_review"
    PHASE_3_EXECUTING = "phase_3_executing"
    # ... other phases
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class User(Base):
    """User model for authentication and authorization."""
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    role = Column(Enum(UserRole), default=UserRole.TESTER, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())

    # Relationships
    projects = relationship("Project", back_populates="creator")
    workflows = relationship("Workflow", back_populates="creator")


class Project(Base):
    """Project model."""
    __tablename__ = "projects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    github_repo_url = Column(String(500))
    rally_project_id = Column(String(100))
    jira_project_key = Column(String(50))
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())

    # Relationships
    creator = relationship("User", back_populates="projects")
    workflows = relationship("Workflow", back_populates="project", cascade="all, delete-orphan")


class Workflow(Base):
    """Workflow model."""
    __tablename__ = "workflows"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    test_type = Column(Enum(TestType), nullable=False)
    status = Column(Enum(WorkflowStatus), default=WorkflowStatus.PENDING, nullable=False)
    current_phase = Column(Integer, default=1)
    input_data = Column(JSONB, nullable=False)  # Figma URL, Rally story, etc.
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())

    # Relationships
    project = relationship("Project", back_populates="workflows")
    creator = relationship("User", back_populates="workflows")
    phases = relationship("WorkflowPhase", back_populates="workflow", cascade="all, delete-orphan")
    test_scenarios = relationship("TestScenario", back_populates="workflow", cascade="all, delete-orphan")

    # Indexes
    __table_args__ = (
        {"comment": "Stores workflow metadata and current status"}
    )


class WorkflowPhase(Base):
    """Workflow phase execution tracking."""
    __tablename__ = "workflow_phases"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workflow_id = Column(UUID(as_uuid=True), ForeignKey("workflows.id", ondelete="CASCADE"), nullable=False)
    phase_number = Column(Integer, nullable=False)
    phase_name = Column(String(100), nullable=False)
    agent_name = Column(String(100))
    status = Column(String(50), default="pending")
    input_data = Column(JSONB)
    output_data = Column(JSONB)
    error_message = Column(Text)
    started_at = Column(TIMESTAMP)
    completed_at = Column(TIMESTAMP)

    # Relationships
    workflow = relationship("Workflow", back_populates="phases")


class TestScenario(Base):
    """Test scenarios generated by LLM."""
    __tablename__ = "test_scenarios"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workflow_id = Column(UUID(as_uuid=True), ForeignKey("workflows.id", ondelete="CASCADE"), nullable=False)
    scenario_json = Column(JSONB, nullable=False)  # Full scenario with steps
    approved = Column(Boolean, default=False)
    approved_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    approved_at = Column(TIMESTAMP)
    created_at = Column(TIMESTAMP, server_default=func.now())

    # Relationships
    workflow = relationship("Workflow", back_populates="test_scenarios")
```

---

## 7. Key Design Patterns Used

### Repository Pattern (Data Access Layer)
```python
# db/repositories/workflow_repository.py

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional, List
from uuid import UUID

from db.models import Workflow


class WorkflowRepository:
    """Repository for Workflow database operations."""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, workflow: Workflow) -> Workflow:
        """Create a new workflow."""
        self.session.add(workflow)
        await self.session.commit()
        await self.session.refresh(workflow)
        return workflow

    async def get_by_id(self, workflow_id: UUID) -> Optional[Workflow]:
        """Get workflow by ID."""
        result = await self.session.execute(
            select(Workflow).where(Workflow.id == workflow_id)
        )
        return result.scalar_one_or_none()

    async def update_status(self, workflow_id: UUID, status: str) -> None:
        """Update workflow status."""
        workflow = await self.get_by_id(workflow_id)
        if workflow:
            workflow.status = status
            await self.session.commit()

    async def list_by_project(self, project_id: UUID) -> List[Workflow]:
        """List workflows for a project."""
        result = await self.session.execute(
            select(Workflow)
            .where(Workflow.project_id == project_id)
            .order_by(Workflow.created_at.desc())
        )
        return result.scalars().all()
```

### Dependency Injection (FastAPI)
```python
# dependencies.py

from sqlalchemy.ext.asyncio import AsyncSession
from db.session import async_session
from services.workflow_service import WorkflowService


async def get_db_session() -> AsyncSession:
    """Dependency that provides database session."""
    async with async_session() as session:
        yield session


async def get_workflow_service(
    db: AsyncSession = Depends(get_db_session)
) -> WorkflowService:
    """Dependency that provides WorkflowService."""
    return WorkflowService(db)
```

### Circuit Breaker Pattern (MCP Server)
```python
# mcp_server/health/circuit_breaker.py

from enum import Enum
from datetime import datetime, timedelta


class CircuitState(Enum):
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if recovered


class CircuitBreaker:
    """Circuit breaker for agent health management."""

    def __init__(
        self,
        failure_threshold: int = 5,
        timeout: int = 60,
        expected_exception: type = Exception
    ):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.expected_exception = expected_exception

        self.failure_count = 0
        self.last_failure_time = None
        self.state = CircuitState.CLOSED

    def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker protection."""
        if self.state == CircuitState.OPEN:
            if self._should_attempt_reset():
                self.state = CircuitState.HALF_OPEN
            else:
                raise Exception("Circuit breaker is OPEN")

        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except self.expected_exception as e:
            self._on_failure()
            raise

    def _on_success(self):
        """Handle successful call."""
        self.failure_count = 0
        self.state = CircuitState.CLOSED

    def _on_failure(self):
        """Handle failed call."""
        self.failure_count += 1
        self.last_failure_time = datetime.now()

        if self.failure_count >= self.failure_threshold:
            self.state = CircuitState.OPEN

    def _should_attempt_reset(self) -> bool:
        """Check if should attempt to reset circuit."""
        return (
            self.last_failure_time is not None and
            datetime.now() >= self.last_failure_time + timedelta(seconds=self.timeout)
        )
```

---

## Summary

This C4 level documentation provides:

1. **Code Examples**: Real implementation patterns for key components
2. **Class Structures**: Actual class definitions with methods
3. **Design Patterns**: Repository, Dependency Injection, Circuit Breaker
4. **Type Safety**: Strong typing with Pydantic, TypeScript, SQLAlchemy
5. **Error Handling**: Retry logic, circuit breakers, exception handling
6. **Real-time Communication**: WebSocket integration patterns
7. **Database Models**: SQLAlchemy ORM models with relationships

These patterns can be directly used as templates for implementation.
