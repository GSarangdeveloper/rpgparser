# C3: Component Architecture Diagram

## Overview
The C3 diagram shows the **internal components** within key containers, their responsibilities, and interactions.

---

## 1. Angular Frontend (SPA) Components

```
┌─────────────────────────────────────────────────────────────────┐
│                    Angular Application                          │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Core Module                                              │ │
│  │  • AuthService (JWT management, login/logout)             │ │
│  │  • AuthGuard (route protection)                           │ │
│  │  • HttpInterceptor (add auth headers, error handling)     │ │
│  │  • WebSocketService (Socket.IO client, reconnection)      │ │
│  │  • NotificationService (toast messages, alerts)           │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Shared Module                                            │ │
│  │  • UI Components (buttons, cards, modals)                 │ │
│  │  • Pipes (date formatting, file size, status color)       │ │
│  │  • Directives (permissions, tooltips)                     │ │
│  │  • Validators (custom form validators)                    │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Feature Modules                                          │ │
│  │                                                            │ │
│  │  ┌────────────────────────────────────────────────────┐  │ │
│  │  │ Project Module                                     │  │ │
│  │  │ • ProjectListComponent                             │  │ │
│  │  │ • ProjectDetailComponent                           │  │ │
│  │  │ • ProjectCreateComponent                           │  │ │
│  │  │ • ProjectService (API calls)                       │  │ │
│  │  │ • ProjectState (NgRx store)                        │  │ │
│  │  └────────────────────────────────────────────────────┘  │ │
│  │                                                            │ │
│  │  ┌────────────────────────────────────────────────────┐  │ │
│  │  │ Workflow Module                                    │  │ │
│  │  │ • WorkflowWizardComponent (4 test types)           │  │ │
│  │  │ • WorkflowStatusComponent (real-time monitoring)   │  │ │
│  │  │ • ApprovalInterfaceComponent (review scenarios)    │  │ │
│  │  │ • WorkflowHistoryComponent                         │  │ │
│  │  │ • WorkflowService (API calls, WebSocket)           │  │ │
│  │  │ • WorkflowState (NgRx store)                       │  │ │
│  │  └────────────────────────────────────────────────────┘  │ │
│  │                                                            │ │
│  │  ┌────────────────────────────────────────────────────┐  │ │
│  │  │ Artifact Module                                    │  │ │
│  │  │ • ArtifactViewerComponent (reports, scripts)       │  │ │
│  │  │ • MonacoEditorComponent (code viewer/editor)       │  │ │
│  │  │ • ReportViewerComponent (Allure, Playwright)       │  │ │
│  │  │ • ArtifactService (download, upload)               │  │ │
│  │  └────────────────────────────────────────────────────┘  │ │
│  │                                                            │ │
│  │  ┌────────────────────────────────────────────────────┐  │ │
│  │  │ Dashboard Module                                   │  │ │
│  │  │ • DashboardComponent (metrics, charts)             │  │ │
│  │  │ • MetricsWidgetComponent                           │  │ │
│  │  │ • RecentWorkflowsComponent                         │  │ │
│  │  │ • DashboardService                                 │  │ │
│  │  └────────────────────────────────────────────────────┘  │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  State Management (NgRx)                                  │ │
│  │  • app.state.ts (root state)                              │ │
│  │  • auth/ (actions, reducers, effects, selectors)          │ │
│  │  • projects/ (CRUD operations)                            │ │
│  │  • workflows/ (workflow lifecycle)                        │ │
│  │  • artifacts/ (artifact management)                       │ │
│  └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. FastAPI Gateway Components

```
┌─────────────────────────────────────────────────────────────────┐
│                   FastAPI Gateway Service                       │
│                                                                 │
│  main.py (FastAPI application instance, middleware setup)      │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  API Router Layer                                         │ │
│  │                                                            │ │
│  │  /api/v1/                                                  │ │
│  │    ├── auth.py (login, logout, refresh token, user info)  │ │
│  │    ├── projects.py (CRUD for projects)                    │ │
│  │    ├── workflows.py (create, approve, cancel workflows)   │ │
│  │    ├── artifacts.py (list, download artifacts)            │ │
│  │    ├── users.py (user management - admin only)            │ │
│  │    └── health.py (liveness, readiness probes)             │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  WebSocket Layer                                          │ │
│  │                                                            │ │
│  │  websocket.py                                              │ │
│  │    • ConnectionManager (manage client connections)        │ │
│  │    • handle_connect() (authenticate, add to pool)         │ │
│  │    • handle_disconnect()                                  │ │
│  │    • broadcast_workflow_update() (to specific client)     │ │
│  │    • RedisSubscriber (listen to Redis PubSub)             │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Service Layer                                            │ │
│  │                                                            │ │
│  │  services/                                                 │ │
│  │    ├── auth_service.py                                    │ │
│  │    │    • authenticate_user()                             │ │
│  │    │    • create_access_token()                           │ │
│  │    │    • verify_token()                                  │ │
│  │    │                                                       │ │
│  │    ├── workflow_service.py                                │ │
│  │    │    • create_workflow()                               │ │
│  │    │    • approve_scenarios()                             │ │
│  │    │    • cancel_workflow()                               │ │
│  │    │    • get_workflow_status()                           │ │
│  │    │                                                       │ │
│  │    ├── project_service.py                                 │ │
│  │    │    • create_project()                                │ │
│  │    │    • list_projects()                                 │ │
│  │    │    • update_project()                                │ │
│  │    │                                                       │ │
│  │    ├── rabbitmq_publisher.py                              │ │
│  │    │    • publish_workflow_message()                      │ │
│  │    │    • publish_resume_message()                        │ │
│  │    │                                                       │ │
│  │    └── redis_service.py                                   │ │
│  │         • get_cached_workflow()                           │ │
│  │         • set_cached_workflow()                           │ │
│  │         • publish_status_update()                         │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Data Access Layer (DAL)                                  │ │
│  │                                                            │ │
│  │  db/                                                       │ │
│  │    ├── postgres_dal.py (SQLAlchemy ORM)                   │ │
│  │    │    • UserDAL, ProjectDAL, WorkflowDAL                │ │
│  │    │    • CRUD operations                                 │ │
│  │    │                                                       │ │
│  │    ├── mongodb_dal.py (Motor async driver)                │ │
│  │    │    • get_test_scenarios()                            │ │
│  │    │    • save_audit_log()                                │ │
│  │    │                                                       │ │
│  │    └── models.py (SQLAlchemy models)                      │ │
│  │         • User, Project, Workflow, WorkflowPhase, etc.    │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Middleware                                               │ │
│  │                                                            │ │
│  │  middleware/                                               │ │
│  │    ├── auth_middleware.py (verify JWT on protected routes)│ │
│  │    ├── rate_limit_middleware.py (slowapi)                 │ │
│  │    ├── cors_middleware.py (configure CORS)                │ │
│  │    ├── error_handler.py (global exception handling)       │ │
│  │    └── logging_middleware.py (request/response logging)   │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Schemas (Pydantic v2 Models)                             │ │
│  │                                                            │ │
│  │  schemas/                                                  │ │
│  │    ├── user_schema.py (UserCreate, UserResponse)          │ │
│  │    ├── project_schema.py (ProjectCreate, ProjectDetail)   │ │
│  │    ├── workflow_schema.py (WorkflowCreate, WorkflowStatus)│ │
│  │    └── artifact_schema.py                                 │ │
│  └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Master Agent Components

```
┌─────────────────────────────────────────────────────────────────┐
│                   Master Agent Service                          │
│                                                                 │
│  main.py (start RabbitMQ consumer, leader election)            │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Workflow Orchestrator (LangGraph State Machine)          │ │
│  │                                                            │ │
│  │  orchestrator/                                             │ │
│  │    ├── state_machine.py                                   │ │
│  │    │    • WorkflowState (Pydantic model)                  │ │
│  │    │    • StateGraph (LangGraph graph definition)         │ │
│  │    │    • Node functions for each phase                   │ │
│  │    │                                                       │ │
│  │    ├── ui_testing_workflow.py                             │ │
│  │    │    • phase_1_generate_scenarios()                    │ │
│  │    │    • phase_2_await_approval() [PAUSE node]           │ │
│  │    │    • phase_3_execute_tests()                         │ │
│  │    │    • phase_4_log_defects()                           │ │
│  │    │    • phase_5_generate_scripts()                      │ │
│  │    │    • phase_6_create_reports()                        │ │
│  │    │    • phase_7_regression_analysis()                   │ │
│  │    │    • phase_8_commit_to_github()                      │ │
│  │    │                                                       │ │
│  │    ├── api_testing_workflow.py (similar 8 phases)         │ │
│  │    ├── legacy_testing_workflow.py                         │ │
│  │    └── standalone_testcase_workflow.py (3 phases)         │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  MCP Client                                               │ │
│  │                                                            │ │
│  │  mcp_client/                                               │ │
│  │    ├── mcp_client.py                                      │ │
│  │    │    • call_tool(tool_name, **kwargs)                  │ │
│  │    │    • retry_with_backoff()                            │ │
│  │    │    • timeout_handler()                               │ │
│  │    │                                                       │ │
│  │    └── tool_definitions.py                                │ │
│  │         • List of available tools and schemas             │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Message Consumer                                         │ │
│  │                                                            │ │
│  │  consumer/                                                 │ │
│  │    ├── rabbitmq_consumer.py                               │ │
│  │    │    • consume_from_queue()                            │ │
│  │    │    • handle_start_workflow_message()                 │ │
│  │    │    • handle_resume_workflow_message()                │ │
│  │    │    • ack_message() / nack_message()                  │ │
│  │    │                                                       │ │
│  │    └── message_handlers.py                                │ │
│  │         • route_to_workflow()                             │ │
│  │         • validate_message_schema()                       │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  State Persistence                                        │ │
│  │                                                            │ │
│  │  persistence/                                              │ │
│  │    ├── workflow_state_manager.py                          │ │
│  │    │    • save_checkpoint()                               │ │
│  │    │    • load_checkpoint()                               │ │
│  │    │    • update_phase_status()                           │ │
│  │    │                                                       │ │
│  │    └── postgres_updater.py                                │ │
│  │         • update_workflow_status()                        │ │
│  │         • create_phase_record()                           │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Error Handling & Retry                                   │ │
│  │                                                            │ │
│  │  error_handling/                                           │ │
│  │    ├── retry_policy.py (tenacity config)                  │ │
│  │    ├── error_recovery.py                                  │ │
│  │    │    • handle_agent_failure()                          │ │
│  │    │    • retry_phase()                                   │ │
│  │    │    • send_to_dead_letter_queue()                     │ │
│  │    │                                                       │ │
│  │    └── circuit_breaker.py                                 │ │
│  │         • CircuitBreaker class                            │ │
│  │         • track_failures()                                │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Leader Election                                          │ │
│  │                                                            │ │
│  │  leader_election/                                          │ │
│  │    └── redis_leader_election.py                           │ │
│  │         • acquire_lock()                                  │ │
│  │         • renew_lock()                                    │ │
│  │         • release_lock()                                  │ │
│  │         • is_leader()                                     │ │
│  └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. MCP Server Components

```
┌─────────────────────────────────────────────────────────────────┐
│                      MCP Server Service                         │
│                                                                 │
│  main.py (FastAPI app with tool registry)                      │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Tool Registry                                            │ │
│  │                                                            │ │
│  │  registry/                                                 │ │
│  │    ├── tool_registry.py                                   │ │
│  │    │    • ToolRegistry class (singleton)                  │ │
│  │    │    • register_tool(name, url, capabilities)          │ │
│  │    │    • get_tool(name) -> AgentInfo                     │ │
│  │    │    • list_tools()                                    │ │
│  │    │                                                       │ │
│  │    └── agent_discovery.py                                 │ │
│  │         • auto_discover_agents() (from env vars)          │ │
│  │         • health_check_all_agents()                       │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Router                                                   │ │
│  │                                                            │ │
│  │  router/                                                   │ │
│  │    ├── tool_router.py                                     │ │
│  │    │    • route_tool_call(tool_name, params)              │ │
│  │    │    • select_healthy_agent() (load balancing)         │ │
│  │    │    • forward_request_to_agent()                      │ │
│  │    │    • handle_agent_response()                         │ │
│  │    │                                                       │ │
│  │    └── load_balancer.py                                   │ │
│  │         • RoundRobinBalancer                              │ │
│  │         • LeastConnectionsBalancer                        │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Health Monitoring                                        │ │
│  │                                                            │ │
│  │  health/                                                   │ │
│  │    ├── health_checker.py                                  │ │
│  │    │    • check_agent_health(agent_url)                   │ │
│  │    │    • periodic_health_check() (background task)       │ │
│  │    │    • mark_agent_unhealthy()                          │ │
│  │    │                                                       │ │
│  │    └── circuit_breaker.py                                 │ │
│  │         • CircuitBreaker per agent                        │ │
│  │         • open/half-open/closed states                    │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  API Endpoints                                            │ │
│  │                                                            │ │
│  │  /mcp/v1/                                                  │ │
│  │    ├── /call_tool (POST) - main tool invocation           │ │
│  │    ├── /list_tools (GET) - list available tools           │ │
│  │    ├── /register_agent (POST) - agent self-registration   │ │
│  │    └── /health (GET) - MCP server health                  │ │
│  └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## 5. Specialized Agent Components (Example: Test Scenario Generator)

```
┌─────────────────────────────────────────────────────────────────┐
│              Test Scenario Generator Agent                      │
│                                                                 │
│  main.py (Flask/FastAPI server listening on port)              │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  API Handler                                              │ │
│  │                                                            │ │
│  │  /api/                                                     │ │
│  │    ├── /generate_scenarios (POST)                         │ │
│  │    │    • Receive: figma_url, rally_story_id              │ │
│  │    │    • Call: ScenarioGenerator.generate()              │ │
│  │    │    • Return: scenarios JSON                          │ │
│  │    │                                                       │ │
│  │    └── /health (GET)                                      │ │
│  │         • Return: status, version, uptime                 │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Core Logic                                               │ │
│  │                                                            │ │
│  │  generator/                                                │ │
│  │    ├── scenario_generator.py                              │ │
│  │    │    • generate(figma_url, rally_story)                │ │
│  │    │    • combine_context()                               │ │
│  │    │    • call_llm()                                      │ │
│  │    │    • parse_llm_response()                            │ │
│  │    │                                                       │ │
│  │    ├── figma_analyzer.py                                  │ │
│  │    │    • fetch_figma_design()                            │ │
│  │    │    • parse_components()                              │ │
│  │    │    • extract_interactions()                          │ │
│  │    │                                                       │ │
│  │    ├── rally_analyzer.py                                  │ │
│  │    │    • fetch_rally_story()                             │ │
│  │    │    • parse_acceptance_criteria()                     │ │
│  │    │    • extract_requirements()                          │ │
│  │    │                                                       │ │
│  │    └── llm_client.py                                      │ │
│  │         • LLMClient class (Azure OpenAI)                  │ │
│  │         • generate_scenarios_prompt()                     │ │
│  │         • call_openai_api()                               │ │
│  │         • handle_rate_limits()                            │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  External API Clients                                     │ │
│  │                                                            │ │
│  │  clients/                                                  │ │
│  │    ├── figma_client.py (requests to Figma API)            │ │
│  │    ├── rally_client.py (rally-restapi-python)             │ │
│  │    └── openai_client.py (openai Python SDK)               │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Utilities                                                │ │
│  │                                                            │ │
│  │  utils/                                                    │ │
│  │    ├── prompt_templates.py (Jinja2 templates)             │ │
│  │    ├── validators.py (validate LLM output)                │ │
│  │    └── logger.py (structured logging)                     │ │
│  └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

Similar structure for other agents:
- **Playwright Executor Agent**: Node.js, Playwright test runner, dynamic test generation
- **API Test Executor Agent**: Python, httpx, pytest, schema validation
- **Defect Logger Agent**: Python, Rally/Jira API clients
- **Script Generator Agent**: Python, OpenAI, Jinja2 templates
- **Report Generator Agent**: Python, Allure CLI, Playwright reporter
- **Regression Analyzer Agent**: Python, pandas, scikit-learn
- **GitHub Integrator Agent**: Python, GitPython, PyGithub
- **Legacy Modernizer Agent**: Python, Tesseract OCR, python-docx, OpenAI

---

## 6. Database Components

### PostgreSQL

```
PostgreSQL 16 Instance
├── Schemas
│   └── public (default schema)
│
├── Tables (see database-schema.md for full DDL)
│   ├── users
│   ├── projects
│   ├── workflows
│   ├── workflow_phases
│   ├── test_scenarios
│   ├── test_executions
│   ├── artifacts
│   ├── github_commits
│   ├── defects
│   └── regression_baselines
│
├── Indexes
│   ├── idx_workflows_project
│   ├── idx_workflows_status
│   ├── idx_test_executions_workflow
│   └── ... (see schema doc)
│
├── Views (optional)
│   ├── vw_workflow_summary (aggregated workflow data)
│   └── vw_test_execution_stats (pass/fail rates)
│
└── Functions
    ├── update_updated_at_column() (trigger function)
    └── calculate_workflow_duration()
```

### MongoDB

```
MongoDB Instance
├── Database: iqtop
│
├── Collections
│   ├── test_scenarios_full
│   │   • Full LLM prompt + response
│   │   • Tokens used, model version
│   │
│   ├── agent_logs
│   │   • Detailed execution logs per agent
│   │   • Stack traces, debug info
│   │
│   ├── audit_trail
│   │   • User actions (login, create, approve)
│   │   • System events (workflow start, complete)
│   │
│   └── llm_interactions
│       • All LLM API calls
│       • Prompt, completion, tokens, cost
│
└── Indexes
    ├── test_scenarios_full: workflow_id
    ├── agent_logs: agent_name, timestamp
    ├── audit_trail: user_id, timestamp
    └── llm_interactions: workflow_id, timestamp
```

---

## Component Interaction Flow (Example: UI Testing Workflow)

```
1. User submits form in Angular
   └─> WorkflowWizardComponent.onSubmit()
       └─> WorkflowService.createWorkflow()
           └─> HTTP POST /api/v1/workflows/ui-test

2. FastAPI Gateway receives request
   └─> workflows_router.create_ui_workflow()
       └─> WorkflowService.create_workflow()
           ├─> PostgreSQL: INSERT into workflows table
           ├─> RabbitMQ: Publish "start_ui_workflow" message
           └─> Return 202 Accepted to Angular

3. Master Agent consumes message
   └─> RabbitMQConsumer.on_message()
       └─> WorkflowOrchestrator.start_workflow()
           └─> ui_testing_workflow.execute()
               └─> Phase 1: Generate scenarios
                   ├─> MCPClient.call_tool("generate_test_scenarios")
                   │   └─> MCP Server routes to Test Scenario Generator Agent
                   │       └─> Agent fetches Figma + Rally, calls GPT-4
                   │           └─> Returns scenarios JSON
                   │
                   ├─> Save scenarios to PostgreSQL + MongoDB
                   ├─> Update workflow status to "PHASE_2_AWAITING_REVIEW"
                   └─> Redis: Publish status update
                       └─> FastAPI Gateway: WebSocket push to Angular
                           └─> Angular displays scenarios for approval

4. User approves scenarios
   └─> ApprovalInterfaceComponent.onApprove()
       └─> WorkflowService.approveScenarios()
           └─> HTTP POST /api/v1/workflows/{id}/approve
               └─> FastAPI Gateway
                   ├─> PostgreSQL: UPDATE test_scenarios SET approved=true
                   └─> RabbitMQ: Publish "resume_workflow" message

5. Master Agent resumes workflow
   └─> WorkflowOrchestrator.resume_workflow()
       └─> ui_testing_workflow.execute() (continue from Phase 3)
           └─> Phase 3-8: Execute remaining phases...
```

---

## Component Dependencies

### Angular SPA
- **Dependencies**: Angular core, Material, NgRx, Socket.IO client
- **External APIs**: FastAPI Gateway (REST + WebSocket)

### FastAPI Gateway
- **Dependencies**: FastAPI, Pydantic, SQLAlchemy, Motor, aio-pika (RabbitMQ), redis-py
- **External Systems**: PostgreSQL, MongoDB, RabbitMQ, Redis

### Master Agent
- **Dependencies**: LangGraph, aio-pika, redis-py, httpx
- **External Systems**: RabbitMQ, Redis, PostgreSQL, MCP Server

### MCP Server
- **Dependencies**: FastAPI, httpx
- **External Systems**: Specialized Agents (HTTP)

### Specialized Agents
- **Dependencies**: Varies (openai, playwright, pytest, etc.)
- **External Systems**: Azure OpenAI, Figma, Rally, GitHub, MinIO

---

## Summary

The C3 diagram provides a detailed view of:
1. **Internal components** within each container
2. **Responsibilities** of each component
3. **Dependencies** between components
4. **Communication patterns** (sync vs async, API calls vs events)

This level of detail is crucial for development teams to understand how to implement and extend the system.
