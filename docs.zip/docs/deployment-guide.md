# Deployment Guide

## Overview
Complete guide for deploying IQTOP in development, staging, and production environments.

---

## Development Environment (Local)

### Prerequisites
```bash
# Required software
- Docker 24+ & Docker Compose
- Node.js 20+
- Python 3.11+
- Git
- Visual Studio Code (recommended)
```

### Step 1: Clone Repository
```bash
git clone https://github.com/your-org/iqtop.git
cd iqtop
```

### Step 2: Environment Setup
```bash
# Copy environment templates
cp .env.example .env

# Edit .env with your credentials
vi .env
```

**Required Environment Variables:**
```bash
# Database
POSTGRES_USER=iqtop_user
POSTGRES_PASSWORD=your_secure_password
POSTGRES_DB=iqtop
MONGODB_URI=mongodb://localhost:27017/iqtop

# RabbitMQ
RABBITMQ_DEFAULT_USER=guest
RABBITMQ_DEFAULT_PASS=guest

# Redis
REDIS_URL=redis://localhost:6379

# MinIO
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minioadmin

# Azure OpenAI
AZURE_OPENAI_API_KEY=your_api_key
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4o

# Figma
FIGMA_API_TOKEN=your_figma_token

# Rally
RALLY_API_KEY=your_rally_key
RALLY_SERVER=rally1.rallydev.com

# GitHub
GITHUB_TOKEN=your_github_token

# JWT
JWT_SECRET_KEY=generate_random_256_bit_key
JWT_ALGORITHM=HS256
```

### Step 3: Start Services with Docker Compose
```bash
# Start all infrastructure services
docker-compose up -d

# Verify services are running
docker-compose ps

# Expected output:
# - postgres (port 5432)
# - mongodb (port 27017)
# - rabbitmq (ports 5672, 15672)
# - redis (port 6379)
# - minio (ports 9000, 9001)
```

### Step 4: Initialize Database
```bash
# Run PostgreSQL migrations
cd backend
python -m alembic upgrade head

# Create initial admin user
python scripts/create_admin_user.py

# Initialize MongoDB indexes
python scripts/init_mongodb.py
```

### Step 5: Start Backend Services
```bash
# Terminal 1: FastAPI Gateway
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# Terminal 2: Master Agent
cd agents/master
source venv/bin/activate
python main.py

# Terminal 3: MCP Server
cd mcp-server
source venv/bin/activate
uvicorn main:app --port 8001

# Terminal 4: Specialized Agents (example: Playwright)
cd agents/playwright
npm install
npm run dev
```

### Step 6: Start Frontend
```bash
cd frontend
npm install
npm start

# Access at: http://localhost:4200
```

### Step 7: Verify Installation
```bash
# Check API health
curl http://localhost:8000/api/v1/health

# Check MCP Server
curl http://localhost:8001/mcp/v1/list_tools

# Check RabbitMQ Management UI
# http://localhost:15672 (guest/guest)

# Check MinIO Console
# http://localhost:9001 (minioadmin/minioadmin)
```

---

## Docker Compose Configuration

### File: `docker-compose.yml`

```yaml
version: '3.8'

services:
  # ========== Infrastructure Services ==========

  postgres:
    image: postgres:16-alpine
    container_name: iqtop-postgres
    environment:
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: ${POSTGRES_DB}
    ports:
      - "5432:5432"
    volumes:
      - postgres-data:/var/lib/postgresql/data
      - ./backend/db/schema.sql:/docker-entrypoint-initdb.d/01-schema.sql
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER}"]
      interval: 10s
      timeout: 5s
      retries: 5

  mongodb:
    image: mongo:7.0
    container_name: iqtop-mongodb
    environment:
      MONGO_INITDB_DATABASE: iqtop
    ports:
      - "27017:27017"
    volumes:
      - mongodb-data:/data/db
    healthcheck:
      test: echo 'db.runCommand("ping").ok' | mongosh localhost:27017/iqtop --quiet
      interval: 10s
      timeout: 5s
      retries: 5

  rabbitmq:
    image: rabbitmq:3.13-management-alpine
    container_name: iqtop-rabbitmq
    environment:
      RABBITMQ_DEFAULT_USER: ${RABBITMQ_DEFAULT_USER}
      RABBITMQ_DEFAULT_PASS: ${RABBITMQ_DEFAULT_PASS}
    ports:
      - "5672:5672"    # AMQP
      - "15672:15672"  # Management UI
    volumes:
      - rabbitmq-data:/var/lib/rabbitmq
    healthcheck:
      test: rabbitmq-diagnostics -q ping
      interval: 30s
      timeout: 10s
      retries: 5

  redis:
    image: redis:7-alpine
    container_name: iqtop-redis
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    command: redis-server --appendonly yes
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  minio:
    image: minio/minio:latest
    container_name: iqtop-minio
    environment:
      MINIO_ROOT_USER: ${MINIO_ROOT_USER}
      MINIO_ROOT_PASSWORD: ${MINIO_ROOT_PASSWORD}
    ports:
      - "9000:9000"  # API
      - "9001:9001"  # Console
    volumes:
      - minio-data:/data
    command: server /data --console-address ":9001"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      interval: 30s
      timeout: 10s
      retries: 3

  # ========== Application Services ==========

  fastapi-gateway:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: iqtop-gateway
    environment:
      DATABASE_URL: postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
      MONGODB_URI: mongodb://mongodb:27017/iqtop
      REDIS_URL: redis://redis:6379
      RABBITMQ_URL: amqp://${RABBITMQ_DEFAULT_USER}:${RABBITMQ_DEFAULT_PASS}@rabbitmq:5672
    ports:
      - "8000:8000"
    depends_on:
      postgres:
        condition: service_healthy
      mongodb:
        condition: service_healthy
      rabbitmq:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./backend:/app
    command: uvicorn main:app --host 0.0.0.0 --port 8000 --reload

  master-agent:
    build:
      context: ./agents/master
      dockerfile: Dockerfile
    container_name: iqtop-master-agent
    environment:
      DATABASE_URL: postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
      REDIS_URL: redis://redis:6379
      RABBITMQ_URL: amqp://${RABBITMQ_DEFAULT_USER}:${RABBITMQ_DEFAULT_PASS}@rabbitmq:5672
      MCP_SERVER_URL: http://mcp-server:8001
    depends_on:
      - rabbitmq
      - redis
      - postgres
    volumes:
      - ./agents/master:/app

  mcp-server:
    build:
      context: ./mcp-server
      dockerfile: Dockerfile
    container_name: iqtop-mcp-server
    ports:
      - "8001:8001"
    volumes:
      - ./mcp-server:/app
    command: uvicorn main:app --host 0.0.0.0 --port 8001 --reload

  # Example: Playwright Agent
  playwright-agent:
    build:
      context: ./agents/playwright
      dockerfile: Dockerfile
    container_name: iqtop-playwright-agent
    environment:
      MCP_SERVER_URL: http://mcp-server:8001
      MINIO_ENDPOINT: minio:9000
      MINIO_ACCESS_KEY: ${MINIO_ROOT_USER}
      MINIO_SECRET_KEY: ${MINIO_ROOT_PASSWORD}
    depends_on:
      - mcp-server
      - minio
    volumes:
      - ./agents/playwright:/app

volumes:
  postgres-data:
  mongodb-data:
  rabbitmq-data:
  redis-data:
  minio-data:

networks:
  default:
    name: iqtop-network
```

---

## Production Deployment (Kubernetes)

### Prerequisites
- Kubernetes cluster (EKS, AKS, or GKE)
- kubectl configured
- Helm 3+
- Docker registry (ECR, ACR, or DockerHub)

### Step 1: Build and Push Docker Images
```bash
# Build all images
./scripts/build_images.sh

# Tag for registry
docker tag iqtop-gateway:latest your-registry/iqtop-gateway:v1.0.0
docker tag iqtop-master-agent:latest your-registry/iqtop-master-agent:v1.0.0
# ... tag all images

# Push to registry
docker push your-registry/iqtop-gateway:v1.0.0
docker push your-registry/iqtop-master-agent:v1.0.0
# ... push all images
```

### Step 2: Create Kubernetes Namespace
```bash
kubectl create namespace iqtop-prod
kubectl config set-context --current --namespace=iqtop-prod
```

### Step 3: Create Secrets
```bash
# Database credentials
kubectl create secret generic db-credentials \
  --from-literal=postgres-user=iqtop_user \
  --from-literal=postgres-password=your_secure_password \
  --from-literal=postgres-db=iqtop

# Azure OpenAI
kubectl create secret generic azure-openai \
  --from-literal=api-key=your_api_key \
  --from-literal=endpoint=https://your-resource.openai.azure.com/

# GitHub
kubectl create secret generic github-credentials \
  --from-literal=token=your_github_token

# JWT
kubectl create secret generic jwt-secret \
  --from-literal=secret-key=$(openssl rand -hex 32)
```

### Step 4: Install Infrastructure with Helm

#### PostgreSQL
```bash
helm repo add bitnami https://charts.bitnami.com/bitnami
helm install postgresql bitnami/postgresql \
  --set auth.username=iqtop_user \
  --set auth.password=your_secure_password \
  --set auth.database=iqtop \
  --set primary.persistence.size=100Gi \
  --set readReplicas.replicaCount=2
```

#### MongoDB
```bash
helm install mongodb bitnami/mongodb \
  --set architecture=replicaset \
  --set replicaCount=3 \
  --set persistence.size=50Gi
```

#### RabbitMQ
```bash
helm install rabbitmq bitnami/rabbitmq \
  --set replicaCount=3 \
  --set persistence.size=10Gi \
  --set auth.username=iqtop \
  --set auth.password=your_secure_password
```

#### Redis
```bash
helm install redis bitnami/redis \
  --set architecture=replication \
  --set master.persistence.size=5Gi \
  --set replica.replicaCount=2
```

### Step 5: Deploy Application Services

#### Kubernetes Manifests

**fastapi-gateway-deployment.yaml**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: fastapi-gateway
  namespace: iqtop-prod
spec:
  replicas: 3
  selector:
    matchLabels:
      app: fastapi-gateway
  template:
    metadata:
      labels:
        app: fastapi-gateway
    spec:
      containers:
      - name: gateway
        image: your-registry/iqtop-gateway:v1.0.0
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: connection-string
        - name: AZURE_OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: azure-openai
              key: api-key
        resources:
          requests:
            cpu: 500m
            memory: 1Gi
          limits:
            cpu: 1000m
            memory: 2Gi
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: fastapi-gateway
  namespace: iqtop-prod
spec:
  selector:
    app: fastapi-gateway
  ports:
  - port: 80
    targetPort: 8000
  type: ClusterIP
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: fastapi-gateway-hpa
  namespace: iqtop-prod
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: fastapi-gateway
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

**ingress.yaml**
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: iqtop-ingress
  namespace: iqtop-prod
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/websocket-services: fastapi-gateway
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - iqtop.yourcompany.com
    secretName: iqtop-tls
  rules:
  - host: iqtop.yourcompany.com
    http:
      paths:
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: fastapi-gateway
            port:
              number: 80
      - path: /
        pathType: Prefix
        backend:
          service:
            name: angular-frontend
            port:
              number: 80
```

### Step 6: Deploy Monitoring

#### Prometheus + Grafana
```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install prometheus prometheus-community/kube-prometheus-stack \
  --set grafana.adminPassword=your_admin_password
```

#### ELK Stack (Logging)
```bash
helm repo add elastic https://helm.elastic.co
helm install elasticsearch elastic/elasticsearch
helm install kibana elastic/kibana
helm install filebeat elastic/filebeat
```

### Step 7: Configure DNS
```bash
# Get Ingress external IP
kubectl get ingress iqtop-ingress -o jsonpath='{.status.loadBalancer.ingress[0].ip}'

# Create A record in your DNS provider:
# iqtop.yourcompany.com -> <EXTERNAL_IP>
```

### Step 8: Initialize Database
```bash
# Run migrations job
kubectl apply -f k8s/jobs/init-database-job.yaml

# Verify
kubectl logs job/init-database
```

---

## Production Checklist

### Security
- [ ] TLS enabled for all external traffic
- [ ] mTLS for internal service-to-service communication (Istio)
- [ ] Secrets stored in Vault or AWS Secrets Manager
- [ ] RBAC configured for Kubernetes
- [ ] Network policies to restrict pod-to-pod communication
- [ ] WAF configured (Cloudflare or AWS WAF)
- [ ] Regular security scans (Trivy for images)

### Reliability
- [ ] All stateful services replicated (Postgres, MongoDB, RabbitMQ, Redis)
- [ ] Persistent volumes with backups
- [ ] Health checks for all services
- [ ] Horizontal Pod Autoscaling configured
- [ ] Resource requests and limits set
- [ ] PodDisruptionBudgets configured

### Monitoring
- [ ] Prometheus metrics exported from all services
- [ ] Grafana dashboards created
- [ ] Log aggregation configured (ELK or CloudWatch)
- [ ] Distributed tracing enabled (Jaeger)
- [ ] Alerting rules configured
- [ ] PagerDuty/Opsgenie integration

### Backup
- [ ] Daily PostgreSQL backups to S3
- [ ] Daily MongoDB backups to S3
- [ ] MinIO bucket replication to separate region
- [ ] Backup restoration tested

### Performance
- [ ] CDN configured for static assets (CloudFront)
- [ ] Database connection pooling (pgBouncer)
- [ ] Redis caching enabled
- [ ] Load testing completed (Locust or k6)
- [ ] API rate limiting configured

---

## Rollback Procedure

### Kubernetes Rollback
```bash
# Rollback to previous version
kubectl rollout undo deployment/fastapi-gateway

# Rollback to specific revision
kubectl rollout history deployment/fastapi-gateway
kubectl rollout undo deployment/fastapi-gateway --to-revision=2

# Check rollout status
kubectl rollout status deployment/fastapi-gateway
```

### Database Rollback
```bash
# Rollback Alembic migration
alembic downgrade -1

# Restore from backup
pg_restore -d iqtop backup_file.dump
```

---

## Disaster Recovery

### RTO/RPO Targets
- **RTO (Recovery Time Objective)**: 1 hour
- **RPO (Recovery Point Objective)**: 5 minutes

### Recovery Steps
1. Restore PostgreSQL from latest backup (15 min)
2. Restore MongoDB from latest backup (10 min)
3. Redeploy application from last known good version (20 min)
4. Verify all services healthy (10 min)
5. Resume operations (5 min)

---

This deployment guide ensures a **reliable**, **scalable**, and **secure** production environment.
