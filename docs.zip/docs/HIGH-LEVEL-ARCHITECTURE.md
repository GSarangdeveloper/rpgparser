# High-Level Physical Architecture

## Complete System Architecture Overview

This diagram shows the **complete physical architecture** of the IQTOP platform, displaying all layers from the user interface down to data storage.

```
┌─────────────────────────────────────────────────────────────────────┐
│                         PRESENTATION LAYER                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Angular 18+ SPA (Material Design / PrimeNG)                 │  │
│  │  - Project Management Dashboard                              │  │
│  │  - Test Configuration Wizards (4 types)                      │  │
│  │  - Real-time Workflow Monitoring                             │  │
│  │  - Artifact Viewer (Reports, Scripts, Test Cases)            │  │
│  │  - Approval Interface (Human-in-the-Loop)                    │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              ↕ (REST + WebSocket)
┌─────────────────────────────────────────────────────────────────────┐
│                          API GATEWAY LAYER                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  FastAPI Gateway (Python 3.11+)                              │  │
│  │  - Authentication & Authorization (JWT)                      │  │
│  │  - Request Validation (Pydantic v2)                          │  │
│  │  - Rate Limiting & Circuit Breaker                           │  │
│  │  - API Versioning (/api/v1/...)                              │  │
│  │  - WebSocket Manager (Socket.IO / native)                    │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────────────┐
│                      MESSAGE BROKER LAYER                           │
│  ┌────────────────────┐  ┌─────────────────────┐                   │
│  │  RabbitMQ          │  │  Redis (Cache +     │                   │
│  │  - Workflow Queue  │  │   PubSub for WS)    │                   │
│  │  - Priority Queue  │  │  - Session Store    │                   │
│  │  - Dead Letter Q   │  │  - Job Status Cache │                   │
│  └────────────────────┘  └─────────────────────┘                   │
└─────────────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────────────┐
│                    ORCHESTRATION LAYER                              │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Master Agent (Python - LangGraph / Temporal.io)             │  │
│  │  - Workflow State Machine (8 phases per test type)           │  │
│  │  - Task Delegation Logic                                     │  │
│  │  - Human-in-Loop Pause/Resume                                │  │
│  │  - Error Recovery & Retry Logic                              │  │
│  │  - Audit Logging                                             │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              ↕ (MCP Protocol)
┌─────────────────────────────────────────────────────────────────────┐
│                    MCP SERVER (Router + Registry)                   │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  FastAPI MCP Server                                          │  │
│  │  - Tool Registry (Dynamic Agent Discovery)                   │  │
│  │  - Request Router                                            │  │
│  │  - Load Balancer (Agent Pool Management)                     │  │
│  │  - Health Check System                                       │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────────────┐
│                    SPECIALIZED AGENT LAYER                          │
│  ┌────────────────┐ ┌─────────────────┐ ┌────────────────────┐    │
│  │ Test Scenario  │ │ Playwright      │ │ API Test           │    │
│  │ Generator      │ │ Executor        │ │ Executor           │    │
│  │ (Python+LLM)   │ │ (Node.js)       │ │ (Python+Postman)   │    │
│  └────────────────┘ └─────────────────┘ └────────────────────┘    │
│  ┌────────────────┐ ┌─────────────────┐ ┌────────────────────┐    │
│  │ Defect Logger  │ │ Script          │ │ Report             │    │
│  │ (Rally/Jira)   │ │ Generator       │ │ Generator          │    │
│  │                │ │ (Python)        │ │ (Allure/Playwright)│    │
│  └────────────────┘ └─────────────────┘ └────────────────────┘    │
│  ┌────────────────┐ ┌─────────────────┐ ┌────────────────────┐    │
│  │ Regression     │ │ GitHub          │ │ Legacy Modernizer  │    │
│  │ Analyzer       │ │ Integrator      │ │ (Python+LLM)       │    │
│  │ (Python+ML)    │ │ (Python+Git)    │ │                    │    │
│  └────────────────┘ └─────────────────┘ └────────────────────┘    │
└─────────────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────────────┐
│                    EXTERNAL INTEGRATIONS LAYER                      │
│  ┌─────────────┐ ┌──────────┐ ┌─────────┐ ┌────────┐ ┌─────────┐ │
│  │ Azure       │ │ Figma    │ │ Rally   │ │ GitHub │ │ Jenkins │ │
│  │ OpenAI      │ │ API      │ │ API     │ │ API    │ │ /CI/CD  │ │
│  │ (GPT-4o)    │ │          │ │ /Jira   │ │        │ │         │ │
│  └─────────────┘ └──────────┘ └─────────┘ └────────┘ └─────────┘ │
└─────────────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────────────┐
│                         DATA PERSISTENCE LAYER                      │
│  ┌────────────────────┐  ┌──────────────────┐  ┌────────────────┐ │
│  │ PostgreSQL 16      │  │ MongoDB          │  │ MinIO / S3     │ │
│  │ - Workflows        │  │ - Test Scenarios │  │ - Screenshots  │ │
│  │ - Projects         │  │ - LLM Responses  │  │ - Reports      │ │
│  │ - Users/Auth       │  │ - Audit Logs     │  │ - Video Traces │ │
│  │ - Test Results     │  │                  │  │ - Artifacts    │ │
│  └────────────────────┘  └──────────────────┘  └────────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Layer Descriptions

### 1. Presentation Layer
**Technology**: Angular 18+ SPA
**Purpose**: User interface for all interactions
**Key Features**:
- Project and workflow management
- Real-time monitoring via WebSocket
- Human-in-the-loop approval interface
- Artifact viewing (reports, scripts, videos)

**Deployment**: Nginx static hosting or CDN (CloudFront)

---

### 2. API Gateway Layer
**Technology**: FastAPI (Python 3.11+)
**Purpose**: Single entry point for all client requests
**Responsibilities**:
- Authentication (JWT tokens)
- Request validation (Pydantic)
- Rate limiting
- WebSocket connection management
- Publish messages to RabbitMQ
- Real-time updates via Redis PubSub

**Deployment**: Kubernetes Deployment (3+ replicas with HPA)

---

### 3. Message Broker Layer
**Technologies**: RabbitMQ + Redis
**Purpose**: Asynchronous communication and caching

**RabbitMQ Queues**:
- `start_ui_workflow`, `start_api_workflow`, `start_legacy_workflow`, `start_standalone_workflow`
- `resume_workflow` (for human approval)
- Dead letter queues for failed messages

**Redis Usage**:
- Cache workflow status (5-min TTL)
- PubSub for WebSocket fanout
- Distributed locks (Master Agent leader election)
- Session store

**Deployment**: StatefulSets (3-node clusters for both)

---

### 4. Orchestration Layer
**Technology**: Python with LangGraph (or Temporal.io)
**Purpose**: Workflow state machine and task orchestration
**Responsibilities**:
- Consume messages from RabbitMQ
- Execute 8-phase state machine
- Delegate tasks to MCP Server
- Handle pause/resume for human-in-the-loop
- Error recovery with exponential backoff
- Update workflow status in PostgreSQL

**Deployment**: Kubernetes Deployment (2 replicas with leader election - only 1 active)

---

### 5. MCP Server Layer
**Technology**: FastAPI
**Purpose**: Model Context Protocol server - routes tool calls to agents
**Responsibilities**:
- Maintain tool registry (tool_name → agent_url mapping)
- Route incoming tool calls to appropriate agents
- Load balancing across agent pools
- Health checks for all agents
- Circuit breaker pattern for fault tolerance

**Deployment**: Kubernetes Deployment (3 replicas)

---

### 6. Specialized Agent Layer
**Technologies**: Python 3.11+ (most agents), Node.js 20+ (Playwright)
**Purpose**: Execute specific tasks (test generation, execution, reporting, etc.)

**9 Specialized Agents**:

1. **Test Scenario Generator** (Python + OpenAI)
   - Fetch Figma designs
   - Fetch Rally user stories
   - Generate test scenarios with GPT-4

2. **Playwright Executor** (Node.js + Playwright)
   - Execute UI tests in browsers
   - Capture screenshots, videos, traces
   - Upload artifacts to MinIO

3. **API Test Executor** (Python + httpx + pytest)
   - Parse OpenAPI/Swagger specs
   - Execute API tests
   - Validate response schemas

4. **Defect Logger** (Python + Rally/Jira APIs)
   - Analyze test failures
   - Create defect tickets automatically
   - Attach screenshots and logs

5. **Script Generator** (Python + OpenAI)
   - Generate production-ready test scripts
   - Apply Page Object Model pattern
   - Format with Prettier/Black

6. **Report Generator** (Python + Allure)
   - Generate Allure HTML reports
   - Generate Playwright reports
   - Upload to MinIO

7. **Regression Analyzer** (Python + pandas + scikit-learn)
   - Compare current vs baseline results
   - Detect performance regressions
   - ML-based flakiness detection

8. **GitHub Integrator** (Python + GitPython + PyGithub)
   - Clone repository
   - Commit generated scripts
   - Create pull requests

9. **Legacy Modernizer** (Python + OCR + OpenAI)
   - Parse legacy docs (PDF, Word, Excel)
   - OCR for screenshots
   - Modernize with GPT-4

**Deployment**: Kubernetes Deployments (1-5 replicas per agent, HPA based on queue depth)

---

### 7. External Integrations Layer
**Purpose**: Third-party services that agents interact with

**Integrations**:
- **Azure OpenAI**: LLM for test generation, script generation, modernization
- **Figma API**: Fetch design specifications
- **Rally/Jira API**: Fetch user stories, create defects
- **GitHub API**: Commit code, create PRs
- **Jenkins/GitLab CI**: Trigger test runs (optional)

**Authentication**: API keys stored in Vault/AWS Secrets Manager

---

### 8. Data Persistence Layer
**Technologies**: PostgreSQL, MongoDB, MinIO/S3

**PostgreSQL (Relational Data)**:
- Users, Projects, Workflows
- WorkflowPhases (audit trail)
- TestScenarios, TestExecutions
- Artifacts metadata, GitHubCommits, Defects
- RegressionBaselines

**MongoDB (Document Store)**:
- test_scenarios_full (complete LLM interactions)
- agent_logs (detailed execution logs)
- audit_trail (user actions)
- llm_interactions (cost tracking)

**MinIO/S3 (Object Storage)**:
- Screenshots (PNG)
- Videos (MP4)
- Playwright traces (ZIP)
- Allure reports (HTML)
- Generated scripts (TypeScript/Python)
- User uploads (Swagger, legacy docs)

**Deployment**:
- PostgreSQL: StatefulSet (1 primary + 2 read replicas)
- MongoDB: StatefulSet (3-node replica set)
- MinIO: StatefulSet (4-node distributed mode)

---

## Data Flow Example: UI Testing Workflow

```
1. User submits form in Angular
   └─> REST POST to FastAPI Gateway
       └─> Gateway publishes to RabbitMQ ("start_ui_workflow")
           └─> Master Agent consumes message
               └─> Phase 1: Call MCP Server → Test Scenario Generator
                   └─> Agent calls Figma API + Rally API + Azure OpenAI
                       └─> Returns scenarios to Master Agent
                           └─> Master Agent saves to PostgreSQL
                               └─> Publishes to Redis PubSub
                                   └─> Gateway pushes to Angular via WebSocket
                                       └─> User sees scenarios, clicks "Approve"
                                           └─> POST /approve to Gateway
                                               └─> Gateway publishes "resume_workflow" to RabbitMQ
                                                   └─> Master Agent resumes
                                                       └─> Phase 3: Call MCP → Playwright Executor
                                                           └─> Executes tests, uploads to MinIO
                                                               └─> Phases 4-8 continue...
                                                                   └─> Final: GitHub commit & PR creation
```

---

## Communication Protocols

| From | To | Protocol | Port |
|------|----|----------|------|
| Angular | FastAPI Gateway | HTTPS (REST) | 443 |
| Angular | FastAPI Gateway | WSS (WebSocket) | 443 |
| FastAPI Gateway | RabbitMQ | AMQP | 5672 |
| FastAPI Gateway | Redis | Redis Protocol | 6379 |
| FastAPI Gateway | PostgreSQL | PostgreSQL Wire | 5432 |
| FastAPI Gateway | MongoDB | MongoDB Wire | 27017 |
| Master Agent | RabbitMQ | AMQP | 5672 |
| Master Agent | MCP Server | HTTP/2 or gRPC | 8001 |
| Master Agent | Redis | Redis Protocol | 6379 |
| MCP Server | Agents | HTTP | Various |
| Agents | Azure OpenAI | HTTPS | 443 |
| Agents | External APIs | HTTPS | 443 |
| Agents | MinIO | S3 API (HTTPS) | 9000 |

---

## Scalability & High Availability

### Stateless Services (Horizontal Scaling)
- **FastAPI Gateway**: 3-10 replicas (HPA based on CPU)
- **MCP Server**: 3-5 replicas (HPA based on requests)
- **Agents**: 1-5 replicas per agent (HPA based on queue depth)

### Stateful Services (Replicated)
- **PostgreSQL**: 1 primary + 2 read replicas (streaming replication)
- **MongoDB**: 3-node replica set (automatic failover)
- **RabbitMQ**: 3-node cluster (quorum queues)
- **Redis**: 3-node Sentinel (automatic failover)
- **MinIO**: 4-node distributed (erasure coding)

### Master Agent (Active-Passive)
- **2 replicas** with leader election via Redis
- Only 1 active at a time (consumes from RabbitMQ)
- Automatic failover if leader dies

---

## Security Architecture

### Network Security
```
Internet
   │
   ↓
[WAF: Cloudflare/AWS WAF] ← DDoS protection
   │
   ↓
[TLS Termination: Nginx Ingress] ← HTTPS
   │
   ↓
[Kubernetes Ingress] ← Internal routing
   │
   ↓
[Service Mesh: Istio] ← mTLS between pods
   │
   ↓
[Application Pods]
```

### Authentication Flow
```
1. User logs in via Angular
2. FastAPI Gateway validates credentials
3. Issues JWT access token (15 min expiry)
4. Issues refresh token (HttpOnly cookie, 7 days)
5. Angular stores access token in memory
6. All API calls include: Authorization: Bearer <token>
7. Gateway validates JWT on every request
8. RBAC check (admin/tester/viewer)
```

### Secrets Management
- **Development**: .env files (gitignored)
- **Production**: HashiCorp Vault or AWS Secrets Manager
- **Kubernetes**: External Secrets Operator syncs secrets from Vault
- **Never** commit secrets to Git
- Rotate secrets every 90 days

---

## Monitoring & Observability

### Metrics (Prometheus + Grafana)
- Workflow completion rate
- Phase-wise execution time
- API latency (p50, p95, p99)
- RabbitMQ queue depth
- Database connection pool utilization
- Agent health status

### Logging (ELK Stack)
- Centralized logs from all services
- Structured JSON logs
- Correlation ID across all components
- 30-day retention

### Tracing (Jaeger)
- Distributed tracing for workflows
- Track request through: Gateway → Master → MCP → Agent → External API
- Identify bottlenecks

### Alerting (PagerDuty)
- Workflow failure rate > 10%
- API error rate > 5%
- Any agent down > 5 min
- Database connection pool exhausted

---

## Disaster Recovery

### Backup Strategy
- **PostgreSQL**: Daily full backup + continuous WAL archiving → S3
- **MongoDB**: Daily snapshot → S3
- **MinIO**: Bucket replication to separate region

### Recovery Targets
- **RTO (Recovery Time Objective)**: 1 hour
- **RPO (Recovery Point Objective)**: 5 minutes

### Recovery Procedure
1. Restore PostgreSQL from backup (15 min)
2. Restore MongoDB from backup (10 min)
3. Redeploy application from Docker registry (20 min)
4. Verify health checks (10 min)
5. Resume operations (5 min)

---

## Performance Benchmarks

| Metric | Target | Notes |
|--------|--------|-------|
| Workflow initiation | < 500ms | Gateway response time |
| Phase 1 (scenario gen) | 30-60s | LLM latency dependent |
| Phase 3 (Playwright) | 2-5 min | Based on test count |
| Complete workflow | < 8 min | Excluding human approval |
| API latency (p95) | < 500ms | Gateway APIs |
| WebSocket latency | < 100ms | Real-time updates |
| Concurrent users | 500+ | With autoscaling |
| Workflows/hour | 1000+ | With proper scaling |

---

## Cost Breakdown (AWS Example)

| Component | Spec | Monthly Cost |
|-----------|------|--------------|
| EKS Control Plane | 1 cluster | $72 |
| EC2 Nodes | 3x t3.xlarge | $300 |
| RDS PostgreSQL | db.t3.large | $150 |
| ElastiCache Redis | cache.t3.medium | $50 |
| DocumentDB (MongoDB) | db.t3.medium | $100 |
| S3 Storage | 500 GB | $12 |
| Data Transfer | 1 TB | $90 |
| NAT Gateway | 3x | $100 |
| **Total** | | **~$874/month** |

*(Can be optimized to ~$600/month with reserved instances)*

---

## Quick Reference: Port Numbers

| Service | Port | Protocol | Purpose |
|---------|------|----------|---------|
| Angular (dev) | 4200 | HTTP | Dev server |
| FastAPI Gateway | 8000 | HTTP | API endpoints |
| MCP Server | 8001 | HTTP | Tool routing |
| PostgreSQL | 5432 | PostgreSQL | Database |
| MongoDB | 27017 | MongoDB | Document DB |
| RabbitMQ (AMQP) | 5672 | AMQP | Message queue |
| RabbitMQ (Mgmt) | 15672 | HTTP | Management UI |
| Redis | 6379 | Redis | Cache/PubSub |
| MinIO (API) | 9000 | S3 | Object storage |
| MinIO (Console) | 9001 | HTTP | Web console |

---

## Summary

This architecture provides:
- ✅ **Scalability**: Horizontal scaling for all stateless services
- ✅ **High Availability**: Replicated stateful services with automatic failover
- ✅ **Fault Tolerance**: Circuit breakers, retries, dead letter queues
- ✅ **Real-time Updates**: WebSocket for instant UI updates
- ✅ **Extensibility**: Easy to add new agents via MCP
- ✅ **Observability**: Comprehensive monitoring, logging, and tracing
- ✅ **Security**: OAuth2, JWT, mTLS, WAF, secrets management
- ✅ **Performance**: < 8 min complete workflow, 500+ concurrent users

This is a **production-grade, enterprise-ready architecture** that can scale from 10 to 10,000+ users.
