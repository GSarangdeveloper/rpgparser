"""
Test Case Management Module
Handles test case definitions, specifications, and validation
"""

import json
import yaml
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
import logging
from datetime import datetime
import hashlib

logger = logging.getLogger(__name__)


class TestType(Enum):
    """Test type enumeration"""
    UNIT = "unit"
    INTEGRATION = "integration"
    E2E = "e2e"
    COMPONENT = "component"
    REGRESSION = "regression"
    SMOKE = "smoke"
    PERFORMANCE = "performance"


class TestPriority(Enum):
    """Test priority levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class TestStatus(Enum):
    """Test case status"""
    DRAFT = "draft"
    READY = "ready"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class TestStep:
    """Individual test step definition"""
    action: str
    selector: Optional[str] = None
    data: Optional[Dict[str, Any]] = None
    expected: Optional[str] = None
    wait_for: Optional[str] = None
    screenshot: bool = False
    timeout: int = 30000
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class TestAssertion:
    """Test assertion definition"""
    type: str  # equals, contains, visible, enabled, etc.
    target: str  # selector or value
    expected: Any
    message: Optional[str] = None
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return asdict(self)


@dataclass
class TestCase:
    """Complete test case definition"""
    id: str
    name: str
    description: str
    type: TestType
    priority: TestPriority
    component: str  # Angular component name
    route: Optional[str] = None
    preconditions: List[str] = field(default_factory=list)
    steps: List[TestStep] = field(default_factory=list)
    assertions: List[TestAssertion] = field(default_factory=list)
    test_data: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    status: TestStatus = TestStatus.DRAFT
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    author: Optional[str] = None
    angular_version: Optional[str] = None
    
    def __post_init__(self):
        """Post initialization processing"""
        if not self.id:
            self.id = self._generate_id()
    
    def _generate_id(self) -> str:
        """Generate unique test case ID"""
        unique_string = f"{self.name}{self.component}{datetime.now().isoformat()}"
        return f"TC_{hashlib.md5(unique_string.encode()).hexdigest()[:8]}"
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        data = asdict(self)
        data['type'] = self.type.value
        data['priority'] = self.priority.value
        data['status'] = self.status.value
        data['created_at'] = self.created_at.isoformat()
        data['updated_at'] = self.updated_at.isoformat()
        data['steps'] = [step.to_dict() for step in self.steps]
        data['assertions'] = [assertion.to_dict() for assertion in self.assertions]
        return data
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'TestCase':
        """Create TestCase from dictionary"""
        # Convert enums
        data['type'] = TestType(data.get('type', 'e2e'))
        data['priority'] = TestPriority(data.get('priority', 'medium'))
        data['status'] = TestStatus(data.get('status', 'draft'))
        
        # Convert dates
        if 'created_at' in data and isinstance(data['created_at'], str):
            data['created_at'] = datetime.fromisoformat(data['created_at'])
        if 'updated_at' in data and isinstance(data['updated_at'], str):
            data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        
        # Convert steps and assertions
        if 'steps' in data:
            data['steps'] = [TestStep(**step) if isinstance(step, dict) else step 
                           for step in data['steps']]
        if 'assertions' in data:
            data['assertions'] = [TestAssertion(**assertion) if isinstance(assertion, dict) else assertion 
                                 for assertion in data['assertions']]
        
        return cls(**data)


@dataclass
class TestSuite:
    """Collection of related test cases"""
    id: str
    name: str
    description: str
    test_cases: List[TestCase] = field(default_factory=list)
    setup: Optional[List[TestStep]] = None
    teardown: Optional[List[TestStep]] = None
    environment: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    
    def add_test_case(self, test_case: TestCase):
        """Add test case to suite"""
        self.test_cases.append(test_case)
    
    def remove_test_case(self, test_case_id: str):
        """Remove test case from suite"""
        self.test_cases = [tc for tc in self.test_cases if tc.id != test_case_id]
    
    def get_test_case(self, test_case_id: str) -> Optional[TestCase]:
        """Get test case by ID"""
        for tc in self.test_cases:
            if tc.id == test_case_id:
                return tc
        return None
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'test_cases': [tc.to_dict() for tc in self.test_cases],
            'setup': [step.to_dict() for step in self.setup] if self.setup else None,
            'teardown': [step.to_dict() for step in self.teardown] if self.teardown else None,
            'environment': self.environment,
            'tags': self.tags,
            'created_at': self.created_at.isoformat()
        }


class TestCaseManager:
    """Manages test cases and suites"""
    
    def __init__(self, storage_path: Optional[Path] = None):
        """
        Initialize test case manager
        
        Args:
            storage_path: Path to store test cases
        """
        self.storage_path = storage_path or Path("./test_cases")
        self.storage_path.mkdir(exist_ok=True)
        self.test_cases: Dict[str, TestCase] = {}
        self.test_suites: Dict[str, TestSuite] = {}
        self._load_existing_cases()
    
    def _load_existing_cases(self):
        """Load existing test cases from storage"""
        # Load test cases
        cases_path = self.storage_path / "cases"
        if cases_path.exists():
            for file_path in cases_path.glob("*.json"):
                try:
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                        test_case = TestCase.from_dict(data)
                        self.test_cases[test_case.id] = test_case
                except Exception as e:
                    logger.error(f"Failed to load test case from {file_path}: {e}")
        
        # Load test suites
        suites_path = self.storage_path / "suites"
        if suites_path.exists():
            for file_path in suites_path.glob("*.json"):
                try:
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                        test_suite = self._dict_to_suite(data)
                        self.test_suites[test_suite.id] = test_suite
                except Exception as e:
                    logger.error(f"Failed to load test suite from {file_path}: {e}")
    
    def create_test_case(self, data: Dict[str, Any]) -> TestCase:
        """
        Create a new test case
        
        Args:
            data: Test case data
            
        Returns:
            Created test case
        """
        test_case = TestCase.from_dict(data)
        self.test_cases[test_case.id] = test_case
        self._save_test_case(test_case)
        logger.info(f"Created test case: {test_case.id}")
        return test_case
    
    def update_test_case(self, test_case_id: str, updates: Dict[str, Any]) -> Optional[TestCase]:
        """
        Update existing test case
        
        Args:
            test_case_id: Test case ID
            updates: Updates to apply
            
        Returns:
            Updated test case or None
        """
        if test_case_id not in self.test_cases:
            logger.error(f"Test case not found: {test_case_id}")
            return None
        
        test_case = self.test_cases[test_case_id]
        
        # Update fields
        for key, value in updates.items():
            if hasattr(test_case, key):
                setattr(test_case, key, value)
        
        test_case.updated_at = datetime.now()
        self._save_test_case(test_case)
        logger.info(f"Updated test case: {test_case_id}")
        return test_case
    
    def delete_test_case(self, test_case_id: str) -> bool:
        """
        Delete test case
        
        Args:
            test_case_id: Test case ID
            
        Returns:
            True if deleted successfully
        """
        if test_case_id not in self.test_cases:
            return False
        
        del self.test_cases[test_case_id]
        
        # Remove from storage
        file_path = self.storage_path / "cases" / f"{test_case_id}.json"
        if file_path.exists():
            file_path.unlink()
        
        logger.info(f"Deleted test case: {test_case_id}")
        return True
    
    def get_test_case(self, test_case_id: str) -> Optional[TestCase]:
        """Get test case by ID"""
        return self.test_cases.get(test_case_id)
    
    def list_test_cases(self, 
                       component: Optional[str] = None,
                       test_type: Optional[TestType] = None,
                       status: Optional[TestStatus] = None) -> List[TestCase]:
        """
        List test cases with optional filters
        
        Args:
            component: Filter by Angular component
            test_type: Filter by test type
            status: Filter by status
            
        Returns:
            Filtered list of test cases
        """
        test_cases = list(self.test_cases.values())
        
        if component:
            test_cases = [tc for tc in test_cases if tc.component == component]
        
        if test_type:
            test_cases = [tc for tc in test_cases if tc.type == test_type]
        
        if status:
            test_cases = [tc for tc in test_cases if tc.status == status]
        
        return test_cases
    
    def create_test_suite(self, data: Dict[str, Any]) -> TestSuite:
        """Create a new test suite"""
        test_suite = TestSuite(**data)
        self.test_suites[test_suite.id] = test_suite
        self._save_test_suite(test_suite)
        logger.info(f"Created test suite: {test_suite.id}")
        return test_suite
    
    def import_from_file(self, file_path: Path) -> Union[TestCase, TestSuite, List[TestCase]]:
        """
        Import test cases from file (JSON, YAML, or custom DSL)
        
        Args:
            file_path: Path to import file
            
        Returns:
            Imported test case(s) or suite
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Determine file type and parse
        if file_path.suffix == '.json':
            with open(file_path, 'r') as f:
                data = json.load(f)
        elif file_path.suffix in ['.yaml', '.yml']:
            with open(file_path, 'r') as f:
                data = yaml.safe_load(f)
        else:
            # Assume custom DSL format
            data = self._parse_custom_dsl(file_path)
        
        # Determine if it's a suite or individual test cases
        if 'test_cases' in data:
            # It's a suite
            return self.create_test_suite(data)
        elif isinstance(data, list):
            # Multiple test cases
            test_cases = []
            for tc_data in data:
                test_cases.append(self.create_test_case(tc_data))
            return test_cases
        else:
            # Single test case
            return self.create_test_case(data)
    
    def export_to_file(self, 
                      output_path: Path,
                      test_case_ids: Optional[List[str]] = None,
                      format: str = 'json') -> Path:
        """
        Export test cases to file
        
        Args:
            output_path: Output file path
            test_case_ids: Test cases to export (all if None)
            format: Export format (json, yaml)
            
        Returns:
            Path to exported file
        """
        output_path = Path(output_path)
        
        # Get test cases to export
        if test_case_ids:
            test_cases = [self.test_cases[id] for id in test_case_ids 
                         if id in self.test_cases]
        else:
            test_cases = list(self.test_cases.values())
        
        # Convert to dict format
        data = [tc.to_dict() for tc in test_cases]
        
        # Export based on format
        if format == 'json':
            with open(output_path, 'w') as f:
                json.dump(data, f, indent=2)
        elif format == 'yaml':
            with open(output_path, 'w') as f:
                yaml.dump(data, f, default_flow_style=False)
        else:
            raise ValueError(f"Unsupported export format: {format}")
        
        logger.info(f"Exported {len(test_cases)} test cases to {output_path}")
        return output_path
    
    def validate_test_case(self, test_case: TestCase) -> List[str]:
        """
        Validate test case completeness and syntax
        
        Args:
            test_case: Test case to validate
            
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        # Required fields
        if not test_case.name:
            errors.append("Test case name is required")
        
        if not test_case.component:
            errors.append("Angular component is required")
        
        if not test_case.steps:
            errors.append("At least one test step is required")
        
        # Validate steps
        for i, step in enumerate(test_case.steps):
            if not step.action:
                errors.append(f"Step {i+1}: Action is required")
            
            if step.action in ['click', 'fill', 'select'] and not step.selector:
                errors.append(f"Step {i+1}: Selector is required for {step.action} action")
            
            if step.action == 'fill' and not step.data:
                errors.append(f"Step {i+1}: Data is required for fill action")
        
        # Validate assertions
        for i, assertion in enumerate(test_case.assertions):
            if not assertion.type:
                errors.append(f"Assertion {i+1}: Type is required")
            
            if not assertion.target:
                errors.append(f"Assertion {i+1}: Target is required")
        
        return errors
    
    def _save_test_case(self, test_case: TestCase):
        """Save test case to storage"""
        cases_path = self.storage_path / "cases"
        cases_path.mkdir(exist_ok=True)
        
        file_path = cases_path / f"{test_case.id}.json"
        with open(file_path, 'w') as f:
            json.dump(test_case.to_dict(), f, indent=2)
    
    def _save_test_suite(self, test_suite: TestSuite):
        """Save test suite to storage"""
        suites_path = self.storage_path / "suites"
        suites_path.mkdir(exist_ok=True)
        
        file_path = suites_path / f"{test_suite.id}.json"
        with open(file_path, 'w') as f:
            json.dump(test_suite.to_dict(), f, indent=2)
    
    def _dict_to_suite(self, data: Dict) -> TestSuite:
        """Convert dictionary to TestSuite"""
        if 'test_cases' in data:
            data['test_cases'] = [TestCase.from_dict(tc) for tc in data['test_cases']]
        
        if 'setup' in data and data['setup']:
            data['setup'] = [TestStep(**step) for step in data['setup']]
        
        if 'teardown' in data and data['teardown']:
            data['teardown'] = [TestStep(**step) for step in data['teardown']]
        
        if 'created_at' in data and isinstance(data['created_at'], str):
            data['created_at'] = datetime.fromisoformat(data['created_at'])
        
        return TestSuite(**data)
    
    def _parse_custom_dsl(self, file_path: Path) -> Dict:
        """
        Parse custom DSL format for test cases
        
        Example DSL:
        TEST "Login Form Validation"
        COMPONENT LoginComponent
        ROUTE /login
        
        STEP click "#login-button"
        EXPECT visible ".error-message"
        ASSERT contains ".error-message" "Email is required"
        """
        # This is a simplified example - implement full DSL parser as needed
        with open(file_path, 'r') as f:
            content = f.read()
        
        # Basic parsing logic
        test_case = {
            'steps': [],
            'assertions': []
        }
        
        for line in content.split('\n'):
            line = line.strip()
            
            if line.startswith('TEST '):
                test_case['name'] = line[5:].strip('"')
            elif line.startswith('COMPONENT '):
                test_case['component'] = line[10:].strip()
            elif line.startswith('ROUTE '):
                test_case['route'] = line[6:].strip()
            elif line.startswith('STEP '):
                parts = line[5:].split(' ', 1)
                test_case['steps'].append({
                    'action': parts[0],
                    'selector': parts[1].strip('"') if len(parts) > 1 else None
                })
            elif line.startswith('ASSERT '):
                parts = line[7:].split(' ', 2)
                test_case['assertions'].append({
                    'type': parts[0],
                    'target': parts[1].strip('"'),
                    'expected': parts[2].strip('"') if len(parts) > 2 else None
                })
        
        return test_case