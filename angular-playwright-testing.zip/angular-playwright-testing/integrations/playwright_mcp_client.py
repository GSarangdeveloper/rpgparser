"""
Playwright MCP Integration Layer
Interfaces with Playwright MCP server for test execution and script generation
"""

import asyncio
import json
import logging
from typing import Dict, Any, List, Optional, AsyncGenerator
from dataclasses import dataclass, asdict
from enum import Enum
import aiohttp
import websockets
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)


class MCPMessageType(Enum):
    """MCP message types"""
    REQUEST = "request"
    RESPONSE = "response"
    NOTIFICATION = "notification"
    ERROR = "error"
    STREAM = "stream"


class MCPCapability(Enum):
    """MCP server capabilities"""
    SCRIPT_GENERATION = "script_generation"
    DOM_ANALYSIS = "dom_analysis"
    SELECTOR_OPTIMIZATION = "selector_optimization"
    TEST_EXECUTION = "test_execution"
    MAINTENANCE = "test_maintenance"
    DEBUGGING = "debugging"


@dataclass
class MCPMessage:
    """MCP protocol message"""
    id: str
    type: MCPMessageType
    method: str
    params: Dict[str, Any]
    timestamp: datetime = None
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now()
        if not self.id:
            self.id = str(uuid.uuid4())
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        data = {
            'id': self.id,
            'type': self.type.value,
            'method': self.method,
            'params': self.params,
            'timestamp': self.timestamp.isoformat()
        }
        return json.dumps(data)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'MCPMessage':
        """Create from JSON string"""
        data = json.loads(json_str)
        data['type'] = MCPMessageType(data['type'])
        data['timestamp'] = datetime.fromisoformat(data['timestamp'])
        return cls(**data)


@dataclass
class AngularContext:
    """Angular application context for MCP"""
    app_name: str
    version: str
    components: List[Dict[str, Any]]
    routes: List[Dict[str, Any]]
    modules: List[str]
    state_management: Optional[str] = None  # NgRx, Akita, etc.
    base_url: str = "http://localhost:4200"
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return asdict(self)


class PlaywrightMCPClient:
    """Client for Playwright MCP server communication"""
    
    def __init__(self, 
                 server_url: str = "ws://localhost:8765",
                 http_url: str = "http://localhost:8766"):
        """
        Initialize MCP client
        
        Args:
            server_url: WebSocket server URL for real-time communication
            http_url: HTTP server URL for REST API
        """
        self.server_url = server_url
        self.http_url = http_url
        self.websocket = None
        self.session = None
        self.capabilities: List[MCPCapability] = []
        self.connected = False
        self.message_handlers = {}
        self.pending_requests = {}
        
    async def connect(self) -> bool:
        """
        Establish connection to MCP server
        
        Returns:
            True if connected successfully
        """
        try:
            # Connect WebSocket
            self.websocket = await websockets.connect(self.server_url)
            self.connected = True
            
            # Create HTTP session
            self.session = aiohttp.ClientSession()
            
            # Discover capabilities
            await self._discover_capabilities()
            
            # Start message handler
            asyncio.create_task(self._handle_messages())
            
            logger.info(f"Connected to MCP server at {self.server_url}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to MCP server: {e}")
            return False
    
    async def disconnect(self):
        """Disconnect from MCP server"""
        if self.websocket:
            await self.websocket.close()
        
        if self.session:
            await self.session.close()
        
        self.connected = False
        logger.info("Disconnected from MCP server")
    
    async def generate_script(self,
                            test_case: Dict[str, Any],
                            angular_context: AngularContext,
                            options: Optional[Dict] = None) -> str:
        """
        Generate Playwright test script via MCP
        
        Args:
            test_case: Test case definition
            angular_context: Angular application context
            options: Generation options
            
        Returns:
            Generated Playwright script
        """
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="generateScript",
            params={
                'testCase': test_case,
                'context': angular_context.to_dict(),
                'options': options or {
                    'usePageObjects': True,
                    'includeScreenshots': True,
                    'includeVideos': False,
                    'parallelExecution': False
                }
            }
        )
        
        response = await self._send_request(message)
        
        if response and 'script' in response:
            return response['script']
        
        raise Exception("Failed to generate script")
    
    async def analyze_dom(self,
                         url: str,
                         component_selector: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze Angular DOM structure
        
        Args:
            url: Page URL
            component_selector: Specific component to analyze
            
        Returns:
            DOM analysis results
        """
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="analyzeDom",
            params={
                'url': url,
                'componentSelector': component_selector,
                'includeAngularInfo': True
            }
        )
        
        response = await self._send_request(message)
        
        return response.get('analysis', {})
    
    async def optimize_selectors(self,
                                selectors: List[str],
                                context: AngularContext) -> Dict[str, str]:
        """
        Optimize selectors for Angular components
        
        Args:
            selectors: List of selectors to optimize
            context: Angular context
            
        Returns:
            Optimized selectors mapping
        """
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="optimizeSelectors",
            params={
                'selectors': selectors,
                'context': context.to_dict(),
                'strategy': 'angular'  # Use Angular-specific optimization
            }
        )
        
        response = await self._send_request(message)
        
        return response.get('optimized', {})
    
    async def execute_test(self,
                          script: str,
                          config: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Execute test script through MCP
        
        Args:
            script: Playwright test script
            config: Execution configuration
            
        Returns:
            Execution results
        """
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="executeTest",
            params={
                'script': script,
                'config': config or {
                    'browser': 'chromium',
                    'headless': False,
                    'timeout': 30000,
                    'retries': 1
                }
            }
        )
        
        response = await self._send_request(message)
        
        return response.get('results', {})
    
    async def suggest_maintenance(self,
                                 test_script: str,
                                 error_log: str,
                                 context: AngularContext) -> List[Dict[str, Any]]:
        """
        Get test maintenance suggestions
        
        Args:
            test_script: Current test script
            error_log: Error log from failed test
            context: Angular context
            
        Returns:
            List of maintenance suggestions
        """
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="suggestMaintenance",
            params={
                'script': test_script,
                'errorLog': error_log,
                'context': context.to_dict()
            }
        )
        
        response = await self._send_request(message)
        
        return response.get('suggestions', [])
    
    async def stream_execution(self,
                              script: str,
                              config: Optional[Dict] = None) -> AsyncGenerator[Dict, None]:
        """
        Stream test execution updates
        
        Args:
            script: Test script to execute
            config: Execution configuration
            
        Yields:
            Execution updates
        """
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="streamExecution",
            params={
                'script': script,
                'config': config or {},
                'stream': True
            }
        )
        
        await self._send_message(message)
        
        # Stream responses
        while True:
            response = await self._receive_stream_response(message.id)
            if response is None:
                break
            
            yield response
    
    async def get_angular_metadata(self, url: str) -> Dict[str, Any]:
        """
        Extract Angular-specific metadata from application
        
        Args:
            url: Application URL
            
        Returns:
            Angular metadata
        """
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="getAngularMetadata",
            params={'url': url}
        )
        
        response = await self._send_request(message)
        
        return response.get('metadata', {})
    
    async def validate_test_script(self,
                                  script: str,
                                  context: AngularContext) -> Dict[str, Any]:
        """
        Validate test script against Angular best practices
        
        Args:
            script: Test script to validate
            context: Angular context
            
        Returns:
            Validation results
        """
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="validateScript",
            params={
                'script': script,
                'context': context.to_dict(),
                'rules': [
                    'angular_selectors',
                    'async_handling',
                    'state_management',
                    'routing'
                ]
            }
        )
        
        response = await self._send_request(message)
        
        return response.get('validation', {})
    
    async def _discover_capabilities(self):
        """Discover MCP server capabilities"""
        message = MCPMessage(
            id=str(uuid.uuid4()),
            type=MCPMessageType.REQUEST,
            method="getCapabilities",
            params={}
        )
        
        response = await self._send_request(message)
        
        if response and 'capabilities' in response:
            self.capabilities = [
                MCPCapability(cap) for cap in response['capabilities']
                if cap in [c.value for c in MCPCapability]
            ]
            logger.info(f"Discovered capabilities: {self.capabilities}")
    
    async def _send_message(self, message: MCPMessage):
        """Send message via WebSocket"""
        if not self.connected or not self.websocket:
            raise Exception("Not connected to MCP server")
        
        await self.websocket.send(message.to_json())
        logger.debug(f"Sent message: {message.id}")
    
    async def _send_request(self, message: MCPMessage, timeout: int = 30) -> Optional[Dict]:
        """
        Send request and wait for response
        
        Args:
            message: Message to send
            timeout: Response timeout in seconds
            
        Returns:
            Response data or None
        """
        # Store pending request
        future = asyncio.Future()
        self.pending_requests[message.id] = future
        
        # Send message
        await self._send_message(message)
        
        try:
            # Wait for response with timeout
            response = await asyncio.wait_for(future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            logger.error(f"Request timeout: {message.id}")
            return None
        finally:
            # Clean up
            if message.id in self.pending_requests:
                del self.pending_requests[message.id]
    
    async def _handle_messages(self):
        """Handle incoming messages from MCP server"""
        while self.connected:
            try:
                message_str = await self.websocket.recv()
                message_data = json.loads(message_str)
                
                # Handle response to pending request
                if message_data.get('type') == 'response':
                    request_id = message_data.get('requestId')
                    if request_id in self.pending_requests:
                        self.pending_requests[request_id].set_result(
                            message_data.get('data', {})
                        )
                
                # Handle notifications
                elif message_data.get('type') == 'notification':
                    await self._handle_notification(message_data)
                
                # Handle stream data
                elif message_data.get('type') == 'stream':
                    await self._handle_stream(message_data)
                
            except websockets.exceptions.ConnectionClosed:
                logger.warning("WebSocket connection closed")
                self.connected = False
                break
            except Exception as e:
                logger.error(f"Error handling message: {e}")
    
    async def _handle_notification(self, message_data: Dict):
        """Handle server notifications"""
        method = message_data.get('method')
        
        if method in self.message_handlers:
            handler = self.message_handlers[method]
            await handler(message_data.get('params', {}))
        else:
            logger.debug(f"Unhandled notification: {method}")
    
    async def _handle_stream(self, message_data: Dict):
        """Handle stream data"""
        stream_id = message_data.get('streamId')
        
        if stream_id in self.message_handlers:
            handler = self.message_handlers[stream_id]
            await handler(message_data.get('data', {}))
    
    async def _receive_stream_response(self, stream_id: str) -> Optional[Dict]:
        """Receive stream response"""
        # This would be implemented with proper stream handling
        # For now, return mock data
        return None
    
    def register_handler(self, method: str, handler):
        """
        Register message handler
        
        Args:
            method: Method or stream ID
            handler: Async handler function
        """
        self.message_handlers[method] = handler
    
    async def health_check(self) -> bool:
        """
        Check MCP server health
        
        Returns:
            True if server is healthy
        """
        try:
            async with self.session.get(f"{self.http_url}/health") as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('status') == 'healthy'
        except Exception as e:
            logger.error(f"Health check failed: {e}")
        
        return False


class MCPScriptBuilder:
    """Helper class to build MCP-compatible test scripts"""
    
    @staticmethod
    def build_angular_test(test_case: Dict[str, Any],
                          page_objects: bool = True) -> Dict[str, Any]:
        """
        Build Angular-specific test structure for MCP
        
        Args:
            test_case: Test case definition
            page_objects: Use page object pattern
            
        Returns:
            MCP-compatible test structure
        """
        test_structure = {
            'name': test_case.get('name'),
            'component': test_case.get('component'),
            'type': 'angular',
            'config': {
                'baseUrl': test_case.get('baseUrl', 'http://localhost:4200'),
                'waitForAngular': True,
                'angularTimeout': 10000
            },
            'setup': [],
            'steps': [],
            'assertions': [],
            'teardown': []
        }
        
        # Convert steps to MCP format
        for step in test_case.get('steps', []):
            mcp_step = {
                'action': step.get('action'),
                'target': {
                    'selector': step.get('selector'),
                    'strategy': 'angular'  # Use Angular-specific selector strategy
                },
                'data': step.get('data'),
                'options': {
                    'waitFor': step.get('wait_for', 'visible'),
                    'timeout': step.get('timeout', 30000),
                    'screenshot': step.get('screenshot', False)
                }
            }
            test_structure['steps'].append(mcp_step)
        
        # Convert assertions
        for assertion in test_case.get('assertions', []):
            mcp_assertion = {
                'type': assertion.get('type'),
                'target': assertion.get('target'),
                'expected': assertion.get('expected'),
                'message': assertion.get('message')
            }
            test_structure['assertions'].append(mcp_assertion)
        
        # Add Angular-specific setup
        test_structure['setup'] = [
            {'action': 'waitForAngular'},
            {'action': 'setAngularTimeout', 'value': 10000}
        ]
        
        return test_structure