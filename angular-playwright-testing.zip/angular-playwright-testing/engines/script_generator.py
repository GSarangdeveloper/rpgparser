"""
Script Generation Engine
Converts test cases into executable Playwright scripts with Angular support
"""

import os
import re
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass
import logging
from jinja2 import Environment, FileSystemLoader, Template
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class ScriptConfig:
    """Configuration for script generation"""
    use_page_objects: bool = True
    use_typescript: bool = True
    include_screenshots: bool = True
    include_videos: bool = False
    parallel_execution: bool = False
    retry_failed: int = 1
    timeout: int = 30000
    headless: bool = False
    slow_mo: int = 0
    angular_wait: bool = True
    allure_reporting: bool = True


class ScriptGenerator:
    """Generates Playwright test scripts from test cases"""
    
    def __init__(self, config: Optional[ScriptConfig] = None):
        """
        Initialize script generator
        
        Args:
            config: Script generation configuration
        """
        self.config = config or ScriptConfig()
        self.template_env = self._setup_templates()
        self.generated_scripts = {}
        
    def _setup_templates(self) -> Environment:
        """Setup Jinja2 template environment"""
        # Create templates directory if it doesn't exist
        template_dir = Path(__file__).parent.parent / "templates"
        template_dir.mkdir(exist_ok=True)
        
        # Create default templates
        self._create_default_templates(template_dir)
        
        env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Add custom filters
        env.filters['camelcase'] = self._camelcase
        env.filters['pascalcase'] = self._pascalcase
        env.filters['escape_quotes'] = self._escape_quotes
        
        return env
    
    def generate_test_script(self,
                           test_case: Dict[str, Any],
                           component_info: Optional[Dict] = None) -> str:
        """
        Generate Playwright test script from test case
        
        Args:
            test_case: Test case definition
            component_info: Angular component information
            
        Returns:
            Generated test script
        """
        # Determine template based on configuration
        if self.config.use_typescript:
            template_name = "playwright_test.ts.j2"
        else:
            template_name = "playwright_test.js.j2"
        
        template = self.template_env.get_template(template_name)
        
        # Prepare context for template
        context = self._prepare_context(test_case, component_info)
        
        # Generate script
        script = template.render(**context)
        
        # Store generated script
        script_id = test_case.get('id', 'unknown')
        self.generated_scripts[script_id] = script
        
        logger.info(f"Generated script for test case: {script_id}")
        
        return script
    
    def generate_page_object(self,
                           component_name: str,
                           selectors: Dict[str, str]) -> str:
        """
        Generate page object for Angular component
        
        Args:
            component_name: Name of Angular component
            selectors: Component selectors mapping
            
        Returns:
            Page object code
        """
        template = self.template_env.get_template("page_object.ts.j2")
        
        context = {
            'component_name': component_name,
            'class_name': self._pascalcase(component_name) + 'Page',
            'selectors': selectors,
            'timestamp': datetime.now().isoformat()
        }
        
        return template.render(**context)
    
    def generate_test_suite(self,
                          test_cases: List[Dict[str, Any]],
                          suite_name: str) -> str:
        """
        Generate test suite from multiple test cases
        
        Args:
            test_cases: List of test cases
            suite_name: Name of test suite
            
        Returns:
            Test suite script
        """
        template = self.template_env.get_template("test_suite.ts.j2")
        
        # Group test cases by component
        grouped_tests = self._group_by_component(test_cases)
        
        context = {
            'suite_name': suite_name,
            'test_groups': grouped_tests,
            'config': self.config,
            'timestamp': datetime.now().isoformat()
        }
        
        return template.render(**context)
    
    def generate_config_file(self, project_name: str = "angular-tests") -> str:
        """
        Generate Playwright configuration file
        
        Args:
            project_name: Project name
            
        Returns:
            Configuration file content
        """
        template = self.template_env.get_template("playwright.config.ts.j2")
        
        context = {
            'project_name': project_name,
            'config': self.config,
            'browsers': ['chromium', 'firefox', 'webkit'],
            'base_url': 'http://localhost:4200',
            'output_dir': './test-results',
            'use_allure': self.config.allure_reporting
        }
        
        return template.render(**context)
    
    def generate_helper_functions(self) -> str:
        """
        Generate Angular-specific helper functions
        
        Returns:
            Helper functions code
        """
        template = self.template_env.get_template("helpers.ts.j2")
        
        context = {
            'angular_wait': self.config.angular_wait,
            'timeout': self.config.timeout
        }
        
        return template.render(**context)
    
    def _prepare_context(self,
                        test_case: Dict[str, Any],
                        component_info: Optional[Dict]) -> Dict[str, Any]:
        """
        Prepare context for template rendering
        
        Args:
            test_case: Test case definition
            component_info: Component information
            
        Returns:
            Template context
        """
        context = {
            'test_name': test_case.get('name', 'Unnamed Test'),
            'test_id': test_case.get('id', 'unknown'),
            'component': test_case.get('component', 'Component'),
            'description': test_case.get('description', ''),
            'steps': self._process_steps(test_case.get('steps', [])),
            'assertions': self._process_assertions(test_case.get('assertions', [])),
            'test_data': test_case.get('test_data', {}),
            'config': self.config,
            'use_page_objects': self.config.use_page_objects,
            'tags': test_case.get('tags', []),
            'priority': test_case.get('priority', 'medium'),
            'route': test_case.get('route', '/'),
            'timestamp': datetime.now().isoformat()
        }
        
        if component_info:
            context['component_info'] = component_info
            context['selectors'] = component_info.get('selectors', {})
        
        return context
    
    def _process_steps(self, steps: List[Dict]) -> List[Dict]:
        """
        Process test steps for script generation
        
        Args:
            steps: Raw test steps
            
        Returns:
            Processed steps
        """
        processed = []
        
        for i, step in enumerate(steps):
            processed_step = {
                'index': i + 1,
                'action': step.get('action', 'unknown'),
                'selector': self._process_selector(step.get('selector')),
                'data': step.get('data'),
                'expected': step.get('expected'),
                'wait_for': step.get('wait_for', 'visible'),
                'timeout': step.get('timeout', self.config.timeout),
                'screenshot': step.get('screenshot', self.config.include_screenshots)
            }
            
            # Generate Playwright code for step
            processed_step['code'] = self._generate_step_code(processed_step)
            
            processed.append(processed_step)
        
        return processed
    
    def _process_assertions(self, assertions: List[Dict]) -> List[Dict]:
        """
        Process assertions for script generation
        
        Args:
            assertions: Raw assertions
            
        Returns:
            Processed assertions
        """
        processed = []
        
        for assertion in assertions:
            processed_assertion = {
                'type': assertion.get('type', 'equals'),
                'target': self._process_selector(assertion.get('target')),
                'expected': assertion.get('expected'),
                'message': assertion.get('message', '')
            }
            
            # Generate Playwright assertion code
            processed_assertion['code'] = self._generate_assertion_code(processed_assertion)
            
            processed.append(processed_assertion)
        
        return processed
    
    def _process_selector(self, selector: Optional[str]) -> str:
        """
        Process and optimize selector for Angular
        
        Args:
            selector: Raw selector
            
        Returns:
            Processed selector
        """
        if not selector:
            return ''
        
        # Convert Angular-specific selectors
        if selector.startswith('app-'):
            # Angular component selector
            return selector
        elif selector.startswith('#'):
            # ID selector
            return f"[id='{selector[1:]}']"
        elif selector.startswith('.'):
            # Class selector
            return selector
        elif selector.startswith('['):
            # Attribute selector
            return selector
        else:
            # Text selector
            return f"text={selector}"
    
    def _generate_step_code(self, step: Dict) -> str:
        """
        Generate Playwright code for a test step
        
        Args:
            step: Processed step
            
        Returns:
            Playwright code
        """
        action = step['action'].lower()
        selector = step['selector']
        
        code_lines = []
        
        # Add wait if needed
        if step.get('wait_for'):
            if step['wait_for'] == 'visible':
                code_lines.append(f"await page.waitForSelector('{selector}', {{ state: 'visible', timeout: {step['timeout']} }});")
            elif step['wait_for'] == 'network':
                code_lines.append(f"await page.waitForLoadState('networkidle');")
        
        # Generate action code
        if action == 'click':
            code_lines.append(f"await page.click('{selector}');")
        elif action == 'fill':
            data = step.get('data', '')
            code_lines.append(f"await page.fill('{selector}', '{data}');")
        elif action == 'select':
            data = step.get('data', '')
            code_lines.append(f"await page.selectOption('{selector}', '{data}');")
        elif action == 'check':
            code_lines.append(f"await page.check('{selector}');")
        elif action == 'uncheck':
            code_lines.append(f"await page.uncheck('{selector}');")
        elif action == 'hover':
            code_lines.append(f"await page.hover('{selector}');")
        elif action == 'navigate':
            url = step.get('data', '/')
            code_lines.append(f"await page.goto('{url}');")
        elif action == 'wait':
            timeout = step.get('data', 1000)
            code_lines.append(f"await page.waitForTimeout({timeout});")
        elif action == 'screenshot':
            name = step.get('data', 'screenshot')
            code_lines.append(f"await page.screenshot({{ path: '{name}.png' }});")
        
        # Add screenshot if configured
        if step.get('screenshot') and action != 'screenshot':
            code_lines.append(f"await page.screenshot({{ path: 'step_{step["index"]}.png' }});")
        
        return '\n    '.join(code_lines)
    
    def _generate_assertion_code(self, assertion: Dict) -> str:
        """
        Generate Playwright assertion code
        
        Args:
            assertion: Processed assertion
            
        Returns:
            Assertion code
        """
        type_ = assertion['type'].lower()
        target = assertion['target']
        expected = assertion['expected']
        
        if type_ == 'visible':
            return f"await expect(page.locator('{target}')).toBeVisible();"
        elif type_ == 'hidden':
            return f"await expect(page.locator('{target}')).toBeHidden();"
        elif type_ == 'enabled':
            return f"await expect(page.locator('{target}')).toBeEnabled();"
        elif type_ == 'disabled':
            return f"await expect(page.locator('{target}')).toBeDisabled();"
        elif type_ == 'equals':
            return f"await expect(page.locator('{target}')).toHaveText('{expected}');"
        elif type_ == 'contains':
            return f"await expect(page.locator('{target}')).toContainText('{expected}');"
        elif type_ == 'count':
            return f"await expect(page.locator('{target}')).toHaveCount({expected});"
        elif type_ == 'value':
            return f"await expect(page.locator('{target}')).toHaveValue('{expected}');"
        elif type_ == 'url':
            return f"await expect(page).toHaveURL('{expected}');"
        elif type_ == 'title':
            return f"await expect(page).toHaveTitle('{expected}');"
        else:
            return f"// Custom assertion: {type_}"
    
    def _group_by_component(self, test_cases: List[Dict]) -> Dict[str, List[Dict]]:
        """Group test cases by component"""
        grouped = {}
        
        for test_case in test_cases:
            component = test_case.get('component', 'General')
            if component not in grouped:
                grouped[component] = []
            grouped[component].append(test_case)
        
        return grouped
    
    def _camelcase(self, text: str) -> str:
        """Convert text to camelCase"""
        parts = re.sub(r'[^a-zA-Z0-9]', ' ', text).split()
        if not parts:
            return ''
        return parts[0].lower() + ''.join(p.capitalize() for p in parts[1:])
    
    def _pascalcase(self, text: str) -> str:
        """Convert text to PascalCase"""
        parts = re.sub(r'[^a-zA-Z0-9]', ' ', text).split()
        return ''.join(p.capitalize() for p in parts)
    
    def _escape_quotes(self, text: str) -> str:
        """Escape quotes in text"""
        return text.replace("'", "\\'").replace('"', '\\"')
    
    def _create_default_templates(self, template_dir: Path):
        """Create default template files"""
        
        # Playwright TypeScript test template
        playwright_ts_template = """import { test, expect, Page } from '@playwright/test';
{% if use_page_objects %}
import { {{ component }}Page } from './pages/{{ component | camelcase }}.page';
{% endif %}
{% if config.allure_reporting %}
import { allure } from 'allure-playwright';
{% endif %}

test.describe('{{ test_name }}', () => {
  let page: Page;
  {% if use_page_objects %}
  let {{ component | camelcase }}Page: {{ component }}Page;
  {% endif %}

  test.beforeEach(async ({ page: testPage }) => {
    page = testPage;
    {% if use_page_objects %}
    {{ component | camelcase }}Page = new {{ component }}Page(page);
    {% endif %}
    
    // Navigate to component route
    await page.goto('{{ route }}');
    
    {% if config.angular_wait %}
    // Wait for Angular to load
    await page.waitForFunction(() => {
      return window['getAllAngularTestabilities'] && 
             window['getAllAngularTestabilities']().length > 0;
    });
    {% endif %}
  });

  test('{{ test_name }}', async () => {
    {% if config.allure_reporting %}
    await allure.id('{{ test_id }}');
    await allure.epic('{{ component }}');
    await allure.story('{{ test_name }}');
    await allure.severity('{{ priority }}');
    {% endif %}
    
    {% for step in steps %}
    // Step {{ step.index }}: {{ step.action }}
    {{ step.code }}
    
    {% endfor %}
    
    {% for assertion in assertions %}
    // Assertion: {{ assertion.type }}
    {{ assertion.code }}
    
    {% endfor %}
  });

  test.afterEach(async () => {
    {% if config.include_screenshots %}
    await page.screenshot({ path: `screenshots/{{ test_id }}-${Date.now()}.png` });
    {% endif %}
  });
});
"""
        
        # Page Object template
        page_object_template = """import { Page, Locator } from '@playwright/test';

export class {{ class_name }} {
  readonly page: Page;
  
  // Selectors
  {% for name, selector in selectors.items() %}
  readonly {{ name | camelcase }}: Locator;
  {% endfor %}

  constructor(page: Page) {
    this.page = page;
    
    // Initialize locators
    {% for name, selector in selectors.items() %}
    this.{{ name | camelcase }} = page.locator('{{ selector }}');
    {% endfor %}
  }

  // Page methods
  async navigate() {
    await this.page.goto('{{ route }}');
  }

  async waitForAngular() {
    await this.page.waitForFunction(() => {
      return window['getAllAngularTestabilities'] && 
             window['getAllAngularTestabilities']().length > 0;
    });
  }
}
"""
        
        # Test suite template
        test_suite_template = """import { test } from '@playwright/test';
{% if config.allure_reporting %}
import { allure } from 'allure-playwright';
{% endif %}

test.describe('{{ suite_name }}', () => {
  {% for component, tests in test_groups.items() %}
  test.describe('{{ component }}', () => {
    {% for test in tests %}
    test('{{ test.name }}', async ({ page }) => {
      // Test implementation
      // Generated from test case: {{ test.id }}
    });
    
    {% endfor %}
  });
  
  {% endfor %}
});
"""
        
        # Save templates
        (template_dir / "playwright_test.ts.j2").write_text(playwright_ts_template)
        (template_dir / "page_object.ts.j2").write_text(page_object_template)
        (template_dir / "test_suite.ts.j2").write_text(test_suite_template)