"""
Main orchestrator for Angular Playwright Testing Framework
"""

import asyncio
import click
import logging
from pathlib import Path
from typing import Optional
import json
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

from modules.test_case_manager import TestCaseManager, TestType, TestPriority
from integrations.playwright_mcp_client import PlaywrightMCPClient, AngularContext
from engines.script_generator import ScriptGenerator, ScriptConfig
from integrations.git_manager import GitManager
from modules.allure_reporter import AllureReporter
from core.angular_mapper import AngularMapper
from core.test_data_manager import TestDataManager

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Rich console for beautiful output
console = Console()


class AngularTestOrchestrator:
    """Main orchestrator for the testing framework"""
    
    def __init__(self):
        self.test_manager = TestCaseManager()
        self.mcp_client = PlaywrightMCPClient()
        self.script_generator = ScriptGenerator()
        self.git_manager = GitManager()
        self.allure_reporter = AllureReporter()
        self.angular_mapper = AngularMapper()
        self.data_manager = TestDataManager()
        
    async def initialize(self):
        """Initialize all components"""
        console.print("[bold green]Initializing Angular Testing Framework...[/bold green]")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            # Connect to MCP server
            task = progress.add_task("Connecting to MCP server...", total=1)
            connected = await self.mcp_client.connect()
            progress.update(task, completed=1)
            
            if not connected:
                console.print("[bold red]Failed to connect to MCP server![/bold red]")
                return False
            
            # Initialize Git repository
            task = progress.add_task("Initializing Git repository...", total=1)
            self.git_manager.initialize_repo()
            progress.update(task, completed=1)
            
            # Setup Allure reporting
            task = progress.add_task("Setting up Allure reporting...", total=1)
            self.allure_reporter.setup()
            progress.update(task, completed=1)
        
        console.print("[bold green]✓ Framework initialized successfully![/bold green]")
        return True
    
    async def process_test_case(self, test_case_path: Path):
        """Process a single test case"""
        console.print(f"\n[bold cyan]Processing test case: {test_case_path}[/bold cyan]")
        
        # Import test case
        test_case = self.test_manager.import_from_file(test_case_path)
        
        # Validate test case
        errors = self.test_manager.validate_test_case(test_case)
        if errors:
            console.print("[bold red]Validation errors:[/bold red]")
            for error in errors:
                console.print(f"  • {error}")
            return None
        
        # Get Angular context
        angular_context = await self.angular_mapper.get_context(test_case.component)
        
        # Generate script via MCP
        console.print("Generating test script via MCP...")
        script = await self.mcp_client.generate_script(
            test_case.to_dict(),
            angular_context
        )
        
        # Save script
        script_path = Path(f"tests/{test_case.id}.spec.ts")
        script_path.parent.mkdir(exist_ok=True)
        script_path.write_text(script)
        
        # Commit to Git
        if self.git_manager.auto_commit:
            self.git_manager.commit_test_script(
                script_path,
                f"Add test: {test_case.name}"
            )
        
        console.print(f"[bold green]✓ Test script generated: {script_path}[/bold green]")
        return script_path
    
    async def run_tests(self, test_paths: list[Path]):
        """Execute generated tests"""
        console.print("\n[bold cyan]Running tests...[/bold cyan]")
        
        results = []
        for test_path in test_paths:
            # Execute via MCP
            result = await self.mcp_client.execute_test(
                test_path.read_text(),
                config={'browser': 'chromium', 'headless': False}
            )
            results.append(result)
            
            # Update test status
            test_id = test_path.stem
            self.test_manager.update_test_case(
                test_id,
                {'status': 'completed' if result['passed'] else 'failed'}
            )
        
        # Generate Allure report
        self.allure_reporter.generate_report(results)
        
        # Display results
        self._display_results(results)
        
        return results
    
    def _display_results(self, results):
        """Display test results in a table"""
        table = Table(title="Test Results")
        table.add_column("Test", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Duration", style="yellow")
        table.add_column("Errors", style="red")
        
        for result in results:
            status = "✓ Passed" if result['passed'] else "✗ Failed"
            table.add_row(
                result['name'],
                status,
                f"{result['duration']}ms",
                str(result.get('errors', 0))
            )
        
        console.print(table)


@click.group()
def cli():
    """Angular Playwright Testing Framework CLI"""
    pass


@cli.command()
@click.option('--path', '-p', type=click.Path(exists=True), required=True,
              help='Path to test case file or directory')
@click.option('--run', '-r', is_flag=True, help='Run tests after generation')
@click.option('--watch', '-w', is_flag=True, help='Watch for changes')
def generate(path, run, watch):
    """Generate test scripts from test cases"""
    async def _generate():
        orchestrator = AngularTestOrchestrator()
        
        if not await orchestrator.initialize():
            return
        
        path_obj = Path(path)
        test_paths = []
        
        if path_obj.is_file():
            # Process single file
            test_path = await orchestrator.process_test_case(path_obj)
            if test_path:
                test_paths.append(test_path)
        else:
            # Process directory
            for test_file in path_obj.glob('**/*.json'):
                test_path = await orchestrator.process_test_case(test_file)
                if test_path:
                    test_paths.append(test_path)
        
        if run and test_paths:
            await orchestrator.run_tests(test_paths)
        
        if watch:
            console.print("\n[bold yellow]Watching for changes... Press Ctrl+C to stop[/bold yellow]")
            # Implement file watcher here
    
    asyncio.run(_generate())


@cli.command()
@click.option('--component', '-c', help='Filter by component')
@click.option('--type', '-t', type=click.Choice(['unit', 'integration', 'e2e']),
              help='Filter by test type')
@click.option('--status', '-s', type=click.Choice(['draft', 'ready', 'completed', 'failed']),
              help='Filter by status')
def list(component, type, status):
    """List all test cases"""
    manager = TestCaseManager()
    
    test_type = TestType(type) if type else None
    test_cases = manager.list_test_cases(
        component=component,
        test_type=test_type,
        status=status
    )
    
    table = Table(title="Test Cases")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Component", style="yellow")
    table.add_column("Type", style="blue")
    table.add_column("Status", style="magenta")
    
    for tc in test_cases:
        table.add_row(
            tc.id,
            tc.name,
            tc.component,
            tc.type.value,
            tc.status.value
        )
    
    console.print(table)


@cli.command()
@click.option('--test-id', '-i', help='Specific test ID to run')
@click.option('--suite', '-s', help='Test suite to run')
@click.option('--browser', '-b', type=click.Choice(['chromium', 'firefox', 'webkit']),
              default='chromium', help='Browser to use')
@click.option('--headless', is_flag=True, help='Run in headless mode')
def run(test_id, suite, browser, headless):
    """Run tests"""
    async def _run():
        orchestrator = AngularTestOrchestrator()
        
        if not await orchestrator.initialize():
            return
        
        # Determine which tests to run
        test_paths = []
        if test_id:
            test_paths.append(Path(f"tests/{test_id}.spec.ts"))
        elif suite:
            test_paths.extend(Path("tests").glob(f"{suite}*.spec.ts"))
        else:
            test_paths.extend(Path("tests").glob("*.spec.ts"))
        
        # Configure execution
        config = {
            'browser': browser,
            'headless': headless
        }
        
        # Run tests
        results = await orchestrator.run_tests(test_paths)
        
        # Display summary
        passed = sum(1 for r in results if r['passed'])
        failed = len(results) - passed
        
        console.print(f"\n[bold]Test Summary:[/bold]")
        console.print(f"  [green]Passed: {passed}[/green]")
        console.print(f"  [red]Failed: {failed}[/red]")
        
        if failed > 0:
            exit(1)
    
    asyncio.run(_run())


@cli.command()
@click.option('--format', '-f', type=click.Choice(['html', 'json', 'junit']),
              default='html', help='Report format')
@click.option('--open', '-o', is_flag=True, help='Open report in browser')
def report(format, open):
    """Generate and view test reports"""
    reporter = AllureReporter()
    
    console.print(f"Generating {format} report...")
    report_path = reporter.generate_report(format=format)
    
    console.print(f"[bold green]Report generated: {report_path}[/bold green]")
    
    if open:
        import webbrowser
        webbrowser.open(f"file://{report_path.absolute()}")


@cli.command()
@click.option('--url', '-u', required=True, help='Angular application URL')
@click.option('--output', '-o', default='angular-context.json',
              help='Output file for context')
def analyze(url, output):
    """Analyze Angular application"""
    async def _analyze():
        orchestrator = AngularTestOrchestrator()
        
        if not await orchestrator.initialize():
            return
        
        console.print(f"Analyzing Angular application at {url}...")
        
        # Get Angular metadata
        metadata = await orchestrator.mcp_client.get_angular_metadata(url)
        
        # Analyze DOM structure
        dom_analysis = await orchestrator.mcp_client.analyze_dom(url)
        
        # Map components
        components = orchestrator.angular_mapper.map_components(dom_analysis)
        
        # Save context
        context = {
            'url': url,
            'metadata': metadata,
            'components': components,
            'routes': dom_analysis.get('routes', [])
        }
        
        Path(output).write_text(json.dumps(context, indent=2))
        
        console.print(f"[bold green]Analysis saved to: {output}[/bold green]")
        
        # Display summary
        console.print(f"\n[bold]Application Summary:[/bold]")
        console.print(f"  Components: {len(components)}")
        console.print(f"  Routes: {len(context['routes'])}")
        console.print(f"  Angular Version: {metadata.get('version', 'Unknown')}")
    
    asyncio.run(_analyze())


@cli.command()
def init():
    """Initialize testing framework in current directory"""
    console.print("[bold cyan]Initializing Angular Testing Framework...[/bold cyan]")
    
    # Create directory structure
    directories = [
        'tests',
        'test_cases',
        'test_data',
        'reports',
        'scripts',
        '.allure'
    ]
    
    for dir_name in directories:
        Path(dir_name).mkdir(exist_ok=True)
        console.print(f"  ✓ Created {dir_name}/")
    
    # Create configuration file
    config = {
        'angular': {
            'base_url': 'http://localhost:4200',
            'wait_for_angular': True
        },
        'playwright': {
            'browsers': ['chromium'],
            'headless': False
        },
        'mcp': {
            'server_url': 'ws://localhost:8765'
        },
        'git': {
            'auto_commit': True,
            'branch_prefix': 'test/'
        }
    }
    
    Path('config.json').write_text(json.dumps(config, indent=2))
    console.print("  ✓ Created config.json")
    
    # Create sample test case
    sample_test = {
        'name': 'Sample Test',
        'component': 'AppComponent',
        'route': '/',
        'steps': [
            {
                'action': 'navigate',
                'data': '/'
            },
            {
                'action': 'click',
                'selector': 'button'
            }
        ],
        'assertions': [
            {
                'type': 'visible',
                'target': 'h1'
            }
        ]
    }
    
    Path('test_cases/sample.json').write_text(json.dumps(sample_test, indent=2))
    console.print("  ✓ Created sample test case")
    
    console.print("\n[bold green]Framework initialized successfully![/bold green]")
    console.print("\nNext steps:")
    console.print("  1. Edit config.json with your settings")
    console.print("  2. Create test cases in test_cases/")
    console.print("  3. Run: python main.py generate -p test_cases/")


if __name__ == '__main__':
    cli()