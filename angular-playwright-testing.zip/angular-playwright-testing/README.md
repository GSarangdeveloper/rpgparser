# Angular Playwright Testing Framework with MCP Integration

A comprehensive testing framework that integrates Playwright with Angular applications through MCP (Model Context Protocol) for automated test generation, execution, and reporting.

## Architecture Overview

### Core Components

1. **Test Case Management Module** (`modules/test_case_manager.py`)
   - Handles test case definitions and specifications
   - Supports JSON, YAML, and custom DSL formats
   - Validates test completeness and syntax
   - Manages test suites and organization

2. **Playwright MCP Integration Layer** (`integrations/playwright_mcp_client.py`)
   - WebSocket and HTTP communication with Playwright MCP server
   - Script generation via MCP
   - DOM analysis for Angular components
   - Selector optimization
   - Test maintenance suggestions

3. **Script Generation Engine** (`engines/script_generator.py`)
   - Converts test cases to Playwright scripts
   - Supports TypeScript and JavaScript
   - Page Object pattern generation
   - Angular-specific helpers and utilities

4. **Git Integration Module** (`integrations/git_manager.py`)
   - Repository management
   - Automated commits and branching
   - Pull request creation
   - Version control for test scripts

5. **Allure Reporting Module** (`modules/allure_reporter.py`)
   - Comprehensive test reports
   - Screenshots and video capture
   - Performance metrics
   - Historical analysis

6. **Angular Component Mapper** (`core/angular_mapper.py`)
   - Component detection and analysis
   - Selector generation
   - Route mapping
   - State management integration

7. **Test Data Management** (`core/test_data_manager.py`)
   - Test data fixtures
   - Environment configurations
   - Data-driven testing support
   - Mock data generation

8. **CI/CD Integration** (`integrations/cicd_integration.py`)
   - Pipeline integration
   - Webhook support
   - Automated test execution
   - Result aggregation

## Installation

### Prerequisites

- Python 3.10+
- Node.js 16+
- Playwright
- Angular CLI
- Git

### Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd angular-playwright-testing
```

2. Install Python dependencies:
```bash
pip install -r requirements.txt
```

3. Install Playwright:
```bash
npx playwright install
```

4. Configure environment:
```bash
cp .env.example .env
# Edit .env with your configuration
```

## Usage

### 1. Define Test Cases

Create test cases in JSON format:

```json
{
  "name": "Login Form Validation",
  "component": "LoginComponent",
  "route": "/login",
  "steps": [
    {
      "action": "fill",
      "selector": "#email",
      "data": "user@example.com"
    },
    {
      "action": "fill",
      "selector": "#password",
      "data": "password123"
    },
    {
      "action": "click",
      "selector": "button[type='submit']"
    }
  ],
  "assertions": [
    {
      "type": "url",
      "expected": "/dashboard"
    }
  ]
}
```

### 2. Generate Test Scripts

```python
from modules.test_case_manager import TestCaseManager
from engines.script_generator import ScriptGenerator
from integrations.playwright_mcp_client import PlaywrightMCPClient

# Initialize components
test_manager = TestCaseManager()
generator = ScriptGenerator()
mcp_client = PlaywrightMCPClient()

# Load test case
test_case = test_manager.import_from_file("test_cases/login.json")

# Generate script
script = generator.generate_test_script(test_case)

# Or generate via MCP
await mcp_client.connect()
script = await mcp_client.generate_script(test_case, angular_context)
```

### 3. Execute Tests

```bash
# Run generated tests
npx playwright test

# Run with Allure reporting
npx playwright test --reporter=allure-playwright

# Run specific test suite
npx playwright test tests/login.spec.ts
```

### 4. View Reports

```bash
# Generate Allure report
allure generate allure-results -o allure-report

# Open report
allure open allure-report
```

## Workflow

### Phase 1: Test Case Input & Processing

1. **Test Case Definition**: Accept test cases in structured format
2. **Angular Component Mapping**: Map test cases to components
3. **Test Data Management**: Handle fixtures and configurations
4. **Validation**: Ensure test completeness

### Phase 2: Script Generation via MCP

1. **MCP Communication**: Connect to Playwright MCP server
2. **Context Building**: Send Angular application context
3. **Script Generation**: Generate optimized Playwright scripts
4. **Selector Optimization**: Use Angular-specific selectors

### Phase 3: Git Integration

1. **Repository Management**: Create/manage test repositories
2. **Branching Strategy**: Feature-based branching
3. **Automated Commits**: Generate meaningful commits
4. **Pull Request Workflow**: Optional PR creation

### Phase 4: Execution & Reporting

1. **Test Execution**: Run Playwright tests
2. **Allure Integration**: Generate comprehensive reports
3. **Report Generation**: Include screenshots, videos, metrics
4. **Historical Analysis**: Track trends over time

## Configuration

### Main Configuration (`config/settings.py`)

```python
PLAYWRIGHT_CONFIG = {
    'browsers': ['chromium', 'firefox', 'webkit'],
    'headless': False,
    'timeout': 30000,
    'retries': 1,
    'workers': 4,
    'use_allure': True
}

ANGULAR_CONFIG = {
    'base_url': 'http://localhost:4200',
    'wait_for_angular': True,
    'angular_timeout': 10000
}

MCP_CONFIG = {
    'server_url': 'ws://localhost:8765',
    'http_url': 'http://localhost:8766',
    'timeout': 30
}

GIT_CONFIG = {
    'repository': 'test-scripts',
    'branch_prefix': 'test/',
    'auto_commit': True,
    'create_pr': False
}
```

## API Reference

### Test Case Manager

```python
# Create test case
test_case = test_manager.create_test_case({
    'name': 'Test Name',
    'component': 'ComponentName',
    'steps': [...],
    'assertions': [...]
})

# Update test case
test_manager.update_test_case(test_case_id, updates)

# List test cases
test_cases = test_manager.list_test_cases(
    component='LoginComponent',
    test_type=TestType.E2E
)
```

### MCP Client

```python
# Connect to MCP server
await mcp_client.connect()

# Generate script
script = await mcp_client.generate_script(test_case, angular_context)

# Analyze DOM
analysis = await mcp_client.analyze_dom(url, component_selector)

# Optimize selectors
optimized = await mcp_client.optimize_selectors(selectors, context)
```

### Script Generator

```python
# Generate test script
script = generator.generate_test_script(test_case, component_info)

# Generate page object
page_object = generator.generate_page_object(component_name, selectors)

# Generate test suite
suite = generator.generate_test_suite(test_cases, suite_name)
```

## Angular-Specific Features

### Component Detection
- Automatic Angular component identification
- Component selector generation
- Dependency injection handling

### Router Integration
- Route-based test navigation
- Guard testing support
- Lazy-loaded module handling

### State Management
- NgRx integration
- State snapshot testing
- Action/Effect testing

### Change Detection
- Proper async handling
- Zone.js integration
- Change detection triggers

## CI/CD Integration

### GitHub Actions

```yaml
name: E2E Tests

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '16'
      
      - name: Install dependencies
        run: |
          npm ci
          npx playwright install
      
      - name: Generate tests
        run: python generate_tests.py
      
      - name: Run tests
        run: npx playwright test
      
      - name: Upload results
        uses: actions/upload-artifact@v2
        with:
          name: test-results
          path: test-results/
```

### Jenkins Pipeline

```groovy
pipeline {
    agent any
    
    stages {
        stage('Setup') {
            steps {
                sh 'npm install'
                sh 'npx playwright install'
            }
        }
        
        stage('Generate Tests') {
            steps {
                sh 'python generate_tests.py'
            }
        }
        
        stage('Run Tests') {
            steps {
                sh 'npx playwright test'
            }
        }
        
        stage('Report') {
            steps {
                allure([
                    results: [[path: 'allure-results']]
                ])
            }
        }
    }
}
```

## Scalability Considerations

### Performance Optimization
- Parallel test execution
- Browser resource management
- Test script caching
- Optimized selectors

### Maintenance Features
- Self-healing selectors
- Automatic script updates
- Test flakiness analysis
- Component change detection

## Security & Quality

### Code Quality
- Script validation
- Best practices enforcement
- Code review integration
- Static analysis

### Security Measures
- Credential management
- Environment isolation
- Access controls
- Secure test data handling

## Troubleshooting

### Common Issues

1. **MCP Connection Failed**
   - Check MCP server is running
   - Verify WebSocket URL
   - Check firewall settings

2. **Angular Detection Failed**
   - Ensure Angular app is running
   - Check base URL configuration
   - Verify Angular version compatibility

3. **Test Generation Errors**
   - Validate test case format
   - Check component selectors
   - Review error logs

## Contributing

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## License

MIT License - See LICENSE file for details

## Support

- GitHub Issues: [Report issues](https://github.com/...)
- Documentation: [Full docs](https://docs...)
- Community: [Discord/Slack](https://...)

## Roadmap

- [ ] Visual testing integration
- [ ] AI-powered test generation
- [ ] Cross-browser cloud testing
- [ ] Performance testing suite
- [ ] Accessibility testing
- [ ] Mobile testing support
- [ ] GraphQL testing
- [ ] WebSocket testing
- [ ] Security testing integration
- [ ] Load testing capabilities